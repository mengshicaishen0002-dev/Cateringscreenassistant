# v2.10.63 — Terminal-Loss Same-Card Recovery + Accept-Anchor Timing

Real-device trigger: offer `#abbe44de` ($86.38 / 3.3 mi) received `offer unavailable` after an Accept, but the exact same card was still/re-again visible. v2.10.62 recovered only from `ACCEPT_UNKNOWN`; explicit `ACCEPT_LOST` installed a 90-second suppression, producing a ~97-second gap before the same offer was tried again.

Changes:
- `ACCEPT_LOST` no longer erases ClaimBudget. A same-card recovery therefore continues as attempt #2/#3 instead of resetting to attempt #1.
- The ordinary 90-second terminal-loss suppression remains for stale/dead cards and all normal fast lanes.
- A single bounded exception observes for 6 seconds after terminal loss. It uses only the CURRENT semantic Accept index; no OCR/full-tree scan and no old rectangle.
- Retry requires the exact amount+mileage to match the old offer, compatible same-offer evidence, current enabled Accept geometry, unchanged rule pass, ClaimBudget capacity, and two current actionable observations separated by at least 180 ms.
- Only that verified current-card recovery clears the terminal-loss suppression. A proven departure/re-broadcast retains the older rearm path.
- Positive Jobs/detail evidence cancels recovery immediately.
- Added `ACCEPT_ANCHOR first seen -> dispatch` diagnostics. Comparing it with FIRST_SEEN shows whether remaining 400+ ms is DeliverThat's delayed Accept export or local dispatch delay; diagnostics never authorize a click.
- Reject no-tree behavior, Pasadena semantics, Gesture24ms, UNKNOWN recovery, success arbitration, and new-card foreground priority are unchanged.
