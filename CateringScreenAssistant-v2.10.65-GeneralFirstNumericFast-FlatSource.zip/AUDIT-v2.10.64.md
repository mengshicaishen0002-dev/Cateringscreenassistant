# v2.10.64 — Same-generation Visual Numeric Fast Lane

Field trigger: `$90 / 5mi` qualified offer logged `FIRST_SEEN→dispatch=1191ms` and fell back to `OCR顶部按钮热区`, while the final OCR itself was only ~131ms. Accessibility did not expose a usable semantic Accept anchor early enough.

## Change
- Added `VISUAL_NUMERIC_FAST` inside the pre-OCR visual lane.
- If the current captured frame has a verified filled-blue Accept rectangle and the SAME Accessibility UI generation already has amount+miles, the app may skip merchant/address/Accept-label completion **only** when `UniversalNumericFastPolicy` proves the numbers pass both General and Pasadena branches and no city allow-list/time filter can change the result.
- Current screen geometry, current DeliverThat package/page, UI generation and safe action bounds are still rechecked immediately before Gesture dispatch.
- Cross-generation evidence alone cannot authorize this lane; old coordinates are never reused.
- Reject path and thresholds are unchanged.
- OCR fallback remains unchanged for all non-universal or ambiguous offers.
- Corrected OCR Accept log text to report the actual `ActionDispatchPolicy.firstGestureDurationMs(true)` (24ms) instead of stale hard-coded `Gesture55ms` wording.

## Expected field log
A qualifying case like `$90 / 5mi` can now produce:
`证据来源=同代数值+当前视觉Accept ... OCR跳过`
instead of waiting for the OCR fallback when address/merchant/semantic Accept text is late.

## Regression
`run-regression-tests.sh` passes, including 242 v2.10.64 integration invariants.
