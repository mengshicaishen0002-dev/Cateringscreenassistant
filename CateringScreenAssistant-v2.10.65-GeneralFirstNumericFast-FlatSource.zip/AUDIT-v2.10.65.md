# v2.10.65 — General-First Numeric Fast Lane

Field trigger: real `$106.53 / 6.6mi` offer under General `$70 / 15mi` and Pasadena `$20 / 5mi` dispatched at `FIRST_SEEN→dispatch=392ms` and later `558ms`. v2.10.64 did not enter VISUAL_NUMERIC_FAST because it required the numbers to satisfy both General and Pasadena thresholds.

## Rule semantics fixed
- General is the base acceptance branch everywhere.
- Pasadena is an **additional** lower-threshold branch for Pasadena endpoint offers that fail General.
- A General-qualified offer is never turned into Reject merely because it exceeds the Pasadena-extra mileage cap.
- Pasadena-only offers still require current Pasadena endpoint evidence before Accept.
- Explicit city allow-list and active time filters still require their own evidence.

## Fast-path change
- `UNIVERSAL_NUMERIC_FAST` / `VISUAL_NUMERIC_FAST` may now skip Pasadena city resolution when the current amount+miles already satisfy General and no explicit city/time filter can change the result.
- Current enabled Accept geometry, same/current numeric pair, page/package guards, UI generation, claim budget and terminal-loss guards remain mandatory.
- No old coordinates and no numeric-only blind click.
- Reject, ACCEPT_LOST recovery, success arbitration and claim confirmation are otherwise unchanged.

## Real trace now covered
`$106.53 / 6.6mi`, General `$70 / 15mi`, Pasadena `$20 / 5mi` => General already PASS, so city is not on the critical path.

## Regression
`run-regression-tests.sh` passes: 8 universal numeric policy cases and 248 v2.10.65 integration invariants.
