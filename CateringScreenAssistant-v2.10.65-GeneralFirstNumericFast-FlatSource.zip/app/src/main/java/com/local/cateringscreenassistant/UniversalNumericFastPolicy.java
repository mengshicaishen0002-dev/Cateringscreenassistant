package com.local.cateringscreenassistant;

/**
 * Accept-only policy for deciding whether location evidence is mathematically irrelevant.
 * General is the base acceptance branch; Pasadena is an additional exception branch for offers
 * that do not pass General. It never authorizes an action by itself; the caller must still own
 * a fresh current Accept rectangle and independently re-prove the current amount/mileage pair.
 */
final class UniversalNumericFastPolicy {
    private UniversalNumericFastPolicy() { }

    static boolean qualifies(float amount, float miles,
                             float generalMinPay, float generalMaxMiles,
                             boolean pasadenaEnabled,
                             float pasadenaMinPay, float pasadenaMaxMiles,
                             boolean hasExplicitCityFilter,
                             boolean hasActiveTimeFilter) {
        if (amount < 0f || miles < 0f || hasExplicitCityFilter || hasActiveTimeFilter) return false;
        // v2.10.65: General is the base rule and Pasadena is an ADDITIONAL lower-threshold
        // branch, not an override that can invalidate an offer already accepted by General.
        // Therefore once General passes, location cannot turn the decision into Reject.
        // Pasadena evidence is needed only for offers that FAIL General and may qualify solely
        // through the Pasadena branch.
        return amount >= generalMinPay && miles <= generalMaxMiles;
    }
}
