package com.local.cateringscreenassistant;

/**
 * Process-wide per-offer Reject/Ignore arbiter. OCR and Accessibility must share the
 * same transaction; otherwise the same first card can be clicked once by each path.
 *
 * v2.10.33 adds two safety properties from real-device traces:
 *  1) a short terminal tombstone after a card disappears/finishes, so a transient RN
 *     reappearance cannot start a brand-new "attempt #1";
 *  2) retry #2 is allowed only after the same logical card has been observed visibly
 *     and continuously after attempt #1. A single late frame is not enough.
 */
final class RejectSequence {
    enum State { READY, WAIT, PROCESSING, TOMBSTONE, HOLD }

    private static final long RETRY_MS = 1100L;
    private static final long FAILED_RETRY_MS = 650L;
    private static final long PROCESSING_HOLD_MS = 7000L;
    private static final long DISAPPEARED_TOMBSTONE_MS = 5000L;
    private static final long TERMINAL_TOMBSTONE_MS = 8000L;
    private static final long VISIBLE_GAP_RESET_MS = 650L;
    private static final long MIN_RETRY_VISIBLE_STREAK_MS = 120L;
    private static final long RECENT_VISIBLE_MS = 500L;
    private static final long ENTRY_TTL_MS = 10 * 60_000L;
    private static final RejectSequence SHARED = new RejectSequence();

    static RejectSequence shared() { return SHARED; }

    private final java.util.LinkedHashMap<String, Entry> entries = new java.util.LinkedHashMap<>();
    private static final class Entry {
        int attempts;
        long retryAfter;
        long processingUntil;
        long tombstoneUntil;
        long lastTouched;
        long lastDispatchAt;
        long visibleSince;
        long lastVisibleAt;
        int visibleSamples;
        boolean holdReported;
        boolean reappearedReported;
    }

    private void purgeExpired(long now) {
        java.util.Iterator<java.util.Map.Entry<String, Entry>> it = entries.entrySet().iterator();
        while (it.hasNext()) {
            Entry e = it.next().getValue();
            if (e.lastTouched > 0 && now >= e.lastTouched && now - e.lastTouched > ENTRY_TTL_MS) it.remove();
        }
    }

    private Entry entry(String identity, long now) {
        purgeExpired(now);
        Entry value = entries.get(identity);
        if (value == null) {
            if (entries.size() >= 100) entries.remove(entries.keySet().iterator().next());
            value = new Entry();
            entries.put(identity, value);
        }
        value.lastTouched = now;
        return value;
    }

    /** Record that this exact logical offer is currently readable/visible. */
    synchronized void noteVisible(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts <= 0) return;
        if (value.lastVisibleAt <= 0 || now < value.lastVisibleAt
                || now - value.lastVisibleAt > VISIBLE_GAP_RESET_MS) {
            value.visibleSince = now;
            value.visibleSamples = 1;
        } else {
            value.visibleSamples++;
        }
        value.lastVisibleAt = now;
    }

    /** A confirmation probe failed to find the old card: break the continuous-visible streak. */
    synchronized void noteMissing(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts <= 0) return;
        value.visibleSince = 0;
        value.lastVisibleAt = 0;
        value.visibleSamples = 0;
    }

    synchronized State observe(String current, long now) {
        Entry value = entry(current, now);
        if (now < value.tombstoneUntil) return State.TOMBSTONE;
        if (value.attempts >= 2) return State.HOLD;
        if (now < value.processingUntil) return State.PROCESSING;
        if (now < value.retryAfter) return State.WAIT;
        if (value.attempts == 1 && !retryVisibilityReady(value, now)) return State.WAIT;
        return State.READY;
    }

    private boolean retryVisibilityReady(Entry value, long now) {
        if (value.visibleSamples < 2 || value.visibleSince <= 0 || value.lastVisibleAt <= 0) return false;
        if (now < value.visibleSince || now - value.visibleSince < MIN_RETRY_VISIBLE_STREAK_MS) return false;
        return now >= value.lastVisibleAt && now - value.lastVisibleAt <= RECENT_VISIBLE_MS;
    }

    /**
     * Atomically reserve a Reject attempt only when the same logical offer is actually READY.
     * OCR and Accessibility both call this shared gate, so only one source can own a dispatch.
     */
    synchronized int reserveIfReady(String current, long now) {
        Entry value = entry(current, now);
        if (now < value.tombstoneUntil || value.attempts >= 2
                || now < value.processingUntil || now < value.retryAfter) return 0;
        if (value.attempts == 1 && !retryVisibilityReady(value, now)) return 0;
        value.attempts++;
        value.lastDispatchAt = now;
        value.retryAfter = now + RETRY_MS;
        value.processingUntil = 0;
        value.tombstoneUntil = 0;
        value.visibleSince = now;
        value.lastVisibleAt = now;
        value.visibleSamples = 1;
        value.holdReported = false;
        value.reappearedReported = false;
        return value.attempts;
    }

    /** Reserve one actual Reject dispatch and return its 1-based attempt number. */
    synchronized int sent(String current, long now) {
        Entry value = entry(current, now);
        if (now < value.tombstoneUntil) return 0;
        if (value.attempts >= 2) return value.attempts;
        if (value.attempts == 1 && !retryVisibilityReady(value, now)) return 0;
        value.attempts++;
        value.lastDispatchAt = now;
        value.retryAfter = now + RETRY_MS;
        value.processingUntil = 0;
        value.visibleSince = now;
        value.lastVisibleAt = now;
        value.visibleSamples = 1;
        value.holdReported = false;
        value.reappearedReported = false;
        return value.attempts;
    }

    /** Positive UI acknowledgement: Reject became disabled/processing. */
    synchronized void markProcessing(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts <= 0 || now < value.tombstoneUntil) return;
        value.processingUntil = Math.max(value.processingUntil, now + PROCESSING_HOLD_MS);
        value.retryAfter = Math.max(value.retryAfter, value.processingUntil);
        value.holdReported = false;
    }

    /** Card vanished without strong server confirmation. Keep a short anti-reappearance tombstone. */
    synchronized void markDisappeared(String current, long now) {
        Entry value = entry(current, now);
        value.tombstoneUntil = Math.max(value.tombstoneUntil, now + DISAPPEARED_TOMBSTONE_MS);
        value.processingUntil = 0;
        value.retryAfter = Math.max(value.retryAfter, value.tombstoneUntil);
        value.visibleSince = 0;
        value.lastVisibleAt = 0;
        value.visibleSamples = 0;
        value.reappearedReported = false;
    }

    /** Strong completion/loss evidence: suppress stale reappearance longer. */
    synchronized void markTerminal(String current, long now) {
        Entry value = entry(current, now);
        // Strong terminal evidence means this logical offer must never be clicked again during
        // its retained lifetime. Saturate the attempt budget after the short UI tombstone.
        value.attempts = Math.max(value.attempts, 2);
        value.tombstoneUntil = Math.max(value.tombstoneUntil, now + TERMINAL_TOMBSTONE_MS);
        value.processingUntil = 0;
        value.retryAfter = Math.max(value.retryAfter, value.tombstoneUntil);
        value.visibleSince = 0;
        value.lastVisibleAt = 0;
        value.visibleSamples = 0;
        value.reappearedReported = false;
    }

    /** Undo a reservation when Android never dispatched the gesture/click. */
    synchronized void failed(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts > 0) value.attempts--;
        value.retryAfter = now + FAILED_RETRY_MS;
        value.processingUntil = 0;
        value.tombstoneUntil = 0;
        value.visibleSince = 0;
        value.lastVisibleAt = 0;
        value.visibleSamples = 0;
        value.holdReported = false;
        value.reappearedReported = false;
    }

    /** Returns true only once when the two-attempt ceiling is reached. */
    synchronized boolean markHoldReported(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts < 2 || value.holdReported) return false;
        value.holdReported = true;
        return true;
    }

    /** Returns true once if a tombstoned card becomes visible again. */
    synchronized boolean markReappearedReported(String current, long now) {
        Entry value = entry(current, now);
        if (now >= value.tombstoneUntil || value.reappearedReported) return false;
        value.reappearedReported = true;
        return true;
    }

    synchronized int attempts(String current, long now) { return entry(current, now).attempts; }

    synchronized void forget(String current) { entries.remove(current); }
}
