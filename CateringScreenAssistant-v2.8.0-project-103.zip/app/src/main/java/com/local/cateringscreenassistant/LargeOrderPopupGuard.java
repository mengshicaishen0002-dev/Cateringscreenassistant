package com.local.cateringscreenassistant;

import java.util.Locale;

/**
 * Detects DeliverThat's informational Large Order tooltip that can cover the action row.
 * This is intentionally text-only so it can be regression tested without Android classes.
 */
final class LargeOrderPopupGuard {
    private LargeOrderPopupGuard() { }

    static boolean isPopupText(String text) {
        String value = normalize(text);
        if (value.isEmpty()) return false;
        boolean multiDriver = value.contains("eligible to have multiple")
                && value.contains("drivers assigned");
        boolean earnings = value.contains("driver earnings displayed")
                || (value.contains("earnings") && value.contains("split equally"));
        return multiDriver || (earnings && value.contains("large order"));
    }

    /** One event fragment can be enough to arm the cheap popup hint before OCR finishes. */
    static boolean hasStrongFragment(String text) {
        String value = normalize(text);
        return value.contains("eligible to have multiple")
                || value.contains("drivers assigned to complete")
                || value.contains("driver earnings displayed");
    }

    private static String normalize(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.US)
                .replaceAll("[^a-z0-9$]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }
}
