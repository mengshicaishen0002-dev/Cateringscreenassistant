package com.local.cateringscreenassistant;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conservative pickup-city parser for Pasadena special rules.
 * A bare occurrence of the word "Pasadena" is never enough: the pickup address must expose
 * a California city/state segment, preferably with ZIP, and that parsed city must be Pasadena.
 */
final class PasadenaRuleGuard {
    private PasadenaRuleGuard() { }

    private static final Pattern OFFER_TIME = Pattern.compile(
            "\\b(?:today|tomorrow|january|february|march|april|may|june|july|august|september|october|november|december)"
                    + "(?:\\s+\\d{1,2})?\\s*(?:at)?\\s*\\d{1,2}:\\d{2}\\s*(?:am|pm)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern CITY_CA_ZIP = Pattern.compile(
            "([^,\\n•]{2,48}),\\s*(?:CA|California)\\s+(\\d{5})(?:-\\d{4})?\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PASADENA_CA_ZIP_NO_COMMA = Pattern.compile(
            "\\bPasadena\\s+(?:CA|California)\\s+\\d{5}(?:-\\d{4})?\\b",
            Pattern.CASE_INSENSITIVE);

    static String pickupCity(String cardText) {
        if (cardText == null || cardText.trim().isEmpty()) return "";
        String normalized = cardText.replace('•', ' ').replaceAll("[\\r\\n]+", " ")
                .replaceAll("\\s+", " ").trim();
        int start = 0;
        Matcher tm = OFFER_TIME.matcher(normalized);
        if (tm.find()) start = tm.end();
        String tail = normalized.substring(Math.min(start, normalized.length()));

        Matcher city = CITY_CA_ZIP.matcher(tail);
        if (city.find()) return cleanCity(city.group(1));
        // OCR sometimes drops the comma before CA. Allow only the exact Pasadena+CA+ZIP shape;
        // do not promote a merchant name or arbitrary text containing "Pasadena".
        if (PASADENA_CA_ZIP_NO_COMMA.matcher(tail).find()) return "Pasadena";
        return "";
    }

    static boolean isPasadenaPickup(String cardText) {
        return "pasadena".equals(pickupCity(cardText).toLowerCase(Locale.US));
    }

    static String auditTag(String cardText, boolean specialEnabled) {
        if (!specialEnabled) return "RULE=GENERAL; PASADENA_DISABLED";
        String city = pickupCity(cardText);
        if (city.isEmpty()) return "RULE=GENERAL; PICKUP_CITY_UNRESOLVED";
        if ("pasadena".equals(city.toLowerCase(Locale.US)))
            return "RULE=PASADENA; PICKUP_CITY=Pasadena";
        return "RULE=GENERAL; CITY_NOT_PASADENA(" + city + ")";
    }

    private static String cleanCity(String raw) {
        if (raw == null) return "";
        String city = raw.trim().replaceAll("\\s+", " ");
        // The regex segment immediately before ", CA ZIP" should be the city. In case OCR
        // included a street fragment separated by punctuation, keep only the last clean segment.
        int semicolon = Math.max(city.lastIndexOf(';'), city.lastIndexOf('|'));
        if (semicolon >= 0 && semicolon + 1 < city.length()) city = city.substring(semicolon + 1).trim();
        return city;
    }
}
