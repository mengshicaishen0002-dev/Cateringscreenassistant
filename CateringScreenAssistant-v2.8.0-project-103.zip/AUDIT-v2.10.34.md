# v2.10.34 Large Order Popup Guard Audit

## Field evidence
A DeliverThat Large Order informational tooltip can cover the action row while the underlying offer remains visible.
The 2026-09-11 Chicken Maison sample showed repeated OCR reads of `$38.11 / 12.7 mi` with the tooltip text and no reliable action anchor.
This UI obstruction must not be interpreted as a successful Reject disappearance.

## Changes
- Detect the multi-driver Large Order tooltip from Accessibility event/tree text and OCR text.
- While the tooltip is visible, freeze all Accept/Reject dispatch.
- OCR locates the tooltip X; if the X glyph itself is missed, infer only the tooltip top-right close point from the exact tooltip signature.
- Tap X first, then immediately rescan the same offer.
- Reject confirmation treats a visible/recent tooltip as UI obstruction: missingChecks reset to 0 and no REJECT_DISAPPEARED/CONFIRMED is emitted from that obstruction.
- Stabilize merchant identity when OCR inserts `Est.$`, distance, `Large Order`, or tooltip text after pickup time.

## Unchanged
- All pay/mileage/city/time thresholds.
- Pasadena special-rule semantics.
- v2.10.31 Accept epoch/fingerprint success isolation.
- v2.10.32 Reject direct dispatch.
- v2.10.33 Reject cross-source transaction/tombstone behavior.
- 80 ms configured scan default and established action gesture durations.
