# v2.10.33 Reject Cross-Source Transaction Audit

Scope: fix real-device traces where OCR Reject completed/disappeared, then Accessibility recreated the same semantic card as a new Reject transaction.

Changes:
- Shared RejectSequence now owns visibility continuity, tombstones, retry eligibility and cross-source reservation.
- Retry #2 requires >=2 recent visible observations spanning >=120ms after retry grace; a missing confirmation probe resets that streak.
- REJECT_DISAPPEARED -> 5s tombstone; REJECT_CONFIRMED / REJECT_LOST -> 8s tombstone.
- Same-card reappearance during tombstone emits one REJECT_REAPPEARED log and cannot dispatch.
- Async and legacy Reject confirmers feed visible/missing observations into the same sequence instead of forgetting the entry immediately.
- Standalone Accessibility Reject also uses reserveIfReady so every execution path follows the same arbiter.

Preserved:
- v2.10.31 Accept success epoch / semantic fingerprint state machine.
- v2.10.32 Reject action direct-dispatch optimization.
- 80ms monitor cadence, existing gesture durations, Pasadena rule guard, and all amount/mileage/city/time thresholds.
