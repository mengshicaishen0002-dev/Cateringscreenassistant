package com.local.cateringscreenassistant;

public class RejectSequenceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        RejectSequence sequence = new RejectSequence();
        check(sequence.observe("A", 0) == RejectSequence.State.READY);
        check(sequence.reserveIfReady("A", 0) == 1);
        check(sequence.observe("A", 100) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 1099) == RejectSequence.State.WAIT);
        // v2.10.33: time alone never authorizes retry #2.
        check(sequence.observe("A", 1100) == RejectSequence.State.WAIT);
        sequence.noteVisible("A", 1110);
        check(sequence.observe("A", 1110) == RejectSequence.State.WAIT);
        sequence.noteVisible("A", 1240);
        check(sequence.observe("A", 1240) == RejectSequence.State.READY);
        check(sequence.reserveIfReady("A", 1240) == 2);
        check(sequence.observe("A", 1241) == RejectSequence.State.HOLD);
        check(sequence.markHoldReported("A", 1241));
        check(!sequence.markHoldReported("A", 1242));

        RejectSequence atomic = new RejectSequence();
        check(atomic.reserveIfReady("RACE", 7000) == 1);
        check(atomic.reserveIfReady("RACE", 7000) == 0);
        atomic.noteVisible("RACE", 8100);
        check(atomic.reserveIfReady("RACE", 8100) == 0); // only one visible sample
        atomic.noteVisible("RACE", 8230);
        check(atomic.reserveIfReady("RACE", 8230) == 2);
        check(atomic.reserveIfReady("RACE", 8231) == 0);

        RejectSequence missingBreaksStreak = new RejectSequence();
        check(missingBreaksStreak.reserveIfReady("M", 1000) == 1);
        missingBreaksStreak.noteVisible("M", 2200);
        missingBreaksStreak.noteVisible("M", 2340);
        missingBreaksStreak.noteMissing("M", 2350);
        check(missingBreaksStreak.observe("M", 2351) == RejectSequence.State.WAIT);
        missingBreaksStreak.noteVisible("M", 2400);
        check(missingBreaksStreak.observe("M", 2400) == RejectSequence.State.WAIT);
        missingBreaksStreak.noteVisible("M", 2530);
        check(missingBreaksStreak.observe("M", 2530) == RejectSequence.State.READY);

        RejectSequence processing = new RejectSequence();
        check(processing.reserveIfReady("P", 4000) == 1);
        processing.markProcessing("P", 4200);
        check(processing.observe("P", 5000) == RejectSequence.State.PROCESSING);
        check(processing.observe("P", 11199) == RejectSequence.State.PROCESSING);
        // Once processing hold expires, retry still requires fresh continuous visibility.
        check(processing.observe("P", 11200) == RejectSequence.State.WAIT);
        processing.noteVisible("P", 11210);
        processing.noteVisible("P", 11340);
        check(processing.observe("P", 11340) == RejectSequence.State.READY);
        check(processing.reserveIfReady("P", 11340) == 2);

        RejectSequence disappeared = new RejectSequence();
        check(disappeared.reserveIfReady("D", 10000) == 1);
        disappeared.markDisappeared("D", 10100);
        check(disappeared.observe("D", 10101) == RejectSequence.State.TOMBSTONE);
        check(disappeared.markReappearedReported("D", 10102));
        check(!disappeared.markReappearedReported("D", 10103));
        disappeared.noteVisible("D", 12000);
        check(disappeared.observe("D", 12000) == RejectSequence.State.TOMBSTONE);
        check(disappeared.reserveIfReady("D", 12000) == 0);
        // Tombstone expires at 15100; a new persistent visible streak may then recover attempt #2.
        disappeared.noteVisible("D", 15110);
        check(disappeared.observe("D", 15110) == RejectSequence.State.WAIT);
        disappeared.noteVisible("D", 15240);
        check(disappeared.observe("D", 15240) == RejectSequence.State.READY);
        check(disappeared.reserveIfReady("D", 15240) == 2);

        RejectSequence terminal = new RejectSequence();
        check(terminal.reserveIfReady("T", 20000) == 1);
        terminal.markTerminal("T", 20100);
        check(terminal.observe("T", 20101) == RejectSequence.State.TOMBSTONE);
        check(terminal.markReappearedReported("T", 20102));
        check(!terminal.markReappearedReported("T", 20103));
        check(terminal.reserveIfReady("T", 27000) == 0);
        terminal.noteVisible("T", 28110);
        terminal.noteVisible("T", 28240);
        check(terminal.observe("T", 28240) == RejectSequence.State.HOLD);
        check(terminal.reserveIfReady("T", 28240) == 0);

        RejectSequence failed = new RejectSequence();
        check(failed.reserveIfReady("F", 30000) == 1);
        failed.markProcessing("F", 30050);
        failed.failed("F", 30100);
        check(failed.attempts("F", 30100) == 0);
        check(failed.observe("F", 30749) == RejectSequence.State.WAIT);
        check(failed.observe("F", 30750) == RejectSequence.State.READY);

        RejectSequence sent = new RejectSequence();
        check(sent.sent("S", 40000) == 1);
        check(sent.sent("S", 41100) == 0); // no continuous visible proof
        sent.noteVisible("S", 41110);
        sent.noteVisible("S", 41240);
        check(sent.sent("S", 41240) == 2);

        RejectSequence shared1 = RejectSequence.shared();
        RejectSequence shared2 = RejectSequence.shared();
        shared1.forget("SHARED");
        check(shared1.reserveIfReady("SHARED", 50000) == 1);
        check(shared2.observe("SHARED", 50001) == RejectSequence.State.WAIT);
        check(shared2.reserveIfReady("SHARED", 50001) == 0);
        shared2.forget("SHARED");

        sequence.forget("A");
        check(sequence.observe("A", 60000) == RejectSequence.State.READY);
        System.out.println("55 rejection sequence cases passed");
    }
}
