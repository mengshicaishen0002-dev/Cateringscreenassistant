package com.local.cateringscreenassistant;

public final class PasadenaRuleGuardTest {
    public static void main(String[] args) {
        check(PasadenaRuleGuard.isPasadenaPickup(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101, United States"),
                "real Pasadena address should use special rule");
        check(!PasadenaRuleGuard.isPasadenaPickup(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM Pasadena Cafe • 175 S Fairfax Ave, Los Angeles, CA 90036, United States"),
                "merchant word Pasadena must not trigger special rule");
        check(!PasadenaRuleGuard.isPasadenaPickup(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM Merchant Pasadena route note Los Angeles CA"),
                "bare Pasadena without parsed pickup city must stay general");
        check("RULE=PASADENA; PICKUP_CITY=Pasadena".equals(PasadenaRuleGuard.auditTag(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM X • 1 E Colorado Blvd, Pasadena, CA 91105", true)),
                "Pasadena audit tag");
        check(PasadenaRuleGuard.auditTag(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM X • 175 S Fairfax Ave, Los Angeles, CA 90036", true)
                .startsWith("RULE=GENERAL; CITY_NOT_PASADENA"), "general audit tag");
        System.out.println("PasadenaRuleGuardTest passed");
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
