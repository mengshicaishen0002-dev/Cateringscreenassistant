# AUDIT v2.10.29 — Reject Fast-Exit

Field trace: $28 / 2.2 mi was correctly rejected, but the action path spent about 47 ms in the action index, 400 ms in the bounded quick tree, 479 ms in the full tree, then traversed ~144 nodes again for ACTION_CLICK.

Changes:
- No amount/mileage/city/time rule values or rule semantics changed.
- Reuse a complete indexed Accept snapshot for ineligible offers and inspect only the same card/local action row for the paired left Reject control.
- Re-prove live amount+mileage on the indexed Accept ancestor before trusting the paired Reject coordinate.
- Reject ACTION_CLICK first follows branches intersecting the fresh verified Reject rectangle; only if that fails does the existing 180-node semantic probe run.
- Existing full-tree/OCR fallbacks remain available when local evidence is incomplete.
- Logging uses `Action索引` rather than the misleading `Accept索引` on Reject traces.

Safety invariants retained:
- exact top-card serial ownership
- same-offer numeric revalidation
- side-specific button geometry
- explicit Jobs/Ignored page guards
- two-attempt Reject arbiter and processing acknowledgement
- continuous monitoring and post-claim isolation
