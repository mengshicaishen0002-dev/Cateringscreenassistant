# v2.10.30 audit — action chain / async Reject / Pasadena guard

Scope is intentionally limited to three items. Existing amount, mileage, city and time thresholds are unchanged.

## 1. Action-chain latency
- Fresh verified Accept snapshots reuse the already-validated DeliverThat root bounds instead of reopening the hierarchy before the 55 ms gesture.
- Reject ACTION_CLICK first tries the exact live node overlapping the verified action rectangle before page-chrome/full semantic fallback.
- Duplicate DeliverThat foreground probes were removed from the Reject snapshot path; the actual dispatcher still validates package/page/geometry.

## 2. Reject confirmation is asynchronous
- Once ACTION_CLICK/gesture is dispatched, the first-card action lane is released immediately.
- Same-card duplicate Reject remains blocked by the existing process-wide RejectSequence retry/processing gate.
- Heavy post-Reject `findOffer()` confirmation runs on a dedicated `reject-confirm` background thread, not the latency-critical `offer-fast` thread.
- Confirmation still requires two consecutive missing reads, with processing acknowledgement for `REJECT_SUCCESS`; otherwise it records `REJECT_UNKNOWN`.

## 3. Pasadena rule protection + logs
- A bare word `Pasadena` no longer selects the Pasadena rule.
- The special rule is selected only when the pickup address parser resolves the California pickup city as Pasadena.
- Decision history includes `RULE=PASADENA; PICKUP_CITY=Pasadena` or a `RULE=GENERAL` reason such as `CITY_NOT_PASADENA(...)` / `PICKUP_CITY_UNRESOLVED`.
- The same guard is used by both foreground monitor and standalone Accessibility path.

Regression target: all prior tests + Pasadena guard tests + v2.10.30 source invariants.
