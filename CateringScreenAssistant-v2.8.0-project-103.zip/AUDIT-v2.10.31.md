# Catering Screen Assistant v2.10.31 — Accept State Machine Fix

Scope is intentionally narrow and driven by the 2026-09-10/11 real-device traces.

- **Global task epoch:** `scanGeneration` is now enforced by queued Accessibility scans and Accept Gesture callbacks. A Jobs badge increase / confirmed claim invalidates the whole older generation. Stale work is dropped before it can dispatch or mutate transaction state.
- **Completed offer guard:** confirmed offers are recorded by semantic identity plus a coarse completion alias (`pay + miles + pickup time`) used only for stale callback invalidation. Fresh offer dispatch never uses the coarse alias.
- **Stable semantic fingerprint regression:** real 4:47 Urbane OCR variants (`$20-30`, `$20-5`, duplicated/missing address characters) must resolve to the same card identity.
- **Accept direct lane:** an indexed Accept action may fuse fresh same-card Accessibility event fields, avoiding quick/full-tree traversal when the action row is already known. Full-tree scanning remains fallback only.
- **Duplicate OCR suppression:** once an Accept transaction is active, duplicate same-card OCR frames are silently suppressed. One success summary reports the number of suppressed frames and stale task drops instead of writing a log line per frame.
- **Reject outcome naming only:** behavior is unchanged, but logs distinguish `REJECT_CONFIRMED`, `REJECT_DISAPPEARED`, and `REJECT_LOST`.
- **Pasadena audit clarity:** logs now show parsed `Pickup city` separately from the configured allowed-city filter. Rule thresholds are unchanged.

Unchanged: 80 ms scan profile, 55 ms first Accept gesture, amount/mileage/city/time thresholds, strict top-card identity/action geometry, Jobs-increment success evidence, continuous monitoring after manual or automated claims.
