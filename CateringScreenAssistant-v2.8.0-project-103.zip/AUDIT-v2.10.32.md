# v2.10.32 Audit

Scope: eliminate the second full semantic-node walk before Reject ACTION_CLICK when the current decision snapshot already provides an exact Reject rectangle.

Changes:
- Added indexed live-action lookup constrained by the exact expected action rectangle.
- Reject/Accept semantic labels are resolved to their clickable node and must match the same physical action before click.
- Existing rectangle-pruned and 180-node semantic scans remain fallback-only.
- Increased rectangle-pruned fallback budget from 40 to 56 to tolerate empty React-Native containers without relaxing geometry.

Unchanged:
- Rule thresholds and Pasadena routing.
- v2.10.31 task epoch / semantic fingerprint / completed-set logic.
- Reject async confirmation and retry state machine.
- 80ms / 55ms action policies.
