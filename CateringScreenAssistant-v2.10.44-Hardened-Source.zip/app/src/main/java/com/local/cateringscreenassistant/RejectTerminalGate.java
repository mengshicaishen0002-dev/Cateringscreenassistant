package com.local.cateringscreenassistant;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * v2.10.41: per-Reject transaction generation/token gate.
 *
 * A card may legitimately be seen again later, so terminal ownership is scoped to the
 * current Reject transaction token rather than permanently to cardId.  Any callback from an
 * older generation is stale and must not write DEFERRED/CONFIRMED/DISAPPEARED/LOST after the
 * transaction has already moved on.  For a live token, only the first terminal outcome wins.
 */
final class RejectTerminalGate {
    private static final class Terminal {
        final long token;
        final String outcome;
        Terminal(long token, String outcome) {
            this.token = token;
            this.outcome = outcome == null ? "" : outcome;
        }
    }

    private final AtomicLong next = new AtomicLong();
    private final ConcurrentHashMap<String, Long> current = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Terminal> terminal = new ConcurrentHashMap<>();

    long begin(String id) {
        if (id == null || id.isEmpty()) return 0L;
        long token = next.incrementAndGet();
        current.put(id, token);
        // A new physical Reject action is a new transaction, even if DeliverThat reused cardId.
        terminal.remove(id);
        return token;
    }

    long currentOrBegin(String id) {
        if (id == null || id.isEmpty()) return 0L;
        Long token = current.get(id);
        return token != null ? token : begin(id);
    }

    boolean isCurrent(String id, long token) {
        if (id == null || id.isEmpty() || token <= 0L) return false;
        Long live = current.get(id);
        return live != null && live == token;
    }

    /** Returns true only for the first terminal write owned by the current token. */
    boolean tryTerminal(String id, long token, String outcome) {
        if (!isCurrent(id, token)) return false;
        final boolean[] won = {false};
        terminal.compute(id, (key, old) -> {
            if (old != null && old.token == token) return old;
            // If a newer transaction raced in, do not let the old token overwrite it.
            Long live = current.get(id);
            if (live == null || live != token) return old;
            won[0] = true;
            return new Terminal(token, outcome);
        });
        return won[0];
    }

    void invalidate(String id, long token) {
        if (id == null || id.isEmpty() || token <= 0L) return;
        current.remove(id, token);
    }

    String terminalOutcomeForTest(String id, long token) {
        Terminal value = terminal.get(id);
        return value != null && value.token == token ? value.outcome : "";
    }
}
