package com.local.cateringscreenassistant;

public class RejectTerminalGateTest {
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        RejectTerminalGate gate = new RejectTerminalGate();
        long t1 = gate.begin("cardA");
        check(gate.isCurrent("cardA", t1), "fresh token must be current");
        check(gate.tryTerminal("cardA", t1, "REJECT_DISAPPEARED"), "first terminal wins");
        check(!gate.tryTerminal("cardA", t1, "REJECT_CONFIRMED"), "conflicting second terminal blocked");
        check("REJECT_DISAPPEARED".equals(gate.terminalOutcomeForTest("cardA", t1)),
                "first terminal must remain authoritative");

        long t2 = gate.begin("cardA");
        check(t2 != t1 && gate.isCurrent("cardA", t2), "new transaction gets new generation");
        check(!gate.isCurrent("cardA", t1), "old callback token must become stale");
        check(!gate.tryTerminal("cardA", t1, "REJECT_LOST"), "stale generation cannot write terminal");
        check(gate.tryTerminal("cardA", t2, "REJECT_CONFIRMED"), "new generation may finish normally");
        gate.invalidate("cardA", t2);
        check(!gate.isCurrent("cardA", t2), "finished token must invalidate queued callbacks");
        System.out.println("RejectTerminalGateTest passed");
    }
}
