# v2.10.306 / versionCode 332
基线：v2.10.305。首个有效 Accept（首次 Spinner）优先于旧 Reject 清理及诊断。

- 结构事件：扫描结束时重查 dirty 与未消费 structural 标志；提交失败保留唤醒需求。Reject 日志仅标注本轮结构事件时间，非结构扫描标注 UNOBSERVED，避免历史事件误算。未增加 Accept 等待或改变扫描/手势参数。
- 旧卡：仅已确认 Reject Spinner 的事务、完整一致身份、无明确离开证据，才延长原动作租约到从动作起算最多 2500ms；这不是新卡的全局冷却。短期 OCR `WEI Segundo Blvd` → `W El Segundo Blvd` 仅用于 Hawthorne CA 90250 的 Reject 端点匹配；不修改 Accept 身份判定。门牌、商家、金额、里程、已知取餐时间和订单号冲突仍分开。缺少平台 ID 时无法证明是同一单。
- 合并旧卡读取：仅普通心跳、同 UI generation、48ms 内文本证据、无优先/结构/新订单需求，且当前规则仍明确拒绝该单时，允许跳过重复索引/Quick，保留 Presence 探测。新证据不被此门控延迟。无事件情况下的实际新卡发现时间仍需实机检查。
- 索引：线程本地纯文本解析缓存扩展到稳定文本、completionKey、Reject observation tail 和 Reject 端点；不缓存按钮 enabled 或动作许可。Binder query/action 长尾仍待实机测量。
- 尾部：增加 rejectAdmit、rejectDispatchCallback、rejectCallbackHandoff、rejectCallbackLog、rejectDispatchReturn 分段；同步回调仅记录所属扫描，异步回调不写入其它扫描。不能据此保证系统 ACTION_CLICK 耗时降低。
- OCR：保留 v305 视觉结果复用与缓冲区逻辑，增加增强 OCR 提交失败诊断；不降低识别精度或修改模型。无新 Accept 补击或 Spinner 参数调整。

验证：49 个纯 Java 测试类、55 组源码专项检查、61 个生产 Java 文件语法解析通过。关键修改后重跑对应检查。未运行 Android SDK/Gradle APK 编译、签名或实机性能测试。不同订单的 Reject 样本不能证明 Accept 端到端延迟或接单率提高。
