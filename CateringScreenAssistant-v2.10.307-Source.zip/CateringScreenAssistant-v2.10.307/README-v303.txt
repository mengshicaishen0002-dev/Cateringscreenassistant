v2.10.303 / 329. Two existing gesture modes; scan/transaction/replay fixes. Read CHANGELOG-v2.10.303.md. Source only.
