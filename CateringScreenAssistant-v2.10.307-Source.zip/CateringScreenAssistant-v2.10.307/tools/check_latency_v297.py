#!/usr/bin/env python3
"""Small production-source regression for 2.10.297's two latency paths."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/java/com/local/cateringscreenassistant'
tap=(root/'TapAccessibilityService.java').read_text()
scan=(root/'OcrMonitorService.java').read_text()
assert 'new BoundedReadBatch(3)' in tap
assert 'new String[]{"Jobs", "e", "$"}' in tap
assert 'if (progress != null || idleProbe)' in tap
assert 'if(progress != null) progress.queries += jobs.size();' in tap
assert 'idleProbe' in tap and '?service.idlePresenceBatch:service.rejectIndexBatch' in tap
assert 'EmptyIndexStatus.BUSY : EmptyIndexStatus.BUDGET' in tap
# No synchronous text index in a busy first-shot branch.
a=tap.index('} else if ("BUSY".equals(actionQuery.reason)) {')
b=tap.index('} else {',a+8)
branch=tap[a:b]
assert 'return failAcceptIndex("ACTION_INDEX_BUSY_YIELD")' in branch
assert 'root.findAccessibilityNodeInfosByText(' not in branch
assert 'scanExit="FIRST_SHOT_INDEX_BUSY_YIELD"' in scan
assert scan.index('scanExit="FIRST_SHOT_INDEX_BUSY_YIELD"') < scan.index('scanExit="PRESENCE_UNPROVEN_OFF_LANE"')
# Re-issued offers still pass through live valuation/Reject flow; no tombstone policy.
assert 'service.universallyRejectedByNumbers(rejectedObservation.amount,rejectedObservation.miles)' in scan
assert 'REJECT_SPINNER_CONFIRMED' in scan
assert 'service.monitorOnly(now,structural,priorityOffer)' in scan
assert 'service.scheduleIdlePresenceProbe();' in scan
print('v297: presence batch, fast BUSY yield, republished Reject, spinner and heartbeat checks passed')
