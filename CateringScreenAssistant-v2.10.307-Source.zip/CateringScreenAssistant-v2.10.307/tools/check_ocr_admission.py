from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text()
a=s.index('        final long epoch;',s.index('    private void evaluate('));b=s.index('        TapAccessibilityService.tapOcrOffer(',a);body=s[a:b]
head='''package com.local.cateringscreenassistant;
import java.util.concurrent.atomic.*;
class AdmissionHarness {void releaseAcceptAdmission(){acceptAdmissionBusy.set(false);}static class Rect{} Rect fullAccept=new Rect();void armAcceptPressure(TapAccessibilityService.FastOfferSnapshot s,long epoch){}
 static boolean isManualInterventionPaused(){return MANUAL_INTERVENTION_PAUSED.get();}
 static class SystemClock{static long elapsedRealtime(){return 5000;}}
 static class TapAccessibilityService{static class FastOfferSnapshot{FastOfferSnapshot(String t,Rect a,Rect b,boolean c,boolean d){}}static int recentJobsBadgeCount(){return 1;}}
 enum SerialAction{NONE,ACCEPT,REJECT}SerialAction serialTopAction=SerialAction.NONE;
 boolean monitorReady=true,blocked;AtomicBoolean acceptAdmissionBusy=new AtomicBoolean();static AtomicBoolean MANUAL_INTERVENTION_PAUSED=new AtomicBoolean();
 long serialTopActionAt,rejectProcessingConfirmedAt,rejectDispatchCompletedAt,rejectOutcomeBaselineEpoch,acceptProcessingConfirmedAt,lastActionDispatchAt,cooldownUntil;
 int pendingAcceptJobsBaseline,admitted,reports;String serialTopText="";AtomicLong claimEpoch=new AtomicLong(1),scanGeneration=new AtomicLong(1);ClaimBudget claimBudget=new ClaimBudget();
 static String CARD="$28–38 4.7 mi Tomorrow at 3:15 PM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 boolean isFinalOcrAcceptBlocked(String t,long n){return blocked;}void reportUnavailableTombstoneSuppressed(String t,long n){reports++;}void beginAcceptFrameSuppression(String t){}
 void admit(){String cardText=CARD,claimId=CardText.identity(cardText);
'''
tests=''' admitted++;}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
 AdmissionHarness h=new AdmissionHarness();h.admit();check(h.admitted==1&&h.serialTopAction==SerialAction.ACCEPT&&h.serialTopText.equals(CARD),"OCR reserves and establishes current owner once");check(h.claimEpoch.get()==2&&h.scanGeneration.get()==2&&!h.acceptAdmissionBusy.get(),"owner epochs advance and admission lock releases");
 h.admit();check(h.admitted==1,"same active owner cannot admit again");
 for(int kind=0;kind<5;kind++){h=new AdmissionHarness();switch(kind){case 0:h.blocked=true;break;case 1:h.monitorReady=false;break;case 2:h.serialTopAction=SerialAction.REJECT;break;case 3:MANUAL_INTERVENTION_PAUSED.set(true);break;case 4:h.acceptAdmissionBusy.set(true);break;}
 h.admit();check(h.admitted==0&&h.claimEpoch.get()==1,"unsafe admission does not acquire transaction "+kind);
 check(h.claimBudget.reserve(CardText.identity(CARD),CARD,5000)==1,"unsafe admission does not consume attempt "+kind);MANUAL_INTERVENTION_PAUSED.set(false);}
 h=new AdmissionHarness();h.blocked=true;h.admit();check(!h.acceptAdmissionBusy.get()&&h.reports==0,"current unsafe admission avoids legacy tombstone reporting and unlocks");
 h=new AdmissionHarness();for(int i=0;i<3;i++)h.claimBudget.reserve(CardText.identity(CARD),CARD,4000+i);h.admit();check(h.admitted==1&&h.serialTopAction==SerialAction.ACCEPT&&!h.acceptAdmissionBusy.get()&&h.claimBudget.reserve(CardText.identity(CARD),5000)==2,"new admitted publication resets completed historical attempt budget, then preserves current transaction");
 System.out.println(checks+" production OCR admission/ownership cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'AdmissionHarness.java';f.write_text(head+body+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d]+[str(src/n) for n in ['CardText.java','ClaimBudget.java','OfferEnrichmentPolicy.java']]+[str(f)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.AdmissionHarness'],check=True)
