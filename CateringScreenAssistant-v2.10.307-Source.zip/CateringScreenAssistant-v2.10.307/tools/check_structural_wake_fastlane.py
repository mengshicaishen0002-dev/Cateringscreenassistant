#!/usr/bin/env python3
"""Static hot-lane regressions; not a substitute for actual Android latency profiling."""
from pathlib import Path
r = Path(__file__).resolve().parents[1]
base = r / 'app/src/main/java/com/local/cateringscreenassistant'
o = (base / 'OcrMonitorService.java').read_text()
t = (base / 'TapAccessibilityService.java').read_text()
h = (base / 'HotOfferScanPolicy.java').read_text()
assert 'if ((structuralOfferWake || freshOfferEvent) && lane!=null && waiting!=null)' in o
assert 'lane.postAtFrontOfQueue(waiting)' in o
assert 'fastCheckDirty.set(true)' in o
assert 'boolean dirty=service.fastCheckDirty.getAndSet(false);' in o
assert 'if ((dirty || service.fastStructuralWake.get()) && service.monitorReady)' in o
assert 'private static final long HOT_HEARTBEAT_MS = 12L;' in h
assert 'private final BoundedReadBatch firstShotIndexBatch = new BoundedReadBatch(4,' in t
assert 'THREAD_PRIORITY_DISPLAY));' in t
assert 'firstShotIndexBatch.warmUp();' in t
assert 'firstShotIndexBatch.close();' in t
assert 'return service.firstShotIndexBatch.begin(jobs,90L);' in t
assert 'return readIndexedQueryPairOnBatch(service.firstShotIndexBatch,root,first,second,timeoutMs);' in t
assert 'private final LiveScanHealth liveScanHealth = new LiveScanHealth();' in o
assert 'service.liveScanHealth.enter(enteredAt,queuedAt,' in o
assert 'service.liveScanHealth.finish(Math.max(0L,finishedAt-enteredAt));' in o
assert 'scanTrace.note(now,"SCAN_HEALTH version="+engineVersion' in o and 'liveScanHealth.snapshotAndReset(now)' in o
assert 'idle_heartbeats=' in o and 'presence_probes=' in o
assert 'private final Runnable scanDiagnosticCheck = new Runnable()' in o
stale=o[o.index('scanExit = "STALE_AT_ENTRY";'):o.index('long now = SystemClock.elapsedRealtime();',o.index('scanExit = "STALE_AT_ENTRY";'))]
assert 'service.fastStructuralWake.set(true)' in stale and 'service.fastCheckDirty.set(true)' in stale
assert 'structural && service.monitorReady && !isManualInterventionPaused()' in stale
assert 'now - lastScreenOfferProbeAt < 12L' in o
assert 'READ_AHEAD_BUSY_YIELD' in t
print('17 production structural-wake, dedicated-index and telemetry invariants passed')
