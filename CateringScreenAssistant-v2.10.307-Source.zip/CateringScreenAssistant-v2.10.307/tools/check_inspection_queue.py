from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text();a=s.index('    private void scheduleClaimInspection(');i=s.index('{',a)+1;d=1
while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
method=s[a:i]
a=s.index('    private void scheduleEnabledClaimInspection(');i=s.index('{',a)+1;d=1
while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
method+=s[a:i]
head='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;
class QueueHarness {boolean canReadAcceptRecoveryProof(long owner){return true;}boolean scheduleEnabledProofRebind(String text,long epoch,long at){return false;}boolean acceptPressureActive(long owner){return false;}boolean resumePressureFromPage(String text,long epoch,long at){return false;}boolean resumeAcceptPressure(long owner,long epoch,long at){return false;}
 static class SystemClock{static long now=1000;static long elapsedRealtime(){return now;}}
 static class Handler{List<Runnable> jobs=new ArrayList<>();void postDelayed(Runnable r,long d){jobs.add(r);}void postAtFrontOfQueue(Runnable r){jobs.add(0,r);}void drain(){while(!jobs.isEmpty())jobs.remove(0).run();}}
 Handler fastWorker=new Handler();boolean monitorReady=true;AtomicLong claimEpoch=new AtomicLong(1);ClaimInspectionQueue claimInspectionQueue=new ClaimInspectionQueue();int reads;
 long serialTopActionAt=900,acceptControlEnabledActionAt,acceptControlEnabledAt;
 enum SerialAction{NONE,ACCEPT} SerialAction serialTopAction=SerialAction.ACCEPT;
 String acceptRetryGuard(long at){return "";}
 java.util.function.Consumer<String> acceptReporter(String t){return x->{};}
 void inspectClaim(String t,long e,int d,int m){reads++;}
 static int checks;static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
'''
test='''public static void main(String[] args){QueueHarness h=new QueueHarness();
 for(int i=0;i<1000;i++)h.scheduleClaimInspection("card",1,0,0,120);
 check(h.fastWorker.jobs.size()==1,"1000 duplicate delayed wakes keep one pending inspection");
 h.scheduleClaimInspection("card",1,0,0,0);h.fastWorker.drain();check(h.reads==1,"urgent proof replaces delayed work; old task does no read");
 h.scheduleClaimInspection("card",1,0,0,20);h.claimEpoch.set(2);h.scheduleClaimInspection("new",2,0,0,0);h.fastWorker.drain();check(h.reads==2,"old epoch cannot inspect new transaction");
 h.scheduleClaimInspection("new",2,0,0,20);h.monitorReady=false;h.fastWorker.drain();check(h.reads==2,"stop cancels scheduled work");
 ClaimInspectionQueue q=new ClaimInspectionQueue();long t=q.request(2,1000,20);check(q.request(1,1000,0)==0&&q.begin(t,2),"stale epoch cannot replace newer pending inspection");check(!q.begin(t,2),"ticket consumed once");
 QueueHarness h2=new QueueHarness();h2.scheduleClaimInspection("card",1,0,0,0);
 h2.fastWorker.jobs.add(0,()->{});h2.scheduleEnabledClaimInspection("card",1,1000);
 h2.fastWorker.drain();check(h2.reads==1,"enabled edge promotes overdue inspector and invalidates old ticket");
 t=q.request(3,1000,0);long u=q.urgent(3,1142);check(!q.begin(t,3)&&q.begin(u,3),"urgent replaces already due ticket behind Binder work");
 check(q.urgent(2,1142)==0,"old epoch cannot promote");
 System.out.println(checks+" production coalesced inspection scheduling cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'QueueHarness.java';p.write_text(head+method+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'ClaimInspectionQueue.java'),str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.QueueHarness'],check=True)
