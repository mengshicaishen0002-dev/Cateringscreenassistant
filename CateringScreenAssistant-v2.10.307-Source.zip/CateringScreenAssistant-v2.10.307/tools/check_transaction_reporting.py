#!/usr/bin/env python3
"""Exercise actual lazy Accept reporter and frozen-TX terminal reporting across text enrichment."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text()
def block(k):
 a=s.index(k);i=s.index('{',a)+1;n=1
 while n:n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
head='''package com.local.cateringscreenassistant;
import java.util.*;
public class ReportHarness {
 enum SerialAction{ACCEPT,NONE}SerialAction serialTopAction=SerialAction.ACCEPT;
 long serialTopActionAt=1000,postTerminalVerifyActionAt;String scanTiming="fast",engineVersion="2.10.246";
 final AcceptAttemptAudit acceptAudit=new AcceptAttemptAudit();PageOutcomePolicy.Tracker acceptPageTracker;
 List<String> reports=new ArrayList<>();int rules;
 static class SystemClock{static long elapsedRealtime(){return 1100;}}
 static class Writer{List<Runnable> queue=new ArrayList<>();void execute(Runnable r){queue.add(r);}void run(){while(!queue.isEmpty())queue.remove(0).run();}}Writer logWriter=new Writer();
 String ruleSummary(String t){rules++;return "rules";}String acceptTiming(String t,String a){return a;}
 void updateOfferStatus(String t,String c,String rules){reports.add(t);}
 static int cases;static void ck(boolean b,String m){cases++;if(!b)throw new AssertionError(m);}
'''
methods=block('    private java.util.function.Consumer<String> acceptReporter(')+block('    private java.util.function.Consumer<String> offerReporterWithTiming(')
test=''' public static void main(String[] args){
 String thin="$30–40 1.9 mi Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101";
 String rich="$30–40 1.9 mi Tomorrow at 10:20 AM Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101";
 ReportHarness h=new ReportHarness();h.acceptAudit.begin(1000,thin);h.acceptAudit.dispatched(1000,1010);
 h.acceptPageTracker=new PageOutcomePolicy.Tracker(1008,thin,null,false);
 java.util.function.Consumer<String> report=h.offerReporterWithTiming(rich,"fast");
 h.serialTopAction=SerialAction.NONE;h.serialTopActionAt=0;
 report.accept("ACCEPT_VERIFY_REQUIRED");ck(h.reports.get(0).contains("TX=1000")&&h.reports.get(0).contains("dispatchCount=1"),"enriched terminal text retains original frozen TX after foreground release");
 h.acceptAudit.begin(2000,rich);h.acceptAudit.dispatched(2000,2010);report.accept("ACCEPT_UNKNOWN");
 ck(!h.reports.get(1).contains("TX=2000"),"old reporter cannot borrow a new attempt ledger");
 h=new ReportHarness();java.util.function.Consumer<String> fast=h.acceptReporter(thin);
 ck(h.rules==0,"first-shot reporter creation performs no city/rule diagnostic parsing");
 fast.accept("Accept batch complete");ck(h.rules==0&&h.reports.isEmpty(),"completion formatting stays on background writer");
 h.serialTopActionAt=2000;h.logWriter.run();
 ck(h.reports.get(0).contains("TX=1000")&&!h.reports.get(0).contains("TX=2000"),"queued Accept report freezes owner rather than rereading global state");
 ck(h.rules==1,"background writer performs diagnostic rule parsing once");
 System.out.println(cases+" production transaction reporter/frozen-owner cases passed");
 }}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'ReportHarness.java';p.write_text(head+methods+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in ['CardText.java','OfferEnrichmentPolicy.java','PageOutcomePolicy.java','AcceptAttemptAudit.java']],str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.ReportHarness'],check=True)
