from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text();a=s.index('    private void awaitClaimProcessingOutcome(');b=s.index('{',a);i=b+1;d=1
while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
method=s[a:i]
head='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;
class ProcessingHarness {
 static class SystemClock {static long now;static long elapsedRealtime(){return now;}}
 static class TapAccessibilityService {static boolean jobsBadgeIncreasedSince(int x){return false;}static boolean isTerminalNegativeClaimOutcome(String s){return !s.isEmpty();}}
 boolean monitorReady=true;AtomicLong claimEpoch=new AtomicLong(1);enum SerialAction{ACCEPT,NONE}SerialAction serialTopAction=SerialAction.ACCEPT;
 String serialTopText="$175.53 2.1 mi (~10 mins) Mendocino Farms • 450 E 17th St, Costa Mesa, CA 92627",terminal="";long serialTopActionAt=1000;int pendingAcceptJobsBaseline,inspections,losses;
 List<Runnable> tasks=new ArrayList<>();class Handler{void postDelayed(Runnable r,long ms){tasks.add(r);}}Handler fastWorker=new Handler();
 String acceptScopedTerminalOutcomeSince(long t){return terminal;}String acceptScopedOutcomeSince(long t){return "";}
 boolean isBoundPositiveClaimOutcome(String a,String b,long t){return false;}void confirmPendingClaimSuccess(String a,String b){}
 void scheduleClaimInspection(String t,long e,int d,int m,long delay){inspectClaim(t,e,d,m);}void finishPendingClaimLoss(String a,String b,boolean c){losses++;}void inspectClaim(String a,long b,int c,int d){inspections++;}
 boolean verifiedAcceptRetryMatches(String text){return false;}
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
'''
test='''public static void main(String[] args){ProcessingHarness h=new ProcessingHarness();SystemClock.now=1349;h.awaitClaimProcessingOutcome(h.serialTopText,1,0,1300,true);check(h.inspections==0&&h.tasks.size()==1,"first quiet window must not inspect before50ms");
 h.tasks.clear();SystemClock.now=1350;h.awaitClaimProcessingOutcome(h.serialTopText,1,0,1300,true);check(h.inspections==1,"first processing window may fresh-check early");
 h=new ProcessingHarness();SystemClock.now=1490;h.awaitClaimProcessingOutcome(h.serialTopText,1,0,1300,false);check(h.inspections==0&&h.tasks.size()==1,"continued disabled state backs off to240ms");
 h=new ProcessingHarness();SystemClock.now=1540;h.awaitClaimProcessingOutcome(h.serialTopText,1,0,1300,false);check(h.inspections==1,"continued processing gets bounded quiet recheck");
 h=new ProcessingHarness();h.terminal="offer unavailable";h.awaitClaimProcessingOutcome(h.serialTopText,1,0,1300,true);check(h.losses==1&&h.inspections==0,"terminal result owns round before any fast retry recheck");
 h=new ProcessingHarness();h.claimEpoch.incrementAndGet();h.awaitClaimProcessingOutcome(h.serialTopText,1,0,1300,true);check(h.tasks.isEmpty()&&h.inspections==0,"old round cannot poll");
 h=new ProcessingHarness();h.awaitClaimProcessingOutcome(h.serialTopText.replace("175.53","176.53"),1,0,1300,true);check(h.tasks.isEmpty()&&h.inspections==0,"different card cannot inherit processing timer");
 System.out.println("7 production processing wait/ownership cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'ProcessingHarness.java';p.write_text(head+method+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d]+[str(src/f) for f in ['CardText.java','OfferEnrichmentPolicy.java','ActionDispatchPolicy.java']]+[str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.ProcessingHarness'],check=True)
