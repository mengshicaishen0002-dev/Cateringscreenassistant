from pathlib import Path
import tempfile,subprocess
r=Path(__file__).resolve().parents[1];s=(r/'app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java').read_text()
def block(sig):
 a=s.index(sig);b=s.index('{',a);i=b+1;d=1
 while d:
  d+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i].replace("OcrMonitorService service", "Recovery service")
head="""import java.util.concurrent.atomic.*;
public class Recovery {
 static class SystemClock {static long now=10000;static long elapsedRealtime(){return now;}}
 static class PageGuard {enum Page {OFFERS,UNKNOWN,JOBS,IGNORED}}
 enum SerialAction {NONE,ACCEPT}
 static class Prefs {boolean dry;boolean getBoolean(String k,boolean f){return dry;}}
 static class TapAccessibilityService {
 static boolean foreground=true;static int clicks;static PageGuard.Page hint=PageGuard.Page.UNKNOWN;
 static PageGuard.Page recentPageHint(){return hint;}
 static boolean isDeliverThatForeground(){return foreground;}
 static boolean clickOffersNavigationFromOtherTab(java.util.function.Consumer<String> done){clicks++;return true;}}
 static Recovery activeInstance;
 static AtomicBoolean MANUAL_INTERVENTION_PAUSED=new AtomicBoolean();
 AtomicBoolean acceptAdmissionBusy=new AtomicBoolean();
 AtomicLong scanGeneration=new AtomicLong();
 boolean monitorReady=true,postClaimIsolationActive;
 long unownedInteractionUntil,pageRecoveryRetryAt,lastActionDispatchAt,unavailableNavigationUntil;
 String postTerminalVerifyOfferText=""; SerialAction serialTopAction=SerialAction.NONE;
 Prefs prefs=new Prefs();
 boolean isPostTerminalSuccessCandidate(String s){return false;}void updateStatus(String s){}
 static void check(boolean b){if(!b)throw new AssertionError();}
"""
test="""public static void main(String[]a){Recovery x=activeInstance=new Recovery();
 check(!x.recoverOffersPage(SystemClock.now));
 TapAccessibilityService.hint=PageGuard.Page.OFFERS;
 check(!x.recoverOffersPage(SystemClock.now));
 TapAccessibilityService.hint=PageGuard.Page.JOBS;
 x.unavailableNavigationUntil=SystemClock.now+1;
 check(!x.recoverOffersPage(SystemClock.now));
 x.unavailableNavigationUntil=0;
 check(x.recoverOffersPage(SystemClock.now));
 check(!x.recoverOffersPage(SystemClock.now+12));
 noteManualTouch();
 check(isManualInterventionPaused()&&x.scanGeneration.get()==1);
 SystemClock.now+=2999;
 TapAccessibilityService.hint=PageGuard.Page.IGNORED;
 check(!x.recoverOffersPage(SystemClock.now));
 SystemClock.now++;
 check(!isManualInterventionPaused()&&x.recoverOffersPage(SystemClock.now));
 SystemClock.now+=300;
 x.serialTopAction=SerialAction.ACCEPT;
 check(!x.recoverOffersPage(SystemClock.now));
 x.serialTopAction=SerialAction.NONE;MANUAL_INTERVENTION_PAUSED.set(true);
 check(!x.recoverOffersPage(SystemClock.now));
 MANUAL_INTERVENTION_PAUSED.set(false);TapAccessibilityService.foreground=false;
 check(!x.recoverOffersPage(SystemClock.now));
 TapAccessibilityService.foreground=true;x.prefs.dry=true;
 check(!x.recoverOffersPage(SystemClock.now));
 check(TapAccessibilityService.clicks==2);
 System.out.println("Production page recovery and 3-second manual pause passed");}}
"""
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'Recovery.java'
 p.write_text(head+block('    public static boolean isManualInterventionPaused()').replace('OcrMonitorService current', 'Recovery current')+block('    public static void noteManualTouch()')+block('    private boolean recoverOffersPage(long now)')+block('    private boolean recoverOffersPage(PageGuard.Page page, long now)')+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(p)],check=True)
 subprocess.run(['java','-cp',d,'Recovery'],check=True)
