from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text()
a=s.index('    private boolean skipIdenticalOwnedRejectImage(');i=s.index('{',a)+1;end=i;d=1
while d:d+=(s[end]=='{')-(s[end]=='}');end+=1
method=s[a:end]
head='''package com.local.cateringscreenassistant;
import java.nio.*;import java.util.*;
public class PixelHarness {
 Object rejectedRoiLock=new Object();RejectConfirmState rejectedRoiOwner;int rejectedRoiWidth=83,rejectedRoiHeight=70;int[] rejectedRoiPixels;long rejectedRoiAt;
 Map<String,RejectConfirmState> rejectConfirmStates=new HashMap<>();
 static class Gate{boolean active=true;boolean isCurrent(String id,long token){return active;}}Gate rejectTerminalGate=new Gate();
 static class RejectConfirmState{String id="old";long token=1;}
 static class Bitmap{int getWidth(){return 83;}int getHeight(){return 70;}}
 static class Image{static class Plane{ByteBuffer b=ByteBuffer.allocate(90*400);int pixel=4;ByteBuffer getBuffer(){return b;}int getRowStride(){return 400;}int getPixelStride(){return pixel;}}Plane p=new Plane();int getWidth(){return 83;}int getHeight(){return 90;}Plane[] getPlanes(){return new Plane[]{p};}}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
'''
test='''public static void main(String[]args){PixelHarness h=new PixelHarness();Image im=new Image();h.rejectedRoiPixels=new int[83*70];h.rejectedRoiOwner=new RejectConfirmState();h.rejectConfirmStates.put("old",h.rejectedRoiOwner);h.rejectedRoiAt=1000;
 Random random=new Random(223);im.p.b.order(ByteOrder.LITTLE_ENDIAN);
 for(int y=0;y<70;y++)for(int x=0;x<83;x++){int rgba=random.nextInt();h.rejectedRoiPixels[y*83+x]=rgba;im.p.b.putInt((y+10)*400+x*4,rgba);}
 check(h.skipIdenticalOwnedRejectImage(im,10,80,1001),"unchanged exact RGBA with padded rows skips before bitmap/OCR");
 for(int channel=0;channel<4;channel++){int at=79*400+82*4+channel;byte old=im.p.b.get(at);im.p.b.put(at,(byte)(old^1));check(!h.skipIdenticalOwnedRejectImage(im,10,80,1002),"one changed channel/pixel always reopens OCR");im.p.b.put(at,old);}
 im.p.b.put(79*400+350,(byte)1);check(h.skipIdenticalOwnedRejectImage(im,10,80,1003),"row padding does not change visible frame");
 check(!h.skipIdenticalOwnedRejectImage(im,10,80,2200),"expired receipt reopens OCR");
 h.rejectTerminalGate.active=false;check(!h.skipIdenticalOwnedRejectImage(im,10,80,1004),"retired owner reopens OCR");h.rejectTerminalGate.active=true;
 im.p.pixel=3;check(!h.skipIdenticalOwnedRejectImage(im,10,80,1004),"unsupported format reopens OCR");
 System.out.println(checks+" exact pre-copy Reject pixel lifecycle cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'PixelHarness.java';p.write_text(head+method+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in ['RejectWorkPolicy.java','CardText.java','ClaimSuccessSignals.java','LargeOrderPopupGuard.java','OfferEnrichmentPolicy.java']],str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.PixelHarness'],check=True)
