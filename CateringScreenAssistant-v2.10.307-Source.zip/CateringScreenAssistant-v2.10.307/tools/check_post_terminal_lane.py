"""Execute late-success verification scheduling without occupying the first-shot queue."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
src = root / 'app/src/main/java/com/local/cateringscreenassistant'
source = (src / 'OcrMonitorService.java').read_text()
def block(signature):
    start = source.index(signature)
    end = source.index('{', start) + 1
    depth = 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end]

head = '''package com.local.cateringscreenassistant;
import java.util.*;
class PostTerminalLane {
 static class SystemClock {static long now=1000;static long elapsedRealtime(){return now;}}
 static class Handler {List<Runnable> queue=new ArrayList<>();void postDelayed(Runnable r,long ms){queue.add(r);}void once(){queue.remove(0).run();}}
 Handler fastWorker=new Handler(),acceptOutcomeWorker=new Handler();
 static final long POST_TERMINAL_JOB_VERIFY_MS=12000,POST_TERMINAL_JOB_VERIFY_POLL_MS=160;
 String postTerminalVerifyOfferText="";long postTerminalVerifyActionAt,postTerminalVerifyUntil;int postTerminalVerifyJobsBaseline=-1;
 boolean monitorReady=true,manualInterventionConfirmed,candidate;int confirmed;
 static class TapAccessibilityService {static boolean success;static int liveReads;
  static boolean recentAcceptedJobDetailMatches(String s,long at){return false;}
  static boolean liveBeginDeliveryMatches(String s){liveReads++;return success;}}
 void clearPostTerminalSuccessCandidate(){candidate=false;}
 boolean isPostTerminalSuccessCandidate(String s){return candidate;}
 void confirmPostTerminalClaimSuccess(String s,String e){confirmed++;candidate=true;}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static final String OFFER="$101.04 6.8 mi Tomorrow at 11:05 AM Red Robin • 3301 E Main St, Ventura, CA 93003";
 static PostTerminalLane fresh(){SystemClock.now=1000;TapAccessibilityService.success=false;TapAccessibilityService.liveReads=0;return new PostTerminalLane();}
'''
tests = '''public static void main(String[] args){
 PostTerminalLane h=fresh();h.armPostTerminalJobVerification(OFFER,900,0,1000);
 check(h.fastWorker.queue.isEmpty()&&h.acceptOutcomeWorker.queue.size()==1,"late Begin Delivery verification queues away from first-shot work");
 h.acceptOutcomeWorker.once();
 check(TapAccessibilityService.liveReads==1&&h.fastWorker.queue.isEmpty()&&h.acceptOutcomeWorker.queue.size()==1,"live read and its next poll stay on the result lane");
 h=fresh();h.armPostTerminalJobVerification(OFFER,900,0,1000);h.postTerminalVerifyActionAt=901;h.acceptOutcomeWorker.once();
 check(TapAccessibilityService.liveReads==0,"superseded verification performs no root reads");
 h=fresh();h.armPostTerminalJobVerification(OFFER,900,0,1000);h.manualInterventionConfirmed=true;h.acceptOutcomeWorker.once();
 check(TapAccessibilityService.liveReads==0,"manual intervention still stops background reads");
 h=fresh();h.armPostTerminalJobVerification(OFFER,900,0,1000);TapAccessibilityService.success=true;h.acceptOutcomeWorker.once();
 check(h.confirmed==1&&h.acceptOutcomeWorker.queue.isEmpty()&&h.fastWorker.queue.isEmpty(),"late positive result is preserved without blocking new-offer queue");
 h=fresh();h.armPostTerminalJobVerification(OFFER,900,0,1000);SystemClock.now=13001;h.acceptOutcomeWorker.once();
 check(TapAccessibilityService.liveReads==0&&h.postTerminalVerifyActionAt==0,"expired verifier clears state without a read");
 System.out.println(checks+" production post-terminal queue-isolation cases passed");}}
'''
with tempfile.TemporaryDirectory() as directory:
    file = Path(directory) / 'PostTerminalLane.java'
    file.write_text(head + block('    private void armPostTerminalJobVerification(')
                    + block('    private void pollPostTerminalJobVerification(') + tests)
    subprocess.run(['java', 'com.sun.tools.javac.Main', '-d', directory,
                    str(src / 'CardText.java'), str(src / 'OfferEnrichmentPolicy.java'), str(file)], check=True)
    subprocess.run(['java', '-cp', directory, 'com.local.cateringscreenassistant.PostTerminalLane'], check=True)
