"""Run actual queued OCR dispatcher with Android boundaries replaced by small fakes."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'TapAccessibilityService.java').read_text()
a=s.index('    private static void tapFreshOcrAction(');b=s.index('    /**',a);method=s[a:b]+s[s.index("    private static GestureDescription buildSingleTap("):s.index("    private static boolean dispatchVerifiedSnapshotGesture(TapAccessibilityService service, Rect bounds,\n            Rect rootBounds")]
head='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.function.*;import java.util.concurrent.atomic.*;
class SystemClock{static long now=5000;static long elapsedRealtime(){return now;}}
class Rect{int left=0,top=0,right=1080,bottom=2400;int width(){return right-left;}int height(){return bottom-top;}boolean isEmpty(){return width()<=0||height()<=0;}boolean contains(int x,int y){return x>=left&&x<right&&y>=top&&y<bottom;}}
class AccessibilityNodeInfo{CharSequence getPackageName(){return "com.deliverthat.driver";}void recycle(){}void getBoundsInScreen(Rect b){if(TapAccessibilityService.changeDuringRead)OcrMonitorService.guard="OCR_ACCEPT_UNAVAILABLE";}}
class Path{void moveTo(float x,float y){}}
class GestureDescription{int strokes;static class StrokeDescription{StrokeDescription(Path p,long s,long d){}}static class Builder{int strokes;Builder addStroke(StrokeDescription s){strokes++;return this;}GestureDescription build(){GestureDescription g=new GestureDescription();g.strokes=strokes;return g;}}}
class GestureResultCallback{public void onCompleted(GestureDescription g){}public void onCancelled(GestureDescription g){}}
class OcrMonitorService{static TapAccessibilityService.FastOfferSnapshot acceptPressureSnapshotForBinding(){return null;}static TapAccessibilityService.Handler clicks;static TapAccessibilityService.Handler acceptCallbackHandler(){return clicks;}static boolean monitor=true;static long at=1000;static String guard="";static int calls,started,sent;
 static boolean isMonitoring(){return monitor;}static long pendingClaimSince(){return at;}
 static String ocrAcceptDispatchGuard(long expected,float a,float m){calls++;return expected!=at?"OWNER_CHANGED":guard;}
 static void noteAcceptGestureDispatchStarted(){started++;}static void noteAcceptGestureDispatched(){sent++;}}
class TapAccessibilityService{static class FastOfferSnapshot{Rect acceptBounds=new Rect();}static void bindPressureGeometry(Rect b,Rect r){}
 static AtomicLong UI_GENERATION=new AtomicLong(1);
 static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>(new TapAccessibilityService());
 static boolean foreground=true,changeDuringRead;static int dispatches,lastStrokes;static PageGuard.Page page=PageGuard.Page.OFFERS;
 static class Handler{List<Runnable> tasks=new ArrayList<>();void post(Runnable r){tasks.add(r);}void postAtFrontOfQueue(Runnable r){tasks.add(0,r);}}
 Handler main=new Handler(),directWorker=new Handler();AccessibilityNodeInfo getRootInActiveWindow(){return new AccessibilityNodeInfo();}
 static boolean higherRow;static boolean noHigherIndexedOfferAction(AccessibilityNodeInfo r,Rect b,float y){return !higherRow;}
 static boolean isDeliverThatForeground(){return foreground;}static PageGuard.Page recentPageHint(){return page;}static PageGuard.Page quickPageOf(AccessibilityNodeInfo r,int n){return page;}
 boolean dispatchGesture(GestureDescription g,GestureResultCallback c,Handler h){dispatches++;lastStrokes=g.strokes;c.onCompleted(g);return true;}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static List<String> failures=new ArrayList<>();static int completed;
 static void reset(){higherRow=false;INSTANCE.set(new TapAccessibilityService());foreground=true;changeDuringRead=false;dispatches=completed=0;page=PageGuard.Page.OFFERS;SystemClock.now=5000;OcrMonitorService.monitor=true;OcrMonitorService.at=1000;OcrMonitorService.guard="";OcrMonitorService.calls=OcrMonitorService.started=OcrMonitorService.sent=0;failures.clear();}
 static void queue(boolean accept){tapFreshOcrAction(accept,accept?765:317,1191,28,4.7f,4900,()->completed++,failures::add);}
 static void run(){TapAccessibilityService s=INSTANCE.get();(s.directWorker.tasks.isEmpty()?s.main:s.directWorker).tasks.remove(0).run();}
'''
test='''public static void main(String[] args){
 reset();OcrMonitorService.clicks=new Handler();queue(true);check(OcrMonitorService.clicks.tasks.size()==1&&INSTANCE.get().directWorker.tasks.isEmpty(),"monitor OCR admission uses independent urgent click queue");OcrMonitorService.clicks.tasks.remove(0).run();check(dispatches==1,"urgent OCR queue dispatches actual gesture");OcrMonitorService.clicks=null;
 reset();queue(true);check(dispatches==0&&INSTANCE.get().main.tasks.isEmpty()&&INSTANCE.get().directWorker.tasks.size()==1,"OCR first tap is queued on idle direct lane without waiting for UI events");run();check(dispatches==1&&lastStrokes==1&&completed==1&&OcrMonitorService.calls==2&&OcrMonitorService.sent==1,"clean owner passes start and final guards then dispatches once");
 reset();queue(true);higherRow=true;run();check(dispatches==0,"queued OCR cannot jump over current upper offer");
 reset();queue(true);OcrMonitorService.guard="OCR_ACCEPT_UNAVAILABLE";run();check(dispatches==0&&OcrMonitorService.started==0&&failures.size()==1,"terminal loss before queued task starts cancels click");
 reset();queue(true);changeDuringRead=true;run();check(dispatches==0&&OcrMonitorService.calls==2&&OcrMonitorService.started==0,"loss during root preflight caught immediately before Android dispatch");
 reset();queue(true);OcrMonitorService.at=2000;run();check(dispatches==0&&failures.get(0).equals("OWNER_CHANGED"),"new owner invalidates old queued tap");
 reset();queue(false);OcrMonitorService.guard="OCR_ACCEPT_UNAVAILABLE";run();check(dispatches==1&&lastStrokes==1&&OcrMonitorService.calls==0,"Reject dispatch does not inherit Accept fence");
 reset();queue(true);OcrMonitorService.monitor=false;run();check(dispatches==0,"stopped monitoring cannot dispatch");
 reset();queue(true);SystemClock.now=8000;run();check(dispatches==0,"stale frame remains blocked");
 reset();queue(true);page=PageGuard.Page.JOBS;run();check(dispatches==0,"assigned-job page still blocks coordinates");
 reset();queue(true);page=PageGuard.Page.IGNORED;run();check(dispatches==0,"Ignored page still blocks coordinates");
 System.out.println(checks+" production queued OCR dispatch cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'TapAccessibilityService.java';f.write_text(head+method+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d]+[str(src/n) for n in ['ActionGeometry.java','ActionDispatchPolicy.java','ScanPolicy.java','PageGuard.java']]+[str(f)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.TapAccessibilityService'],check=True)
