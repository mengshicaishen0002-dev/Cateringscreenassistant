#!/usr/bin/env python3
"""Run production demand admission and rescue priority against a deterministic event stream."""
from pathlib import Path
import subprocess
import tempfile

root=Path(__file__).resolve().parents[1]
source=root/'app/src/main/java/com/local/cateringscreenassistant'
service=(source/'OcrMonitorService.java').read_text()
def method(start,end):
    a=service.index(start)
    return service[a:service.index(end,a)]
observe=method('    public static void noteForegroundOfferDemand(String text)', '    /**')
deadline=method('    private void armRejectResultDeadline(', '    /** A different top permits')
close=method('    private boolean closeRejectConfirmation(', '    private void expireRejectTail(')

priority=method('    private String rejectRescuePriority(', '    private void deferFinalRejectRescue(')
defer=method('    private void deferFinalRejectRescue(', '    private void waitForRejectForeground(')
foreground=method('    private void waitForRejectForeground(', '    private void runFinalRejectRescue(')
wake=method('    private static final class NumericWake {', '    private final ThreadLocal<PipelineTiming>')
empty=method('    private void releaseExpiredReject(', '    private void scheduleRejectFinalTail(')
recent=method('    private static boolean foregroundOfferDemandRecent(', '    /** Cheap cache/event-only screen presence gate.')
header='''package com.local.cateringscreenassistant;
import java.util.concurrent.*;import java.util.concurrent.atomic.*;
class SystemClock { static long now=1000L;static long elapsedRealtime(){return now;} }
class TapAccessibilityService {static boolean foreground;static long seen;static long recentFirstSeenAt(String s,long age){return seen;}static boolean hasDeliverThatReplayForegroundHint(){return foreground;}}
public class OcrMonitorService {
 static boolean paused;static boolean isManualInterventionPaused(){return paused;}
 static OcrMonitorService activeInstance;
 static AtomicLong foregroundOfferDemandAt=new AtomicLong();
 boolean monitorReady=true;
 static final long REJECT_RESULT_DEADLINE_MS=5000;
 final AtomicReference<RejectConfirmState> expiredReject=new AtomicReference<>();
 RejectSequence rejectSequence=new RejectSequence();
 enum SerialAction {NONE,ACCEPT,REJECT} SerialAction serialTopAction=SerialAction.NONE;
 AtomicBoolean fastCheckDirty=new AtomicBoolean(),fastCheckQueued=new AtomicBoolean();
 long lastStructuralWakeAt;
 static class RejectConfirmState {int probeCount,priorityDeferrals,budgetDeferrals,evidenceDeferrals,processingDeferrals,changedDeferrals,foregroundUnavailable;AtomicBoolean awaitingForeground=new AtomicBoolean();Runnable foregroundExpiry;long actionAt=1000,foregroundEmptyAt,foregroundEmptyGeneration;String lastDeferReason;String id,text;long token=1;RejectConfirmState(String t){text=t;id=CardText.identity(t);}}
 static class Gate {
  boolean closed;int terminalCount;
  boolean isCurrent(String id,long token){return token==1&&!closed;}
  boolean tryTerminal(String id,long token,String outcome){if(!isCurrent(id,token))return false;terminalCount++;return true;}
  void invalidate(String id,long token){closed=true;}
 }
 Gate rejectTerminalGate=new Gate();
 ConcurrentHashMap<String,RejectConfirmState> rejectConfirmStates=new ConcurrentHashMap<>();
 static class Handler {int queued;long delay;Runnable pending;boolean postDelayed(Runnable r,long d){queued++;delay=d;pending=r;return true;}boolean post(Runnable r){return postDelayed(r,0);}void removeCallbacks(Runnable r){if(pending==r)pending=null;}}
 Handler fastWorker=new Handler(),rejectConfirmWorker=new Handler();boolean expired;int finished;
 void finishAsyncRejectConfirmation(RejectConfirmState s,String evidence,boolean changedTop){finished++;rejectConfirmStates.remove(s.id,s);}
 void runFinalRejectRescue(RejectConfirmState s){}void expireRejectTail(RejectConfirmState s,String r){expired=true;if(hardDeadline)closeRejectConfirmation(s,"TIMEOUT",true);}
 boolean hardDeadline;
 static int checks;static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
'''
tests='''public static void main(String[] args){
 OcrMonitorService s=activeInstance=new OcrMonitorService();
 String old="$29.00 2.6 mi Tomorrow at 10:15 AM Mendocino Farms • 631 Wilshire Blvd, Santa Monica, CA 90401";
 RejectConfirmState state=new RejectConfirmState(old);s.rejectConfirmStates.put(state.id,state);
 for(int i=0;i<300;i++){SystemClock.now+=20;noteForegroundOfferDemand("Accept");noteForegroundOfferDemand(old);noteForegroundOfferDemand("$29.00 2.6 mi");}
 check(foregroundOfferDemandAt.get()==0L,"six seconds of old-card redraws cannot renew new-card priority");
 s.fastCheckDirty.set(true);
 check(s.rejectRescueMayRun(state),"dirty old-card queue cannot starve rescue");
 s.fastCheckQueued.set(true);s.lastStructuralWakeAt=SystemClock.now;
 check(!s.rejectRescueMayRun(state),"new structural wake protects the scan before numeric parsing");
 SystemClock.now+=121;
 check(s.rejectRescueMayRun(state),"older structural wake does not starve rescue");
 s.fastCheckQueued.set(false);
 noteForegroundOfferDemand(old.replace("29.00","125.23"));
 check(!s.rejectRescueMayRun(state),"real new numeric pair gives foreground priority");
 check("NEW_OFFER_PRIORITY".equals(s.rejectRescuePriority(state)),"new-card reason is explicit");
 SystemClock.now+=241;
 check(s.rejectRescueMayRun(state),"new-card lease expires without renewed proof");
 s.serialTopAction=SerialAction.ACCEPT;
 check(!s.rejectRescueMayRun(state),"Accept transaction always keeps priority");
 check("ACCEPT_PRIORITY".equals(s.rejectRescuePriority(state)),"Accept reason is separate");
 s.serialTopAction=SerialAction.NONE;
 noteForegroundOfferDemand(old.replace("10:15","11:15"));
 check(!s.rejectRescueMayRun(state),"same numeric pair with genuinely different pickup is new demand");
 SystemClock.now=1200;state.probeCount=1;s.expired=false;s.deferFinalRejectRescue(state,"SCAN_BUDGET");
 check(!s.expired&&s.rejectConfirmWorker.queued==1&&s.rejectConfirmWorker.delay==80,"first inconclusive read gets bounded backoff");
 state.probeCount=5;s.deferFinalRejectRescue(state,"SCAN_BUDGET");
 check(s.rejectConfirmWorker.queued==2&&s.rejectConfirmWorker.delay==240,"later read backs off rather than looping every80ms");
 state.probeCount=10;s.deferFinalRejectRescue(state,"SCAN_BUDGET");
 check(s.expired&&s.rejectConfirmWorker.queued==2,"ten unresolved reads stop tree work before twenty-five repeats");
 state.probeCount=0;
 for(int i=0;i<5;i++)s.deferFinalRejectRescue(state,"EVIDENCE_INCOMPLETE");
 check(s.rejectConfirmWorker.delay==240&&state.evidenceDeferrals==5,"incomplete reads back off even when completed probes stay at zero");
 s.deferFinalRejectRescue(state,"CONTROL_DISABLED");s.deferFinalRejectRescue(state,"UI_CHANGED");
 check(state.processingDeferrals==1&&state.changedDeferrals==1&&state.evidenceDeferrals==5,
       "disabled controls and UI churn are distinct from missing card evidence");
 TapAccessibilityService.seen=SystemClock.now-20;
 String next=old.replace("29.00","128.23");
 noteForegroundOfferDemand(next);
 long firstWake=s.lastNumericWake.get().wakeAt;
 SystemClock.now+=10;noteForegroundOfferDemand(next);
 check(s.lastNumericWake.get().wakeAt==firstWake,"same numeric burst keeps its first wake");
 int confirm=s.rejectConfirmWorker.queued;
 s.waitForRejectForeground(state);s.waitForRejectForeground(state);
 check(state.awaitingForeground.get()&&s.rejectConfirmWorker.queued==confirm+1&&s.fastWorker.queued==0,
       "outside window parks one old-card timer without queuing scans");
 onDeliverThatForeground();
 check(!state.awaitingForeground.get()&&s.rejectConfirmWorker.queued==confirm+2&&s.rejectConfirmWorker.delay==0&&s.fastWorker.queued==0,
       "foreground return resumes one bounded old-card read");
 paused=true;
 check(!s.rejectRescueMayRun(state)&&"MANUAL_PAUSE".equals(s.rejectRescuePriority(state)),
       "manual interaction blocks old-card action");
 paused=false;
 s.observeRejectEmptyOffers(true,1,1219,1220);
 check(state.foregroundEmptyAt==0,"transition floor rejects immediate empty");
 s.observeRejectEmptyOffers(true,1,1220,1221);
 s.observeRejectEmptyOffers(true,1,1340,1340);
 check(s.finished==0,"two frames must be separated by the full quiet gap");
 s.observeRejectEmptyOffers(false,1,1341,1341);
 s.observeRejectEmptyOffers(true,1,1462,1463);
 s.observeRejectEmptyOffers(true,2,1583,1584);
 check(s.finished==0,"nonempty and generation changes reset proof");
 s.observeRejectEmptyOffers(true,2,1704,1705);
 check(s.finished==1&&s.rejectConfirmStates.isEmpty(),"two stable explicit empty reads close the old Reject");

 s=activeInstance=new OcrMonitorService();s.hardDeadline=true;SystemClock.now=1300;
 state=new RejectConfirmState(old);s.rejectConfirmStates.put(state.id,state);
 s.rejectSequence.reserveFirstIfReady(state.id,1000);
 s.armRejectResultDeadline(state);
 check(s.rejectConfirmWorker.pending!=null&&s.rejectConfirmWorker.delay==4700&&s.fastWorker.queued==0,
       "terminal deadline does not depend on the live-read queue");
 SystemClock.now=6000;s.rejectConfirmWorker.pending.run();
 check(s.expiredReject.get()==state&&s.rejectConfirmStates.isEmpty()&&s.rejectTerminalGate.terminalCount==1,
       "stalled read expires once while retaining top-card ownership");
 s.rejectConfirmWorker.pending.run();
 check(s.rejectTerminalGate.terminalCount==1,"late watchdog cannot duplicate a completed outcome");
 s.observeRejectEmptyOffers(true,5,6100,6100);
 check(s.expiredReject.get()==state,"one empty read never releases an expired old card");
 s.observeRejectEmptyOffers(true,5,6220,6220);
 check(s.expiredReject.get()==null&&s.rejectSequence.reserveFirstIfReady(state.id,6221)==1,
       "proven departure clears old ownership and identical later card starts at attempt one");
 s=activeInstance=new OcrMonitorService();
 String id=s.rejectSequence.bindObservation(old,1000);
 s.rejectSequence.reserveFirstIfReady(id,1000);
 SystemClock.now=1150;
 s.recordRejectDeparture(id,true);
 check(s.rejectConfirmStates.isEmpty()&&s.expiredReject.get()==null,
       "confirmed top replacement retires the old Reject transaction");
 check(s.rejectSequence.reserveFirstIfReady(s.rejectSequence.bindObservation(old,1325),1325)==0,
       "brief same-card reorder keeps its physical dispatch lease");
 check(s.rejectSequence.reserveFirstIfReady(s.rejectSequence.bindObservation(old,7011),7011)==1,
       "same order after the bounded physical lease can be a fresh publication");
 s.observeRejectEmptyOffers(true,6,7130,7135);
 check(s.rejectSequence.reserveFirstIfReady(id,7136)==0,
       "a single unconfirmed empty read cannot restart a still-owned Reject transaction");
 System.out.println(checks+" actual Reject demand/queue lifecycle cases passed");
 }}'''
with tempfile.TemporaryDirectory(prefix='csa-demand-') as directory:
    temp=Path(directory); harness=temp/'OcrMonitorService.java'
    harness.write_text(header+wake+observe+deadline+close+recent+priority+defer+foreground+empty+tests)
    files=['CardText.java','ClaimSuccessSignals.java','OfferEnrichmentPolicy.java','RejectDemandPolicy.java','RejectSequence.java','RejectProbePolicy.java','RejectConfirmPriorityPolicy.java']
    subprocess.run(['java','com.sun.tools.javac.Main','-d',str(temp),*[str(source/name) for name in files],str(harness)],check=True)
    subprocess.run(['java','-cp',str(temp),'com.local.cateringscreenassistant.OcrMonitorService'],check=True)
