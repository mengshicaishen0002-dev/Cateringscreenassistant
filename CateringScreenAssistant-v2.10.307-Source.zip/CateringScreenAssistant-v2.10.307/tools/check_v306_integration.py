from pathlib import Path
b=Path(__file__).resolve().parents[1]/'app/src/main/java/com/local/cateringscreenassistant'
o=(b/'OcrMonitorService.java').read_text(); r=(b/'RejectSequence.java').read_text(); e=(b/'OfferEnrichmentPolicy.java').read_text()
assert 'rejectSequence.markSpinnerAcknowledged(state.id,SystemClock.elapsedRealtime())' in o
assert 'SPINNER_REDRAW_MS = 2500L' in r and 'value.lastDispatchAt+SPINNER_REDRAW_MS' in r
assert 'if (!hasReorderedDepartures) return false;' in r
assert 'REJECT_OCR_EL_SEGUNDO' in e and 'blvd hawthorne ca 90250' in e
coalesce=o[o.index('// Fresh same-generation evidence for a Spinner-acknowledged'):o.index('StringBuilder rejectRoute',o.index('// Fresh same-generation evidence for a Spinner-acknowledged'))]
for x in ['!structural','!priorityOffer','!service.fastCheckDirty.get()','!service.fastStructuralWake.get()','!foregroundOfferDemandRecent(240L)','ownedFrame.uiGeneration==scanUiGeneration','now-ownedFrame.capturedAt<=48L','acknowledgedRedraw','scheduleIdlePresenceProbe()','universallyRejectedByNumbers','quickDecisionTextComplete','fastRuleFailure']:
    assert x in coalesce,x
assert 'service.decisionWakeAt.set(structural ? service.lastStructuralWakeAt : 0L)' in o
assert '本轮结构唤醒→扫描=UNOBSERVED' in o
assert 'pipelineTiming.mark("rejectAdmit",submitAt)' in o and 'pipelineTiming.mark("rejectDispatchReturn",SystemClock.elapsedRealtime())' in o
assert 'OCR_ENHANCED_SUBMIT_FAILED' in o
for stage in ['rejectDispatchCallback','rejectCallbackHandoff','rejectCallbackLog']:
    assert 'noteDecisionStage("'+stage+'")' in o
print('v306 source integration checks passed')
