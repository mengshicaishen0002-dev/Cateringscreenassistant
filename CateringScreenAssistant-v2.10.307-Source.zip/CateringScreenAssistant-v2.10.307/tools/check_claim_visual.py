#!/usr/bin/env python3
"""Run actual OCR-proof/navigation methods against unreadable Android nodes."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'TapAccessibilityService.java').read_text()
a=s.index('    private static volatile BeginDeliveryOcrProof');b=s.index('    public static boolean clickOffersNavigation',a)
methods=s[a:b]
header='''package com.local.cateringscreenassistant;
import java.util.function.*;import java.util.concurrent.atomic.*;
class VisualHarness {
 static class OcrMonitorService {static boolean isManualInterventionPaused(){return false;}}
 static volatile long automaticNavigationUntil;
 static class SystemClock {static long now=1000;static long elapsedRealtime(){return now;}}
 static class Rect {int left,top;int width(){return 709;}int height(){return 1536;}boolean isEmpty(){return false;}}
 static class AccessibilityNodeInfo {void getBoundsInScreen(Rect r){}void recycle(){}}
 static class TapAccessibilityService {AccessibilityNodeInfo getRootInActiveWindow(){return new AccessibilityNodeInfo();}boolean performGlobalAction(int a){global++;return true;}}
 static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>(new TapAccessibilityService());
 static AtomicLong UI_GENERATION=new AtomicLong(1);static boolean foreground=true;static int global,taps,checks;static float x,y;static final int GLOBAL_ACTION_BACK=1;
 static boolean isDeliverThatForeground(){return foreground;}
 static void collectLimitedText(AccessibilityNodeInfo r,StringBuilder s,int[] n){}
 static AccessibilityNodeInfo findBackNavigationNode(AccessibilityNodeInfo r){return null;}
 static boolean clickNavigationNode(AccessibilityNodeInfo n){return false;}
 static void invalidateDecisionEvidence(){UI_GENERATION.incrementAndGet();}
 static void invalidateNavigationPageHint(){beginDeliveryOcrProof=null;UI_GENERATION.incrementAndGet();}
 static boolean dispatchNavigationGesture(TapAccessibilityService s,Rect r,float a,float b,String d,Consumer<String> ok,Consumer<String> fail){taps++;x=a;y=b;invalidateNavigationPageHint();return true;}
 static void check(boolean b){checks++;if(!b)throw new AssertionError("visual case "+checks);}
'''
tests=''' public static void main(String[] args){
 String owner="$30–40 0.8 mi (~6 mins) Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101";
 check(ClaimVisualProbePolicy.bottom(1536)>1313); // Timeline and CTA in supplied layout
 check(ClaimVisualProbePolicy.due(true,false,1000,0));
 check(!ClaimVisualProbePolicy.due(false,false,1000,0));
 check(!ClaimVisualProbePolicy.due(true,true,1000,0));
 check(!ClaimVisualProbePolicy.due(true,false,1200,1000));
 noteBeginDeliveryOcr(true,owner,1000,1);check(hasFreshBeginDeliveryOcr(owner));
 check(!hasFreshBeginDeliveryOcr(owner.replace("238", "239")));
 SystemClock.now=1751;check(!hasFreshBeginDeliveryOcr(owner));
 SystemClock.now=999;check(!hasFreshBeginDeliveryOcr(owner));
 SystemClock.now=1000;UI_GENERATION.set(2);check(!hasFreshBeginDeliveryOcr(owner));
 UI_GENERATION.set(1);foreground=false;check(!hasFreshBeginDeliveryOcr(owner));
 clickPostClaimBack(d->{},d->{});check(taps==0&&global==0);
 foreground=true;noteBeginDeliveryOcr(false,owner,1000,1);check(!hasFreshBeginDeliveryOcr(owner));
 noteBeginDeliveryOcr(true,owner,1000,1);invalidateDecisionEvidenceAfterClaim();check(hasFreshBeginDeliveryOcr(owner));clickPostClaimBack(d->{},d->{});
 check(taps==1&&global==0&&Math.abs(x-88.625f)<0.01f&&Math.abs(y-115.2f)<0.01f);
 check(!hasFreshBeginDeliveryOcr(owner)); // navigation consumes old screenshot proof
 System.out.println(checks+" production visual proof/navigation cases passed");
 }
}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'VisualHarness.java';p.write_text(header+methods+tests)
 names=['ClaimVisualProbePolicy.java','ClaimSuccessSignals.java','OfferEnrichmentPolicy.java','CardText.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d]+[str(src/f) for f in names]+[str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.VisualHarness'],check=True)

# Returning from an unavailable page must use current Offers evidence, not a cached page label.
ocr=(src/'OcrMonitorService.java').read_text()
a=ocr.index('// Success can be published during the short Jobs transition.')
b=ocr.index('long age =',a)
assert 'hasFreshBeginDeliveryOcr(originalText)' in ocr[a:b]
assert 'readOffersNavigationSurface(true)' in ocr[a:b]
assert 'page == PageGuard.Page.OFFERS' not in ocr[a:b]
