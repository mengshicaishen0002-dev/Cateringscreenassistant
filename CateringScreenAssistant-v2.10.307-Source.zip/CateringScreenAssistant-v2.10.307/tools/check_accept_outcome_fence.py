#!/usr/bin/env python3
"""Exercise production Accept dispatch fencing and outcome cache readers without Android."""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
ocr=(src/'OcrMonitorService.java').read_text();tap=(src/'TapAccessibilityService.java').read_text()
def block(text,signature):
 a=text.index(signature);b=text.index('{',a);depth=1;i=b+1
 while depth:
  depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[a:i]
tap_methods=['    public static long claimOutcomeEventEpoch()',
'    public static String recentAcceptTerminalOutcomeAfter(', '    public static String recentAcceptOutcomeAfter(',
'    public static String acceptOutcomeEventDiagnostic(', '    private static void updateClaimUiCaches(',
'    public static String recentCachedClaimOutcomeSince(', '    public static String recentTerminalNegativeClaimOutcomeSince(']
ocr_methods=['    public static boolean hasBoundAcceptSuccess()', '    public static String acceptRetryGuard(', '    public static void noteAcceptGestureDispatchStarted()', '    private AcceptOutcomeFence acceptFenceFor(',
'    private synchronized PageOutcomePolicy.Tracker pageTracker(', '    private String pageBoundOutcome(', '    private void scheduleAcceptPageProbe(long actionAt)', '    private void scheduleAcceptPageProbe(long actionAt, boolean offerWake)', '    private void noteUnboundAcceptOutcome(', '    private void expireUnboundAcceptOutcome(', '    private String acceptScopedTerminalOutcomeSince(',
'    private String acceptScopedOutcomeSince(', '    private boolean canCommitAcceptTerminalLoss(',
'    private boolean isBoundPositiveClaimOutcome(', '    private void loadUnavailableTombstones()']
header='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;import java.util.function.*;
class SystemClock {static long elapsed=10000,up=1000;static long elapsedRealtime(){return elapsed;}static long uptimeMillis(){return up;}static void advance(long ms){elapsed+=ms;up+=ms;}}
class TapAccessibilityService {static boolean currentNegativeSurfaceBlocksAccept(){return false;}
 static String uiMutationDiagnostic(){return "type=2048,changes=1,window=7,benign=3";}
 static AtomicLong CLAIM_OUTCOME_EVENT_EPOCH=new AtomicLong(4);
 static AcceptOutcomeFence.Observation lastScopedClaimEvent,lastScopedTerminalEvent,lastScopedPositiveEvent;
 static String lastClaimOutcomeHint="",lastTerminalClaimOutcomeHint="",lastAcceptedJobDetailRaw="";
 static long lastClaimOutcomeHintAt,lastTerminalClaimOutcomeHintAt,lastAcceptedJobDetailAt,lastJobsBadgeAt;static int lastJobsBadgeCount;
 static boolean isTerminalNegativeClaimOutcome(String s){return ClaimSuccessSignals.isTerminalNegative(s);}
 static boolean isPositiveClaimOutcome(String s){return ClaimSuccessSignals.isPositive(s);}
 static void repaint(String raw){updateClaimUiCaches(raw);}
 static long outcomeUiGeneration(){return 1;}static long outcomeWindowEpoch(){return 1;}
 static boolean retryPage;static boolean freshPage,releaseDuringRead;static PageOutcomePolicy.Reading sampleAcceptPageOutcome(BooleanSupplier p){if(releaseDuringRead)OcrMonitorService.activeInstance.serialTopAction=OcrMonitorService.SerialAction.NONE;return retryPage?new PageOutcomePolicy.Reading(1,1,SystemClock.elapsed,SystemClock.elapsed,true,false,"","$195.36 0.3 mi Tomorrow at 11:35 AM Mendocino Farms • 631 Wilshire Blvd, Santa Monica, CA 90401","OK",7,26,"","ENABLED"):freshPage?new PageOutcomePolicy.Reading(1,1,SystemClock.elapsed,SystemClock.elapsed,true,false,"offer unavailable",""):null;}
 static boolean jobsBadgeIncreasedSince(int n){return false;}
'''
middle='''}
public class OcrMonitorService {static boolean acceptPressureActive(long at){return false;}
 boolean preserveVisibleAcceptLoading(long at,PageOutcomePolicy.Tracker t,long now){return false;}
 static boolean isMonitoring(){return activeInstance!=null&&activeInstance.monitorReady;}
 String visualBoundOutcome(long at){return "";}
 static OcrMonitorService activeInstance;long acceptPageReadActiveAt,acceptPageReadOwner;boolean monitorReady=true;enum SerialAction{NONE,ACCEPT}SerialAction serialTopAction=SerialAction.ACCEPT;
 long serialTopActionAt=9900,ignoredAcceptOutcomeActionAt,acceptRetryDispatchPendingAt;String serialTopText="$235.60 3.3 mi Erewhon Market • 8550 Santa Monica Blvd, West Hollywood, CA 90069";
 PageOutcomePolicy.Baseline preparedPageBaseline,dispatchedPageBaseline;boolean dispatchedPageBaselineClean;
 PageOutcomePolicy.Tracker acceptPageTracker;AtomicBoolean acceptPageProbeQueued=new AtomicBoolean();int acceptPageProbeCount,acceptPageValidProbeCount;long acceptPageProbeStartedAt;final Object acceptPageProbeScheduleLock=new Object();Runnable pendingAcceptPageProbe;long pendingAcceptPageProbeOwner;
 void pauseAcceptPressureForContext(long at,String reason,long time){}
 void requestImmediateFastCheck(long n){}
 AtomicLong claimEpoch=new AtomicLong(7);AcceptOutcomeFence acceptOutcomeFence,acceptAdmissionGuardFence;
 static final String UNAVAILABLE_TOMBSTONES_PREF="unavailable";static final long ORDER_ID_TOMBSTONE_TTL_MS=21600000L;
 class Prefs {boolean contains(String key){return m.containsKey(key);}Map<String,Object> m=new HashMap<>();boolean getBoolean(String k,boolean d){return (Boolean)m.getOrDefault(k,d);}
 @SuppressWarnings("unchecked") Set<String> getStringSet(String k,Set<String> d){return (Set<String>)m.getOrDefault(k,d);}Prefs edit(){return this;}Prefs remove(String k){m.remove(k);return this;}Prefs putBoolean(String k,boolean v){m.put(k,v);return this;}void apply(){}}
 Prefs prefs=new Prefs();Map<String,Long> unavailableTombstones=new HashMap<>();
 List<String> reports=new ArrayList<>();List<Runnable> pending=new ArrayList<>();long lastDelay;int polls,tombstones,navigations,unknowns;int pendingAcceptJobsBaseline;String pendingJobDetailCandidateIdentity="";
 class Handler {List<Runnable> queue;Handler(){queue=pending;}Handler(List<Runnable> q){queue=q;}void post(Runnable r){queue.add(r);}boolean postAtFrontOfQueue(Runnable r){queue.add(0,r);return true;}boolean postDelayed(Runnable r,long ms){lastDelay=ms;queue.add(r);return true;}void removeCallbacks(Runnable r){queue.remove(r);}}Handler fastWorker=new Handler(),acceptOutcomeWorker;
 void confirmPendingClaimSuccess(String t,String e){} void scheduleEnabledClaimInspection(String t,long e,long at){long owner=serialTopActionAt;fastWorker.postAtFrontOfQueue(()->{if(monitorReady&&serialTopAction==SerialAction.ACCEPT&&serialTopActionAt==owner&&claimEpoch.get()==e)inspectClaim(t,e);});}
 void scheduleClaimInspection(String t,long e,int d,int m,long delay){fastWorker.postDelayed(()->inspectClaim(t,e),delay);}void inspectClaim(String text,long epoch){polls++;}Consumer<String> acceptReporter(String t){return offerReporter(t);}Consumer<String> offerReporter(String t){return reports::add;}
 static void onJobsBadgeObserved(int n){}
 void finishPendingClaimLoss(String t,String e,boolean terminal){if(terminal){if(canCommitAcceptTerminalLoss(t,e)){tombstones++;navigations++;}}else{unknowns++;serialTopAction=SerialAction.NONE;}}

 void commit(){if(canCommitAcceptTerminalLoss(serialTopText,"unavailable")){tombstones++;navigations++;}}
 static int checks;static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 static OcrMonitorService setup(){TapAccessibilityService.retryPage=false;TapAccessibilityService.releaseDuringRead=false;SystemClock.elapsed=10000;SystemClock.up=1000;TapAccessibilityService.CLAIM_OUTCOME_EVENT_EPOCH.set(4);
 TapAccessibilityService.lastScopedClaimEvent=TapAccessibilityService.lastScopedTerminalEvent=new AcceptOutcomeFence.Observation("offer unavailable",4,990,9990);
 TapAccessibilityService.lastScopedPositiveEvent=null;TapAccessibilityService.lastClaimOutcomeHint=TapAccessibilityService.lastTerminalClaimOutcomeHint="";
 TapAccessibilityService.freshPage=false;return activeInstance=new OcrMonitorService();}
 static void event(String hint,long epoch,long origin,long receipt){AcceptOutcomeFence.Observation o=new AcceptOutcomeFence.Observation(hint,epoch,origin,receipt);
 TapAccessibilityService.CLAIM_OUTCOME_EVENT_EPOCH.set(epoch);TapAccessibilityService.lastScopedClaimEvent=o;
 if(ClaimSuccessSignals.isTerminalNegative(hint))TapAccessibilityService.lastScopedTerminalEvent=o;
 if(ClaimSuccessSignals.isPositive(hint)&&!ClaimSuccessSignals.isJobDetailHint(hint))TapAccessibilityService.lastScopedPositiveEvent=o;}
'''
tests='''public static void main(String[] args){
 OcrMonitorService s=setup();noteAcceptGestureDispatchStarted();AcceptOutcomeFence first=s.acceptOutcomeFence;
 check(first!=null&&first.baselineEventEpoch==4&&first.dispatchElapsed==10000,"fence starts at actual dispatch call, not admission9900");
 SystemClock.advance(7);TapAccessibilityService.repaint("offer unavailable");
 check(!TapAccessibilityService.recentTerminalNegativeClaimOutcomeSince(9900).isEmpty(),"reproduce legacy: reread old hint gets a fresh timestamp7ms after dispatch");
 check(s.acceptScopedTerminalOutcomeSince(9900).isEmpty(),"repainted tree cache is not a new post-dispatch event");
 s.commit();check(s.tombstones==0&&s.navigations==0&&s.pending.size()==3,"unbound old hint cannot tombstone or navigate away");
 check(s.reports.size()==1&&s.reports.get(0).contains("OUTCOME_UNBOUND_PENDING"),"unbound evidence is reported once per transaction");
 s.pending.remove(2).run();check(s.polls==1,"unbound terminal evidence retains observation rather than stranding transaction");
 event("offer unavailable",5,995,10007);check(s.acceptScopedTerminalOutcomeSince(9900).isEmpty(),"queued pre-dispatch event is rejected even when received after dispatch");
 event("offer unavailable",6,1006,10007);check(!s.acceptScopedTerminalOutcomeSince(9900).isEmpty(),"genuine new7ms event is allowed: no arbitrary minimum response delay");
 s.commit();check(s.tombstones==1&&s.navigations==1,"only bound current failure can reach terminal side effects");
 SystemClock.advance(100);noteAcceptGestureDispatchStarted();check(s.acceptOutcomeFence==first,"same transaction retry preserves first actual-dispatch fence");
 s.serialTopActionAt=10107;s.claimEpoch.incrementAndGet();noteAcceptGestureDispatchStarted();check(s.acceptOutcomeFence!=first&&s.acceptOutcomeFence.baselineEventEpoch==6,"new transaction owns new baseline");
 check(s.acceptScopedOutcomeSince(9900).isEmpty(),"old tail cannot read the new transaction outcome");
 s=setup();noteAcceptGestureDispatchStarted();event("offer unavailable",5,1001,10002);SystemClock.advance(3);
 check(!s.acceptScopedTerminalOutcomeSince(9900).isEmpty(),"event during Android dispatch call survives receipt before call-return acknowledgement");
 s=setup();noteAcceptGestureDispatchStarted();SystemClock.advance(7);TapAccessibilityService.repaint("offer accepted");
 check(!hasBoundAcceptSuccess()&&!s.isBoundPositiveClaimOutcome(s.serialTopText,"offer accepted",9900),"cached positive sentence cannot falsely confirm a new transaction");
 event("offer accepted",5,1006,10007);check(hasBoundAcceptSuccess()&&s.isBoundPositiveClaimOutcome(s.serialTopText,"offer accepted",9900),"fresh explicit positive event remains valid");
 event("Delivery Timeline/Dropoff Instructions",6,1007,10007);check(s.isBoundPositiveClaimOutcome(s.serialTopText,"offer accepted",9900),"generic job-detail event does not erase a fresh explicit success");
 AcceptOutcomeFence f=s.acceptOutcomeFence;
 check(!f.accepts(new AcceptOutcomeFence.Observation("x",6,0,10007),10007,1007),"missing event origin remains unbound");
 check(!f.accepts(new AcceptOutcomeFence.Observation("x",6,1008,10007),10007,1007),"future event origin rejected");
 check(!f.accepts(new AcceptOutcomeFence.Observation("x",6,1006,9999),10007,1007),"receipt predating dispatch rejected");
 check(!f.accepts(new AcceptOutcomeFence.Observation("x",6,1006,10007),15008,6008),"expired event rejected");
 s=setup();noteAcceptGestureDispatchStarted();SystemClock.advance(7);TapAccessibilityService.repaint("offer unavailable");s.acceptScopedTerminalOutcomeSince(9900);s.pending.remove(1).run();
 check(s.unknowns==1&&s.tombstones==0&&s.navigations==0,"unbound persistent UI cannot freeze the lane or force retirement; bounded UNKNOWN only");
 s=setup();s.prefs.m.put(UNAVAILABLE_TOMBSTONES_PREF,Set.of("order:legacy\t"+(System.currentTimeMillis()+3600000)));s.prefs.m.put("minPay",80f);s.loadUnavailableTombstones();
 check(s.unavailableTombstones.isEmpty()&&!s.prefs.m.containsKey(UNAVAILABLE_TOMBSTONES_PREF),"one-time upgrade clears legacy unscoped loss cache");
 check(s.prefs.m.get("minPay").equals(80f),"cache migration preserves configured rules");
 s.prefs.m.put(UNAVAILABLE_TOMBSTONES_PREF,Set.of("order:new\t"+(System.currentTimeMillis()+3600000)));s.loadUnavailableTombstones();
 check(s.unavailableTombstones.isEmpty()&&!s.prefs.m.containsKey(UNAVAILABLE_TOMBSTONES_PREF),"all saved losses are discarded");
 s=setup();s.acceptAdmissionGuardFence=new AcceptOutcomeFence(7,9900,4,10000,1000);SystemClock.advance(7);event("offer accepted",5,1006,10007);
 check(hasBoundAcceptSuccess()&&s.acceptOutcomeFence==null,"manual success during admission cancels a not-yet-dispatched tap without claiming automatic success");
 s=setup();s.preparedPageBaseline=new PageOutcomePolicy.Baseline(1,1,1,9950,9990,true,false);noteAcceptGestureDispatchStarted();
 SystemClock.advance(120);TapAccessibilityService.freshPage=true;TapAccessibilityService.repaint("offer unavailable");
 check(s.acceptScopedTerminalOutcomeSince(9900).isEmpty(),"eventless prompt waits for fresh page proof");
 s.pending.remove(0).run();check(s.pageBoundOutcome(9900).isEmpty(),"first real scheduled sample cannot commit");
 SystemClock.advance(120);s.pending.remove(1).run();
 check(s.acceptScopedTerminalOutcomeSince(9900).equals("offer unavailable"),"two scheduled fresh page samples bind a genuine new failure without an event");
 s.commit();check(s.tombstones==1&&s.navigations==1,"central terminal side effects accept qualified page proof");
 s=setup();s.preparedPageBaseline=new PageOutcomePolicy.Baseline(1,1,1,9950,9990,true,true);noteAcceptGestureDispatchStarted();
 SystemClock.advance(120);TapAccessibilityService.freshPage=true;TapAccessibilityService.repaint("offer unavailable");s.acceptScopedTerminalOutcomeSince(9900);s.pending.remove(0).run();
 SystemClock.advance(120);s.pending.remove(1).run();s.commit();check(s.tombstones==0&&s.navigations==0,"production scheduler cannot retire a prompt present before dispatch");
 s=setup();s.preparedPageBaseline=new PageOutcomePolicy.Baseline(1,1,1,9950,9990,true,false);noteAcceptGestureDispatchStarted();
 SystemClock.advance(120);TapAccessibilityService.repaint("offer unavailable");s.acceptScopedTerminalOutcomeSince(9900);s.pending.remove(0).run();
 check(s.acceptPageProbeCount==1&&s.acceptPageValidProbeCount==0,"incomplete read consumes total cap but not valid proof budget");
 check(s.reports.stream().anyMatch(x->x.contains("ACCEPT_PAGE_OUTCOME_PROBE")&&x.contains("NO_READ")),"unsuccessful real probe emits its reason");
 SystemClock.advance(120);TapAccessibilityService.freshPage=true;s.pending.remove(1).run();
 SystemClock.advance(120);s.pending.remove(1).run();
 check(s.pageBoundOutcome(9900).equals("offer unavailable"),"incomplete first read does not prevent later two-frame confirmation");
 s=setup();s.preparedPageBaseline=new PageOutcomePolicy.Baseline(1,1,1,9950,9990,true,false);noteAcceptGestureDispatchStarted();
 s.acceptPageProbeCount=6;s.acceptPageProbeStartedAt=10000;SystemClock.advance(1146);
 s.pageTracker(9900).observe(new PageOutcomePolicy.Reading(1,1,11126,11146,true,false,"offer unavailable",""),11146);
 s.scheduleAcceptPageProbe(9900);check(s.pending.size()==1,"sixth-read onset schedules reserved confirmation");
 SystemClock.advance(130);TapAccessibilityService.freshPage=true;s.pending.remove(0).run();
 check(s.acceptPageProbeCount==7&&s.pageBoundOutcome(9900).equals("offer unavailable"),"reserved seventh read binds late onset after normal window");
 s=setup();s.preparedPageBaseline=new PageOutcomePolicy.Baseline(1,1,1,9950,9990,true,false);noteAcceptGestureDispatchStarted();
 s.acceptPageProbeCount=6;s.acceptPageProbeStartedAt=10000;SystemClock.advance(1146);
 s.pageTracker(9900).observe(new PageOutcomePolicy.Reading(1,1,11126,11146,true,false,"",""),11146);
 s.pageTracker(9900).validReads=12;
 s.scheduleAcceptPageProbe(9900);check(s.pending.size()==1,"active monitored transaction keeps observing after twelfth read");
 s=setup();noteAcceptGestureDispatchStarted();List<Runnable> dedicated=new ArrayList<>();
 s.acceptOutcomeWorker=s.new Handler(dedicated);s.scheduleAcceptPageProbe(9900);
 check(s.pending.isEmpty()&&dedicated.size()==1,"post-dispatch probe bypasses busy offer scan queue");
 s.serialTopAction=SerialAction.NONE;dedicated.remove(0).run();
 check(s.acceptPageProbeCount==0&&!s.acceptPageProbeQueued.get(),"released owner cancels dedicated queued probe");
 s=setup();noteAcceptGestureDispatchStarted();s.scheduleAcceptPageProbe(9900);
 TapAccessibilityService.releaseDuringRead=true;s.pending.remove(0).run();
 check(s.reports.isEmpty()&&!s.acceptPageProbeQueued.get(),"owner release during Binder read drops old report and clears queue flag");
 s=setup();noteAcceptGestureDispatchStarted();s.scheduleAcceptPageProbe(9900);
 SystemClock.advance(3001);s.pending.remove(0).run();
 check(s.acceptPageProbeCount==1&&!s.pending.isEmpty(),"active transaction continues observations past three seconds");
 s=setup();noteAcceptGestureDispatchStarted();s.acceptPageProbeCount=2;
 s.pageTracker(9900).validReads=2;SystemClock.advance(1751);s.scheduleAcceptPageProbe(9900);
 check(s.pending.size()==1,"CAVA two reads after long queue gap still schedule useful work");
 s=setup();s.preparedPageBaseline=new PageOutcomePolicy.Baseline(1,1,1,9950,9990,true,false);noteAcceptGestureDispatchStarted();
 check(acceptRetryGuard(9900).isEmpty(),"clear current transaction can retry");
 s.pageTracker(9900).observe(new PageOutcomePolicy.Reading(1,1,10010,10020,true,false,"offer unavailable",""),10020);
 SystemClock.advance(21);
 check(acceptRetryGuard(9900).contains("NEGATIVE_PENDING"),"first fresh negative pauses actual retry before confirmation");
 SystemClock.advance(700);
 check(acceptRetryGuard(9900).contains("NEGATIVE_PENDING"),"candidate does not become retry permission when grace passes");
 s.pageTracker(9900).observe(new PageOutcomePolicy.Reading(1,1,10730,10740,true,false,"",""),10740);SystemClock.advance(20);
 check(acceptRetryGuard(9900).isEmpty(),"new clear read releases temporary pause");
 check(acceptRetryGuard(9899).contains("TRANSACTION_CHANGED"),"queued retry cannot inherit another transaction");
 s.pageTracker(9900).observe(new PageOutcomePolicy.Reading(1,1,10770,10780,true,false,"offer unavailable",""),10780);
 s.pageTracker(9900).observe(new PageOutcomePolicy.Reading(1,1,10900,10910,true,false,"offer unavailable",""),10910);SystemClock.advance(200);
 check(acceptRetryGuard(9900).contains("TERMINAL_OBSERVED"),"confirmed fresh loss blocks physical retry");
 s.monitorReady=false;check(acceptRetryGuard(9900).contains("CANCELLED"),"manual/stop guard cancels queued retry");
 s=setup();s.serialTopText="$195.36 0.3 mi";TapAccessibilityService.retryPage=true;noteAcceptGestureDispatchStarted();s.scheduleAcceptPageProbe(9900);SystemClock.advance(100);s.pending.remove(0).run();
 check(s.lastDelay==12&&s.polls==0,"enabled page schedules12ms proof and queues inspector without tapping on outcome worker");
 s.pending.remove(0).run();check(s.polls==1,"first fresh enabled page immediately wakes guarded inspector");
 SystemClock.advance(120);s.pending.remove(0).run();check(s.polls==1,"second proof queues inspector rather than invoking it inline");
 s.pending.remove(0).run();check(s.polls==2,"second verified page also wakes actual inspector lane");
 s=setup();s.serialTopText="$195.36 0.3 mi";TapAccessibilityService.retryPage=true;noteAcceptGestureDispatchStarted();s.scheduleAcceptPageProbe(9900);SystemClock.advance(100);s.pending.remove(0).run();
 s.serialTopActionAt++;s.pending.remove(0).run();check(s.polls==0,"first enabled-page wake cannot cross transaction token");
 s=setup();noteAcceptGestureDispatchStarted();
 s.scheduleAcceptPageProbe(9900);
 Runnable pendingProbe=s.pendingAcceptPageProbe;
 s.fastWorker.postAtFrontOfQueue(()->{});
 s.scheduleAcceptPageProbe(9900,true);
 check(pendingProbe!=null&&s.pending.get(0)==pendingProbe&&java.util.Collections.frequency(s.pending,pendingProbe)==1,
       "recovery promotes the existing delayed outcome read without duplicating it");
 System.out.println(checks+" production Accept outcome ownership/cache cases passed");
}}
'''
# The real commit method must gate before marking loss/tombstone or scheduling retirement.
finish=block(ocr,'    private synchronized void finishPendingClaimLoss(')
assert finish.index('canCommitAcceptTerminalLoss(')<finish.index('claimBudget.forget(')<finish.index('scheduleUnavailableCardRetirement(')
inspector=block(ocr,'    private void inspectClaim(String originalText, long epoch, int disabledChecks')
assert 'findOffer(' not in inspector and 'activePage()' not in inspector
assert 'observeCurrentTopAcceptSnapshot()' in inspector
assert 'OfferEnrichmentPolicy.sameTransaction(originalText, current.text)' in inspector
assert 'tracker.needsConfirmation(nowProbe)' not in finish
assert 'claimBudget.exhausted(id,' not in inspector
assert 'pressureBudgetObserving' not in inspector
assert 'ActionDispatchPolicy.previousGestureFinished(' in inspector
assert 'scheduledTracker.nextContinuousProbeDelayMs(acceptPageProbeCount,now)' in ocr
assert 'tracker.shouldWakeEnabledRecheck(SystemClock.elapsedRealtime())' in ocr
# Four offer dispatchers establish the fence before sending; navigation/popup do not.
assert tap.count('OcrMonitorService.noteAcceptGestureDispatchStarted();')==4
assert tap.count('ocrAcceptDispatchGuard(acceptActionAt,amount,miles)')==2
assert 'event.getEventTime(), claimNow' in tap
with tempfile.TemporaryDirectory(prefix='accept-fence-') as d:
 h=Path(d)/'OcrMonitorService.java';h.write_text(header+'\n'.join(block(tap,m) for m in tap_methods)+middle+'\n'.join(block(ocr,m) for m in ocr_methods)+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'AcceptOutcomeFence.java'),str(src/'ActionDispatchPolicy.java'),str(src/'PageOutcomePolicy.java'),str(src/'OfferEnrichmentPolicy.java'),str(src/'ClaimSuccessSignals.java'),str(src/'CardText.java'),str(h)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.OcrMonitorService'],check=True)
