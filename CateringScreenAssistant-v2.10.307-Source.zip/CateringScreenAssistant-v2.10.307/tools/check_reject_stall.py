#!/usr/bin/env python3
"""Execute the production pending-action watchdog and inspect the late-callback fence."""
from pathlib import Path
import tempfile
import subprocess

root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/local/cateringscreenassistant'
source=(src/'OcrMonitorService.java').read_text()
def block(signature):
    a=source.index(signature); b=source.index('{',a); end=b+1; depth=1
    while depth:
        depth+=(source[end]=='{')-(source[end]=='}'); end+=1
    return source[a:end]
head=r'''
package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;import java.util.function.*;
class SystemClock {static long elapsedRealtime(){return 4200;}static long uptimeMillis(){return 4200;}}
class TapAccessibilityService {
 static boolean jobsBadgeIncreasedSince(int n){return false;}
 static boolean recentAcceptedJobDetailMatches(String t,long n){return false;}
 static boolean isTerminalNegativeClaimOutcome(String t){return false;}
 static String recentEventClaimOutcomeAfter(long epoch,long at){return "";}
}
public class OcrMonitorService {
 boolean preserveVisibleAcceptLoading(long at,PageOutcomePolicy.Tracker t,long now){return false;}
 enum SerialAction{NONE,ACCEPT,REJECT}
 SerialAction serialTopAction=SerialAction.REJECT;
 String serialTopText="$30 2.5 mi Tomorrow at 11:15 AM Mendocino Farms • 2847 Park Ave, Tustin, CA 92782";
 long serialTopActionAt=1000,rejectDispatchCompletedAt,rejectOutcomeBaselineEpoch=7;
 long acceptRetryDispatchPendingAt;
 PageOutcomePolicy.Tracker tracker;
 PageOutcomePolicy.Tracker pageTracker(long at){return tracker;}
 long rejectProcessingConfirmedAt,acceptDispatchObservationAt=1000,acceptCallbackDelayReportedForActionAt,terminalLossUntil;
 int pendingAcceptJobsBaseline=1,backgroundStarts,rejectInspections,cancels;
 String terminalLossIdentity="";AtomicLong claimEpoch=new AtomicLong(1);
 RejectSequence rejectSequence=new RejectSequence();List<String> logs=new ArrayList<>();
 boolean acceptGestureDispatchedForCurrentTransaction(){return true;}
 boolean acceptGestureCompletedForCurrentTransaction(){return true;}
 void cancelUndispatchedAccept(String t,String reason){cancels++;}
 Consumer<String> offerReporter(String text){return logs::add;}
 String acceptScopedOutcomeSince(long at){return "";}
 String acceptScopedTerminalOutcomeSince(long at){return "";}
 boolean isBoundPositiveClaimOutcome(String a,String b,long at){return false;}
 void confirmPendingClaimSuccess(String a,String b){}
 void holdJobDetailCandidate(String a,String b){}
 void finishPendingClaimLoss(String a,String b,boolean terminal){serialTopAction=SerialAction.NONE;}
 void markTerminalLoss(String text,long now){}
 void inspectClaim(String text,long epoch){}
 void inspectReject(String text,long epoch,int missing){rejectInspections++;}
 static class RejectConfirmState {long token;}
 Map<String,RejectConfirmState> rejectConfirmStates=new HashMap<>();
 RejectTerminalGate rejectTerminalGate=new RejectTerminalGate();
 long acceptProcessingConfirmedAt,rejectTransitionSuppressUntil,cooldownUntil,
      accessibilityActionHoldUntil,lastReadableFastScan,lastScan;
 void requestImmediateFastCheck(long at){}
 Consumer<String> offerReporterWithTiming(String text,String timing){return message -> logs.add(timing+" "+message);}
 void startAsyncRejectConfirmation(String text,long baseline,long at){
  if(!text.equals(serialTopText)||baseline!=7||at!=1000)throw new AssertionError("wrong watchdog owner");
  backgroundStarts++;claimEpoch.incrementAndGet();serialTopAction=SerialAction.NONE;serialTopText="";serialTopActionAt=0;
 }
'''
test=r'''
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
  OcrMonitorService h=new OcrMonitorService();
  check(h.handlePendingSerialFast(4199)&&h.backgroundStarts==0,"callback wait has a strict3.2-second bound");
  check(h.handlePendingSerialFast(4200)&&h.backgroundStarts==1,"missing Reject callback transfers to bounded current-card confirmation");
  check(h.serialTopAction==SerialAction.NONE&&h.claimEpoch.get()==2&&h.rejectInspections==0,"watchdog releases foreground without a blocking tree or success verdict");
  check(!h.handlePendingSerialFast(4300)&&h.backgroundStarts==1,"duplicate watchdog cannot create a second owner");
  h=new OcrMonitorService();h.rejectDispatchCompletedAt=1200;h.handlePendingSerialFast(4200);
  check(h.backgroundStarts==0&&h.rejectInspections==1,"completed callbacks retain existing Reject confirmation");
  h=new OcrMonitorService();h.serialTopAction=SerialAction.ACCEPT;h.handlePendingSerialFast(4200);
  check(h.backgroundStarts==0,"Reject watchdog never releases an Accept transaction");
  h.tracker=new PageOutcomePolicy.Tracker(4100,h.serialTopText,
          new PageOutcomePolicy.Baseline(1,1,1,4090,4099,true,false),true);
  h.tracker.observe(new PageOutcomePolicy.Reading(1,1,4120,4140,true,false,"",
          "$259.73 3.3 mi Erewhon Market • 8550 Santa Monica Blvd, West Hollywood, CA 90069"),4140);
  h.acceptRetryDispatchPendingAt=4180;
  check(h.handlePendingSerialFast(4200)&&h.serialTopAction==SerialAction.ACCEPT,"in-flight retry keeps its callback owner");
  h.acceptRetryDispatchPendingAt=0;
  check(h.handlePendingSerialFast(4201)&&h.serialTopAction==SerialAction.NONE,"confirmed swap immediately releases serial lane");
  h=new OcrMonitorService();String gone=h.serialTopText;
  h.finishRejectTransaction(gone,true,false,"original offer gone with processing evidence");
  check(h.logs.size()==1&&h.logs.get(0).startsWith("Reject尝试ID=1000 REJECT_DISAPPEARED"),
        "processing evidence does not replace the old-card departure outcome");
  h.finishRejectTransaction(gone,true,false,"duplicate departure");
  check(h.logs.size()==1,"retired serial attempt cannot log a second outcome");
  h=new OcrMonitorService();h.finishRejectTransaction(h.serialTopText,false,true,"negative server outcome");
  check(h.logs.size()==1&&h.logs.get(0).startsWith("Reject尝试ID=1000 REJECT_BACKGROUND_FINALIZED"),
        "server outcome is distinct from a page-observed departure");
  System.out.println("11 production callback-watchdog, swap-release and terminal reporting cases passed");
 }}
'''
with tempfile.TemporaryDirectory(prefix='csa-reject-stall-') as d:
    harness=Path(d)/'OcrMonitorService.java'
    harness.write_text(head+block('    private boolean handlePendingSerialFast(')+block('    private void finishRejectTransaction(')+test)
    subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(harness),
                    *[str(src/name) for name in ['CardText.java','OfferEnrichmentPolicy.java','RejectSequence.java','RejectTerminalGate.java','ActionDispatchPolicy.java','PageOutcomePolicy.java','ClaimSuccessSignals.java']]],check=True)
    subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.OcrMonitorService'],check=True)
failed=source[source.index('java.util.function.Consumer<String> failed = failureReason -> {'):]
assert failed.index('rejectEpoch != claimEpoch.get()') < failed.index('rejectSequence.failed(')
