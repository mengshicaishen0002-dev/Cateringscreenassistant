#!/usr/bin/env python3
"""Exercise production Pasadena enrichment and queue choice with deterministic receipts."""
from pathlib import Path
import tempfile, subprocess
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()
def block(signature):
 a=s.index(signature);b=s.index('{',a);d=1;i=b+1
 while d:
  d+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
a=s.index('        boolean priorityOffer =');b=s.index(';',a)+1
priority=s[a:b]
head=r'''package com.local.cateringscreenassistant;
import java.util.*;
class SystemClock {static long now=1000;static long elapsedRealtime(){return now;}}
class Rect {boolean empty;boolean isEmpty(){return empty;}}
class TapAccessibilityService {
 static class DecisionEvidence {String text;float amount,miles;long capturedAt;DecisionEvidence(String t,long at){text=t;amount=CardText.amount(t);miles=CardText.miles(t);capturedAt=at;}}
 static class FastOfferSnapshot {String text;float amount,miles;long capturedAt;boolean acceptEnabled=true;Rect acceptBounds=new Rect();Object receipt=new Object();
 FastOfferSnapshot(String t,long at){text=t;amount=CardText.amount(t);miles=CardText.miles(t);capturedAt=at;}
 FastOfferSnapshot withDecisionText(String t){FastOfferSnapshot f=new FastOfferSnapshot(t,capturedAt);f.receipt=receipt;return f;}}
}
public class OcrMonitorService {
 enum SerialAction {NONE,ACCEPT,REJECT} SerialAction serialTopAction=SerialAction.NONE;long cancelledAcceptPriorityUntil;
 static class Prefs {boolean enabled=true;boolean getBoolean(String k,boolean d){return enabled;}float getFloat(String k,float d){return k.equals("minPay")?80:k.equals("maxMiles")?20:k.equals("pasadenaMinPay")?25:5;}}
 Prefs prefs=new Prefs();
 boolean decisionNeedsOfferTimeEvidence(){return false;}
 boolean quickDecisionTextComplete(String t,float a,float m){return !OfferEnrichmentPolicy.endpointKey(t).isEmpty()&&a>=0&&m>=0;}
 String fastRuleFailure(String t,float a,float m){return PasadenaRuleGuard.isPasadenaOffer(t)&&a>=25&&m<=5?"":"FAIL";}
 boolean universallyQualifiedByNumbers(float a,float m){return a>=80&&m<=20;}
 float offerLowAmount(String t){return CardText.amount(t);}float offerMiles(String t){return CardText.miles(t);}
 static long offerDemandAt;boolean structuralWakePending;
 static boolean foregroundOfferDemandRecent(long age){return offerDemandAt>0 && SystemClock.now-offerDemandAt<=age;}
 boolean priority(TapAccessibilityService.DecisionEvidence priorityEvidence){OcrMonitorService service=this;
'''
tests=r'''return priorityOffer;}
 static int checks;static void check(boolean x,String why){checks++;if(!x)throw new AssertionError(why);}
 public static void main(String[] args){
 OcrMonitorService o=new OcrMonitorService();
 String card="$28–38 3.4 mi Tomorrow at 6:00 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 TapAccessibilityService.FastOfferSnapshot c=new TapAccessibilityService.FastOfferSnapshot(card,980);
 TapAccessibilityService.DecisionEvidence e=new TapAccessibilityService.DecisionEvidence(card,995);
 TapAccessibilityService.FastOfferSnapshot f=o.fusePasadenaCityEvidence(c,e);
 check(f!=null&&f.receipt==c.receipt&&f.capturedAt==980,"enrichment preserves live receipt and never refreshes its age from cached fields");
 check(o.priority(e),"Pasadena numeric candidate enters priority queue");
 offerDemandAt=990;check(o.priority(null),"fresh coherent offer demand goes ahead of old tail work");
 offerDemandAt=960;check(!o.priority(null),"old demand does not keep priority");offerDemandAt=0;
 e=new TapAccessibilityService.DecisionEvidence("$28 12.6 mi",990);check(!o.priority(e),"long mileage is not an Accept queue candidate");
 e=new TapAccessibilityService.DecisionEvidence("$98 0.5 mi",990);check(o.priority(e),"General queue priority remains");
 e=new TapAccessibilityService.DecisionEvidence(card,995);o.serialTopAction=SerialAction.REJECT;check(o.priority(e),"old Reject yields priority slot to qualified candidate");o.serialTopAction=SerialAction.ACCEPT;check(!o.priority(e),"in-flight Accept remains exclusive");o.serialTopAction=SerialAction.NONE;
 e=new TapAccessibilityService.DecisionEvidence(card,400);check(o.fusePasadenaCityEvidence(c,e)==null,"stale event is rejected");
 e=new TapAccessibilityService.DecisionEvidence(card.replace("6:00 AM","7:00 AM"),995);check(o.fusePasadenaCityEvidence(c,e)==null,"conflicting pickup cannot enrich current card");
 e=new TapAccessibilityService.DecisionEvidence(card.replace("3.4 mi","4.4 mi"),995);check(o.fusePasadenaCityEvidence(c,e)==null,"numeric mismatch rejected");
 e=new TapAccessibilityService.DecisionEvidence(card,995);c.acceptEnabled=false;check(o.fusePasadenaCityEvidence(c,e)==null,"disabled current control rejected");c.acceptEnabled=true;
 o.prefs.enabled=false;check(!o.pasadenaNumericCandidate(e),"disabled special rule not a priority candidate");
 System.out.println(checks+" production Pasadena enrichment/queue cases passed");}}
'''
body='\n'.join(block(m) for m in ['    private boolean pasadenaNumericCandidate(', '    private TapAccessibilityService.FastOfferSnapshot fusePasadenaCityEvidence('])
with tempfile.TemporaryDirectory(prefix='csa-pasadena-') as d:
 h=Path(d)/'OcrMonitorService.java'
 # Methods belong inside the class, before the priority method.
 h.write_text(head[:head.index(' boolean priority(')]+body+'\n'+head[head.index(' boolean priority('):]+priority+tests)
 names=['CardText.java','OfferEnrichmentPolicy.java','PasadenaRuleGuard.java','ClaimSuccessSignals.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in names],str(h)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.OcrMonitorService'],check=True)
