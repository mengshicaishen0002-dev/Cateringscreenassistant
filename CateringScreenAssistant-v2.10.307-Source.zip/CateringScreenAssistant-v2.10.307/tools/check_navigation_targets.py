"""Execute current target selection, bounded parent click and recovery visibility on RN trees."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'TapAccessibilityService.java').read_text()
def block(sig):
 a=s.index(sig);i=s.index('{',a)+1;d=1;b=i
 while d:d+=(s[b]=='{')-(s[b]=='}');b+=1
 return s[a:b]
head='''package com.local.cateringscreenassistant;
import java.util.*;
class Rect {int left,top,right,bottom;Rect(){}Rect(int l,int t,int r,int b){left=l;top=t;right=r;bottom=b;}int width(){return right-left;}int height(){return bottom-top;}int centerX(){return(left+right)/2;}int centerY(){return(top+bottom)/2;}boolean isEmpty(){return width()<=0||height()<=0;}boolean contains(int x,int y){return x>=left&&x<right&&y>=top&&y<bottom;}void set(Rect v){left=v.left;top=v.top;right=v.right;bottom=v.bottom;}}
class AccessibilityNodeInfo {static int ACTION_CLICK=16;String text;Rect bounds;boolean visible=true,selected,clickable;int clicks;AccessibilityNodeInfo parent;List<AccessibilityNodeInfo> kids=new ArrayList<>();AccessibilityNodeInfo(String t,Rect b){text=t;bounds=b;}AccessibilityNodeInfo add(AccessibilityNodeInfo n){kids.add(n);n.parent=this;return n;}static AccessibilityNodeInfo obtain(AccessibilityNodeInfo n){return n;}CharSequence getText(){return text;}CharSequence getContentDescription(){return null;}boolean isVisibleToUser(){return visible;}boolean isSelected(){return selected;}boolean isChecked(){return false;}boolean isClickable(){return clickable;}boolean isEnabled(){return true;}int getActions(){return clickable?16:0;}boolean performAction(int x){clicks++;return true;}void getBoundsInScreen(Rect r){r.set(bounds);}AccessibilityNodeInfo getParent(){return parent;}int getChildCount(){return kids.size();}AccessibilityNodeInfo getChild(int i){return kids.get(i);}void recycle(){}}
class OcrMonitorService{static boolean isManualInterventionPaused(){return false;}}
public class NavigationTargets {static String lettersOnlyLower(CharSequence s){return s.toString().toLowerCase(Locale.US).replaceAll("[^a-z]","");}static boolean matchesAccept(CharSequence s){return s!=null && s.toString().equalsIgnoreCase("Accept");}
'''
test='''static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}public static void main(String[] args){
 Rect screen=new Rect(0,0,1080,2400);AccessibilityNodeInfo root=new AccessibilityNodeInfo("",screen);
 AccessibilityNodeInfo title=root.add(new AccessibilityNodeInfo("Offers",new Rect(80,80,300,150)));
 root.add(new AccessibilityNodeInfo("Jobs",new Rect(100,360,200,410)));
 AccessibilityNodeInfo offers=root.add(new AccessibilityNodeInfo("Offers",new Rect(400,360,500,410)));
 root.add(new AccessibilityNodeInfo("Ignored",new Rect(700,360,820,410)));
 check(findOffersNavigationNode(root,screen)==offers,"actual Jobs/Offers/Ignored row outranks earlier heading");
 root.clickable=true;check(!clickNavigationNode(offers)&&root.clicks==0,"whole tab bar/page parent never receives semantic click");
 offers.clickable=true;check(clickNavigationNode(offers)&&offers.clicks==1,"actual enabled visible tab receives click");
 offers.visible=false;check(!clickNavigationNode(offers),"hidden tab cannot receive semantic click");offers.visible=true;
 AccessibilityNodeInfo hidden=root.add(new AccessibilityNodeInfo("Ignored",new Rect(0,300,200,350)));hidden.visible=false;hidden.selected=true;
 AccessibilityNodeInfo restore=hidden.add(new AccessibilityNodeInfo("Restore",new Rect(0,500,200,550)));restore.visible=false;
 offers.selected=true;boolean[] flags=new boolean[7];StringBuilder text=new StringBuilder();collectRecoveryPageFlags(root,flags,text);
 check(flags[2]&&!flags[0]&&!flags[3],"hidden selected Ignored and Restore cannot contaminate current recovery classification");
 AccessibilityNodeInfo bridge=root.add(new AccessibilityNodeInfo("",screen));bridge.visible=false;bridge.add(new AccessibilityNodeInfo("No offers available",new Rect(0,600,500,650)));
 flags=new boolean[7];collectRecoveryPageFlags(root,flags,new StringBuilder());check(flags[6],"visible descendant under hidden RN bridge still supplies current evidence");
 hidden.visible=true;flags=new boolean[7];collectRecoveryPageFlags(root,flags,new StringBuilder());check(flags[0],"actually visible selected Ignored remains a blocker");
 AccessibilityNodeInfo onlyHeading=new AccessibilityNodeInfo("",screen);onlyHeading.add(new AccessibilityNodeInfo("Offers",new Rect(80,80,300,150)));
 check(findOffersNavigationNode(onlyHeading,screen)==null,"recovery never clicks uncorroborated Offers heading");
 System.out.println(checks+" production navigation target/visibility cases passed");}}
'''
methods=['    private static boolean clickNavigationNode(', '    private static AccessibilityNodeInfo findOffersNavigationNode(', '    private static void collectNavigationNodes(', '    private static String nodeLabel(', '    private static void collectRecoveryPageFlags(']
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'NavigationTargets.java';p.write_text(head+'\n'.join(block(m) for m in methods)+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'ButtonLabels.java'),str(src/'EmptyOffersPolicy.java'),str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.NavigationTargets'],check=True)
