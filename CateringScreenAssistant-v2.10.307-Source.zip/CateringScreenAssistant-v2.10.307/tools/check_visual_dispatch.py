#!/usr/bin/env python3
"""Exercise production first-shot preflight/rebound, with Android reads/dispatch mocked."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1];s=root/'app/src/main/java/com/local/cateringscreenassistant'
t=(s/'TapAccessibilityService.java').read_text()
def block(sig):
 a=t.index(sig);b=t.index('{',a);depth=1;i=b+1
 while depth:
  depth+=(t[i]=='{')-(t[i]=='}');i+=1
 return t[a:i]
header=r'''package com.local.cateringscreenassistant;
import java.util.*;import java.util.function.*;import java.util.concurrent.atomic.*;
class SystemClock {static long now=1000;static long elapsedRealtime(){return now;}}
class Rect {int left,top,right,bottom;Rect(){}Rect(int a,int b,int c,int d){left=a;top=b;right=c;bottom=d;}Rect(Rect r){set(r);}
 void set(Rect r){left=r.left;top=r.top;right=r.right;bottom=r.bottom;}boolean isEmpty(){return right<=left||bottom<=top;}}
class AccessibilityNodeInfo {CharSequence getPackageName(){return "com.deliverthat.driver";}void recycle(){}
 void getBoundsInScreen(Rect r){r.set(new Rect(0,0,1080,2400));if(TapAccessibilityService.rootMutates){TapAccessibilityService.UI_GENERATION.incrementAndGet();TapAccessibilityService.rootMutates=false;}}}
class OcrMonitorService {static boolean monitoring=true;static String cardGuard="";static String firstAcceptCardGuard(String t){return cardGuard;}static boolean isMonitoring(){return monitoring;}}
public class TapAccessibilityService {
 static final AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>(new TapAccessibilityService());static final AtomicLong UI_GENERATION=new AtomicLong(1);
 static boolean currentNegative;static boolean currentNegativeSurfaceBlocksAccept(){return currentNegative;}
 static PageGuard.Page page=PageGuard.Page.UNKNOWN;static boolean rootMutates,indexMutates;static int transientMutations;static int exact,generic,tree,dispatch;static FastOfferSnapshot indexed;
 static class FastOfferSnapshot {String text;Rect acceptBounds;boolean acceptEnabled;FastOfferSnapshot(String t,Rect b,boolean e){text=t;acceptBounds=b;acceptEnabled=e;}}
 static class QuickTopResult {FastOfferSnapshot snapshot;}
 static boolean noHigherIndexedOfferAction(AccessibilityNodeInfo r,Rect b,float y){return !higherRow;}static boolean higherRow;
 AccessibilityNodeInfo getRootInActiveWindow(){return new AccessibilityNodeInfo();}
 static boolean isDeliverThatForeground(){return true;}static PageGuard.Page recentPageHint(){return page;}
 static FastOfferSnapshot getIndexedNumericTopAcceptSnapshot(float a,float m){exact++;if(indexMutates||exact<=transientMutations)UI_GENERATION.incrementAndGet();return indexed;}
 static FastOfferSnapshot getIndexedTopAcceptSnapshot(boolean a,boolean b){generic++;return null;}
 static QuickTopResult getQuickTopOfferSnapshotResult(long ms,int nodes){tree++;return new QuickTopResult();}
 static boolean safeActionBounds(Rect root,Rect b,boolean a){return b.left>540&&b.right<=root.right&&!b.isEmpty();}
 static void dispatchVerifiedSnapshotGesture(TapAccessibilityService s,Rect b,Rect r,boolean a,long ms,int v,boolean bindForPressure,Consumer<String> ok,Consumer<String> fail,BooleanSupplier fresh){if(!bindForPressure)throw new AssertionError("visual first tap must bind the verified CTA");if(!fresh.getAsBoolean()){fail.accept("FINAL_PROOF_CHANGED");return;}dispatch++;ok.accept("SENT");}
'''
tests=r'''
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static final Rect button=new Rect(689,1281,840,1338);
 static final String old="$133.85 Est. 17.9 mi Tomorrow at 7:50 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 static void reset(){currentNegative=false;transientMutations=0;higherRow=false;OcrMonitorService.cardGuard="";exact=generic=tree=dispatch=0;page=PageGuard.Page.UNKNOWN;rootMutates=indexMutates=false;SystemClock.now=1000;UI_GENERATION.set(1);indexed=new FastOfferSnapshot("$133.85 17.9 mi",button,true);}
 static void tap(long gen,long at){tapVisualAccessibilityOffer(button,133.85f,17.9f,old,at,gen,m->{},m->{});}
 public static void main(String[] args){
 reset();tap(1,990);check(dispatch==1&&exact==0&&generic==0&&tree==0,"unchanged frame dispatches without repeated field/tree work");
 reset();currentNegative=true;tap(1,990);check(dispatch==0,"visible failure veto survives to final visual gesture supplier");
 reset();OcrMonitorService.cardGuard="ACCEPT_REJECT_OWNED";tap(1,990);check(dispatch==0,"final visual first-shot refuses current Reject ownership");
 reset();higherRow=true;tap(1,990);check(dispatch==0,"visual first-shot refuses a readable upper offer");
 reset();UI_GENERATION.set(2);tap(1,990);check(dispatch==1&&exact==1&&generic==0&&tree==0,"RN churn uses one exact-pair rebind, no generic/tree restart");
 reset();rootMutates=true;tap(1,990);check(dispatch==1&&exact==1,"root read mutation gets one live rebind after root, no double rebuild");
 reset();indexed=new FastOfferSnapshot("$134.85 17.9 mi",button,true);UI_GENERATION.set(2);tap(1,990);check(dispatch==0,"different current pay cancels");
 reset();indexed=new FastOfferSnapshot("$133.85 18.9 mi",button,true);UI_GENERATION.set(2);tap(1,990);check(dispatch==0,"different current miles cancels");
 reset();indexed=new FastOfferSnapshot(old.replace("7:50","8:50"),button,true);UI_GENERATION.set(2);tap(1,990);check(dispatch==0,"same pair conflicting pickup cancels");
 reset();indexed=new FastOfferSnapshot(old,new Rect(689,1600,840,1657),true);UI_GENERATION.set(2);tap(1,990);check(dispatch==0,"different action row never inherits old frame");
 reset();indexed.acceptEnabled=false;UI_GENERATION.set(2);tap(1,990);check(dispatch==0,"disabled Accept cannot dispatch");
 reset();indexMutates=true;UI_GENERATION.set(2);tap(1,990);check(dispatch==0&&exact==2&&generic==0&&tree==0,"continuous mutation stops after one restart");
 reset();transientMutations=1;UI_GENERATION.set(2);tap(1,990);check(dispatch==1&&exact==2&&generic==0&&tree==0,"one transient mutation recovers in the same frame");
 reset();transientMutations=1;indexed.acceptEnabled=false;UI_GENERATION.set(2);tap(1,990);check(dispatch==0&&exact==2,"restart still needs an enabled control");
 reset();page=PageGuard.Page.JOBS;tap(1,990);check(dispatch==0,"Jobs remains blocked");
 reset();page=PageGuard.Page.IGNORED;tap(1,990);check(dispatch==0,"Ignored remains blocked");
 reset();UI_GENERATION.set(2);tap(1,500);check(dispatch==0,"old visual frame cannot rebind");
 reset();indexed=new FastOfferSnapshot("Begin Delivery $133.85 17.9 mi",button,true);UI_GENERATION.set(2);tap(1,990);check(dispatch==0,"accepted-job controls block offer action");
 System.out.println(checks+" production visual dispatch/rebound cases passed");
 }}'''
with tempfile.TemporaryDirectory(prefix='csa-visual-') as d:
 p=Path(d);h=p/'TapAccessibilityService.java';h.write_text(header+'\n'.join(block(sig) for sig in ['    private static final class VisualGenerationRebound {','    private static VisualGenerationRebound tryVisualGenerationRebound(','    public static void tapVisualAccessibilityOffer('])+tests)
 names=['CardText.java','ClaimSuccessSignals.java','PageGuard.java','ScanPolicy.java','ActionDispatchPolicy.java','VisualGenerationReboundPolicy.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(s/n) for n in names],str(h)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.TapAccessibilityService'],check=True)
