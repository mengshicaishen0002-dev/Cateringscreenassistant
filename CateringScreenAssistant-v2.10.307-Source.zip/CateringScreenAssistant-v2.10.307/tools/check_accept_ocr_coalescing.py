"""Exercise the production ordinary-OCR coalescer; new/ambiguous/terminal cards must reopen it."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()
a=s.index('    private boolean skipFreshOwnedAcceptOcr(');i=s.index('{',a)+1;d=1
while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
method=s[a:i]
head='''package com.local.cateringscreenassistant;
class AcceptOcrHarness {
 enum SerialAction{NONE,ACCEPT,REJECT}SerialAction serialTopAction=SerialAction.ACCEPT;
 long serialTopActionAt=1000;String serialTopText=OFFER;boolean sent=true;String terminal="";static boolean demand;
 static boolean foregroundOfferDemandRecent(long age){return demand;}
 static final String OFFER="$100.40 10.8 mi Tomorrow at 11:35 AM Mendocino Farms • 4201 McGowen St #205, Long Beach, CA 90808";
 boolean acceptGestureDispatchedForCurrentTransaction(){return sent;}
 String pageBoundOutcome(long at){return terminal;}
 static class TapAccessibilityService {
  static long generation=1;static DecisionEvidence evidence;
  static class DecisionEvidence{String text;long capturedAt=1100,uiGeneration=1;DecisionEvidence(String t){text=t;}}
  static DecisionEvidence recentDecisionEvidence(long age){return evidence;}
  static long currentUiGeneration(){return generation;}
 }
 static int checks;static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
 static void evidence(String t){TapAccessibilityService.evidence=new TapAccessibilityService.DecisionEvidence(t);}
'''
test=''' public static void main(String[] args){
 AcceptOcrHarness h=new AcceptOcrHarness();evidence(OFFER);
 check(h.skipFreshOwnedAcceptOcr(1119),"fresh full same-generation owned evidence avoids duplicate ordinary OCR");
 demand=true;check(!h.skipFreshOwnedAcceptOcr(1119),"new foreground demand wins even with matching cached owner text");demand=false;
 check(h.skipFreshOwnedAcceptOcr(1200),"100ms inclusive evidence boundary");
 check(!h.skipFreshOwnedAcceptOcr(1201),"expired evidence immediately reopens ordinary OCR");
 check(!h.skipFreshOwnedAcceptOcr(1099),"future evidence cannot suppress OCR");
 TapAccessibilityService.generation=2;check(!h.skipFreshOwnedAcceptOcr(1119),"new publication generation reopens OCR");TapAccessibilityService.generation=1;
 for(String t:new String[]{OFFER.replace("100.40","101.40"),OFFER.replace("10.8","10.9"),OFFER.replace("4201","4202"),OFFER.replace("11:35","11:40"),"$100.40 10.8 mi",OFFER+" Begin Delivery",OFFER+" "+OFFER.replace("4201","4202")}) {
  evidence(t);check(!h.skipFreshOwnedAcceptOcr(1119),"changed/partial/terminal/conflicting identity retains OCR: "+t);
 }
 evidence(OFFER);h.terminal="offer unavailable";check(!h.skipFreshOwnedAcceptOcr(1119),"bound failure retains independent visual verification");h.terminal="accepted";check(!h.skipFreshOwnedAcceptOcr(1119),"bound success retains independent visual verification");h.terminal="";
 h.sent=false;check(!h.skipFreshOwnedAcceptOcr(1119),"pre-dispatch first shot retains OCR fallback");h.sent=true;
 h.serialTopActionAt=0;check(!h.skipFreshOwnedAcceptOcr(1119),"unowned frame cannot be coalesced");h.serialTopActionAt=1000;
 h.serialTopAction=SerialAction.NONE;check(!h.skipFreshOwnedAcceptOcr(1119),"new-card scan remains open");h.serialTopAction=SerialAction.REJECT;check(!h.skipFreshOwnedAcceptOcr(1119),"Accept helper does not suppress Reject work");h.serialTopAction=SerialAction.ACCEPT;
 TapAccessibilityService.evidence=null;check(!h.skipFreshOwnedAcceptOcr(1119),"missing semantics leaves image fallback open");
 System.out.println(checks+" production Accept ordinary-OCR coalescing cases passed");
 }}'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'AcceptOcrHarness.java';f.write_text(head+method+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in ['CardText.java','ClaimSuccessSignals.java','OfferEnrichmentPolicy.java','IndexedWitnessPolicy.java','RejectDemandPolicy.java']],str(f)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.AcceptOcrHarness'],check=True)
frame=s[s.index('    private void onFrame('):s.index('    private boolean tryVisualAccessibilityFastLane(')]
assert frame.index('skipFreshOwnedAcceptOcr(')<frame.index('imageToTopRoiBitmap(')<frame.index('recognizer.process(')
assert frame.count('skipFreshOwnedAcceptOcr(')==3
# Each gate is explicitly ordinary-only: terminal and current visual retry bypass it.
for fragment in frame.split('skipFreshOwnedAcceptOcr(')[:-1]:
 assert '!terminalProbe && !visualRetryProbe' in fragment[-160:]
print('Accept ordinary-only pre-copy/pre-submit integration checks passed')
