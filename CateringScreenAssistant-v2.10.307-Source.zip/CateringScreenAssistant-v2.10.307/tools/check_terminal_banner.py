#!/usr/bin/env python3
"""Exercise actual terminal OCR consumer and page filter with field toast vocabulary."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
ocr=(src/'OcrMonitorService.java').read_text();tap=(src/'TapAccessibilityService.java').read_text()
def block(s,k):
 a=s.index(k);b=s.index('{',a);i=b+1;n=1
 while n:
  n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
assert 'acceptGestureDispatchedForCurrentTransaction()' in block(ocr,'    private boolean terminalVisualContext(')
methods='\n'.join([block(ocr,'    private String visualBoundOutcome('),block(ocr,'    private void observeTerminalVisual('),block(tap,'    private static String pageNegativeHint(')])
header='''package com.local.cateringscreenassistant;
import java.util.*;
public class BannerHarness {
 static class SystemClock {static long now;static long elapsedRealtime(){return now;}}
 static class TapAccessibilityService {static long gen=1,epoch=1;static boolean foreground=true;static int notes;
 static boolean isDeliverThatForeground(){return foreground;}static long currentUiGeneration(){return gen;}
 static long outcomeWindowEpoch(){return epoch;}static void noteBeginDeliveryOcr(boolean b,String s,long at,long g){notes++;}}
 enum SerialAction {NONE,ACCEPT};SerialAction serialTopAction=SerialAction.ACCEPT;
 boolean monitorReady=true,postClaimIsolationActive;String serialTopText="offer A",postTerminalVerifyOfferText="";
 long serialTopActionAt=1000,lastActionDispatchAt=1000,postTerminalVerifyActionAt,postTerminalVerifyUntil;
 static boolean isManualInterventionPaused(){return false;}
 final ClaimVisualProbePolicy.NegativeProof terminalVisualNegative=new ClaimVisualProbePolicy.NegativeProof();
 AcceptOutcomeFence fence=new AcceptOutcomeFence(1,1000,1,1010,1010);int pauses,losses,successes;
 AcceptOutcomeFence acceptFenceFor(long at){return fence!=null&&fence.actionAt==at?fence:null;}
 void pauseAcceptPressureForContext(long at,String s,long now){pauses++;}
 void finishPendingClaimLoss(String owner,String evidence,boolean terminal){if(terminal&&!visualBoundOutcome(serialTopActionAt).isEmpty())losses++;}
 void confirmPendingClaimSuccess(String s,String e){successes++;}void confirmPostTerminalClaimSuccess(String s,String e){successes++;}
 static int count;static void ck(boolean b,String m){count++;if(!b)throw new AssertionError(m);}
 void read(String s,long frame,long now,boolean header){SystemClock.now=now;observeTerminalVisual(s,frame,1,header);}
'''
tests=''' public static void main(String[] args){
 String banner="Job Already Assigned\\nThis job is already assigned to another driver.";
 String hint=ClaimSuccessSignals.extractOutcomeHint(banner);
 ck(ClaimSuccessSignals.isTerminalNegative(hint),"actual red banner parsed");
 ck(pageNegativeHint(banner).equals(hint),"actual page filter reaches parser");
 ck(pageNegativeHint("Assigned to you").isEmpty(),"self assignment is not failure");
 ck(ClaimSuccessSignals.isPositive(ClaimSuccessSignals.extractOutcomeHint("Job already assigned to you")),"self assignment remains positive");
 ck(pageNegativeHint("Driver assigned / no offers available").isEmpty(),"generic assigned/available not terminal");
 ck(!ClaimVisualProbePolicy.headerDue(true,false,true,false,2000,0),"no work before dispatch");
 ck(!ClaimVisualProbePolicy.headerDue(true,true,false,false,2000,0),"no header OCR before loading");
 ck(!ClaimVisualProbePolicy.headerDue(true,true,true,true,2000,0),"one OCR in flight");
 ck(!ClaimVisualProbePolicy.headerDue(true,true,true,false,2200,2000),"500ms cadence");
 ck(ClaimVisualProbePolicy.headerDue(true,true,true,false,2500,2000),"postloading header fallback even if page clear");
 ck(ClaimVisualProbePolicy.top()==0&&ClaimVisualProbePolicy.headerBottom(2340)==468,"top toast above old 20% crop included");
 BannerHarness a=new BannerHarness();a.read("",1100,1200,true);a.read(banner,1500,1650,true);a.read(banner,2100,2250,true);
 ck(a.losses==0,"empty OCR is not a clear baseline");
 a=new BannerHarness();a.read("Deliveries Offers",1100,1200,true);
 ck(TapAccessibilityService.notes==0,"header-only blank cannot erase success proof");
 a.read(banner,1500,1650,true);ck(a.pauses==1&&a.losses==0,"first negative pauses, does not commit");
 a.read(banner,1500,1660,true);ck(a.losses==0,"same screenshot is not second proof");
 a.read(banner,1550,1680,true);ck(a.losses==0,"too-close screenshot is not second proof");
 a.read(banner,1600,1750,true);ck(a.losses==1,"two fresh negative frames reach existing loss flow");
 ck(a.visualBoundOutcome(1000).equals(hint),"negative participates in scoped commit and late-tail readers");
 TapAccessibilityService.epoch=2;ck(a.visualBoundOutcome(1000).isEmpty(),"window transition invalidates result");
 TapAccessibilityService.epoch=1;ck(a.visualBoundOutcome(2000).isEmpty(),"new offer never inherits proof");
 a=new BannerHarness();a.read(banner,1100,1200,true);a.read(banner,1800,1900,true);
 ck(a.losses==0,"preexisting toast is not fabricated new outcome");
 a=new BannerHarness();a.read("Deliveries Offers",1100,1200,true);a.read(banner,1500,2300,true);
 ck(a.pauses==0&&a.losses==0,"stale OCR cannot alter state");
 a.read(banner,900,1200,true);ck(a.pauses==0,"pre-dispatch frame rejected");
 a.fence=null;a.read(banner,1500,1650,true);ck(a.pauses==0,"missing dispatch proof rejected");
 a=new BannerHarness();a.read("Deliveries Offers",1100,1200,true);TapAccessibilityService.gen=2;
 a.read(banner,1500,1650,true);ck(a.pauses==0,"changed UI rejected");TapAccessibilityService.gen=1;
 a.postClaimIsolationActive=true;a.read(banner,1500,1650,true);ck(a.pauses==0,"confirmed success wins");
 a=new BannerHarness();a.read("Begin Delivery Delivery Timeline MENDO_46474511540436997",1500,1650,false);
 ck(a.successes==1&&a.losses==0,"existing successful job flow preserved");
 a=new BannerHarness();a.read("Deliveries Offers",1100,1200,true);a.read(banner,1500,1650,true);
 a.serialTopAction=SerialAction.NONE;a.postTerminalVerifyActionAt=1000;a.postTerminalVerifyOfferText="offer A";a.postTerminalVerifyUntil=9000;
 a.read(banner,2100,2250,false);
 ck(a.visualBoundOutcome(1000).equals(hint)&&a.losses==0&&a.pauses==1,"late UNKNOWN correction publishes proof only, no click/navigation");
 a=new BannerHarness();a.read("Deliveries Offers",1100,1200,true);a.read(banner,1500,1650,true);
 a.serialTopAction=SerialAction.NONE;a.postTerminalVerifyActionAt=1000;a.postTerminalVerifyOfferText="offer A";a.postTerminalVerifyUntil=9000;a.lastActionDispatchAt=2000;
 a.read(banner,2100,2250,false);ck(a.visualBoundOutcome(1000).isEmpty(),"new action stops old negative publication");
 a=new BannerHarness();TapAccessibilityService.foreground=false;a.read(banner,1700,1800,true);ck(a.pauses==0,"foreign app rejected");
 System.out.println(count+" production terminal banner cases passed");
 }
}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'BannerHarness.java';p.write_text(header+methods+tests)
 names=['ClaimVisualProbePolicy.java','ClaimSuccessSignals.java','AcceptOutcomeFence.java','OfferEnrichmentPolicy.java','CardText.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*map(lambda f:str(src/f),names),str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.BannerHarness'],check=True)
