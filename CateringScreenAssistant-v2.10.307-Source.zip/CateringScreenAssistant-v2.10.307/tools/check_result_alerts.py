#!/usr/bin/env python3
"""Run production alert identity, sound/vibration selection and stop/override lifecycle."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'ClaimSuccessAlert.java').read_text()
def block(sig):
 a=s.index(sig);i=s.index('{',a)+1;n=1
 while n:n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
fields=s[s.index('    static final String ACTION_STOP'):s.index('    private ClaimSuccessAlert()')]
head='''package com.local.cateringscreenassistant;
import java.util.*;
class Uri {int type;Uri(int t){type=t;}}
class AudioAttributes {static final int USAGE_ALARM=4,USAGE_NOTIFICATION=5,CONTENT_TYPE_SONIFICATION=6;int usage;
 static class Builder {AudioAttributes a=new AudioAttributes();Builder setUsage(int u){a.usage=u;return this;}Builder setContentType(int c){return this;}AudioAttributes build(){return a;}}}
class Ringtone {boolean playing,loop;AudioAttributes attrs;void setAudioAttributes(AudioAttributes a){attrs=a;}void setLooping(boolean b){loop=b;}void play(){playing=true;}void stop(){playing=false;}}
class RingtoneManager {static final int TYPE_ALARM=1,TYPE_NOTIFICATION=2;static boolean noNotification;static Uri last;
 static Uri getDefaultUri(int t){return t==TYPE_NOTIFICATION&&noNotification?null:new Uri(t);}
 static Ringtone getRingtone(Context c,Uri u){last=u;return new Ringtone();}}
class VibrationEffect {long[] pattern;static VibrationEffect createWaveform(long[] p,int n){VibrationEffect e=new VibrationEffect();e.pattern=p;return e;}}
class Vibrator {long[] last;boolean canceled;boolean hasVibrator(){return true;}void cancel(){canceled=true;}void vibrate(VibrationEffect e){last=e.pattern;canceled=false;}void vibrate(long[] p,int n){last=p;canceled=false;}}
class NotificationManager {List<Integer> canceled=new ArrayList<>();void cancel(int id){canceled.add(id);}}
class Context {static final String NOTIFICATION_SERVICE="notification",VIBRATOR_SERVICE="vibrator";Vibrator vibrator=new Vibrator();NotificationManager notifications=new NotificationManager();Context getApplicationContext(){return this;}Object getSystemService(String k){return k.equals(NOTIFICATION_SERVICE)?notifications:vibrator;}}
class Looper {static Looper getMainLooper(){return new Looper();}}
class Handler {Runnable callback;long deadline;Handler(Looper l){}void removeCallbacksAndMessages(Object o){callback=null;}void postAtTime(Runnable r,Object o,long at){callback=r;deadline=at;}}
class SystemClock {static long elapsedRealtime(){return 1000;}static long uptimeMillis(){return 1000;}}
class Build {static class VERSION {static int SDK_INT=35;}static class VERSION_CODES {static final int O=26,P=28;}}
public class AlertHarness {
'''
methods='\n'.join(block(x) for x in ['    static synchronized boolean shouldSend(', '    private static String alertIdentity(', '    static void stop(', '    private static void startAlarm('])
tests=''' static int checks;static void ck(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
 String a="$30–40 1.9 mi Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101";
 String b="$30–40 1.9 mi Tomorrow at 10:20 AM Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101";
 ck(alertIdentity(false,100,a).equals(alertIdentity(false,100,b)),"pickup enrichment cannot duplicate one TX alert");
 ck(!alertIdentity(false,100,a).equals(alertIdentity(false,101,a)),"new push TX remains independently alertable");
 ck(!alertIdentity(false,100,a).equals(alertIdentity(true,100,a)),"later confirmed success is not suppressed by verification");
 ck(shouldSend(alertIdentity(false,100,a),1000),"first verification emits");
 ck(!shouldSend(alertIdentity(false,100,b),1100),"same TX enriched verification deduplicates");
 ck(shouldSend(alertIdentity(true,100,b),1101),"confirmation still emits after verification");
 Context c=new Context();startAlarm(c,1,VERIFY_ALARM_DURATION_MS,false);
 ck(RingtoneManager.last.type==RingtoneManager.TYPE_NOTIFICATION&&!activeTone.loop,"unconfirmed result uses short notification sound, never alarm loop");
 ck(activeTone.attrs.usage==AudioAttributes.USAGE_NOTIFICATION&&Arrays.equals(c.vibrator.last,new long[]{0,100}),"unconfirmed audio usage and vibration distinct from success");
 ck(MAIN.deadline==2000,"verification cue deadline one second");
 Ringtone verify=activeTone;startAlarm(c,2,SUCCESS_ALARM_DURATION_MS,true);
 ck(!verify.playing&&activeTone.playing&&activeTone.loop&&activeConfirmed,"confirmed success upgrades and replaces verification");
 ck(RingtoneManager.last.type==RingtoneManager.TYPE_ALARM&&activeTone.attrs.usage==AudioAttributes.USAGE_ALARM,"only confirmed success uses alarm stream");
 ck(Arrays.equals(c.vibrator.last,VIBRATION)&&MAIN.deadline==9000,"success retains long vibration and eight second alarm");
 Ringtone confirmed=activeTone;startAlarm(c,3,VERIFY_ALARM_DURATION_MS,false);
 ck(activeTone==confirmed&&confirmed.playing&&activeNotificationId==2,"later ambiguous reply cannot silence success alarm");
 stop(c);ck(!confirmed.playing&&activeTone==null&&!activeConfirmed&&MAIN.callback==null,"stop releases tone, vibration and timeout state");
 RingtoneManager.noNotification=true;startAlarm(c,4,VERIFY_ALARM_DURATION_MS,false);
 ck(activeTone==null&&!activeConfirmed&&Arrays.equals(c.vibrator.last,VERIFY_VIBRATION),"missing notification sound stays vibration-only, never falls back to alarm");
 stop(c);System.out.println(checks+" production result alert identity/sound/lifecycle cases passed");
 }}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'AlertHarness.java';p.write_text(head+fields+methods+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'CardText.java'),str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.AlertHarness'],check=True)
ocr=(src/'OcrMonitorService.java').read_text()
assert 'notifyVerificationRequired(this, originalText, terminalEvidence, finishedActionAt)' in ocr
assert 'notifyConfirmed(this, originalText, evidence, serialTopActionAt)' in ocr
assert 'notifyConfirmed(this, originalText, evidence, confirmedOwner)' in ocr
assert '待核对（未确认接单）' in s
print('All production alert callers carry the frozen transaction owner')
