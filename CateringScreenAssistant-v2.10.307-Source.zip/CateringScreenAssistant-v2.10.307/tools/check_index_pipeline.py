#!/usr/bin/env python3
"""v300 speed-first migrated legacy index assertions: live production methods and deterministic Android reads."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant';source=(src/'TapAccessibilityService.java').read_text()
def block(signature):
 a=source.index(signature);b=source.index('{',a);d=1;i=b+1
 while d:
  d+=(source[i]=='{')-(source[i]=='}');i+=1
 return source[a:i]
header=r'''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;import java.util.function.*;import java.util.regex.*;
class SystemClock {static volatile long now=1000;static long elapsedRealtime(){return now;}static long uptimeMillis(){return now;}static synchronized void advance(long ms){now+=ms;}}
class Rect {int left,top,right,bottom;Rect(){}Rect(int a,int b,int c,int d){left=a;top=b;right=c;bottom=d;}Rect(Rect r){set(r);}
 void setEmpty(){left=top=right=bottom=0;}void set(Rect r){left=r.left;top=r.top;right=r.right;bottom=r.bottom;}boolean isEmpty(){return right<=left||bottom<=top;}int centerX(){return (left+right)/2;}int centerY(){return (top+bottom)/2;}boolean contains(int x,int y){return x>=left&&x<right&&y>=top&&y<bottom;}}
class AccessibilityNodeInfo {static final int ACTION_CLICK=16;boolean performAction(int action){TapAccessibilityService.semanticRejectClicks++;return true;}String text="",desc="",pkg="com.deliverthat.driver";boolean enabled=true,actionable=true;int windowId=1;Rect bounds;List<AccessibilityNodeInfo> kids=new ArrayList<>();
 CountDownLatch textRead;int textReads,descriptionReads,boundsReads;AccessibilityNodeInfo parent;AccessibilityNodeInfo getParent(){return parent;}AccessibilityNodeInfo(String t,Rect b){text=t;bounds=b;}CharSequence getText(){textReads++;if(textRead!=null)textRead.countDown();return text;}CharSequence getContentDescription(){descriptionReads++;return desc;}CharSequence getPackageName(){return pkg;}
 static AccessibilityNodeInfo obtain(AccessibilityNodeInfo n){return n;}boolean visible=true;boolean isEnabled(){return enabled;}boolean isVisibleToUser(){return visible;}boolean refreshOK=true,mutateOnRefresh,stopOnRefresh,windowOnRefresh;CountDownLatch gate,entered;int refreshCalls;long refreshCost=1;Runnable refreshHook;boolean refresh(){refreshCalls++;if(refreshHook!=null)refreshHook.run();if(entered!=null)entered.countDown();if(gate!=null)try{gate.await();}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}SystemClock.advance(refreshCost);if(stopOnRefresh)OcrMonitorService.monitoring=false;if(windowOnRefresh)TapAccessibilityService.WINDOW_TRANSITION_EPOCH.incrementAndGet();if(mutateOnRefresh){TapAccessibilityService.UI_GENERATION.incrementAndGet();mutateOnRefresh=false;}return refreshOK;}
 void getBoundsInScreen(Rect b){boundsReads++;if(this==TapAccessibilityService.INSTANCE.get().root)TapAccessibilityService.boundReads++;b.set(bounds);}int getWindowId(){return windowId;}void recycle(){}
 final List<String> queryLog=TapAccessibilityService.queries;
 List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String q){queryLog.add(q);
 if(TapAccessibilityService.queryGate!=null && TapAccessibilityService.gatedQueries.contains(q)) {
  TapAccessibilityService.queryEntered.countDown();
  try{if(!TapAccessibilityService.queryGate.await(2,TimeUnit.SECONDS))throw new IllegalStateException("query coordination");}
  catch(InterruptedException e){Thread.currentThread().interrupt();throw new IllegalStateException(e);}
 }
 SystemClock.advance(2);if(TapAccessibilityService.mutateIndex||TapAccessibilityService.outcomeMutations>0){if(TapAccessibilityService.outcomeMutations>0)TapAccessibilityService.outcomeMutations--;TapAccessibilityService.UI_GENERATION.incrementAndGet();TapAccessibilityService.mutateIndex=false;}
 List<AccessibilityNodeInfo> out=new ArrayList<>();for(AccessibilityNodeInfo n:kids)if((n.text+" "+n.desc).toLowerCase(Locale.US).contains(q.toLowerCase(Locale.US)))out.add(n);return out;}}
class OcrMonitorService {static void noteReplayDiscovery(long at,String stage){}static Handler proof=new Handler(),clicks=new Handler();
 static Handler acceptRenewalHandler(){return proof;}static Handler acceptCallbackHandler(){return clicks;}
 static boolean rejectNumbers;static boolean eventNumbersUniversallyRejected(float amount,float miles){return rejectNumbers && amount>=0 && amount<50;}static int indexedRootWakes;static void requestImmediateFastCheck(long at,boolean structural){if(structural)indexedRootWakes++;}static TapAccessibilityService.FastOfferSnapshot pressureSnapshot;static TapAccessibilityService.FastOfferSnapshot acceptPressureSnapshotForBinding(){return pressureSnapshot;}static List<TapAccessibilityService.FastOfferSnapshot> boundSnapshots=new ArrayList<>();static void bindAcceptPressureSnapshot(TapAccessibilityService.FastOfferSnapshot f){boundSnapshots.add(f);}static boolean pressureActive;static String pressureGuard="";static boolean acceptPressureActive(long at){return pressureActive && (pendingAction==0 || pendingAction==at);}static String acceptLoadingRetryBlock(long at){return "";}static boolean canReadAcceptRecoveryProof(long owner){return true;}static String acceptPressureGuard(long at){return !retryGuard.isEmpty()?retryGuard:pressureGuard;}static volatile boolean monitoring=true;static List<String> controlModes=new ArrayList<>();static void onAcceptControlObserved(long at,String mode,long elapsed){controlModes.add(mode);}static String firstAcceptCardGuard(String t){return cardGuard;}static String cardGuard="";static boolean isMonitoring(){return monitoring;}static long pendingAction;static long pendingClaimSince(){return pendingAction;}static String pendingText="";static String pendingClaimText(long at){return pendingText;}static String retryGuard="";static String acceptRetryGuard(long at){return retryGuard;}static boolean hasBoundAcceptSuccess(){return false;}static boolean isManualInterventionPaused(){return false;}static void prepareAcceptPageBaseline(PageOutcomePolicy.Baseline b){}static long sentAt;static long acceptDispatchObservedAt(){return sentAt;}}
class Log {static void d(String a,String b){}}
class Handler {List<Runnable> pending=new ArrayList<>();void postAtFrontOfQueue(Runnable r){pending.add(0,r);}void postDelayed(Runnable r,long ms){pending.add(r);}void post(Runnable r){r.run();}}
 public class TapAccessibilityService {
 static int semanticRejectClicks;
 static PageGuard.Page recentPageHint(){return page;}
 static boolean largeOrderPopupRecentlyVisible(long maxAge){return false;}
 static final ThreadLocal<RejectReadProgress> REJECT_READ_PROGRESS=new ThreadLocal<>();
 static final ThreadLocal<AccessibilityNodeInfo> REJECT_READ_ROOT=new ThreadLocal<>();
 Handler main=new Handler();ThreadPoolExecutor rootReadAhead;Handler controlWatchWorker;volatile AcceptControlWatch activeControlWatch;
 static final AtomicReference<AcceptControlWatch> WATCH_CANDIDATE=new AtomicReference<>();
 static FutureTask<String> indexedRootPending;static TapAccessibilityService indexedRootPendingOwner;static boolean wakeWhenIndexedRootReady;static long indexedRootPendingGeneration,indexedRootPendingEpoch,indexedRootPendingAt;
 static final ThreadLocal<String> ROOT_READ_TRACE=ThreadLocal.withInitial(()->"COLD");
 static final Object INDEX_ROOT_LOCK=new Object();static AccessibilityNodeInfo indexedRootReceipt;static TapAccessibilityService indexedRootOwner;static long indexedRootAt,indexedRootGeneration,indexedRootEpoch,indexedRootQueueMs,indexedRootBinderMs;
 static final AtomicReference<PageRetryReceipt> PAGE_RETRY_RECEIPT=new AtomicReference<>();
 final BoundedReadBatch witnessReadBatch=new BoundedReadBatch(4),firstShotIndexBatch=new BoundedReadBatch(4),ownedResumeReadBatch=new BoundedReadBatch(4),outcomePageReadBatch=new BoundedReadBatch(4),outcomeDeadlineReads=new BoundedReadBatch(1),successDeadlineReads=new BoundedReadBatch(1);static String lastUiMutationTrace="test-event";static String foregroundPackage="com.deliverthat.driver";
 static final ThreadLocal<RejectedIndexObservation> REJECTED_SELF_INDEX=new ThreadLocal<>();
 static final ThreadLocal<String> ACCEPT_INDEX_FAILURE=ThreadLocal.withInitial(()->"NOT_READ");
 static final ThreadLocal<String> RETRY_WITNESS_FAILURE=ThreadLocal.withInitial(()->"NONE");
 static final ThreadLocal<String> RETRY_WITNESS_DETAIL=ThreadLocal.withInitial(()->"NONE");
 static final ThreadLocal<String> RETRY_TREE_FAILURE=ThreadLocal.withInitial(()->"NOT_USED");
 static final AtomicReference<IndexedWitness> LAST_INDEXED_WITNESS=new AtomicReference<>();
 static final ThreadLocal<String> OWNED_NODE_REFRESH_DETAIL=ThreadLocal.withInitial(() -> "NOT_READ");
 static final ThreadLocal<Boolean> OWNED_NODE_PROCESSING=ThreadLocal.withInitial(() -> false);
 static final AtomicReference<ResumeNodeReceipt> RESUME_NODES=new AtomicReference<>();
 static PageOutcomePolicy.SurfaceGate CURRENT_SURFACE_GATE=new PageOutcomePolicy.SurfaceGate();
 static final AtomicLong WINDOW_TRANSITION_EPOCH=new AtomicLong();
 static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>();static AtomicLong UI_GENERATION=new AtomicLong(1),PRESSURE_LAYOUT_EPOCH=new AtomicLong();
 static final Pattern LIVE_MONEY_RANGE=Pattern.compile("(?:\\$|USD)(\\d+(?:\\.\\d+)?)\\s*[-–—]\\s*\\$?(\\d+(?:\\.\\d+)?)");
 static final Pattern LIVE_MONEY=Pattern.compile("(?:\\$|USD)(\\d+(?:\\.\\d+)?)");static final Pattern LIVE_MILES=Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*mi\\b");
 static final Pattern LIVE_CA_ZIP=Pattern.compile("CA [0-9]{5}");
 static final Pattern LIVE_OFFER_TIME=Pattern.compile("(?:Tomorrow|Today) at \\d+:\\d+ [AP]M");
 static final ConcurrentHashMap<String,Long> FIRST_SEEN_AT=new ConcurrentHashMap<>();static final long FIRST_SEEN_ROLLOVER_MS=8000;
 static long firstSeenNumericKey,acceptAnchorNumericKey;static long firstSeenNumericAt,firstSeenNumericLastAt,acceptAnchorFirstAt,acceptAnchorLastAt;
 static String routedReject="";static void cacheDecisionEvidence(String t,long g){routedReject=t;}
 static class DecisionEvidence {String identity,text="";float amount,miles;long capturedAt;}
 static DecisionEvidence recentEventBurstDecisionEvidence(long age){return null;}
 AccessibilityNodeInfo root;static int resolveCalls;static int rootReads,boundReads,dispatch,refresh;static Runnable pressureFinalHook;static int outcomeMutations;static boolean mutateIndex,witnessOpenAtDispatch,throwDispatch,finalRetryChurn,finalRetryNegative,finalRetryWindow;static List<String> queries=Collections.synchronizedList(new ArrayList<>());
 static CountDownLatch queryGate,queryEntered;static Set<String> gatedQueries=Set.of();static PageGuard.Page page=PageGuard.Page.UNKNOWN;static FastOfferSnapshot refreshResult;
 static QuickTopResult retryTree;static Runnable treeHook;static int treeReads;
 static QuickTopResult getQuickTopOfferSnapshotResult(long ms,int nodes){if(ms!=45||nodes!=96)throw new AssertionError("retry tree must stay bounded");treeReads++;if(treeHook!=null)treeHook.run();return retryTree;}
 static CountDownLatch rootGate,rootEntered;
 static final AtomicReference<AcceptPageObservation> LAST_ACCEPT_PAGE=new AtomicReference<>();
 AccessibilityNodeInfo getRootInActiveWindow(){rootReads++;if(rootEntered!=null)rootEntered.countDown();if(rootGate!=null)try{rootGate.await();}catch(InterruptedException e){Thread.currentThread().interrupt();throw new IllegalStateException(e);}return root;}
 static AccessibilityNodeInfo resolveIndexedAction(AccessibilityNodeInfo n,Rect r,boolean a){resolveCalls++;return n.parent==null?n:n.parent;}
 static boolean safeActionBounds(Rect r,Rect b,boolean a){return !b.isEmpty()&&b.right<=r.right&&(a?b.left>r.right/2:b.right<r.right/2);}
 static boolean nodeIsActionable(AccessibilityNodeInfo n){return n.actionable;}
 static int actionReadyReads;
 static boolean actionNodeReady(AccessibilityNodeInfo n){actionReadyReads++;for(int d=0;n!=null&&d<6;d++,n=n.parent)if(n.enabled&&n.actionable)return true;return false;}
 static void addUniquePiece(List<CardText.Piece> p,String text,Rect b){p.add(new CardText.Piece(text,b.left,b.top,b.bottom));}

 static boolean isPositiveClaimOutcome(String s){return false;}static String recentCachedClaimOutcomeSince(long n){return "";}static PageGuard.Page quickPageOf(AccessibilityNodeInfo r,int n){return page;}
 static FastOfferSnapshot quickRefreshTopAction(TapAccessibilityService s,float a,float m,boolean v){return refreshResult;}
 static FastOfferSnapshot getIndexedNumericTopAcceptSnapshot(float a,float m){refresh++;return refreshResult;}
 static boolean isDeliverThatForeground(){return true;}
 static void dispatchActionGesture(TapAccessibilityService s,Rect b,boolean a,long ms,int variant,Consumer<String> ok,Consumer<String> fail){dispatch++;ok.accept("sent");}
 static boolean dispatchVerifiedSnapshotGesture(TapAccessibilityService s,Rect b,Rect r,boolean a,long ms,int v,boolean bindForPressure,Consumer<String> ok,Consumer<String> fail,BooleanSupplier fresh){if(!bindForPressure)throw new AssertionError("first tap must bind the verified CTA");int before=dispatch;dispatchVerifiedSnapshotGesture(s,b,r,a,ms,v,ok,fail,fresh);return dispatch!=before;}
 static void dispatchVerifiedSnapshotGesture(TapAccessibilityService s,Rect b,Rect r,boolean a,long ms,int variant,Consumer<String> ok,Consumer<String> fail,BooleanSupplier fresh){if(pressureFinalHook!=null){Runnable hook=pressureFinalHook;pressureFinalHook=null;hook.run();}if(finalRetryChurn)UI_GENERATION.incrementAndGet();if(finalRetryWindow)WINDOW_TRANSITION_EPOCH.incrementAndGet();if(finalRetryNegative)OcrMonitorService.retryGuard="RETRY_NEGATIVE_PENDING";if(!fresh.getAsBoolean()){fail.accept("RETRY_PROOF_EXPIRED");return;}dispatchVerifiedSnapshotGesture(s,b,r,a,ms,variant,ok,fail);}
 static void dispatchVerifiedSnapshotGesture(TapAccessibilityService s,Rect b,Rect r,boolean a,long ms,int variant,Consumer<String> ok,Consumer<String> fail){witnessOpenAtDispatch=hasFreshIndexedWitness();if(throwDispatch)throw new IllegalStateException("dispatch test");dispatch++;OcrMonitorService.sentAt=SystemClock.now;ok.accept("sent");}
'''
methods=['    private static AccessibilityNodeInfo resolveIndexedRejectAction(', '    private static AccessibilityNodeInfo resolveIndexedRejectParent(', '    private static boolean attachRejectProof(', '    private static boolean boundRejectContextCurrent(', '    private static FastOfferSnapshot boundIndexedReject(', '    private static void dispatchBoundReject(', '    private static FastOfferSnapshot currentPressureRenewalSnapshot(', '    private static String ownedResumeReceiptState(', '    private static final class AcceptPageObservation {','    private static void renewPressureRetry(', '    private static void tapPressureRetryPrepared(', '    private static boolean samePressureGeometry(', '    private static FastOfferSnapshot refreshCurrentOwnedAcceptNodes(String expected,long owner,boolean pressureRenewal)', '    private static boolean ownedResumeReceiptCurrent(', '    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryPairOnBatch(', '    public static String ownedAcceptNodeRefreshDetail()', '    public static boolean ownedAcceptNodeProcessingObserved()', '    private static final class ResumeNodeReceipt {', '    private static void clearAcceptResumeNodes()', '    private static void rememberAcceptResumeNodes(', '    public static FastOfferSnapshot refreshCurrentOwnedAcceptNodes(', '    private static final class IndexedSeedValue {', '    private static void collectCapturedIndexedEndpointPieces(', '    private static boolean hasAsciiDigit(', '    private static void appendIndexedEndpointPiece(', '    private static String pressureStopReason(', '    public static FastOfferSnapshot observeCurrentOwnedAcceptSnapshot(', '    public static void tapPressureRetry(', '    public static boolean isCurrentPressureResumeSnapshot(', '    static String pressureResumeProofBlock(', '    private static final class RejectedIndexObservation', '    public static FastOfferSnapshot takeRejectedSelfIndexObservation()', '    private static AccessibilityNodeInfo rootForRejectRead(', '    private static long rejectReadDeadline(', '    private static FastOfferSnapshot failRejectRead(', '    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryGroupWithBudget(', '    private String rebindAcceptControl(', '    private static java.util.concurrent.FutureTask<String> prefetchIndexedRoot(', '    private static final class AcceptControlWatch implements AutoCloseable {', '    private static void rememberAcceptControl(', '    public static void startAcceptControlWatch(', '    private void pollAcceptControl(', '    private static AccessibilityNodeInfo recentIndexedRoot(', '    private static AccessibilityNodeInfo readCurrentIndexedRoot(', '    private static AccessibilityNodeInfo readCurrentIndexedRoot(\n', '    private static void clearIndexedRootReceipt(', '    private static BoundedReadBatch.Pending<IndexedQueryResult> readIndexedActionAndNumbers(', '    private static final class PageRetryReceipt {', '    private static void clearPageRetryReceipt(', '    private static boolean freshPageRetrySnapshot(', '    public static FastOfferSnapshot takeAcceptPageRetrySnapshot(', '    public static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(\n            boolean requireLocation, boolean requireOfferTime, long softBudgetMs,', '    public static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(\n            boolean requireLocation, boolean requireOfferTime, long softBudgetMs,\n            java.util.function.BiPredicate<Float, Float> numericReject, StringBuilder phases)', '    private static final class IndexedQueryResult ', '    private static final class IndexedQueryRead ', '    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryPair(', '    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryPairWithBudget(', '    private static void collectIndexedNumericNodes(', '    private static boolean noHigherIndexedOfferAction(', '    private static void collectIndexedRejectBoundary(', '    private static void collectIndexedConfiguredCityPieces(', '    private static FastOfferSnapshot getIndexedNumericTopActionSnapshot(float expectedAmount,\n                                                                         float expectedMiles,\n                                                                         boolean accept,\n                                                                         boolean requirePasadena,\n', '    public static final class QuickTopResult {', '    private static FastOfferSnapshot readRetryQuickTreeSnapshot(', '    private static boolean canReuseRetryIndex(', '    private static String witnessReadFailure(', '    private static FastOfferSnapshot failAcceptIndex(', '    private static String acceptIndexFailure(', '    private static String retryWitnessFailure(', '    private static boolean hardRetryWitnessFailure(', '    private static FastOfferSnapshot refreshRetryWitnessSnapshot(', '    private static void dispatchRetryFromCurrentProof(', '    private static void collectIndexedOfferTimePieces(AccessibilityNodeInfo root,',
'    private static void collectIndexedOfferTimePieces(AccessibilityNodeInfo root,\n            Rect actionBounds,List<CardText.Piece> pieces,IndexedWitness witness)',
'    private static void collectIndexedLocationPieces(AccessibilityNodeInfo root, Rect actionBounds,',
'    private static void collectIndexedLocationPieces(AccessibilityNodeInfo root,Rect actionBounds,',
'    public static boolean currentNegativeSurfaceBlocksAccept()', '    static boolean hasCurrentNegativeBaseline(', '    public static void tapSnapshotRetryDetailed(', '    private static String pageNegativeHint(', '    public static PageOutcomePolicy.Reading sampleAcceptPageOutcome(','    private static PageOutcomePolicy.Reading readAcceptPageOutcome(', '    private static boolean pageHasSeparateNumericRows(', '    private static boolean matchesAccept(', '    private static String lettersOnlyLower(', '    private static boolean isAcceptLabel(', '    private static final class WitnessNodeValue {', '    private static final class WitnessNodeRead implements BoundedReadBatch.Read<WitnessNodeValue> {', '    private static boolean hasFreshIndexedWitness()', '    private static final class IndexedWitness {','    private static final class IndexedReadProof {','    public static final class FastOfferSnapshot {','    private static void recordNumericFirstSeen(DecisionEvidence candidate)',
'    private static void recordNumericFirstSeen(String identity,','    private static void noteAcceptAnchor(float amount,',
'    private static void collectIndexedEndpointPieces(', '    private static void collectIndexedEndpointPieces(List<AccessibilityNodeInfo> indexed,\n            Rect actionBounds,List<CardText.Piece> pieces,IndexedWitness witness,int windowId,java.util.Set<String> seen)', '    private static void collectIndexedOfferNumbers(', '    private static void collectIndexedOfferNumbers(AccessibilityNodeInfo root, Rect actionBounds,\n            List<CardText.Piece> pieces, IndexedWitness witness)',
'    private static void collectIndexedNumericPieces(AccessibilityNodeInfo root, String[] queries,\n                                                     Rect actionBounds,',
'    private static void collectIndexedNumericPieces(AccessibilityNodeInfo root, String[] queries,\n            Rect actionBounds, List<CardText.Piece> pieces, IndexedWitness witness)', '    private static boolean quickNumericPairMatches(',
'    public static FastOfferSnapshot observeCurrentTopAcceptSnapshot()', '    private static FastOfferSnapshot readIndexedCurrentTopAcceptSnapshot(', '    public static FastOfferSnapshot getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(', '    public static void tapSnapshotFastDetailed(']
# Only replace android Log in the harness, not production sources.
body='\n'.join(block(m) for m in methods).replace('android.util.Log.d','Log.d')
test=r'''
 static int checks;static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 static void drainPressure(){for(int n=0;n<20;n++){
  if(!OcrMonitorService.proof.pending.isEmpty())OcrMonitorService.proof.pending.remove(0).run();
  if(!OcrMonitorService.clicks.pending.isEmpty())OcrMonitorService.clicks.pending.remove(0).run();
  if(OcrMonitorService.proof.pending.isEmpty()&&OcrMonitorService.clicks.pending.isEmpty())return;
 }throw new AssertionError("renewal loop did not quiesce");}
 static Rect button=new Rect(689,1094,840,1151);static String last;
 static TapAccessibilityService setup(){OcrMonitorService.proof=new Handler();OcrMonitorService.clicks=new Handler();pressureFinalHook=null;clearAcceptResumeNodes();rootGate=rootEntered=null;clearIndexedRootReceipt();TapAccessibilityService old=INSTANCE.get();if(old!=null){old.firstShotIndexBatch.close();old.witnessReadBatch.close();old.ownedResumeReadBatch.close();old.outcomePageReadBatch.close();old.outcomeDeadlineReads.close();old.successDeadlineReads.close();if(old.rootReadAhead!=null)old.rootReadAhead.shutdownNow();}IndexedWitness prior=LAST_INDEXED_WITNESS.getAndSet(null);if(prior!=null)prior.close();TapAccessibilityService s=new TapAccessibilityService();s.firstShotIndexBatch.warmUp();s.witnessReadBatch.warmUp();s.ownedResumeReadBatch.warmUp();s.outcomePageReadBatch.warmUp();CURRENT_SURFACE_GATE=new PageOutcomePolicy.SurfaceGate();INSTANCE.set(s);OcrMonitorService.rejectNumbers=false;routedReject="";OcrMonitorService.monitoring=true;WINDOW_TRANSITION_EPOCH.set(0);queries=Collections.synchronizedList(new ArrayList<>());s.root=new AccessibilityNodeInfo("",new Rect(0,0,1080,2400));
 s.root.kids.add(new AccessibilityNodeInfo("Accept",button));s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));
 s.root.kids.add(new AccessibilityNodeInfo("0.2 mi",new Rect(410,850,580,900)));s.root.kids.add(new AccessibilityNodeInfo("Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA",new Rect(80,940,900,1000)));
 AcceptControlWatch priorControl=WATCH_CANDIDATE.getAndSet(null);if(priorControl!=null)priorControl.close();OcrMonitorService.controlModes.clear();queryGate=queryEntered=null;gatedQueries=Set.of();rootReads=boundReads=dispatch=refresh=resolveCalls=0;treeReads=0;retryTree=null;treeHook=null;witnessOpenAtDispatch=throwDispatch=finalRetryChurn=finalRetryNegative=finalRetryWindow=false;OcrMonitorService.retryGuard="";OcrMonitorService.cardGuard="";queries.clear();mutateIndex=false;outcomeMutations=0;page=PageGuard.Page.UNKNOWN;SystemClock.now=1000;UI_GENERATION.set(1);PRESSURE_LAYOUT_EPOCH.set(0);FIRST_SEEN_AT.clear();firstSeenNumericAt=firstSeenNumericLastAt=acceptAnchorFirstAt=acceptAnchorLastAt=0;firstSeenNumericKey=acceptAnchorNumericKey=0;OcrMonitorService.indexedRootWakes=0;refreshResult=null;PAGE_RETRY_RECEIPT.set(null);OcrMonitorService.boundSnapshots.clear();OcrMonitorService.pressureSnapshot=null;OcrMonitorService.pendingAction=0;OcrMonitorService.pendingText="";OcrMonitorService.sentAt=0;foregroundPackage="com.deliverthat.driver";return s;}
 static FastOfferSnapshot read(){return getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,false);}
 static void tap(FastOfferSnapshot s){tapSnapshotFastDetailed(s,s.amount,s.miles,m->last=m,m->last=m);}
 static final String OWNED="$110.02 2.6 mi Today at 11:05 AM Mendocino Farms • 840 S Sepulveda Blvd, El Segundo, CA 90245";
 static void traceCard(TapAccessibilityService s,String text,int offset,boolean accept,boolean enabled) {
  s.root.kids.add(new AccessibilityNodeInfo(text,new Rect(80,700+offset,950,1050+offset)));
  s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(248,1159+offset,386,1227+offset)));
  if(accept){AccessibilityNodeInfo n=new AccessibilityNodeInfo("Accept",new Rect(689,1162+offset,840,1219+offset));n.enabled=enabled;s.root.kids.add(n);}
 }
 static TapAccessibilityService traceRows(int kind) {
  TapAccessibilityService s=setup();s.root.kids.clear();
  traceCard(s,"$19–29 4.8 mi Today at 10:50 AM Urbane Cafe • 4001 N Lakewood Blvd Suite 100, Long Beach, CA 90846",0,true,true);
  if(kind!=3) traceCard(s,OWNED,736,kind!=2,kind!=1);
  OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;OcrMonitorService.pendingText=OWNED;
  return s;
 }
 public static void main(String[] args) throws Exception {
 TapAccessibilityService s=setup();FastOfferSnapshot f;
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 10:55 AM",new Rect(80,910,900,935)));
 s.root.kids.get(1).text="Est. $26–36 0.2 mi Tomorrow at 10:55 AM";
 f=getIndexedCurrentTopRejectSnapshot(true,false,60L,(pay,mi)->pay<50);
 check(f!=null && f.amount==26f && f.miles==0.2f,"current range lower bound and enabled Reject proven");
 check(queries.equals(List.of("e")),"one semantic query reuses complete numeric/time fields and skips city: "+queries);
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 10:55 AM",new Rect(80,910,900,935)));
 mutateIndex=true;check(getIndexedCurrentTopRejectSnapshot(true,false,60L,(pay,mi)->true)==null,"UI mutation invalidates current Reject proof");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));s.root.kids.get(4).enabled=false;
 check(getIndexedCurrentTopRejectSnapshot(true,false,60L,(pay,mi)->true)==null,"disabled Reject cannot dispatch");
 s=setup();


 s=setup();s.root.kids.clear();
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("$29–39 4.1 mi",new Rect(80,850,500,900)));
 f=getIndexedCurrentTopRejectSnapshot(true,true,60L,(pay,mi)->pay<50);
 check(f!=null && f.amount==29f && queries.stream().noneMatch(q->q.equals("Today")||q.equals("Tomorrow")||q.equals("•")),"numeric-only must-reject avoids time/city queries");
 s=setup();s.root.kids.clear();
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("$69 4.1 mi",new Rect(80,850,500,900)));
 check(getIndexedCurrentTopRejectSnapshot(true,true,60L,(pay,mi)->false)==null,"possible special-city qualifier still needs complete decision identity");
 s=setup();
 for(Set<String> pair:List.of(Set.of("a","e"),Set.of("$","mi"),Set.of("a","e","$","mi"))) {
  setup();gatedQueries=pair;queryGate=new CountDownLatch(1);queryEntered=new CountDownLatch(pair.size());
  AtomicReference<FastOfferSnapshot> indexed=new AtomicReference<>();
  Thread queryReader=new Thread(()->indexed.set(read()));queryReader.start();
  try {
   boolean concurrent=queryEntered.await(2,TimeUnit.SECONDS);
   queryGate.countDown();queryReader.join(2000);
   check(concurrent && indexed.get()!=null,"independent index pair starts both reads before either returns "+pair);
   tap(indexed.get());check(dispatch==1,"parallel index receipt still reaches verified first tap "+pair);
  } catch(InterruptedException e){Thread.currentThread().interrupt();throw new AssertionError(e);}
  finally {queryGate.countDown();}
 }
 s=setup();

 check(!noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),1964),"last-window check catches upper Accept above tree/visual target");
 s.root.kids.get(0).enabled=false;
 check(!noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),1964),"disabled upper button remains final boundary");
 s.root.kids.get(0).text="Ignore";s.root.kids.get(0).bounds=new Rect(248,1094,386,1151);
 check(!noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),1964),"upper Ignore blocks tree/visual/OCR final path too");
 check(noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),1094),"same-row left control does not block current right CTA");
 s=setup();
 s.root.kids.add(new AccessibilityNodeInfo("$121.97 Est. 0.2 mi",new Rect(80,850,580,900)));
 f=read();check(f!=null && f.amount==121.97f && f.miles==.2f
         && Collections.frequency(queries,"$")<=1 && Collections.frequency(queries,"mi")<=1,
         "action-sufficient numeric discovery may cancel speculative queries but never repeats them: "+queries);
 tap(f);check(dispatch==1,"action-sufficient numeric evidence reaches guarded dispatch");
 s=setup(); // Neither action query can return these separate numeric labels.
 f=read();check(f!=null && f.amount==121.97f && f.miles==.2f
         && Collections.frequency(queries,"$")==1 && Collections.frequency(queries,"mi")==1,
         "required concurrent numeric discovery runs each query exactly once: "+queries);
 tap(f);check(dispatch==1,"reused live numeric fields reach guarded dispatch");
 s=setup();

 s.root.kids.clear();s.root.kids.add(new AccessibilityNodeInfo("Accept",button));
 s.root.kids.add(new AccessibilityNodeInfo("$28–38 3.4 mi Tomorrow at 6:00 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040",new Rect(80,850,900,1000)));
 f=getIndexedNumericTopActionSnapshot(28,3.4f,true,true,null,true);
 check(f!=null&&queries.equals(Arrays.asList("a","e")),"exact Pasadena reuses complete current action query without numeric/city/time IPC");
 check(f.pageOutcomeBaseline()!=null&&f.indexedRead.witness!=null,"exact path retains outcome baseline and current node witness");
 tap(f);check(dispatch==1,"exact receipt reaches guarded first dispatch");
 s=setup();s.root.kids.clear();s.root.kids.add(new AccessibilityNodeInfo("Accept",button));
 s.root.kids.add(new AccessibilityNodeInfo("$28–38 3.4 mi Tomorrow at 6:00 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040",new Rect(80,850,900,1000)));
 f=getIndexedNumericTopActionSnapshot(28,3.4f,true,true,null,true);UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&!last.contains("LIVE_NODE_RECHECK"),"speed-first exact branch dispatches cached CTA without extra IPC after generation churn");
 s=setup();s.root.kids.clear();s.root.kids.add(new AccessibilityNodeInfo("Accept",button));
 s.root.kids.add(new AccessibilityNodeInfo("$28–38 3.4 mi Tomorrow at 6:00 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040",new Rect(80,850,900,1000)));
 f=getIndexedNumericTopActionSnapshot(28,3.4f,true,true,null,true);
 s.root.kids.get(1).text=s.root.kids.get(1).text.replace("6:00 AM","7:00 AM");UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1,"speed-first intentionally accepts stale pickup risk rather than cancelling admitted first CTA");


 s=setup();s.root.kids.get(0).enabled=false;
 s.root.kids.add(new AccessibilityNodeInfo("Accept",new Rect(689,1964,840,2021)));
 f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);
 check(f==null,"disabled top Accept never skips to enabled lower CTA");
 s=setup();s.root.kids.get(0).text="";
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(248,1094,386,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("Accept",new Rect(689,1964,840,2021)));
 f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);
 check(f==null,"upper Ignore boundary blocks lower CTA borrowing original numbers");
 check(read()==null,"self index also retains upper Ignore boundary");
 s=setup();s.root.kids.get(0).text="";
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(248,1094,386,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("Accept",new Rect(689,1964,840,2021)));
 s.root.kids.add(new AccessibilityNodeInfo("$90.00 3 mi Tomorrow at 8:00 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040",new Rect(80,1500,900,1800)));
 check(getIndexedNumericTopActionSnapshot(90,3,true,true,null,false)==null,"even a complete lower offer cannot skip readable upper offer");
 s.root.kids.remove(4);f=getIndexedNumericTopActionSnapshot(90,3,true,true,null,false);
 check(f!=null&&f.amount==90,"genuine next offer is actionable immediately after upper row disappears");
 s=setup();f=read();OcrMonitorService.cardGuard="ACCEPT_REJECT_OWNED";tap(f);
 check(dispatch==0&&last.contains("ACCEPT_REJECT_OWNED"),"final indexed dispatch rejects newly acquired Reject owner");
 s=setup();f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);
 check(f!=null&&queries.contains("$121.97")&&queries.contains("0.2 mi"),"separate numeric nodes still use exact current lookups");
 s=setup();s.root.kids.get(3).text="$121.97 0.2 mi Tomorrow at 6:00 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";
 f=getIndexedNumericTopActionSnapshot(80,.2f,true,false,null,false);check(f==null,"reused fields cannot change expected amount");
 s=setup();s.root.kids.get(3).text="$121.97 0.2 mi Tomorrow at 6:00 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";
 f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,true,null,true);check(f==null,"non-Pasadena current city still fails special branch");
 s=setup();s.root.pkg="other.app";f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);check(f==null,"exact branch rejects foreign root");
 s=setup();s.root.kids.get(0).enabled=false;f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);check(f==null,"exact branch rejects disabled Accept");
 s=setup();mutateIndex=true;f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);check(f==null,"exact branch rejects index churn");
 s=setup();s.root.kids.get(2).text="0.2 mi 9.9 mi";f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);check(f==null,"exact branch rejects multiple mileage rows");
 s=setup();f=read();check(f!=null&&f.amount==121.97f&&f.miles==.2f,"self-index assembles current exact pair and action");
 s=setup();f=read();final java.util.concurrent.atomic.AtomicInteger lazyFormats=new java.util.concurrent.atomic.AtomicInteger();
 f.indexedRead.deferredStages=()->{check(dispatch==1,"diagnostic formatting must follow gesture dispatch");lazyFormats.incrementAndGet();return "LAZY_DIAGNOSTIC";};
 tap(f);check(lazyFormats.get()==1&&last.contains("LAZY_DIAGNOSTIC"),"successful callback renders deferred diagnostic once");
 s=setup();f=read();final java.util.concurrent.atomic.AtomicInteger blockedFormats=new java.util.concurrent.atomic.AtomicInteger();
 f.indexedRead.deferredStages=()->{blockedFormats.incrementAndGet();return "MUST_NOT_FORMAT";};s.root.pkg="other.app";foregroundPackage="other.app";
 tap(f);check(dispatch==0&&blockedFormats.get()==0,"blocked first tap does not pay diagnostic formatting cost");
 s=setup();f=read();

 check(f.text.contains("Luna Grill")&&!queries.contains("•"),"current action index supplies endpoint without another query");
 check(firstSeenNumericAt<=f.capturedAt&&acceptAnchorFirstAt<=firstSeenNumericAt,"first-seen timestamps retain actual numeric/action read instants");
 tap(f);check(dispatch==1&&rootReads==1&&boundReads==1&&last.contains("LIVE_WINDOW_BOUNDS_REUSED"),"fresh window receipt removes second root call without rebuilding geometry");
 check(IndexedReadPolicy.reuseWindow(1,1,1000,1080,true,true),"receipt exact 80ms bound");
 check(!IndexedReadPolicy.reuseWindow(1,1,1000,1081,true,true),"expired receipt cannot skip root");
 check(!IndexedReadPolicy.reuseWindow(1,2,1000,1001,true,true),"window transition invalidates receipt");
 check(!IndexedReadPolicy.reuseWindow(1,1,1000,1001,false,true),"unknown foreground retains root read");
 check(!IndexedReadPolicy.reuseWindow(1,1,1000,1001,true,false),"missing node provenance retains root read");
 check(!IndexedReadPolicy.reuseWindow(1,1,1000,999,true,true),"clock reversal rejects receipt");
 check(last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"receipt fast path has explicit diagnostic");
 s=setup();f=read();WINDOW_TRANSITION_EPOCH.incrementAndGet();tap(f);
 check(rootReads==1,"speed-first keeps indexed root bounds despite window epoch churn");
 s=setup();f=read();finalRetryWindow=true;tap(f);check(dispatch==1,"speed-first does not veto first gesture on window epoch churn");
 s=setup();f=read();finalRetryChurn=true;tap(f);check(dispatch==1,"speed-first does not veto first gesture on generation churn");
 s=setup();f=read();tap(f);
 check(last.contains("INDEX_READ_BEGIN→dispatch")&&last.contains("INDEX_PHASE"),"whole index start-to-dispatch and phase accounting survives");
 s=setup();s.root.kids.get(3).desc=s.root.kids.get(3).text;s.root.kids.get(3).text="";f=read();check(f!=null&&!queries.contains("•")&&f.text.contains("Luna Grill"),"description-only endpoint reuses current action query");
 s=setup();s.root.kids.get(3).text="Shop • 10 Elm St, ZZ 11111";f=read();check(f!=null&&!queries.contains("•"),"eligible general self-index avoids optional endpoint Binder fallback");
 s=setup();s.root.kids.get(3).bounds=new Rect(80,1200,900,1300);f=read();check(f!=null&&!f.text.contains("Luna Grill"),"endpoint below current action cannot be reused");
 s=setup();s.root.kids.get(3).text="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA $150.00 9.9 mi";f=read();check(f==null||!f.text.contains("$150.00"),"multiple route rows cannot supply reused endpoint evidence");
 s=setup();f=read().withDecisionText(read().text+" Tomorrow at 10:15 AM");tap(f);check(dispatch==1&&last.contains("LIVE_WINDOW_BOUNDS_REUSED"),"descriptive enrichment keeps originating proof");
 s=setup();f=read();SystemClock.now+=81;tap(f);check(dispatch==1&&boundReads==1&&last.contains("LIVE_WINDOW_BOUNDS_REUSED"),"aged indexed receipt reuses CTA/root without second Binder read");
 s=setup();f=read();s.root.pkg="other.app";foregroundPackage="other.app";tap(f);check(dispatch==0,"real foreground switch blocks even within receipt TTL");
 s=setup();f=read();UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"generation churn dispatches without node rebind");
 s=setup();f=read();f.indexedRead.witness.close();UI_GENERATION.incrementAndGet();refreshResult=new FastOfferSnapshot(f.text,button,new Rect(),true,false,SystemClock.now,f.amount,f.miles,new IndexedReadProof(s.root.bounds,1,2,1000,SystemClock.now,"fresh"));tap(f);
 check(dispatch==1&&refresh==0,"closed witness still uses admitted CTA for first gesture");
 s=setup();f=read();s.root.windowId=2;WINDOW_TRANSITION_EPOCH.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"speed-first accepts changed window identity within same foreground app");
 s=setup();s.root.kids.get(0).enabled=false;f=observeCurrentTopAcceptSnapshot();
 check(f!=null&&!f.acceptEnabled,"observation-only retry index retains disabled action and current fields");
 s=setup();s.root.kids.get(0).enabled=false;check(read()==null,"disabled current top cannot borrow another enabled state");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("This delivery conflicts with an existing job at 11:05 AM",new Rect(10,50,900,90)));
 PageOutcomePolicy.Reading conflictPage=sampleAcceptPageOutcome(()->true);check(conflictPage.complete&&ClaimSuccessSignals.isTimeConflict(conflictPage.hint)&&conflictPage.hint.contains("11:05 AM"),"bounded live page preserves conflict cause and original excerpt");
 s=setup();mutateIndex=true;check(read()!=null,"same-window generation churn retains first-shot receipt");
 s=setup();s.root.kids.get(1).text="$79.99";check(read()==null,"unqualified non-special General never passes numeric shortcut");
 s=setup();check(getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,false,false)==null,"city-filter mode cannot use General numeric shortcut");
 s=setup();check(getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true)==null,"time-filter mode still requires current pickup time");
 check(!IndexedReadPolicy.reuseBounds(1,1,1000,999,true)&&!IndexedReadPolicy.reuseBounds(1,2,1000,1001,true),"clock inversion and generation mismatch reject reuse");
 s=setup();f=read();long seen=firstSeenNumericAt;recordNumericFirstSeen(f.identity,f.amount,f.miles,seen-2);
 check(firstSeenNumericAt==seen-2&&firstSeenNumericLastAt==seen,"out-of-order event parsing cannot move first-seen later");

 s=setup();f=read();int indexCalls=queries.size();s.root.kids.get(1).text="$110.00";UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0&&queries.size()==indexCalls,"admitted coordinates dispatch despite changed pay after index");
 s=setup();f=read();s.root.kids.get(2).text="9.9 mi";UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"admitted coordinates dispatch despite later mileage text change");
 s=setup();f=read();s.root.kids.get(3).text="Other Cafe • 20 Main St, Irvine, CA 92618, USA";UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"admitted coordinates dispatch without re-proving changed endpoint");
 s=setup();f=read();s.root.kids.get(0).bounds=new Rect(689,1600,840,1657);UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"old CTA coordinates are dispatched even after layout churn by user preference");
 s=setup();f=read();s.root.kids.get(1).gate=new CountDownLatch(1);UI_GENERATION.incrementAndGet();tap(f);s.root.kids.get(1).gate.countDown();check(dispatch==1&&refresh==0,"slow refreshed node is not read at all on first CTA dispatch");
 s=setup();f=read();s.root.kids.get(1).refreshOK=false;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"detached RN nodes do not delay admitted first CTA");
 s=setup();f=read();IndexedWitness w=f.indexedRead.witness;check(w!=null&&s.main.pending.size()==1,"owned nodes have a bounded cleanup callback");
 s.main.pending.get(0).run();check(w.closed&&w.fields.isEmpty()&&w.action==null,"expiry recycles all retained node handles");w.close();check(w.fields.isEmpty(),"cleanup is idempotent");
 s=setup();f=read();w=f.indexedRead.witness;read();check(w.closed,"a newer index closes the superseded witness");
 check(!IndexedWitnessPolicy.sameIdentity("$121.97 0.2 mi","$121.97 0.2 mi"),"numbers alone cannot authorize a witness rebind");
 check(!IndexedWitnessPolicy.sameIdentity("$121.97 0.2 mi Tomorrow at 10:15 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618", "$121.97 0.2 mi Tomorrow at 11:15 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618"),"known pickup conflict blocks witness identity");

 s=setup();s.root.kids.get(2).text="0.2mi";f=read();check(f!=null&&f.miles==.2f&&(queries.size()==4 && new java.util.HashSet<>(queries).equals(java.util.Set.of("a","e","$","mi"))),"compact mileage uses one broad query with unchanged exact numeric proof");
 s=setup();f=read();check(queries.size()==4 && new java.util.HashSet<>(queries).equals(java.util.Set.of("a","e","$","mi")),"shared c action lookup finds both captions in one complete query");
 s.root.kids.get(1).mutateOnRefresh=true;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"source mutation after index does not cancel first CTA");
 s=setup();f=read();s.root.kids.get(1).visible=false;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"stale live witness visibility does not cancel indexed CTA");
 IndexedWitness cap=new IndexedWitness();for(int i=0;i<9;i++)cap.field(new AccessibilityNodeInfo("$1",new Rect(0,0,100,20)));
 check(cap.overflow&&cap.fields.size()==8,"node ownership is strictly bounded");cap.close();
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("$121.97 0.2 mi luna grill • 524 spectrum center dr, irvine, ca 92618, usa",new Rect(80,850,900,1000)));
 f=read();check(f!=null,"case-varied merged parent retains current indexed offer");
 UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"lossless folded parent sends CTA without node refresh");
 check(IndexedWitnessPolicy.singleFoldedSource(List.of("$121.97", "0.2   mi", "LUNA GRILL • 524 Spectrum Center Dr, Irvine, CA 92618", "$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618"))==8,"folded merged source losslessly covers split labels");
 check(IndexedWitnessPolicy.singleFoldedSource(List.of("$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618", "Tomorrow at 10:15 AM"))==0,"missing known pickup field cannot be omitted");
 check(IndexedWitnessPolicy.singleFoldedSource(List.of("$121.97 0.2 mi $99 9 mi", "$121.97"))==0,"conflicting route cannot supply merged proof");
 String identity="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";
 check(!IndexedWitnessPolicy.sameIdentity(identity+" burq_3744670",identity+" burq_3744671"),"provider-id conflict blocks witness rebind");
 s=setup();f=read();s.root.kids.get(3).refreshCost=70;UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0,"a completed coherent proof is not discarded when its last Binder read overruns the soft slice");
 // v139: RN merged parent and duplicated numeric children require only one field refresh.
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));s.root.kids.add(new AccessibilityNodeInfo("$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA",new Rect(80,850,900,1000)));
 f=read();check(f!=null&&f.indexedRead.witness.fields.size()==2&&Collections.frequency(queries,"$")<=1&&Collections.frequency(queries,"mi")<=1,"coherent action-query parent avoids duplicate numeric processing/child handles after concurrent discovery: "+queries);
 check(hasFreshIndexedWitness(),"fresh published proof suppresses competing ancestor enrichment");
 s.root.kids.get(1).refreshCost=70;s.root.kids.get(2).refreshCost=70;s.root.kids.get(3).refreshCost=70;
 UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"merged parent CTA sends without duplicate child Binder reads");
 check(!hasFreshIndexedWitness(),"dispatch cleanup releases ancestor-enrichment suppression");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));s.root.kids.add(new AccessibilityNodeInfo("$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA",new Rect(80,850,900,1000)));
 f=read();s.root.kids.get(6).text="$121.97 0.2 mi Other Cafe • 10 Main St, Irvine, CA 92618";UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0,"identity mutation no longer cancels admitted first CTA");
 s=setup();f=read();SystemClock.now+=301;check(!hasFreshIndexedWitness(),"expired proof never defers event enrichment");
 check(IndexedWitnessPolicy.minimumCover(identity,List.of("$121.97","0.2 mi","Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618"))==7,"split numeric and endpoint sources are all retained when necessary");
 String timed=identity+" Tomorrow at 10:15 AM burq_3744670";
 check(Integer.bitCount(IndexedWitnessPolicy.minimumCover(timed,List.of(identity,"Tomorrow at 10:15 AM","burq_3744670")))==3,"known pickup and provider ID cannot be dropped to save reads");
 check(IndexedWitnessPolicy.minimumCover(identity,List.of("$121.97 0.2 mi"))==0,"missing endpoint cannot authorize compact proof");
 check(IndexedWitnessPolicy.minimumCover(identity,List.of(identity+" $99.00 9.9 mi"))==0,"multi-card parent cannot authorize compact proof");
 check(last!=null,"completion detail survives");
 s=setup();f=read();UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&last.contains("LIVE_WINDOW_RECEIPT_REUSED")&&last.contains("PREFLIGHT root="),"split-field indexed CTA avoids final parallel rebind, retains phase trace");
 s=setup();f=read();s.root.kids.get(0).enabled=false;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1,"disabled after indexing does not invoke slow first gesture proof");
 s=setup();f=read();s.root.kids.get(0).stopOnRefresh=true;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1,"no refresh side effect; admitted CTA dispatched before monitor stop hook");
 s=setup();f=read();AccessibilityNodeInfo timeId=new AccessibilityNodeInfo("Tomorrow at 10:15 AM burq_3744670",new Rect(80,1010,900,1050));
 f.indexedRead.witness.field(timeId);f=f.withDecisionText(f.text+" Tomorrow at 10:15 AM burq_3744670");UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"enriched CTA no longer needs slow sequential node proof");
 s=setup();f=read();s.root.kids.get(0).windowOnRefresh=true;UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1,"no refresh side effect; admitted CTA dispatched despite window churn");
 s=setup();queryGate=new CountDownLatch(1);queryEntered=new CountDownLatch(1);gatedQueries=Set.of("e");
 CountDownLatch earlyParsed=new CountDownLatch(1);s.root.kids.get(0).textRead=earlyParsed;
 FutureTask<FastOfferSnapshot> streamedRead=new FutureTask<>(()->read());
 Thread streamedReader=new Thread(streamedRead);streamedReader.start();
 try {
  check(queryEntered.await(1,TimeUnit.SECONDS),"second caption query is still outstanding");
  check(earlyParsed.await(1,TimeUnit.SECONDS) && !streamedRead.isDone(),"first caption parses while second is outstanding without publishing");
  queryGate.countDown();
  check(streamedRead.get(1,TimeUnit.SECONDS)!=null,"both caption results still complete the same top-row proof");
 }catch(Exception ex){throw new AssertionError(ex);}finally{queryGate.countDown();}
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Claim",new Rect(689,1040,840,1090)));f=read();
 check(f!=null&&f.acceptBounds.top==1040&&new java.util.HashSet<>(queries).containsAll(java.util.Set.of("a","e")),"shared action query still selects the higher Claim rather than lower Accept");
 s=setup();AccessibilityNodeInfo disabledClaim=new AccessibilityNodeInfo("Claim",new Rect(689,1040,840,1090));disabledClaim.enabled=false;s.root.kids.add(disabledClaim);
 s.root.kids.get(0).actionable=false;
 int readinessBefore=actionReadyReads;
 check(read()==null,"disabled higher Claim cannot borrow a lower enabled Accept");
 check(actionReadyReads-readinessBefore==1,"only the elected top Accept is checked for readiness");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Cancel",new Rect(689,1020,840,1070)));s.root.kids.add(new AccessibilityNodeInfo("Coffee Merchant",new Rect(689,1010,840,1060)));f=read();
 check(f!=null&&f.acceptBounds.top==1094,"shared-letter false positives never authorize or replace the actual action");
 for(String caption:List.of("ACCEPT","Claim","Accept Offer","Claim Delivery","Button Accept","Claim Request")){
  s=setup();s.root.kids.get(0).text=caption;f=read();check(f!=null,"shared index retains supported semantic caption "+caption);
 }
 s=setup();f=read();UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&last.contains("ACTION_INDEX=SHARED_A_E")&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"shared index tracing survives speed-first direct CTA dispatch");
 check(IndexedWitnessPolicy.sourceCover(List.of("$121.97","0.2 mi","Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618"))==7,"split fields retain every source without semantic reparsing");
 int cover=IndexedWitnessPolicy.sourceCover(List.of("$121.97","0.2 mi",identity));check(Integer.bitCount(cover)==1,"complete parent text subsumes redundant child strings losslessly");
 cover=IndexedWitnessPolicy.sourceCover(List.of(identity,"Tomorrow at 10:15 AM","burq_3744670"));check(cover==7,"pickup and provider text are never dropped when not literally covered");
 cover=IndexedWitnessPolicy.sourceCover(List.of("$121.97","0.2 mi",identity+" $90.00 9.9 mi"));check(cover==7,"multi-offer parent cannot replace its card-local numeric children");
 check(IndexedWitnessPolicy.sourceCover(List.of("","$121.97"))==2,"empty source descriptions require no refresh");
 String[] atoms={"", "$121.97", "0.2 mi", identity, "Tomorrow at 10:15 AM", identity+" $90.00 9.9 mi"};
 java.util.Random random=new java.util.Random(157);
 for(int trial=0;trial<500;trial++){
  java.util.List<String> inputs=new java.util.ArrayList<>();for(int k=0;k<1+random.nextInt(8);k++)inputs.add(atoms[random.nextInt(atoms.length)]);
  int actual=IndexedWitnessPolicy.sourceCover(inputs);int minimum=99;
  for(int mask=1;mask<(1<<inputs.size());mask++){
   boolean covers=true;
   for(int j=0;j<inputs.size();j++)if(!inputs.get(j).trim().isEmpty()){
    boolean found=false;for(int i=0;i<inputs.size();i++)if((mask&(1<<i))!=0 && (i==j || (!CardText.containsMultipleMileageRows(inputs.get(i))&&inputs.get(i).contains(inputs.get(j)))))found=true;
    if(!found)covers=false;
   }
   if(covers)minimum=Math.min(minimum,Integer.bitCount(mask));
  }
  boolean allEmpty=inputs.stream().allMatch(String::isEmpty);if(allEmpty)minimum=0;
  check(Integer.bitCount(actual)==minimum,"maximal literal cover equals exhaustive reference");
 }
 s=setup();f=read();check(f.pageOutcomeBaseline()!=null&&!f.pageOutcomeBaseline().negative,"clean baseline travels with coherent snapshot");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("offer unavailable",new Rect(10,50,600,90)));f=read();check(f.pageOutcomeBaseline().negative,"visible existing prompt recorded before tap");
 s.root.kids.get(s.root.kids.size()-1).visible=false;f=read();check(!f.pageOutcomeBaseline().negative,"hidden old prompt cannot poison baseline");
 PageOutcomePolicy.Reading page=sampleAcceptPageOutcome(()->true);check(page!=null&&page.complete&&page.hint.isEmpty()&&page.context!=null,"production sampler ignores hidden prompt and reads coherent current card");
 s.root.kids.get(s.root.kids.size()-1).visible=true;page=sampleAcceptPageOutcome(()->true);check(page!=null&&page.hint.equals("offer unavailable"),"production sampler finds eventless current failure");
 s.root.kids.add(new AccessibilityNodeInfo("Begin Delivery",new Rect(10,80,600,100)));page=sampleAcceptPageOutcome(()->true);check(page!=null&&page.positive,"Begin Delivery veto survives prompt sampling");
 mutateIndex=true;check(sampleAcceptPageOutcome(()->true).complete,"one invalid sample is discarded and independent fresh-root restart can succeed");
 check(!sampleAcceptPageOutcome(()->false).complete,"superseded transaction cannot sample a page");
 s=setup();s.root.pkg="other.app";check(!sampleAcceptPageOutcome(()->true).complete,"foreign active window cannot supply outcome evidence");
 s=setup();String parentText="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";
 s.root.kids.add(new AccessibilityNodeInfo(parentText,new Rect(10,700,900,1060)));
 s.root.kids.add(new AccessibilityNodeInfo("offer unavailable",new Rect(10,50,600,90)));
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.context!=null&&CardText.amount(page.context)==121.97f,"parent and numeric children remain one spatially bound card");
 s.root.kids.add(new AccessibilityNodeInfo("$90.00 9.9 mi",new Rect(10,800,900,850)));
 page=sampleAcceptPageOutcome(()->true);check(page.context==null&&page.reason.equals("CONFLICTING_NUMBERS")&&page.evidenceDetail.contains("90.0")&&page.evidenceDetail.contains("121.97"),"distinct values at same coordinates still reject cross-card contamination");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("$90.00 9.9 mi",new Rect(10,1400,900,1450)));
 page=sampleAcceptPageOutcome(()->true);check(page.context!=null&&CardText.amount(page.context)==121.97f,"lower offer below top action cannot contaminate original top outcome context");
 s=setup();s.root.kids.remove(0);s.root.kids.add(new AccessibilityNodeInfo("0.2 mi",new Rect(10,1400,300,1450)));
 page=sampleAcceptPageOutcome(()->true);check(page.context==null&&page.reason.equals("AMBIGUOUS_ROWS"),"two separated equal mileage rows without action cannot masquerade as parent-child duplicates");

 s=setup();s.root.kids.get(0).enabled=false;s.root.kids.add(new AccessibilityNodeInfo("Offer unavailable. Please contact support about this offer.",new Rect(20,40,900,90)));
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.actionState.equals("DISABLED")&&page.excerpt.contains("contact support"),"same live bounded probe preserves disabled node and original failure sentence");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Your jobs overlap with another route",new Rect(20,40,900,90)));
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.queries==7&&ClaimSuccessSignals.isTimeConflict(page.hint),"shared a query retains overlap classification while reducing one query");
 s=setup();s.root.kids.get(0).bounds=new Rect(725,1110,780,1130);AccessibilityNodeInfo buttonParent=new AccessibilityNodeInfo("",button);buttonParent.enabled=false;s.root.kids.get(0).parent=buttonParent;
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.actionState.equals("DISABLED"),"small enabled label resolves disabled semantic parent for processing observation");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Offer Unavailable",new Rect(20,40,900,90)));s.root.kids.add(new AccessibilityNodeInfo("Offer Unavailable. Please contact support for more details.",new Rect(20,40,900,160)));
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.excerpt.contains("contact support"),"full failure sentence is retained instead of shorter heading");
 s=setup();outcomeMutations=100;page=sampleAcceptPageOutcome(()->true);check(page.reason.equals("UI_CHANGED")&&page.queries==4&&page.nodes==0&&queries.size()==8&&rootReads==2,"continuous churn stops after exactly two independent reads without accepting mixed evidence");
 INSTANCE.get().firstShotIndexBatch.close();INSTANCE.get().witnessReadBatch.close();
 s=setup();f=read();tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"retry reads sibling numeric/address index with no card ancestors");
 s=setup();f=read();s.root.kids.get(3).text=s.root.kids.get(3).text.replace("524", "525");UI_GENERATION.incrementAndGet();
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1&&last.contains("sent"),"speed-first preserves in-flight admitted Accept despite endpoint refresh");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 10:45 AM",new Rect(80,910,900,930)));
 f=getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true);
 s.root.kids.get(4).text="Tomorrow at 11:45 AM";UI_GENERATION.incrementAndGet();
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"speed-first keeps admitted current transaction after pickup-time refresh");
 // Commerce/Pasadena first-shot rebind must retain every special-rule field too.
 s=setup();s.root.kids.get(1).text="$28–38";s.root.kids.get(2).text="4.7 mi";
 s.root.kids.get(3).text="Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 f=read();check(f!=null&&f.indexedRead.witness!=null,"special-only eligible card publishes live sources");
 int specialQueries=queries.size();UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0&&queries.size()==specialQueries,"special-rule first gesture sends without extra Binder query after RN churn");
 s=setup();s.root.kids.get(1).text="$28–38";s.root.kids.get(2).text="4.7 mi";s.root.kids.get(3).text="Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 f=read();s.root.kids.get(3).text=s.root.kids.get(3).text.replace("6100","6101");UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0,"special first gesture keeps captured CTA when RN address redraws");
 s=setup();s.root.kids.get(1).text="$28–38";s.root.kids.get(2).text="4.7 mi";s.root.kids.get(3).text="Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 3:15 PM",new Rect(80,900,900,930)));
 f=getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true);
 check(f!=null&&f.indexedRead.witness!=null,"required pickup time retained in special witness");
 specialQueries=queries.size();UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0&&queries.size()==specialQueries,"special plus time guard avoids repeat index when all current fields match");
 s=setup();s.root.kids.get(1).text="$28–38";s.root.kids.get(2).text="4.7 mi";s.root.kids.get(3).text="Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 3:15 PM",new Rect(80,900,900,930)));
 f=getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true);
 s.root.kids.get(4).text="Tomorrow at 4:15 PM";UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0,"special first gesture survives pickup-time redraw without another Binder round");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 3:15 PM",new Rect(80,900,900,930)));
 f=getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true);
 check(f!=null&&f.indexedRead.witness!=null,"General with explicit time proof retains live time source");
 specialQueries=queries.size();UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0&&queries.size()==specialQueries,"General plus time proof also avoids repeat index");
 s=setup();s.root.kids.get(3).text="Today at 8:00 PM, PDT, Nobu • 903 N La Cienega Blvd, Los Angeles, CA 90069";
 f=getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true);
 check(f!=null&&!queries.contains("Today")&&!queries.contains("Tomorrow"),"already-live pickup skips two redundant queries");
 check(OfferEnrichmentPolicy.endpointKey(f.text).startsWith("nobu|"),"live index canonicalizes pickup zone");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 3:15 PM",new Rect(80,900,900,930)));
 f=getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true);
 check(f!=null&&queries.contains("Today")&&queries.contains("Tomorrow"),"missing pickup still requires live time index");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(120,1040,400,1080)));
 page=sampleAcceptPageOutcome(()->true);
 check(page.complete&&page.actionState.equals("OTHER_ROW"),"lower enabled Accept cannot supply top-row recovery proof");
 s=setup();s.root.kids.get(3).text="$121.97 0.2 mi Tomorrow at 9:50 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";
 f=getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true);
 check(f!=null&&queries.size()==4&&new java.util.HashSet<>(queries).equals(java.util.Set.of("a","e","$","mi")),"concurrent current queries supply full numeric/address/time proof without a second round");
 int fastQueries=queries.size();tap(f);check(dispatch==1&&queries.size()==fastQueries&&rootReads==1,"reused query retains a fresh bounded window receipt");
 s=setup();s.root.kids.get(3).text="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";s.root.kids.get(3).visible=false;
 f=read();check(f!=null&&queries.contains("$"),"invisible shared-query parent never replaces current numeric index");
 s=setup();f=read();tap(f);check(witnessOpenAtDispatch&&!hasFreshIndexedWitness(),"owned proof cleanup follows verified gesture dispatch");
 s=setup();f=read();throwDispatch=true;boolean threw=false;try{tap(f);}catch(IllegalStateException expected){threw=true;}
 check(threw&&!hasFreshIndexedWitness(),"dispatch exception still releases owned node handles");
 // v172 final retry uses the just-read observation witness, with no full re-index.
 s=setup();f=observeCurrentTopAcceptSnapshot();check(f!=null&&f.indexedRead.witness!=null&&!hasFreshIndexedWitness(),"enabled observation owns local retry nodes without suppressing event enrichment");
 int beforeRetryQueries=queries.size(),beforeRetryRoots=rootReads;UI_GENERATION.incrementAndGet();
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1&&queries.size()==beforeRetryQueries&&rootReads<=beforeRetryRoots+1,"same-owner retry dispatches without a second full-index pass");
 s=setup();s.root.kids.get(0).enabled=false;f=observeCurrentTopAcceptSnapshot();check(f!=null&&f.indexedRead.witness==null&&!hasFreshIndexedWitness(),"disabled observation never exports click witness");
 s=setup();f=observeCurrentTopAcceptSnapshot();UI_GENERATION.incrementAndGet();s.root.kids.get(1).text="$122.97";beforeRetryQueries=queries.size();
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1&&queries.size()==beforeRetryQueries,"admitted same-owner pressure stays live during amount redraw");
 s=setup();f=observeCurrentTopAcceptSnapshot();UI_GENERATION.incrementAndGet();s.root.kids.get(3).text=s.root.kids.get(3).text.replace("524","525");
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"admitted same-owner pressure tolerates endpoint redraw");
 s=setup();s.root.kids.get(3).text="$121.97 0.2 mi Tomorrow at 9:50 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";f=observeCurrentTopAcceptSnapshot();
 s.root.kids.get(3).text=s.root.kids.get(3).text.replace("9:50","10:50");UI_GENERATION.incrementAndGet();tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"admitted same-owner pressure tolerates time redraw");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(0).mutateOnRefresh=true;beforeRetryQueries=queries.size();
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1&&queries.size()==beforeRetryQueries,"generation churn cannot veto admitted same-owner pressure");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(0).windowOnRefresh=true;
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"same-app window epoch churn cannot cancel admitted gesture");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.pkg="other.app";foregroundPackage="other.app";beforeRetryQueries=queries.size();
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==0&&queries.size()==beforeRetryQueries,"real foreign foreground event must stop gesture without extra Binder work");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.windowId=2;
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"same-app current window id churn does not cancel admitted gesture");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(0).enabled=false;
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"already-admitted pressure tap is not cancelled by changed enabled bit before UI spinner");
 s=setup();f=observeCurrentTopAcceptSnapshot();f.indexedRead.witness.close();beforeRetryQueries=queries.size();
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"closed node witness does not block already admitted pressure dispatch");
 s=setup();f=observeCurrentTopAcceptSnapshot();SystemClock.advance(301);beforeRetryQueries=queries.size();
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"aged same-owner witness does not block admitted pressure gesture");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(0).stopOnRefresh=true;
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"no refresh occurs on sent CTA; retain separate explicit monitor-stop test");
 s=setup();s.root=null;check(read()==null&&acceptIndexFailure().equals("NO_ROOT"),"missing root is diagnosed");
 s=setup();s.root.kids.get(0).text="Other";check(read()==null&&acceptIndexFailure().equals("NO_ACCEPT"),"missing Accept is diagnosed");
 s=setup();s.root.kids.get(1).text="";check(read()==null&&acceptIndexFailure().equals("NUMERIC_MISSING"),"missing current numbers are diagnosed");
 s=setup();mutateIndex=true;check(read()!=null,"RN generation churn is tolerated for same current top Accept");
 s=setup();s.root.pkg="other.app";check(read()==null&&acceptIndexFailure().equals("FOREIGN_APP"),"foreign root is diagnosed");
 s=setup();check(getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true)==null&&acceptIndexFailure().equals("PICKUP_TIME_MISSING"),"required time absence is diagnosed");
 for(int guardKind=0;guardKind<3;guardKind++) {
  s=setup();f=observeCurrentTopAcceptSnapshot();finalRetryChurn=guardKind==0;finalRetryNegative=guardKind==1;finalRetryWindow=guardKind==2;
  tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
  check((guardKind!=1&&dispatch==1)||(guardKind==1&&dispatch==0),"generation/window churn are nonterminal; negative surface is terminal: "+guardKind);
 }
 // v173 complete fresh index fields are reused only while the action is live and generation unchanged.
 s=setup();f=observeCurrentTopAcceptSnapshot();beforeRetryQueries=queries.size();
 s.root.kids.get(1).refreshOK=false;s.root.kids.get(2).refreshOK=false;s.root.kids.get(3).refreshOK=false;
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1&&queries.size()==beforeRetryQueries,"complete index sends without a second numeric/endpoint Binder read");
 check(s.root.kids.get(0).refreshCalls==0&&s.root.kids.get(1).refreshCalls==0&&s.root.kids.get(2).refreshCalls==0&&s.root.kids.get(3).refreshCalls==0,"speed-first avoids all pre-dispatch node refresh");
 s=setup();f=observeCurrentTopAcceptSnapshot();SystemClock.advance(81);s.root.kids.get(1).refreshOK=false;
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1&&s.root.kids.get(1).refreshCalls==0,"admitted pressure dispatch tolerates older numeric witness without refresh");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(0).refreshCost=81;
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"no expensive action refresh; slow refresh cost cannot cancel gesture");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(0).text="Other";
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"admitted CTA coordinates are sent despite RN label redraw");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(0).refreshOK=false;s.root.kids.get(0).text="Other";
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"detached stale node does not cause another pre-send Binder read");
 s=setup();f=observeCurrentTopAcceptSnapshot();IndexedWitness longWitness=f.indexedRead.witness;f=new FastOfferSnapshot(f.text,f.acceptBounds,new Rect(),true,false,f.capturedAt,f.amount,f.miles,new IndexedReadProof(s.root.bounds,1,UI_GENERATION.get(),f.capturedAt-151,f.capturedAt,"long"));f.indexedRead.witness=longWitness;
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1&&s.root.kids.get(1).refreshCalls==0,"long initial index no longer forces a synchronous live-node round trip");
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(3).text="";UI_GENERATION.incrementAndGet();
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1,"admitted same-owner gesture continues through incomplete address redraw");
 // v173: v94-style current-tree rescue, gated by missing index and full original identity.
 String expected="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";
 s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(0).text="Other";f.indexedRead.witness.close();
 retryTree=new QuickTopResult(new FastOfferSnapshot(expected,button,new Rect(),true,false,SystemClock.now),false,40);
 tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
 check(dispatch==1&&treeReads<=1,"same-owner retry dispatches from retained geometry without mandatory slow tree rescue");
 for(String reason:new String[]{"UI_CHANGED_FIELDS","ACCEPT_DISABLED","FOREIGN_APP","PAIR_CHANGED","NUMERIC_CONFLICT","PICKUP_TIME_MISSING"}) {
  s=setup();f=observeCurrentTopAcceptSnapshot();retryTree=new QuickTopResult(f,false,20);
  check(readRetryQuickTreeSnapshot(s,f,121.97f,.2f,0,reason)==null&&treeReads==0,"real conflicts never start tree rescue: "+reason);
 }
 for(int kind=0;kind<12;kind++) {
  s=setup();f=observeCurrentTopAcceptSnapshot();
  String treeText=kind==0?expected.replace("121.97","122.97"):kind==1?expected.replace("524","525"):expected;
  if(kind==2){f=f.withDecisionText(expected+" Tomorrow at 10:15 AM");treeText=expected+" Tomorrow at 11:15 AM";}
  if(kind==3)f=f.withDecisionText("$121.97 0.2 mi");
  retryTree=new QuickTopResult(new FastOfferSnapshot(treeText,button,new Rect(),true,false,SystemClock.now),kind==4,40);
  if(kind==5)treeHook=()->UI_GENERATION.incrementAndGet();
  if(kind==6)treeHook=()->WINDOW_TRANSITION_EPOCH.incrementAndGet();
  if(kind==7)treeHook=()->OcrMonitorService.retryGuard="RETRY_NEGATIVE_PENDING";
  if(kind==8)treeHook=()->INSTANCE.get().root.pkg="other.app";
  if(kind==9)treeHook=()->SystemClock.advance(151);
  if(kind==10)treeHook=()->INSTANCE.get().root.bounds=new Rect(0,0,1080,2200);
  if(kind==11)treeHook=()->{throw new IllegalStateException("OEM read");};
  check(readRetryQuickTreeSnapshot(s,f,121.97f,.2f,0,"NO_ACCEPT")==null,"bounded tree rejects stale/wrong/negative proof kind="+kind);
 }
 s=setup();f=observeCurrentTopAcceptSnapshot();retryTree=new QuickTopResult(f,false,40);OcrMonitorService.retryGuard="RETRY_NEGATIVE_PENDING";
 check(readRetryQuickTreeSnapshot(s,f,121.97f,.2f,0,"NO_ACCEPT")==null&&treeReads==0,"fresh negative stops rescue before tree work");
 s=setup();f=observeCurrentTopAcceptSnapshot();retryTree=new QuickTopResult(new FastOfferSnapshot(expected,button,new Rect(),false,false,SystemClock.now),false,40);
 FastOfferSnapshot disabledTree=readRetryQuickTreeSnapshot(s,f,121.97f,.2f,0,"NO_ACCEPT");
 check(disabledTree!=null&&!disabledTree.acceptEnabled,"tree disabled state remains observation-only");
 for(int kind=0;kind<3;kind++) {
  s=setup();f=observeCurrentTopAcceptSnapshot();s.root.kids.get(0).text="Other";f.indexedRead.witness.close();
  retryTree=new QuickTopResult(new FastOfferSnapshot(expected,button,new Rect(),true,false,SystemClock.now),false,40);
  finalRetryChurn=kind==0;finalRetryNegative=kind==1;finalRetryWindow=kind==2;
  tapSnapshotRetryDetailed(f,121.97f,.2f,2,d->last=d,d->last=d);
  check((kind!=1&&dispatch==1)||(kind==1&&dispatch==0),"generation/window churn permits pressure while negative UI blocks it: "+kind);
 }
 // Both independent query IPCs start together; all values still share one generation fence.
 s=setup();queryEntered=new CountDownLatch(2);queryGate=new CountDownLatch(1);gatedQueries=Set.of("e","$");
 java.util.concurrent.ExecutorService pageLane=java.util.concurrent.Executors.newSingleThreadExecutor();
 java.util.concurrent.Future<PageOutcomePolicy.Reading> parallelPage=pageLane.submit(()->sampleAcceptPageOutcome(()->true));
 check(queryEntered.await(1,TimeUnit.SECONDS),"outcome query pair launches concurrently rather than waiting sequentially");
 queryGate.countDown();page=parallelPage.get(1,TimeUnit.SECONDS);pageLane.shutdownNow();
 check(page.complete && page.context!=null,"parallel page query values remain coherent and complete");
 AcceptControlWatch priorControl=WATCH_CANDIDATE.getAndSet(null);if(priorControl!=null)priorControl.close();OcrMonitorService.controlModes.clear();queryGate=queryEntered=null;gatedQueries=Set.of();
 // v196: page/control proof is handed directly to the retry dispatcher, consumed once.
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 9:30 AM",new Rect(80,910,900,935)));
 OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;
 page=sampleAcceptPageOutcome(()->true);
 f=takeAcceptPageRetrySnapshot(page.context,900);
 check(f!=null && f.acceptEnabled,"complete clean same-card sampler exports its final enabled proof");
 check(f.acceptControlReadAt()>=f.acceptProofStartedAt()&&f.acceptControlReadAt()<=f.capturedAt,
       "page receipt carries final CTA refresh time independently of the tree-read start");
 check(takeAcceptPageRetrySnapshot(page.context,900)==null,"page retry receipt is consumed exactly once");
 s=setup();OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=950;
 page=sampleAcceptPageOutcome(()->true);String receiptText=page.context;
 check(!sampleAcceptPageOutcome(()->false).complete,"yielded next sample is not new control evidence");
 check(takeAcceptPageRetrySnapshot(receiptText,900)!=null,"starting/yielding a later sample cannot erase an unconsumed fresh receipt");
 s=setup();OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=950;
 page=sampleAcceptPageOutcome(()->true);receiptText=page.context;
 s.root.kids.add(new AccessibilityNodeInfo("Offer unavailable",new Rect(20,40,900,90)));
 sampleAcceptPageOutcome(()->true);
 check(takeAcceptPageRetrySnapshot(receiptText,900)==null,"completed negative sample clears previous enabled receipt before tracker publication");

 int pageQueries=queries.size(),pageRoots=rootReads;
 tapSnapshotRetryDetailed(f,f.amount,f.miles,2,d->last=d,d->last=d);
 check(dispatch==1 && queries.size()==pageQueries && rootReads==pageRoots,"page proof reaches retry without a second root/index/tree read");
 check(last.contains("RETRY_PAGE_PROOF"),"direct page retry source is logged distinctly");
 for(int guardCase=0;guardCase<6;guardCase++) {
  s=setup();s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 9:30 AM",new Rect(80,910,900,935)));
  OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;page=sampleAcceptPageOutcome(()->true);
  switch(guardCase) {
   case 0:OcrMonitorService.sentAt++;break;
   case 1:WINDOW_TRANSITION_EPOCH.incrementAndGet();break;
   case 2:SystemClock.advance(251);break;
   case 3:OcrMonitorService.pendingAction=901;break;
   case 4:OcrMonitorService.retryGuard="RETRY_NEGATIVE_PENDING";break;
   case 5:OcrMonitorService.monitoring=false;break;
  }
  check(takeAcceptPageRetrySnapshot(page.context,900)==null,"page receipt rejected for stale/foreign/negative/stopped state "+guardCase);
 }
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 9:30 AM",new Rect(80,910,900,935)));
 OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;page=sampleAcceptPageOutcome(()->true);
 check(takeAcceptPageRetrySnapshot(page.context.replace("524","525"),900)==null,"same numbers and time with different address cannot consume a usable receipt");
 s=setup();s.root.kids.get(0).refreshOK=false;OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;
 page=sampleAcceptPageOutcome(()->true);
 check(takeAcceptPageRetrySnapshot(page.context,900)==null && page.actionState.equals("NOT_EXPORTED"),"detached control cannot publish enabled proof");
 s=setup();s.root.kids.get(0).mutateOnRefresh=true;OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;
 page=sampleAcceptPageOutcome(()->true);
 check(page.complete && rootReads==2 && takeAcceptPageRetrySnapshot(page.context,900)!=null,"control-refresh churn discards first proof and restarts from an independent coherent root");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("offer unavailable",new Rect(10,50,900,90)));OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;
 page=sampleAcceptPageOutcome(()->true);check(takeAcceptPageRetrySnapshot(page.context,900)==null,"visible terminal-negative text cannot publish a direct retry receipt");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("$29.00 2.2 mi",new Rect(10,300,900,350)));
 page=sampleAcceptPageOutcome(()->true);
 check(page.complete && page.context!=null && page.reason.equals("OK") && CardText.amount(page.context)==121.97f,"distant previous numeric row no longer poisons current-card conflict scope");
 s=setup();OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;page=sampleAcceptPageOutcome(()->true);f=takeAcceptPageRetrySnapshot(page.context,900);
 finalRetryChurn=true;tapSnapshotRetryDetailed(f,f.amount,f.miles,2,d->last=d,d->last=d);
 check(dispatch==1,"page retry does not veto same-owner gesture on RN generation churn");

 for(int pageCase=0;pageCase<4;pageCase++) {
  s=setup();s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 9:30 AM",new Rect(80,910,900,935)));
  OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;page=sampleAcceptPageOutcome(()->true);
  f=takeAcceptPageRetrySnapshot(page.context,900);
  check(f!=null&&f.indexedRead.witness!=null,"page receipt retains refreshable action/identity sources");
  UI_GENERATION.incrementAndGet();
  if(pageCase==1)s.root.kids.get(3).text=s.root.kids.get(3).text.replace("524","525");
  if(pageCase==2)s.root.kids.get(0).enabled=false;
  if(pageCase==3)OcrMonitorService.retryGuard="RETRY_NEGATIVE_PENDING";
  int oldQueries=queries.size(),oldRoots=rootReads;
  tapSnapshotRetryDetailed(f,121.97f,0.2f,2,d->last=d,d->last=d);
  check(dispatch==(pageCase==3?0:1),"page retry tolerates redraw/disabled updates but stops on explicit negative gate "+pageCase);
  check(queries.size()==oldQueries&&treeReads<=1&&rootReads<=oldRoots+1,"page handoff may use one bounded read but never another broad index "+pageCase);
 }
 for(int lateCase=0;lateCase<4;lateCase++) {
  s=setup();s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 9:30 AM",new Rect(80,910,900,935)));
  OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;page=sampleAcceptPageOutcome(()->true);
  SystemClock.advance(142);if(lateCase==3)UI_GENERATION.incrementAndGet();f=takeAcceptPageRetrySnapshot(page.context,900);
  check(f!=null,"142ms queue delay retains rebind candidate, not fresh click permission");
  if(lateCase==1)s.root.kids.get(3).text=s.root.kids.get(3).text.replace("524","525");
  if(lateCase==2)s.root.kids.get(0).enabled=false;
  int oldRoots=rootReads,oldQueries=queries.size();
  tapSnapshotRetryDetailed(f,f.amount,f.miles,2,d->last=d,d->last=d);
  check(dispatch==1,"admitted same-owner late candidate retains first-response pressure under RN redraw "+lateCase);
  check(rootReads<=oldRoots+1&&treeReads<=1&&queries.size()==oldQueries,"late candidate rebind avoids broad index and may use one bounded read "+lateCase);
 }
 s=setup();f=read();check(f!=null&&new HashSet<>(queries).equals(Set.of("a","e","$","mi")),"exact caption selection shares four discovery queries; no extra Accept/Claim Binder lookups");
 s=setup();queryGate=new CountDownLatch(1);queryEntered=new CountDownLatch(4);gatedQueries=Set.of("e","$","USD","mi");
 FutureTask<PageOutcomePolicy.Reading> pageGroupTask=new FutureTask<>(()->sampleAcceptPageOutcome(()->true));
 new Thread(pageGroupTask).start();
 try {
  check(queryEntered.await(1,TimeUnit.SECONDS),"first four page indexes run concurrently in bounded pool");
  queryGate.countDown();PageOutcomePolicy.Reading groupedPage=pageGroupTask.get(2,TimeUnit.SECONDS);
  check(groupedPage.complete&&groupedPage.queries==7,"four-plus-three grouping retains all seven outcome queries");
 }catch(Exception groupFailure){throw new AssertionError(groupFailure);}finally{queryGate.countDown();queryGate=queryEntered=null;gatedQueries=Set.of();}
 s=setup();f=read();int rootCount=rootReads;FastOfferSnapshot second=read();
 check(second!=null&&rootReads==rootCount,"same-generation active-root receipt removes duplicate root Binder read");
 SystemClock.advance(41);read();check(rootReads==rootCount+1,"root receipt expires after40ms without extending its timestamp");
 UI_GENERATION.incrementAndGet();read();check(rootReads==rootCount+2,"new UI generation requires a fresh root");
 WINDOW_TRANSITION_EPOCH.incrementAndGet();read();check(rootReads==rootCount+3,"window transition requires a fresh root");
 foregroundPackage="other.app";read();check(rootReads==rootCount+4,"foreign foreground cannot borrow root receipt");
 s=setup();f=read();OcrMonitorService.pendingAction=900;
 check(isCurrentPressureResumeSnapshot(f,f.text,900),"resume takes a current enabled same-card proof");
 check(!isCurrentPressureResumeSnapshot(f,f.text,901),"resume owner mismatch vetoes old queue task");
 check(!isCurrentPressureResumeSnapshot(f,f.text.replace("$", "$9"),900),"resume must retain exact current identity");
 UI_GENERATION.incrementAndGet();check(!isCurrentPressureResumeSnapshot(f,f.text,900),"mutated snapshot cannot resume cached pressure");
 s=setup();f=read();OcrMonitorService.pendingAction=900;SystemClock.advance(251);
 check(!isCurrentPressureResumeSnapshot(f,f.text,900),"expired live CTA cannot resume");
 s=setup();f=read();OcrMonitorService.pendingAction=900;WINDOW_TRANSITION_EPOCH.incrementAndGet();
 check(!isCurrentPressureResumeSnapshot(f,f.text,900),"window epoch changed before resume");
 s=setup();f=read();OcrMonitorService.pendingAction=900;foregroundPackage="other.app";
 check(!isCurrentPressureResumeSnapshot(f,f.text,900),"foreign foreground blocks live-proof resume");


 // Root read-ahead is single-flight, bounded and never publishes a superseded window/frame.
 s=setup();s.rootReadAhead=new ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(1),run->{Thread t=new Thread(run);t.setDaemon(true);return t;});s.rootReadAhead.prestartAllCoreThreads();
 rootGate=new CountDownLatch(1);rootEntered=new CountDownLatch(1);
 FutureTask<String> prefetched=prefetchIndexedRoot(s,UI_GENERATION.get());
 try {
  check(rootEntered.await(1,TimeUnit.SECONDS),"prefetch starts root before index joins");
  final TapAccessibilityService ahead=s;AtomicReference<AccessibilityNodeInfo> joined=new AtomicReference<>();
  Thread joiner=new Thread(()->joined.set(readCurrentIndexedRoot(ahead,UI_GENERATION.get())));joiner.start();rootGate.countDown();joiner.join(2000);
  check(joined.get()!=null&&rootReads==1,"index joins same in-flight root without another Binder root call");
 }catch(Exception e){throw new AssertionError(e);}finally{rootGate.countDown();}
 s=setup();s.rootReadAhead=new ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(1),run->{Thread t=new Thread(run);t.setDaemon(true);return t;});s.rootReadAhead.prestartAllCoreThreads();
 rootGate=new CountDownLatch(1);rootEntered=new CountDownLatch(1);prefetched=prefetchIndexedRoot(s,UI_GENERATION.get());
 try{
  check(rootEntered.await(1,TimeUnit.SECONDS),"slow root starts");
  check(readCurrentIndexedRoot(s,UI_GENERATION.get())==null&&acceptIndexFailure().equals("ROOT_READ_PENDING")&&rootReads==1,"pending read yields within slice without duplicate root");
  UI_GENERATION.incrementAndGet();rootGate.countDown();check(!"READY".equals(prefetched.get(1,TimeUnit.SECONDS))&&indexedRootReceipt==null,"old generation root cannot publish after completion");
 }catch(Exception e){throw new AssertionError(e);}finally{rootGate.countDown();}
 check(OcrMonitorService.indexedRootWakes==0,"superseded roots cannot wake the scanner");
 s=setup();s.rootReadAhead=new ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(1),run->{Thread t=new Thread(run);t.setDaemon(true);return t;});
 rootGate=new CountDownLatch(1);rootEntered=new CountDownLatch(1);prefetched=prefetchIndexedRoot(s,UI_GENERATION.get());
 try{
  check(rootEntered.await(1,TimeUnit.SECONDS),"slow current root starts");
  check(readCurrentIndexedRoot(s,UI_GENERATION.get())==null&&OcrMonitorService.indexedRootWakes==0,"unfinished root cannot wake the scanner");
  rootGate.countDown();
  check("READY".equals(prefetched.get(1,TimeUnit.SECONDS))&&OcrMonitorService.indexedRootWakes==1,"late current root wakes the scanner immediately after publication");
  check(readCurrentIndexedRoot(s,UI_GENERATION.get())!=null&&rootReads==1,"woken scanner reuses the published root");
 }catch(Exception e){throw new AssertionError(e);}finally{rootGate.countDown();}
 s=setup();s.rootReadAhead=new ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(1),run->{Thread t=new Thread(run);t.setDaemon(true);return t;});
 rootGate=new CountDownLatch(1);rootEntered=new CountDownLatch(1);
 prefetched=prefetchIndexedRoot(s,UI_GENERATION.get());
 try {
  check(rootEntered.await(1,TimeUnit.SECONDS),"first-shot slow root begins");
  check(read()==null&&acceptIndexFailure().equals("ROOT_READ_PENDING")&&rootReads==1&&queries.isEmpty(),
       "first-shot wait releases scan before a stalled root completes");
  rootGate.countDown();
  check("READY".equals(prefetched.get(1,TimeUnit.SECONDS))&&OcrMonitorService.indexedRootWakes==1,
       "root completion wakes a fresh first shot");
  check(read()!=null&&rootReads==1,"first shot reuses ready root without a second Binder fetch");
 }catch(Exception e){throw new AssertionError(e);}finally{rootGate.countDown();}
 // A saturated prefetch executor must not fall back to a synchronous root call on first shot.
 s=setup();s.rootReadAhead=new ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(1),run->{Thread t=new Thread(run);t.setDaemon(true);return t;});
 CountDownLatch saturated=new CountDownLatch(1),unblock=new CountDownLatch(1);
 s.rootReadAhead.execute(()->{saturated.countDown();try{unblock.await();}catch(InterruptedException e){Thread.currentThread().interrupt();}});
 try {
  check(saturated.await(1,TimeUnit.SECONDS),"root reader occupied");
  s.rootReadAhead.execute(()->{});
  check(read()==null&&acceptIndexFailure().equals("ROOT_READ_PENDING")&&rootReads==0&&queries.isEmpty(),"saturated root queue yields first shot without a duplicate blocking Binder call");
 }catch(Exception e){throw new AssertionError(e);}finally{unblock.countDown();}
 // Control watch refreshes one anchored control. It may report/wake; it never sends a click.
 s=setup();f=read();check(WATCH_CANDIDATE.get()!=null,"first index retains separate wake-only control");
 s.controlWatchWorker=new Handler();OcrMonitorService.pendingAction=900;startAcceptControlWatch(f.text,900);
 AcceptControlWatch watching=s.activeControlWatch;check(watching!=null,"watch binds original transaction");
 int watchRoots=rootReads,watchQueries=queries.size();s.root.kids.get(0).enabled=false;s.pollAcceptControl(watching);
 check(OcrMonitorService.controlModes.equals(List.of("DISABLED"))&&dispatch==0,"disabled control only observed");
 s.root.kids.get(0).enabled=true;s.pollAcceptControl(watching);s.pollAcceptControl(watching);
 check(OcrMonitorService.controlModes.equals(List.of("DISABLED","ENABLED_RECOVERED"))&&dispatch==0,"enabled edge wakes once without click authority");
 check(rootReads==watchRoots&&queries.size()==watchQueries,"light watch does not read root or seven-query page");
 WINDOW_TRANSITION_EPOCH.incrementAndGet();s.pollAcceptControl(watching);check(s.activeControlWatch==null,"window transition cancels control watch");
 s=setup();f=read();s.controlWatchWorker=new Handler();OcrMonitorService.pendingAction=900;startAcceptControlWatch(f.text,900);watching=s.activeControlWatch;
 OcrMonitorService.retryGuard="RETRY_NEGATIVE_PENDING";int oldRefresh=s.root.kids.get(0).refreshCalls;s.pollAcceptControl(watching);
 check(s.activeControlWatch==null&&s.root.kids.get(0).refreshCalls==oldRefresh,"negative evidence stops watch before any control read");

 s=setup();f=read();s.controlWatchWorker=new Handler();OcrMonitorService.pendingAction=900;startAcceptControlWatch(f.text,900);watching=s.activeControlWatch;
 s.root.kids.get(0).refreshOK=false;s.root.kids.remove(0);s.root.kids.add(0,new AccessibilityNodeInfo("Accept",button));
 watchQueries=queries.size();s.pollAcceptControl(watching);
 check(OcrMonitorService.controlModes.equals(List.of("ENABLED"))&&watching.rebinds==1&&dispatch==0,"detached RN control can rebind current caption and only wake inspection");
 check(queries.size()==watchQueries+1,"control rebind uses caption index rather than seven-query page scan");
 s=setup();f=read();s.controlWatchWorker=new Handler();OcrMonitorService.pendingAction=900;startAcceptControlWatch(f.text,900);watching=s.activeControlWatch;
 s.root.kids.get(0).refreshOK=false;s.root.kids.remove(0);s.pollAcceptControl(watching);s.pollAcceptControl(watching);watchQueries=queries.size();s.pollAcceptControl(watching);
 check(watching.rebinds==1&&queries.size()==watchQueries&&dispatch==0,"early hidden polls cannot exhaust caption rebinds");
 watching.nextRebindAt=0;s.root.kids.add(0,new AccessibilityNodeInfo("Accept",button));s.pollAcceptControl(watching);
 check(watching.rebinds==2&&OcrMonitorService.controlModes.contains("ENABLED_RECOVERED")&&dispatch==0,"late replacement control wakes live inspection without dispatch authority");
 s=setup();OcrMonitorService.rejectNumbers=true;
 s.root.kids.get(1).text="$23.00";s.root.kids.get(2).text="12.6 mi";
 int beforeRejectReady=actionReadyReads;
 f=read();
 check(f==null && ACCEPT_INDEX_FAILURE.get().equals("NUMERIC_ALL_BRANCHES_REJECT"),"known universal rejection exits self-index before city work");
 check(actionReadyReads==beforeRejectReady,"conclusive numeric rejection skips irrelevant Accept readiness traversal");
 check(CardText.amount(routedReject)==23f && CardText.miles(routedReject)==12.6f && dispatch==0,"current failed numeric pair is routing evidence only, never a dispatch");
 FastOfferSnapshot observed=takeRejectedSelfIndexObservation();
 check(observed!=null && observed.amount==23f && !observed.acceptEnabled && observed.rejectBounds.isEmpty()
       && observed.rejectReuseReason.equals("NO_REJECT_NODE"),"reject routing without a button explains why the proof cannot be reused");
 check(takeRejectedSelfIndexObservation()==null,"observation consumed once");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(246,1094,386,1151)));
 check(read()!=null,"Accept index caches the current root for a subsequent rule check");
 int priorRootReads=rootReads;
 StringBuilder rejectPhases=new StringBuilder();
 check(getIndexedCurrentTopRejectSnapshot(false,false,60L,(pay,mi)->true,rejectPhases)!=null
        &&rootReads==priorRootReads&&rejectPhases.toString().contains("Reject根节点=复用"),
       "Reject resolver reuses only the current indexed root");
 UI_GENERATION.incrementAndGet();
 getIndexedCurrentTopRejectSnapshot(false,false,60L,(pay,mi)->true,new StringBuilder());
 check(rootReads>priorRootReads,"generation change forces a fresh Reject root");

 s=setup();OcrMonitorService.rejectNumbers=true;s.root.kids.get(1).text="$23.00";
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(246,1094,386,1151)));
 check(read()==null,"universal Reject uses shared top row");observed=takeRejectedSelfIndexObservation();
 check(observed!=null&&observed.rejectEnabled&&observed.rejectProof!=null,"same row supplies fresh Reject proof");
 check(observed.rejectReadStartedAt()<=observed.rejectNumbersReadAt()
       && observed.rejectNumbersReadAt()<=observed.capturedAt,
       "shared Reject latches the time of the bound numeric pair");
 check(observed.rejectIndexTiming().contains("query=")&&observed.rejectIndexTiming().contains("fieldsAndProof="),
       "shared Reject logs root, query, action, numeric and final proof phases");
 check(observed.withDecisionText(observed.text+" Tomorrow at 11:00 AM").rejectNumbersReadAt()
       ==observed.rejectNumbersReadAt(),"enrichment preserves the original numeric evidence time");
 semanticRejectClicks=0;int readsBeforeReject=queries.size();
 dispatchBoundReject(s,observed,m->last=m,m->last=m,()->true);
 check(semanticRejectClicks==1&&queries.size()==readsBeforeReject&&last.contains("SHARED_REJECT_ROW"),"current bound control clicks without new index read");
 dispatchBoundReject(s,observed,m->last=m,m->last=m,()->true);
 check(semanticRejectClicks==1,"shared proof is single use");
 s=setup();OcrMonitorService.rejectNumbers=true;s.root.kids.get(1).text="$23.00";
 Rect rejectArea=new Rect(246,1094,386,1151);
 AccessibilityNodeInfo label=new AccessibilityNodeInfo("Ignore",rejectArea);
 label.actionable=false;label.parent=new AccessibilityNodeInfo("",rejectArea);
 s.root.kids.add(label);
 check(read()==null,"nested Reject caption takes the shared row");
 observed=takeRejectedSelfIndexObservation();
 check(observed!=null&&observed.rejectEnabled&&observed.rejectProof!=null,
       "nested Reject caption resolves the same-row clickable parent");
 label.parent.enabled=false;label.parent.parent=new AccessibilityNodeInfo("",rejectArea);
 read();observed=takeRejectedSelfIndexObservation();
 check(observed!=null&&!observed.rejectEnabled&&observed.rejectProof==null
       &&observed.rejectReuseReason.equals("REJECT_DISABLED"),"disabled nested control blocks clickable ancestor");

 s=setup();OcrMonitorService.rejectNumbers=true;s.root.kids.get(1).text="$23.00";s.root.kids.get(2).text="12.6 mi";s.root.kids.get(0).text="Other";
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(246,1094,386,1151)));
 check(read()==null,"missing Accept stays in the rejection-only route");
 observed=takeRejectedSelfIndexObservation();
 check(observed!=null&&observed.rejectEnabled&&observed.rejectProof.stages.equals("SHARED_TOP_REJECT"),
       "shared top Reject and coherent numeric pair survive without a second index");
 s=setup();OcrMonitorService.rejectNumbers=true;s.root.kids.get(0).text="Other";
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(246,1094,386,1151)));
 check(read()==null&&takeRejectedSelfIndexObservation()==null,
       "missing Accept never allows Reject for a potentially qualifying amount");

 s=setup();OcrMonitorService.rejectNumbers=true;s.root.kids.get(1).text="$23.00";
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(246,1094,386,1151)));
 read();observed=takeRejectedSelfIndexObservation();UI_GENERATION.incrementAndGet();
 dispatchBoundReject(s,observed,m->last=m,m->last=m,()->true);
 check(semanticRejectClicks==1&&REJECT_PROOF_CHANGED_BEFORE_CLICK.equals(last),
       "changed top generation revokes proof before any click call");
 s=setup();s.root.kids.get(1).text="$23.00";
 AccessibilityNodeInfo firstReject=new AccessibilityNodeInfo("Ignore",new Rect(246,1094,386,1151));
 s.root.kids.add(firstReject);
 f=getIndexedNumericTopActionSnapshot(23,.2f,false,false,null,false);
 check(f!=null&&f.rejectProof!=null,"exact numeric Reject retains the resolved action");
 int exactReads=queries.size();dispatchBoundReject(s,f,m->last=m,m->last=m,()->true);
 check(semanticRejectClicks==2&&queries.size()==exactReads&&last.contains("EXACT_REJECT_ROW"),"exact Reject clicks without requery");
 firstReject.enabled=false;
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(246,1494,386,1551)));
 check(getIndexedNumericTopActionSnapshot(23,.2f,false,false,null,false)==null,"disabled top Reject cannot redirect the click to a lower card");


 s=setup();OcrMonitorService.rejectNumbers=true;s.root.kids.get(1).text="$23.00";s.root.kids.get(2).text="12.6 mi";read();UI_GENERATION.incrementAndGet();
 check(takeRejectedSelfIndexObservation()==null,"generation invalidates rejected observation");
 s=setup();OcrMonitorService.rejectNumbers=true;s.root.kids.get(1).text="$23.00";s.root.kids.get(2).text="12.6 mi";read();WINDOW_TRANSITION_EPOCH.incrementAndGet();
 check(takeRejectedSelfIndexObservation()==null,"window transition invalidates rejected observation");
 s=setup();s.root.kids.get(1).text="$68.69";s.root.kids.get(2).text="4 mi";
 f=read();observed=takeRejectedSelfIndexObservation();
 check(f==null && observed!=null && observed.text.contains("Irvine") && observed.amount==68.69f && dispatch==0,
       "complete current non-special city failure is retained for Reject routing, no Accept dispatch");
 s=setup();s.root.kids.get(1).text="$68.69";s.root.kids.get(2).text="4 mi";s.root.kids.get(3).text="Luna Grill";
 read();check(takeRejectedSelfIndexObservation()==null,"unresolved city never creates a complete-city rejection observation");
 for(int gate=0;gate<6;gate++) {
  s=setup();f=read();OcrMonitorService.pressureActive=true;OcrMonitorService.pressureSnapshot=null;OcrMonitorService.pressureGuard="";
  if(gate==1)OcrMonitorService.pressureGuard="FOREIGN_APP";
  if(gate==2)OcrMonitorService.pressureGuard="CONTROL_NOT_EXPORTED";
  if(gate==3)OcrMonitorService.pressureActive=false;
  if(gate==4)WINDOW_TRANSITION_EPOCH.incrementAndGet();
  if(gate==5)foregroundPackage="other.app";
  int beforeDispatch=dispatch;tapPressureRetry(f,900,814,d->{},d->{});drainPressure();
  check(dispatch-beforeDispatch==((gate==0||gate==4)?1:0),"same-app window churn never cancels pressure; explicit foreground/negative/stop still gate "+gate);
 }
 OcrMonitorService.pressureActive=false;OcrMonitorService.pressureSnapshot=null;OcrMonitorService.pressureGuard="";
 // Replay 563607660: insertion puts $19 top and the active $110.02 in row two.
 s=traceRows(0);PageOutcomePolicy.Reading followed=sampleAcceptPageOutcome(()->true);
 check(followed.complete&&IndexedWitnessPolicy.sameIdentity(OWNED,followed.context)&&followed.actionState.equals("ENABLED"),"inserted garbage top cannot displace the active offer identity");
 check(followed.evidenceDetail.contains("OWNED_ROW_REBOUND"),"probe diagnoses active offer moving to lower visible row");
 f=takeAcceptPageRetrySnapshot(OWNED,900);
 check(f!=null&&f.acceptBounds.top==1898&&f.acceptBounds.bottom==1955,"fresh receipt uses the original offer's relocated row coordinates");
 check(isCurrentPressureResumeSnapshot(f,OWNED,900),"lower-row proof can resume the existing transaction");
 OcrMonitorService.pressureActive=true;int previousSends=dispatch;tapPressureRetry(f,900,12,d->{},d->{});drainPressure();
 check(dispatch==previousSends+1,"actual pressure dispatcher accepts the freshly verified lower-row receipt");
 UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();tapPressureRetry(f,900,13,d->{},d->{});drainPressure();
 check(dispatch>=previousSends+1,"layout churn cannot retroactively cancel a previously dispatched click");
 // Both v238 cancelled reservations are kept when the live same-card action has not moved.
 s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
 rememberAcceptResumeNodes(f,1000);OcrMonitorService.pressureActive=true;
 int pressureQueries=queries.size();int pressureSends=dispatch;
 for(int turn=0;turn<2;turn++) {
  UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
  final List<String> pressureLog=new ArrayList<>();tapPressureRetry(f,1000,turn+2,pressureLog::add,pressureLog::add);drainPressure();
  check(dispatch==pressureSends+turn+1,"same-card pressure sends on layout redraw without mandatory synchronous renewal "+turn);
 }
 check(queries.size()==pressureQueries,"pressure layout renewal never launches broad page/negative queries");
 s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
 rememberAcceptResumeNodes(f,1000);OcrMonitorService.pressureActive=true;
 UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
 pressureFinalHook=()->{UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();};
 final List<String> doubleRenew=new ArrayList<>();tapPressureRetry(f,1000,2,doubleRenew::add,doubleRenew::add);drainPressure();
 check(dispatch==1,"second same-card publication does not cancel queued retry at final gesture boundary");
 for(int endGate=0;endGate<3;endGate++) {
  s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
  rememberAcceptResumeNodes(f,1000);OcrMonitorService.pressureActive=true;
  UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();final int end=endGate;
  pressureFinalHook=()->{if(end==0)OcrMonitorService.pressureActive=false;
      if(end==1)OcrMonitorService.retryGuard="NEGATIVE_VISIBLE";
      if(end==2)OcrMonitorService.pendingAction=1001;};
  tapPressureRetry(f,1000,2,d->{},d->{});drainPressure();
  check(dispatch==0,"spinner/terminal/owner change after inline renewal wins final send fence "+endGate);
 }
 OcrMonitorService.pressureSnapshot=null;OcrMonitorService.pressureGuard="";OcrMonitorService.retryGuard="";

 for(int change=0;change<6;change++) {
  s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
  rememberAcceptResumeNodes(f,1000);OcrMonitorService.pressureActive=true;
  UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
  if(change==0)s.root.kids.get(0).enabled=false;
  if(change==1)s.root.kids.get(0).bounds=new Rect(689,1300,840,1357);
  if(change==2)s.root.kids.get(1).text="$10.00";
  if(change==3)WINDOW_TRANSITION_EPOCH.incrementAndGet();
  if(change==4)OcrMonitorService.pressureGuard="NEGATIVE_VISIBLE";
  if(change==5)OcrMonitorService.pressureActive=false;
  final List<String> pressureLog=new ArrayList<>();tapPressureRetry(f,1000,2,pressureLog::add,pressureLog::add);drainPressure();
  check(dispatch==(change<=3?1:0),"same-owner pressure tolerates redraw/price/window; negative/paused still stop "+change);
 }
 OcrMonitorService.pressureActive=false;OcrMonitorService.pressureSnapshot=null;OcrMonitorService.pressureGuard="";
 s=traceRows(0);followed=sampleAcceptPageOutcome(()->true);f=observeCurrentOwnedAcceptSnapshot(OWNED,900);
 check(f!=null&&f.acceptBounds.top==1898,"inspector fallback also searches owned visible row, never just current top");
 s=traceRows(1);followed=sampleAcceptPageOutcome(()->true);
 check(followed.complete&&IndexedWitnessPolicy.sameIdentity(OWNED,followed.context)&&followed.actionState.equals("DISABLED"),"disabled original below an enabled new top remains owned processing observation");
 check(takeAcceptPageRetrySnapshot(OWNED,900)==null,"disabled lower row never lends click authority");
 s=traceRows(2);followed=sampleAcceptPageOutcome(()->true);
 check(followed.complete&&IndexedWitnessPolicy.sameIdentity(OWNED,followed.context)&&followed.actionState.equals("NOT_EXPORTED"),"Reject-only owned row is not mistaken for disappeared original");
 s=traceRows(2);followed=sampleAcceptPageOutcome(()->true);f=observeCurrentOwnedAcceptSnapshot(OWNED,900);
 check(f!=null&&!f.acceptEnabled&&f.acceptBounds.isEmpty(),"missing original Accept yields observation only, never new-top geometry");
 s=traceRows(3);followed=sampleAcceptPageOutcome(()->true);
 check(followed.complete&&!PageOutcomePolicy.compatible(OWNED,followed.context)&&followed.evidenceDetail.contains("OWNED_ROW_SEARCH=COMPLETE"),"confirmed all-row absence is distinct from simple top-card replacement");
 check(takeAcceptPageRetrySnapshot(OWNED,900)==null,"a new top offer cannot consume an original-owner retry receipt");
 s=traceRows(0);s.root.kids.get(0).text=OWNED;followed=sampleAcceptPageOutcome(()->true);
 check(followed.context==null&&followed.reason.equals("AMBIGUOUS_OWNED_ROWS")&&takeAcceptPageRetrySnapshot(OWNED,900)==null,"two matching visible rows cannot arbitrarily borrow one rectangle");
 s=traceRows(0);s.root.kids.removeIf(n->n.bounds.top>1300);traceCard(s,"2.6 mi Today at 11:05 AM Mendocino Farms • 840 S Sepulveda Blvd, El Segundo, CA 90245",736,true,true);
 followed=sampleAcceptPageOutcome(()->true);
 check(followed.context==null&&followed.reason.equals("OWNED_ROW_INCOMPLETE"),"missing owned-row amount cannot borrow top garbage amount or prove original absence");
 s=traceRows(0);s.root.kids.get(0).text=OWNED.replace("840 S Sepulveda", "841 S Sepulveda");followed=sampleAcceptPageOutcome(()->true);
 f=takeAcceptPageRetrySnapshot(OWNED,900);
 check(f!=null&&f.acceptBounds.top==1898,"identical numbers/time on another endpoint never capture the active offer");
 s=traceRows(0);s.root.kids.get(5).mutateOnRefresh=true;followed=sampleAcceptPageOutcome(()->true);
 f=takeAcceptPageRetrySnapshot(OWNED,900);check(f==null||f.indexedRead.generation==UI_GENERATION.get(),"generation churn cannot preserve a stale first-pass row receipt");
 // Current direct button attributes from one coherent discovery do not need a parent walk.
 s=setup();f=read();check(f!=null && resolveCalls==0,"direct exact button uses captured current attributes without duplicate resolution");
 s=setup();s.root.kids.get(0).actionable=false;
 check(read()==null,"enabled text with no actionable control or ancestor cannot gain click permission");
 s=setup();s.root.kids.get(0).visible=false;
 check(read()==null,"hidden exact button cannot become current first-shot authority");

 s=setup();AccessibilityNodeInfo caption=s.root.kids.get(0);
 caption.bounds=new Rect(10,1094,20,1151);caption.parent=new AccessibilityNodeInfo("",button);
 f=read();check(f!=null && resolveCalls>0,"text child still resolves its real button parent");
 s=setup();f=read();s.controlWatchWorker=new Handler();OcrMonitorService.pendingAction=900;
 startAcceptControlWatch(f.text,900);AcceptControlWatch firstWatch=s.activeControlWatch;
 int queuedWatch=s.controlWatchWorker.pending.size();
 for(int i=0;i<100;i++)startAcceptControlWatch(f.text,900);
 check(s.activeControlWatch==firstWatch && s.controlWatchWorker.pending.size()==queuedWatch,"100 same-transaction observer starts preserve one watch and one queue entry");
 OcrMonitorService.pendingText="";OcrMonitorService.pressureActive=false;
 s=traceRows(0);followed=sampleAcceptPageOutcome(()->true);f=takeAcceptPageRetrySnapshot(OWNED,900);
 OcrMonitorService.pressureActive=true;int validBefore=dispatch;
 UI_GENERATION.incrementAndGet();tapPressureRetry(f,900,14,d->{},d->{});drainPressure();
 check(dispatch==validBefore+1,"click-only UI generation change keeps the verified fixed-position pressure loop continuous");
 PRESSURE_LAYOUT_EPOCH.incrementAndGet();final String[] stopReason={""};tapPressureRetry(f,900,15,d->{},d->stopReason[0]=d);drainPressure();
 check(dispatch==validBefore+2,"same-owner retry continues under layout epoch churn without pre-send replay proof");
 OcrMonitorService.pressureActive=false;
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("This offer is no longer available.",new Rect(100,1700,900,1800)));
 f=readIndexedCurrentTopAcceptSnapshot(100f,20f,false,true,false,true);
 check(f!=null&&currentNegativeSurfaceBlocksAccept()&&hasCurrentNegativeBaseline(f),"current live index publishes visible failure without needing owner attribution");
 int beforeFailureTap=dispatch;tap(f);
 check(dispatch==beforeFailureTap,"final physical first-shot cannot bypass visible failure surface");
 s.root.kids.remove(s.root.kids.size()-1);SystemClock.advance(5);
 f=readIndexedCurrentTopAcceptSnapshot(100f,20f,false,true,false,true);
 check(f!=null&&!currentNegativeSurfaceBlocksAccept()&&!hasCurrentNegativeBaseline(f),"new coherent clean index removes current veto without history or cooldown");
 s=setup();f=read();check(f!=null&&f.indexedRead.deferredStages!=null&&f.indexedRead.stages.equals("INDEX_CURRENT_TOP"),"first-shot phase diagnostics are deferred until reporting");
 int beforeFormatting=queries.size();ROOT_READ_TRACE.set("OTHER_THREAD_CONTEXT");String formatted=f.indexedRead.formattedStages();
 check(queries.size()==beforeFormatting&&formatted.contains("INDEX_PHASE")&&!formatted.contains("OTHER_THREAD_CONTEXT"),"deferred report retains captured timings and never touches Android index");
 check(formatted.contains("seedFilterAndRejectMs=") && formatted.contains("acceptControlMs=")
       && formatted.contains("sharedFieldsMs=") && formatted.contains("recycleAndRowGuardMs=")
       && formatted.contains("numericWaitMs=") && formatted.contains("numericBindMs="),
       "post-dispatch log splits resolution and numeric binding into distinct stages");
 s=setup();
 AccessibilityNodeInfo decoration=new AccessibilityNodeInfo("DeliverThat offers and deliveries",new Rect(100,100,800,130));
 s.root.kids.add(decoration);
 AccessibilityNodeInfo failureLabel=new AccessibilityNodeInfo("This offer is no longer",new Rect(100,1700,900,1800));
 failureLabel.desc="available.";
 s.root.kids.add(failureLabel);
 f=read();
 check(f!=null && decoration.boundsReads==0 && failureLabel.boundsReads==0,
       "plain labels require no geometry reads in the shared first-shot index");
 check(hasCurrentNegativeBaseline(f)&&currentNegativeSurfaceBlocksAccept(),
       "the negative surface remains visible even when its text is split across the node");
 AccessibilityNodeInfo field=new AccessibilityNodeInfo("$121.97 0.2 mi Tomorrow at 10:00 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618",new Rect(80,850,900,1000));
 List<IndexedSeedValue> captured=List.of(new IndexedSeedValue(field,field.text,field.desc,field.bounds,true,1,true));
 List<CardText.Piece> capturedPieces=new ArrayList<>();IndexedWitness capturedWitness=new IndexedWitness();
 collectCapturedIndexedEndpointPieces(captured,button,capturedPieces,capturedWitness,1,new HashSet<>());
 check(field.textReads==0&&field.descriptionReads==0&&field.boundsReads==0,"shared discovery and witness reuse captured field metadata without rereading getters");
 List<CardText.Piece> ordinaryPieces=new ArrayList<>();collectIndexedEndpointPieces(List.of(field),button,ordinaryPieces,null,1,new HashSet<>());
 check(capturedPieces.size()==ordinaryPieces.size()&&capturedPieces.size()==1&&capturedPieces.get(0).text.equals(ordinaryPieces.get(0).text)&&capturedWitness.fieldText.get(0).equals(field.text),"captured metadata preserves numeric/address/time evidence and retry witness text");
 capturedWitness.close();
 // Reproduce the goop recovery path: original witness released, same current nodes after loading.
 s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
 rememberAcceptResumeNodes(f,1000);f.indexedRead.witness.close();SystemClock.advance(700);UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
 int beforeNodeQueries=queries.size();FastOfferSnapshot ownedNodes=refreshCurrentOwnedAcceptNodes(f.text,1000);
 check(ownedNodes!=null&&isCurrentPressureResumeSnapshot(ownedNodes,f.text,1000),"active owner can renew every live identity field after processing despite old first-frame age");
 check(queries.size()==beforeNodeQueries+2&&s.root.kids.get(0).refreshCalls>0&&s.root.kids.get(1).refreshCalls>0,"owned node recovery refreshes actual action/numbers with only two negative-surface queries and no numeric/row rediscovery");
 check(refreshCurrentOwnedAcceptNodes(f.text,1001)==null,"another transaction never inherits retained handles");
 OcrMonitorService.pendingAction=1001;check(refreshCurrentOwnedAcceptNodes(f.text,1000)==null,"old owner result loses permission immediately");
 for(int mutation=0;mutation<10;mutation++) {
  s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;rememberAcceptResumeNodes(f,1000);SystemClock.advance(700);UI_GENERATION.incrementAndGet();
  if(mutation==0)s.root.kids.get(1).text="$121.98";
  if(mutation==1)s.root.kids.get(3).text="Other Cafe • 524 Spectrum Center Dr, Irvine, CA 92618";
  if(mutation==2)s.root.kids.get(0).enabled=false;
  if(mutation==3)s.root.kids.get(0).visible=false;
  if(mutation==4)s.root.kids.get(1).refreshOK=false;
  if(mutation==5)s.root.kids.get(0).bounds=new Rect(689,1194,840,1251);
  if(mutation==6)s.root.kids.get(1).text="";
  if(mutation==7)s.root.kids.get(0).windowOnRefresh=true;
  if(mutation==8)s.root.kids.get(1).refreshHook=()->OcrMonitorService.retryGuard="negative";
  if(mutation==9)s.root.kids.add(new AccessibilityNodeInfo("This offer is no longer available.",new Rect(100,1700,900,1800)));
  check(refreshCurrentOwnedAcceptNodes(f.text,1000)==null,"fresh node recovery refuses mutated identity/control/geometry/window/negative "+mutation);
 }
 s=setup();f=read();OcrMonitorService.pendingAction=1000;rememberAcceptResumeNodes(f,1000);clearAcceptResumeNodes();
 check(RESUME_NODES.get()==null&&refreshCurrentOwnedAcceptNodes(f.text,1000)==null,"terminal cleanup releases retained handles and never revives historical offer");
 // Concurrent page publication may replace the receipt during a complete current live read.
 for(int race=0;race<6;race++) {
  s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
  rememberAcceptResumeNodes(f,1000);
  ResumeNodeReceipt originalReceipt=RESUME_NODES.get();
  final int kind=race;final FastOfferSnapshot originalOffer=f;
  s.root.kids.get(1).refreshHook=()-> {
   IndexedReadProof newProof=new IndexedReadProof(originalOffer.indexedRead.rootBounds,
      originalOffer.indexedRead.windowId,UI_GENERATION.get(),1000,SystemClock.elapsedRealtime(),"PAGE_REPLACEMENT");
   String text=kind==1?originalOffer.text.replace("Irvine", "Pasadena"):originalOffer.text;
   if(kind==2)newProof=new IndexedReadProof(new Rect(0,0,1080,2300),originalOffer.indexedRead.windowId,UI_GENERATION.get(),1000,SystemClock.elapsedRealtime(),"RESIZED");
   if(kind==3)newProof=new IndexedReadProof(originalOffer.indexedRead.rootBounds,99,UI_GENERATION.get(),1000,SystemClock.elapsedRealtime(),"OTHER_WINDOW");
   FastOfferSnapshot replacement=new FastOfferSnapshot(text,originalOffer.acceptBounds,new Rect(),true,false,SystemClock.elapsedRealtime(),originalOffer.amount,originalOffer.miles,newProof);
   if(kind==4) RESUME_NODES.set(null);
   else RESUME_NODES.set(new ResumeNodeReceipt(kind==5?1001:1000,replacement,originalReceipt.nodes));
  };
  FastOfferSnapshot result=refreshCurrentOwnedAcceptNodes(f.text,1000);
  check((result!=null)==(race==0),"receipt object replacement preserves only same transaction/window/root/identity "+race);
 }
 // Disabled current control is an observation, never authority or a reason for a broad reread.
 s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
 rememberAcceptResumeNodes(f,1000);SystemClock.advance(700);UI_GENERATION.incrementAndGet();
 s.root.kids.get(0).enabled=false;int beforeDisabledQueries=queries.size();
 check(refreshCurrentOwnedAcceptNodes(f.text,1000)==null && ownedAcceptNodeProcessingObserved(),"live disabled action is observation only, without a snapshot");
 check(queries.size()==beforeDisabledQueries && ownedAcceptNodeRefreshDetail().contains("ACTION_DISABLED"),"disabled node skips both negative queries and explains fallback cause");
 s.root.kids.get(0).enabled=true;UI_GENERATION.incrementAndGet();
 check(refreshCurrentOwnedAcceptNodes(f.text,1000)!=null && !ownedAcceptNodeProcessingObserved(),"new enabled proof immediately clears processing observation, without cooldown");
 // a/e visual guard must overlap, preserving higher rows and visible failures.
 s=setup();queryGate=new CountDownLatch(1);queryEntered=new CountDownLatch(2);gatedQueries=Set.of("a","e");
 final TapAccessibilityService guardService=s;
 FutureTask<Boolean> topGuard=new FutureTask<>(()->noHigherIndexedOfferAction(guardService.root,new Rect(0,0,1080,2400),button.top));
 new Thread(topGuard).start();
 try {check(queryEntered.await(1,TimeUnit.SECONDS),"both visual boundary queries start before either finishes");
 queryGate.countDown();check(topGuard.get(1,TimeUnit.SECONDS),"parallel visual guard accepts coherent current top row");}
 catch(Exception ex){throw new AssertionError(ex);}finally{queryGate=null;gatedQueries=Set.of();}
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("This offer is no longer available.",new Rect(100,1700,900,1800)));
 check(!noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),button.top),"visual guard blocks current negative surface");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Accept",new Rect(689,900,840,957)));
 check(!noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),button.top),"parallel guard preserves upper offer insertion veto");
 // A running ordinary/page index may occupy every shared read slot. Owned renewal is independent.
 s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
 rememberAcceptResumeNodes(f,1000);SystemClock.advance(700);UI_GENERATION.incrementAndGet();
 CountDownLatch busyEntered=new CountDownLatch(4),busyRelease=new CountDownLatch(1);
 List<BoundedReadBatch.Read<String>> held=new ArrayList<>();
 for(int n=0;n<4;n++)held.add(new BoundedReadBatch.Read<String>() {
  public String read(){busyEntered.countDown();try{busyRelease.await();}catch(InterruptedException e){Thread.currentThread().interrupt();}return "done";}
  public void close(){}
 });
 final TapAccessibilityService busyService=s;
 FutureTask<BoundedReadBatch.Result<String>> ordinaryBusy=new FutureTask<>(()->busyService.witnessReadBatch.read(held,5000));
 new Thread(ordinaryBusy).start();
 try {
  check(busyEntered.await(1,TimeUnit.SECONDS),"ordinary page/index pool is fully occupied");
  FastOfferSnapshot independent=refreshCurrentOwnedAcceptNodes(f.text,1000);
  check(independent!=null&&isCurrentPressureResumeSnapshot(independent,f.text,1000),"owned live identity and negative proof complete while all ordinary read slots stay blocked");
  PageOutcomePolicy.Reading independentPage=sampleAcceptPageOutcome(()->true);
  check(independentPage.complete && independentPage.queries==7,"full outcome page query batch completes while the first-shot pool is occupied");

 }catch(Exception ex){throw new AssertionError(ex);}finally{busyRelease.countDown();}
 try{check(ordinaryBusy.get(1,TimeUnit.SECONDS).complete(),"ordinary read retains its own work and finishes after release");}
 catch(Exception ex){throw new AssertionError(ex);}
 // v300 speed-first transition contract: old v295 asserted that ANY layout churn
 // requires async Binder renewal and a queued callback. That queue was removed to
 // prevent lost catering offers. Check the CURRENT dispatch behavior instead:
 // same-owner layout/React redraws keep sending, but negative, paused and real
 // foreground-switch states block. None may add broad Binder reads.
 for(int legacyGate=0;legacyGate<7;legacyGate++) {
  s=setup();f=read();OcrMonitorService.pendingAction=1000;
  OcrMonitorService.pendingText=f.text;rememberAcceptResumeNodes(f,1000);
  OcrMonitorService.pressureActive=true;
  if(legacyGate==1)OcrMonitorService.retryGuard="NEGATIVE_VISIBLE";
  if(legacyGate==2)OcrMonitorService.pressureActive=false;
  if(legacyGate==3)foregroundPackage="other.app";
  if(legacyGate==4)UI_GENERATION.incrementAndGet();
  if(legacyGate==5)PRESSURE_LAYOUT_EPOCH.incrementAndGet();
  if(legacyGate==6)s.root.kids.get(0).enabled=false;
  int oldReads=queries.size(),oldRoots=rootReads;
  tapPressureRetry(f,1000,2,d->{},d->{});drainPressure();
  boolean allowed=(legacyGate==0||legacyGate>=4);
  check(dispatch==(allowed?1:0),"v300 legacy-safe pressure gate "+legacyGate);
  check(queries.size()==oldReads&&rootReads==oldRoots,
       "v300 same-owner gesture must not requery root or values "+legacyGate);
 }
 OcrMonitorService.pressureActive=false;OcrMonitorService.pressureSnapshot=null;
 OcrMonitorService.pressureGuard="";OcrMonitorService.retryGuard="";

 // Real blocked root acquisition must respect the external deadline.
 s=setup();OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;
 rootGate=new CountDownLatch(1);rootEntered=new CountDownLatch(1);
 long wallStart=System.nanoTime();
 PageOutcomePolicy.Reading timedPage=sampleAcceptPageOutcome(()->true);
 long wallMs=TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-wallStart);
 check(!timedPage.complete && timedPage.reason.startsWith("INDEX_") && wallMs<550,
       "blocked root cannot monopolize result lane beyond external deadline");
 rootGate.countDown();rootGate=null;rootEntered=null;
 Thread.sleep(20);
 check(takeAcceptPageRetrySnapshot(OcrMonitorService.pendingText,900)==null,
       "cancelled late root cannot publish a retry receipt");
 s=setup();OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;
 String assigned="$101.04 6.8 mi Today at 11:05 AM Red Robin • 3301 E Main St, Ventura, CA 93003";
 OcrMonitorService.pendingText=assigned;s.root.kids.clear();
 s.root.kids.add(new AccessibilityNodeInfo(assigned,new Rect(80,700,950,1050)));
 s.root.kids.add(new AccessibilityNodeInfo("Begin Delivery",new Rect(80,1090,950,1151)));
 PageOutcomePolicy.Reading assignedPage=sampleAcceptPageOutcome(()->true);
 check(assignedPage.complete && assignedPage.ownedPositive,"assigned detail confirms independently of removed Offer row");
 s.root.kids.get(0).text=assigned.replace("101.04","102.04");
 assignedPage=sampleAcceptPageOutcome(()->true);
 check(!assignedPage.ownedPositive,"different job amount never gets fast confirmation");
 s.root.kids.get(0).text=assigned;s.root.kids.get(1).visible=false;
 assignedPage=sampleAcceptPageOutcome(()->true);
 check(!assignedPage.ownedPositive,"hidden Begin Delivery never gets fast confirmation");

 // Actual v242 race: a thin General-first snapshot gains pickup time during the live read.
 s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
 check(OfferEnrichmentPolicy.pickupKey(f.text).isEmpty(),"repro starts from the thin first-dispatch identity");
 rememberAcceptResumeNodes(f,1000);
 final ResumeNodeReceipt thinReceipt=RESUME_NODES.get();
 final FastOfferSnapshot thinOffer=f;
 final String richOffer="$121.97 0.2 mi Today at 10:00 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";
 s.root.kids.get(3).text="Today at 10:00 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";
 s.root.kids.get(1).refreshHook=()-> {
  IndexedReadProof proof=new IndexedReadProof(thinOffer.indexedRead.rootBounds,thinOffer.indexedRead.windowId,
    UI_GENERATION.get(),1000,SystemClock.elapsedRealtime(),"PAGE_ENRICHED");
  FastOfferSnapshot rich=new FastOfferSnapshot(richOffer,thinOffer.acceptBounds,new Rect(),true,false,
    SystemClock.elapsedRealtime(),thinOffer.amount,thinOffer.miles,proof);
  RESUME_NODES.set(new ResumeNodeReceipt(1000,rich,thinReceipt.nodes));
 };
 FastOfferSnapshot enrichedRenewal=refreshCurrentOwnedAcceptNodes(f.text,1000,true);
 check(enrichedRenewal!=null,"pickup enrichment during current refresh must not cancel the admitted retry: "+ownedAcceptNodeRefreshDetail());

 // No duplicate result sweep: the secondary inspector borrows only a completed primary read.
 s=traceRows(0);int cacheQueries=queries.size(),cacheRoots=rootReads;
 check(observeCurrentOwnedAcceptSnapshot(OWNED,900)==null && queries.size()==cacheQueries && rootReads==cacheRoots,
       "before first page publication an inspector returns without a second Binder sweep");
 followed=sampleAcceptPageOutcome(()->true);cacheQueries=queries.size();cacheRoots=rootReads;
 f=observeCurrentOwnedAcceptSnapshot(OWNED,900);
 check(f!=null && f.acceptBounds.top==1898 && queries.size()==cacheQueries && rootReads==cacheRoots,
       "current cached page can supply only its separate same-owner live receipt");
 check(observeCurrentOwnedAcceptSnapshot(OWNED,900)==null,"enabled page text cannot recreate a consumed click receipt");
 s=traceRows(2);followed=sampleAcceptPageOutcome(()->true);cacheQueries=queries.size();cacheRoots=rootReads;
 for(int i=0;i<10;i++)check(observeCurrentOwnedAcceptSnapshot(OWNED,900)!=null,
       "secondary processing inspection reuses the primary observation");
 check(queries.size()==cacheQueries && rootReads==cacheRoots,"ten secondary readers issue zero extra index/root calls");
 SystemClock.advance(121);
 check(observeCurrentOwnedAcceptSnapshot(OWNED,900)==null,"old page observation expires");
 followed=sampleAcceptPageOutcome(()->true);UI_GENERATION.incrementAndGet();
 check(observeCurrentOwnedAcceptSnapshot(OWNED,900)==null,"UI change invalidates the shared observation");
 s=traceRows(2);sampleAcceptPageOutcome(()->true);WINDOW_TRANSITION_EPOCH.incrementAndGet();
 check(observeCurrentOwnedAcceptSnapshot(OWNED,900)==null,"window transition invalidates the shared observation");
 s=traceRows(2);sampleAcceptPageOutcome(()->true);OcrMonitorService.pendingAction=901;
 check(observeCurrentOwnedAcceptSnapshot(OWNED,901)==null,"new publication never inherits the old observation");
 s=traceRows(2);sampleAcceptPageOutcome(()->true);OcrMonitorService.sentAt++;
 check(observeCurrentOwnedAcceptSnapshot(OWNED,900)==null,"different dispatch cannot borrow an earlier result");

 // Pasadena trace regression: UI_CHANGED alone must not discard the numbered reservation.
 for(int churn=0;churn<4;churn++) {
  s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
  rememberAcceptResumeNodes(f,1000);OcrMonitorService.pressureActive=true;
  final int kind=churn;final AccessibilityNodeInfo churnField=s.root.kids.get(1);
  churnField.refreshHook=()->{churnField.refreshHook=null;UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
   if(kind==1)OcrMonitorService.pressureActive=false;
   if(kind==2)OcrMonitorService.retryGuard="NEGATIVE_VISIBLE";
   if(kind==3)OcrMonitorService.pendingAction=2000;
  };
  UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
  final int[] stopped={0};final String[] retained={""};
  tapPressureRetry(f,1000,4,d->retained[0]=d,d->{stopped[0]++;retained[0]=d;});drainPressure();
  check(dispatch==1&&stopped[0]==0&&churnField.refreshHook!=null,
        "same-owner pressure does not execute stale Binder refresh hooks before send "+churn+":"+retained[0]);
 }
 // A complete split pay/miles/pickup/address proof uses bounded waves rather than five serial Binder reads.
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 10:20 AM",new Rect(80,910,900,935)));
 f=getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true);check(f!=null&&OfferEnrichmentPolicy.pickupKey(f.text).equals("tomorrow-10:20am"),"split pickup source retained in live offer");
 OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;rememberAcceptResumeNodes(f,1000);OcrMonitorService.pressureActive=true;
 UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
 final String[] waveDone={""};tapPressureRetry(f,1000,2,d->waveDone[0]=d,d->waveDone[0]=d);drainPressure();
 check(dispatch==1&&waveDone[0].contains("PRESSURE_CACHED_CTA"),"complete split-field offer skips five live refresh reads during pressure send:"+waveDone[0]);
 // The page reader can add a new time handle after renewal has already copied its source set.
 // A second asynchronous refresh must keep the same admitted retry instead of reporting failure.
 s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
 OcrMonitorService.sentAt=1000;rememberAcceptResumeNodes(f,1000);OcrMonitorService.pressureActive=true;
 final TapAccessibilityService enrichService=s;
 s.root.kids.get(1).refreshHook=()-> {
  enrichService.root.kids.get(1).refreshHook=null;
  enrichService.root.kids.add(new AccessibilityNodeInfo("Today at 10:00 AM",new Rect(80,910,900,935)));
  PageOutcomePolicy.Reading publication=sampleAcceptPageOutcome(()->true);
  check(publication.complete,"new page proof is published during the first live renewal");
 };
 UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
 final int[] renewalFailures={0};final String[] renewalDone={""};
 tapPressureRetry(f,1000,2,d->renewalDone[0]=d,d->{renewalFailures[0]++;renewalDone[0]=d;});
 drainPressure();
 check(dispatch==1 && renewalFailures[0]==0 && renewalDone[0].contains("PRESSURE_CACHED_CTA"),
       "enrichment text update does not force an extra pre-send round trip: "+renewalDone[0]);

 // Enrichment is permitted only when the fields actually read now agree with the newer proof.
 s=setup();f=read();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
 rememberAcceptResumeNodes(f,1000);
 final ResumeNodeReceipt conflictReceipt=RESUME_NODES.get();final FastOfferSnapshot conflictOffer=f;
 s.root.kids.get(3).text="Today at 11:00 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";
 s.root.kids.get(1).refreshHook=()-> {
  IndexedReadProof proof=new IndexedReadProof(conflictOffer.indexedRead.rootBounds,conflictOffer.indexedRead.windowId,
      UI_GENERATION.get(),1000,SystemClock.elapsedRealtime(),"CONFLICTING_PICKUP");
  FastOfferSnapshot other=new FastOfferSnapshot(richOffer,conflictOffer.acceptBounds,new Rect(),true,false,
      SystemClock.elapsedRealtime(),conflictOffer.amount,conflictOffer.miles,proof);
  RESUME_NODES.set(new ResumeNodeReceipt(1000,other,conflictReceipt.nodes));
 };
 check(refreshCurrentOwnedAcceptNodes(f.text,1000,true)==null && ownedAcceptNodeRefreshDetail().equals("PUBLISHED_IDENTITY_CONFLICT"),
       "newly known conflicting pickup time stops instead of relaxing identity to old numbers");
 // A slow primary read does not provoke a second seven-query sweep from the proof lane.
 s=traceRows(2);sampleAcceptPageOutcome(()->true);
 rootGate=new CountDownLatch(1);rootEntered=new CountDownLatch(1);
 FutureTask<PageOutcomePolicy.Reading> heldPrimary=new FutureTask<>(()->sampleAcceptPageOutcome(()->true));
 new Thread(heldPrimary).start();
 try {
  check(rootEntered.await(1,TimeUnit.SECONDS),"primary result reader is actually waiting on its root");
  cacheQueries=queries.size();cacheRoots=rootReads;long joinStarted=System.nanoTime();
  check(observeCurrentOwnedAcceptSnapshot(OWNED,900)!=null,"secondary can use a fresh processing observation while primary is busy");
  check(queries.size()==cacheQueries && rootReads==cacheRoots && TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-joinStarted)<100,
       "busy primary never makes the secondary queue or duplicate Binder work");
 } finally {rootGate.countDown();}
 check(heldPrimary.get(1,TimeUnit.SECONDS).complete,"only the original primary read finishes after release");
 rootGate=rootEntered=null;
 System.out.println(checks+" production indexed first-dispatch/receipt cases passed");
 }}'''
with tempfile.TemporaryDirectory(prefix='csa-index-') as d:
 h=Path(d)/'TapAccessibilityService.java'
 reason=next(line for line in source.splitlines() if 'static final String REJECT_PROOF_CHANGED_BEFORE_CLICK' in line)
 h.write_text(header+reason+'\n'+body+test)
 names=['ActionRowPolicy.java','ButtonLabels.java','PageOutcomePolicy.java','CardText.java','ClaimSuccessSignals.java','PageGuard.java','OfferEnrichmentPolicy.java','PasadenaRuleGuard.java','IndexedReadPolicy.java','FastSnapshotPolicy.java','ActionDispatchPolicy.java','VisualGenerationReboundPolicy.java','IndexedWitnessPolicy.java','RejectDemandPolicy.java','BoundedReadBatch.java','RejectReadProgress.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in names],str(h)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.TapAccessibilityService'],check=True)
