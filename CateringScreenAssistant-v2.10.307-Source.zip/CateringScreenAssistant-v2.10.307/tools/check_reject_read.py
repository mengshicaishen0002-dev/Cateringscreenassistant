#!/usr/bin/env python3
"""Execute production bounded traversal and empty-index proof on synthetic RN hierarchies."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/local/cateringscreenassistant'
text=(src/'TapAccessibilityService.java').read_text()
def block(signature):
 a=text.index(signature); b=text.index('{',a); depth=1; i=b+1
 while depth:
  if text[i]=='{':depth+=1
  elif text[i]=='}':depth-=1
  i+=1
 return text[a:i]
header=r'''package com.local.cateringscreenassistant;
import java.util.*;import java.util.function.*;import java.util.concurrent.atomic.*;import java.util.regex.*;
// Traversal uses a deterministic fake clock; real caller deadlines have a separate production test.
class BoundedReadBatch {
 interface Read<T>{T read();void close();}BoundedReadBatch(int n){}void warmUp(){}
 static class Result<T>{List<T> values;Result(List<T> v){values=v;}boolean complete(){return true;}String reason="OK";}
 <T> Result<T> read(List<? extends Read<T>> jobs,long ms){List<T> out=new ArrayList<>();for(Read<T> job:jobs){try{out.add(job.read());}finally{job.close();}}return new Result<>(out);}
}
class SystemClock {static long ticks,cost,rootCost,indexCost;static long elapsedRealtime(){return ticks;} }
class Rect {int left,top,right,bottom;Rect(){}Rect(int a,int b,int c,int d){left=a;top=b;right=c;bottom=d;}
 boolean isEmpty(){return right<=left||bottom<=top;}void set(Rect r){left=r.left;top=r.top;right=r.right;bottom=r.bottom;} }
class AccessibilityNodeInfo {
 static final int ACTION_CLICK=16;String text="",desc="",pkg="com.deliverthat.driver";
 boolean visible=true,selected,checked,clickable,enabled=true,stale;List<AccessibilityNodeInfo> kids=new ArrayList<>();
 static AccessibilityNodeInfo obtain(AccessibilityNodeInfo n){return n;}
 static int reads,failIndex=-1,indexCalls;static Runnable mutate;
 AccessibilityNodeInfo(String s){text=s;}CharSequence getText(){return text;}CharSequence getContentDescription(){return desc;}
 CharSequence getPackageName(){return pkg;}boolean isVisibleToUser(){return visible;}boolean isClickable(){return clickable;}
 int getActions(){return clickable?16:0;}boolean isEnabled(){return enabled;}boolean isSelected(){return selected;}boolean isChecked(){return checked;}
 void getBoundsInScreen(Rect r){if(stale)throw new IllegalStateException();SystemClock.ticks+=SystemClock.cost;reads++;r.set(new Rect(0,0,1000,1800));}
 int getChildCount(){return kids.size();}AccessibilityNodeInfo getChild(int i){return kids.get(i);}void recycle(){}
 List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String q){indexCalls++;SystemClock.ticks+=SystemClock.indexCost;if(indexCalls==failIndex)return null;
  if(mutate!=null){Runnable m=mutate;mutate=null;m.run();}List<AccessibilityNodeInfo> r=new ArrayList<>();find(this,q.toLowerCase(Locale.US),r);return r;}
 static void find(AccessibilityNodeInfo n,String q,List<AccessibilityNodeInfo> r){if((n.text+" "+n.desc).toLowerCase(Locale.US).contains(q))r.add(n);for(AccessibilityNodeInfo c:n.kids)find(c,q,r);}
}
class OcrMonitorService {static boolean monitoring=true,paused;static boolean isMonitoring(){return monitoring;}static boolean isManualInterventionPaused(){return paused;}}
class Handler {List<Runnable> q=new ArrayList<>();void post(Runnable r){q.add(r);}void postDelayed(Runnable r,long d){q.add(r);}void next(){q.remove(0).run();}}
public class TapAccessibilityService {
 static volatile String lastPresenceProbeDetail="UNOBSERVED";
 static void checkFallbackRead(){}
 static void recordQuickPage(PageGuard.Page page){updatePageHint(page);}
 static final ThreadLocal<RejectReadProgress> REJECT_READ_PROGRESS=new ThreadLocal<>();
 static final ThreadLocal<AccessibilityNodeInfo> REJECT_READ_ROOT=new ThreadLocal<>();
 // This fixture starts with the tree route; separate cases explicitly exercise index-first.
 java.util.concurrent.atomic.AtomicInteger rejectReadTurn=new java.util.concurrent.atomic.AtomicInteger(1);
 final BoundedReadBatch rejectIndexBatch=new BoundedReadBatch(5);final BoundedReadBatch idlePresenceBatch=new BoundedReadBatch(3);final BoundedReadBatch rejectDeadlineReads=new BoundedReadBatch(1);static AtomicLong WINDOW_TRANSITION_EPOCH=new AtomicLong();
 Handler main=new Handler();Handler rejectRecheckWorker=main;static boolean isDeliverThatForeground(){return true;}static boolean hint=true;static boolean hasDeliverThatReplayForegroundHint(){return hint;}
 enum ForegroundState {DELIVERTHAT,OTHER_APP,UNKNOWN} static ForegroundState foreground=ForegroundState.DELIVERTHAT;static ForegroundState deliverThatForegroundState(){return foreground;}
 static final Pattern LIVE_MONEY=Pattern.compile("(?:\\$|USD)\\s*\\d+",Pattern.CASE_INSENSITIVE);
 static final Pattern LIVE_MILES=Pattern.compile("\\d+(?:\\.\\d+)?\\s*mi\\b",Pattern.CASE_INSENSITIVE);
 static final Pattern LIVE_CA_ZIP=Pattern.compile("CA \\d{5}");
 static AtomicLong UI_GENERATION=new AtomicLong();static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>();
 int rootReads;AccessibilityNodeInfo root;AccessibilityNodeInfo getRootInActiveWindow(){rootReads++;SystemClock.ticks+=SystemClock.rootCost;return root;}
 static class ActionHit {Rect bounds;boolean enabled;ActionHit(Rect b,boolean e){bounds=b;enabled=e;}}
 static class FastOfferSnapshot {String text;FastOfferSnapshot(String t){text=t;}}
 static void updatePageHint(PageGuard.Page p){} static boolean matchesAccept(CharSequence s){return s!=null&&(s.toString().equalsIgnoreCase("Accept")||s.toString().equalsIgnoreCase("Claim"));}
 static String lettersOnlyLower(CharSequence s){return s.toString().toLowerCase(Locale.US).replaceAll("[^a-z]","");}
 static boolean safeActionBounds(Rect r,Rect b,boolean a){return true;}static boolean actionNodeReady(AccessibilityNodeInfo n){return n.enabled;}
 static boolean structuralActionShape(AccessibilityNodeInfo n,Rect b,Rect r){return n.clickable;}
 static void addUniqueHit(List<ActionHit> h,Rect b,boolean e){h.add(new ActionHit(b,e));}
 static void addUniquePiece(List<CardText.Piece> p,String s,Rect b){p.add(new CardText.Piece(s,b.left,b.top,b.bottom));}
 static int rejectIndexReads;static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(boolean a,boolean b,long ms){rejectIndexReads++;return null;}
 static FastOfferSnapshot quickTopSnapshotFromProbe(QuickActionProbe p){return p.sawMoney&&p.sawMiles&&p.sawAction?new FastOfferSnapshot("$125.23 4.3 mi Tomorrow at 11:10 AM Cafe • 100 Main St, Los Angeles, CA 90024"):null;}
'''
methods=['    private static boolean relevantRejectIndexText(', '    private static final class IndexedQueryRead', '    private static final class IndexedQueryResult', '    private static AccessibilityNodeInfo rootForRejectRead(', '    private static long rejectReadDeadline(', '    private static final class QuickActionProbe','    public static final class QuickTopResult',
'    public static QuickTopResult getQuickTopOfferSnapshotResult(long softBudgetMs, int maxNodes)',
'    private static QuickTopResult getQuickTopOfferSnapshotResult(long softBudgetMs, int maxNodes,',
'    private static String rejectProbeEvidence(', '    private static void quickCollectActionEvidence(','    private static void noteQuickEvidence(',
'    private enum EmptyIndexStatus {', '    enum OfferPresence {', '    static OfferPresence probeCurrentOffersPresence(', '    private static EmptyIndexStatus readIndexedEmptyOffers(long softBudgetMs,\n            java.util.function.BooleanSupplier mayRun) {', '    private static EmptyIndexStatus readIndexedEmptyOffers(long softBudgetMs,\n            java.util.function.BooleanSupplier mayRun,boolean idleProbe) {', '    private static PageGuard.Page quickPageFromProbe(', '    private static boolean hasIndexedEmptyOffers(long softBudgetMs) {', '    private static boolean hasIndexedEmptyOffers(long softBudgetMs,',
'    private static QuickTopResult readRejectRecheck()', '    private static QuickTopResult readRejectRecheck(String expectedText) {', '    private static QuickTopResult readRejectRecheck(String expectedText,', '    private static QuickTopResult readRejectRecheckWithinBudget(', '    private static String rejectRecheckForegroundBlock()', '    public static void recheckRejectedTop(', '    private static void deliverRejectRecheckTop(']
test=r'''
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static TapAccessibilityService setup(int n,boolean empty){TapAccessibilityService s=new TapAccessibilityService();INSTANCE.set(s);s.rejectDeadlineReads.warmUp();s.idlePresenceBatch.warmUp();s.root=new AccessibilityNodeInfo("");
 for(int i=0;i<n;i++)s.root.kids.add(new AccessibilityNodeInfo("wrapper"));
 AccessibilityNodeInfo tab=new AccessibilityNodeInfo("Offers");tab.selected=true;s.root.kids.add(tab);
 if(empty)s.root.kids.add(new AccessibilityNodeInfo("No offers available"));
 rejectIndexReads=0;SystemClock.ticks=0;SystemClock.cost=0;SystemClock.rootCost=0;SystemClock.indexCost=0;AccessibilityNodeInfo.indexCalls=0;AccessibilityNodeInfo.failIndex=-1;AccessibilityNodeInfo.mutate=null;return s;}
 public static void main(String[] args){
 TapAccessibilityService s=setup(240,true);
 QuickTopResult old=getQuickTopOfferSnapshotResult(45,96);check(old.budgetExceeded&&!old.emptyOffers&&old.visited==96,"reproduce old 96-node false unknown");
 QuickTopResult fixed=readRejectRecheck();check(fixed.emptyOffers&&!fixed.budgetExceeded&&fixed.visited<20,"cheap wrapper-heavy empty page completes: "+fixed.limitReason+" visited="+fixed.visited);
 s=setup(240,true);SystemClock.cost=2;QuickTopResult slow=getQuickTopOfferSnapshotResult(45,1024);
 check(slow.budgetExceeded&&slow.visited<40&&slow.limitReason.startsWith("TIME_LIMIT"),"45ms cap is preserved on slow Binder");
 SystemClock.cost=0;check(hasIndexedEmptyOffers(45),"complete live empty index independent of prefix");
 s=setup(1200,true);fixed=readRejectRecheck();check(fixed.emptyOffers&&fixed.limitReason.startsWith("INDEXED_EMPTY"),"index resolves node-limited empty page");
 s.root.kids.add(new AccessibilityNodeInfo("$125.23 4.3 mi"));check(!hasIndexedEmptyOffers(45),"stale empty label plus live card is not absence");
 s=setup(240,true);s.root.kids.add(new AccessibilityNodeInfo("Accept"));check(!hasIndexedEmptyOffers(45),"action contradicts empty marker");
 s=setup(240,true);s.root.kids.get(240).selected=false;check(!hasIndexedEmptyOffers(45),"unselected Offers is insufficient");
 s=setup(240,false);check(!readRejectRecheck().emptyOffers,"blank transitional page is not empty confirmation");
 s=setup(240,true);s.root.pkg="other.app";check(!readRejectRecheck().emptyOffers,"wrong package cannot confirm");
 s=setup(240,true);AccessibilityNodeInfo.failIndex=2;check(!hasIndexedEmptyOffers(45),"partial failed text index is unknown");
 s=setup(240,true);AccessibilityNodeInfo.mutate=()->UI_GENERATION.incrementAndGet();check(!hasIndexedEmptyOffers(45),"generation change invalidates index proof");
 s=setup(240,true);s.root.stale=true;check(!readRejectRecheck().emptyOffers,"stale tree never confirms absence");
 // Screenshot-defined empty Offers page is a low-cost idle presence result.
 s=setup(240,true);check(probeCurrentOffersPresence(34,()->true)==OfferPresence.EMPTY,"explicit empty Offers goes to monitoring");
 check(AccessibilityNodeInfo.indexCalls==3,"idle gate uses three bounded current-page text queries, never a full tree");
 s=setup(240,true);s.root.kids.add(new AccessibilityNodeInfo("$125.23 4.3 mi"));
 check(probeCurrentOffersPresence(34,()->true)==OfferPresence.PRESENT,"new live offer overrides stale empty text");
 s=setup(240,false);check(probeCurrentOffersPresence(34,()->true)==OfferPresence.UNKNOWN,"unknown transition never counted as empty page");
 s=setup(240,false);s.root.kids.get(240).selected=false;
 s.root.kids.add(new AccessibilityNodeInfo("No offers available"));
 check(probeCurrentOffersPresence(34,()->true)==OfferPresence.EMPTY,
       "React-Native omission of selected/header bits does not hide explicit empty Offers");

 // An occupied Jobs tab remains navigable: prices shown in existing jobs are NOT live Offers.
 s=setup(240,false);s.root.kids.get(240).selected=false;
 s.root.kids.add(new AccessibilityNodeInfo("Deliveries"));
 AccessibilityNodeInfo jobsTab=new AccessibilityNodeInfo("Jobs");jobsTab.selected=true;s.root.kids.add(jobsTab);
 s.root.kids.add(new AccessibilityNodeInfo("$250.00 4.3 mi job scheduled tomorrow"));
 check(probeCurrentOffersPresence(34,()->true)==OfferPresence.JOBS_LIST,
       "populated Jobs tab with existing job pricing triggers return, not offer dispatch");
 s=setup(240,true);s.root.pkg="com.other";check(probeCurrentOffersPresence(34,()->true)==OfferPresence.UNKNOWN,"other foreground page is not an empty Offers proof");
 check(RejectProbePolicy.maxReads()==10&&RejectProbePolicy.retryMs(1)==80&&RejectProbePolicy.retryMs(20)==240,"finite work and backoff");

 OcrMonitorService.paused=true;
 check(rejectRecheckForegroundBlock().equals("MANUAL_PAUSE"),"manual pause is explicit");
 OcrMonitorService.paused=false;OcrMonitorService.monitoring=false;
 check(rejectRecheckForegroundBlock().equals("MONITOR_STOPPED"),"stopped service differs from leaving app");
 OcrMonitorService.monitoring=true;hint=false;foreground=ForegroundState.OTHER_APP;
 check(rejectRecheckForegroundBlock().equals("OUTSIDE_DELIVERTHAT"),"other app waits for foreground return");
 foreground=ForegroundState.UNKNOWN;
 check(rejectRecheckForegroundBlock().equals("WINDOW_UNREADABLE"),"unknown window remains inconclusive");
 foreground=ForegroundState.DELIVERTHAT;hint=true;
 s=setup(240,true);final int[] outcomes=new int[4];final boolean[] run={true};
 recheckRejectedTop("$29 2.6 mi",false,top->outcomes[0]++,gone->outcomes[1]++,unknown->outcomes[2]++,()->run[0],()->outcomes[3]++,(ms,b)->{},tree->{});
 s.main.next();check(outcomes[1]==0&&s.main.q.size()==1,"first empty read alone does not finalize Reject");
 int readsAtFirstEmpty=rejectIndexReads;
 s.rejectReadTurn.set(1);
 s.main.next();check(outcomes[1]==1,"two fresh complete empty reads finalize Reject");
 check(rejectIndexReads==readsAtFirstEmpty,"second empty snapshot does not run a Reject action index first");
 Arrays.fill(outcomes,0);s=setup(240,true);s.rejectReadTurn.set(1);
 recheckRejectedTop("$29 2.6 mi",true,top->outcomes[0]++,gone->outcomes[1]++,diagnostic->outcomes[2]++,()->true,()->{},(ms,b)->{},tree->{});
 s.main.next();check(rejectIndexReads==0,"processing observation starts with empty index even on Reject-first turn");
 UI_GENERATION.incrementAndGet();
 s.main.next();check(outcomes[1]==0&&outcomes[2]==1,"different UI generations cannot combine into empty confirmation");
 Arrays.fill(outcomes,0);s=setup(240,true);
 recheckRejectedTop("$29 2.6 mi",true,top->outcomes[0]++,gone->outcomes[1]++,diagnostic->outcomes[2]++,()->true,()->{},(ms,b)->{},tree->{});
 s.main.next();WINDOW_TRANSITION_EPOCH.incrementAndGet();
 s.main.next();check(outcomes[1]==0&&outcomes[2]==1,"different windows cannot combine into empty confirmation");
 Arrays.fill(outcomes,0);s=setup(240,true);
 recheckRejectedTop("$29 2.6 mi",false,top->outcomes[0]++,gone->outcomes[1]++,unknown->outcomes[2]++,()->run[0],()->outcomes[3]++,(ms,b)->{},tree->{});
 s.main.next();s.root.kids.add(new AccessibilityNodeInfo("$125.23 4.3 mi, Los Angeles, CA 90024"));s.root.kids.add(new AccessibilityNodeInfo("Accept"));
 s.main.next();check(outcomes[1]==1&&outcomes[0]==0,"new top between empty reads is departure, never a retry target");
 Arrays.fill(outcomes,0);s=setup(240,true);
 recheckRejectedTop("$29 2.6 mi",false,top->outcomes[0]++,gone->outcomes[1]++,unknown->outcomes[2]++,()->run[0],()->outcomes[3]++,(ms,b)->{},tree->{});
 s.main.next();run[0]=false;s.main.next();check(outcomes[1]==0&&outcomes[3]==1,"new demand cancels delayed confirmation read");run[0]=true;
 Arrays.fill(outcomes,0);s=setup(240,true);
 recheckRejectedTop("$29 2.6 mi",false,top->outcomes[0]++,gone->outcomes[1]++,unknown->outcomes[2]++,()->run[0],()->outcomes[3]++,(ms,b)->{},tree->{});
 s.main.next();s.root=null;s.main.next();check(outcomes[1]==0&&outcomes[2]==1,"null second root remains unknown");

 s=setup(240,false);AccessibilityNodeInfo nums=new AccessibilityNodeInfo("$125.23 4.3 mi, Los Angeles, CA 90024");
 AccessibilityNodeInfo early=new AccessibilityNodeInfo("");early.clickable=true;s.root.kids.add(0,nums);s.root.kids.add(1,early);
 QuickTopResult prefix=getQuickTopOfferSnapshotResult(45,1024),complete=readRejectRecheck();
 check(prefix.visited<10&&complete.visited>240,"Reject final-tail bypasses foreground early-stop heuristic");
 s=setup(10,true);AccessibilityNodeInfo blank=new AccessibilityNodeInfo("");blank.clickable=true;s.root.kids.add(blank);
 fixed=readRejectRecheck();check(fixed.emptyOffers&&AccessibilityNodeInfo.indexCalls==5&&rejectIndexReads==1,"complete explicit empty page ignores unlabeled structural chrome with indexed evidence");
 check(EmptyOffersPolicy.isExplicitEmpty("You have no offers available.")&&EmptyOffersPolicy.isExplicitEmpty("No offers available at this time"),"explicit empty sentence variants");
 check(!EmptyOffersPolicy.isExplicitEmpty("Loading offers")&&!EmptyOffersPolicy.isExplicitEmpty("No offers available $125.23 4.3 mi"),"loading or mixed card text is not empty proof");
 s=setup(176,true);for(int i=0;i<2;i++){AccessibilityNodeInfo chrome=new AccessibilityNodeInfo("");chrome.clickable=true;s.root.kids.add(chrome);}
 fixed=readRejectRecheck();check(fixed.emptyOffers&&fixed.visited<10&&AccessibilityNodeInfo.indexCalls==5&&rejectIndexReads==1,"field trace: 180-ish nodes, two blank controls, explicit complete empty; without wrapper traversal");
 Arrays.fill(outcomes,0);
 recheckRejectedTop("$48.99 7.9 mi",false,top->outcomes[0]++,gone->outcomes[1]++,unknown->outcomes[2]++,()->true,()->{},(ms,b)->{},tree->{});
 s.main.next();check(outcomes[1]==0,"structural chrome still requires a second fresh empty read");s.main.next();check(outcomes[1]==1,"two complete empty frames with blank controls finalize departure");
 s=setup(10,true);s.root.kids.add(new AccessibilityNodeInfo("Begin to Delivery"));check(!readRejectRecheck().emptyOffers,"assigned-job CTA contradicts stale empty label");
 s=setup(10,true);s.root.kids.add(new AccessibilityNodeInfo("Delivery Timeline"));check(!readRejectRecheck().emptyOffers,"job timeline prevents empty proof");
 s=setup(10,true);s.root.kids.add(new AccessibilityNodeInfo("Pickup instructions"));check(!readRejectRecheck().emptyOffers,"job instructions prevent empty proof");
 s=setup(10,true);s.root.kids.add(new AccessibilityNodeInfo("Ignore"));check(!readRejectRecheck().emptyOffers,"semantic Reject always vetoes empty proof");
 s=setup(10,true);s.root.kids.get(10).selected=false;check(!readRejectRecheck().emptyOffers,"tree empty proof needs selected Offers, not sentence alone");
 s=setup(1200,true);final boolean[] priority={true};AccessibilityNodeInfo.mutate=()->priority[0]=false;
 fixed=readRejectRecheck("$48.99 7.9 mi",()->priority[0],false);
 check(!fixed.emptyOffers&&fixed.limitReason.startsWith("YIELD_PRIORITY")&&AccessibilityNodeInfo.indexCalls==5&&rejectIndexReads==1,"new-card priority during independent index stops before further queries/Reject index");
 s=setup(1200,true);fixed=readRejectRecheck("$48.99 7.9 mi",()->false,false);check(fixed.visited==0&&AccessibilityNodeInfo.indexCalls==0,"existing priority prevents physical reads");
 s=setup(10,false);check(!hasIndexedEmptyOffers(45)&&AccessibilityNodeInfo.indexCalls==5,"loading/nonempty index exits after missing positive anchor query");
 s=setup(1200,true);check(hasIndexedEmptyOffers(45)&&AccessibilityNodeInfo.indexCalls==5,"independent empty proof keeps full vocabulary with five grouped index queries");
 for(String bad:new String[]{"Claim","Decline","Ignored","Begin to Delivery","Pickup instructions","Delivery Timeline","Approver Name","NUID","GL String","USD125.23","4.3 mi","Restore"}){
  s=setup(1200,true);AccessibilityNodeInfo n=new AccessibilityNodeInfo(bad);if(bad.equals("Ignored"))n.selected=true;s.root.kids.add(n);
  check(!hasIndexedEmptyOffers(45),"grouped negative query still catches "+bad);
 }
 s=setup(180,true);s.root.kids.get(180).selected=false;s.root.kids.add(new AccessibilityNodeInfo("Deliveries"));s.root.kids.add(new AccessibilityNodeInfo("Jobs"));
 fixed=readRejectRecheck();check(fixed.emptyOffers&&AccessibilityNodeInfo.indexCalls==5,"complete current hub/Offers/Jobs chrome substitutes for absent RN selected bit");
 s=setup(1200,true);s.root.kids.get(1200).selected=false;s.root.kids.add(new AccessibilityNodeInfo("Deliveries Jobs Offers"));check(hasIndexedEmptyOffers(45),"independent index accepts full current hub chrome without selected bit");
 s.root.kids.add(new AccessibilityNodeInfo("Begin Delivery"));check(!hasIndexedEmptyOffers(45),"hub chrome never overrides assigned-job CTA");
 s=setup(10,true);SystemClock.rootCost=70;SystemClock.indexCost=10;check(hasIndexedEmptyOffers(80),"slow root acquisition no longer consumes the entire independent index phase budget");
 s=setup(1200,true);SystemClock.indexCost=30;fixed=readRejectRecheck();check(fixed.budgetExceeded&&!fixed.emptyOffers&&fixed.limitReason.startsWith("TOTAL_READ_BUDGET")&&rejectIndexReads==1,"unfinished empty index does not append another Reject index phase");

 Arrays.fill(outcomes,0);
 String driftA="Est. $7.75 O 0.7 mi (-3 mins) Tomorrow at 7:00 AM Corner Bakery Cafe • 111S Westlake Blvd, Westlake Village, CA 91362, United States";
 String driftB=driftA.replace("7.75","7.70").replace("Westlake Blvd","Westla Blvd");
 deliverRejectRecheckTop(driftA,new FastOfferSnapshot(driftB),top->outcomes[0]++,gone->outcomes[1]++,unknown->outcomes[2]++);
 check(outcomes[0]==0 && outcomes[1]==0 && outcomes[2]==1,"OCR drift neither proves departure nor authorizes rescue with old numbers");
 // Production starts with index-first; the second turn uses the independent traversal route.
 s=setup(1200,true);s.rejectReadTurn.set(0);fixed=readRejectRecheck();
 check(fixed.emptyOffers && fixed.limitReason.startsWith("INDEXED_EMPTY_FIRST") && s.rootReads==1,"index-first resolves wrapper-heavy empty page with one root acquisition");
 s=setup(10,true);s.rejectReadTurn.set(0);SystemClock.rootCost=40;
 fixed=readRejectRecheck();check(fixed.emptyOffers && s.rootReads==1,"single total deadline allows a cheap complete index after root acquisition");
 s=setup(10,true);s.rejectReadTurn.set(0);SystemClock.rootCost=70;
 fixed=readRejectRecheck();check(fixed.budgetExceeded && !fixed.emptyOffers && s.rootReads==1 && fixed.limitReason.contains("rootMs=70"),"slow root consumes shared deadline and reports its phase, never empty proof");
 s=setup(10,false);s.rejectReadTurn.set(0);fixed=readRejectRecheck();
 check(s.rootReads==1 && !fixed.emptyOffers,"index miss and traversal fallback reuse one live root in the same probe");
 s=setup(240,false);s.root.kids.add(new AccessibilityNodeInfo("Deliveries"));s.root.kids.add(new AccessibilityNodeInfo("Jobs"));
 fixed=readRejectRecheck();check(fixed.emptyOffers && fixed.visited<20,"selected complete hub with no offer/action proves indexed absence without wrapper walk");
 s.root.kids.add(new AccessibilityNodeInfo("Loading please wait"));check(!hasIndexedEmptyOffers(45),"loading hub never proves absence");
 System.out.println(checks+" production Reject traversal/index/lifecycle cases passed");
 }
}'''
with tempfile.TemporaryDirectory(prefix='reject-read-') as d:
 temp=Path(d); h=temp/'TapAccessibilityService.java';reason=next(line for line in text.splitlines() if 'static final String REJECT_RECHECK_TOP_CHANGED' in line)
 h.write_text(header+reason+'\n'+'\n'.join(block(m) for m in methods)+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',str(temp),*[str(src/n) for n in ['CardText.java','ButtonLabels.java','PageGuard.java','ClaimSuccessSignals.java','QuickEvidencePolicy.java','RejectProbePolicy.java','RejectDemandPolicy.java','OfferEnrichmentPolicy.java','RejectConfirmPriorityPolicy.java','EmptyOffersPolicy.java','RejectReadProgress.java']],str(h)],check=True)
 subprocess.run(['java','-cp',str(temp),'com.local.cateringscreenassistant.TapAccessibilityService'],check=True)
