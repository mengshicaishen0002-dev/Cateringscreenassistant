"""Compile the production release method; exercise evidence arriving after inspector decision."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text()
a=s.index('    private synchronized void finishPendingClaimLoss(');b=s.index('    private void armPostTerminalJobVerification(',a);method=s[a:b]
a=s.index("    private boolean preserveVisibleAcceptLoading(");b=s.index("    public static String acceptLoadingRetryBlock(",a);method+=s[a:b]
head='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;
class CommitHarness {
 static class SystemClock{static long elapsedRealtime(){return 3500;}static long uptimeMillis(){return 3500;}}
 static class TapAccessibilityService{static long outcomeWindowEpoch(){return 1;}static void invalidateDecisionEvidence(){}static boolean detail,jobs;static boolean recentAcceptedJobDetailMatches(String s,long at){return detail;}static boolean jobsBadgeIncreasedSince(int x){return jobs;}}
 static class ClaimSuccessAlert{static void notifyVerificationRequired(Object h,String t,String e,long owner){}}
 enum SerialAction{ACCEPT,NONE}SerialAction serialTopAction=SerialAction.ACCEPT;
 String serialTopText="$88.40 0.4 mi Today at 5:00 PM Mendocino Farms • 4531 Hollywood Blvd, Los Angeles, CA 90027",negative="",positive="";
 long serialTopActionAt=1000,rejectProcessingConfirmedAt,acceptProcessingConfirmedAt,pendingAcceptMissingSince,pendingAcceptTerminalProbeAt,pendingJobDetailCandidateAt,cooldownUntil,accessibilityActionHoldUntil,lastReadableFastScan,lastScan;
 long spinnerObservedAt,lastSpinnerFrameAt,spinnerCandidateAt,pressureOwner=1000,pressureEpoch=1,spinnerWindowEpoch=1;int pendingAcceptJobsBaseline,acceptPageProbeCount=19;long acceptPageProbeStartedAt=1000;
 String pendingJobDetailCandidateIdentity="";AtomicLong claimEpoch=new AtomicLong(1),scanGeneration=new AtomicLong(1);
 static final long UNKNOWN_REAPPEAR_EVIDENCE_TTL_MS=60000,ACCEPT_LATE_TAIL_WINDOW_MS=5000;
 Map<String,String> terminalLossDecisionText=new HashMap<>(),unknownReappearDecisionText=new HashMap<>();Map<String,Long> unknownReappearEvidenceUntil=new HashMap<>();
 List<String> reports=new ArrayList<>();int successes,marks,retirements,tails,probes,tasks,recoveries;boolean canCommit=true,allowProbe;
 class Handler{void postDelayed(Runnable r,long ms){tasks++;}}Handler fastWorker=new Handler();
 PageOutcomePolicy.Tracker tracker=new PageOutcomePolicy.Tracker(1000,serialTopText,null,false);
 PageOutcomePolicy.Tracker pageTracker(long at){return allowProbe?new PageOutcomePolicy.Tracker(1000,serialTopText,null,false):tracker;}
 String acceptScopedTerminalOutcomeSince(long at){return negative;}String acceptScopedOutcomeSince(long at){return positive;}
 boolean isBoundPositiveClaimOutcome(String t,String p,long at){return !p.isEmpty();}
 void confirmPendingClaimSuccess(String t,String p){successes++;serialTopAction=SerialAction.NONE;}
 void scheduleAcceptPageProbe(long at){probes++;}void expireUnboundAcceptOutcome(String t,long e,long at){}
 boolean canCommitAcceptTerminalLoss(String t,String e){return canCommit;}
 String acceptOutcomeDiagnostic(long at){return tracker.diagnostic();}
 java.util.function.Consumer<String> offerReporter(String t){return reports::add;}
 String acceptResultTiming(String t,String state,long now){return state;}
 boolean quickDecisionTextComplete(String t){return true;}
 ClaimBudget claimBudget=new ClaimBudget();
 void consumeAcceptSuppressionSummary(){}void armPostTerminalJobVerification(String t,long a,int b,long n){}
 AcceptAttemptAudit acceptAudit=new AcceptAttemptAudit();
 PageOutcomePolicy.Tracker acceptPageTracker=tracker;
 java.util.concurrent.Executor logWriter=Runnable::run;
 String engineVersion="test";
 String ruleSummary(String t){return "";}
 void updateOfferStatus(String s,String t,String rules){reports.add(s);}
 java.util.function.Consumer<String> navigationReport;
 void scheduleUnavailableCardRetirement(String t,long a,int n,java.util.function.Consumer<String> report){retirements++;navigationReport=report;}void scheduleLateAcceptTail(String t,long a,int b,long until,int n){tails++;}
 void returnToOffersAfterUnavailable(String text,java.util.function.Consumer<String> report){recoveries++;}
 void requestImmediateFastCheck(long n){}
 boolean verifiedAcceptRetryMatches(String text){return false;}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static CommitHarness fresh(){TapAccessibilityService.detail=false;TapAccessibilityService.jobs=false;return new CommitHarness();}
'''
tests='''public static void main(String[] args)throws Exception{
 CommitHarness h=fresh();h.negative="offer unavailable";h.tracker.bound=h.negative;h.tracker.status="CONFIRMED_PAGE_EDGE";
 h.acceptAudit.begin(1000,h.serialTopText);h.acceptAudit.dispatched(1000,1006);
 String id=CardText.identity(h.serialTopText);h.claimBudget.reserve(id,h.serialTopText,1000);
 h.finishPendingClaimLoss(h.serialTopText,"older unknown decision",false);
 check(h.serialTopAction==SerialAction.NONE,"confirmed unavailable releases the original transaction");
 h.acceptAudit.begin(3000,"other");
 h.navigationReport.accept("UNAVAILABLE_AUTO_RETURN");
 check(h.reports.stream().anyMatch(s->s.startsWith("UNAVAILABLE_AUTO_RETURN；TX=1000,dispatchCount=1")),"recovery keeps the original dispatch audit");
 check(h.retirements==1&&h.tails==0,"new terminal proof upgrades UNKNOWN at commit");
 check(h.reports.stream().noneMatch(x->x.startsWith("ACCEPT_UNKNOWN")),"confirmed edge never logged UNKNOWN");
 for(int kind=0;kind<3;kind++){h=fresh();h.negative="offer unavailable";if(kind==0)h.positive="success";if(kind==1)TapAccessibilityService.detail=true;if(kind==2)TapAccessibilityService.jobs=true;
 h.finishPendingClaimLoss(h.serialTopText,"unknown",false);check(h.successes==1&&h.retirements==0&&h.marks==0,"positive wins pre-release "+kind);}
 h=fresh();h.spinnerObservedAt=1100;h.lastSpinnerFrameAt=3470;
 h.finishPendingClaimLoss(h.serialTopText,"unknown",false);
 check(h.serialTopAction==SerialAction.ACCEPT&&h.probes==1&&h.tasks==0&&h.tails==0,"live spinner preserves the original owner");
 h=fresh();h.spinnerObservedAt=1100;h.lastSpinnerFrameAt=3200;
 h.finishPendingClaimLoss(h.serialTopText,"unknown",false);
 check(h.serialTopAction==SerialAction.NONE&&h.tails==1,"stale spinner does not hold new offers");
 h=fresh();h.finishPendingClaimLoss(h.serialTopText,"unknown",false);check(h.marks==0&&h.tails==1&&h.retirements==0,"unproved state remains UNKNOWN without navigation");
 h=fresh();h.tracker=new PageOutcomePolicy.Tracker(1000,h.serialTopText,new PageOutcomePolicy.Baseline(1,2,3,900,950,true,false),true);
 String replacement=h.serialTopText.replace("88.40","19.00");
 h.tracker.observe(new PageOutcomePolicy.Reading(1,3,3200,3210,true,false,"",replacement,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),3210);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,3,3300,3310,true,false,"",replacement,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),3310);
 h.tracker.requestDepartureOutcomeProbe(3450);
 h.finishPendingClaimLoss(h.serialTopText,"clean replacement holds the foreground",false);
 check(h.serialTopAction==SerialAction.NONE&&h.probes==0&&h.tasks==0&&h.tails==1&&h.retirements==0,
     "clean new offer skips old read-only grace and tracks old outcome in background");
 h=fresh();h.allowProbe=true;h.acceptPageProbeCount=1;h.finishPendingClaimLoss(h.serialTopText,"unknown",false);check(h.serialTopAction==SerialAction.ACCEPT&&h.probes==1&&h.tasks==1,"remaining proof budget keeps transaction");
 h=fresh();h.finishPendingClaimLoss(h.serialTopText.replace("88.40","89.40"),"unknown",false);check(h.serialTopAction==SerialAction.ACCEPT&&h.reports.isEmpty(),"foreign card cannot release owner");
 h=fresh();h.serialTopAction=SerialAction.NONE;h.finishPendingClaimLoss(h.serialTopText,"unknown",false);check(h.reports.isEmpty(),"released owner ignores stale finish");
 // Deterministic worker ordering: a finished page publication owns the lock before UNKNOWN.
 final CommitHarness owner=fresh();java.util.concurrent.CountDownLatch locked=new java.util.concurrent.CountDownLatch(1),finishReady=new java.util.concurrent.CountDownLatch(1);
 Thread publisher=new Thread(()->{synchronized(owner){locked.countDown();try{finishReady.await();}catch(InterruptedException e){throw new RuntimeException(e);}owner.negative="offer unavailable";owner.tracker.bound=owner.negative;owner.tracker.status="CONFIRMED_PAGE_EDGE";}});
 publisher.start();locked.await();Thread finisher=new Thread(()->{finishReady.countDown();owner.finishPendingClaimLoss(owner.serialTopText,"stale decision",false);});finisher.start();publisher.join();finisher.join();
 check(owner.retirements==1&&owner.tails==0,"page commit cannot race foreground release");
 h=fresh();h.acceptPageProbeCount=1;
 h.tracker.observe(new PageOutcomePolicy.Reading(1,4,3300,3310,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),3310);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,4,3400,3410,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),3410);
 h.finishPendingClaimLoss(h.serialTopText,"unbound prompt",false);
 check(h.serialTopAction==SerialAction.NONE&&h.recoveries==1&&h.retirements==0&&h.tails==1,"two fresh unbound prompts recover navigation while remaining UNKNOWN, never Reject");
 h=fresh();h.tracker.observe(new PageOutcomePolicy.Reading(1,4,3400,3410,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),3410);
 h.finishPendingClaimLoss(h.serialTopText,"single prompt",false);check(h.recoveries==0,"one prompt cannot force navigation");
 h=fresh();h.tracker.observe(new PageOutcomePolicy.Reading(1,4,3300,3310,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),3310);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,4,3400,3410,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),3410);
 TapAccessibilityService.detail=true;h.finishPendingClaimLoss(h.serialTopText,"unbound prompt",false);
 check(h.successes==1&&h.recoveries==0,"new success wins even over confirmed unbound prompt recovery");
 System.out.println(checks+" production Accept commit/race cases passed");}}
'''
# Publication must share this exact lock and recheck ownership inside it after sampling.
pub=s[s.index('                // Publish page evidence'):s.index('                String detail=tracker')]
assert 'synchronized (OcrMonitorService.this)' in pub
assert pub.index('serialTopActionAt!=actionAt')<pub.index('tracker.observe(')
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'CommitHarness.java';f.write_text(head+method+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d]+[str(src/n) for n in ['CardText.java','OfferEnrichmentPolicy.java','ClaimSuccessSignals.java','PageOutcomePolicy.java','AcceptAttemptAudit.java','ClaimBudget.java']]+[str(f)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.CommitHarness'],check=True)
