#!/usr/bin/env python3
"""Prove new Offers publications are not blocked by old unavailable history.
Executes the actual v2.10.291 current-card safety fence, plus source invariants.
"""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()

def block(sig):
    start=s.index(sig);cur=s.index('{',start)+1;depth=1
    while depth:
        depth+=(s[cur]=='{')-(s[cur]=='}');cur+=1
    return s[start:cur]

for obsolete in ['isTerminalLossSuppressed(', 'isUnavailableTombstoned(',
                 'isUnavailableNumericTombstoned(', 'rearmUnavailableRebroadcast(',
                 'scheduleUnavailableCleanRecovery(', 'getIndexedUnavailableRebroadcastSnapshot(',
                 'fuseUnavailableRebroadcastFromIndexedAction(',
                 'fuseReappearanceDecision(']:
    assert obsolete not in s, 'obsolete order-history code still active: '+obsolete
assert s.count('if(TapAccessibilityService.currentNegativeSurfaceBlocksAccept())')==1
assert 'private static final long FAST_CHECK_INTERVAL_MS = 12L;' in s or 'HotOfferScanPolicy.heartbeatDelay(false)' in s
assert s.count('service.claimBudget.available(')>10, 'first-dispatch gating unintentionally altered'

h='''package com.local.cateringscreenassistant;
import java.util.*;
class TapAccessibilityService{
 static boolean negative;
 static boolean currentNegativeSurfaceBlocksAccept(){return negative;}
}
public class LivePublicationHarness{
 static int checks;
 static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 RejectSequence rejectSequence=new RejectSequence();RejectTerminalGate rejectTerminalGate=new RejectTerminalGate();
 static class RejectConfirmState {String text,id;long token;
  RejectConfirmState(String t,long n){text=t;id=CardText.identity(t);token=n;}}
 Map<String,RejectConfirmState> rejectConfirmStates=new HashMap<>();
'''
t='''public static void main(String[] args){
 String old="$112.09 6.9 mi Tomorrow at 11:15 AM Mendocino Farms • 13790 Jamboree Rd Ste 4, Irvine, CA 92602";
 String next="$140 2 mi Tomorrow at 10:00 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";
 String id=CardText.identity(old);LivePublicationHarness gate=new LivePublicationHarness();
 TapAccessibilityService.negative=true;
 check(gate.isFinalOcrAcceptBlocked(old,2000L),"live negative UI blocks old card");
 check(gate.isFinalOcrAcceptBlocked(next,2000L),"live negative UI blocks unrelated card");
 TapAccessibilityService.negative=false;
 for(int i=0;i<100;i++){
   check(!gate.isFinalOcrAcceptBlocked(old,2001L+i),"same order can be freshly attempted on any clear publication "+i);
   check(!gate.isFinalOcrAcceptBlocked(next,2001L+i),"different order independently eligible "+i);
 }
 gate.rejectSequence.reserveFirstIfReady(id,1000L);
 check(gate.isFinalOcrAcceptBlocked(old,1100L),"current owned Reject blocks same card");
 check(!gate.isFinalOcrAcceptBlocked(next,1100L),"owned Reject cannot block unrelated offer");
 gate.rejectSequence.forget(id);
 check(!gate.isFinalOcrAcceptBlocked(old,1101L),"completed Reject does not create history filter");
 long token=gate.rejectTerminalGate.begin(id);
 gate.rejectConfirmStates.put(id,new RejectConfirmState(old,token));
 check(gate.isFinalOcrAcceptBlocked(old,2000L),"active background Reject remains fenced");
 gate.rejectTerminalGate.invalidate(id,token);
 check(!gate.isFinalOcrAcceptBlocked(old,2001L),"released transaction permits fresh observation");
 System.out.println(checks+" current-publication/surface/Reject cases passed");
}}
'''
with tempfile.TemporaryDirectory(prefix='csa-live-publication-') as d:
    java=Path(d)/'LivePublicationHarness.java'
    java.write_text(h+'\n'.join([block('    private String acceptCardSafetyReason('),block('    private boolean isFinalOcrAcceptBlocked(')])+t)
    subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/(n+'.java')) for n in ['CardText','OfferEnrichmentPolicy','RejectDemandPolicy','RejectSequence','RejectTerminalGate','ClaimSuccessSignals']],str(java)],check=True)
    subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.LivePublicationHarness'],check=True)
