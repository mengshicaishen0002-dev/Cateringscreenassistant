from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';ocr=(src/'OcrMonitorService.java').read_text();tap=(src/'TapAccessibilityService.java').read_text()
def block(s,sig):
 a=s.index(sig);b=s.index('{',a);i=b+1;d=1
 while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
foreground=block(tap,'    public static ForegroundState deliverThatForegroundState()')
methods='\n'.join(block(ocr,n) for n in ['    private boolean yieldDeepScanDuringUnavailableReturn(', '    private boolean finishUnavailableReturn(', '    private void expireUnavailableReturn(', '    private void returnToOffersAfterUnavailable(String originalText, int attempt,', '    private boolean stopPostClaimNavigationIfNeeded('])
head='''import java.util.*;import java.util.concurrent.atomic.*;import java.util.function.*;
class NavigationHarness {
 static class SystemClock{static long now=1000;static long elapsedRealtime(){return now;}static long uptimeMillis(){return now;}}
 static class AccessibilityNodeInfo{String pkg="com.deliverthat.driver";int recycled;CharSequence getPackageName(){return pkg;}void recycle(){recycled++;}}
 static class TapAccessibilityService{
 enum ForegroundState{DELIVERTHAT,OTHER_APP,UNKNOWN}
 static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>(new TapAccessibilityService());static AccessibilityNodeInfo root=new AccessibilityNodeInfo();static boolean throwsRead,offers,begin,unavailable,jobs,dropCallback,gesture;static int clicks;
 AccessibilityNodeInfo getRootInActiveWindow(){if(throwsRead)throw new IllegalStateException();return root;}
'''
mid='''static class Rect{boolean empty;boolean isEmpty(){return empty;}}
static class FastOfferSnapshot {boolean acceptEnabled=true,rejectEnabled;Rect acceptBounds=new Rect(),rejectBounds=new Rect();String text="new";}
static boolean hasFreshBeginDeliveryOcr(String s){return begin;}static boolean liveBeginDeliveryMatches(String s){return begin;}
 enum OffersNavigationSurface { OFFERS, JOBS, IGNORED, STALE_OFFER, DELIVERY, UNKNOWN }
 static OffersNavigationSurface readOffersNavigationSurface(boolean requireClearPage){
  return jobs?OffersNavigationSurface.JOBS:unavailable?OffersNavigationSurface.STALE_OFFER:offers?OffersNavigationSurface.OFFERS:OffersNavigationSurface.UNKNOWN;
 }
 static boolean clickOffersRecoveryNavigation(boolean preferred, BooleanSupplier mayNavigate, Consumer<String> ok,Consumer<String> fail){if(!mayNavigate.getAsBoolean())return false;clicks++;gesture=preferred;if(!dropCallback)ok.accept("sent");return true;}}
 static final long UNAVAILABLE_RETURN_DEADLINE_MS=1000,UNAVAILABLE_RETURN_OBSERVE_MS=350,POST_CLAIM_NAVIGATION_WATCHDOG_MS=10000;static final int UNAVAILABLE_RETURN_MAX_CLICKS=4;
 enum SerialAction{NONE,ACCEPT}SerialAction serialTopAction=SerialAction.NONE;long unavailableNavigationUntil=11000,lastReadableFastScan,lastScan;
 AtomicLong unavailableReturnEpoch=new AtomicLong(1),postClaimNavigationEpoch=new AtomicLong(1);boolean monitorReady=true,manualInterventionConfirmed,postClaimIsolationActive;int releases,successes;
 List<String> logs=new ArrayList<>();List<Runnable> tasks=new ArrayList<>();class Handler{void postDelayed(Runnable r,long d){tasks.add(r);}}Handler acceptOutcomeWorker=new Handler(),fastWorker=new Handler();
 Consumer<String> offerReporter(String t){return logs::add;}boolean isPostTerminalSuccessCandidate(String t){return false;}void confirmPostTerminalClaimSuccess(String a,String b){successes++;}void requestImmediateFastCheck(long n){}
 void releasePostClaimIsolation(String s){releases++;postClaimIsolationActive=false;postClaimNavigationEpoch.incrementAndGet();}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static NavigationHarness setup(){SystemClock.now=1000;TapAccessibilityService.root=new AccessibilityNodeInfo();TapAccessibilityService.throwsRead=false;TapAccessibilityService.offers=TapAccessibilityService.begin=TapAccessibilityService.unavailable=TapAccessibilityService.jobs=TapAccessibilityService.dropCallback=TapAccessibilityService.gesture=false;TapAccessibilityService.clicks=0;return new NavigationHarness();}
'''
test='''public static void main(String[] args){
 NavigationHarness h=setup();check(TapAccessibilityService.deliverThatForegroundState()==TapAccessibilityService.ForegroundState.DELIVERTHAT&&TapAccessibilityService.root.recycled==1,"live DeliverThat root read and recycled");
 for(String overlay:new String[]{"com.android.systemui","android"}) {
  h=setup();TapAccessibilityService.root.pkg=overlay;
  check(TapAccessibilityService.deliverThatForegroundState()==TapAccessibilityService.ForegroundState.UNKNOWN,"system overlay pauses instead of cancelling");
  h.returnToOffersAfterUnavailable("offer",0,1000,1,h.logs::add);
  check(TapAccessibilityService.clicks==0&&h.unavailableReturnEpoch.get()==1&&!h.tasks.isEmpty(),"overlay sends no click and preserves bounded recovery");
  TapAccessibilityService.root.pkg="com.deliverthat.driver";TapAccessibilityService.offers=true;
  h.tasks.remove(0).run();check(h.unavailableReturnEpoch.get()==2,"overlay dismissal resumes and confirms Offers");
 }
 h=setup();
 TapAccessibilityService.root.pkg="other.app";check(TapAccessibilityService.deliverThatForegroundState()==TapAccessibilityService.ForegroundState.OTHER_APP,"explicit foreign app is distinct from missing root");
 TapAccessibilityService.root.pkg="";check(TapAccessibilityService.deliverThatForegroundState()==TapAccessibilityService.ForegroundState.UNKNOWN,"empty package is unknown");
 TapAccessibilityService.root=null;check(TapAccessibilityService.deliverThatForegroundState()==TapAccessibilityService.ForegroundState.UNKNOWN,"missing root is unknown");
 TapAccessibilityService.throwsRead=true;check(TapAccessibilityService.deliverThatForegroundState()==TapAccessibilityService.ForegroundState.UNKNOWN,"temporary read exception is unknown");
 h=setup();TapAccessibilityService.root=null;h.returnToOffersAfterUnavailable("order",3,1000,1,h.logs::add);check(h.unavailableReturnEpoch.get()==1&&h.tasks.size()==1&&TapAccessibilityService.clicks==0,"unknown root defers without click, spending attempt or cancelling owner");
 TapAccessibilityService.root=new AccessibilityNodeInfo();TapAccessibilityService.offers=true;h.tasks.remove(0).run();check(h.unavailableReturnEpoch.get()==2&&h.logs.stream().anyMatch(s->s.contains("CONFIRMED")),"root restoration can finish the same return transaction");
 h=setup();TapAccessibilityService.root.pkg="other.app";h.returnToOffersAfterUnavailable("order",0,1000,1,h.logs::add);check(h.tasks.isEmpty()&&TapAccessibilityService.clicks==0&&h.unavailableReturnEpoch.get()==2,"actual app switch stops immediately without background clicks");
 h=setup();TapAccessibilityService.root=null;SystemClock.now=11000;h.returnToOffersAfterUnavailable("order",0,1000,1,h.logs::add);check(h.tasks.isEmpty()&&h.unavailableReturnEpoch.get()==2&&TapAccessibilityService.clicks==0,"unknown cannot extend navigation deadline");
 h=setup();TapAccessibilityService.root=null;h.returnToOffersAfterUnavailable("order",3,1000,1,h.logs::add);TapAccessibilityService.root=new AccessibilityNodeInfo();h.tasks.remove(0).run();check(TapAccessibilityService.clicks==1,"unknown wait preserves existing click ordinal");
 h=setup();TapAccessibilityService.root=null;h.returnToOffersAfterUnavailable("order",0,1000,1,h.logs::add);h.unavailableReturnEpoch.incrementAndGet();TapAccessibilityService.root=new AccessibilityNodeInfo();h.tasks.remove(0).run();check(TapAccessibilityService.clicks==0,"superseded task still cannot click");
 h=setup();TapAccessibilityService.offers=true;TapAccessibilityService.unavailable=true;
 h.returnToOffersAfterUnavailable("old",0,1000,1,h.logs::add);
 check(h.unavailableReturnEpoch.get()==1&&h.logs.stream().noneMatch(s->s.contains("CONFIRMED")),"Offers chrome behind a stale failure is not return confirmation");
 h=setup();TapAccessibilityService.jobs=true;TapAccessibilityService.dropCallback=true;
 h.returnToOffersAfterUnavailable("old",0,1000,1,h.logs::add);
 check(TapAccessibilityService.clicks==1&&!TapAccessibilityService.gesture&&h.tasks.size()==1,"Jobs proof starts semantic click and independently schedules verification");
 h.tasks.remove(0).run();
 check(TapAccessibilityService.clicks==2&&TapAccessibilityService.gesture&&h.tasks.size()==1,"missing callback still reaches exact-target gesture retry");
 SystemClock.now=2000;h.tasks.remove(0).run();
 check(h.unavailableReturnEpoch.get()==2&&h.logs.stream().anyMatch(s->s.contains("TIMEOUT")),"bounded timeout releases before another surface read");
 h=setup();TapAccessibilityService.unavailable=true;
 h.returnToOffersAfterUnavailable("old",0,1000,1,h.logs::add);
 check(!TapAccessibilityService.gesture,"stale surface first tries the exact semantic Offers node");
 h.expireUnavailableReturn(1,h.logs::add);h.tasks.remove(0).run();
 check(TapAccessibilityService.clicks==1&&h.unavailableNavigationUntil==0
     &&h.logs.stream().anyMatch(s->s.contains("独立计时到期")),"deadline cancels old continuation before another click");
 h=setup();h.postClaimIsolationActive=true;TapAccessibilityService.root=null;AtomicInteger resumes=new AtomicInteger();boolean stop=h.stopPostClaimNavigationIfNeeded(h.logs::add,1000,1,resumes::incrementAndGet);check(stop&&h.releases==0&&h.tasks.size()==1,"confirmed claim waits through unreadable window without dropping isolation");h.tasks.remove(0).run();check(resumes.get()==1,"same navigation stage resumes");
 TapAccessibilityService.root=new AccessibilityNodeInfo();TapAccessibilityService.root.pkg="other.app";check(h.stopPostClaimNavigationIfNeeded(h.logs::add,1000,1,()->{})&&h.releases==1,"confirmed claim stops for real foreground change");
 h=setup();h.postClaimIsolationActive=true;TapAccessibilityService.root=null;SystemClock.now=11000;check(h.stopPostClaimNavigationIfNeeded(h.logs::add,1000,1,()->{})&&h.releases==1&&h.tasks.isEmpty(),"confirmed navigation keeps its original deadline while root unknown");
 h=setup();check(h.yieldDeepScanDuringUnavailableReturn(null,1000),"navigation with no current indexed card avoids deep tree");
 check(!h.yieldDeepScanDuringUnavailableReturn(new TapAccessibilityService.FastOfferSnapshot(),1000),"current indexed card is never delayed by navigation lease");
 TapAccessibilityService.FastOfferSnapshot partial=new TapAccessibilityService.FastOfferSnapshot();partial.acceptEnabled=false;
 check(h.yieldDeepScanDuringUnavailableReturn(partial,1000),"partial index cannot trigger deep navigation tree");
 partial.acceptEnabled=true;partial.text="dead";
 check(!h.yieldDeepScanDuringUnavailableReturn(partial,1000),"each current enabled offer overrides old history and keeps navigation deep read idle");
 partial.text="new";partial.acceptEnabled=false;partial.rejectEnabled=true;
 check(!h.yieldDeepScanDuringUnavailableReturn(partial,1000),"fresh rejectable new card retains priority");
 check(!h.yieldDeepScanDuringUnavailableReturn(null,11000),"navigation skip expires at fixed deadline");
 h.serialTopAction=SerialAction.ACCEPT;check(!h.yieldDeepScanDuringUnavailableReturn(null,1000),"active Accept owns its normal confirmation lane");
 h.returnToOffersAfterUnavailable("old",0,1000,1,h.logs::add);check(TapAccessibilityService.clicks==0&&h.unavailableNavigationUntil==0,"old navigation stops before touching a new Accept");
 h=setup();h.unavailableReturnEpoch.set(2);h.finishUnavailableReturn(1);check(h.unavailableNavigationUntil==11000,"old finish cannot clear a newer navigation lease");
 System.out.println(checks+" production foreground/navigation recovery cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'NavigationHarness.java';f.write_text(head+foreground+mid+methods+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(f)],check=True)
 subprocess.run(['java','-cp',d,'NavigationHarness'],check=True)

# Exercise the production classifier with the exact toast and empty-state text from the replay.
surface = block(tap, '    static OffersNavigationSurface readOffersNavigationSurface(')
surface_harness = r'''
import java.util.Locale;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
class CardText { static String completionKey(String unused){throw new AssertionError("unexpected");} }
class TapAccessibilityService {
 enum OffersNavigationSurface { OFFERS, JOBS, IGNORED, STALE_OFFER, DELIVERY, UNKNOWN }
 static final AtomicReference<TapAccessibilityService> INSTANCE =
     new AtomicReference<>(new TapAccessibilityService());
 static final Pattern LIVE_MONEY=Pattern.compile("\\$[0-9]");
 static final Pattern LIVE_MILES=Pattern.compile("[0-9] mi");
 static class AccessibilityNodeInfo {
  CharSequence getPackageName(){return "com.deliverthat.driver";}
  void recycle(){}
 }
 static java.util.concurrent.atomic.AtomicLong UI_GENERATION=new java.util.concurrent.atomic.AtomicLong(),WINDOW_TRANSITION_EPOCH=new java.util.concurrent.atomic.AtomicLong();
 static String text;
 static boolean[] testFlags;
 AccessibilityNodeInfo getRootInActiveWindow(){return new AccessibilityNodeInfo();}
 static void collectRecoveryPageFlags(AccessibilityNodeInfo root, boolean[] flags, StringBuilder visible) {
  System.arraycopy(testFlags,0,flags,0,flags.length);
  visible.append(text);
  flags[6] = EmptyOffersPolicy.isExplicitEmpty(text.split("\\|",2)[0]);
 }
 static void updatePageHint(PageGuard.Page page){}
 static PageGuard.Page fallbackPageFromTreeText(String text){return PageGuard.emptyDeliveriesTab(text);}
'''
surface_cases = r'''
 static void expect(OffersNavigationSurface expected, String raw, int... flags) {
  text=raw;
  testFlags=new boolean[7];
  for(int flag:flags) testFlags[flag]=true;
  OffersNavigationSurface actual=readOffersNavigationSurface(true);
  if(actual!=expected) throw new AssertionError(raw+": "+actual);
 }
 public static void main(String[] args){
  String toast="This offer is no longer available.";
  expect(OffersNavigationSurface.OFFERS, "No offers available|"+toast);
  expect(OffersNavigationSurface.OFFERS, "No offers available|"+toast, 2);
  expect(OffersNavigationSurface.STALE_OFFER, "No offers available|$205.63 0.7 mi "+toast, 2, 5);
  expect(OffersNavigationSurface.STALE_OFFER, toast, 2);
  expect(OffersNavigationSurface.JOBS, "No offers available|"+toast, 1);
  expect(OffersNavigationSurface.DELIVERY, "No offers available|Begin Delivery "+toast);
  System.out.println("6 production replay surface cases passed");
 }
}
'''
with tempfile.TemporaryDirectory() as d:
 files=[]
 for name,content in [('TapAccessibilityService.java', surface_harness+surface+surface_cases),
                      *((n+'.java', (src/(n+'.java')).read_text().split('\n',1)[1])
                        for n in ['EmptyOffersPolicy','PageGuard','ClaimSuccessSignals'])]:
  f=Path(d)/name
  f.write_text(content)
  files.append(str(f))
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*files],check=True)
 subprocess.run(['java','-cp',d,'TapAccessibilityService'],check=True)
