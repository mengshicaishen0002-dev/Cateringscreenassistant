#!/usr/bin/env python3
"""Static safety regression for the Jobs-empty -> Offers fast-return wiring."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]/"app/src/main/java/com/local/cateringscreenassistant"
t=(p/"TapAccessibilityService.java").read_text()
s=(p/"OcrMonitorService.java").read_text()
assert 'PageGuard.explicitEmptyOtherTabText(shallowDecisionText)' in t
assert 'OcrMonitorService.requestImmediateFastCheck(event.getEventTime(), true, eventReceivedAt)' in t
assert 'JOBS_EMPTY, IGNORED_EMPTY, JOBS_LIST, IGNORED_LIST' in t
assert 'return emptyJobs ? EmptyIndexStatus.JOBS_EMPTY : EmptyIndexStatus.JOBS_LIST;' in t
assert 'return emptyIgnored ? EmptyIndexStatus.IGNORED_EMPTY : EmptyIndexStatus.IGNORED_LIST;' in t
assert 'generation!=TapAccessibilityService.currentUiGeneration()' in s
assert 'TapAccessibilityService.recordIdleOtherTabHint(presence);' in s
assert 'case JOBS_LIST:' in s and 'case IGNORED_LIST:' in s
assert 'PageGuard.clickedDeliveriesTab(shallowDecisionText)' in t
assert 'hasSelectedOtherTabNavigation(root, rootBounds, livePage, raw)' in t
assert 'lastOtherHubTabClickAt' in t
assert 'if(offersSelected) return false;' in t
assert s.index('if (service.recoverOffersPage(now))') < s.index('if(service.monitorOnly(now,structural,priorityOffer))')
assert 'clickOffersNavigationFromOtherTab' in s
assert 'liveOfferSignal(SystemClock.elapsedRealtime())' in s
print('Jobs empty-page monitoring, event fast wake and verified Offers recovery wired')
# Confirm that successful-claim navigation stays distinct from the ordinary
# empty-Jobs auto-return, and retains its independent back -> Offers -> proof path.
assert 'scheduleReturnToOffersAfterClaim(report, 0,' in s
claim_nav=s[s.index('private void confirmPendingClaimSuccess('):s.index('private synchronized void finishPendingClaimLoss(')]
assert 'enterPostClaimIsolation(evidence, jobsNow);' in claim_nav
assert 'scheduleReturnToOffersAfterClaim(report, 0,' in claim_nav
assert 'TapAccessibilityService.clickPostClaimBack(' in claim_nav
assert 'scheduleFindOffersAfterClaim(report, 0,' in claim_nav
assert 'TapAccessibilityService.clickOffersNavigation(' in claim_nav
assert 'completePostClaimReturnIfVisible(report, token)' in claim_nav
assert 'TapAccessibilityService.hasCurrentOffersSurfaceEvidence()' in claim_nav
print('Confirmed-claim back -> Offers -> verified-page navigation remains intact')
