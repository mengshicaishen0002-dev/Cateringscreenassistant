#!/usr/bin/env python3
"""Run the production cache-only Accept card/Reject fence against real arbitration policies."""
from pathlib import Path
import tempfile, subprocess
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()
def block(sig):
 a=s.index(sig);b=s.index('{',a);depth=1;i=b+1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
header=r'''package com.local.cateringscreenassistant;
import java.util.concurrent.*;
class TapAccessibilityService {static boolean currentNegativeSurfaceBlocksAccept(){return false;}}
public class OcrMonitorService {
 static OcrMonitorService activeInstance;static class SystemClock {static long now=2000;static long elapsedRealtime(){return now;}}
 RejectSequence rejectSequence=new RejectSequence();RejectTerminalGate rejectTerminalGate=new RejectTerminalGate();
 static class RejectConfirmState {String id,text;long token;RejectConfirmState(String t,long k){text=t;id=CardText.identity(t);token=k;}}
 ConcurrentHashMap<String,RejectConfirmState> rejectConfirmStates=new ConcurrentHashMap<>();
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
'''
test=r'''
 public static void main(String[] args){
 String mend="$29–39 Est. 0.3 mi (~2 mins) Today at 10:45 AM Mendocino Farms • 444 Flower St, Los Angeles, CA 90071, United States";
 String porto="Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040, United States";
 String contaminated=mend+" "+mend+" $29–39 0.3 mi Mendocino Farms • 444 Flower St, Los Angeles, CA 90071, United States "+porto;
 OcrMonitorService o=activeInstance=new OcrMonitorService();
 check(o.acceptCardSafetyReason(mend,2000).isEmpty(),"ordinary clean card unchanged");
 check(o.acceptCardSafetyReason(contaminated,2000).equals("ACCEPT_CARD_CONFLICT"),"real repeated-parent cross-merchant log blocked");
 check(!PasadenaRuleGuard.isPasadenaOffer(contaminated),"stray Commerce cannot qualify mixed card");
 check(o.acceptCardSafetyReason(mend+" "+mend,2000).isEmpty(),"duplicate same pickup remains usable");
 String id=CardText.identity(mend);check(o.rejectSequence.reserveFirstIfReady(id,1000)==1,"original Reject reservation acquired");
 check(firstAcceptCardGuard(mend).equals("ACCEPT_REJECT_OWNED"),"reserved Reject blocks final first-shot guard");
 check(o.rejectSequence.attempts(id,2000)==1,"Accept guard never consumes Reject retry count");
 String next="$90 2 mi Today at 11:45 AM "+porto;
 check(firstAcceptCardGuard(next).isEmpty(),"genuine new top is immediately allowed");
 check(firstAcceptCardGuard("$29–39 0.3 mi").equals("ACCEPT_REJECT_OWNED"),"sparse redraw cannot evade original Reject owner");
 o.rejectSequence.markDisappeared(id,2100);SystemClock.now=2200;
 check(firstAcceptCardGuard(mend).equals("ACCEPT_REJECT_OWNED"),"brief redraw after Reject terminal remains blocked");
 SystemClock.now=20000;check(firstAcceptCardGuard(mend).isEmpty(),"expired bounded exclusion does not permanently reject re-publication");
 long token=o.rejectTerminalGate.begin(id);o.rejectConfirmStates.put(id,new RejectConfirmState(mend,token));
 check(firstAcceptCardGuard(mend).equals("ACCEPT_REJECT_OWNED"),"unfinished background Reject still owns same card after lease");
 check(firstAcceptCardGuard(next).isEmpty(),"background Reject never globally blocks a new card");
 o.rejectTerminalGate.invalidate(id,token);check(firstAcceptCardGuard(mend).isEmpty(),"stale background token has no authority");
 String route=mend+" • 100 E Colorado Blvd, Pasadena, CA 91105";
 check(!CardText.containsConflictingPickupEvidence(route)&&PasadenaRuleGuard.isPasadenaOffer(route),"real route destination keeps special-city rule");
 System.out.println(checks+" production cross-card/Reject Accept exclusion cases passed");
 }}'''
with tempfile.TemporaryDirectory(prefix='csa-card-safety-') as d:
 h=Path(d)/'OcrMonitorService.java';h.write_text(header+block('    private String acceptCardSafetyReason(')+block('    public static String firstAcceptCardGuard(')+test)
 names=['CardText.java','PasadenaRuleGuard.java','RejectSequence.java','RejectDemandPolicy.java','RejectTerminalGate.java','OfferEnrichmentPolicy.java','ClaimSuccessSignals.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in names],str(h)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.OcrMonitorService'],check=True)
# Admission and physical dispatch all invoke the production fence, not just diagnostics.
assert 'acceptCardSafetyReason(snapshot.text, reserveNow)' in s
assert 'acceptCardSafetyReason(acceptedText, now)' in s
assert 'acceptCardSafetyReason(text, now)' in block('    private boolean isFinalOcrAcceptBlocked(')
assert 'acceptCardSafetyReason(service.serialTopText' in block('    public static String ocrAcceptDispatchGuard(')
t=(src/'TapAccessibilityService.java').read_text()
assert 'firstAcceptCardGuard(current.text)' in t
assert 'firstAcceptCardGuard(expectedText)' in t
