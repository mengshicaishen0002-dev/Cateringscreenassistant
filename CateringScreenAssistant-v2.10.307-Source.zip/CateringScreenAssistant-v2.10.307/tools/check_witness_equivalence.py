from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
baseline=(root/'tools/baseline-v179/IndexedWitnessPolicy.java.txt').read_text().replace('IndexedWitnessPolicy','BaselineIndexedWitnessPolicy')
harness='''package com.local.cateringscreenassistant;
import java.util.*;
class WitnessEquivalence {
 public static void main(String[] args){
 String base="$98.00 0.5 mi Tomorrow at 11:00 AM Mendocino Farms • 631 Wilshire Blvd, Santa Monica, CA 90401";
 List<String> v=new ArrayList<>(Arrays.asList(null,""," ","$98.00","0.5 mi",base,base.replace("98.00","99.00"),base.replace("0.5","0.6"),base.replace("11:00","12:00"),base.replace("631","632"),base+" $12.00 4.0 mi",base+" Begin Delivery",base+" Delivery Timeline Pickup Instructions"));
 for(String tail:new String[]{""," Large Order"," Tomorrow at 11:00 AM"," UBC_123456"})for(String sep:new String[]{" ","  ","\\n","\\t"})v.add((base+tail).replace(" ",sep));
 int count=0;for(String a:v)for(String b:v){if(IndexedWitnessPolicy.sameIdentity(a,b)!=BaselineIndexedWitnessPolicy.sameIdentity(a,b))throw new AssertionError("identity mismatch");count++;}
 Random random=new Random(180);for(int k=0;k<2000;k++){List<String> list=new ArrayList<>();for(int i=0,n=random.nextInt(8)+1;i<n;i++)list.add(v.get(random.nextInt(v.size())));
 if(IndexedWitnessPolicy.singleFoldedSource(list)!=BaselineIndexedWitnessPolicy.singleFoldedSource(list))throw new AssertionError("folding mismatch");
 if(IndexedWitnessPolicy.sourceCover(list)!=BaselineIndexedWitnessPolicy.sourceCover(list))throw new AssertionError("cover mismatch");count+=2;}
 System.out.println(count+" v179/v180 witness equivalence cases passed");
 }}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'BaselineIndexedWitnessPolicy.java').write_text(baseline);(p/'WitnessEquivalence.java').write_text(harness)
 names=['IndexedWitnessPolicy.java','CardText.java','RejectDemandPolicy.java','OfferEnrichmentPolicy.java','ClaimSuccessSignals.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in names],str(p/'BaselineIndexedWitnessPolicy.java'),str(p/'WitnessEquivalence.java')],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.WitnessEquivalence'],check=True)
