#!/usr/bin/env python3
"""Run the production scheduling allowance and live trace against synthetic timings."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
directory = root / 'app/src/main/java/com/local/cateringscreenassistant'
source = (directory / 'OcrMonitorService.java').read_text()

def block(signature):
    start = source.index(signature)
    end = source.index('{', start) + 1
    depth = 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end]

unit = r'''
    private static final class TapAccessibilityService {
        static final class FastOfferSnapshot {
            final float amount=116.0f, miles=8.4f;
            final boolean acceptEnabled=false;
        }
        static final class QuickTopResult {
            FastOfferSnapshot snapshot;
            boolean emptyOffers, emptyContradicted, budgetExceeded;
            String limitReason="NONE";
        }
    }
    private static void check(boolean pass, String reason) {
        if (!pass) throw new AssertionError(reason);
    }
    public static void main(String[] args) {
        FallbackGrace grace = new FallbackGrace();
        for (long time = 100; time < 132; time++)
            check(grace.defer(true,time), "first burst may yield briefly");
        check(!grace.defer(true,132) && !grace.defer(true,900),
                "nonstop mutations cannot postpone a bounded fallback indefinitely");
        grace.attempted();
        check(!grace.defer(false,901) && grace.defer(true,1000), "a new read opens a new allowance");
        check(touchScanAllowed(1000,1080,false), "read-only scan has time to finish");
        check(!touchScanAllowed(1000,1079,false) && !touchScanAllowed(1000,900,false)
                && !touchScanAllowed(1000,1200,true), "guard release and explicit pause start no passive read");
        ScanTrace trace = new ScanTrace();
        trace.note(1000,"SCAN_START owner=NONE");
        trace.note(1000,"QUICK_RESULT EMPTY");
        for (int i=1;i<1000;i++) {
            trace.note(1000+i,"SCAN_START owner=NONE");
            trace.note(1000+i,"QUICK_RESULT EMPTY");
        }
        check(trace.snapshot().split("\n").length==2,
                "idle activity remains readable without filling the ring");
        trace.note(1999,"QUICK_RESULT amount=116.0 miles=8.4 accept=false");
        check(trace.snapshot().contains("amount=116.0"), "new card survives throttling without a dispatch");
        for (int i=0;i<181;i++) trace.note(2000+i,"QUICK_RESULT marker="+i);
        check(trace.snapshot().split("\n").length==180, "trace storage remains bounded");
        ScanTrace readTrace = new ScanTrace();
        TapAccessibilityService.QuickTopResult unreadable = new TapAccessibilityService.QuickTopResult();
        QuickReadTrace first = new QuickReadTrace(unreadable, 2000, 2040, true);
        readTrace.noteQuick(2050,first);
        readTrace.noteQuick(3100,first);
        check(readTrace.snapshot().split("\n").length==1,"an old read never prints again as a new result");
        check(readTrace.snapshot().contains("read_start_ms=2000 read_end_ms=2040 read_duration_ms=40 result_age_ms=10"),
                "read timing is independent of the log time");
        check(first.summary(3100,3000).contains("latest_quick_read_age_ms=1060 quick_in_latest_scan=false"),
                "scan heartbeat marks an older read as separate from the latest scan");
        QuickReadTrace second = new QuickReadTrace(unreadable, 3090, 3100, true);
        readTrace.noteQuick(3110,second);
        check(readTrace.snapshot().split("\n").length==2,"a fresh unreadable result has its own timestamp");
        TapAccessibilityService.QuickTopResult empty = new TapAccessibilityService.QuickTopResult();
        empty.emptyOffers = true;
        readTrace.noteQuick(3120,new QuickReadTrace(empty,3103,3115,true));
        check(readTrace.snapshot().contains("QUICK_RESULT EMPTY"),"a newly confirmed empty page changes the result");
        readTrace.noteQuick(3140,new QuickReadTrace(empty,3125,3135,false));
        check(readTrace.snapshot().contains("QUICK_RESULT UI_CHANGED"),"a generation change cannot report a valid empty page");
        TapAccessibilityService.QuickTopResult card = new TapAccessibilityService.QuickTopResult();
        card.snapshot = new TapAccessibilityService.FastOfferSnapshot();
        readTrace.noteQuick(3160,new QuickReadTrace(card,3140,3155,true));
        check(readTrace.snapshot().contains("QUICK_RESULT amount=116.0"),"readable cards retain the actual read timing");
        PipelineTiming stalled = new PipelineTiming(4000);
        stalled.completeScan(3940,4050,false,true,"PATH_RETURNED");
        readTrace.noteSlowScan(4100,4090,stalled);
        readTrace.noteSlowScan(5200,5190,stalled);
        check(readTrace.snapshot().split("SCAN_SLOW",-1).length==2,"one slow scan is logged once");
        check(readTrace.snapshot().contains("completed_scan_is_latest=false trigger=PRIORITY queue_ms=60"),
                "a later fast scan does not hide a slow sample");
        System.out.println("Live scan continuity and trace cases passed");
    }
'''
with tempfile.TemporaryDirectory(prefix='csa-live-scan-') as temp:
    java_file = Path(temp) / 'LiveScanContinuity.java'
    java_file.write_text('package com.local.cateringscreenassistant;\nclass LiveScanContinuity {\n'
                         + block('    private static final class FallbackGrace')
                         + block('    private static final class QuickReadTrace')
                         + block('    private static final class ScanTrace')
                         + block('    private static boolean touchScanAllowed(') + unit + '}')
    subprocess.run(['java','com.sun.tools.javac.Main','-d',temp,
                    str(directory/'HotOfferScanPolicy.java'),str(directory/'PipelineTiming.java'),str(java_file)], check=True)
    subprocess.run(['java','-cp',temp,'com.local.cateringscreenassistant.LiveScanContinuity'], check=True)

touch = block('    private void observeOfferDuringTouch(')
assert 'getQuickTopOfferSnapshotResult(' in touch
assert all(action not in touch for action in ('tryFastAccept(', 'dispatchClaim(', 'handleRejectedCard('))

scan = block('    static void requestImmediateFastCheck(long eventTime, boolean structuralOfferWake, long eventReceivedAt)')
assert 'catch (RuntimeException failure)' in scan and 'fastCheckQueued.set(false)' in scan

assert 'scanTrace.note(' not in scan and 'observeOfferDuringTouch(' not in scan
assert 'service.lastQuickTrace = new QuickReadTrace(quickResult,quickStarted,quickFinished,' in scan
assert 'if (!structural && ownedFrame != null' in scan
assert 'structuralOfferWake || freshOfferEvent' in scan
diagnostics = block('    private final Runnable scanDiagnosticCheck')
assert 'scanTrace.note(' in diagnostics and 'observeOfferDuringTouch(now)' in diagnostics
assert 'scanTrace.noteQuick(' in diagnostics and 'latest_scan_age_ms=' in diagnostics
assert 'scanTrace.noteSlowScan(' in diagnostics and 'timing.completeScan(' in scan

# v2.10.293 idle-present-first gate: expensive traversal never owns the fast heartbeat
# without an offer, while priority/structural events bypass the gate entirely.
assert 'service.monitorOnly(now,structural,priorityOffer)' in scan
assert 'service.scheduleIdlePresenceProbe();' in scan
assert scan.index('service.monitorOnly(now,structural,priorityOffer)') < scan.index('service.noteDecisionStage("preflight")')
assert 'scanExit="IDLE_PRESENCE_MONITOR"' in scan
assert 'PRESENCE_UNPROVEN_OFF_LANE' in scan
assert 'idlePresenceWorker=new Handler(idlePresenceThread.getLooper())' in source
assert 'offer-idle-presence' in source
assert 'presence_probes=' in source and 'presence_found=' in source
assert 'probeCurrentOffersPresence(34L,' in source
assert 'serialTopAction==SerialAction.ACCEPT || rejectConfirmStates.isEmpty()' in source
assert 'REJECT_SPINNER_CONFIRMED' in source

assert 'getBoundedQuickTopOfferSnapshot(' in scan
assert 'TapAccessibilityService.activePage()' not in scan
assert 'TapAccessibilityService.debugTreeSummary()' not in scan
assert 'full.explicitEmpty' in scan and 'noCardStatus' in scan

# v2.10.292: urgent structural events re-promote the queued scan, independent of
# first-wake bookkeeping, and background diagnostics own summary rendering.
assert 'service.liveScanHealth.enter(' in scan and 'service.liveScanHealth.finish(' in scan
assert 'new LiveScanHealth()' in source
assert '"SCAN_HEALTH " +liveScanHealth.snapshotAndReset' not in source or 'SCAN_HEALTH ' in source
