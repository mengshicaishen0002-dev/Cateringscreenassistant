#!/usr/bin/env python3
"""Exercise production pre-dispatch current-owner/amount/spinner fences after legacy tombstone removal."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()
def block(sig):
 a=s.index(sig);b=s.index('{',a);i=b+1;d=1
 while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
for old in ['isTerminalLossSuppressed(', 'isUnavailableTombstoned(', 'reportUnavailableTombstoneSuppressed(']:
 assert old not in s, old
header='''package com.local.cateringscreenassistant;
import java.util.concurrent.atomic.AtomicBoolean;
public class TerminalGuardHarness {
 static TerminalGuardHarness activeInstance;
 static AtomicBoolean MANUAL_INTERVENTION_PAUSED=new AtomicBoolean(false);
 static boolean confirmed;static boolean hasBoundAcceptSuccess(){return confirmed;}
 static class SystemClock {static long elapsedRealtime(){return 5000L;}}
 enum SerialAction {NONE,ACCEPT};SerialAction serialTopAction=SerialAction.ACCEPT;
 String serialTopText="$28–38 4.7 mi Tomorrow at 3:15 PM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 long serialTopActionAt=1000L,pressureOwner,spinnerCandidateAt,spinnerObservedAt;
 boolean monitorReady=true,blocked;
 String acceptCardSafetyReason(String text,long now){return blocked?"CURRENT_SURFACE_BLOCK":"";}
 static int checks;static void check(boolean c,String reason){checks++;if(!c)throw new AssertionError(reason);}
'''
tests='''public static void main(String[] args){
 TerminalGuardHarness h=new TerminalGuardHarness();activeInstance=h;
 check(ocrAcceptDispatchGuard(1000L,28f,4.7f).isEmpty(),"fresh current owner can click");
 check("OCR_ACCEPT_OWNER_CHANGED".equals(ocrAcceptDispatchGuard(999L,28f,4.7f)),"old owner cannot click");
 check("OCR_ACCEPT_NUMERIC_CHANGED".equals(ocrAcceptDispatchGuard(1000L,29f,4.7f)),"amount mismatch rejected");
 check("OCR_ACCEPT_NUMERIC_CHANGED".equals(ocrAcceptDispatchGuard(1000L,28f,4.8f)),"mileage mismatch rejected");
 h.blocked=true;check("CURRENT_SURFACE_BLOCK".equals(ocrAcceptDispatchGuard(1000L,28f,4.7f)),"current negative page prevents click");h.blocked=false;
 h.spinnerCandidateAt=5200;h.pressureOwner=1000;
 check("RETRY_SPINNER_CANDIDATE".equals(ocrAcceptDispatchGuard(1000L,28f,4.7f)),"spinner candidate gates duplicate gesture");
 h.spinnerCandidateAt=0;h.spinnerObservedAt=5300;
 check("RETRY_SPINNER_CONFIRMED".equals(ocrAcceptDispatchGuard(1000L,28f,4.7f)),"spinner confirmation gates duplicate gesture");
 h.spinnerObservedAt=0;h.pressureOwner=0;
 confirmed=true;check("OCR_ACCEPT_SUCCESS_OBSERVED".equals(ocrAcceptDispatchGuard(1000L,28f,4.7f)),"success stops further attempts");confirmed=false;
 MANUAL_INTERVENTION_PAUSED.set(true);check("OCR_ACCEPT_OWNER_CHANGED".equals(ocrAcceptDispatchGuard(1000L,28f,4.7f)),"manual intervention blocks tap");MANUAL_INTERVENTION_PAUSED.set(false);
 h.monitorReady=false;check("OCR_ACCEPT_OWNER_CHANGED".equals(ocrAcceptDispatchGuard(1000L,28f,4.7f)),"stopped monitor blocks tap");h.monitorReady=true;
 activeInstance=null;check("OCR_ACCEPT_NO_OWNER".equals(ocrAcceptDispatchGuard(1000L,28f,4.7f)),"missing owner blocks tap");
 System.out.println(checks+" current-terminal/dispatch checks passed");
}}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'TerminalGuardHarness.java'
 p.write_text((header+'\n'.join([block('    public static String acceptLoadingRetryBlock('),block('    public static String ocrAcceptDispatchGuard(')])+tests).replace('OcrMonitorService','TerminalGuardHarness'))
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'CardText.java'),str(src/'OfferEnrichmentPolicy.java'),str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.TerminalGuardHarness'],check=True)
