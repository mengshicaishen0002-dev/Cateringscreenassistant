#!/usr/bin/env python3
"""Run the production retry method with deterministic Android boundary fakes."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'TapAccessibilityService.java').read_text()
a=s.index('    public static void tapSnapshotRetryDetailed(')
b=s.index('    public static void tapVisualSnapshotRetryDetailed',a)
method=s[a:b]
header="""package com.local.cateringscreenassistant;
import java.util.function.Consumer;
import java.util.concurrent.atomic.*;
class RetryHarness {
 static class Rect { boolean empty; boolean isEmpty(){return empty;} }
 static class IndexedReadProof {String stages="";}
 static class FastOfferSnapshot {IndexedReadProof indexedRead;String text; Rect acceptBounds=new Rect(); boolean acceptEnabled=true; long gen=UI_GENERATION.get();long liveReadGeneration(){return gen;}FastOfferSnapshot(String t){text=t;}}
 static class TapAccessibilityService {Main main=new Main();}
 static class Main {void post(Runnable r){throw new AssertionError("retry must not queue on main");}}
 static class OcrMonitorService {static boolean monitor=true,success;static boolean isMonitoring(){return monitor;}static boolean isManualInterventionPaused(){return false;}static long pendingClaimSince(){return 1;}static long acceptDispatchObservedAt(){return 1;}static String retryGuard="";static String acceptRetryGuard(long at){return retryGuard;}static boolean hasBoundAcceptSuccess(){return success;}}
 static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>(new TapAccessibilityService());
 static AtomicLong UI_GENERATION=new AtomicLong();
 static String foregroundPackage="com.deliverthat.driver";static FastOfferSnapshot live;static boolean foreground=true,change,preReadChange,blockDuringIndex;static int taps,checks;static String failure;
 static java.util.regex.Pattern LIVE_OFFER_TIME=java.util.regex.Pattern.compile("(?:Today|Tomorrow) at");
 static FastOfferSnapshot readIndexedCurrentTopAcceptSnapshot(float min,float max,boolean special,boolean general,boolean time,boolean requireEnabled){if(preReadChange)UI_GENERATION.incrementAndGet();if(live!=null)live.gen=UI_GENERATION.get();if(change)UI_GENERATION.incrementAndGet();if(blockDuringIndex)OcrMonitorService.retryGuard="RETRY_NEGATIVE_PENDING";return live;}
 static boolean quickNumericPairMatches(String t,float a,float m){return CardText.amount(t)==a&&CardText.miles(t)==m;}
 static boolean isDeliverThatForeground(){return foreground;}
 static void clearPageRetryReceipt(long at){}
 static boolean freshPageRetrySnapshot(FastOfferSnapshot s,long at){return false;}
 static FastOfferSnapshot refreshRetryWitnessSnapshot(TapAccessibilityService s,FastOfferSnapshot original){return null;}
 static String retryWitnessFailure(){return "NONE";}static boolean hardRetryWitnessFailure(String r){return false;}
 static final ThreadLocal<String> RETRY_TREE_FAILURE=ThreadLocal.withInitial(()->"NOT_USED");
 static FastOfferSnapshot readRetryQuickTreeSnapshot(TapAccessibilityService s,FastOfferSnapshot f,float a,float m,long at,String reason){return null;}
 static final ThreadLocal<String> RETRY_WITNESS_DETAIL=ThreadLocal.withInitial(()->"NONE");
 static String acceptIndexFailure(){return "TEST_MISSING_INDEX";}
 static void dispatchRetryFromCurrentProof(TapAccessibilityService s,FastOfferSnapshot current,boolean witness,int attempt,long actionAt,Consumer<String> ok,Consumer<String> fail){
  if(!foreground){fail.accept("RETRY_FOREGROUND_CHANGED");return;}
  dispatchActionGesture(s,current.acceptBounds,true,ActionDispatchPolicy.retryGestureDurationMs(attempt),ActionDispatchPolicy.retryVariant(attempt),ok,fail);
 }
 static void dispatchActionGesture(TapAccessibilityService s,Rect r,boolean a,long d,int v,Consumer<String> ok,Consumer<String> fail){taps++;ok.accept("sent");}
 static void check(boolean b){checks++;if(!b)throw new AssertionError("retry case "+checks);}
"""
tests="""public static void main(String[] args){
 String t="$28–38 0.6 mi (~3 mins) Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101";
 FastOfferSnapshot original=new FastOfferSnapshot(t);
 live=new FastOfferSnapshot(t);
 run(original);check(taps==1);
 live=null;run(original);check(taps==1&&failure.contains("NO_PROOF"));
 live=new FastOfferSnapshot(t);live.acceptEnabled=false;run(original);check(taps==1&&failure.contains("禁用/处理中"));
 live=new FastOfferSnapshot(t.replace("238","239"));run(original);check(taps==1&&failure.contains("IDENTITY"));
 live=new FastOfferSnapshot(t.replace("0.6","0.7"));run(original);check(taps==1);
 live=new FastOfferSnapshot(t);change=true;run(original);check(taps==2); // RN generation churn no longer cancels a valid retry
 change=false;foreground=false;run(original);check(taps==2);
 foreground=true;OcrMonitorService.retryGuard="RETRY_NEGATIVE_PENDING";run(original);check(taps==2&&failure.contains("NEGATIVE_PENDING"));
 OcrMonitorService.retryGuard="RETRY_TERMINAL_OBSERVED";run(original);check(taps==2);
 OcrMonitorService.retryGuard="";blockDuringIndex=true;run(original);check(taps==2&&failure.contains("NEGATIVE_PENDING"));
 blockDuringIndex=false;OcrMonitorService.retryGuard="";OcrMonitorService.success=true;run(original);check(taps==2);
 OcrMonitorService.success=false;OcrMonitorService.monitor=false;run(original);check(taps==2);
 OcrMonitorService.monitor=true;live=new FastOfferSnapshot(t.replace("Mendocino","Today at 10:15 AM Mendocino"));run(original);check(taps==3);
 preReadChange=true;live=new FastOfferSnapshot(t);run(original);check(taps==4); // fresh inner read owns generation after pre-read event
 String nobu="$85.67 Est. 1.2 mi (~8 mins) Today at 8:00 PM, Nobu • 903 N La Cienega Blvd, Los Angeles, CA 90069";
 preReadChange=false;live=new FastOfferSnapshot(nobu);int before=taps;
 tapSnapshotRetryDetailed(new FastOfferSnapshot(nobu.replace("PM, Nobu","PM , PDT, Nobu")),85.67f,1.2f,2,d->{},d->failure=d);
 check(taps==before+1);
 live=new FastOfferSnapshot(nobu.replace("903 N","904 N"));before=taps;
 tapSnapshotRetryDetailed(new FastOfferSnapshot(nobu),85.67f,1.2f,2,d->{},d->failure=d);
 check(taps==before&&failure.contains("IDENTITY"));
 System.out.println(checks+" production retry dispatch cases passed");
 }
 static void run(FastOfferSnapshot s){failure="";tapSnapshotRetryDetailed(s,28f,0.6f,2,d->{},d->failure=d);}
}
"""
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'RetryHarness.java';p.write_text(header+method+tests)
 files=['CardText.java','OfferEnrichmentPolicy.java','ClaimSuccessSignals.java','ActionDispatchPolicy.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d]+[str(src/f) for f in files]+[str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.RetryHarness'],check=True)
