#!/usr/bin/env python3
"""Run actual cancellation and lazy reporter methods; verify logging cannot precede wake."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1];s=root/'app/src/main/java/com/local/cateringscreenassistant';t=(s/'OcrMonitorService.java').read_text()
def block(sig):
 a=t.index(sig);b=t.index('{',a);d=1;i=b+1
 while d:
  d+=(t[i]=='{')-(t[i]=='}');i+=1
 return t[a:i]
header='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.function.*;import java.util.concurrent.atomic.*;
class SystemClock {static long elapsedRealtime(){return 1000;}static long uptimeMillis(){return 1000;}}
class TapAccessibilityService {static long recentFirstSeenAt(String text,long age){return 0L;}static void startAcceptControlWatch(String text,long at){}}
class AcceptAttemptAudit {int count;void dispatched(long actionAt,long at){count++;}int sendsFor(long at){return count;}}
class Handler {Runnable pending;long delay;void postDelayed(Runnable r,long d){pending=r;delay=d;}}
public class OcrMonitorService {Handler acceptClickWorker;long pressureEpoch,acceptRetryDispatchPendingAt;boolean spinnerCandidate,pressureActive;int scheduledPressure;boolean hasSpinnerCandidate(long at){return spinnerCandidate;}static boolean acceptPressureActive(long at){return activeInstance!=null && activeInstance.pressureActive && at==activeInstance.serialTopActionAt;}void scheduleAcceptPressure(long at,long epoch){scheduledPressure++;}
 static OcrMonitorService activeInstance;boolean monitorReady=true;long acceptDispatchObservationAt,acceptDispatchAckReportedForActionAt;
 enum SerialAction {NONE,ACCEPT}SerialAction serialTopAction=SerialAction.ACCEPT;
 String acceptTimingText="",acceptTransactionTiming="";
 String engineVersion="TEST",serialTopText="",pendingJobDetailCandidateIdentity="",scanTiming="old timing";
 long acceptControlEnabledActionAt,acceptControlEnabledAt,expeditedReprobeActionAt;
 Object fastWorker=new Object();
 Object worker=new Object();
 static class Replay {void dispatched(Object worker,long tx,long at,long numericAt){}} final Replay acceptReplay=new Replay();
 String retryGuard="";
 boolean verifiedAcceptRetryMatches(String text){return false;}
 static String acceptRetryGuard(long at){return activeInstance.retryGuard;}
 void scheduleClaimInspection(String text,long epoch,int d,int m,long delay){trace.add("retry:"+delay);}long cancelledAcceptPriorityUntil,serialTopActionAt=900,pendingAcceptMissingSince,pendingAcceptTerminalProbeAt,pendingJobDetailCandidateAt,cooldownUntil,accessibilityActionHoldUntil,lastReadableFastScan,lastScan;
 int pendingAcceptJobsBaseline,audits;AtomicLong claimEpoch=new AtomicLong(),scanGeneration=new AtomicLong();
 static class Budget {int forgotten;boolean releaseUndispatchedRetry(String id,int attempt){return true;}boolean releaseUndispatchedRetry(String id,int attempt,long at){return true;}void forget(String s){forgotten++;}void cancelUndispatched(String s){forgotten++;}}Budget claimBudget=new Budget();
 List<String> trace=new ArrayList<>();List<Runnable> pending=new ArrayList<>();
 class Log {void execute(Runnable r){pending.add(r);}}Log logWriter=new Log();
 final AcceptAttemptAudit acceptAudit=new AcceptAttemptAudit();
 boolean acceptGestureDispatchedForCurrentTransaction(){return acceptDispatchObservationAt>=serialTopActionAt;}void noteAcceptGestureCompleted(){}
 void scheduleAcceptPageProbe(long n){}void consumeAcceptSuppressionSummary(){}void requestImmediateFastCheck(long n){trace.add("wake");}
 String acceptStageTiming(String a,String b,long n){return "timed";}Consumer<String> offerReporterWithTiming(String a,String b){return acceptReporter(a);}
 String ruleSummary(String s){audits++;return "rule";}void updateOfferStatus(String m,String text,String rule){trace.add("log:"+m+"|card="+text);}
'''
test='''
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args){OcrMonitorService s=new OcrMonitorService();
 Consumer<String> report=s.acceptReporter("$133.85 17.9 mi");
 check(s.audits==0&&s.trace.isEmpty(),"no city auditing or log write while creating dispatch callback");

 s.acceptTimingText="$133.85 17.9 mi";s.acceptTransactionTiming="first dispatch";
 check(s.acceptTiming("$133.85 17.9 mi","later OCR").equals("first dispatch"),"same transaction freezes first dispatch timing");
 check(s.acceptTiming("$55 2 mi","new card").equals("new card"),"new card uses its own timing");

 Consumer<String> frozen=s.acceptReporter("$133.85 17.9 mi");
 frozen.accept("frozen result");s.pending.remove(0).run();
 check(s.trace.get(s.trace.size()-1).contains("first dispatch"),"actual result reporter retains first dispatch timing");
 s.trace.clear();s.audits=0;
 s.acceptTimingText="";s.acceptTransactionTiming="";
 s.scanTiming="changed";report.accept("sent");
 check(s.audits==0&&s.trace.isEmpty()&&s.pending.size()==1,"gesture callback queues all audit work without blocking its lane");
 s.pending.remove(0).run();
 check(s.audits==1&&s.trace.get(0).contains("old timing"),"background report preserves original timing");
 s.trace.clear();s.cancelUndispatchedAccept("$133.85 17.9 mi","cancelled");
 check(s.trace.equals(List.of("wake"))&&s.pending.size()==1,"urgent new scan precedes cancellation logging");
 check(s.serialTopAction==SerialAction.NONE&&s.cooldownUntil==0&&s.claimBudget.forgotten==1,"only undispatched transaction releases cooldown and reservation");
 check(s.cancelledAcceptPriorityUntil==1200,"cancelled first dispatch gets bounded priority rescan");
 check(s.scanGeneration.get()==1&&s.claimEpoch.get()==1,"queued old callbacks invalidated before wake");
 while(!s.pending.isEmpty())s.pending.remove(0).run();check(s.trace.get(0).equals("wake")&&s.trace.get(1).contains("cancelled"),"log work is off first-claim handoff");
 s.cancelUndispatchedAccept("$133.85 17.9 mi","again");check(s.claimBudget.forgotten==1,"duplicate callback cannot release twice");
 OcrMonitorService ack=activeInstance=new OcrMonitorService();ack.serialTopText="$121.97 0.2 mi";
 noteAcceptGestureDispatched();check(ack.acceptDispatchObservationAt==1000&&ack.trace.equals(List.of("wake")),"dispatch acknowledgement time precedes wake and diagnostic work");
 check(ack.pending.size()==1&&ack.audits==0,"ack audit work is queued off the urgent lane");
 ack.serialTopText="$999 9 mi";while(!ack.pending.isEmpty())ack.pending.remove(0).run();check(ack.trace.get(1).contains("card=$121.97 0.2 mi"),"ack report binds captured transaction even after screen changes");
 noteAcceptGestureDispatched();check(ack.pending.isEmpty(),"same action does not enqueue duplicate ack logs");
 OcrMonitorService retry=activeInstance=new OcrMonitorService();retry.serialTopText="$121.97 0.2 mi";
 retry.retainFirstAcceptAfterUndispatchedRetry(retry.serialTopText,"id",2,1,"RETRY_PAGE_REPROBE_REQUIRED");
 retry.retainFirstAcceptAfterUndispatchedRetry(retry.serialTopText,"id",2,1,"RETRY_PAGE_REPROBE_REQUIRED");
 check(retry.trace.equals(List.of("retry:0","retry:0")),"unsent retries do not inject a settle timer");
 retry.serialTopActionAt++;retry.retryGuard="negative";
 retry.retainFirstAcceptAfterUndispatchedRetry(retry.serialTopText,"id",2,1,"RETRY_PAGE_REPROBE_REQUIRED");
 check(retry.trace.equals(List.of("retry:0","retry:0","wake")),"terminal guard wakes outcome observation without requeuing another retry");
 retry.trace.clear();retry.retryGuard="";
 retry.retainFirstAcceptAfterUndispatchedRetry(retry.serialTopText,"id",2,1,"PRESSURE_STOPPED:LAYOUT_RENEWAL_YIELD");
 check(retry.trace.isEmpty()&&retry.serialTopAction==SerialAction.ACCEPT,"layout yield keeps owner and does not enqueue duplicate inspection");
 retry.trace.clear();retry.acceptDispatchObservationAt=1000;
 retry.cancelUndispatchedAccept(retry.serialTopText,"ACCEPT_BURST_INTERRUPTED");
 check(retry.serialTopAction==SerialAction.ACCEPT&&retry.claimBudget.forgotten==0
    &&retry.trace.equals(List.of("retry:0")),"partially delivered first batch retains ownership and checks result");
 OcrMonitorService fast=activeInstance=new OcrMonitorService();fast.serialTopText="$121.97 0.2 mi";
 fast.pressureActive=true;fast.acceptClickWorker=new Handler();
 noteAcceptGestureDispatched();
 check(fast.trace.equals(List.of("wake")),"first pressure ACK wakes tracking");
 noteAcceptGestureDispatched();
 check(fast.trace.equals(List.of("wake")),"same pressure ACK does not duplicate scan wake");
 check(fast.acceptClickWorker.delay==172L&&fast.acceptClickWorker.pending!=null,
       "first accepted gesture uses the same bounded callback-loss recovery as later gestures");
 fast.acceptClickWorker.pending.run();
 check(fast.scheduledPressure==1,"owner-matched watchdog enters same-transaction retry if callback is lost");
 fast.pressureActive=false;fast.acceptClickWorker.pending.run();
 check(fast.scheduledPressure==1,"loading/terminal/stop gate prevents late timer retry");
 OcrMonitorService second=activeInstance=new OcrMonitorService();second.serialTopText="$121.97 0.2 mi";
 second.pressureActive=true;second.acceptClickWorker=new Handler();second.acceptAudit.count=1;
 noteAcceptGestureDispatched();
 check(second.acceptClickWorker.delay==172L,"subsequent pressure uses 172ms callback-loss recovery");
 second.claimEpoch.incrementAndGet();second.acceptClickWorker.pending.run();
 check(second.scheduledPressure==0,"old claim epoch timer cannot override newer Accept");
 System.out.println("22 production Accept handoff/reporter/ack/early-pressure cases passed");}}
'''
with tempfile.TemporaryDirectory(prefix='csa-handoff-') as d:
 h=Path(d)/'OcrMonitorService.java';h.write_text(header+block('    private void cancelUndispatchedAccept(')+block('    private void retainFirstAcceptAfterUndispatchedRetry(')+block('    private String acceptTiming(')+block('    private java.util.function.Consumer<String> acceptReporter(')+block('    public static void noteAcceptGestureDispatched() {')+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(s/'CardText.java'),str(s/'OfferEnrichmentPolicy.java'),str(s/'ActionDispatchPolicy.java'),str(h)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.OcrMonitorService'],check=True)
