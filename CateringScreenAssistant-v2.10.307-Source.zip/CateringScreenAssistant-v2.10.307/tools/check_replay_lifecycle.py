from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1]
stubs={
'android/content/Context.java':'''package android.content;import java.io.*;public class Context {final File f;public Context(File f){this.f=f;}public File getCacheDir(){return f;}}''',
'android/os/Handler.java':'''package android.os;import java.util.*;public class Handler {public final List<Runnable> pending=new ArrayList<>(),delayed=new ArrayList<>();public boolean post(Runnable r){pending.add(r);return true;}public boolean postDelayed(Runnable r,long ms){delayed.add(r);return true;}public void drain(){while(!pending.isEmpty())pending.remove(0).run();}}''',
'android/os/Process.java':'''package android.os;public class Process {public static int THREAD_PRIORITY_BACKGROUND=10;public static void setThreadPriority(int x){}}''',
'android/os/SystemClock.java':'''package android.os;public class SystemClock{public static long elapsedRealtime(){return 0;}}''',
'android/util/Log.java':'''package android.util;public class Log{public static int w(String t,String m,Throwable e){e.printStackTrace();return 0;}}''',
'android/util/AtomicFile.java':'''package android.util;import java.io.*;public class AtomicFile{final File f;public AtomicFile(File f){this.f=f;}public FileOutputStream startWrite()throws IOException{f.getParentFile().mkdirs();return new FileOutputStream(f);}public void finishWrite(FileOutputStream s)throws IOException{s.close();}public void failWrite(FileOutputStream s)throws IOException{s.close();}}''',
'android/media/Image.java':'''package android.media;import java.nio.*;public class Image{public Plane[]getPlanes(){return new Plane[]{new Plane()};}public int getWidth(){return 40;}public int getHeight(){return 40;}public long getTimestamp(){return 123000L;}public static class Plane{public int getPixelStride(){return 4;}public int getRowStride(){return 160;}public ByteBuffer getBuffer(){return ByteBuffer.allocate(6400);}}}''',
'android/graphics/Bitmap.java':'''package android.graphics;import java.io.*;public class Bitmap{public enum Config{ARGB_8888}public enum CompressFormat{JPEG}public static Bitmap createBitmap(int[]p,int w,int h,Config c){return new Bitmap();}public boolean compress(CompressFormat c,int q,OutputStream s){return true;}public void recycle(){}}'''
}
test=r'''package com.local.cateringscreenassistant;
import android.content.*;import android.os.*;import android.media.*;import java.io.*;import java.nio.charset.*;import java.util.zip.*;
public class ReplayLifecycleTest {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static String read(File f){try(ZipFile z=new ZipFile(f)){return new String(z.getInputStream(z.getEntry("timeline.txt")).readAllBytes(),StandardCharsets.UTF_8);}catch(Exception e){return "";}}
 public static void main(String[]args)throws Exception{
  Context c=new Context(new File(args[0]));Handler h=new Handler();AcceptReplay r=new AcceptReplay(c);
  r.dispatched(h,1,1000,980);h.drain();r.dispatched(h,1,1020,0);
  check(h.delayed.size()==1,"retries retain one clip");
  r.sample(new Image(),1050,"NO_CTA_CANDIDATE",1048);
  r.sample(new Image(),1065,"CTA_CANDIDATE",1063);
  r.markDiscovery(1066,"OFFER_WAKE_SIGNAL");
  r.markDiscovery(1070,"ACCEPT_INDEX_READ_BEGIN");
  r.dispatched(h,2,1100,1080);h.drain();
  check(h.delayed.size()==2,"new transaction gets independent recording during old clip");
  h.delayed.get(0).run();r.event(1120,"NEW_OWNER");
  h.delayed.get(1).run();
  File f=AcceptReplay.latestFile(c);String text="";
  for(int i=0;i<200;i++){text=read(f);if(text.contains("tx_elapsed_ms=2\n")&&text.contains("NEW_OWNER"))break;Thread.sleep(10);}
  check(text.contains("tx_elapsed_ms=2\n")&&text.contains("NEW_OWNER"),"old delayed finish never closes or overwrites new recording");
  check(!text.contains("tx_elapsed_ms=1\n"),"latest export belongs to new transaction");
  check(text.contains("pre_dispatch_frames=2\n"),"a visual edge is retained within the normal frame interval");
  check(text.contains("1050\tSCREEN_CTA_SAMPLE\tNO_CTA_CANDIDATE"),"previous empty screenshot can be aligned");
  check(text.contains("1065\tSCREEN_CTA_SAMPLE\tCTA_CANDIDATE"),"candidate appearance is recorded");
  check(text.contains("1066\tOFFER_WAKE_SIGNAL")&&text.contains("1070\tACCEPT_INDEX_READ_BEGIN"),"wake and index marker emerge in the clip");
  check(text.contains("callback_elapsed_ms=1063 producer_timestamp_ns=123000"),"frame clock domains exported separately");
  check(text.contains("1080\tFIRST_LOCAL_NUMERIC tx=2"),"first numeric time is bound to the current transaction");
  check(text.contains("cta_edge_status=BRACKETED"),"visual edge evidence is explicit");
  r.sample(new Image(),2000,"NO_CTA_CANDIDATE",1999);
  // Production sends the first gesture before copying the same acquired CTA frame.
  r.dispatched(h,3,62008,62003);
  r.sample(new Image(),62000,"CTA_CANDIDATE",61998);
  h.drain();h.delayed.get(2).run();
  for(int i=0;i<200;i++){text=read(f);if(text.contains("tx_elapsed_ms=3\n"))break;Thread.sleep(10);}
  check(text.contains("cta_edge_status=BRACKETED_WIDE")&&text.contains("cta_edge_gap_ms=60000")
        &&text.contains("last_no_cta_elapsed_ms=2000")&&text.contains("first_cta_elapsed_ms=62000")
        &&text.contains("pre_dispatch_frames=2"),"static idle frame and deferred CTA copy are both kept in timestamp-ordered pre-roll");
  r.clearPreRoll();
  r.sample(new Image(),63000,"CTA_CANDIDATE",62999);
  r.dispatched(h,4,63010,63003);h.drain();h.delayed.get(3).run();
  for(int i=0;i<200;i++){text=read(f);if(text.contains("tx_elapsed_ms=4\n"))break;Thread.sleep(10);}
  check(text.contains("cta_edge_status=NO_PRECEDING_NO_CTA_FRAME")
        &&text.contains("last_no_cta_elapsed_ms=-1"),"new foreground does not inherit an old negative frame");
  System.out.println("13 production replay rollover/export/discovery cases passed");
 }
}'''
with tempfile.TemporaryDirectory() as d:
 d=Path(d);files=[]
 for n,s in stubs.items():
  f=d/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s);files.append(str(f))
 h=d/'ReplayLifecycleTest.java';h.write_text(test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',str(d),*files,str(root/'app/src/main/java/com/local/cateringscreenassistant/AcceptReplay.java'),str(h)],check=True)
 subprocess.run(['java','-cp',str(d),'com.local.cateringscreenassistant.ReplayLifecycleTest',str(d/'cache')],check=True)


monitor=(root/'app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java').read_text()
frame=monitor[monitor.index('    private void onFrame('):monitor.index('    private boolean tryVisualAccessibilityFastLane(')]
assert 'screenAccept != null && screenAcceptVisible' in frame
assert frame.index('tryVisualAccessibilityFastLane(') < frame.index('if (replayAfterVisual) sampleOfferReplayFrame(')
assert frame.index('if (replayAfterVisual) sampleOfferReplayFrame(') < frame.index('} finally { image.close(); }',frame.index('if (replayAfterVisual)'))
assert 'hotDetection==screenAccept ? !screenAcceptVisible : acceptSpinnerMask(image,button)!=0' in frame
