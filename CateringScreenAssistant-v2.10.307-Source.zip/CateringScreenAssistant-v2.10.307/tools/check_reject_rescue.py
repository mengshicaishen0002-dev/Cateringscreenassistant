#!/usr/bin/env python3
"""Execute production final Reject dispatcher with changing UI/ownership fixtures."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'TapAccessibilityService.java').read_text()
a=s.index('    private static void tapSnapshotRejectFast(FastOfferSnapshot snapshot,float amount,float miles,')
b=s.index('    private static String rejectProbeEvidence(',a)
methods=s[a:b]
head='''package com.local.cateringscreenassistant;
import java.util.concurrent.atomic.*;import java.util.function.*;
class SystemClock {static long now=1000;static long elapsedRealtime(){return now;}}
class Rect {boolean empty;Rect(){}Rect(Rect r){empty=r.empty;}boolean isEmpty(){return empty;}}
class Handler {void post(Runnable r){r.run();}void postAtFrontOfQueue(Runnable r){r.run();}}
class OcrMonitorService {static boolean monitoring=true,paused;static boolean isMonitoring(){return monitoring;}static boolean isManualInterventionPaused(){return paused;}}
public class TapAccessibilityService {
 static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>();
 static AtomicLong UI_GENERATION=new AtomicLong(1),WINDOW_TRANSITION_EPOCH=new AtomicLong(1);
 Handler main=new Handler();static int gestures,hybrids,boundClicks,checks;static boolean popup,churn,stop,window,losePriority;static boolean priority=true;
 static FastOfferSnapshot refreshed;
 static class FastOfferSnapshot {String text;Object rejectProof;Rect rejectBounds=new Rect();boolean rejectEnabled=true;long capturedAt=1000;FastOfferSnapshot(String t){text=t;}}
 static FastOfferSnapshot quickRefreshTopAction(TapAccessibilityService s,float a,float m,boolean accept){return refreshed;}
 static boolean largeOrderPopupRecentlyVisible(long age){return popup;}static boolean isLargeOrderInfoPopupVisible(){return popup;}
 static void dispatchBoundReject(TapAccessibilityService s,FastOfferSnapshot snapshot,Consumer<String> ok,Consumer<String> fail,BooleanSupplier mayDispatch){if(mayDispatch==null||mayDispatch.getAsBoolean())boundClicks++;}
 static void dispatchRejectHybrid(TapAccessibilityService s,float a,float m,Rect r,String t,boolean monitoring,Consumer<String> ok,Consumer<String> fail){hybrids++;}
 static void dispatchActionGesture(TapAccessibilityService s,Rect r,boolean accept,long ms,int variant,Consumer<String> ok,Consumer<String> fail,BooleanSupplier fresh){
  if(accept||ms!=90)throw new AssertionError("rescue must use Reject fallback gesture");
  if(churn)UI_GENERATION.incrementAndGet();if(window)WINDOW_TRANSITION_EPOCH.incrementAndGet();if(stop)OcrMonitorService.monitoring=false;if(losePriority)priority=false;
  if(fresh.getAsBoolean()){gestures++;ok.accept("sent");}else fail.accept("stale");
 }
 static String card="$30.00 3.2 mi Tomorrow at 12:05 PM Mendocino Farms • 4201 McGowen St #205, Long Beach, CA 90808";
 static FastOfferSnapshot setup(){INSTANCE.set(new TapAccessibilityService());UI_GENERATION.set(1);WINDOW_TRANSITION_EPOCH.set(1);SystemClock.now=1000;OcrMonitorService.monitoring=true;OcrMonitorService.paused=false;gestures=hybrids=boundClicks=0;popup=churn=stop=window=losePriority=false;priority=true;refreshed=null;return new FastOfferSnapshot(card);}
 static void send(FastOfferSnapshot f,boolean rescue){tapSnapshotRejectFast(f,30f,3.2f,d->{},r->{},()->priority,rescue);}
 static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
'''
tests=''' public static void main(String[] args){
 FastOfferSnapshot f=setup();send(f,true);check(gestures==1&&hybrids==0,"fresh rescue uses gesture instead of repeating semantic click");
 f=setup();send(f,false);check(gestures==0&&hybrids==1,"first Reject without a receipt preserves hybrid path");
 f=setup();f.rejectProof=new Object();tapSnapshotRejectFast(f,30f,3.2f,d->{},r->{},null,false);
 check(boundClicks==1&&gestures==0&&hybrids==0,"first Reject with a receipt bypasses re-indexing");
 f=setup();f.rejectProof=new Object();send(f,false);check(boundClicks==1&&hybrids==0,"first Reject with an owner guard still uses fast bound ACTION_CLICK");
 f=setup();f.rejectProof=new Object();priority=false;send(f,false);check(boundClicks==0&&hybrids==0,"stale Reject owner cancelled before initial click");
 f=setup();f.rejectProof=new Object();send(f,true);check(boundClicks==0&&gestures==1,"final rescue keeps independent current-gesture guard");
 f=setup();f.rejectEnabled=false;send(f,true);check(gestures==0,"disabled Reject never gets rescue");
 f=setup();SystemClock.now=1500;refreshed=new FastOfferSnapshot(card.replace("4201","4202"));send(f,true);check(gestures==0,"refreshed different address rejected");
 f=setup();SystemClock.now=1500;refreshed=new FastOfferSnapshot(card);refreshed.capturedAt=1500;send(f,true);check(gestures==1,"stale soft snapshot refreshes same card before rescue");
 f=setup();SystemClock.now=3201;send(f,true);check(gestures==0,"hard expiry cannot dispatch");
 f=setup();SystemClock.now=999;send(f,true);check(gestures==0,"reversed clock cannot dispatch");
 f=setup();priority=false;send(f,true);check(gestures==0,"foreground new-card priority wins before action");
 f=setup();losePriority=true;send(f,true);check(gestures==0,"foreground priority wins at final dispatch fence");
 f=setup();churn=true;send(f,true);check(gestures==0,"generation changes cancel gesture");
 f=setup();window=true;send(f,true);check(gestures==0,"window changes cancel gesture");
 f=setup();stop=true;send(f,true);check(gestures==0,"monitor stop at final fence cancels");
 f=setup();OcrMonitorService.paused=true;send(f,true);check(gestures==0,"manual intervention cancels");
 f=setup();popup=true;send(f,true);check(gestures==0,"popup blocks rescue");
 System.out.println(checks+" production final Reject gesture/ownership cases passed");
 }}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'TapAccessibilityService.java';p.write_text(head+methods+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in ['CardText.java','ClaimSuccessSignals.java','OfferEnrichmentPolicy.java','FastSnapshotPolicy.java','ActionDispatchPolicy.java']],str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.TapAccessibilityService'],check=True)
