#!/usr/bin/env python3
"""Assert priority wiring in the actual production Java source."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java').read_text()
t=(root/'app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java').read_text()
checks={
    'takeover before serial owner':s.index('if (service.preemptRejectForQualifiedTop(now, structural, priorityOffer))')<s.index('if (service.handlePendingSerialFast(now))'),
    'new top always indexed': 'getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(' in s[s.index('private boolean preemptRejectForQualifiedTop'):s.index('private boolean handlePendingSerialFast')],
    'only old REJECT can be preempted': 'if (serialTopAction != SerialAction.REJECT' in s[s.index('private boolean preemptRejectForQualifiedTop'):s.index('private boolean handlePendingSerialFast')],
    'old reject lock retired ahead of accept':s.index('retireStaleSerialLock(current.text, "QUALIFIED_ACCEPT_PREEMPT_REJECT"')<s.index('boolean sent = universal ? dispatchUniversalNumericAccept(current)'),
    'keeps normal universal and Pasadena rule': 'fastRuleFailure(current).isEmpty()' in s[s.index('private boolean preemptRejectForQualifiedTop'):s.index('private boolean handlePendingSerialFast')],
    'old callback fenced via epoch': 'claimEpoch.incrementAndGet();' in s[s.index('private void retireStaleSerialLock'):s.index('private int topCropTop')],
    'reject dispatch bound to same transaction': 'rejectEpoch == claimEpoch.get()' in s[s.index('private void handleRejectedCard('):s.index('private final Runnable rejectProofRefresh')],
    'Reject fast-path retains direct bound click': 'if (!gestureRescue && snapshot.rejectProof != null)' in t,
    'Reject direct click owner check': 'mayDispatch == null || mayDispatch.getAsBoolean()' in t[t.index('private static void dispatchBoundReject'):t.index('private static void tapSnapshotRejectFast(')],
    'OCR Reject queued action owner check': '新合格订单优先；旧OCR Reject已取消' in t,
    'OCR qualified new top first frame': 'OCR合格订单抢占旧Reject' in s,
    'pending accept still serial owner': 'if (serialTopAction == SerialAction.ACCEPT)' in s[s.index('private boolean handlePendingSerialFast'):s.index('private String acceptCardSafetyReason')],
    'empty departure releases and top change retains only existing dispatch lease': 'rejectSequence.forget(id);' in s[s.index('private void recordRejectDeparture'):s.index('private void observeRejectEmptyOffers')],
}
for name,ok in checks.items():
    if not ok: raise AssertionError(name)
    print('PASS',name)
print(len(checks),'priority integration cases passed')
