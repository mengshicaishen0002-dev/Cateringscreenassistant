from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text()
def block(text,sig):
 a=text.index(sig);b=text.index('{',a);i=b+1;d=1
 while d:d+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[a:i]
legacy=(r/'tests/VisualPixelsLegacy.txt').read_text().replace('findVisualAcceptButton','legacyFind').replace('scanVisualAcceptButton','legacyScan')
methods='\n'.join(block(s,x) for x in ['    private VisualAcceptDetection findCompleteVisualAcceptInImage(', '    private interface VisualPixels','    private VisualAcceptDetection findVisualAcceptButton(','    private VisualAcceptDetection findVisualAcceptInImage(','    private VisualAcceptDetection detectVisualAccept(','    private final class VisualAcceptScan','    private boolean looksLikeAcceptBlue(','    private boolean looksLikeEarlyAcceptBlue(','    private boolean isAcceptShape(','    private static final class VisualAcceptDetection'])
header='''package com.local.cateringscreenassistant;
import java.nio.*;import java.util.*;
public class DetectorHarness {
 int[] visualScanPixels;int width=709;
 static class Rect {int left,top,right,bottom;Rect(int a,int b,int c,int d){left=a;top=b;right=c;bottom=d;}Rect(Rect r){this(r.left,r.top,r.right,r.bottom);}boolean isEmpty(){return right<=left||bottom<=top;}int width(){return right-left;}int height(){return bottom-top;}int centerX(){return (left+right)/2;}int centerY(){return (top+bottom)/2;}void union(Rect r){left=Math.min(left,r.left);top=Math.min(top,r.top);right=Math.max(right,r.right);bottom=Math.max(bottom,r.bottom);}public String toString(){return left+","+top+","+right+","+bottom;}}
 static class Bitmap {int w,h,reads;int[] p;Bitmap(int w,int h){this.w=w;this.h=h;p=new int[w*h];}int getWidth(){return w;}int getHeight(){return h;}void getPixels(int[] a,int off,int stride,int x,int y,int w,int h){reads++;for(int j=0;j<h;j++)System.arraycopy(p,(y+j)*this.w+x,a,off+j*stride,w);}}
 static class Image {static class Plane {ByteBuffer b;int row,pixel=4;ByteBuffer getBuffer(){return b;}int getRowStride(){return row;}int getPixelStride(){return pixel;}}Plane p=new Plane();int h,w;int getWidth(){return w;}Plane[] getPlanes(){return new Plane[]{p};}int getHeight(){return h;}Image(Bitmap b,int top){w=b.w;h=top+b.h;p.row=b.w*4+32;p.b=ByteBuffer.allocate(h*p.row);for(int y=0;y<b.h;y++)for(int x=0;x<b.w;x++){int at=(top+y)*p.row+x*4,c=b.p[y*b.w+x];p.b.put(at,(byte)(c>>16));p.b.put(at+1,(byte)(c>>8));p.b.put(at+2,(byte)c);p.b.put(at+3,(byte)255);}}}
 static String key(VisualAcceptDetection v){return v==null?"NONE":v.bounds+":"+v.earlyFade;}
 static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
'''
test='''public static void main(String[] args){DetectorHarness t=new DetectorHarness();Random rnd=new Random(160);int checks=0;
 for(int i=0;i<180;i++){int w=i%2==0?709:1080,h=900;Bitmap b=new Bitmap(w,h);Arrays.fill(b.p,0xfff0f0f0);
 int rects=i<4?1:1+rnd.nextInt(6);for(int j=0;j<rects;j++){int x=i<4?(int)(w*.55):rnd.nextInt(w),y=i<4?580:rnd.nextInt(h);int rw=i<4?(int)(w*.32):40+rnd.nextInt(w/2),rh=i<4?60:5+rnd.nextInt(150);int c=new int[]{0xff22b1e8,0xff9bdced,0xffbbbbbb,0xffee5555}[i<4?i:rnd.nextInt(4)];for(int yy=y;yy<Math.min(h,y+rh);yy++)for(int xx=x;xx<Math.min(w,x+rw);xx++)b.p[yy*w+xx]=c;}
 for(boolean early:new boolean[]{false,true}){String old=key(t.legacyFind(b,early));b.reads=0;String now=key(t.findVisualAcceptButton(b,early));check(old.equals(now),"legacy equivalence "+i+" "+old+" "+now);check(b.reads==1,"one bitmap read");checks+=2;
 t.width=w;Image image=new Image(b,31);check(now.equals(key(t.findVisualAcceptInImage(image,31,31+h,early))),"strided RGBA direct pixels match Bitmap");checks++;}
 }
 Bitmap b=new Bitmap(709,900);Image bad=new Image(b,0);bad.p.pixel=3;check(t.findVisualAcceptInImage(bad,0,900,true)==null,"unsupported stride never clicks");
 Bitmap clipped=new Bitmap(1080,2340);Arrays.fill(clipped.p,0xfff0f0f0);
 for(int yy=1253;yy<1361;yy++)for(int xx=563;xx<965;xx++)clipped.p[yy*1080+xx]=0xff22b1e8;
 t.width=1080;Image edge=new Image(clipped,0);
 VisualAcceptDetection part=t.findVisualAcceptInImage(edge,468,1357,false),full=t.findCompleteVisualAcceptInImage(edge,468,1357,false);
 check(part!=null&&part.bounds.bottom+468<1361,"real trace truncates at94percent scan edge");checks++;
 check(full!=null&&Math.abs(full.bounds.top+468-1253)<=2&&full.bounds.bottom+468>=1360,"same-frame edge expansion restores complete CTA center: "+key(full));checks++;
 Bitmap ordinary=new Bitmap(1080,2340);Arrays.fill(ordinary.p,0xfff0f0f0);
 for(int yy=1153;yy<1221;yy++)for(int xx=563;xx<965;xx++)ordinary.p[yy*1080+xx]=0xff22b1e8;
 Image normal=new Image(ordinary,0);
 check(key(t.findVisualAcceptInImage(normal,468,1357,false)).equals(key(t.findCompleteVisualAcceptInImage(normal,468,1357,false))),"ordinary CTA geometry unchanged");checks++;
 for(int yy=1253;yy<1800;yy++)for(int xx=563;xx<965;xx++)clipped.p[yy*1080+xx]=0xff22b1e8;
 check(t.findCompleteVisualAcceptInImage(new Image(clipped,0),468,1357,false)==null,"still-clipped or oversized region cannot be clicked");checks++;
 System.out.println((checks+1)+" production visual pixel equivalence/copy cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 h=Path(d)/'DetectorHarness.java';h.write_text(header+methods+legacy+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'VisualAcceptFadePolicy.java'),str(h)],check=True)
 subprocess.run(['java','-Xmx512m','-cp',d,'com.local.cateringscreenassistant.DetectorHarness'],check=True)
