from pathlib import Path
import tempfile,subprocess
p=Path(__file__).resolve().parents[1]/'app/src/main/java/com/local/cateringscreenassistant'
s=r'''package com.local.cateringscreenassistant;
class OwnedSuccessTest {
 static int n;static void ok(boolean b,String m){n++;if(!b)throw new AssertionError(m);}
 static String text="$101.04 6.8 mi Today at 11:05 AM Red Robin • 3301 E Main St, Ventura, CA 93003";
 static PageOutcomePolicy.Reading read(long at,int w,long e,boolean complete,boolean owned,String hint){return new PageOutcomePolicy.Reading(w,e,at,at+10,complete,true,hint,null,"OWNED_ROW_INCOMPLETE",7,50,"","NOT_EXPORTED","",owned);}
 static PageOutcomePolicy.Tracker tracker(){return new PageOutcomePolicy.Tracker(1000,text,null,false);}
 public static void main(String[] a){
  PageOutcomePolicy.Tracker t=tracker();t.observe(read(1100,1,3,true,true,""),1110);ok(!t.hasConfirmedOwnedSuccess(),"one read not enough");
  t.observe(read(1190,1,3,true,true,""),1200);ok(t.hasConfirmedOwnedSuccess(),"two bound detail reads confirm despite absent original offer");
  t=tracker();t.observe(read(1100,1,3,true,true,""),1110);t.observe(read(1190,2,3,true,true,""),1200);ok(!t.hasConfirmedOwnedSuccess(),"window changed");
  t=tracker();t.observe(read(1100,1,3,true,true,""),1110);t.observe(read(1150,1,3,false,false,""),1160);t.observe(read(1200,1,3,true,true,""),1210);ok(!t.hasConfirmedOwnedSuccess(),"incomplete resets consecutive proof");
  t=tracker();t.observe(read(1100,1,3,true,true,""),1110);t.observe(read(1200,1,3,true,true,"offer unavailable"),1210);ok(!t.hasConfirmedOwnedSuccess(),"negative veto");
  t=tracker();t.observe(read(900,1,3,true,true,""),1110);t.observe(read(1190,1,3,true,true,""),1200);ok(!t.hasConfirmedOwnedSuccess(),"pre dispatch proof rejected");
  ok(CardText.knownJobFieldsAgree(text,"Begin Delivery"),"missing fields preserve stable fallback");
  ok(!CardText.knownJobFieldsAgree(text,text.replace("101.04","102.04")+" Begin Delivery"),"different amount rejected");
  ok(!CardText.knownJobFieldsAgree(text,text.replace("11:05","12:05")+" Begin Delivery"),"different pickup rejected");
  ok(ClaimSuccessSignals.acceptedJobMatchesOffer(text,text+" Begin Delivery"),"strict detail binding");
  t=tracker();t.observe(new PageOutcomePolicy.Reading(1,3,1100,1100,false,false,"",null,"INDEX_BUSY",0,0),1100);
  ok(t.nextContinuousProbeDelayMs(1,1100)>=80,"busy reader does not consume rapid snapshot-recovery attempts");
  ok(!t.retryContextBlocked() && t.mayProbeContinuous(1100),"busy reader retains terminal observation without blocking current owner");
  System.out.println(n+" owned-success isolation cases passed");
 }
}'''
with tempfile.TemporaryDirectory() as d:
 h=Path(d)/'OwnedSuccessTest.java';h.write_text(s)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(p/x) for x in ['PageOutcomePolicy.java','CardText.java','ClaimSuccessSignals.java','OfferEnrichmentPolicy.java']],str(h)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.OwnedSuccessTest'],check=True)

