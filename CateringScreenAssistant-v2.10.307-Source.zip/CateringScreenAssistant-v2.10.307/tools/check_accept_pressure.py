"""Run actual pressure lifecycle, cached dispatch guard and current-proof resume methods."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()
def block(sig):
 a=s.index(sig);i=s.index('{',a)+1;end=i;depth=1
 while depth:depth+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[a:end]
methods='\n'.join(block(sig) for sig in ['    private void armAcceptPressure(', '    private boolean hasSpinnerCandidate(', '    private boolean preserveVisibleAcceptLoading(', '    public static String acceptLoadingRetryBlock(', '    public static boolean canReadAcceptRecoveryProof(', '    private void applyAcceptSpinnerMask(', '    private void expireSpinnerCandidate(', '    public static boolean acceptPressureActive(', '    public static String acceptPressureGuard(', '    private void pauseAcceptPressureForContext(', '    private void finishAcceptPressure(', '    private void releaseAcceptAdmission(', '    private void scheduleAcceptPressure(', '    private void runAcceptPressure(', '    private boolean recordResumeBlock(', '    private String spinnerResumeBlock(', '    private boolean resumeAcceptPressure(', '    private boolean resumePressureFromPage('])
head='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;
class SystemClock{static long now=1000;static long elapsedRealtime(){return now;}}
class Handler{List<Runnable> tasks=new ArrayList<>(),delayed=new ArrayList<>();boolean postAtFrontOfQueue(Runnable r){tasks.add(0,r);return true;}void postDelayed(Runnable r,long ms){delayed.add(r);}void run(){if(!tasks.isEmpty())tasks.remove(0).run();}}
class TapAccessibilityService{
 static long outcomeWindowEpoch(){return 1;}
 static boolean foreground=true;static String proofBlock="";static boolean hasDeliverThatReplayForegroundHint(){return foreground;}
 static String pressureResumeProofBlock(FastOfferSnapshot s,String text,long owner){
  if(!foreground)return "FOREGROUND_CHANGED";
  if(!proofBlock.isEmpty())return proofBlock;
  if(!OcrMonitorService.guard.isEmpty())return OcrMonitorService.guard;
  return s!=null&&s.valid&&s.capturedAt<=SystemClock.now&&SystemClock.now-s.capturedAt<=250?"":"STALE_PROOF";
 }
 static FastOfferSnapshot receipt;static FastOfferSnapshot takeAcceptPageRetrySnapshot(String text,long owner){FastOfferSnapshot s=receipt;receipt=null;return s;}
 static void startAcceptControlWatch(String t,long at){OcrMonitorService.activeInstance.watches++;}
 static class FastOfferSnapshot{String identity="offer",text=OcrMonitorService.OFFER;long capturedAt=SystemClock.now,proofStartedAt=capturedAt,controlReadAt;long acceptProofStartedAt(){return proofStartedAt;}long acceptControlReadAt(){return controlReadAt>0?controlReadAt:proofStartedAt;}boolean valid=true;}
}
class OcrMonitorService {
 static final String OFFER="$110.97 0.3 mi Mendocino Farms • 444 Flower St, Los Angeles, CA 90071";
 static OcrMonitorService activeInstance;
 enum SerialAction{NONE,ACCEPT}
 SerialAction serialTopAction=SerialAction.ACCEPT;long serialTopActionAt=1000,pressureOwner,pressureEpoch,spinnerObservedAt,lastSpinnerFrameAt,spinnerCandidateAt,spinnerWindowEpoch,acceptRetryDispatchPendingAt;
 int spinnerClearFrames;long spinnerFirstClearAt,spinnerClearedAt;SPINNER_TIMING_CONSTANTSAtomicLong queuedPressureOwner=new AtomicLong();
 String serialTopText=OFFER;AtomicLong claimEpoch=new AtomicLong(1);
 boolean monitorReady=true,paused;static String guard="";
 Handler acceptClickWorker=new Handler(),acceptProofWorker=new Handler();int recoveryWakes;
 void scheduleEnabledClaimInspection(String text,long epoch,long at){recoveryWakes++;}TapAccessibilityService.FastOfferSnapshot pressureSnapshot,spinnerSnapshot;
 AcceptSpinnerPolicy.Tracker spinnerTracker=new AcceptSpinnerPolicy.Tracker();
 AtomicBoolean acceptAdmissionBusy=new AtomicBoolean(),pressureAdmissionWaiting=new AtomicBoolean();
 PageOutcomePolicy.Tracker tracker=new PageOutcomePolicy.Tracker(1000,OFFER,null,false);
 PageOutcomePolicy.Tracker pageTracker(long at){return at==serialTopActionAt?tracker:null;}
 static class Budget{int sends=1;void enableContinuous(String id,long now){}}
 Budget claimBudget=new Budget();int inspections,probes,watches;List<String> events=new ArrayList<>();
 static class Replay{void event(long at,String text){activeInstance.events.add(text);}void pinFrameAt(long at){}}Replay acceptReplay=new Replay();
 static boolean isManualInterventionPaused(){return activeInstance.paused;}
 static String acceptRetryGuard(long at){return guard;}
 java.util.function.Consumer<String> acceptReporter(String text){return events::add;}
 void scheduleAcceptPageProbe(long at){probes++;}
 void scheduleClaimInspection(String text,long epoch,int a,int b,long delay){inspections++;}
 boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot,long epoch,long a,long b,boolean pressure){
  if(!pressure||snapshot!=pressureSnapshot)throw new AssertionError("lost admitted CTA");
  claimBudget.sends++;return true;
 }
 String acceptRetryDecisionText(String text){return text;}
 String acceptResultTiming(String text,String phase,long at){return phase+"="+at;}
 static int checks;static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
 static OcrMonitorService fresh(){SystemClock.now=1000;OcrMonitorService h=new OcrMonitorService();activeInstance=h;guard="";TapAccessibilityService.foreground=true;TapAccessibilityService.proofBlock="";TapAccessibilityService.receipt=null;h.armAcceptPressure(new TapAccessibilityService.FastOfferSnapshot(),1);return h;}
 static TapAccessibilityService.FastOfferSnapshot current(){return new TapAccessibilityService.FastOfferSnapshot();}
'''
head=head.replace('SPINNER_TIMING_CONSTANTS', ' '.join(
    line.strip() for line in s.splitlines()
    if line.strip().startswith('private static final long SPINNER_')))
tests='''public static void main(String[] args){
 OcrMonitorService h=fresh();check(h.acceptClickWorker.delayed.isEmpty(),"no arbitrary pressure expiry");
 for(int i=0;i<820;i++){h.scheduleAcceptPressure(1000,1);h.acceptClickWorker.run();SystemClock.now+=17;}
 check(h.claimBudget.sends==821&&h.pressureSnapshot!=null,"continuous valid pressure has no count cap");
 SystemClock.now=20000;h.scheduleAcceptPressure(1000,1);h.acceptClickWorker.run();check(h.claimBudget.sends==822,"no elapsed-time stop");
 h.scheduleAcceptPressure(1000,1);
 SystemClock.now=20010;h.applyAcceptSpinnerMask(OFFER,1000,1,20010,1);
 h.acceptClickWorker.run();check(h.claimBudget.sends==822&&h.pressureSnapshot!=null,"first spinner sector blocks already queued pressure without retiring the transaction");
 check(acceptPressureGuard(1000).equals("RETRY_SPINNER_CANDIDATE"),"loading candidate is visible at the final dispatch fence");
 SystemClock.now=20026;h.applyAcceptSpinnerMask(OFFER,1000,1,20026,14);
 h.acceptClickWorker.run();check(h.pressureSnapshot==null&&h.claimBudget.sends==822,"rotated frame confirms loading and ends taps");
 SystemClock.now=21088;TapAccessibilityService.FastOfferSnapshot live=current();
 check(!h.resumeAcceptPressure(1000,1,21088,live)&&h.acceptClickWorker.tasks.isEmpty(),"enabled proof alone cannot override visible loading");
 TapAccessibilityService.receipt=live;
 check(!h.resumePressureFromPage(OFFER,1,21088)&&TapAccessibilityService.receipt==live,
       "an early wake preserves the usable page receipt until the visual gate opens");
 TapAccessibilityService.receipt=null;
 h.applyAcceptSpinnerMask(OFFER,1000,1,21088,0);
 check(!h.resumeAcceptPressure(1000,1,21088,live)&&h.acceptClickWorker.tasks.isEmpty(),"one clear frame keeps the confirmed block");
 SystemClock.now=21104;h.applyAcceptSpinnerMask(OFFER,1000,1,21104,0);
 check(h.acceptProofWorker.tasks.size()==1,"second clear frame immediately queues proof");
 h.applyAcceptSpinnerMask(OFFER,1000,1,21105,0);
 h.acceptProofWorker.run();
 check(h.recoveryWakes==1&&h.acceptProofWorker.tasks.isEmpty(),"more clear frames do not duplicate the wake");
 check(canReadAcceptRecoveryProof(1000)&&!canReadAcceptRecoveryProof(1001),"clear frames allow proof reads for the original owner only");
 live=current();live.proofStartedAt=20025;
 check(!h.resumeAcceptPressure(1000,1,21104,live)&&h.acceptClickWorker.tasks.isEmpty(),"proof started during loading cannot reopen pressure");
 check(h.events.stream().anyMatch(x->x.contains("reason=CONTROL_READ_BEFORE_SPINNER_CLEAR")),"stale control explains why a clear-frame wake cannot dispatch");
 live=current();live.proofStartedAt=20000;live.controlReadAt=21100;
 check(!h.resumeAcceptPressure(1000,1,21104,live),"enabled control sampled before decisive clear frame cannot resume");
 SystemClock.now=21106;live=current();live.proofStartedAt=20000;live.controlReadAt=21106;
 h.resumeAcceptPressure(1000,1,21106,live);
 check(h.acceptClickWorker.tasks.size()==1&&h.claimBudget.sends==822,"an in-flight page read can reuse only a control refreshed after decisive clear");
 h.acceptClickWorker.run();
 check(h.claimBudget.sends==823&&h.spinnerObservedAt==0&&h.events.stream().anyMatch(x->x.contains("SPINNER_CLEARED_SAME_CARD_ENABLED")),"clean reenabled row resumes same transaction and attempt count");
 SystemClock.now=21120;h.applyAcceptSpinnerMask(OFFER,1000,1,21120,1);
 check(acceptLoadingRetryBlock(1000).equals("RETRY_SPINNER_CANDIDATE"),"spinner can be seen again after resumed send");
 h=fresh();SystemClock.now=1020;h.spinnerObservedAt=1010;h.lastSpinnerFrameAt=1010;h.spinnerClearFrames=2;
 live=current();h.resumeAcceptPressure(1000,1,1020,live);
 SystemClock.now=1030;h.applyAcceptSpinnerMask(OFFER,1000,1,1030,1);
 h.acceptClickWorker.run();check(h.claimBudget.sends==1,"recurring loading revokes already queued recovery");
 h=fresh();SystemClock.now=1020;h.spinnerObservedAt=1010;h.lastSpinnerFrameAt=1010;h.spinnerClearFrames=2;
 live=current();h.resumeAcceptPressure(1000,1,1020,live);guard="terminal";
 h.acceptClickWorker.run();check(h.claimBudget.sends==1&&h.spinnerObservedAt==1010,"terminal result wins over queued recovery");
 check(h.events.stream().anyMatch(x->x.contains("phase=SEND reason=terminal")),"queued resume records the terminal reason");
 h=fresh();h.scheduleAcceptPressure(1000,1);h.scheduleAcceptPressure(1000,1);
 check(h.acceptClickWorker.tasks.size()==1,"duplicate retry wakes coalesce");
 SystemClock.now=1010;h.applyAcceptSpinnerMask(OFFER,1000,1,1010,1);h.acceptClickWorker.run();
 SystemClock.now=1026;h.applyAcceptSpinnerMask(OFFER,1000,1,1026,0);
 check(h.acceptClickWorker.tasks.isEmpty(),"one empty frame does not resume");
 SystemClock.now=1042;h.applyAcceptSpinnerMask(OFFER,1000,1,1042,0);h.acceptClickWorker.run();
 check(h.claimBudget.sends==1 && h.hasSpinnerCandidate(1000),"brief spinner visibility gap keeps pressure paused");
 SystemClock.now=1010+SPINNER_CLEAR_MIN_MS;h.applyAcceptSpinnerMask(OFFER,1000,1,SystemClock.now,0);h.acceptClickWorker.run();
 check(h.claimBudget.sends==2,"false candidate clears and retries promptly on clean frames");
 h=fresh();SystemClock.now=1010;h.applyAcceptSpinnerMask(OFFER,1000,1,1010,1);
 SystemClock.now=1010+SPINNER_CANDIDATE_TIMEOUT_MS;h.acceptClickWorker.delayed.remove(0).run();h.acceptClickWorker.run();
 check(h.claimBudget.sends==2,"a lone ambiguous frame times out if the screen stops publishing");
 for(int reason=0;reason<3;reason++){h=fresh();if(reason==0)h.paused=true;if(reason==1)TapAccessibilityService.foreground=false;if(reason==2)guard="terminal";
 h.scheduleAcceptPressure(1000,1);h.acceptClickWorker.run();check(h.claimBudget.sends==1&&h.pressureSnapshot==null,"stop fence "+reason);}
 h=fresh();h.scheduleAcceptPressure(1000,1);h.claimEpoch.incrementAndGet();h.acceptClickWorker.run();check(h.claimBudget.sends==1,"stale owner queue task never clicks");
 h=fresh();h.acceptAdmissionBusy.set(true);h.scheduleAcceptPressure(1000,1);h.acceptClickWorker.run();check(h.claimBudget.sends==1&&h.pressureAdmissionWaiting.get()&&h.acceptClickWorker.delayed.isEmpty(),"contention wakes without timer");
 h.releaseAcceptAdmission();h.acceptClickWorker.run();check(h.claimBudget.sends==2,"admission release resumes immediately");
 h=fresh();h.scheduleAcceptPressure(1000,1);h.pauseAcceptPressureForContext(1000,"FOREIGN_APP",1100);h.acceptClickWorker.run();check(h.claimBudget.sends==1&&h.pressureSnapshot==null,"foreign-root observation revokes already queued pressure");
 check(!acceptPressureGuard(1000).isEmpty(),"pause latch remains without bound server failure");
 SystemClock.now=1200;live=current();h.resumeAcceptPressure(1000,1,1200,live);h.acceptClickWorker.run();h.acceptClickWorker.run();check(h.pressureSnapshot==live&&h.claimBudget.sends==2,"new current enabled proof can recover a foreign-read pause");
 h.pauseAcceptPressureForContext(1000,"OLD_FOREIGN_READ",1100);check(h.pressureSnapshot==live,"old observer cannot revoke newer proof");
 h=fresh();SystemClock.now=1300;live=current();h.resumeAcceptPressure(1000,1,1300,live);h.acceptClickWorker.run();check(h.pressureSnapshot==live&&h.acceptClickWorker.tasks.isEmpty(),"active loop refreshes geometry without adding duplicate click chains");
 h=fresh();SystemClock.now=1500;check(!h.resumeAcceptPressure(1000,1,1000,h.spinnerSnapshot),"original stale rectangle cannot resume");
 h=fresh();h.pauseAcceptPressureForContext(1000,"OWNED_ROW_NOT_FOUND",1100);SystemClock.now=1200;live=current();h.resumeAcceptPressure(1000,1,1200,live);guard="terminal";h.acceptClickWorker.run();check(h.pressureSnapshot==null&&h.claimBudget.sends==1,"terminal wins queued current proof");
 h=fresh();h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,false,false,"",null,"FOREIGN_APP",0,0),1110);
 h.scheduleAcceptPressure(1000,1);h.acceptClickWorker.run();check(h.claimBudget.sends==1,"actual click entry consults page pause even before observer wake");
 h=fresh();check(!h.resumePressureFromPage(OFFER,1,1100),"caption-only wake without page receipt cannot resume");
 h.pauseAcceptPressureForContext(1000,"OWNED_ROW_NOT_FOUND",1100);SystemClock.now=1200;live=current();TapAccessibilityService.receipt=live;
 check(h.resumePressureFromPage(OFFER,1,1201),"completed page proof bypasses a duplicate Binder inspection");h.acceptClickWorker.run();h.acceptClickWorker.run();
 check(h.pressureSnapshot==live&&h.claimBudget.sends==2,"direct page recovery uses current rect and preserves original transaction");
 h=fresh();for(String reason:new String[]{"CONTROL_NOT_EXPORTED","CONTROL_DISABLED","INSPECTOR_DISABLED","INSPECTOR_NO_CURRENT_ACCEPT"}){
  h.pauseAcceptPressureForContext(1000,reason,1100);check(h.pressureSnapshot!=null&&acceptPressureActive(1000),"temporary control export state never pauses admitted pressure: "+reason);
 }
 h=fresh();SystemClock.now=1010;h.applyAcceptSpinnerMask(OFFER,1000,1,1010,1);SystemClock.now=1026;h.applyAcceptSpinnerMask(OFFER,1000,1,1026,14);h.acceptClickWorker.run();
 h.applyAcceptSpinnerMask(OFFER,1000,1,1042,0);h.applyAcceptSpinnerMask(OFFER,1000,1,1058,0);check(!canReadAcceptRecoveryProof(1000)&&h.acceptProofWorker.tasks.isEmpty(),"two adjacent zero masks are not sustained clear");
 h.applyAcceptSpinnerMask(OFFER,1000,1,1074,1);h.applyAcceptSpinnerMask(OFFER,1000,1,1090,0);h.applyAcceptSpinnerMask(OFFER,1000,1,1185,0);check(!canReadAcceptRecoveryProof(1000),"returning spinner resets the quiet interval");
 h.applyAcceptSpinnerMask(OFFER,1000,1,1186,0);check(canReadAcceptRecoveryProof(1000)&&h.acceptProofWorker.tasks.size()==1,"sustained clear opens exactly one proof wake");
 h=fresh();h.pauseAcceptPressureForContext(1000,"OWNED_ROW_NOT_FOUND",1000);SystemClock.now=1100;live=current();
 check(h.resumeAcceptPressure(1000,1,1100,live),"fresh proof queues recovery");TapAccessibilityService.proofBlock="UI_GENERATION_CHANGED";h.acceptClickWorker.run();
 check(h.claimBudget.sends==1&&h.acceptProofWorker.delayed.size()==1,"generation change blocks stale tap but schedules one fresh proof");
 TapAccessibilityService.proofBlock="";SystemClock.now=1116;h.acceptProofWorker.delayed.remove(0).run();check(h.recoveryWakes==1,"fresh proof wake survives benign generation churn");
 System.out.println(checks+" production pressure/context/spinner/current-geometry cases passed");}}'''
with tempfile.TemporaryDirectory(prefix='csa-pressure-') as d:
 p=Path(d)/'OcrMonitorService.java';p.write_text(head+methods+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/f'{name}.java') for name in ['ActionDispatchPolicy','AcceptSpinnerPolicy','PageOutcomePolicy','CardText','OfferEnrichmentPolicy']],str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.OcrMonitorService'],check=True)
