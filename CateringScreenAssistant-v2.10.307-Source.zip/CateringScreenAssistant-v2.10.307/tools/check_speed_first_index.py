#!/usr/bin/env python3
"""Execute speed-first production self-index, same-owner retry and foreground bounds with deterministic Android reads."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant';source=(src/'TapAccessibilityService.java').read_text()
def block(signature):
 a=source.index(signature);b=source.index('{',a);d=1;i=b+1
 while d:
  d+=(source[i]=='{')-(source[i]=='}');i+=1
 return source[a:i]
header=r'''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;import java.util.function.*;import java.util.regex.*;
class SystemClock {static volatile long now=1000;static long elapsedRealtime(){return now;}static long uptimeMillis(){return now;}static synchronized void advance(long ms){now+=ms;}}
class Rect {int left,top,right,bottom;Rect(){}Rect(int a,int b,int c,int d){left=a;top=b;right=c;bottom=d;}Rect(Rect r){set(r);}
 void setEmpty(){left=top=right=bottom=0;}void set(Rect r){left=r.left;top=r.top;right=r.right;bottom=r.bottom;}boolean isEmpty(){return right<=left||bottom<=top;}int centerX(){return (left+right)/2;}int centerY(){return (top+bottom)/2;}boolean contains(int x,int y){return x>=left&&x<right&&y>=top&&y<bottom;}}
class AccessibilityNodeInfo {static final int ACTION_CLICK=16;boolean performAction(int action){TapAccessibilityService.semanticRejectClicks++;return true;}String text="",desc="",pkg="com.deliverthat.driver";boolean enabled=true,actionable=true;int windowId=1;Rect bounds;List<AccessibilityNodeInfo> kids=new ArrayList<>();
 CountDownLatch textRead;int textReads,descriptionReads,boundsReads;AccessibilityNodeInfo parent;AccessibilityNodeInfo getParent(){return parent;}AccessibilityNodeInfo(String t,Rect b){text=t;bounds=b;}CharSequence getText(){textReads++;if(textRead!=null)textRead.countDown();return text;}CharSequence getContentDescription(){descriptionReads++;return desc;}CharSequence getPackageName(){return pkg;}
 static AccessibilityNodeInfo obtain(AccessibilityNodeInfo n){return n;}boolean visible=true;boolean isEnabled(){return enabled;}boolean isVisibleToUser(){return visible;}boolean refreshOK=true,mutateOnRefresh,stopOnRefresh,windowOnRefresh;CountDownLatch gate,entered;int refreshCalls;long refreshCost=1;Runnable refreshHook;boolean refresh(){refreshCalls++;if(refreshHook!=null)refreshHook.run();if(entered!=null)entered.countDown();if(gate!=null)try{gate.await();}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}SystemClock.advance(refreshCost);if(stopOnRefresh)OcrMonitorService.monitoring=false;if(windowOnRefresh)TapAccessibilityService.WINDOW_TRANSITION_EPOCH.incrementAndGet();if(mutateOnRefresh){TapAccessibilityService.UI_GENERATION.incrementAndGet();mutateOnRefresh=false;}return refreshOK;}
 void getBoundsInScreen(Rect b){boundsReads++;if(this==TapAccessibilityService.INSTANCE.get().root)TapAccessibilityService.boundReads++;b.set(bounds);}int getWindowId(){return windowId;}void recycle(){}
 final List<String> queryLog=TapAccessibilityService.queries;
 List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String q){queryLog.add(q);
 if(TapAccessibilityService.queryGate!=null && TapAccessibilityService.gatedQueries.contains(q)) {
  TapAccessibilityService.queryEntered.countDown();
  try{if(!TapAccessibilityService.queryGate.await(2,TimeUnit.SECONDS))throw new IllegalStateException("query coordination");}
  catch(InterruptedException e){Thread.currentThread().interrupt();throw new IllegalStateException(e);}
 }
 SystemClock.advance(2);if(TapAccessibilityService.mutateIndex||TapAccessibilityService.outcomeMutations>0){if(TapAccessibilityService.outcomeMutations>0)TapAccessibilityService.outcomeMutations--;TapAccessibilityService.UI_GENERATION.incrementAndGet();TapAccessibilityService.mutateIndex=false;}
 List<AccessibilityNodeInfo> out=new ArrayList<>();for(AccessibilityNodeInfo n:kids)if((n.text+" "+n.desc).toLowerCase(Locale.US).contains(q.toLowerCase(Locale.US)))out.add(n);return out;}}
class OcrMonitorService {static void noteReplayDiscovery(long at,String stage){}static Handler proof=new Handler(),clicks=new Handler();
 static Handler acceptRenewalHandler(){return proof;}static Handler acceptCallbackHandler(){return clicks;}
 static boolean rejectNumbers;static boolean eventNumbersUniversallyRejected(float amount,float miles){return rejectNumbers && amount>=0 && amount<50;}static int indexedRootWakes;static void requestImmediateFastCheck(long at,boolean structural){if(structural)indexedRootWakes++;}static TapAccessibilityService.FastOfferSnapshot pressureSnapshot;static TapAccessibilityService.FastOfferSnapshot acceptPressureSnapshotForBinding(){return pressureSnapshot;}static List<TapAccessibilityService.FastOfferSnapshot> boundSnapshots=new ArrayList<>();static void bindAcceptPressureSnapshot(TapAccessibilityService.FastOfferSnapshot f){boundSnapshots.add(f);}static boolean pressureActive;static String pressureGuard="";static boolean acceptPressureActive(long at){return pressureActive && (pendingAction==0 || pendingAction==at);}static String acceptLoadingRetryBlock(long at){return "";}static boolean canReadAcceptRecoveryProof(long owner){return true;}static String acceptPressureGuard(long at){return !retryGuard.isEmpty()?retryGuard:pressureGuard;}static volatile boolean monitoring=true;static List<String> controlModes=new ArrayList<>();static void onAcceptControlObserved(long at,String mode,long elapsed){controlModes.add(mode);}static String firstAcceptCardGuard(String t){return cardGuard;}static String cardGuard="";static boolean isMonitoring(){return monitoring;}static long pendingAction;static long pendingClaimSince(){return pendingAction;}static String pendingText="";static String pendingClaimText(long at){return pendingText;}static String retryGuard="";static String acceptRetryGuard(long at){return retryGuard;}static boolean hasBoundAcceptSuccess(){return false;}static boolean isManualInterventionPaused(){return false;}static void prepareAcceptPageBaseline(PageOutcomePolicy.Baseline b){}static long sentAt;static long acceptDispatchObservedAt(){return sentAt;}}
class Log {static void d(String a,String b){}}
class Handler {List<Runnable> pending=new ArrayList<>();void postAtFrontOfQueue(Runnable r){pending.add(0,r);}void postDelayed(Runnable r,long ms){pending.add(r);}void post(Runnable r){r.run();}}
 public class TapAccessibilityService {
 static int semanticRejectClicks;
 static PageGuard.Page recentPageHint(){return page;}
 static boolean largeOrderPopupRecentlyVisible(long maxAge){return false;}
 static final ThreadLocal<RejectReadProgress> REJECT_READ_PROGRESS=new ThreadLocal<>();
 static final ThreadLocal<AccessibilityNodeInfo> REJECT_READ_ROOT=new ThreadLocal<>();
 Handler main=new Handler();ThreadPoolExecutor rootReadAhead;Handler controlWatchWorker;volatile AcceptControlWatch activeControlWatch;
 static final AtomicReference<AcceptControlWatch> WATCH_CANDIDATE=new AtomicReference<>();
 static FutureTask<String> indexedRootPending;static TapAccessibilityService indexedRootPendingOwner;static boolean wakeWhenIndexedRootReady;static long indexedRootPendingGeneration,indexedRootPendingEpoch,indexedRootPendingAt;
 static final ThreadLocal<String> ROOT_READ_TRACE=ThreadLocal.withInitial(()->"COLD");
 static final Object INDEX_ROOT_LOCK=new Object();static AccessibilityNodeInfo indexedRootReceipt;static TapAccessibilityService indexedRootOwner;static long indexedRootAt,indexedRootGeneration,indexedRootEpoch,indexedRootQueueMs,indexedRootBinderMs;
 static final AtomicReference<PageRetryReceipt> PAGE_RETRY_RECEIPT=new AtomicReference<>();
 final BoundedReadBatch witnessReadBatch=new BoundedReadBatch(4),firstShotIndexBatch=new BoundedReadBatch(4),ownedResumeReadBatch=new BoundedReadBatch(4),outcomePageReadBatch=new BoundedReadBatch(4),outcomeDeadlineReads=new BoundedReadBatch(1),successDeadlineReads=new BoundedReadBatch(1);static String lastUiMutationTrace="test-event";static String foregroundPackage="com.deliverthat.driver";
 static final ThreadLocal<RejectedIndexObservation> REJECTED_SELF_INDEX=new ThreadLocal<>();
 static final ThreadLocal<String> ACCEPT_INDEX_FAILURE=ThreadLocal.withInitial(()->"NOT_READ");
 static final ThreadLocal<String> RETRY_WITNESS_FAILURE=ThreadLocal.withInitial(()->"NONE");
 static final ThreadLocal<String> RETRY_WITNESS_DETAIL=ThreadLocal.withInitial(()->"NONE");
 static final ThreadLocal<String> RETRY_TREE_FAILURE=ThreadLocal.withInitial(()->"NOT_USED");
 static final AtomicReference<IndexedWitness> LAST_INDEXED_WITNESS=new AtomicReference<>();
 static final ThreadLocal<String> OWNED_NODE_REFRESH_DETAIL=ThreadLocal.withInitial(() -> "NOT_READ");
 static final ThreadLocal<Boolean> OWNED_NODE_PROCESSING=ThreadLocal.withInitial(() -> false);
 static final AtomicReference<ResumeNodeReceipt> RESUME_NODES=new AtomicReference<>();
 static PageOutcomePolicy.SurfaceGate CURRENT_SURFACE_GATE=new PageOutcomePolicy.SurfaceGate();
 static final AtomicLong WINDOW_TRANSITION_EPOCH=new AtomicLong();
 static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>();static AtomicLong UI_GENERATION=new AtomicLong(1),PRESSURE_LAYOUT_EPOCH=new AtomicLong();
 static final Pattern LIVE_MONEY_RANGE=Pattern.compile("(?:\\$|USD)(\\d+(?:\\.\\d+)?)\\s*[-–—]\\s*\\$?(\\d+(?:\\.\\d+)?)");
 static final Pattern LIVE_MONEY=Pattern.compile("(?:\\$|USD)(\\d+(?:\\.\\d+)?)");static final Pattern LIVE_MILES=Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*mi\\b");
 static final Pattern LIVE_CA_ZIP=Pattern.compile("CA [0-9]{5}");
 static final Pattern LIVE_OFFER_TIME=Pattern.compile("(?:Tomorrow|Today) at \\d+:\\d+ [AP]M");
 static final ConcurrentHashMap<String,Long> FIRST_SEEN_AT=new ConcurrentHashMap<>();static final long FIRST_SEEN_ROLLOVER_MS=8000;
 static long firstSeenNumericKey,acceptAnchorNumericKey;static long firstSeenNumericAt,firstSeenNumericLastAt,acceptAnchorFirstAt,acceptAnchorLastAt;
 static String routedReject="";static void cacheDecisionEvidence(String t,long g){routedReject=t;}
 static class DecisionEvidence {String identity,text="";float amount,miles;long capturedAt;}
 static DecisionEvidence hotEvent;static DecisionEvidence recentEventBurstDecisionEvidence(long maxAgeMs){return hotEvent;}
 AccessibilityNodeInfo root;static int resolveCalls;static int rootReads,boundReads,dispatch,refresh;static Runnable pressureFinalHook;static int outcomeMutations;static boolean mutateIndex,witnessOpenAtDispatch,throwDispatch,finalRetryChurn,finalRetryNegative,finalRetryWindow;static List<String> queries=Collections.synchronizedList(new ArrayList<>());
 static CountDownLatch queryGate,queryEntered;static Set<String> gatedQueries=Set.of();static PageGuard.Page page=PageGuard.Page.UNKNOWN;static FastOfferSnapshot refreshResult;
 static QuickTopResult retryTree;static Runnable treeHook;static int treeReads;
 static QuickTopResult getQuickTopOfferSnapshotResult(long ms,int nodes){if(ms!=45||nodes!=96)throw new AssertionError("retry tree must stay bounded");treeReads++;if(treeHook!=null)treeHook.run();return retryTree;}
 static CountDownLatch rootGate,rootEntered;
 static final AtomicReference<AcceptPageObservation> LAST_ACCEPT_PAGE=new AtomicReference<>();
 AccessibilityNodeInfo getRootInActiveWindow(){rootReads++;if(rootEntered!=null)rootEntered.countDown();if(rootGate!=null)try{rootGate.await();}catch(InterruptedException e){Thread.currentThread().interrupt();throw new IllegalStateException(e);}return root;}
 static AccessibilityNodeInfo resolveIndexedAction(AccessibilityNodeInfo n,Rect r,boolean a){resolveCalls++;return n.parent==null?n:n.parent;}
 static boolean safeActionBounds(Rect r,Rect b,boolean a){return !b.isEmpty()&&b.right<=r.right&&(a?b.left>r.right/2:b.right<r.right/2);}
 static boolean nodeIsActionable(AccessibilityNodeInfo n){return n.actionable;}
 static int actionReadyReads;
 static boolean actionNodeReady(AccessibilityNodeInfo n){actionReadyReads++;for(int d=0;n!=null&&d<6;d++,n=n.parent)if(n.enabled&&n.actionable)return true;return false;}
 static void addUniquePiece(List<CardText.Piece> p,String text,Rect b){p.add(new CardText.Piece(text,b.left,b.top,b.bottom));}

 static boolean isPositiveClaimOutcome(String s){return false;}static String recentCachedClaimOutcomeSince(long n){return "";}static PageGuard.Page quickPageOf(AccessibilityNodeInfo r,int n){return page;}
 static FastOfferSnapshot quickRefreshTopAction(TapAccessibilityService s,float a,float m,boolean v){return refreshResult;}
 static FastOfferSnapshot getIndexedNumericTopAcceptSnapshot(float a,float m){refresh++;return refreshResult;}
 static boolean isDeliverThatForeground(){return true;}
 static void dispatchActionGesture(TapAccessibilityService s,Rect b,boolean a,long ms,int variant,Consumer<String> ok,Consumer<String> fail){dispatch++;ok.accept("sent");}
 static boolean dispatchVerifiedSnapshotGesture(TapAccessibilityService s,Rect b,Rect r,boolean a,long ms,int v,boolean bindForPressure,Consumer<String> ok,Consumer<String> fail,BooleanSupplier fresh){if(!bindForPressure)throw new AssertionError("first tap must bind the verified CTA");int before=dispatch;dispatchVerifiedSnapshotGesture(s,b,r,a,ms,v,ok,fail,fresh);return dispatch!=before;}
 static void dispatchVerifiedSnapshotGesture(TapAccessibilityService s,Rect b,Rect r,boolean a,long ms,int variant,Consumer<String> ok,Consumer<String> fail,BooleanSupplier fresh){if(pressureFinalHook!=null){Runnable hook=pressureFinalHook;pressureFinalHook=null;hook.run();}if(finalRetryChurn)UI_GENERATION.incrementAndGet();if(finalRetryWindow)WINDOW_TRANSITION_EPOCH.incrementAndGet();if(finalRetryNegative)OcrMonitorService.retryGuard="RETRY_NEGATIVE_PENDING";if(!fresh.getAsBoolean()){fail.accept("RETRY_PROOF_EXPIRED");return;}dispatchVerifiedSnapshotGesture(s,b,r,a,ms,variant,ok,fail);}
 static void dispatchVerifiedSnapshotGesture(TapAccessibilityService s,Rect b,Rect r,boolean a,long ms,int variant,Consumer<String> ok,Consumer<String> fail){witnessOpenAtDispatch=hasFreshIndexedWitness();if(throwDispatch)throw new IllegalStateException("dispatch test");dispatch++;OcrMonitorService.sentAt=SystemClock.now;ok.accept("sent");}
'''
methods=['    private static AccessibilityNodeInfo resolveIndexedRejectAction(', '    private static AccessibilityNodeInfo resolveIndexedRejectParent(', '    private static boolean attachRejectProof(', '    private static boolean boundRejectContextCurrent(', '    private static FastOfferSnapshot boundIndexedReject(', '    private static void dispatchBoundReject(', '    private static FastOfferSnapshot currentPressureRenewalSnapshot(', '    private static String ownedResumeReceiptState(', '    private static final class AcceptPageObservation {','    private static void renewPressureRetry(', '    private static void tapPressureRetryPrepared(', '    private static boolean samePressureGeometry(', '    private static FastOfferSnapshot refreshCurrentOwnedAcceptNodes(String expected,long owner,boolean pressureRenewal)', '    private static boolean ownedResumeReceiptCurrent(', '    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryPairOnBatch(', '    public static String ownedAcceptNodeRefreshDetail()', '    public static boolean ownedAcceptNodeProcessingObserved()', '    private static final class ResumeNodeReceipt {', '    private static void clearAcceptResumeNodes()', '    private static void rememberAcceptResumeNodes(', '    public static FastOfferSnapshot refreshCurrentOwnedAcceptNodes(', '    private static final class IndexedSeedValue {', '    private static void collectCapturedIndexedEndpointPieces(', '    private static boolean hasAsciiDigit(', '    private static void appendIndexedEndpointPiece(', '    private static String pressureStopReason(', '    public static FastOfferSnapshot observeCurrentOwnedAcceptSnapshot(', '    public static void tapPressureRetry(', '    public static boolean isCurrentPressureResumeSnapshot(', '    static String pressureResumeProofBlock(', '    private static final class RejectedIndexObservation', '    public static FastOfferSnapshot takeRejectedSelfIndexObservation()', '    private static AccessibilityNodeInfo rootForRejectRead(', '    private static long rejectReadDeadline(', '    private static FastOfferSnapshot failRejectRead(', '    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryGroupWithBudget(', '    private String rebindAcceptControl(', '    private static java.util.concurrent.FutureTask<String> prefetchIndexedRoot(', '    private static final class AcceptControlWatch implements AutoCloseable {', '    private static void rememberAcceptControl(', '    public static void startAcceptControlWatch(', '    private void pollAcceptControl(', '    private static AccessibilityNodeInfo recentIndexedRoot(', '    private static AccessibilityNodeInfo readCurrentIndexedRoot(', '    private static AccessibilityNodeInfo readCurrentIndexedRoot(\n', '    private static void clearIndexedRootReceipt(', '    private static BoundedReadBatch.Pending<IndexedQueryResult> readIndexedActionAndNumbers(', '    private static final class PageRetryReceipt {', '    private static void clearPageRetryReceipt(', '    private static boolean freshPageRetrySnapshot(', '    public static FastOfferSnapshot takeAcceptPageRetrySnapshot(', '    public static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(\n            boolean requireLocation, boolean requireOfferTime, long softBudgetMs,', '    public static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(\n            boolean requireLocation, boolean requireOfferTime, long softBudgetMs,\n            java.util.function.BiPredicate<Float, Float> numericReject, StringBuilder phases)', '    private static final class IndexedQueryResult ', '    private static final class IndexedQueryRead ', '    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryPair(', '    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryPairWithBudget(', '    private static void collectIndexedNumericNodes(', '    private static boolean noHigherIndexedOfferAction(', '    private static void collectIndexedRejectBoundary(', '    private static void collectIndexedConfiguredCityPieces(', '    private static FastOfferSnapshot getIndexedNumericTopActionSnapshot(float expectedAmount,\n                                                                         float expectedMiles,\n                                                                         boolean accept,\n                                                                         boolean requirePasadena,\n', '    public static final class QuickTopResult {', '    private static FastOfferSnapshot readRetryQuickTreeSnapshot(', '    private static boolean canReuseRetryIndex(', '    private static String witnessReadFailure(', '    private static FastOfferSnapshot failAcceptIndex(', '    private static String acceptIndexFailure(', '    private static String retryWitnessFailure(', '    private static boolean hardRetryWitnessFailure(', '    private static FastOfferSnapshot refreshRetryWitnessSnapshot(', '    private static void dispatchRetryFromCurrentProof(', '    private static void collectIndexedOfferTimePieces(AccessibilityNodeInfo root,',
'    private static void collectIndexedOfferTimePieces(AccessibilityNodeInfo root,\n            Rect actionBounds,List<CardText.Piece> pieces,IndexedWitness witness)',
'    private static void collectIndexedLocationPieces(AccessibilityNodeInfo root, Rect actionBounds,',
'    private static void collectIndexedLocationPieces(AccessibilityNodeInfo root,Rect actionBounds,',
'    public static boolean currentNegativeSurfaceBlocksAccept()', '    static boolean hasCurrentNegativeBaseline(', '    public static void tapSnapshotRetryDetailed(', '    private static String pageNegativeHint(', '    public static PageOutcomePolicy.Reading sampleAcceptPageOutcome(','    private static PageOutcomePolicy.Reading readAcceptPageOutcome(', '    private static boolean pageHasSeparateNumericRows(', '    private static boolean matchesAccept(', '    private static String lettersOnlyLower(', '    private static boolean isAcceptLabel(', '    private static final class WitnessNodeValue {', '    private static final class WitnessNodeRead implements BoundedReadBatch.Read<WitnessNodeValue> {', '    private static boolean hasFreshIndexedWitness()', '    private static final class IndexedWitness {','    private static final class IndexedReadProof {','    public static final class FastOfferSnapshot {','    private static void recordNumericFirstSeen(DecisionEvidence candidate)',
'    private static void recordNumericFirstSeen(String identity,','    private static void noteAcceptAnchor(float amount,',
'    private static void collectIndexedEndpointPieces(', '    private static void collectIndexedEndpointPieces(List<AccessibilityNodeInfo> indexed,\n            Rect actionBounds,List<CardText.Piece> pieces,IndexedWitness witness,int windowId,java.util.Set<String> seen)', '    private static void collectIndexedOfferNumbers(', '    private static void collectIndexedOfferNumbers(AccessibilityNodeInfo root, Rect actionBounds,\n            List<CardText.Piece> pieces, IndexedWitness witness)',
'    private static void collectIndexedNumericPieces(AccessibilityNodeInfo root, String[] queries,\n                                                     Rect actionBounds,',
'    private static void collectIndexedNumericPieces(AccessibilityNodeInfo root, String[] queries,\n            Rect actionBounds, List<CardText.Piece> pieces, IndexedWitness witness)', '    private static boolean quickNumericPairMatches(',
'    public static FastOfferSnapshot observeCurrentTopAcceptSnapshot()', '    private static FastOfferSnapshot readIndexedCurrentTopAcceptSnapshot(', '    public static FastOfferSnapshot getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(', '    public static void tapSnapshotFastDetailed(']
# Only replace android Log in the harness, not production sources.
body='\n'.join(block(m) for m in methods).replace('android.util.Log.d','Log.d')
test=r'''
 static int checks;static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 static void drainPressure(){for(int n=0;n<20;n++){
  if(!OcrMonitorService.proof.pending.isEmpty())OcrMonitorService.proof.pending.remove(0).run();
  if(!OcrMonitorService.clicks.pending.isEmpty())OcrMonitorService.clicks.pending.remove(0).run();
  if(OcrMonitorService.proof.pending.isEmpty()&&OcrMonitorService.clicks.pending.isEmpty())return;
 }throw new AssertionError("renewal loop did not quiesce");}
 static Rect button=new Rect(689,1094,840,1151);static String last;
 static TapAccessibilityService setup(){OcrMonitorService.proof=new Handler();OcrMonitorService.clicks=new Handler();pressureFinalHook=null;clearAcceptResumeNodes();rootGate=rootEntered=null;clearIndexedRootReceipt();TapAccessibilityService old=INSTANCE.get();if(old!=null){old.firstShotIndexBatch.close();old.witnessReadBatch.close();old.ownedResumeReadBatch.close();old.outcomePageReadBatch.close();old.outcomeDeadlineReads.close();old.successDeadlineReads.close();if(old.rootReadAhead!=null)old.rootReadAhead.shutdownNow();}IndexedWitness prior=LAST_INDEXED_WITNESS.getAndSet(null);if(prior!=null)prior.close();TapAccessibilityService s=new TapAccessibilityService();s.firstShotIndexBatch.warmUp();s.witnessReadBatch.warmUp();s.ownedResumeReadBatch.warmUp();s.outcomePageReadBatch.warmUp();CURRENT_SURFACE_GATE=new PageOutcomePolicy.SurfaceGate();INSTANCE.set(s);OcrMonitorService.rejectNumbers=false;routedReject="";OcrMonitorService.monitoring=true;WINDOW_TRANSITION_EPOCH.set(0);queries=Collections.synchronizedList(new ArrayList<>());s.root=new AccessibilityNodeInfo("",new Rect(0,0,1080,2400));
 s.root.kids.add(new AccessibilityNodeInfo("Accept",button));s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));
 s.root.kids.add(new AccessibilityNodeInfo("0.2 mi",new Rect(410,850,580,900)));s.root.kids.add(new AccessibilityNodeInfo("Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA",new Rect(80,940,900,1000)));
 AcceptControlWatch priorControl=WATCH_CANDIDATE.getAndSet(null);if(priorControl!=null)priorControl.close();OcrMonitorService.controlModes.clear();queryGate=queryEntered=null;gatedQueries=Set.of();rootReads=boundReads=dispatch=refresh=resolveCalls=0;treeReads=0;retryTree=null;treeHook=null;witnessOpenAtDispatch=throwDispatch=finalRetryChurn=finalRetryNegative=finalRetryWindow=false;OcrMonitorService.retryGuard="";OcrMonitorService.cardGuard="";hotEvent=null;mutateIndex=false;outcomeMutations=0;page=PageGuard.Page.UNKNOWN;SystemClock.now=1000;UI_GENERATION.set(1);PRESSURE_LAYOUT_EPOCH.set(0);FIRST_SEEN_AT.clear();firstSeenNumericAt=firstSeenNumericLastAt=acceptAnchorFirstAt=acceptAnchorLastAt=0;firstSeenNumericKey=acceptAnchorNumericKey=0;OcrMonitorService.indexedRootWakes=0;refreshResult=null;PAGE_RETRY_RECEIPT.set(null);OcrMonitorService.boundSnapshots.clear();OcrMonitorService.pressureSnapshot=null;OcrMonitorService.pendingAction=0;OcrMonitorService.pendingText="";OcrMonitorService.sentAt=0;foregroundPackage="com.deliverthat.driver";return s;}
 static FastOfferSnapshot read(){return getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,false);}
 static void tap(FastOfferSnapshot s){tapSnapshotFastDetailed(s,s.amount,s.miles,m->last=m,m->last=m);}
 static final String OWNED="$110.02 2.6 mi Today at 11:05 AM Mendocino Farms • 840 S Sepulveda Blvd, El Segundo, CA 90245";
 static void traceCard(TapAccessibilityService s,String text,int offset,boolean accept,boolean enabled) {
  s.root.kids.add(new AccessibilityNodeInfo(text,new Rect(80,700+offset,950,1050+offset)));
  s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(248,1159+offset,386,1227+offset)));
  if(accept){AccessibilityNodeInfo n=new AccessibilityNodeInfo("Accept",new Rect(689,1162+offset,840,1219+offset));n.enabled=enabled;s.root.kids.add(n);}
 }
 static TapAccessibilityService traceRows(int kind) {
  TapAccessibilityService s=setup();s.root.kids.clear();
  traceCard(s,"$19–29 4.8 mi Today at 10:50 AM Urbane Cafe • 4001 N Lakewood Blvd Suite 100, Long Beach, CA 90846",0,true,true);
  if(kind!=3) traceCard(s,OWNED,736,kind!=2,kind!=1);
  OcrMonitorService.pendingAction=900;OcrMonitorService.sentAt=900;OcrMonitorService.pendingText=OWNED;
  return s;
 }
 public static void main(String[] args) throws Exception {
 TapAccessibilityService s=setup();FastOfferSnapshot f;
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 10:55 AM",new Rect(80,910,900,935)));
 s.root.kids.get(1).text="Est. $26–36 0.2 mi Tomorrow at 10:55 AM";
 f=getIndexedCurrentTopRejectSnapshot(true,false,60L,(pay,mi)->pay<50);
 check(f!=null && f.amount==26f && f.miles==0.2f,"current range lower bound and enabled Reject proven");
 check(queries.equals(List.of("e")),"one semantic query reuses complete numeric/time fields and skips city: "+queries);
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("Tomorrow at 10:55 AM",new Rect(80,910,900,935)));
 mutateIndex=true;check(getIndexedCurrentTopRejectSnapshot(true,false,60L,(pay,mi)->true)==null,"UI mutation invalidates current Reject proof");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));s.root.kids.get(4).enabled=false;
 check(getIndexedCurrentTopRejectSnapshot(true,false,60L,(pay,mi)->true)==null,"disabled Reject cannot dispatch");
 s=setup();


 s=setup();s.root.kids.clear();
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("$29–39 4.1 mi",new Rect(80,850,500,900)));
 f=getIndexedCurrentTopRejectSnapshot(true,true,60L,(pay,mi)->pay<50);
 check(f!=null && f.amount==29f && queries.stream().noneMatch(q->q.equals("Today")||q.equals("Tomorrow")||q.equals("•")),"numeric-only must-reject avoids time/city queries");
 s=setup();s.root.kids.clear();
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(116,1094,519,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("$69 4.1 mi",new Rect(80,850,500,900)));
 check(getIndexedCurrentTopRejectSnapshot(true,true,60L,(pay,mi)->false)==null,"possible special-city qualifier still needs complete decision identity");
 s=setup();
 for(Set<String> pair:List.of(Set.of("a","e"),Set.of("$","mi"),Set.of("a","e","$","mi"))) {
  setup();gatedQueries=pair;queryGate=new CountDownLatch(1);queryEntered=new CountDownLatch(pair.size());
  AtomicReference<FastOfferSnapshot> indexed=new AtomicReference<>();
  Thread queryReader=new Thread(()->indexed.set(read()));queryReader.start();
  try {
   boolean concurrent=queryEntered.await(2,TimeUnit.SECONDS);
   queryGate.countDown();queryReader.join(2000);
   check(concurrent && indexed.get()!=null,"independent index pair starts both reads before either returns "+pair);
   tap(indexed.get());check(dispatch==1,"parallel index receipt still reaches verified first tap "+pair);
  } catch(InterruptedException e){Thread.currentThread().interrupt();throw new AssertionError(e);}
  finally {queryGate.countDown();}
 }
 s=setup();

 check(!noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),1964),"last-window check catches upper Accept above tree/visual target");
 s.root.kids.get(0).enabled=false;
 check(!noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),1964),"disabled upper button remains final boundary");
 s.root.kids.get(0).text="Ignore";s.root.kids.get(0).bounds=new Rect(248,1094,386,1151);
 check(!noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),1964),"upper Ignore blocks tree/visual/OCR final path too");
 check(noHigherIndexedOfferAction(s.root,new Rect(0,0,1080,2400),1094),"same-row left control does not block current right CTA");
 s=setup();
 s.root.kids.add(new AccessibilityNodeInfo("$121.97 Est. 0.2 mi",new Rect(80,850,580,900)));
 f=read();check(f!=null && f.amount==121.97f && f.miles==.2f
         && Collections.frequency(queries,"$")<=1 && Collections.frequency(queries,"mi")<=1,
         "action-sufficient numeric discovery may cancel speculative queries but never repeats them: "+queries);
 tap(f);check(dispatch==1,"action-sufficient numeric evidence reaches guarded dispatch");
 s=setup(); // Neither action query can return these separate numeric labels.
 f=read();check(f!=null && f.amount==121.97f && f.miles==.2f
         && Collections.frequency(queries,"$")==1 && Collections.frequency(queries,"mi")==1,
         "required concurrent numeric discovery runs each query exactly once: "+queries);
 tap(f);check(dispatch==1,"reused live numeric fields reach guarded dispatch");
 s=setup();

 s.root.kids.clear();s.root.kids.add(new AccessibilityNodeInfo("Accept",button));
 s.root.kids.add(new AccessibilityNodeInfo("$28–38 3.4 mi Tomorrow at 6:00 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040",new Rect(80,850,900,1000)));
 f=getIndexedNumericTopActionSnapshot(28,3.4f,true,true,null,true);
 check(f!=null&&queries.equals(Arrays.asList("a","e")),"exact Pasadena reuses complete current action query without numeric/city/time IPC");
 check(f.pageOutcomeBaseline()!=null&&f.indexedRead.witness!=null,"exact path retains outcome baseline and current node witness");
 tap(f);check(dispatch==1,"exact receipt reaches guarded first dispatch");
 s=setup();s.root.kids.clear();s.root.kids.add(new AccessibilityNodeInfo("Accept",button));
 s.root.kids.add(new AccessibilityNodeInfo("$28–38 3.4 mi Tomorrow at 6:00 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040",new Rect(80,850,900,1000)));
 f=getIndexedNumericTopActionSnapshot(28,3.4f,true,true,null,true);UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&!last.contains("LIVE_NODE_RECHECK"),"speed-first exact branch dispatches cached CTA without extra IPC after generation churn");
 s=setup();s.root.kids.clear();s.root.kids.add(new AccessibilityNodeInfo("Accept",button));
 s.root.kids.add(new AccessibilityNodeInfo("$28–38 3.4 mi Tomorrow at 6:00 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040",new Rect(80,850,900,1000)));
 f=getIndexedNumericTopActionSnapshot(28,3.4f,true,true,null,true);
 s.root.kids.get(1).text=s.root.kids.get(1).text.replace("6:00 AM","7:00 AM");UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1,"speed-first intentionally accepts stale pickup risk rather than cancelling admitted first CTA");


 s=setup();s.root.kids.get(0).enabled=false;
 s.root.kids.add(new AccessibilityNodeInfo("Accept",new Rect(689,1964,840,2021)));
 f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);
 check(f==null,"disabled top Accept never skips to enabled lower CTA");
 s=setup();s.root.kids.get(0).text="";
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(248,1094,386,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("Accept",new Rect(689,1964,840,2021)));
 f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);
 check(f==null,"upper Ignore boundary blocks lower CTA borrowing original numbers");
 check(read()==null,"self index also retains upper Ignore boundary");
 s=setup();s.root.kids.get(0).text="";
 s.root.kids.add(new AccessibilityNodeInfo("Ignore",new Rect(248,1094,386,1151)));
 s.root.kids.add(new AccessibilityNodeInfo("Accept",new Rect(689,1964,840,2021)));
 s.root.kids.add(new AccessibilityNodeInfo("$90.00 3 mi Tomorrow at 8:00 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040",new Rect(80,1500,900,1800)));
 check(getIndexedNumericTopActionSnapshot(90,3,true,true,null,false)==null,"even a complete lower offer cannot skip readable upper offer");
 s.root.kids.remove(4);f=getIndexedNumericTopActionSnapshot(90,3,true,true,null,false);
 check(f!=null&&f.amount==90,"genuine next offer is actionable immediately after upper row disappears");
 s=setup();f=read();OcrMonitorService.cardGuard="ACCEPT_REJECT_OWNED";tap(f);
 check(dispatch==0&&last.contains("ACCEPT_REJECT_OWNED"),"final indexed dispatch rejects newly acquired Reject owner");
 s=setup();f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);
 check(f!=null&&queries.contains("$121.97")&&queries.contains("0.2 mi"),"separate numeric nodes still use exact current lookups");
 s=setup();s.root.kids.get(3).text="$121.97 0.2 mi Tomorrow at 6:00 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";
 f=getIndexedNumericTopActionSnapshot(80,.2f,true,false,null,false);check(f==null,"reused fields cannot change expected amount");
 s=setup();s.root.kids.get(3).text="$121.97 0.2 mi Tomorrow at 6:00 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";
 f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,true,null,true);check(f==null,"non-Pasadena current city still fails special branch");
 s=setup();s.root.pkg="other.app";f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);check(f==null,"exact branch rejects foreign root");
 s=setup();s.root.kids.get(0).enabled=false;f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);check(f==null,"exact branch rejects disabled Accept");
 s=setup();mutateIndex=true;f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);check(f==null,"exact branch rejects index churn");
 s=setup();s.root.kids.get(2).text="0.2 mi 9.9 mi";f=getIndexedNumericTopActionSnapshot(121.97f,.2f,true,false,null,false);check(f==null,"exact branch rejects multiple mileage rows");
 s=setup();f=read();check(f!=null&&f.amount==121.97f&&f.miles==.2f,"self-index assembles current exact pair and action");
 s=setup();f=read();final java.util.concurrent.atomic.AtomicInteger lazyFormats=new java.util.concurrent.atomic.AtomicInteger();
 f.indexedRead.deferredStages=()->{check(dispatch==1,"diagnostic formatting must follow gesture dispatch");lazyFormats.incrementAndGet();return "LAZY_DIAGNOSTIC";};
 tap(f);check(lazyFormats.get()==1&&last.contains("LAZY_DIAGNOSTIC"),"successful callback renders deferred diagnostic once");
 s=setup();f=read();final java.util.concurrent.atomic.AtomicInteger blockedFormats=new java.util.concurrent.atomic.AtomicInteger();
 f.indexedRead.deferredStages=()->{blockedFormats.incrementAndGet();return "MUST_NOT_FORMAT";};s.root.pkg="other.app";foregroundPackage="other.app";
 tap(f);check(dispatch==0&&blockedFormats.get()==0,"blocked first tap does not pay diagnostic formatting cost");
 s=setup();f=read();

 check(f.text.contains("Luna Grill")&&!queries.contains("•"),"current action index supplies endpoint without another query");
 check(firstSeenNumericAt<=f.capturedAt&&acceptAnchorFirstAt<=firstSeenNumericAt,"first-seen timestamps retain actual numeric/action read instants");
 tap(f);check(dispatch==1&&rootReads==1&&boundReads==1&&last.contains("LIVE_WINDOW_BOUNDS_REUSED"),"fresh window receipt removes second root call without rebuilding geometry");
 check(IndexedReadPolicy.reuseWindow(1,1,1000,1080,true,true),"receipt exact 80ms bound");
 check(!IndexedReadPolicy.reuseWindow(1,1,1000,1081,true,true),"expired receipt cannot skip root");
 check(!IndexedReadPolicy.reuseWindow(1,2,1000,1001,true,true),"window transition invalidates receipt");
 check(!IndexedReadPolicy.reuseWindow(1,1,1000,1001,false,true),"unknown foreground retains root read");
 check(!IndexedReadPolicy.reuseWindow(1,1,1000,1001,true,false),"missing node provenance retains root read");
 check(!IndexedReadPolicy.reuseWindow(1,1,1000,999,true,true),"clock reversal rejects receipt");
 check(last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"receipt fast path has explicit diagnostic");
 s=setup();f=read();WINDOW_TRANSITION_EPOCH.incrementAndGet();tap(f);
 check(rootReads==1,"speed-first keeps indexed root bounds despite window epoch churn");
 s=setup();f=read();finalRetryWindow=true;tap(f);check(dispatch==1,"speed-first does not veto first gesture on window epoch churn");
 s=setup();f=read();finalRetryChurn=true;tap(f);check(dispatch==1,"speed-first does not veto first gesture on generation churn");
 s=setup();f=read();tap(f);
 check(last.contains("INDEX_READ_BEGIN→dispatch")&&last.contains("INDEX_PHASE"),"whole index start-to-dispatch and phase accounting survives");
 s=setup();s.root.kids.get(3).desc=s.root.kids.get(3).text;s.root.kids.get(3).text="";f=read();check(f!=null&&!queries.contains("•")&&f.text.contains("Luna Grill"),"description-only endpoint reuses current action query");
 s=setup();s.root.kids.get(3).text="Shop • 10 Elm St, ZZ 11111";f=read();check(f!=null&&!queries.contains("•"),"eligible General skips optional endpoint Binder fallback");
 s=setup();s.root.kids.get(3).bounds=new Rect(80,1200,900,1300);f=read();check(f!=null&&!f.text.contains("Luna Grill"),"endpoint below current action cannot be reused");
 s=setup();s.root.kids.get(3).text="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA $150.00 9.9 mi";f=read();check(f==null||!f.text.contains("$150.00"),"multiple route rows cannot supply reused endpoint evidence");
 s=setup();f=read().withDecisionText(read().text+" Tomorrow at 10:15 AM");tap(f);check(dispatch==1&&last.contains("LIVE_WINDOW_BOUNDS_REUSED"),"descriptive enrichment keeps originating proof");
 s=setup();f=read();SystemClock.now+=81;tap(f);check(dispatch==1&&boundReads==1&&last.contains("LIVE_WINDOW_BOUNDS_REUSED"),"aged indexed receipt reuses CTA/root without second Binder read");
 s=setup();f=read();s.root.pkg="other.app";foregroundPackage="other.app";tap(f);check(dispatch==0,"real foreground switch blocks even within receipt TTL");
 s=setup();f=read();UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"generation churn dispatches without node rebind");
 s=setup();f=read();f.indexedRead.witness.close();UI_GENERATION.incrementAndGet();refreshResult=new FastOfferSnapshot(f.text,button,new Rect(),true,false,SystemClock.now,f.amount,f.miles,new IndexedReadProof(s.root.bounds,1,2,1000,SystemClock.now,"fresh"));tap(f);
 check(dispatch==1&&refresh==0,"closed witness still uses admitted CTA for first gesture");
 s=setup();f=read();s.root.windowId=2;WINDOW_TRANSITION_EPOCH.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"speed-first accepts changed window identity within same foreground app");
 s=setup();s.root.kids.get(0).enabled=false;f=observeCurrentTopAcceptSnapshot();
 check(f!=null&&!f.acceptEnabled,"observation-only retry index retains disabled action and current fields");
 s=setup();s.root.kids.get(0).enabled=false;check(read()==null,"disabled current top cannot borrow another enabled state");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("This delivery conflicts with an existing job at 11:05 AM",new Rect(10,50,900,90)));
 PageOutcomePolicy.Reading conflictPage=sampleAcceptPageOutcome(()->true);check(conflictPage.complete&&ClaimSuccessSignals.isTimeConflict(conflictPage.hint)&&conflictPage.hint.contains("11:05 AM"),"bounded live page preserves conflict cause and original excerpt");
 s=setup();mutateIndex=true;check(read()!=null,"mid-index RN generation churn no longer drops qualified current receipt");
 // v300: use an event's numeric pair only if the CURRENT enabled top action
 // independently supplies descriptive overlap; no numeric Binder wait is needed.
 s=setup();s.root.kids.remove(2);s.root.kids.remove(1);
 hotEvent=new DecisionEvidence();hotEvent.amount=121.97f;hotEvent.miles=.2f;
 hotEvent.text="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";hotEvent.identity="luna";
 hotEvent.capturedAt=SystemClock.now;
 f=read();check(f!=null && f.amount==121.97f && f.miles==.2f
   && f.indexedRead.deferredStages.get().contains("EVENT_BRIDGE_NO_NUMERIC_WAIT"),
   "recent matching event and current descriptive CTA skip numeric Binder waiting");
 tap(f);check(dispatch==1,"event bridge reaches actual first Accept gesture");
 s=setup();s.root.kids.clear();s.root.kids.add(new AccessibilityNodeInfo("Accept",button));
 hotEvent=new DecisionEvidence();hotEvent.amount=121.97f;hotEvent.miles=.2f;
 hotEvent.text="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";hotEvent.identity="luna";
 hotEvent.capturedAt=SystemClock.now;
 f=read();check(f!=null && f.amount==121.97f,
   "aggressive fresh numeric event may bridge a bare CURRENT Accept as requested");
 s=setup();s.root.kids.clear();s.root.kids.add(new AccessibilityNodeInfo("Accept",button));
 hotEvent=new DecisionEvidence();hotEvent.amount=121.97f;hotEvent.miles=.2f;
 hotEvent.text="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";hotEvent.identity="luna";
 hotEvent.capturedAt=SystemClock.now-150L;
 check(read()==null,"stale event cannot bridge a bare Accept even with aggressive setting");
 s=setup();hotEvent=new DecisionEvidence();hotEvent.amount=121.97f;hotEvent.miles=.2f;hotEvent.capturedAt=SystemClock.now;
 f=read();check(f!=null && new java.util.HashSet<>(queries).equals(java.util.Set.of("a","$","mi")),
  "fresh universally qualified event uses three parallel queries; no optional Reject boundary");
 s=setup();s.root.kids.get(1).text="$79.99";check(read()==null,"unqualified non-special General never passes numeric shortcut");
 s=setup();check(getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,false,false)==null,"city-filter mode cannot use General numeric shortcut");
 s=setup();check(getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(80,20,true,true,true)==null,"time-filter mode still requires current pickup time");
 check(!IndexedReadPolicy.reuseBounds(1,1,1000,999,true)&&!IndexedReadPolicy.reuseBounds(1,2,1000,1001,true),"clock inversion and generation mismatch reject reuse");
 s=setup();f=read();long seen=firstSeenNumericAt;recordNumericFirstSeen(f.identity,f.amount,f.miles,seen-2);
 check(firstSeenNumericAt==seen-2&&firstSeenNumericLastAt==seen,"out-of-order event parsing cannot move first-seen later");

 s=setup();f=read();int indexCalls=queries.size();s.root.kids.get(1).text="$110.00";UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0&&queries.size()==indexCalls,"admitted coordinates dispatch despite changed pay after index");
 s=setup();f=read();s.root.kids.get(2).text="9.9 mi";UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"admitted coordinates dispatch despite later mileage text change");
 s=setup();f=read();s.root.kids.get(3).text="Other Cafe • 20 Main St, Irvine, CA 92618, USA";UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"admitted coordinates dispatch without re-proving changed endpoint");
 s=setup();f=read();s.root.kids.get(0).bounds=new Rect(689,1600,840,1657);UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"old CTA coordinates are dispatched even after layout churn by user preference");
 s=setup();f=read();s.root.kids.get(1).gate=new CountDownLatch(1);UI_GENERATION.incrementAndGet();tap(f);s.root.kids.get(1).gate.countDown();check(dispatch==1&&refresh==0,"slow refreshed node is not read at all on first CTA dispatch");
 s=setup();f=read();s.root.kids.get(1).refreshOK=false;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"detached RN nodes do not delay admitted first CTA");
 s=setup();f=read();IndexedWitness w=f.indexedRead.witness;check(w!=null&&s.main.pending.size()==1,"owned nodes have a bounded cleanup callback");
 s.main.pending.get(0).run();check(w.closed&&w.fields.isEmpty()&&w.action==null,"expiry recycles all retained node handles");w.close();check(w.fields.isEmpty(),"cleanup is idempotent");
 s=setup();f=read();w=f.indexedRead.witness;read();check(w.closed,"a newer index closes the superseded witness");
 check(!IndexedWitnessPolicy.sameIdentity("$121.97 0.2 mi","$121.97 0.2 mi"),"numbers alone cannot authorize a witness rebind");
 check(!IndexedWitnessPolicy.sameIdentity("$121.97 0.2 mi Tomorrow at 10:15 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618", "$121.97 0.2 mi Tomorrow at 11:15 AM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618"),"known pickup conflict blocks witness identity");

 s=setup();s.root.kids.get(2).text="0.2mi";f=read();check(f!=null&&f.miles==.2f&&(queries.size()==4 && new java.util.HashSet<>(queries).equals(java.util.Set.of("a","e","$","mi"))),"compact mileage uses one broad query with unchanged exact numeric proof");
 s=setup();f=read();check(queries.size()==4 && new java.util.HashSet<>(queries).equals(java.util.Set.of("a","e","$","mi")),"shared c action lookup finds both captions in one complete query");
 s.root.kids.get(1).mutateOnRefresh=true;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"source mutation after index does not cancel first CTA");
 s=setup();f=read();s.root.kids.get(1).visible=false;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0,"stale live witness visibility does not cancel indexed CTA");
 IndexedWitness cap=new IndexedWitness();for(int i=0;i<9;i++)cap.field(new AccessibilityNodeInfo("$1",new Rect(0,0,100,20)));
 check(cap.overflow&&cap.fields.size()==8,"node ownership is strictly bounded");cap.close();
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("$121.97 0.2 mi luna grill • 524 spectrum center dr, irvine, ca 92618, usa",new Rect(80,850,900,1000)));
 f=read();check(f!=null,"case-varied merged parent retains current indexed offer");
 UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"lossless folded parent sends CTA without node refresh");
 check(IndexedWitnessPolicy.singleFoldedSource(List.of("$121.97", "0.2   mi", "LUNA GRILL • 524 Spectrum Center Dr, Irvine, CA 92618", "$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618"))==8,"folded merged source losslessly covers split labels");
 check(IndexedWitnessPolicy.singleFoldedSource(List.of("$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618", "Tomorrow at 10:15 AM"))==0,"missing known pickup field cannot be omitted");
 check(IndexedWitnessPolicy.singleFoldedSource(List.of("$121.97 0.2 mi $99 9 mi", "$121.97"))==0,"conflicting route cannot supply merged proof");
 String identity="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";
 check(!IndexedWitnessPolicy.sameIdentity(identity+" burq_3744670",identity+" burq_3744671"),"provider-id conflict blocks witness rebind");
 s=setup();f=read();s.root.kids.get(3).refreshCost=70;UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0,"a completed coherent proof is not discarded when its last Binder read overruns the soft slice");
 // v139: RN merged parent and duplicated numeric children require only one field refresh.
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));s.root.kids.add(new AccessibilityNodeInfo("$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA",new Rect(80,850,900,1000)));
 f=read();check(f!=null&&f.indexedRead.witness.fields.size()==2&&Collections.frequency(queries,"$")<=1&&Collections.frequency(queries,"mi")<=1,"coherent action-query parent avoids duplicate numeric processing/child handles after concurrent discovery: "+queries);
 check(hasFreshIndexedWitness(),"fresh published proof suppresses competing ancestor enrichment");
 s.root.kids.get(1).refreshCost=70;s.root.kids.get(2).refreshCost=70;s.root.kids.get(3).refreshCost=70;
 UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&refresh==0&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"merged parent CTA sends without duplicate child Binder reads");
 check(!hasFreshIndexedWitness(),"dispatch cleanup releases ancestor-enrichment suppression");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));s.root.kids.add(new AccessibilityNodeInfo("$121.97",new Rect(80,850,260,900)));s.root.kids.add(new AccessibilityNodeInfo("$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA",new Rect(80,850,900,1000)));
 f=read();s.root.kids.get(6).text="$121.97 0.2 mi Other Cafe • 10 Main St, Irvine, CA 92618";UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&refresh==0,"identity mutation no longer cancels admitted first CTA");
 s=setup();f=read();SystemClock.now+=301;check(!hasFreshIndexedWitness(),"expired proof never defers event enrichment");
 check(IndexedWitnessPolicy.minimumCover(identity,List.of("$121.97","0.2 mi","Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618"))==7,"split numeric and endpoint sources are all retained when necessary");
 String timed=identity+" Tomorrow at 10:15 AM burq_3744670";
 check(Integer.bitCount(IndexedWitnessPolicy.minimumCover(timed,List.of(identity,"Tomorrow at 10:15 AM","burq_3744670")))==3,"known pickup and provider ID cannot be dropped to save reads");
 check(IndexedWitnessPolicy.minimumCover(identity,List.of("$121.97 0.2 mi"))==0,"missing endpoint cannot authorize compact proof");
 check(IndexedWitnessPolicy.minimumCover(identity,List.of(identity+" $99.00 9.9 mi"))==0,"multi-card parent cannot authorize compact proof");
 check(last!=null,"completion detail survives");
 s=setup();f=read();UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&last.contains("LIVE_WINDOW_RECEIPT_REUSED")&&last.contains("PREFLIGHT root="),"split-field indexed CTA avoids final parallel rebind, retains phase trace");
 s=setup();f=read();s.root.kids.get(0).enabled=false;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1,"disabled after indexing does not invoke slow first gesture proof");
 s=setup();f=read();s.root.kids.get(0).stopOnRefresh=true;UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1,"no refresh side effect; admitted CTA dispatched before monitor stop hook");
 s=setup();f=read();AccessibilityNodeInfo timeId=new AccessibilityNodeInfo("Tomorrow at 10:15 AM burq_3744670",new Rect(80,1010,900,1050));
 f.indexedRead.witness.field(timeId);f=f.withDecisionText(f.text+" Tomorrow at 10:15 AM burq_3744670");UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"enriched CTA no longer needs slow sequential node proof");
 s=setup();f=read();s.root.kids.get(0).windowOnRefresh=true;UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1,"no refresh side effect; admitted CTA dispatched despite window churn");
 s=setup();queryGate=new CountDownLatch(1);queryEntered=new CountDownLatch(1);gatedQueries=Set.of("e");
 CountDownLatch earlyParsed=new CountDownLatch(1);s.root.kids.get(0).textRead=earlyParsed;
 FutureTask<FastOfferSnapshot> streamedRead=new FutureTask<>(()->read());
 Thread streamedReader=new Thread(streamedRead);streamedReader.start();
 try {
  check(queryEntered.await(1,TimeUnit.SECONDS),"second caption query is still outstanding");
  check(earlyParsed.await(1,TimeUnit.SECONDS) && !streamedRead.isDone(),"first caption parses while second is outstanding without publishing");
  queryGate.countDown();
  check(streamedRead.get(1,TimeUnit.SECONDS)!=null,"both caption results still complete the same top-row proof");
 }catch(Exception ex){throw new AssertionError(ex);}finally{queryGate.countDown();}
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Claim",new Rect(689,1040,840,1090)));f=read();
 check(f!=null&&f.acceptBounds.top==1040&&new java.util.HashSet<>(queries).containsAll(java.util.Set.of("a","e")),"shared action query still selects the higher Claim rather than lower Accept");
 s=setup();AccessibilityNodeInfo disabledClaim=new AccessibilityNodeInfo("Claim",new Rect(689,1040,840,1090));disabledClaim.enabled=false;s.root.kids.add(disabledClaim);
 s.root.kids.get(0).actionable=false;
 int readinessBefore=actionReadyReads;
 check(read()==null,"disabled higher Claim cannot borrow a lower enabled Accept");
 check(actionReadyReads-readinessBefore==1,"only the elected top Accept is checked for readiness");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Cancel",new Rect(689,1020,840,1070)));s.root.kids.add(new AccessibilityNodeInfo("Coffee Merchant",new Rect(689,1010,840,1060)));f=read();
 check(f!=null&&f.acceptBounds.top==1094,"shared-letter false positives never authorize or replace the actual action");
 for(String caption:List.of("ACCEPT","Claim","Accept Offer","Claim Delivery","Button Accept","Claim Request")){
  s=setup();s.root.kids.get(0).text=caption;f=read();check(f!=null,"shared index retains supported semantic caption "+caption);
 }
 s=setup();f=read();UI_GENERATION.incrementAndGet();tap(f);check(dispatch==1&&last.contains("ACTION_INDEX=SHARED_A_E")&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"shared index tracing survives speed-first direct CTA dispatch");
 check(IndexedWitnessPolicy.sourceCover(List.of("$121.97","0.2 mi","Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618"))==7,"split fields retain every source without semantic reparsing");
 int cover=IndexedWitnessPolicy.sourceCover(List.of("$121.97","0.2 mi",identity));check(Integer.bitCount(cover)==1,"complete parent text subsumes redundant child strings losslessly");
 cover=IndexedWitnessPolicy.sourceCover(List.of(identity,"Tomorrow at 10:15 AM","burq_3744670"));check(cover==7,"pickup and provider text are never dropped when not literally covered");
 cover=IndexedWitnessPolicy.sourceCover(List.of("$121.97","0.2 mi",identity+" $90.00 9.9 mi"));check(cover==7,"multi-offer parent cannot replace its card-local numeric children");
 check(IndexedWitnessPolicy.sourceCover(List.of("","$121.97"))==2,"empty source descriptions require no refresh");
 String[] atoms={"", "$121.97", "0.2 mi", identity, "Tomorrow at 10:15 AM", identity+" $90.00 9.9 mi"};
 java.util.Random random=new java.util.Random(157);
 for(int trial=0;trial<500;trial++){
  java.util.List<String> inputs=new java.util.ArrayList<>();for(int k=0;k<1+random.nextInt(8);k++)inputs.add(atoms[random.nextInt(atoms.length)]);
  int actual=IndexedWitnessPolicy.sourceCover(inputs);int minimum=99;
  for(int mask=1;mask<(1<<inputs.size());mask++){
   boolean covers=true;
   for(int j=0;j<inputs.size();j++)if(!inputs.get(j).trim().isEmpty()){
    boolean found=false;for(int i=0;i<inputs.size();i++)if((mask&(1<<i))!=0 && (i==j || (!CardText.containsMultipleMileageRows(inputs.get(i))&&inputs.get(i).contains(inputs.get(j)))))found=true;
    if(!found)covers=false;
   }
   if(covers)minimum=Math.min(minimum,Integer.bitCount(mask));
  }
  boolean allEmpty=inputs.stream().allMatch(String::isEmpty);if(allEmpty)minimum=0;
  check(Integer.bitCount(actual)==minimum,"maximal literal cover equals exhaustive reference");
 }
 s=setup();f=read();check(f.pageOutcomeBaseline()!=null&&!f.pageOutcomeBaseline().negative,"clean baseline travels with coherent snapshot");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("offer unavailable",new Rect(10,50,600,90)));f=read();check(f.pageOutcomeBaseline().negative,"visible existing prompt recorded before tap");
 s.root.kids.get(s.root.kids.size()-1).visible=false;f=read();check(!f.pageOutcomeBaseline().negative,"hidden old prompt cannot poison baseline");
 PageOutcomePolicy.Reading page=sampleAcceptPageOutcome(()->true);check(page!=null&&page.complete&&page.hint.isEmpty()&&page.context!=null,"production sampler ignores hidden prompt and reads coherent current card");
 s.root.kids.get(s.root.kids.size()-1).visible=true;page=sampleAcceptPageOutcome(()->true);check(page!=null&&page.hint.equals("offer unavailable"),"production sampler finds eventless current failure");
 s.root.kids.add(new AccessibilityNodeInfo("Begin Delivery",new Rect(10,80,600,100)));page=sampleAcceptPageOutcome(()->true);check(page!=null&&page.positive,"Begin Delivery veto survives prompt sampling");
 mutateIndex=true;check(sampleAcceptPageOutcome(()->true).complete,"one invalid sample is discarded and independent fresh-root restart can succeed");
 check(!sampleAcceptPageOutcome(()->false).complete,"superseded transaction cannot sample a page");
 s=setup();s.root.pkg="other.app";check(!sampleAcceptPageOutcome(()->true).complete,"foreign active window cannot supply outcome evidence");
 s=setup();String parentText="$121.97 0.2 mi Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618, USA";
 s.root.kids.add(new AccessibilityNodeInfo(parentText,new Rect(10,700,900,1060)));
 s.root.kids.add(new AccessibilityNodeInfo("offer unavailable",new Rect(10,50,600,90)));
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.context!=null&&CardText.amount(page.context)==121.97f,"parent and numeric children remain one spatially bound card");
 s.root.kids.add(new AccessibilityNodeInfo("$90.00 9.9 mi",new Rect(10,800,900,850)));
 page=sampleAcceptPageOutcome(()->true);check(page.context==null&&page.reason.equals("CONFLICTING_NUMBERS")&&page.evidenceDetail.contains("90.0")&&page.evidenceDetail.contains("121.97"),"distinct values at same coordinates still reject cross-card contamination");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("$90.00 9.9 mi",new Rect(10,1400,900,1450)));
 page=sampleAcceptPageOutcome(()->true);check(page.context!=null&&CardText.amount(page.context)==121.97f,"lower offer below top action cannot contaminate original top outcome context");
 s=setup();s.root.kids.remove(0);s.root.kids.add(new AccessibilityNodeInfo("0.2 mi",new Rect(10,1400,300,1450)));
 page=sampleAcceptPageOutcome(()->true);check(page.context==null&&page.reason.equals("AMBIGUOUS_ROWS"),"two separated equal mileage rows without action cannot masquerade as parent-child duplicates");

 s=setup();s.root.kids.get(0).enabled=false;s.root.kids.add(new AccessibilityNodeInfo("Offer unavailable. Please contact support about this offer.",new Rect(20,40,900,90)));
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.actionState.equals("DISABLED")&&page.excerpt.contains("contact support"),"same live bounded probe preserves disabled node and original failure sentence");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Your jobs overlap with another route",new Rect(20,40,900,90)));
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.queries==7&&ClaimSuccessSignals.isTimeConflict(page.hint),"shared a query retains overlap classification while reducing one query");
 s=setup();s.root.kids.get(0).bounds=new Rect(725,1110,780,1130);AccessibilityNodeInfo buttonParent=new AccessibilityNodeInfo("",button);buttonParent.enabled=false;s.root.kids.get(0).parent=buttonParent;
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.actionState.equals("DISABLED"),"small enabled label resolves disabled semantic parent for processing observation");
 s=setup();s.root.kids.add(new AccessibilityNodeInfo("Offer Unavailable",new Rect(20,40,900,90)));s.root.kids.add(new AccessibilityNodeInfo("Offer Unavailable. Please contact support for more details.",new Rect(20,40,900,160)));
 page=sampleAcceptPageOutcome(()->true);check(page.complete&&page.excerpt.contains("contact support"),"full failure sentence is retained instead of shorter heading");
 s=setup();outcomeMutations=100;page=sampleAcceptPageOutcome(()->true);check(page.reason.equals("UI_CHANGED")&&page.queries==4&&page.nodes==0&&queries.size()==8&&rootReads==2,"continuous churn stops after exactly two independent reads without accepting mixed evidence");
 INSTANCE.get().firstShotIndexBatch.close();INSTANCE.get().witnessReadBatch.close();
 // Speed-first acceptance: indexed CTA dispatches even after generation, window and time churn.
 s=setup();f=read();UI_GENERATION.incrementAndGet();int before=queries.size();tap(f);
 check(dispatch==1&&queries.size()==before&&last.contains("LIVE_WINDOW_RECEIPT_REUSED"),"generation change never induces a new pre-tap index");
 s=setup();f=read();WINDOW_TRANSITION_EPOCH.incrementAndGet();before=rootReads;tap(f);
 check(dispatch==1&&rootReads==before,"window epoch change does not require new root Binder read");
 s=setup();f=read();SystemClock.advance(451);before=rootReads;tap(f);
 check(dispatch==1&&rootReads==before,"admitted 451ms-old indexed CTA still sends first gesture");
 s=setup();f=read();s.root.kids.get(3).text="Other Cafe • 20 Main St, Irvine, CA 92618, USA";UI_GENERATION.incrementAndGet();tap(f);
 check(dispatch==1,"user-authorized stale endpoint risk does not silently cancel first click");
 s=setup();f=read();s.root.pkg="other.app";foregroundPackage="other.app";tap(f);
 check(dispatch==0,"other app is never tapped even in speed-first mode");
 s=setup();f=read();OcrMonitorService.monitoring=false;tap(f);
 check(dispatch==0,"stopped monitor cannot dispatch");
 s=setup();f=read();OcrMonitorService.cardGuard="ACCEPT_REJECT_OWNED";tap(f);
 check(dispatch==0,"in-flight Reject ownership is still protected");
 s=setup();f=read();finalRetryChurn=true;tap(f);
 check(dispatch==1,"generation churn immediately before Android dispatch does not cancel gesture");
 s=setup();f=read();finalRetryWindow=true;tap(f);
 check(dispatch==1,"window churn immediately before Android dispatch does not cancel gesture");
 // Pressure same-owner retry also skips a deep refresh when original indexed CTA is available.
 s=setup();f=observeCurrentTopAcceptSnapshot();OcrMonitorService.pendingAction=1000;OcrMonitorService.pendingText=f.text;
 tapSnapshotRetryDetailed(f,f.amount,f.miles,2,d->last=d,d->last=d);
 check(dispatch==1,"indexed same-owner retry sends directly without slow tree");
 System.out.println(checks+" current speed-first index, Reject selection and gesture tests passed");
 }}'''
with tempfile.TemporaryDirectory(prefix='csa-index-') as d:
 h=Path(d)/'TapAccessibilityService.java'
 reason=next(line for line in source.splitlines() if 'static final String REJECT_PROOF_CHANGED_BEFORE_CLICK' in line)
 h.write_text(header+reason+'\n'+body+test)
 names=['ActionRowPolicy.java','ButtonLabels.java','PageOutcomePolicy.java','CardText.java','ClaimSuccessSignals.java','PageGuard.java','OfferEnrichmentPolicy.java','PasadenaRuleGuard.java','IndexedReadPolicy.java','FastSnapshotPolicy.java','ActionDispatchPolicy.java','VisualGenerationReboundPolicy.java','IndexedWitnessPolicy.java','RejectDemandPolicy.java','BoundedReadBatch.java','RejectReadProgress.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in names],str(h)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.TapAccessibilityService'],check=True)
