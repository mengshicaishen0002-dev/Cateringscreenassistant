from pathlib import Path
import tempfile,subprocess
p=Path(__file__).resolve().parents[1];src=p/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text();a=s.index('    private void tryVisualRetry(');b=s.index('    private static final class VisualAcceptDetection',a);method=s[a:b]
header='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;
class VisualFrameHarness {void releaseAcceptAdmission(){acceptAdmissionBusy.set(false);}
 static class SystemClock{static long now=1900;static long elapsedRealtime(){return now;}}
 static class Rect{int left,top,right,bottom;Rect(){}Rect(int l,int t,int r,int b){left=l;top=t;right=r;bottom=b;}Rect(Rect b){this(b.left,b.top,b.right,b.bottom);}boolean isEmpty(){return right<=left||bottom<=top;}void offset(int x,int y){left+=x;right+=x;top+=y;bottom+=y;}}
 static String CARD="$88.40 0.4 mi (~4 mins) Today at 5:00 PM Mendocino Farms • 4531 Hollywood Blvd, Los Angeles, CA 90027";
 static class Text {String card=CARD,page=CARD+" Accept";Element e=new Element();String getText(){return page;}List<TextBlock> getTextBlocks(){return Arrays.asList(new TextBlock(e));}
 static class TextBlock{Element e;TextBlock(Element e){this.e=e;}List<Line> getLines(){return Arrays.asList(new Line(e));}}
 static class Line{Element e;Line(Element e){this.e=e;}List<Element> getElements(){return Arrays.asList(e);}}
 static class Element{String text="Accept";Rect box=new Rect(689,1173,840,1230);Rect getBoundingBox(){return box;}String getText(){return text;}}
 }
 static class TapAccessibilityService {static long generation=1;static long currentUiGeneration(){return generation;}static class FastOfferSnapshot{String text;FastOfferSnapshot(String t,Rect a,Rect b,boolean e,boolean f,long at){text=t;}}}
 enum SerialAction{ACCEPT,NONE}SerialAction serialTopAction=SerialAction.ACCEPT;long serialTopActionAt=1000,acceptGestureCompletedAt=1000,acceptRetryDispatchPendingAt;
 boolean monitorReady=true,visualRetryNeeded=true;AtomicLong claimEpoch=new AtomicLong(1);AtomicBoolean acceptAdmissionBusy=new AtomicBoolean();
 VisualRetryPolicy.Proof visualRetryProof=new VisualRetryPolicy.Proof();String serialTopText=CARD;int width=1080,height=2400,dispatches,lastAttempt;ClaimBudget claimBudget=new ClaimBudget();static String guard="";
 int visualRetryDiagnosticMask;List<String> diagnostics=new ArrayList<>();java.util.function.Consumer<String> offerReporter(String t){return diagnostics::add;}
 int topCropTop(){return 0;}String textNearButton(Text t,Rect b){return t.card;}String fastRuleFailure(String t){return "";}static String acceptRetryGuard(long at){return guard;}
 boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot f,long epoch,long frame,long gen){dispatches++;lastAttempt=claimBudget.reserve(CardText.identity(f.text),f.text,SystemClock.now);return lastAttempt>0;}
 static int checks;static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
 static Rect visual=new Rect(563,1145,965,1259);
 static VisualFrameHarness setup(){SystemClock.now=1900;TapAccessibilityService.generation=1;guard="";VisualFrameHarness h=new VisualFrameHarness();h.claimBudget.reserve(CardText.identity(CARD),CARD,1000);return h;}
 String acceptRetryDecisionText(String text){return text;}
 void first(){tryVisualRetry(new Text(),visual,1800,1,1,1000);}
 void second(Text t){SystemClock.now=2140;tryVisualRetry(t,visual,2040,1,1,1000);}
'''
tests='''public static void main(String[] args){
 VisualFrameHarness h=setup();h.first();check(h.dispatches==0,"single frame cannot dispatch");check(h.diagnostics.size()==1,"waiting-second-frame diagnostic recorded");h.noteVisualRetrySkip(8,"same reason");check(h.diagnostics.size()==1,"same reason does not flood logs");h.second(new Text());check(h.dispatches==1&&h.lastAttempt==2,"second current frame retries as attempt2 in existing budget");check(h.serialTopActionAt==1000&&h.claimEpoch.get()==1,"visual retry never starts another transaction");
 for(int k=0;k<9;k++){h=setup();h.first();Text t=new Text();switch(k){case 0:t.e.text="Accepting";break;case 1:t.e.box=new Rect(100,1173,250,1230);break;case 2:t.page+=" This offer is no longer available.";break;case 3:t.card=CARD.replace("5:00","6:00");break;case 4:guard="RETRY_NEGATIVE_PENDING";break;case 5:h.claimEpoch.incrementAndGet();break;case 6:TapAccessibilityService.generation=2;break;case 7:h.acceptRetryDispatchPendingAt=2100;break;case 8:h.visualRetryNeeded=false;break;}
 h.second(t);check(h.dispatches==0,"unsafe frame cannot retry "+k);check(h.claimBudget.reserve(CardText.identity(CARD),CARD,2200)==2,"unsafe frame does not consume a retry "+k);}
 h=setup();h.first();SystemClock.now=2600;h.tryVisualRetry(new Text(),visual,2040,1,1,1000);check(h.dispatches==0,"expired OCR cannot authorize retry");
 h=setup();h.claimBudget.reserve(CardText.identity(CARD),CARD,1100);h.claimBudget.reserve(CardText.identity(CARD),CARD,1200);h.first();h.second(new Text());check(h.dispatches==0,"visual fallback cannot reopen exhausted3-attempt budget");
 System.out.println(checks+" production OCR visual retry frame/ownership cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'VisualFrameHarness.java';f.write_text(header+method+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d]+[str(src/n) for n in ['CardText.java','OfferEnrichmentPolicy.java','ClaimSuccessSignals.java','ClaimBudget.java','ActionGeometry.java','ActionDispatchPolicy.java','VisualRetryPolicy.java']]+[str(f)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.VisualFrameHarness'],check=True)
