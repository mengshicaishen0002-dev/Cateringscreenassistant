from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'TapAccessibilityService.java').read_text()
def block(sig):
 a=s.index(sig);i=s.index('{',a)+1;end=i;d=1
 while d:d+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[a:end]
methods='\n'.join(block(x) for x in ['    private static FastOfferSnapshot getIndexedTopActionSnapshot(boolean accept,','    static FastOfferSnapshot getBoundedIndexedTopActionSnapshot(','    private static QuickTopResult readRejectRecheck(String expectedText,'])
head='''package com.local.cateringscreenassistant;
import java.util.concurrent.*;import java.util.concurrent.atomic.*;
class SystemClock{static long elapsedRealtime(){return System.nanoTime()/1000000;}}
public class TapAccessibilityService {
 static AtomicLong UI_GENERATION=new AtomicLong(1),WINDOW_TRANSITION_EPOCH=new AtomicLong(1);
 static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>();
 final BoundedReadBatch actionDeadlineReads=new BoundedReadBatch(1),rejectDeadlineReads=new BoundedReadBatch(1);
 static class AccessibilityNodeInfo {void recycle(){}}
 static final ThreadLocal<RejectReadProgress> REJECT_READ_PROGRESS=new ThreadLocal<>();
 static final ThreadLocal<AccessibilityNodeInfo> REJECT_READ_ROOT=new ThreadLocal<>();
 AtomicInteger rejectReadTurn=new AtomicInteger();
 static class FastOfferSnapshot{}
 static class QuickTopResult{FastOfferSnapshot snapshot;boolean budget,budgetExceeded,emptyOffers,emptyContradicted;int visited;String reason,limitReason;
 QuickTopResult(FastOfferSnapshot a,boolean b,int c,boolean d,String e){this(a,b,c,d,e,false);}
 QuickTopResult(FastOfferSnapshot a,boolean b,int c,boolean d,String e,boolean f){snapshot=a;budget=budgetExceeded=b;visited=c;emptyOffers=d;emptyContradicted=f;reason=limitReason=e;}}
 static volatile CountDownLatch gate;static volatile boolean change;
 static void slow(){try{if(gate!=null)gate.await();}catch(InterruptedException e){Thread.currentThread().interrupt();}if(change)UI_GENERATION.incrementAndGet();}
 static FastOfferSnapshot readIndexedTopActionSnapshot(boolean a,boolean b,boolean c){slow();return new FastOfferSnapshot();}
 static QuickTopResult readRejectRecheckWithinBudget(String t,java.util.function.BooleanSupplier may){RejectReadProgress p=REJECT_READ_PROGRESS.get();p.stage="TREE";p.visited=7;slow();return new QuickTopResult(null,false,1,false,"OK");}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
'''
tests='''public static void main(String[]args)throws Exception{
 TapAccessibilityService service=new TapAccessibilityService();INSTANCE.set(service);service.actionDeadlineReads.warmUp();service.rejectDeadlineReads.warmUp();
 check(getIndexedTopActionSnapshot(true,false,false)!=null,"normal read returns");
 gate=new CountDownLatch(1);long start=SystemClock.elapsedRealtime();check(getIndexedTopActionSnapshot(true,false,false)==null,"blocked Binder does not hold caller");check(SystemClock.elapsedRealtime()-start<250,"bounded wait");
 start=SystemClock.elapsedRealtime();check(getIndexedTopActionSnapshot(true,false,false)==null,"busy slot fails without another root job");check(SystemClock.elapsedRealtime()-start<100,"no busy queue wait");
 QuickTopResult timed=readRejectRecheck("old",()->true,false);
 check(timed.budget&&!timed.emptyOffers,"Reject deadline is incomplete, never disappearance");
 check(timed.visited==7 && timed.reason.contains("stage=TREE") && timed.reason.contains("visitedAtReturn=7"),"timeout keeps partial read progress instead of zeroing it");
 gate.countDown();gate=null;service.actionDeadlineReads.close();service.rejectDeadlineReads.close();
 service=new TapAccessibilityService();INSTANCE.set(service);change=true;check(getIndexedTopActionSnapshot(true,false,false)==null,"generation change invalidates completed read");
 change=false;check(readRejectRecheck("old",()->false,false).reason.equals("YIELD_PRIORITY"),"new offer avoids old read entirely");
 service.actionDeadlineReads.close();service.rejectDeadlineReads.close();System.out.println(checks+" production bounded root/index/Reject read cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'TapAccessibilityService.java';p.write_text(head+methods+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'BoundedReadBatch.java'),str(src/'RejectProbePolicy.java'),str(src/'RejectReadProgress.java'),str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.TapAccessibilityService'],check=True)
