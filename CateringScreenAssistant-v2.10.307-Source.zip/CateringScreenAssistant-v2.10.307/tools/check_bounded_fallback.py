"""Run production fallback/numeric deadline wrappers with real worker pools and blocked reads."""
from pathlib import Path
import tempfile,subprocess
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'TapAccessibilityService.java').read_text()
def block(sig):
 a=s.index(sig);b=s.index('{',a);i=b+1;d=1
 while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
head='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
class SystemClock {static long elapsedRealtime(){return System.nanoTime()/1000000L;}}
public class TapAccessibilityService {
 static final AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>();
 static final AtomicLong UI_GENERATION=new AtomicLong(1),WINDOW_TRANSITION_EPOCH=new AtomicLong(1);
 final BoundedReadBatch fallbackDeadlineReads=new BoundedReadBatch(1),numericDeadlineReads=new BoundedReadBatch(1);
 static final ThreadLocal<FallbackReadScope> FALLBACK_READ_SCOPE=new ThreadLocal<>();
 static final ThreadLocal<String> ROUTING_READ_TRACE=ThreadLocal.withInitial(()->"NONE");
 static final ThreadLocal<RejectReadProgress> REJECT_READ_PROGRESS=new ThreadLocal<>();
 static final ThreadLocal<AccessibilityNodeInfo> REJECT_READ_ROOT=new ThreadLocal<>();
 static class AccessibilityNodeInfo {static AtomicInteger recycled=new AtomicInteger();void recycle(){recycled.incrementAndGet();}}
 static class FastOfferSnapshot {String text="$28 4 mi";boolean rejectEnabled=true;}
 static volatile CountDownLatch gate,entered,closed;static volatile boolean mutate,mutateWindow;static AtomicInteger fullReads=new AtomicInteger(),numericReads=new AtomicInteger();
 static void waitRead(){if(entered!=null)entered.countDown();try{if(gate!=null)gate.await();}catch(InterruptedException e){throw new RuntimeException(e);}if(mutate)UI_GENERATION.incrementAndGet();if(mutateWindow)WINDOW_TRANSITION_EPOCH.incrementAndGet();}
 static class WindowScan {
  final boolean[] flags = new boolean[7];
  final List<Object> accepts=List.of(), rejects=List.of();
  final StringBuilder visibleText=new StringBuilder();
 }
 static final java.util.regex.Pattern LIVE_MONEY=java.util.regex.Pattern.compile("[0-9]");
 static final java.util.regex.Pattern LIVE_MILES=LIVE_MONEY;
 static volatile boolean empty,unreadable;
 static AtomicInteger quickReads=new AtomicInteger(),topReads=new AtomicInteger();
 static boolean scanDeliverThatWindows(TapAccessibilityService service, WindowScan scan) {
  fullReads.incrementAndGet();
  try {checkFallbackRead();waitRead();checkFallbackRead();scan.flags[6]=empty;return !unreadable;}
  finally {if(closed!=null)closed.countDown();}
 }
 static PageGuard.Page pageFromScan(WindowScan scan){return PageGuard.Page.OFFERS;}
 static List<FastOfferSnapshot> buildFastOfferSnapshots(WindowScan scan, PageGuard.Page page){
  return empty?List.of():List.of(new FastOfferSnapshot());
 }
 static String topVisibleOfferText(WindowScan scan){topReads.incrementAndGet();return "";}
 static void updatePageHint(PageGuard.Page page){}
 static void cacheDecisionEvidence(String text,long generation){}
 static class QuickTopResult {
  final String reason;
  QuickTopResult(FastOfferSnapshot snapshot,boolean exceeded,int visited,boolean empty,String reason){this.reason=reason;}
 }
 static QuickTopResult getQuickTopOfferSnapshotResult(){
  quickReads.incrementAndGet();
  try {waitRead();return new QuickTopResult(new FastOfferSnapshot(),false,1,false,"COHERENT");}
  finally {if(closed!=null)closed.countDown();}
 }
 static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(boolean a,boolean b,long t,java.util.function.BiPredicate<Float,Float> pred,StringBuilder trace){numericReads.incrementAndGet();REJECT_READ_ROOT.set(new AccessibilityNodeInfo());waitRead();return new FastOfferSnapshot();}
 static AccessibilityNodeInfo recentIndexedRoot(TapAccessibilityService service,long gen,long now,long epoch){return null;}
 static boolean quickNumericPairMatches(String text,float a,float b){return a==28f&&b==4f;}
 static int checks;static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
 static void await(CountDownLatch l)throws Exception{check(l.await(2,TimeUnit.SECONDS),"fixture worker completed");}
'''
test='''public static void main(String[]args)throws Exception {
 TapAccessibilityService svc=new TapAccessibilityService();INSTANCE.set(svc);svc.fallbackDeadlineReads.warmUp();svc.numericDeadlineReads.warmUp();
 check(getBoundedFastOfferSnapshots(60,false,()->true).cards.size()==1,"complete fallback survives");
 mutate=true;check(getBoundedFastOfferSnapshots(60,false,()->true)==null,"changed UI cannot publish full tree");mutate=false;
 mutateWindow=true;check(getBoundedFastOfferSnapshots(60,false,()->true)==null,"changed window cannot publish full tree");mutateWindow=false;
 gate=new CountDownLatch(1);entered=new CountDownLatch(1);closed=new CountDownLatch(1);
 long start=SystemClock.elapsedRealtime();check(getBoundedFastOfferSnapshots(60,false,()->true)==null,"blocked full tree yields no partial card");
 check(SystemClock.elapsedRealtime()-start<240,"full tree cannot hold offer caller for original 413ms");await(entered);
 int before=fullReads.get();start=SystemClock.elapsedRealtime();check(getBoundedFastOfferSnapshots(60,false,()->true)==null&&fullReads.get()==before,"busy worker never queues another full traversal");check(SystemClock.elapsedRealtime()-start<100,"busy result immediate");
 gate.countDown();await(closed);gate=entered=closed=null;
 for(int i=0;i<30 && getBoundedFastOfferSnapshots(60,false,()->true)==null;i++)Thread.yield();
 check(getBoundedFastOfferSnapshots(60,false,()->false)==null,"foreground priority prevents fallback");
 check("COHERENT".equals(getBoundedQuickTopOfferSnapshot(80,()->true).reason),"quick evidence arrives within budget");
 empty=true;
 int previous=fullReads.get();
 FullScanResult page=getBoundedFastOfferSnapshots(60,true,()->true);
 check(page.explicitEmpty && page.cards.isEmpty() && fullReads.get()==previous+1
       && topReads.get()==1,"page and locked top reuse a single traversal");
 empty=false;unreadable=true;
 check(getBoundedFastOfferSnapshots(60,false,()->true)==null,"unreadable window is not an explicit empty page");
 unreadable=false;
 gate=new CountDownLatch(1);entered=new CountDownLatch(1);closed=new CountDownLatch(1);
 AtomicBoolean current=new AtomicBoolean(true);
 AtomicReference<QuickTopResult> yielded=new AtomicReference<>();
 Thread caller=new Thread(()->yielded.set(getBoundedQuickTopOfferSnapshot(80,current::get)));
 caller.start();await(entered);current.set(false);caller.join(1000);
 check(yielded.get()!=null && "QUICK_YIELD".equals(yielded.get().reason)
       && closed.getCount()==1,"new order yields even while previous Android read is blocked");
 check(getBoundedFastOfferSnapshots(60,false,()->true)==null && "FULL_BUSY".equals(routingReadTrace()),
       "blocked quick read never spawns another fallback traversal");
 gate.countDown();await(closed);gate=entered=closed=null;
 for(int i=0;i<30 && !"COHERENT".equals(getBoundedQuickTopOfferSnapshot(80,()->true).reason);i++)Thread.yield();
 check(getBoundedNumericRejectSnapshot(28,4,true,false,()->true)!=null,"current numeric Reject succeeds");
 check(getBoundedCurrentRejectSnapshot(true,false,(a,b)->true,new StringBuilder(),60,()->true)!=null,
       "direct Reject finds the current control on the same bounded lane");
 check(getBoundedNumericRejectSnapshot(99,4,true,false,()->true)==null,"mismatched numeric pair cannot authorize routing");
 mutate=true;check(getBoundedNumericRejectSnapshot(28,4,true,false,()->true)==null,"UI churn invalidates numeric result");mutate=false;
 int recycled=AccessibilityNodeInfo.recycled.get();gate=new CountDownLatch(1);entered=new CountDownLatch(1);
 start=SystemClock.elapsedRealtime();check(getBoundedNumericRejectSnapshot(28,4,true,false,()->true)==null,"blocked numeric root cannot publish");check(SystemClock.elapsedRealtime()-start<200,"exact Reject bounded inside 40ms caller slice");await(entered);
 check(AccessibilityNodeInfo.recycled.get()==recycled,"in-flight root not recycled early");
 before=numericReads.get();
 check(getBoundedCurrentRejectSnapshot(true,false,(a,b)->true,new StringBuilder(),60,()->true)==null
       && "REJECT_BUSY".equals(routingReadTrace()) && numericReads.get()==before,
       "direct Reject does not repeat a blocked exact re-read");
 gate.countDown();for(int i=0;i<100 && AccessibilityNodeInfo.recycled.get()==recycled;i++)Thread.sleep(2);
 check(AccessibilityNodeInfo.recycled.get()==recycled+1,"late root recycled once after worker exits");
 svc.fallbackDeadlineReads.close();svc.numericDeadlineReads.close();
 System.out.println(checks+" production bounded full-tree/numeric caller lifecycle cases passed");
}}
'''
methods=['    private static final class FallbackReadScope ', '    private static final class FallbackReadExpired ', '    private static void checkFallbackRead(', '    public static String routingReadTrace(', '    private static <T> T readScanFallback(', '    static final class FullScanResult ', '    static FullScanResult getBoundedFastOfferSnapshots(', '    static QuickTopResult getBoundedQuickTopOfferSnapshot(', '    public static FastOfferSnapshot getBoundedNumericRejectSnapshot(', '    static FastOfferSnapshot getBoundedCurrentRejectSnapshot(', '    private static FastOfferSnapshot readBoundedRejectIndex(']
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'TapAccessibilityService.java';p.write_text(head+'\n'.join(block(m) for m in methods)+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'BoundedReadBatch.java'),str(src/'RejectReadProgress.java'),str(src/'QuickTreeBudgetPolicy.java'),str(src/'PageGuard.java'),str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.TapAccessibilityService'],check=True)
