"""Execute production rescue transition using the real RejectSequence timer and attempt gate."""
from pathlib import Path
import tempfile,subprocess
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text()
def block(sig):
 a=s.index(sig);b=s.index('{',a);i=b+1;d=1
 while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
head='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.function.*;import java.util.concurrent.atomic.AtomicBoolean;
class Rect {}
class SystemClock{static long now=1000;static long elapsedRealtime(){return now;}static long uptimeMillis(){return now;}}
class TapAccessibilityService {
 static class Rect{boolean isEmpty(){return false;}}
 static class FastOfferSnapshot{boolean rejectEnabled=true;Rect rejectBounds=new Rect();}
 static class QuickTopResult{int visited;String limitReason="OK";}
 static boolean enabled=true;static int sent;static long claimOutcomeEventEpoch(){return 1;}
 static final String REJECT_RECHECK_TOP_CHANGED="top changed";
 static void recheckRejectedTop(String text,boolean preferEmpty,Consumer<FastOfferSnapshot> same,Consumer<String> gone,Consumer<String> unknown,BooleanSupplier may,Runnable deferred,java.util.function.BiConsumer<Long,Boolean> stats,Consumer<QuickTopResult> tree){stats.accept(20L,false);FastOfferSnapshot card=new FastOfferSnapshot();card.rejectEnabled=enabled;same.accept(card);}
 static void tapSnapshotRejectRescue(FastOfferSnapshot c,float a,float b,Consumer<String> sentCallback,Consumer<String> fail,BooleanSupplier may){if(may.getAsBoolean()){sent++;sentCallback.accept("sent");}}
}
public class RescueReadiness {
 static final long REJECT_RESULT_DEADLINE_MS=5000;
 void requestImmediateFastCheck(long at,boolean urgent){}
 boolean finishRejectFromCachedOutcome(RejectConfirmState state){return false;}
 boolean monitorReady=true;boolean current=true;int expired,deferred;String reason="";
 RejectSequence rejectSequence=new RejectSequence();Map<String,RejectConfirmState> rejectConfirmStates=new HashMap<>();
 class Gate{boolean isCurrent(String id,long token){return current;}void invalidate(String id,long token){current=false;}}
 Gate rejectTerminalGate=new Gate();
 boolean rejectRescueMayRun(RejectConfirmState s){return true;}String rejectRescuePriority(RejectConfirmState s){return "NONE";}
 void deferFinalRejectRescue(RejectConfirmState s,String why){deferred++;reason=why;}void expireRejectTail(RejectConfirmState s,String why){expired++;reason=why;current=false;}
 void waitForRejectForeground(RejectConfirmState s){deferred++;reason="OUTSIDE_DELIVERTHAT";}
 void finishAsyncRejectConfirmation(RejectConfirmState s,String e,boolean changedTop){}void startAsyncRejectConfirmation(String s,long a,long b){}
 Consumer<String> offerReporterWithTiming(String text,String timing){return x->{};}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
'''
test='''public static void main(String[]args){
 String text="$28 4 mi Tomorrow at 11:00 AM Corner Bakery Cafe • 100 N La Cienega Blvd, Los Angeles, CA 90048";String id=CardText.identity(text);
 RescueReadiness h=new RescueReadiness();RejectConfirmState state=new RejectConfirmState(id,text,1000,1,1);h.rejectSequence.reserveFirstIfReady(id,1000);
 SystemClock.now=1180;h.runFinalRejectRescue(state);check(h.expired==0&&h.deferred==1&&h.reason.equals("RETRY_NOT_READY")&&TapAccessibilityService.sent==0,"180ms first probe waits instead of declaring second attempt exhausted");
 SystemClock.now=1359;h.runFinalRejectRescue(state);check(h.expired==0&&TapAccessibilityService.sent==0,"359ms still preserves first transaction");
 SystemClock.now=1360;h.runFinalRejectRescue(state);check(TapAccessibilityService.sent==1&&h.rejectSequence.attempts(id,1360)==2,"fresh enabled same-card proof at 360ms reserves exactly one rescue");
 SystemClock.now=1720;h.runFinalRejectRescue(state);check(h.expired==0&&h.reason.equals("RESCUE_ALREADY_SENT")&&TapAccessibilityService.sent==1&&state.lastActionAt==1360,"second action keeps one attempt ID while waiting for departure");
 h=new RescueReadiness();state=new RejectConfirmState(id,text,1000,1,1);h.rejectSequence.reserveFirstIfReady(id,1000);TapAccessibilityService.enabled=false;SystemClock.now=1180;h.runFinalRejectRescue(state);
 check(h.expired==1&&h.reason.contains("Reject控制进入处理中")&&state.processingReported,"disabled button never fabricates spinner; costly tail is retired");
 TapAccessibilityService.enabled=true;SystemClock.now=1280;int sent=TapAccessibilityService.sent;h.runFinalRejectRescue(state);check(TapAccessibilityService.sent==sent,"retired confirmation cannot resend without a new current publication");
 h.current=false;h.runFinalRejectRescue(state);check(TapAccessibilityService.sent==sent,"retired callback cannot send again");
 System.out.println(checks+" production Reject early-readiness/rescue state cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'RescueReadiness.java';p.write_text(head+block('    private static final class RejectConfirmState {')+block('    private void runFinalRejectRescue(')+test)
 files=['CardText','RejectSequence','RejectProbePolicy','OfferEnrichmentPolicy','AcceptSpinnerPolicy']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/(n+'.java')) for n in files],str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.RescueReadiness'],check=True)
