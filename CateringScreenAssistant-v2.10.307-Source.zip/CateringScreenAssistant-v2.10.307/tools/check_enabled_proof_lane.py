"""Run production enabled-proof scheduling with a deliberately backlogged scan lane."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()
def block(sig):
 a=s.index(sig);i=s.index('{',a)+1;d=1
 while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
head='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;
class EnabledProofHarness {boolean canReadAcceptRecoveryProof(long owner){return allowProof;}
 boolean allowProof=true; static class Replay {void event(long at,String text){}} Replay acceptReplay=new Replay();
 static class SystemClock {static long now=1000;static long elapsedRealtime(){return now;}}
 static class Handler {List<Runnable> tasks=new ArrayList<>();void postAtFrontOfQueue(Runnable r){tasks.add(0,r);}void drain(){while(!tasks.isEmpty())tasks.remove(0).run();}}
 static class TapAccessibilityService {
  static int reads,nodeReads;static FastOfferSnapshot result,nodeResult;static Runnable hook,nodeHook;static boolean fail,processing;
  static boolean ownedAcceptNodeProcessingObserved(){return processing;}
  static String ownedAcceptNodeRefreshDetail(){return processing?"REFRESH_FAILED:ACTION_DISABLED":"NO_CURRENT_RECEIPT";}
  static class FastOfferSnapshot {boolean acceptEnabled=true;long capturedAt=1000;}
  static FastOfferSnapshot refreshCurrentOwnedAcceptNodes(String t,long at){nodeReads++;if(nodeHook!=null)nodeHook.run();return nodeResult;}
  static FastOfferSnapshot observeCurrentOwnedAcceptSnapshot(String t,long at){reads++;if(hook!=null)hook.run();if(fail)throw new IllegalStateException("stale");return result;}
 }
 enum SerialAction {NONE,ACCEPT}SerialAction serialTopAction=SerialAction.ACCEPT;
 boolean monitorReady=true,paused,active,receipt;String guard="";
 long acceptPageReadActiveAt,acceptPageReadOwner=900;long serialTopActionAt=900,pressureOwner=900,pressureEpoch=1,acceptControlEnabledActionAt,acceptControlEnabledAt;
 AtomicLong claimEpoch=new AtomicLong(1),enabledProofRebindOwner=new AtomicLong(),enabledProofDemand=new AtomicLong();ClaimInspectionQueue claimInspectionQueue=new ClaimInspectionQueue();
 Handler fastWorker=new Handler(),acceptProofWorker=new Handler(),acceptOutcomeWorker=new Handler();int resumed,inspected,probes;List<String> logs=new ArrayList<>();
 boolean isManualInterventionPaused(){return paused;}String acceptRetryGuard(long owner){return guard;}
 boolean acceptPressureActive(long owner){return active;}
 boolean resumePressureFromPage(String text,long epoch,long at){if(!receipt)return false;resumed++;return true;}
 boolean resumeAcceptPressure(long owner,long epoch,long at,TapAccessibilityService.FastOfferSnapshot f){if(owner!=serialTopActionAt||epoch!=claimEpoch.get()||!guard.isEmpty())return false;resumed++;return true;}
 String acceptRetryDecisionText(String text){return text;}
 void scheduleAcceptPageProbe(long at){probes++;}
 void scheduleAcceptPageProbe(long at,boolean urgent){if(urgent)urgentProbes++;probes++;}int urgentProbes;
 void scheduleClaimInspection(String t,long e,int a,int b,long d){inspected++;}
 void inspectClaim(String t,long e,int a,int b){inspected++;}
 java.util.function.Consumer<String> acceptReporter(String t){return logs::add;}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static EnabledProofHarness fresh(){TapAccessibilityService.reads=TapAccessibilityService.nodeReads=0;TapAccessibilityService.nodeResult=null;TapAccessibilityService.processing=false;TapAccessibilityService.hook=TapAccessibilityService.nodeHook=null;TapAccessibilityService.fail=false;TapAccessibilityService.result=new TapAccessibilityService.FastOfferSnapshot();return new EnabledProofHarness();}
'''
tests='''public static void main(String[] args){
 EnabledProofHarness h=fresh();h.allowProof=false;
 h.scheduleEnabledClaimInspection("owned",1,990);
 check(h.acceptProofWorker.tasks.isEmpty(),"visual loading blocks new proof reads");
 h.allowProof=true;h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(h.resumed==1,"clear loading gate allows enabled proof scheduling");
 h=fresh();h.fastWorker.tasks.add(()->{throw new AssertionError("ordinary scan backlog must not run");});
 h.acceptOutcomeWorker.tasks.add(()->{throw new AssertionError("page outcome backlog must not run");});
 for(int i=0;i<1000;i++)h.scheduleEnabledClaimInspection("owned",1,990);
 check(h.acceptProofWorker.tasks.size()==1&&h.fastWorker.tasks.size()==1&&h.acceptOutcomeWorker.tasks.size()==1,"1000 caption wakes coalesce into one independent proof, without waiting for scan or page-outcome queue");
 h.acceptProofWorker.drain();check(TapAccessibilityService.reads==1&&h.resumed==1&&h.inspected==0,"one current owned-row proof resumes without duplicate inspector");
 check(h.enabledProofRebindOwner.get()==0,"successful proof releases coalescing owner");
 check(h.acceptOutcomeWorker.tasks.size()==1,"owned enabled renewal never drains or waits for page/navigation backlog");
 h=fresh();TapAccessibilityService.result.acceptEnabled=false;h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();check(h.resumed==0&&h.inspected==1,"disabled current row never sends and falls back to ordinary state inspection");
 h=fresh();TapAccessibilityService.result=null;h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();check(h.resumed==0&&h.inspected==1&&h.urgentProbes==1,"missing original row cannot borrow top-card authority");
 h=fresh();h.scheduleEnabledClaimInspection("owned",1,990);h.claimEpoch.incrementAndGet();h.acceptProofWorker.drain();check(TapAccessibilityService.reads==0&&h.resumed==0,"stale queued owner performs no read or resume");
 h=fresh();h.scheduleEnabledClaimInspection("owned",1,990);h.paused=true;h.acceptProofWorker.drain();check(TapAccessibilityService.reads==0,"manual pause cancels proof before Binder work");
 h=fresh();final EnabledProofHarness terminal=h;TapAccessibilityService.hook=()->terminal.guard="negative";h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();check(h.resumed==0,"negative appearing during proof wins before resume");
 h=fresh();final EnabledProofHarness switched=h;TapAccessibilityService.hook=()->switched.serialTopActionAt=901;h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();check(h.resumed==0,"owner changing during read cannot inherit result");
 h=fresh();TapAccessibilityService.fail=true;h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();check(h.inspected==1&&h.enabledProofRebindOwner.get()==0,"read exception returns to inspector and never leaks coalescing latch");
 h=fresh();h.receipt=true;h.scheduleEnabledClaimInspection("owned",1,990);check(h.resumed==1&&h.acceptProofWorker.tasks.isEmpty()&&TapAccessibilityService.reads==0,"existing complete page receipt avoids a new read entirely");
 h=fresh();h.active=true;h.scheduleEnabledClaimInspection("owned",1,990);check(h.acceptProofWorker.tasks.isEmpty(),"running pressure chain never creates another proof loop");
 h=fresh();h.acceptProofWorker=null;h.scheduleEnabledClaimInspection("owned",1,990);h.fastWorker.drain();check(h.inspected==1,"missing proof worker preserves ordinary inspector fallback");
 h=fresh();long oldTicket=h.claimInspectionQueue.request(1,900,50);h.scheduleEnabledClaimInspection("owned",1,990);
 check(!h.claimInspectionQueue.begin(oldTicket,1)&&h.claimInspectionQueue.request(1,1000,0)==0,"urgent proof invalidates pending scan inspector and coalesces duplicate requests during its read");
 h.acceptProofWorker.drain();check(h.claimInspectionQueue.request(1,1100,0)>0,"completed proof releases inspection ticket for later outcomes");
 h=fresh();h.scheduleEnabledClaimInspection("owned",1,990);h.receipt=true;h.acceptProofWorker.drain();
 check(h.resumed==1&&TapAccessibilityService.reads==0,"page proof completed during queue wait avoids another Binder read");
 h=fresh();TapAccessibilityService.nodeResult=new TapAccessibilityService.FastOfferSnapshot();h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(h.resumed==1&&TapAccessibilityService.nodeReads==1&&TapAccessibilityService.reads==0,"live owned-node proof resumes without seven-query page discovery");
 check(h.logs.stream().anyMatch(x->x.contains("source=LIVE_OWNED_NODES")),"diagnostics distinguish node renewal from page fallback");
 h=fresh();h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(TapAccessibilityService.nodeReads==1&&TapAccessibilityService.reads==1&&h.resumed==1,"node failure still locates current owned row through unchanged page fallback");
 h=fresh();TapAccessibilityService.processing=true;h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(h.resumed==0&&h.inspected==0&&h.probes==1&&TapAccessibilityService.reads==0,"known disabled node waits for outcome without duplicate page fallback/inspector or gesture");
 check(h.logs.stream().anyMatch(x->x.contains("LIVE_CONTROL_PROCESSING")&&x.contains("ACTION_DISABLED")),"processing diagnostics distinguish live disabled from missing handles");
 TapAccessibilityService.processing=false;h.scheduleEnabledClaimInspection("owned",1,1001);h.acceptProofWorker.drain();
 check(h.resumed==1&&TapAccessibilityService.reads==1,"later enabled wake remains eligible immediately, no processing suppression cache");
 h=fresh();final EnabledProofHarness reawaken=h;TapAccessibilityService.result=null;
 TapAccessibilityService.hook=()->{TapAccessibilityService.hook=null;reawaken.scheduleEnabledClaimInspection("owned",1,1001);};
 h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.tasks.remove(0).run();
 check(h.acceptProofWorker.tasks.size()==1&&h.inspected==0,"enabled wake arriving during unsuccessful proof queues immediate new proof instead of being lost");
 TapAccessibilityService.result=new TapAccessibilityService.FastOfferSnapshot();h.acceptProofWorker.drain();
 check(h.resumed==1&&h.enabledProofRebindOwner.get()==0,"new current proof resumes original transaction after read race");
 h=fresh();final EnabledProofHarness pageWins=h;
 TapAccessibilityService.nodeHook=()->pageWins.receipt=true;
 h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(h.resumed==1 && TapAccessibilityService.reads==0 && h.inspected==0,"page proof completing during node read prevents duplicate seven-query fallback");
 h=fresh();final EnabledProofHarness pressureWins=h;
 TapAccessibilityService.nodeHook=()->pressureWins.active=true;
 h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(TapAccessibilityService.reads==0 && h.inspected==0,"parallel resumed pressure prevents duplicate fallback");
 h=fresh();h.acceptPageReadActiveAt=999;
 h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(h.resumed==0 && TapAccessibilityService.reads==0 && h.inspected==0 && h.probes==1,"in-flight result read owns fallback work without a duplicate page query");
 h=fresh();h.acceptPageReadActiveAt=800;
 h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(h.resumed==1 && TapAccessibilityService.reads==1,"expired result-read marker cannot suppress current fallback");
 h=fresh();h.acceptPageReadActiveAt=999;h.acceptPageReadOwner=899;
 h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(h.resumed==1 && TapAccessibilityService.reads==1,"a prior transaction's in-flight page marker cannot delay the new transaction");

 h=fresh();final EnabledProofHarness changedDuringNodes=h;
 TapAccessibilityService.nodeHook=()->changedDuringNodes.serialTopActionAt=901;
 h.scheduleEnabledClaimInspection("owned",1,990);h.acceptProofWorker.drain();
 check(TapAccessibilityService.reads==0 && h.resumed==0,"owner change during node read stops before any fallback work");
 System.out.println(checks+" production enabled-proof lane/coalescing cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'EnabledProofHarness.java';f.write_text(head+block('    private boolean scheduleEnabledProofRebind(')+block('    private void scheduleEnabledClaimInspection(')+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'ClaimInspectionQueue.java'),str(f)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.EnabledProofHarness'],check=True)
