from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()
def method(signature):
 a=s.index(signature); i=s.index('{',a)+1; depth=1; end=i
 while depth:
  depth+=(s[end]=='{')-(s[end]=='}'); end+=1
 return s[a:end]
methods=method('    private RejectConfirmState ownedRejectForText(')+method('    private boolean skipFreshOwnedRejectOcr(')
head="""package com.local.cateringscreenassistant;
import java.util.*;
public class CoalescingHarness {
 static long generation=1; static boolean demand;
 enum SerialAction{NONE,ACCEPT,REJECT}SerialAction serialTopAction=SerialAction.NONE;String serialTopText="";long serialTopActionAt;
 static class TapAccessibilityService {
  static class DecisionEvidence {String text;long capturedAt,uiGeneration=1;DecisionEvidence(String t,long at){text=t;capturedAt=at;}}
  static DecisionEvidence evidence;
  static DecisionEvidence recentDecisionEvidence(long age){return evidence!=null && 1119-evidence.capturedAt>=0 && 1119-evidence.capturedAt<=age?evidence:null;}
  static long currentUiGeneration(){return generation;}
 }
 static class RejectConfirmState {String id="one",text;long actionAt=1000,token=1;RejectConfirmState(String t){text=t;}}
 Map<String,RejectConfirmState> rejectConfirmStates=new HashMap<>();
 static class Gate{boolean current=true;boolean isCurrent(String id,long token){return current;}}
 Gate rejectTerminalGate=new Gate();
 static boolean foregroundOfferDemandRecent(long age){return demand;}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
"""
test="""public static void main(String[] args) {
 CoalescingHarness h=new CoalescingHarness();
 String old="$52–62 19.4 mi (~29 mins) Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 String rich=old.replace("Porto's","Tomorrow at 9:25 AM Porto's");
 h.rejectConfirmStates.put("one",new RejectConfirmState(old));
 TapAccessibilityService.evidence=new TapAccessibilityService.DecisionEvidence(rich,1100);
 check(h.skipFreshOwnedRejectOcr(1119),"fresh compatible enrichment skips initial OCR work");
 TapAccessibilityService.evidence=new TapAccessibilityService.DecisionEvidence(rich+" "+rich,1100);
 check(h.skipFreshOwnedRejectOcr(1119),"same-card duplicate mileage and pickup suppresses only owned OCR");
 TapAccessibilityService.evidence=new TapAccessibilityService.DecisionEvidence(rich,1100);
 check(!h.skipFreshOwnedRejectOcr(1180),"180ms age always reopens visual fallback");
 generation=2;check(!h.skipFreshOwnedRejectOcr(1119),"new UI generation reopens OCR");generation=1;
 demand=true;check(!h.skipFreshOwnedRejectOcr(1119),"new offer demand wins");demand=false;
 for(String next:new String[]{rich.replace("52–62","53–63"),rich.replace("6100","6101"),rich+" "+rich.replace("6100","6101"),rich+" Begin Delivery"}) {
  TapAccessibilityService.evidence=new TapAccessibilityService.DecisionEvidence(next,1100);
  check(!h.skipFreshOwnedRejectOcr(1119),"different/terminal frame retains OCR");
 }
 h.rejectConfirmStates.get("one").text=rich;
 TapAccessibilityService.evidence=new TapAccessibilityService.DecisionEvidence(rich.replace("9:25","10:25"),1100);
 check(!h.skipFreshOwnedRejectOcr(1119),"different pickup retains OCR");
 TapAccessibilityService.evidence=new TapAccessibilityService.DecisionEvidence(rich,1100);
 h.rejectTerminalGate.current=false;check(!h.skipFreshOwnedRejectOcr(1119),"retired transaction cannot suppress OCR");
 h.rejectTerminalGate.current=true;TapAccessibilityService.evidence=null;
 check(!h.skipFreshOwnedRejectOcr(1119),"missing semantic evidence keeps OCR fallback");
 h.rejectConfirmStates.clear();h.serialTopAction=SerialAction.REJECT;h.serialTopText=rich;h.serialTopActionAt=1000;
 TapAccessibilityService.evidence=new TapAccessibilityService.DecisionEvidence(rich,1100);
 check(h.skipFreshOwnedRejectOcr(1119),"same serial Reject coalesces OCR before dispatch callback creates background owner");
 h.serialTopText=rich.replace("6100","6101");check(!h.skipFreshOwnedRejectOcr(1119),"serial owner never coalesces different pickup address");
 h.serialTopText=rich;h.serialTopAction=SerialAction.ACCEPT;check(!h.skipFreshOwnedRejectOcr(1119),"Accept work is not skipped by Reject coalescing");
 System.out.println(checks+" production Reject OCR coalescing cases passed");
}}
"""
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'CoalescingHarness.java';p.write_text(head+methods+test)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in ['CardText.java','ClaimSuccessSignals.java','LargeOrderPopupGuard.java','OfferEnrichmentPolicy.java','RejectWorkPolicy.java']],str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.CoalescingHarness'],check=True)
# The executed gate must run before allocating/copying the image. In-flight work also has
# a transaction-epoch fence before ML Kit, raw evaluation and enhanced evaluation.
frame=s[s.index('    private void onFrame('):s.index('    private boolean tryVisualAccessibilityFastLane(')]
assert frame.index('skipFreshOwnedRejectOcr(SystemClock.elapsedRealtime())')<frame.index('imageToTopRoiBitmap(')<frame.index('recognizer.process(')
assert frame.count('terminalEpoch != claimEpoch.get()')>=4
print('Reject pre-copy/in-flight epoch integration checks passed')
