from pathlib import Path
import tempfile,subprocess
p=Path(__file__).resolve().parents[1];src=p/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'TapAccessibilityService.java').read_text()
a=s.index('    public static void tapVisualSnapshotRetryDetailed(');b=s.index('    public static void tapIfOfferStillMatches',a);method=s[a:b]
header="""package com.local.cateringscreenassistant;
import java.util.function.*;import java.util.concurrent.atomic.*;
class VisualRetryHarness {
 static class SystemClock{static long now=1000;static long elapsedRealtime(){return now;}}
 static class Rect{boolean isEmpty(){return false;}}
 static class TapAccessibilityService{}
 static class FastOfferSnapshot {String text;float amount=88.40f,miles=.4f;boolean acceptEnabled=true;Rect acceptBounds=new Rect();FastOfferSnapshot(String t){text=t;}}
 static class OcrMonitorService {static String guard="";static boolean monitor=true;static long at=100;static boolean isMonitoring(){return monitor;}static boolean isManualInterventionPaused(){return false;}static long pendingClaimSince(){return at;}static String acceptRetryGuard(long at){return guard;}}
 static AtomicReference<TapAccessibilityService> INSTANCE=new AtomicReference<>(new TapAccessibilityService());static AtomicLong UI_GENERATION=new AtomicLong(1);
 static String foregroundPackage="com.deliverthat.driver";static boolean currentNegativeSurfaceBlocksAccept(){return false;}static FastOfferSnapshot semantic,numeric;static boolean churn,lateChurn,lateNegative;static String failure="";static int taps,checks;
 static FastOfferSnapshot observeCurrentTopAcceptSnapshot(){return semantic;}
 static FastOfferSnapshot getIndexedNumericVisualAcceptSnapshot(float a,float m,Rect b){if(churn)UI_GENERATION.incrementAndGet();return numeric;}
 static void dispatchActionGesture(TapAccessibilityService s,Rect b,boolean a,long d,int v,Consumer<String> ok,Consumer<String> fail,BooleanSupplier guard){if(lateChurn)UI_GENERATION.incrementAndGet();if(lateNegative)OcrMonitorService.guard="RETRY_NEGATIVE_PENDING";if(!guard.getAsBoolean()){failure="FINAL_FENCE";return;}taps++;ok.accept("sent");}
 static String text="$88.40 0.4 mi (~4 mins) Today at 5:00 PM Mendocino Farms • 4531 Hollywood Blvd, Los Angeles, CA 90027";
 static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
 static void reset(){SystemClock.now=1000;UI_GENERATION.set(1);OcrMonitorService.guard="";OcrMonitorService.monitor=true;OcrMonitorService.at=100;churn=false;lateChurn=false;lateNegative=false;semantic=null;numeric=new FastOfferSnapshot("$88.40 0.4 mi");failure="";taps=0;}
 static void clearPageRetryReceipt(long at){}
 static void run(){tapVisualSnapshotRetryDetailed(new FastOfferSnapshot(text),800,1,100,2,d->{},d->failure=d);}
"""
tests="""public static void main(String[] args){
 reset();run();check(taps==1,"admitted visual CTA sends without extra Binder reads");
 reset();semantic=new FastOfferSnapshot(text);semantic.acceptEnabled=false;run();check(taps==1,"visual retry does not wait for refreshed semantic state");
 reset();numeric=null;run();check(taps==1,"visual retry avoids a second numeric index read");
 reset();churn=true;run();check(taps==1,"generation churn does not cancel visual retry");
 reset();lateChurn=true;run();check(taps==1,"final gesture generation churn does not cancel");
 reset();OcrMonitorService.guard="RETRY_TERMINAL_OBSERVED";run();check(taps==0,"terminal result owns retry");
 reset();OcrMonitorService.at=101;run();check(taps==0,"old transaction cannot retry");
 reset();SystemClock.now=1201;run();check(taps==1,"aged frame accepted by owner in speed-first mode");
 reset();OcrMonitorService.monitor=false;run();check(taps==0,"stopped monitor cancels retry");
 reset();foregroundPackage="other.app";run();check(taps==0,"foreign app is never tapped");
 System.out.println(checks+" speed-first production visual retry cases passed");}}
"""
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'VisualRetryHarness.java';f.write_text(header+method+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d]+[str(src/n) for n in ['CardText.java','OfferEnrichmentPolicy.java','ClaimSuccessSignals.java','PageOutcomePolicy.java','VisualRetryPolicy.java','ActionDispatchPolicy.java']]+[str(f)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.VisualRetryHarness'],check=True)
