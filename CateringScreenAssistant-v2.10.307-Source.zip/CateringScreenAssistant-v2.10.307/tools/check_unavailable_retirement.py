"""Exercise actual retirement routing when an enabled card remains behind a failure prompt."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()
a=s.index('    private void scheduleUnavailableCardRetirement(');b=s.index('    private boolean yieldDeepScanDuringUnavailableReturn(',a)
method=s[a:b]
head='''package com.local.cateringscreenassistant;
import java.util.*;
class RetirementHarness {
 static class SystemClock {static long uptimeMillis(){return 1500;}static long elapsedRealtime(){return 1500;}}
 static class Handler {List<Runnable> queue=new ArrayList<>();void post(Runnable r){queue.add(r);}void postDelayed(Runnable r,long ms){queue.add(r);}void drain(){while(!queue.isEmpty())queue.remove(0).run();}}Handler fastWorker=new Handler(),acceptOutcomeWorker=new Handler();
 static final long UNAVAILABLE_RETIRE_DELAY_MS=160,UNAVAILABLE_RETIRE_POLL_MS=90;
 static class TapAccessibilityService {
  static boolean negative,success,offers;static FastOfferSnapshot accept,reject;
  static class Rect {boolean isEmpty(){return false;}}
  static class FastOfferSnapshot {String text;boolean acceptEnabled,rejectEnabled;float amount=117.07f,miles=1.7f;Rect rejectBounds=new Rect();FastOfferSnapshot(String t){text=t;}}
  static boolean hasCurrentNegativeBaseline(FastOfferSnapshot f){return negative;}
  static boolean recentAcceptedJobDetailMatches(String t,long at){return success;}
  static boolean liveBeginDeliveryMatches(String t){return success;}
  static FastOfferSnapshot getIndexedTopAcceptSnapshot(boolean a,boolean b){return accept;}
  static FastOfferSnapshot getIndexedTopRejectSnapshot(boolean a,boolean b){return reject;}
  static FastOfferSnapshot getPairedRejectSnapshotFromIndexedAccept(FastOfferSnapshot a){return reject;}
  static boolean hasCurrentOffersSurfaceEvidence(boolean b){return offers;}
 }
 enum SerialAction {NONE,ACCEPT}SerialAction serialTopAction=SerialAction.NONE;long serialTopActionAt,postTerminalVerifyActionAt=1000;
 boolean monitorReady=true,manualInterventionConfirmed,postClaimIsolationActive;static final int UNAVAILABLE_RETIRE_MAX_POLLS=3;
 int rejects,successes,wakes,polls,returns;List<String> logs=new ArrayList<>();
 boolean isPostTerminalSuccessCandidate(String t){return false;}
 void confirmPostTerminalClaimSuccess(String t,String e){successes++;}
 void requestImmediateFastCheck(long n){wakes++;}void observeTerminalLossTop(String t,long n){}
 void returnToOffersAfterUnavailable(String t,java.util.function.Consumer<String> c){returns++;}
 void handleFastRejection(TapAccessibilityService.FastOfferSnapshot s,float a,float m,String e){rejects++;}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static final String OFFER="$117.07 1.7 mi Tomorrow at 11:15 AM Mendocino Farms • 14141 Ventura Blvd, Sherman Oaks, CA 91423";
 static RetirementHarness fresh(){TapAccessibilityService.success=TapAccessibilityService.negative=TapAccessibilityService.offers=false;
  TapAccessibilityService.accept=new TapAccessibilityService.FastOfferSnapshot(OFFER);TapAccessibilityService.accept.acceptEnabled=true;
  TapAccessibilityService.reject=new TapAccessibilityService.FastOfferSnapshot(OFFER);TapAccessibilityService.reject.rejectEnabled=true;return new RetirementHarness();}
'''
tests='''public static void main(String[] args){
 RetirementHarness h=fresh();TapAccessibilityService.negative=true;h.retireUnavailableCard(OFFER,1000,0,h.logs::add);h.fastWorker.drain();
 check(h.rejects==1&&h.wakes==0,"enabled stale original behind fresh negative enters verified Reject cleanup");
 h=fresh();h.retireUnavailableCard(OFFER,1000,0,h.logs::add);h.fastWorker.drain();check(h.rejects==0&&h.wakes==1,"clean enabled current card follows normal publication flow");
 h=fresh();TapAccessibilityService.negative=true;TapAccessibilityService.accept.text=OFFER.replace("117.07","118.07");h.retireUnavailableCard(OFFER,1000,0,h.logs::add);h.fastWorker.drain();
 check(h.rejects==0&&h.wakes==1,"different current order never inherits old cleanup");
 h=fresh();TapAccessibilityService.negative=true;TapAccessibilityService.success=true;h.retireUnavailableCard(OFFER,1000,0,h.logs::add);h.fastWorker.drain();
 check(h.successes==1&&h.rejects==0,"Begin Delivery wins before cleanup");
 h=fresh();h.serialTopAction=SerialAction.ACCEPT;TapAccessibilityService.negative=true;h.retireUnavailableCard(OFFER,1000,0,h.logs::add);h.fastWorker.drain();check(h.rejects==0&&h.wakes==0,"new active owner cancels old cleanup");
 h=fresh();h.postTerminalVerifyActionAt=2000;TapAccessibilityService.negative=true;h.retireUnavailableCard(OFFER,1000,0,h.logs::add);h.fastWorker.drain();check(h.rejects==0,"old token cannot clear new transaction");
 h=fresh();h.scheduleUnavailableCardRetirement(OFFER,1000,0,h.logs::add);
 check(h.fastWorker.queue.isEmpty()&&h.acceptOutcomeWorker.queue.size()==1,"retirement Binder discovery queues on outcome worker, leaving first-shot queue free");
 h=fresh();TapAccessibilityService.negative=true;h.retireUnavailableCard(OFFER,1000,0,h.logs::add);
 check(h.rejects==0&&h.fastWorker.queue.size()==1,"outcome discovery does not mutate Reject transaction directly");
 h.serialTopAction=SerialAction.ACCEPT;h.serialTopActionAt=2000;h.fastWorker.drain();
 check(h.rejects==0,"new Accept between background discovery and foreground commit wins cleanup race");
 System.out.println(checks+" production unavailable retirement/surface cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'RetirementHarness.java';f.write_text(head+method+tests)
 names=['CardText.java','OfferEnrichmentPolicy.java','ClaimSuccessSignals.java']
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,*[str(src/n) for n in names],str(f)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.RetirementHarness'],check=True)
