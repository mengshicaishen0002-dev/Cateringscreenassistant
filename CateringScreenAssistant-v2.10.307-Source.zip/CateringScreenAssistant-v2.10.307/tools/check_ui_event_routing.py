#!/usr/bin/env python3
"""Compile the actual event-classification and generation-routing block."""
from pathlib import Path
import subprocess,tempfile
p=Path(__file__).resolve().parents[1];src=p/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'TapAccessibilityService.java').read_text()
a=s.index('            String shallowDecisionText = eventOwnText(event);',s.index('public void onAccessibilityEvent'))
b=s.index('            // v2.10.59 latency fix:',a)
block=s[a:b]
assert 'queueAncestorEvidence(event, generation);' in s
assert 'cacheDecisionEvidenceAncestorsFromEvent(event, generation)' not in s[a:s.index('    @Override\n    public void onInterrupt',a)]
assert 'if (!benignEvent) queueDirectCheck();' in s
assert 'String claimEventRaw = shallowDecisionText;' in s
# Important: no early return may suppress positive/negative event evidence.
assert 'return;' not in s[a:s.index('    @Override\n    public void onInterrupt',a)]
java="""package com.local.cateringscreenassistant;
import java.util.concurrent.atomic.AtomicLong;
class UiEventRoutingTest {
 static final AtomicLong UI_GENERATION=new AtomicLong(20), PRESSURE_LAYOUT_EPOCH=new AtomicLong(), BENIGN_UI_EVENTS=new AtomicLong();
 static String lastUiMutationTrace="INITIAL";
 static class Event {int changes,window=3;String before="",text="";
 int getContentChangeTypes(){return changes;}int getWindowId(){return window;}String getBeforeText(){return before;}
 long getEventTime(){return 123L;}}
 static class OcrMonitorService {static void requestImmediateFastCheck(long at,boolean urgent,long received) {}}
 static long eventReceivedAt=123L;
 static PageGuard.Page lastPage=PageGuard.Page.UNKNOWN;
 static void updatePageHint(PageGuard.Page p){lastPage=p;}
 static String eventOwnText(Event e){return e.text;}
 static boolean route(Event event,int type){
"""+block+"""return benignEvent;}
 static int checks;
 static void check(boolean ok){checks++;if(!ok)throw new AssertionError("routing "+checks);}
 public static void main(String[] args){
 Event e=new Event();
 check(route(e,8));check(PRESSURE_LAYOUT_EPOCH.get()==0);check(UI_GENERATION.get()==20);check(BENIGN_UI_EVENTS.get()==1);check(lastUiMutationTrace.equals("INITIAL"));
 e.before="Expires in 12s";e.text="Expires in 11s";
 check(route(e,16));check(UI_GENERATION.get()==20);check(BENIGN_UI_EVENTS.get()==2);
 // Undefined/subtree/text-only content events still invalidate (no complete old/new edit proof).
 for(int flags:new int[]{0,1,2,3,4,8,64}){e.changes=flags;check(!route(e,2048));}
 check(UI_GENERATION.get()==27);check(lastUiMutationTrace.contains("changes=64"));
 e.changes=0;e.text="This offer is no longer available.";
 check(!route(e,16));check(UI_GENERATION.get()==28);
 e.text="Expires in 11s";e.before="Expires in 12s";
 for(int type:new int[]{1,32,4096,4194304})check(!route(e,type));
 e.window=-1;check(!route(e,8));check(UI_GENERATION.get()==33);
 long oldUi=UI_GENERATION.get(),oldLayout=PRESSURE_LAYOUT_EPOCH.get();
 e.window=3;e.text="Accept";check(!route(e,1));check(UI_GENERATION.get()==oldUi+1&&PRESSURE_LAYOUT_EPOCH.get()==oldLayout);
 e.changes=1;check(!route(e,2048));check(PRESSURE_LAYOUT_EPOCH.get()==oldLayout+1);
 e.changes=0;check(!route(e,4096));check(PRESSURE_LAYOUT_EPOCH.get()==oldLayout+2);
 System.out.println(checks+" production event-routing cases passed");
 }
}
"""
with tempfile.TemporaryDirectory(prefix='ui-routing-') as d:
 h=Path(d)/'UiEventRoutingTest.java';h.write_text(java)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'PageGuard.java'),str(src/'UiMutationPolicy.java'),str(h)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.UiEventRoutingTest'],check=True)
