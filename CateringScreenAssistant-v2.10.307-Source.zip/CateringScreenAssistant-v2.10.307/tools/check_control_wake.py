from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';s=(src/'OcrMonitorService.java').read_text()
def block(sig):
 a=s.index(sig);i=s.index('{',a)+1;d=1
 while d:d+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i].replace("OcrMonitorService","ControlWakeHarness")
code='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;import java.util.function.*;
class ControlWakeHarness {static class SystemClock{static long elapsedRealtime(){return 1000;}}
 static ControlWakeHarness activeInstance;boolean monitorReady=true;enum SerialAction{NONE,ACCEPT}SerialAction serialTopAction=SerialAction.NONE;
 String serialTopText="$101.55 6 mi Cafe Rio • 24230 Valencia Blvd, Valencia, CA 91355",guard="";long acceptControlEnabledActionAt,acceptControlEnabledAt;long serialTopActionAt=900;AtomicLong claimEpoch=new AtomicLong(1);int inspections;List<String> log=new ArrayList<>();
 final AcceptAttemptAudit acceptAudit=new AcceptAttemptAudit();
 class Prefs{float getFloat(String key,float fallback){return key.equals("minPay")?100f:50f;}boolean getBoolean(String key,boolean fallback){return true;}}Prefs prefs=new Prefs();
 static boolean isMonitoring(){return activeInstance!=null&&activeInstance.monitorReady;}static String acceptRetryGuard(long at){return activeInstance.guard;}
 void scheduleEnabledClaimInspection(String t,long e,long at){inspections++;}
 Consumer<String> acceptReporter(String text){return log::add;}
 static int checks;static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
'''+block('    public static boolean shouldPrefetchOfferRoot(')+block('    public static void onAcceptControlObserved(')+'''
 public static void main(String[] args){ControlWakeHarness h=new ControlWakeHarness();activeInstance=h;
 check(shouldPrefetchOfferRoot("$101.55")&&shouldPrefetchOfferRoot("$50 Cafe • 475 S Lake Ave, Pasadena, CA 91101"),"amount-only hint can overlap root acquisition before mileage export");
 check(!shouldPrefetchOfferRoot("$49")&&!shouldPrefetchOfferRoot("6 mi")&&!shouldPrefetchOfferRoot("$70 Cafe • 10 Main St, Los Angeles, CA 90001"),"below all branches/missing amount does not prefetch");
 check(h.serialTopAction==SerialAction.NONE&&h.inspections==0,"prefetch hint does not admit claim");
 h.acceptAudit.begin(900,h.serialTopText);h.acceptAudit.dispatched(900,950);
 h.serialTopAction=SerialAction.ACCEPT;check(!shouldPrefetchOfferRoot("$101.55"),"pending transaction stops root prefetch hints");
 onAcceptControlObserved(900,"DISABLED",40);onAcceptControlObserved(900,"NOT_EXPORTED:REFRESH_FAILED",80);check(h.inspections==0,"disabled/missing signal never requests retry");
 onAcceptControlObserved(900,"ENABLED",100);check(h.inspections==1,"enabled edge requests current identity inspection only");
 onAcceptControlObserved(900,"ENABLED_RECOVERED",110);check(h.inspections==2&&h.acceptControlEnabledAt==1000&&h.acceptControlEnabledActionAt==900,"recovered control supplies scheduling override only");
 PageOutcomePolicy.Tracker tracker=new PageOutcomePolicy.Tracker(950,h.serialTopText,null,false);
 check(h.acceptAudit.summary(h.serialTopText,tracker).contains("firstEnabled=50ms"),"actual control wake updates enabled diagnostic even without a page enabled sample");
 h.guard="RETRY_NEGATIVE_PENDING";onAcceptControlObserved(900,"ENABLED",120);check(h.inspections==2,"negative hint vetoes wake");
 h.guard="";onAcceptControlObserved(901,"ENABLED",140);check(h.inspections==2,"foreign transaction cannot wake current retry");
 h.monitorReady=false;onAcceptControlObserved(900,"ENABLED",160);check(h.inspections==2,"stopped monitor does no wake");
 System.out.println(checks+" production prefetch-hint/control-wake admission cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'ControlWakeHarness.java';p.write_text(code)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'CardText.java'),str(src/'OfferEnrichmentPolicy.java'),str(src/'PasadenaRuleGuard.java'),str(src/'PageOutcomePolicy.java'),str(src/'AcceptAttemptAudit.java'),str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.ControlWakeHarness'],check=True)
