#!/usr/bin/env python3
"""Ensure no expired alias/tombstone admission machinery can suppress live offer indexing."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
s=(src/'OcrMonitorService.java').read_text()
for old in ['relatedLossOwner(', 'isUnavailableTombstoned(', 'isUnavailableNumericTombstoned(',
            'getIndexedUnavailableRebroadcastSnapshot(', 'unavailablePromotionAliases',
            'unavailableTombstones', 'terminalLossCooldowns', 'rearmUnavailableRebroadcast(']:
 assert old not in s, 'deleted obsolete alias still present: '+old
# The current offer has its own contemporaneous text, not fields from a prior failure.
java='''package com.local.cateringscreenassistant;
public class AliasFreshPublication {
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
 String a="$139.93 16 mi (~27 mins) Tomorrow at 3:05 PM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 String b="$139.93 16 mi (~27 mins) Tomorrow at 4:05 PM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040";
 String c="$222 2 mi Tomorrow at 3:05 PM Luna Grill • 524 Spectrum Center Dr, Irvine, CA 92618";
 for(int n=0;n<100;n++){
  check(!CardText.identity(a).isEmpty(),"current offer parse remains intact "+n);
  check(!CardText.identity(b).isEmpty(),"relisted offer parse remains intact "+n);
  check(!CardText.identity(c).isEmpty(),"unrelated offer parse remains intact "+n);
  check(!CardText.sameOffer(a,c),"different merchant must not be merged "+n);
 }
 System.out.println(checks+" current-offer alias-independence checks passed");
 }}'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'AliasFreshPublication.java';p.write_text(java)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d,str(src/'CardText.java'),str(src/'OfferEnrichmentPolicy.java'),str(p)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.AliasFreshPublication'],check=True)
