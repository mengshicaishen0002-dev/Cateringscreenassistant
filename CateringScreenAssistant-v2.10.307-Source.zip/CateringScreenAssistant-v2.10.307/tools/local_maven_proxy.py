#!/usr/bin/env python3
"""Tiny build-only Maven mirror: Java talks localhost; curl performs allowed HTTPS fetches."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import mimetypes
import hashlib
import os
import subprocess
import sys
import threading
import urllib.parse
import http.client
import ssl
import shutil

ROOT = Path(os.environ.get("CSA_MAVEN_CACHE", "/tmp/csa-maven-proxy-cache"))
LOCKS = {}
LOCKS_GUARD = threading.Lock()
# The canonical Google Maven endpoint redirects to dl.google.com, which is not
# reachable in some restricted build environments. This mirror serves the same
# repository layout without that redirect.
GOOGLE = "https://dl.google.com/android/maven2/"
MAVEN = "https://repo.maven.apache.org/maven2/"
PLUGINS = "https://plugins.gradle.org/m2/"


def bases_for(relative):
    google_first = relative.startswith((
        "com/android/", "com/google/android/", "com/google/mlkit/",
        "com/google/firebase/", "androidx/"
    ))
    return (GOOGLE, MAVEN, PLUGINS) if google_first else (MAVEN, GOOGLE, PLUGINS)


def lock_for(relative):
    with LOCKS_GUARD:
        return LOCKS.setdefault(relative, threading.Lock())


FETCH_LOCAL = threading.local()

def fetch_pooled(url, target):
    # Reuse HTTPS proxy tunnels: hundreds of tiny Maven metadata requests otherwise
    # each pay a new CONNECT/TLS handshake. This is build tooling only.
    proxy = urllib.parse.urlsplit(os.environ.get("HTTPS_PROXY", ""))
    if not proxy.hostname:
        return None
    remote = urllib.parse.urlsplit(url)
    connections = getattr(FETCH_LOCAL, "connections", None)
    if connections is None:
        connections = FETCH_LOCAL.connections = {}
    key = (remote.hostname, remote.port or 443)
    conn = connections.get(key)
    try:
        if conn is None:
            conn = http.client.HTTPSConnection(proxy.hostname, proxy.port,
                    context=ssl.create_default_context(cafile=os.environ.get("CODEX_PROXY_CERT")), timeout=45)
            conn.set_tunnel(*key)
            connections[key] = conn
        conn.request("GET", remote.path)
        response = conn.getresponse()
        if response.status == 200:
            with target.open("wb") as stream:
                shutil.copyfileobj(response, stream)
            return True
        response.read()
        return False if response.status == 404 else None
    except (OSError, http.client.HTTPException):
        conn.close()
        connections.pop(key, None)
        return None


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def do_HEAD(self):
        self._serve(False)

    def do_GET(self):
        self._serve(True)

    def _serve(self, body):
        relative = urllib.parse.unquote(self.path.split("?", 1)[0]).lstrip("/")
        if not relative or ".." in relative.split("/"):
            self.send_error(400)
            return
        target = ROOT / relative
        with lock_for(relative):
            if not target.is_file():
                target.parent.mkdir(parents=True, exist_ok=True)
                checksum_source = None
                algorithm = None
                if relative.endswith(".sha1"):
                    checksum_source = ROOT / relative[:-5]
                    algorithm = "sha1"
                elif relative.endswith(".md5"):
                    checksum_source = ROOT / relative[:-4]
                    algorithm = "md5"
                if checksum_source is not None and checksum_source.is_file():
                    digest = hashlib.new(algorithm, checksum_source.read_bytes()).hexdigest()
                    target.write_text(digest, encoding="ascii")
                if target.is_file():
                    pass
                else:
                    temp = target.with_suffix(target.suffix + ".part")
                    found = False
                    for base in bases_for(relative):
                        pooled = fetch_pooled(base + relative, temp)
                        if pooled is True:
                            temp.replace(target)
                            found = True
                            break
                        if pooled is False:
                            continue
                        result = subprocess.run(
                            ["curl", "-L", "--fail", "--silent", "--show-error",
                             "--retry", "2", "--retry-delay", "1",
                             "--connect-timeout", "15", "--max-time", "180",
                             "-o", str(temp), base + relative],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        if result.returncode == 0:
                            temp.replace(target)
                            found = True
                            break
                    if not found:
                        try:
                            temp.unlink()
                        except FileNotFoundError:
                            pass
                        self.send_error(404)
                        return
        size = target.stat().st_size
        self.send_response(200)
        self.send_header("Content-Length", str(size))
        self.send_header("Content-Type", mimetypes.guess_type(target.name)[0]
                         or "application/octet-stream")
        self.end_headers()
        if body:
            with target.open("rb") as stream:
                while True:
                    chunk = stream.read(1024 * 1024)
                    if not chunk:
                        break
                    self.wfile.write(chunk)

    def log_message(self, fmt, *args):
        sys.stdout.write((fmt % args) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 18765
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
