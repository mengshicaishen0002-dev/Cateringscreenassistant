from pathlib import Path
base=Path(__file__).resolve().parents[1]/'app/src/main/java/com/local/cateringscreenassistant'
o=(base/'OcrMonitorService.java').read_text(); t=(base/'TapAccessibilityService.java').read_text()
frame=o[o.index('    private void onFrame('):o.index('    private boolean tryVisualAccessibilityFastLane(')]
visual=o[o.index('    private boolean tryVisualAccessibilityFastLane('):o.index('    private void noteVisualRetrySkip(')]
event=t[t.index('boolean emptyStructuralWake ='):t.index('boolean hasShallowText =')]
assert event.index('requestImmediateFastCheck(event.getEventTime(), true, eventReceivedAt)') < event.index('prefetchIndexedRoot(this,generation)')
assert 'if (!emptyStructuralWake)' in event
assert 'cached.uiGeneration == frameUiGeneration' in visual and 'universallyRejectedByNumbers(cached.amount, cached.miles)' in visual
assert 'if (cachedOnly || fastCheckQueued.get()) return false;' in visual
assert 'if (directFirstProbe && hotDetection != null && !hotDetection.earlyFade' in frame
assert 'terminalProbe ? null : reusableDirectDetection != null ? reusableDirectDetection' in frame
assert 'roi.recycle()' not in frame
assert 'catch (RuntimeException submissionFailure)' in frame and 'OCR_SUBMIT_FAILED' in frame
assert 'REJECT_CANONICAL=' in o and 'REJECT_OBSERVED=' in o
assert 'SPINNER_MASK_READ tx=' in o and 'mask_read_ms=' in o
assert 'SCAN_HEALTH version=' in o and 'MONITOR_STARTED version=' in o
print('11 v305 integration/source invariants passed')
