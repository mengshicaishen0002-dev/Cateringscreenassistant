#!/usr/bin/env python3
"""Prove precompiled outcome parsing retains the shipped v173 decisions and excerpts."""
from pathlib import Path
import tempfile,subprocess,shutil
root=Path(__file__).resolve().parents[1];src=root/'app/src/main/java/com/local/cateringscreenassistant'
old=(root/'tools/baseline-v173/ClaimSuccessSignals.java.txt').read_text().replace('ClaimSuccessSignals','BaselineClaimSuccessSignals')
harness=r'''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.*;
public class OutcomeParserEquivalence {
 static int count;static void eq(Object a,Object b){count++;if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 static List<Object> current(String s){return Arrays.asList(ClaimSuccessSignals.normalize(s),ClaimSuccessSignals.hasBeginDeliveryControl(s),ClaimSuccessSignals.isExactBeginDeliveryControl(s),ClaimSuccessSignals.hasAcceptedJobDetail(s),ClaimSuccessSignals.isTimeConflict(s),ClaimSuccessSignals.timeConflictHint(s),ClaimSuccessSignals.extractOutcomeHint(s),ClaimSuccessSignals.outcomeExcerpt(s),ClaimSuccessSignals.isPositive(s),ClaimSuccessSignals.isJobDetailHint(s),ClaimSuccessSignals.isTerminalNegative(s),ClaimSuccessSignals.jobsBadgeCount(s));}
 static List<Object> baseline(String s){return Arrays.asList(BaselineClaimSuccessSignals.normalize(s),BaselineClaimSuccessSignals.hasBeginDeliveryControl(s),BaselineClaimSuccessSignals.isExactBeginDeliveryControl(s),BaselineClaimSuccessSignals.hasAcceptedJobDetail(s),BaselineClaimSuccessSignals.isTimeConflict(s),BaselineClaimSuccessSignals.timeConflictHint(s),BaselineClaimSuccessSignals.extractOutcomeHint(s),BaselineClaimSuccessSignals.outcomeExcerpt(s),BaselineClaimSuccessSignals.isPositive(s),BaselineClaimSuccessSignals.isJobDetailHint(s),BaselineClaimSuccessSignals.isTerminalNegative(s),BaselineClaimSuccessSignals.jobsBadgeCount(s));}
 public static void main(String[] args)throws Exception {
 String[] examples={"This offer is no longer available.","Offer unavailable. Please contact support.","already claimed","claimed by another","someone else claimed","unable to accept","failed to accept","successfully accepted","job accepted","delivery accepted","offer accepted","assigned to you","you are assigned","something went wrong","try again","error","Begin Delivery","Begin to Delivery","Delivery Timeline MENDO_46474511540436997","Pickup Instructions Approver Name NUID GL String","Delivery Timeline Dropoff Instructions","This route conflicts with an existing job at 11:10 AM","job conflict","time conflict","no time conflicts","without scheduling conflicts","orders overlap","no conflict","Jobs: 12","Jobs","job","MENDO_46474511540436997", "$160.35 3.2 mi Tomorrow at 11:10 AM Mendocino Farms • 21107 Hawthorne Blvd Ste A, Torrance, CA 90503"};
 String[] spaces={" ","  ","\n","\r\n","\t","\u00a0"};
 for(int i=0;i<1400;i++) {
  String s=examples[i%examples.length];if(i%3==0)s=s.toUpperCase(Locale.US);
  s=s.replace(" ",spaces[(i/3)%spaces.length]);if(i%4==0)s=examples[(i+7)%examples.length]+" | "+s;
  eq(current(s),baseline(s));
 }
 for(String s:new String[]{null,""," ","\n","Conflicts without route", "Jobs: abc", "begin\u00a0delivery"})eq(current(s),baseline(s));
 ExecutorService pool=Executors.newFixedThreadPool(4);List<Future<?>> pending=new ArrayList<>();
 for(int thread=0;thread<4;thread++){final int t=thread;pending.add(pool.submit(()->{for(int i=0;i<300;i++){String s=examples[(i+t)%examples.length];if(!current(s).equals(baseline(s)))throw new AssertionError("concurrent matcher state leaked");}}));}
 for(Future<?> f:pending)f.get();pool.shutdown();count+=1200;
 System.out.println(count+" outcome parser equivalence/concurrency cases passed");
 }
}'''
with tempfile.TemporaryDirectory(prefix='csa-outcome-parser-') as tmp:
 p=Path(tmp)
 for n in ['CardText.java','ClaimSuccessSignals.java']:(p/n).write_text((src/n).read_text())
 (p/'BaselineClaimSuccessSignals.java').write_text(old);(p/'OutcomeParserEquivalence.java').write_text(harness)
 compiler=['javac'] if shutil.which('javac') else ['java','com.sun.tools.javac.Main']
 subprocess.run(compiler+['-d',tmp,*map(str,p.glob('*.java'))],check=True)
 subprocess.run(['java','-cp',tmp,'com.local.cateringscreenassistant.OutcomeParserEquivalence'],check=True)
