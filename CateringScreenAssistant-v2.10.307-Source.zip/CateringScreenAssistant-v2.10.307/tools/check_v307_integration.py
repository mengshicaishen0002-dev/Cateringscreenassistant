from pathlib import Path
b=Path(__file__).resolve().parents[1]/'app/src/main/java/com/local/cateringscreenassistant'
o=(b/'OcrMonitorService.java').read_text(); a=(b/'TapAccessibilityService.java').read_text()
# Current disabled row must be independently indexed, conclusively ineligible, and owned.
gate=o[o.index('// A current disabled control on an already-owned'):o.index('long rejectStarted=',o.index('// A current disabled control on an already-owned'))]
for x in ['!rejectedObservation.rejectEnabled','"REJECT_DISABLED"','currentDisabledOwnedReject','rejectedRoutingGeneration==TapAccessibilityService.currentUiGeneration()','REJECT_CURRENT_DISABLED_OWNED','return;']:
    assert x in gate,x
assert gate.count('rejectedRoutingGeneration==TapAccessibilityService.currentUiGeneration()')==2
helper=o[o.index('private boolean currentDisabledOwnedReject'):o.index('/** Universal numeric Reject sibling')]
for x in ['now-observed.capturedAt>48L','endpointKey','containsConflictingOfferNumbers','containsConflictingPickupEvidence','containsConflictingAddresses','acknowledgedRedraw','isCurrent(owner.id,owner.token)','now-owner.lastActionAt<=600L','sameTransaction']:
    assert x in helper,x
assert 'dispatch' not in helper and 'closeRejectConfirmation' not in helper
observe=o[o.index('private void observeRejectSpinner'):o.index('private void observeAcceptSpinner')]
for x in ['isCurrent(state.id,state.token)','spinnerTracker.observe','compareAndSet(false,true)','!confirm.postAtFrontOfQueue','state.spinnerConfirmed.set(false)','logWriter.execute','非服务器最终结果','转圈确认交接']:
    assert x in observe,x
index=a[a.index('private static FastOfferSnapshot readIndexedCurrentTopAcceptSnapshot('):a.index('private static FastOfferSnapshot boundIndexedReject(')]
assert index.index('NUMERIC_ALL_BRANCHES_REJECT')<index.index('if (!fastUniversalIndex && requireEnabled) {\n                actionEnabled=actionNodeReady')
assert 'if (fastUniversalIndex || !requireEnabled)\n                        actionEnabled = actionNodeReady' in index
assert 'deferredAcceptReadiness.recycle()' in index
assert 'numericWaitMs=' in index
print('v307 source integration checks passed (read-only disabled observation, index lifecycle, spinner acknowledgement)')
