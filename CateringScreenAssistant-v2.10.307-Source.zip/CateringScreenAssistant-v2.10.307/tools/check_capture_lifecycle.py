#!/usr/bin/env python3
"""Exercise the real capture stop callback without an Android device."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
source = (root / "app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java").read_text()
start = source.index("    private synchronized void onScreenCaptureEnded(")
end = source.index("    /** Keep both the CPU", start)
methods = source[start:end]
harness = """
public class CaptureLifecycle {
    static class MediaProjection {}
    static class SystemClock { static long uptimeMillis() { return 1000L; } }
    static class VirtualDisplay { int releases; void release() { releases++; } }
    static class ImageReader {
        int clears, closes;
        void setOnImageAvailableListener(Object listener, Object handler) {
            if (listener != null || handler != null) throw new AssertionError("listener must be cleared");
            clears++;
        }
        void close() { closes++; }
    }
    MediaProjection projection;
    VirtualDisplay virtualDisplay;
    ImageReader reader;
    boolean monitorReady = true;
    String status;
    int wakeups;
    void updateStatus(String next) { status=next; }
    void requestImmediateFastCheck(long at, boolean structural) {
        if (structural && at == 1000L) wakeups++;
    }
    static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        CaptureLifecycle service = new CaptureLifecycle();
        MediaProjection old = new MediaProjection();
        MediaProjection current = service.projection = new MediaProjection();
        VirtualDisplay display = service.virtualDisplay = new VirtualDisplay();
        ImageReader capture = service.reader = new ImageReader();
        service.onScreenCaptureEnded(old);
        check(service.projection == current && capture.closes == 0 && service.wakeups == 0,
              "stale callback must not close a newer capture grant");
        service.onScreenCaptureEnded(current);
        check(service.projection == null && service.reader == null && service.virtualDisplay == null
              && display.releases == 1 && capture.closes == 1 && capture.clears == 1,
              "capture stop closes only the capture resources");
        check(service.monitorReady && service.wakeups == 1 && service.status.contains("继续运行"),
              "capture stop must keep monitor alive and trigger Accessibility scan");
        service.onScreenCaptureEnded(current);
        check(capture.closes == 1 && service.wakeups == 1, "duplicate callback is ignored");
        System.out.println("4 production capture and scan lifecycle cases passed");
    }
""" + methods + "\n}"
with tempfile.TemporaryDirectory(prefix="csa-capture-") as directory:
    path = Path(directory) / "CaptureLifecycle.java"
    path.write_text(harness)
    subprocess.run(["java", "com.sun.tools.javac.Main", "-d", directory, str(path)], check=True)
    subprocess.run(["java", "-cp", directory, "CaptureLifecycle"], check=True)
