"""Execute actual inspector + identity binding/callback guards for the $195.36 trace."""
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1];src=r/'app/src/main/java/com/local/cateringscreenassistant';source=(src/'OcrMonitorService.java').read_text()
def block(sig):
 a=source.index(sig);i=source.index('{',a)+1;d=1
 while d:d+=(source[i]=='{')-(source[i]=='}');i+=1
 return source[a:i]
methods='\n'.join(block(x) for x in ['    private boolean verifiedAcceptRetryMatches(', '    private String acceptRetryDecisionText(', '    private boolean acceptCallbackCurrent(', '    private void inspectClaim(String originalText, long epoch, int disabledChecks'])
head='''package com.local.cateringscreenassistant;
import java.util.*;import java.util.concurrent.atomic.*;import java.util.function.*;
class SparseHarness {boolean preserveVisibleAcceptLoading(long at,PageOutcomePolicy.Tracker t,long now){return false;}String acceptLoadingRetryBlock(long owner){return "";}void scheduleAcceptPageProbe(long owner){}boolean resumeAcceptPressure(long owner,long epoch,long at,TapAccessibilityService.FastOfferSnapshot current){return false;}void pauseAcceptPressureForContext(long at,String reason,long time){}void releaseAcceptAdmission(){acceptAdmissionBusy.set(false);}boolean pressureBudgetObserving(String id,long now){return false;}boolean acceptPressureActive(long at){return false;}
 static final String SPARSE="$195.36 Est. 0.3 mi (~2 mins)", FULL=SPARSE+" Tomorrow at 11:35 AM Mendocino Farms • 631 Wilshire Blvd, Santa Monica, CA 90401";
 static class SystemClock{static long now=1240;static long elapsedRealtime(){return now;}}
 static class Rect{boolean isEmpty(){return false;}}
 static class TapAccessibilityService {
  static class FastOfferSnapshot {String text;long capturedAt=1240;boolean acceptEnabled=true;Rect acceptBounds=new Rect();FastOfferSnapshot(String t){text=t;}}
  static FastOfferSnapshot live=new FastOfferSnapshot(FULL);
  static FastOfferSnapshot pageLive;static FastOfferSnapshot takeAcceptPageRetrySnapshot(String text,long at){FastOfferSnapshot s=pageLive;pageLive=null;return s;}
  static Runnable indexHook;static int controlReads;static FastOfferSnapshot observeCurrentTopAcceptSnapshot(){controlReads++;if(indexHook!=null){Runnable hook=indexHook;indexHook=null;hook.run();}return live;}
  static FastOfferSnapshot ownedLive;static FastOfferSnapshot observeCurrentOwnedAcceptSnapshot(String text,long owner){return ownedLive;}
  static String currentAcceptObservationReason(){return "TEST_INDEX_MISSING";}
  static boolean recentAcceptedJobDetailMatches(String t,long at){return false;}static boolean jobsBadgeIncreasedSince(int b){return false;}
  static boolean isTerminalNegativeClaimOutcome(String t){return !t.isEmpty();}static PageGuard.Page recentPageHint(){return PageGuard.Page.OFFERS;}
  static String recentClaimOutcomeSince(long t){return "";}
 }
 enum SerialAction{NONE,ACCEPT}SerialAction serialTopAction=SerialAction.ACCEPT;
 boolean monitorReady=true,visualRetryNeeded;AtomicLong claimEpoch=new AtomicLong(1),scanGeneration=new AtomicLong(1);
 AtomicBoolean acceptAdmissionBusy=new AtomicBoolean();String serialTopText=SPARSE,acceptRetryEnrichedText="",negative="";
 long acceptPageReadOwner=1000;long acceptControlEnabledActionAt,acceptControlEnabledAt,acceptPageReadActiveAt;long acceptDispatchObservationAt;long serialTopActionAt=1000,acceptRetryDispatchPendingAt,acceptGestureCompletedAt=1020,acceptProcessingConfirmedAt;
 int pendingAcceptJobsBaseline,acceptProcessingQuietChecks;
 long cooldownUntil,accessibilityActionHoldUntil,lastReadableFastScan,lastScan,terminalLossUntil;
 String terminalLossIdentity="";long pendingAcceptMissingSince,pendingAcceptTerminalProbeAt,acceptPageProbeStartedAt;
 static final long ACCEPT_TERMINAL_DEEP_PROBE_AFTER_MS=320,ACCEPT_TERMINAL_DEEP_PROBE_GAP_MS=360,ACCEPT_TERMINAL_TRACK_WINDOW_MS=1100,ACCEPT_TERMINAL_TRACK_POLL_MS=50;
 static final long ACCEPT_PAGE_READ_HEAD_START_MS=12L;
 AtomicBoolean acceptPageProbeQueued=new AtomicBoolean();
 PageOutcomePolicy.Tracker tracker;ClaimBudget claimBudget=new ClaimBudget();
 List<Runnable> queued=new ArrayList<>();List<String> logs=new ArrayList<>();int sends,attempt,losses,successes;
 class Handler{void postDelayed(Runnable r,long ms){queued.add(r);}}Handler fastWorker=new Handler();
 PageOutcomePolicy.Tracker pageTracker(long a){return a==serialTopActionAt?tracker:null;}
 Consumer<String> acceptReporter(String text){return logs::add;}Consumer<String> offerReporter(String text){return logs::add;}boolean wasRecentlyCompleted(String t){throw new AssertionError("callback consulted historical completion");}
 void cancelUndispatchedAccept(String t,String reason){throw new AssertionError(reason);}
 boolean acceptGestureDispatchedForCurrentTransaction(){return true;}
 String acceptScopedTerminalOutcomeSince(long t){return negative;}String acceptScopedOutcomeSince(long t){return negative;}
 boolean isBoundPositiveClaimOutcome(String text,String hint,long at){return false;}
 void confirmPendingClaimSuccess(String t,String e){successes++;}
 void finishPendingClaimLoss(String t,String e,boolean terminal){losses++;}
 void markTerminalLoss(String id,long now){}String fastRuleFailure(String t){return "";}
 String acceptResultTiming(String t,String e,long n){return "";}
 void awaitClaimProcessingOutcome(String t,long e,int m,long n,boolean f){}
 boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot current,long epoch){
  if(!verifiedAcceptRetryMatches(current.text)&&!OfferEnrichmentPolicy.sameTransaction(serialTopText,current.text))throw new AssertionError("rich retry must remain original transaction");
  attempt=claimBudget.reserve(CardText.identity(current.text),current.text,SystemClock.now);if(attempt>0){sends++;acceptRetryDispatchPendingAt=SystemClock.now;}return attempt>0;
 }
 void inspectClaim(String t,long e){inspectClaim(t,e,0,0);}
 void scheduleClaimInspection(String t,long e,int d,int m,long delay){queued.add(()->inspectClaim(t,e,d,m));}
 static int checks;static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static SparseHarness setup(boolean proof){TapAccessibilityService.indexHook=null;TapAccessibilityService.pageLive=null;SystemClock.now=1240;TapAccessibilityService.live=new TapAccessibilityService.FastOfferSnapshot(FULL);SparseHarness h=new SparseHarness();h.claimBudget.reserve(CardText.identity(SPARSE),SPARSE,1000);
 h.tracker=new PageOutcomePolicy.Tracker(1000,SPARSE,null,false);
 if(proof){h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,true,false,"",FULL,"OK",7,26,"","ENABLED"),1110);h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","ENABLED"),1230);}return h;}
'''
tests='''public static void main(String[] args){
 SparseHarness h=setup(false);h.inspectClaim(SPARSE,1);check(h.sends==0,"v169 sparse/rich mismatch reproduced without verified identity");
 h=setup(true);h.inspectClaim(SPARSE,1);check(h.sends==1&&h.attempt==2,"actual inspector retries trace as attempt2 after two proofs");
 h=setup(true);h.acceptPageReadActiveAt=1235;
 h.inspectClaim(SPARSE,1);check(h.sends==0&&!h.queued.isEmpty(),"background read retains its head start without a recovered control");
 h=setup(true);h.acceptPageReadActiveAt=1235;h.acceptControlEnabledAt=1238;h.acceptControlEnabledActionAt=1000;
 h.inspectClaim(SPARSE,1);check(h.sends==1&&h.attempt==2,"recovered control can reach final live proof without waiting for background read");
 h=setup(true);h.inspectClaim(SPARSE,1);
 check(h.serialTopText.equals(SPARSE)&&h.serialTopActionAt==1000&&h.claimEpoch.get()==1,"first transaction anchors remain immutable");
 check(h.acceptCallbackCurrent(1,1,FULL),"rich retry callback belongs to original sparse transaction without consulting completion history");
 check(!h.acceptCallbackCurrent(2,1,FULL)&&!h.acceptCallbackCurrent(1,2,FULL),"stale epoch callback blocked");
 check(h.logs.stream().filter(x->x.startsWith("ACCEPT_RETRY_IDENTITY_BOUND")).count()==1,"identity adoption logged once");
 h.inspectClaim(SPARSE,1);check(h.sends==1,"parallel inspector wake cannot duplicate inflight retry");
 h=setup(true);h.negative="offer unavailable";h.inspectClaim(SPARSE,1);check(h.sends==0&&h.losses==1,"terminal failure precedes identity/retry work");
 h=setup(true);TapAccessibilityService.live.text=FULL.replace("631","632");h.inspectClaim(SPARSE,1);check(h.sends==0,"different live address never reuses bound retry identity");
 h=setup(true);TapAccessibilityService.live.acceptEnabled=false;h.inspectClaim(SPARSE,1);check(h.sends==0&&h.acceptProcessingConfirmedAt==1240,"disabled button remains processing wait");
 h=setup(true);h.acceptAdmissionBusy.set(true);h.inspectClaim(SPARSE,1);check(h.sends==0&&!h.queued.isEmpty(),"visual lane admission lock prevents competing retry");
 h=setup(true);h.claimBudget.reserve(CardText.identity(SPARSE),SPARSE,1120);h.claimBudget.reserve(CardText.identity(SPARSE),SPARSE,1140);h.claimBudget.enableContinuous(CardText.identity(SPARSE),1140);h.inspectClaim(SPARSE,1);check(h.sends==1&&h.attempt==4&&h.losses==0,"continuous monitored owner remains retryable after three sends and enrichment");
 h=setup(true);h.serialTopAction=SerialAction.NONE;check(h.acceptRetryDecisionText(SPARSE).equals(SPARSE),"released transaction cannot enrich/retry");
 h=setup(true);check(h.acceptRetryDecisionText(FULL.replace("195.36","196.36")).contains("196.36"),"foreign inspector cannot borrow active identity");
 h=setup(false);h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,true,false,"",FULL,"OK",7,26,"","ENABLED"),1110);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1230);
 h.inspectClaim(SPARSE,1);check(h.sends==1&&h.attempt==2,"single enabled export plus second clean identity can reach fresh live enabled retry");
 h=setup(false);h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,true,false,"",FULL,"OK",7,26,"","ENABLED"),1110);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1230);
 TapAccessibilityService.live.acceptEnabled=false;h.inspectClaim(SPARSE,1);check(h.sends==0,"fresh disabled live control vetoes bridge retry");
 h=setup(false);h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,true,false,"",FULL,"OK",7,26,"","ENABLED"),1110);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1230);
 TapAccessibilityService.live=null;h.inspectClaim(SPARSE,1);check(h.sends==0,"missing live control cannot reuse historical coordinates");
 h=setup(false);h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1110);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1230);
 h.inspectClaim(SPARSE,1);check(h.sends==1&&h.attempt==2,"two full clean identities reach current enabled control even with no page-button export");
 h=setup(false);h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1110);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1230);
 TapAccessibilityService.live.acceptEnabled=false;h.inspectClaim(SPARSE,1);check(h.sends==0,"no historical enabled export can override disabled live control");
 h=setup(false);h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1110);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1230);
 TapAccessibilityService.live=null;h.inspectClaim(SPARSE,1);check(h.sends==0,"identity-only wake cannot click missing live control");
 h=setup(false);h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","NOT_EXPORTED"),1230);
 int reads=TapAccessibilityService.controlReads;h.inspectClaim(SPARSE,1);
 check(TapAccessibilityService.controlReads==reads&&h.visualRetryNeeded&&!h.queued.isEmpty(),"fresh missing page sample defers duplicate index but retains blue-button fallback");
 SystemClock.now=1350;h.inspectClaim(SPARSE,1);
 check(TapAccessibilityService.controlReads==reads+1,"expired page sample restores independent live index");
 h=setup(false);h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","DISABLED"),1230);
 reads=TapAccessibilityService.controlReads;h.negative="offer unavailable";h.inspectClaim(SPARSE,1);
 check(h.losses==1&&TapAccessibilityService.controlReads==reads,"terminal event precedes all coalescing and reads");
 h=setup(true);TapAccessibilityService.pageLive=new TapAccessibilityService.FastOfferSnapshot(FULL);
 reads=TapAccessibilityService.controlReads;h.inspectClaim(SPARSE,1);
 check(h.sends==1&&TapAccessibilityService.controlReads==reads,"fresh page/control receipt skips repeated inspector index and keeps shared attempt2 budget");
 h=setup(false);h.acceptDispatchObservationAt=1000;h.acceptPageProbeQueued.set(true);SystemClock.now=1011;
 reads=TapAccessibilityService.controlReads;h.inspectClaim(SPARSE,1);
 check(TapAccessibilityService.controlReads==reads&&!h.queued.isEmpty(),"initial in-flight sampler keeps fast queue free for its receipt");
 SystemClock.now=1012;h.inspectClaim(SPARSE,1);
 check(TapAccessibilityService.controlReads==reads+1,"initial sampler yield is bounded at12ms");
 h=setup(false);final SparseHarness racing=h;TapAccessibilityService.live=null;
 TapAccessibilityService.indexHook=()->{racing.tracker.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,true,false,"",FULL,"OK",7,26,"","ENABLED"),1110);racing.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","ENABLED"),1230);TapAccessibilityService.pageLive=new TapAccessibilityService.FastOfferSnapshot(FULL);};
 h.inspectClaim(SPARSE,1);check(h.sends==1&&h.attempt==2,"proof published during slow stale index is consumed before waiting for another inspection");
 check(h.logs.stream().anyMatch(x->x.startsWith("ACCEPT_PAGE_RETRY_REUSED")),"receipt handoff has explicit evidence in transaction log");

 h=setup(false);h.serialTopText=FULL;h.claimBudget=new ClaimBudget();h.claimBudget.reserve(CardText.identity(FULL),FULL,1000);
 h.tracker=new PageOutcomePolicy.Tracker(1000,FULL,null,false);
 h.tracker.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"",FULL,"OK",7,26,"","DISABLED"),1230);
 h.acceptControlEnabledActionAt=1000;h.acceptControlEnabledAt=1239;reads=TapAccessibilityService.controlReads;
 h.inspectClaim(FULL,1);
 check(TapAccessibilityService.controlReads==reads+1,"fresh recovered control bypasses old disabled-page scheduling suppression");
 check(h.sends==1,"fresh enabled control can reach final verification without a settle delay");
 h=setup(false);h.serialTopText=FULL;h.claimBudget=new ClaimBudget();h.claimBudget.reserve(CardText.identity(FULL),FULL,1000);h.tracker=new PageOutcomePolicy.Tracker(1000,FULL,null,false);
 h.inspectClaim(FULL,1);
 check(h.sends==1&&h.attempt==2,"unchanged complete current identity permits early second attempt before450ms");
 h=setup(false);h.serialTopText=FULL;h.claimBudget=new ClaimBudget();h.claimBudget.reserve(CardText.identity(FULL),FULL,1000);h.tracker=new PageOutcomePolicy.Tracker(1000,FULL,null,false);
 h.acceptGestureCompletedAt=0;h.inspectClaim(FULL,1);
 check(h.sends==0,"enabled proof cannot overlap an unfinished gesture");
 h.acceptGestureCompletedAt=1240;h.inspectClaim(FULL,1);
 check(h.sends==1,"enabled proof may send immediately on callback");
 h=setup(false);h.acceptPageReadActiveAt=1200;SystemClock.now=1211;reads=TapAccessibilityService.controlReads;h.inspectClaim(SPARSE,1);
 check(TapAccessibilityService.controlReads==reads&&!h.queued.isEmpty(),"running page read prevents overlapping independent index");
 SystemClock.now=1212;h.inspectClaim(SPARSE,1);
 check(TapAccessibilityService.controlReads==reads+1,"page-read yield is bounded at12ms");
 h=setup(false);h.serialTopText=FULL;h.claimBudget=new ClaimBudget();h.claimBudget.reserve(CardText.identity(FULL),FULL,1000);h.tracker=new PageOutcomePolicy.Tracker(1000,FULL,null,false);
 TapAccessibilityService.pageLive=new TapAccessibilityService.FastOfferSnapshot(FULL);reads=TapAccessibilityService.controlReads;h.inspectClaim(FULL,1);
 check(h.sends==1&&TapAccessibilityService.controlReads==reads,"complete page receipt reused without waiting for enrichment history or extra index");
 h=setup(false);String routeOnly=FULL.replace("Tomorrow at 11:35 AM","");h.serialTopText=routeOnly;h.claimBudget=new ClaimBudget();h.claimBudget.reserve(CardText.identity(routeOnly),routeOnly,1000);h.tracker=new PageOutcomePolicy.Tracker(1000,routeOnly,null,false);
 TapAccessibilityService.pageLive=new TapAccessibilityService.FastOfferSnapshot(FULL);reads=TapAccessibilityService.controlReads;h.inspectClaim(routeOnly,1);
 check(h.sends==1&&h.attempt==2&&TapAccessibilityService.controlReads==reads,"known route plus current pickup enrichment reuses original budget without extra index or450ms wait");
 h=setup(false);h.serialTopText=FULL;h.claimBudget=new ClaimBudget();h.claimBudget.reserve(CardText.identity(FULL),FULL,1000);h.tracker=new PageOutcomePolicy.Tracker(1000,FULL,null,false);
 TapAccessibilityService.live=new TapAccessibilityService.FastOfferSnapshot("$19 4.8 mi Urbane Cafe • 4001 N Lakewood Blvd, Long Beach, CA 90846");
 TapAccessibilityService.ownedLive=new TapAccessibilityService.FastOfferSnapshot(FULL);h.inspectClaim(FULL,1);
 check(h.sends==1&&h.losses==0&&h.serialTopActionAt==1000,"inserted nonqualifying top cannot retire the active offer located in row two");
 h=setup(false);h.serialTopText=FULL;h.claimBudget=new ClaimBudget();h.claimBudget.reserve(CardText.identity(FULL),FULL,1000);h.tracker=new PageOutcomePolicy.Tracker(1000,FULL,null,false);
 TapAccessibilityService.live=new TapAccessibilityService.FastOfferSnapshot("$19 4.8 mi Urbane Cafe • 4001 N Lakewood Blvd, Long Beach, CA 90846");
 TapAccessibilityService.ownedLive=new TapAccessibilityService.FastOfferSnapshot(FULL);TapAccessibilityService.ownedLive.acceptEnabled=false;h.inspectClaim(FULL,1);
 check(h.sends==0&&h.losses==0&&!h.queued.isEmpty(),"disabled owned lower row stays in processing observation without clicking inserted top");
 TapAccessibilityService.ownedLive=null;
 System.out.println(checks+" production sparse-first inspector/alias/ownership cases passed");}}
'''
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'SparseHarness.java';f.write_text(head+methods+tests)
 subprocess.run(['java','com.sun.tools.javac.Main','-d',d]+[str(src/n) for n in ['CardText.java','OfferEnrichmentPolicy.java','PageOutcomePolicy.java','ClaimBudget.java','ActionDispatchPolicy.java','ClaimConfirmation.java','PageGuard.java']]+[str(f)],check=True)
 subprocess.run(['java','-cp',d,'com.local.cateringscreenassistant.SparseHarness'],check=True)
