#!/usr/bin/env python3
"""Execute the production gesture builder and callback routing with Android surface doubles."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
src = root / "app/src/main/java/com/local/cateringscreenassistant"
source = (src / "TapAccessibilityService.java").read_text()

def block(signature):
    start = source.index(signature)
    begin = source.index("{", start)
    end, depth = begin + 1, 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end]

head = r'''
package com.local.cateringscreenassistant;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.*;
class SystemClock { static long elapsedRealtime(){return 1000;} }
class Rect {
 int left=560,top=1000,right=960,bottom=1100;
 Rect(){} Rect(int l,int t,int r,int b){left=l;top=t;right=r;bottom=b;}
 boolean isEmpty(){return right<=left||bottom<=top;}
 int width(){return right-left;}int height(){return bottom-top;}
 boolean contains(int x,int y){return x>=left&&x<right&&y>=top&&y<bottom;}
}
class Path {float x,y;void moveTo(float x,float y){this.x=x;this.y=y;}}
class Handler { final String lane;Handler(String name){lane=name;} }
class GestureDescription {
 final long duration;final int strokes;final java.util.List<StrokeDescription> plan;GestureDescription(long ms,int n,java.util.List<StrokeDescription> p){duration=ms;strokes=n;plan=p;}
 int getStrokeCount(){return strokes;}
 static class StrokeDescription {final long duration,end,start;final float x,y;StrokeDescription(Path p,long start,long ms){duration=ms;this.start=start;end=start+ms;x=p.x;y=p.y;}}
 static class Builder {
  long duration;int strokes;java.util.List<StrokeDescription> plan=new java.util.ArrayList<>();Builder addStroke(StrokeDescription stroke){duration=Math.max(duration,stroke.end);strokes++;plan.add(stroke);return this;}
  GestureDescription build(){return new GestureDescription(duration,strokes,plan);}
 }
}
class OcrMonitorService {
 static String loading="";static String acceptLoadingRetryBlock(long owner){return loading;}static long pendingClaimSince(){return 1000;}static void noteAcceptCallbackEntry(long owner,long call,long ack,long at,boolean cancelled){}static Handler clicks=new Handler("clicks");static Handler acceptCallbackHandler(){return clicks;}
 static boolean monitoring=true,success;static int mode;
 static int acceptFirstGestureMode(){return mode;}static int began,dispatched;
 static void noteAcceptGesturePlan(long owner,long call,long ack,String plan){}
 static boolean isMonitoring(){return monitoring;}
 static boolean hasBoundAcceptSuccess(){return success;}
 static void noteAcceptGestureDispatchStarted(){began++;}
 static void noteAcceptGestureDispatched(){dispatched++;}
}
public class TapAccessibilityService {
 Handler main=new Handler("main"),directWorker=new Handler("direct");
 GestureDescription last;Handler callbackLane;GestureResultCallback callback;int sends;
 boolean accepted=true;
 static class GestureResultCallback {
  public void onCompleted(GestureDescription g){} public void onCancelled(GestureDescription g){}
 }
 boolean dispatchGesture(GestureDescription g,GestureResultCallback cb,Handler lane){
  last=g;callback=cb;callbackLane=lane;sends++;return accepted;
 }
 static void bindPressureGeometry(Rect b,Rect r){}
 static boolean safeActionBounds(Rect root,Rect b,boolean accept){return !b.isEmpty();}
 static String rectString(Rect b){return "bounds";}
'''
signatures = [
    "    private static void dispatchVerifiedSnapshotGesture(TapAccessibilityService service, Rect bounds,",
    "    private static void dispatchVerifiedSnapshotGesture(TapAccessibilityService service,Rect bounds,",
]
signatures += ["    private static GestureDescription buildSingleTap(",
    "    private static boolean dispatchVerifiedSnapshotGesture(TapAccessibilityService service, Rect bounds,\n            Rect rootBounds"]
tests = r'''
 static int checks;static String detail="",failure="";
 static void check(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
 public static void main(String[] args){
  Rect button=new Rect(),window=new Rect(0,0,1080,2400);
  TapAccessibilityService s=new TapAccessibilityService();
  dispatchVerifiedSnapshotGesture(s,button,window,true,ActionDispatchPolicy.firstGestureDurationMs(true),0,true,
      value->detail=value,value->failure=value,()->true);
  check(s.sends==1&&s.last.duration==12&&s.last.strokes==1,"first dispatch carries one 12ms tap");
  check(s.callbackLane==OcrMonitorService.clicks,"monitored Accept callback bypasses UI event queue");
  check(OcrMonitorService.dispatched==1&&detail.isEmpty(),"dispatch ack is separate from gesture completion");
  s.callback.onCompleted(s.last);check(detail.contains("Gesture12ms")&&detail.contains("SINGLE_12"),"completion records actual planned stroke");
  dispatchVerifiedSnapshotGesture(s,button,window,true,ActionDispatchPolicy.retryGestureDurationMs(2),0,
      value->detail=value,value->failure=value,()->true);
  check(s.sends==2&&s.last.duration==12&&s.last.strokes==1,"verified second gesture also12ms");
  s.callback.onCompleted(s.last);
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,
      value->detail=value,value->failure=value,()->true);
  check(s.sends==3&&s.last.duration==12&&s.last.strokes==1,"third independent dispatch carries one tap");
  s.callback.onCompleted(s.last);
  check(detail.contains("CALL_ELAPSED=")&&detail.contains("DISPATCH_ELAPSED=")&&detail.contains("CALLBACK_ELAPSED="),"per-tap actual send and completion anchors are separate");
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,
      value->detail=value,value->failure=value,()->false);
  check(s.sends==3&&failure.contains("ACCEPT_FINAL_LIVE_GATE_STOPPED"),"true live stop still blocks final tap");
  OcrMonitorService.loading="RETRY_SPINNER_CANDIDATE";
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,value->detail=value,value->failure=value);
  check(s.sends==3&&failure.equals("RETRY_SPINNER_CANDIDATE"),"first loading frame blocks the final gesture");
  OcrMonitorService.loading="RETRY_SPINNER_CONFIRMED";
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,value->detail=value,value->failure=value);
  check(s.sends==3&&failure.equals("RETRY_SPINNER_CONFIRMED"),"confirmed loading keeps the gesture blocked");
  OcrMonitorService.loading="";
  OcrMonitorService.success=true;
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,value->detail=value,value->failure=value);
  check(s.sends==3,"observed success blocks another gesture");
  OcrMonitorService.success=false;
  dispatchVerifiedSnapshotGesture(s,button,window,false,ActionDispatchPolicy.firstGestureDurationMs(false),0,
      value->detail=value,value->failure=value);
  check(s.last.duration==55&&s.callbackLane==s.main,"Reject stroke and callback routing remain compatible");
  OcrMonitorService.clicks=null;
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,value->detail=value,value->failure=value);
  check(s.callbackLane==s.main,"unavailable worker has a valid callback handler");
  OcrMonitorService.monitoring=false;OcrMonitorService.clicks=new Handler("clicks");
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,value->detail=value,value->failure=value);
  check(s.callbackLane==s.main,"standalone workflow keeps existing callback lane");
  OcrMonitorService.monitoring=true;OcrMonitorService.mode=ActionDispatchPolicy.SEQUENTIAL;
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,true,value->detail=value,value->failure=value,()->true);
  check(s.last.duration==38&&s.last.strokes==3&&s.last.plan.get(0).start==0&&s.last.plan.get(1).start==13&&s.last.plan.get(2).start==26,"sequential first burst queues three non-overlapping DOWN/UP strokes once");
  s.callback.onCompleted(s.last);check(detail.contains("strokes=3"),"logged stroke count matches the dispatched batch");
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,value->detail=value,value->failure=value);
  check(s.last.duration==12&&s.last.strokes==1,"later verified retry is still a single stroke");
  check(ActionDispatchPolicy.initialOutcomeReadDelayMs(true,1000,1020)==280&&ActionDispatchPolicy.initialOutcomeReadDelayMs(false,1000,1020)==0&&ActionDispatchPolicy.initialOutcomeReadDelayMs(true,1000,1300)==0,"bounded outcome read head start only while pressure active");
  for(int legacy:new int[]{0,1,3,-1,99}){
   OcrMonitorService.mode=ActionDispatchPolicy.gestureMode(legacy);
   dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,true,value->detail=value,value->failure=value,()->true);
   check(s.last.duration==12&&s.last.strokes==1,"retired or single stored mode uses one physical 12ms tap");
   s.callback.onCompleted(s.last);check(detail.contains("SINGLE_12"),"unified single mode logged");
  }
  check(ActionDispatchPolicy.gestureSelection(2)==1&&ActionDispatchPolicy.gestureSelection(1)==0&&ActionDispatchPolicy.gestureSelection(3)==0,"stored mode migrates correctly to two-option selector");
  check(ActionDispatchPolicy.gestureModeForSelection(0)==0&&ActionDispatchPolicy.gestureModeForSelection(1)==2,"two-option selector preserves persisted IDs");
  check(ActionDispatchPolicy.firstStrokeMs(0)==12&&ActionDispatchPolicy.firstStrokeMs(2)==12,"both modes use 12ms strokes");
  OcrMonitorService.mode=ActionDispatchPolicy.SEQUENTIAL;OcrMonitorService.loading="RETRY_SPINNER_CANDIDATE";
  int before=s.sends;
  dispatchVerifiedSnapshotGesture(s,button,window,true,12,0,true,value->detail=value,value->failure=value,()->true);
  check(s.sends==before,"spinner blocks a new three-tap batch");
  OcrMonitorService.loading="";
  System.out.println(checks+" production short-gesture/final-proof/callback routing cases passed");
 }}
'''
with tempfile.TemporaryDirectory(prefix="csa-fast-gesture-") as directory:
    harness = Path(directory) / "TapAccessibilityService.java"
    harness.write_text(head + "\n".join(block(signature) for signature in signatures) + tests)
    subprocess.run(["java", "com.sun.tools.javac.Main", "-d", directory,
                    str(src / "ActionDispatchPolicy.java"), str(harness)], check=True)
    subprocess.run(["java", "-cp", directory,
                    "com.local.cateringscreenassistant.TapAccessibilityService"], check=True)
