CateringScreenAssistant v2.10.299 full source ZIP. Based on v2.10.297.
Adds Accept-first preemption of pending Reject when a NEW qualifying top appears; keeps original Reject and repeated-publication handling.
Old queued Reject callbacks/gestures are fenced by the original transaction epoch, preserving first Reject direct ACTION_CLICK.
Does not include keystore; build using existing private GitHub secret and workflow. Android release APK not yet compiled by this package.
