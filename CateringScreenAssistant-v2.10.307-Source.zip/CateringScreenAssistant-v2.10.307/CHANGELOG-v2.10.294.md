# v2.10.294 — Jobs 空页自动返回 Offers 恢复

## 现场证据
2026-11-23 21:33 用户照片：DeliverThat 在 Deliveries 的 Jobs 标签（深色已选），显示 “You don't have any jobs.”，但自动监控未返回 Offers。此处必须区别于 Offers 空页以及真实已接订单详情。

## 修复范围
1. 延续 v2.10.293 的“无单只做低成本存在性探测”，但将 Jobs/ Ignored 的明确空页文案分类为 `JOBS_EMPTY` / `IGNORED_EMPTY`，不再吞掉其它标签证据。
2. Accessibility 当前事件直接识别 `You don't have any jobs.`（兼容英文弯引号），仅发出紧急唤醒和页面提示，不执行未经确认的点击。
3. 闲置探测读取到同一代的明确 Jobs 空页时通知快速扫描线程；扫描前的 `recoverOffersPage` 将复核当前 DeliverThat 前台、Deliveries/Jobs/Offers 入口和已选 Jobs 标签，只尝试点击 Offers。正在执行接单、接单成功隔离、详情/Begin Delivery 或人工介入时，原有安全守卫保持有效。
4. 首击金额/里程/Accept 节点索引、12ms 监控心跳、Accept Spinner 补击、Reject 转圈规则不作调整。

## 接单成功后自动返回
通过直接对比 v2.10.292、v2.10.293 与本版源文件，`confirmPendingClaimSuccess`、`scheduleReturnToOffersAfterClaim`、`scheduleFindOffersAfterClaim`、`completePostClaimReturnIfVisible`、`clickPostClaimBack`、`clickOffersNavigation` 等接单成功导航代码未改动。现有流程仍为：证实成功 → 详情页 Back → Offers 点击 → 页面确认；十秒导航看门狗及正常重试保持。

## 验证范围和限制
已通过 996 项首击索引回归、128 项页面守卫、页面事件路由 31 项、36 项前台导航检查、8 项导航目标、12 项成功隔离、1085 项视觉等价，以及其他生产方法回归；源代码未经 Android SDK/Gradle 构建为 APK，必须通过 GitHub Actions 实际编译并实机检查 Jobs→Offers 和接单成功→Offers。
