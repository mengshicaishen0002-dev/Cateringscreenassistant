# v2.10.295 — Jobs 有单 / 无单自动返回 Offers

基线：v2.10.294；`versionCode=321`、`versionName=2.10.295`。

## 修复范围

- v294 只把 Jobs 空列表文案 `You don't have any jobs.` 作为导航信号。有已分配 Jobs 的列表不包含该文案，因此仍可能停在 Jobs。本版将存在性探测扩为 `JOBS_LIST`、`IGNORED_LIST`，与 `JOBS_EMPTY`/`IGNORED_EMPTY` 共用自动返回链路。
- 空闲探测增加一次 `Jobs` 文字索引（共 4 个宽查询），**只运行于独立低优先级空闲探测线程，不进入金额/里程/按钮/Accept 热路径**。即使 Jobs 列表含价格与距离，也不能误判为 Offers 的新订单；只有同时有当前 Offers 金额+里程+动作证明时才维持有单判定，避免 RN 选中状态残留。
- 真实 `TYPE_VIEW_CLICKED` 的 Jobs 或 Ignored 标签事件只记录有时限的唤醒提示；不直接发起点击。返回前重新读当前 DeliverThat 前台窗口、Deliveries/Jobs/Offers 标签、导航几何、当前实际选择或有效近期点击证据，且拒绝已明确选中的 Offers 页面。非活动窗口、过期证据、配送详情页缺少完整导航栏时禁止导航。
- Jobs 列表可能出现价格、配送说明或 Begin Delivery 标签；仅凭这些字符串不应将**Jobs 列表**当成**订单详情**并阻断返回。直接从已确认 Jobs 列表点击 Offers，无需点 Jobs 中的任何订单。
- Ignored 标签可能是无文字的眼睛图标；保留其经当前页面证实的恢复通道，不回退 v294 的已有能力。
- 继续保留 3 秒人工触摸保护、接单进行中的事务隔离和已接单成功后的“详情 Back→Offers→确认页面”专用流程；不会把普通 Jobs 页面恢复和成功接单流程混在一起。

## 不变项与验证边界

金额/里程/按钮快速索引、Accept 第一次点击、转圈确认/补击、Reject 转圈与确认、12ms 心跳和城市规则未修改。通过 Java 单元、Jobs 页面专项、996 首次索引、页面恢复、Accept commit / foreground / event routing / live scan continuity 等源码回归。Android APK 尚未在这里编译，实机速度与返回动作必须由 GitHub Actions + 手机日志验证。
