# v2.10.304 生成签名 APK

1. 将 `CateringScreenAssistant-v2.10.304-Source.zip` 上传 Google Drive，设置允许通过链接下载，复制**刚上传 302 ZIP 的新链接**。
2. 把随包交付的 `GitHub-build-apk-from-Drive-v304.yml` 全文覆盖 GitHub 仓库 `.github/workflows/build-apk.yml`。
3. 这次不会自动 Push 构建。到 Actions > Build signed CSA APK v2.10.304 > Run workflow，粘贴 `source_url` 为步骤1的**完整链接**，运行。
4. 工作流下载 ZIP 后会以 SHA256 和版本校验，确保下载的是 302 而非 296/299。校验失败只说明下载错误，并非 APK 编译失败。
5. 运行全部回归和 Gradle assembleRelease 后，下载 `CateringScreenAssistant-v2.10.304-Signed-APK` Artifact，解压 APK 后再安装。

速度优先设置有错单风险。Spinner 表示请求被客户端处理，最终成功必须有服务端/Jobs 证据。
