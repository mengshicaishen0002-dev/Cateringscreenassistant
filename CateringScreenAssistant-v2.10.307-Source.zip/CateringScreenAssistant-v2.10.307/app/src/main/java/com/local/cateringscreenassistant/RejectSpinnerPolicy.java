package com.local.cateringscreenassistant;

/**
 * Spinner-only Reject acknowledgement. Never infer success from a gray/disabled button.
 * Unlike Accept's blue-button detector, the Reject control may use neutral backgrounds.
 * A rotating arc on successive frames is required; one static icon is not confirmation.
 */
final class RejectSpinnerPolicy {
    interface Pixels { int color(int x, int y); }
    private static final int[] RADII = {19, 26, 33, 40};
    private static final double[] COS = new double[16], SIN = new double[16];
    static {
        for (int i=0;i<16;i++) {
            double a=i*Math.PI/8;
            COS[i]=Math.cos(a);SIN[i]=Math.sin(a);
        }
    }
    private static int contrast(int a,int b) {
        return Math.max(Math.abs((a>>16&255)-(b>>16&255)),
                Math.max(Math.abs((a>>8&255)-(b>>8&255)),
                        Math.abs((a&255)-(b&255))));
    }
    static int arcMask(int left,int top,int right,int bottom,Pixels pixels) {
        int w=right-left,h=bottom-top;
        if(w<40 || h<24) return 0;
        int cx=(left+right)/2,cy=(top+bottom)/2;
        int background=pixels.color(cx,cy);
        for (int dx=-2;dx<=2;dx+=2) for(int dy=-2;dy<=2;dy+=2)
            if (contrast(background,pixels.color(cx+dx,cy+dy))>38) return 0;
        // The spinner is inside the control; normal letter/text rows cause side contamination.
        for(int side=-1;side<=1;side+=2) for(int dy=-2;dy<=2;dy+=2)
            if(contrast(background,pixels.color(cx+side*w/3,cy+dy))>60) return 0;
        int bestMask=0,bestCount=0;
        for(int percent:RADII) {
            int radius=Math.max(4,h*percent/100),mask=0;
            for(int i=0;i<16;i++) {
                for(int step=-1;step<=1;step++) {
                    int x=cx+(int)Math.round((radius+step)*COS[i]);
                    int y=cy+(int)Math.round((radius+step)*SIN[i]);
                    if(x<left || x>=right || y<top || y>=bottom) continue;
                    if(contrast(background,pixels.color(x,y))>65) {mask|=1<<i;break;}
                }
            }
            int n=Integer.bitCount(mask);
            if(n>bestCount && n>=2 && n<=12) {bestCount=n;bestMask=mask;}
        }
        return bestMask;
    }
    private RejectSpinnerPolicy() { }
}
