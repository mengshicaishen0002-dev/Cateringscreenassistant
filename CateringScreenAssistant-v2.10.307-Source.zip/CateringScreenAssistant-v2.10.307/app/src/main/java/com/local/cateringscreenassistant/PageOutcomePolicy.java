package com.local.cateringscreenassistant;

/** Fresh UI onset evidence; never authorizes a click or treats disappearance as success. */
final class PageOutcomePolicy {
    /** Current UI state only. No offer identity, cooldown or historical decision is retained. */
    static boolean transientControlGap(String reason) {
        return "CONTROL_NOT_EXPORTED".equals(reason) || "CONTROL_DISABLED".equals(reason)
                || "INSPECTOR_DISABLED".equals(reason) || "INSPECTOR_NO_CURRENT_ACCEPT".equals(reason);
    }
    static final class SurfaceGate {
        private long epoch=-1, end=-1;
        private boolean negative;
        synchronized void observe(long windowEpoch,long start,long finished,boolean complete,
                                  boolean hasNegative,long now) {
            if(!complete || start<0 || finished<start || finished-start>180L
                    || now<finished || now-finished>180L || windowEpoch<epoch) return;
            // An in-flight pre-prompt clear read must not erase a newer negative publication.
            if(windowEpoch==epoch && (finished<=end || (negative!=hasNegative && start<=end))) return;
            epoch=windowEpoch;end=finished;negative=hasNegative;
        }
        synchronized boolean blocks(long windowEpoch) {return epoch==windowEpoch && negative;}
    }
    static final class Baseline {
        final int window; final long generation, epoch, start, end; final boolean complete, negative;
        Baseline(int window, long generation, long epoch, long start, long end,
                 boolean complete, boolean negative) {
            this.window=window; this.generation=generation; this.epoch=epoch;
            this.start=start; this.end=end; this.complete=complete; this.negative=negative;
        }
        boolean cleanAt(long dispatch, long gen, long windowEpoch) {
            return complete && !negative && generation==gen && epoch==windowEpoch
                    && start<=end && end<=dispatch && dispatch-start<=180L;
        }
    }
    static final class Reading {
        final int window; final long epoch, start, end;
        final boolean complete, positive, ownedPositive; final String hint, context;
        final String reason; final int queries,nodes;
        final String excerpt, actionState, evidenceDetail;
        Reading(int window,long epoch,long start,long end,boolean complete,
                boolean positive,String hint,String context) {
            this(window,epoch,start,end,complete,positive,hint,context,"OK",0,0);
        }
        Reading(int window,long epoch,long start,long end,boolean complete,
                boolean positive,String hint,String context,String reason,int queries,int nodes) {
            this(window,epoch,start,end,complete,positive,hint,context,reason,queries,nodes,"","UNKNOWN");
        }
        Reading(int window,long epoch,long start,long end,boolean complete,
                boolean positive,String hint,String context,String reason,int queries,int nodes,
                String excerpt,String actionState) {
            this(window,epoch,start,end,complete,positive,hint,context,reason,queries,nodes,excerpt,actionState,"");
        }
        Reading(int window,long epoch,long start,long end,boolean complete,
                boolean positive,String hint,String context,String reason,int queries,int nodes,
                String excerpt,String actionState,String evidenceDetail) {
            this(window,epoch,start,end,complete,positive,hint,context,reason,queries,nodes,excerpt,actionState,evidenceDetail,false);
        }
        Reading(int window,long epoch,long start,long end,boolean complete,
                boolean positive,String hint,String context,String reason,int queries,int nodes,
                String excerpt,String actionState,String evidenceDetail,boolean ownedPositive) {
            this.ownedPositive=ownedPositive;
            this.evidenceDetail=evidenceDetail==null?"":evidenceDetail;
            this.window=window;this.epoch=epoch;this.start=start;this.end=end;
            this.complete=complete;this.positive=positive;this.hint=hint;this.context=context;
            this.reason=reason==null?"READ_EXCEPTION":reason;this.queries=queries;this.nodes=nodes;
            this.excerpt=excerpt==null?"":excerpt;this.actionState=actionState==null?"UNKNOWN":actionState;
        }
    }
    static final class Tracker {
        final long dispatch; final String expected; final Baseline baseline;
        final boolean initiallyClean; boolean clean, blocked;
        int validReads;
        private long ownedSuccessEnd=-1,ownedSuccessEpoch=-1;
        private int ownedSuccessWindow=-1;
        private boolean ownedSuccessConfirmed;
        synchronized boolean hasConfirmedOwnedSuccess(){return ownedSuccessConfirmed;}

        private int transientRecoveryCredits;
        private boolean fastRecoveryPending;
        String lastExcerpt="", lastActionState="UNKNOWN", observedContext="", mismatchDetail="";
        long disabledAt=-1, enabledAt=-1;
        private String retryCandidate="", retryIdentity="";
        private long retryCandidateEnd=-1, retryReadyAt=-1;
        private int retryWindow=-1; private long retryEpoch=-1;

        private void resetRetryCandidate() {
            retryCandidate=""; retryCandidateEnd=-1; retryReadyAt=-1;
        }
        private void observeRetryIdentity(Reading r) {
            if (!r.hint.isEmpty() || r.positive || r.context.isEmpty()
                    || !("ENABLED".equals(r.actionState) || "DISABLED".equals(r.actionState)
                        || "NOT_EXPORTED".equals(r.actionState))
                    || OfferEnrichmentPolicy.endpointKey(r.context).isEmpty()
                    || (OfferEnrichmentPolicy.pickupKey(r.context).isEmpty() && CardText.orderId(r.context).isEmpty())) {
                resetRetryCandidate(); return;
            }
            // Original merchant/address + exact numbers bind missing pickup fields to one
            // CURRENT complete enabled same-card reading. Numeric-only originals still need two.
            if("ENABLED".equals(r.actionState)
                    && !OfferEnrichmentPolicy.endpointKey(expected).isEmpty()
                    && OfferEnrichmentPolicy.sameTransaction(expected,r.context)) {
                retryIdentity=r.context;retryReadyAt=r.end;
                retryCandidate=r.context;retryCandidateEnd=r.end;
                retryWindow=r.window;retryEpoch=r.epoch;return;
            }
            if (retryCandidateEnd<0 || retryWindow!=r.window || retryEpoch!=r.epoch
                    || r.start-retryCandidateEnd>700
                    || !OfferEnrichmentPolicy.sameTransaction(retryCandidate,r.context)) {
                retryCandidate=r.context; retryCandidateEnd=r.end;
                retryWindow=r.window; retryEpoch=r.epoch; retryReadyAt=-1; return;
            }
            if (r.start-retryCandidateEnd>=20) {
                retryIdentity=r.context; retryReadyAt=r.end;
            }
        }
        synchronized boolean retryNeedsConfirmation(long now) {
            return !blocked && bound.isEmpty() && firstHint.isEmpty() && retryCandidateEnd>=0
                    && retryReadyAt<0 && "ENABLED".equals(lastActionState)
                    && now>=retryCandidateEnd && now-retryCandidateEnd<=250;
        }
        // This is identity evidence only. Missing export may wake the inspector, whose
        // final live same-card enabled-control check remains mandatory before any retry.
        synchronized String retryDecision(long now) {
            return !blocked && bound.isEmpty() && firstHint.isEmpty() && retryReadyAt>=0
                    && now>=retryReadyAt && now-retryReadyAt<=250
                    && ("ENABLED".equals(lastActionState)
                        || "NOT_EXPORTED".equals(lastActionState)) ? retryIdentity : "";
        }
        // Ownership only. Dispatch still needs retryDecision freshness plus the final live index.
        synchronized boolean retryMatches(String text) {
            return !retryIdentity.isEmpty() && OfferEnrichmentPolicy.sameTransaction(retryIdentity,text);
        }

        // A pressure pause is independent of outcome attribution: an unreadable/foreign
        // surface cannot authorize cached coordinates, even when no loss can be asserted.
        private String pressurePause="";
        private boolean negativeVisible;
        synchronized boolean hasVisibleNegative() {return negativeVisible;}
        private long pressurePauseAt=-1;
        private int cleanWindow=-1; private long cleanEpoch=-1;
        private long promptFirst=-1,promptEnd=-1; private int promptWindow=-1;
        private long promptEpoch=-1; private String promptHint="";
        private boolean promptConfirmed;
        synchronized String pressureBlockReason() {return pressurePause;}
        synchronized void pausePressure(String reason,long at) {
            if(transientControlGap(reason)) return; // Spinner observation owns processing stops.
            if(at>=pressurePauseAt) {pressurePause=reason;pressurePauseAt=at;}
        }
        synchronized void notePressureRevalidated(String text,long at) {
            if(!blocked && !negativeVisible && bound.isEmpty() && !hasPendingNegative() && at>=pressurePauseAt
                    && compatible(expected,text) && CardText.amount(text)>=0f && CardText.miles(text)>=0f) {
                pressurePause="";pressurePauseAt=at;
            }
        }
        synchronized boolean hasFreshUnboundPrompt(long now) {
            return !blocked && bound.isEmpty() && promptConfirmed && now>=promptEnd
                    && now-promptEnd<=500L;
        }
        private void observePrompt(Reading r) {
            if(r.hint.isEmpty() || r.positive || !r.context.isEmpty()) {
                promptFirst=promptEnd=-1;promptConfirmed=false;return;
            }
            if(promptFirst<0 || promptWindow!=r.window || promptEpoch!=r.epoch
                    || !promptHint.equals(r.hint) || r.start-promptEnd>700L) {
                promptFirst=r.end;promptConfirmed=false;
            } else if(r.start-promptFirst>=80L) promptConfirmed=true;
            promptWindow=r.window;promptEpoch=r.epoch;promptHint=r.hint;promptEnd=r.end;
        }
        private boolean hasCurrentCleanContext(Reading r) {
            return clean && cleanWindow==r.window && cleanEpoch>=0 && r.epoch>=cleanEpoch;
        }
        private long differentCandidateEnd=-1;
        private boolean differentCandidateClean;
        private String differentCandidate="";
        private int differentCandidateWindow=-1;
        private long differentCandidateEpoch=-1;
        private long departedAt=-1,departureRequestedAt=-1;
        private int departureReads;
        private long departureReadEpoch=-1;
        synchronized boolean hasConfirmedDeparture() {return blocked && departedAt>=0L;}
        synchronized void requestDepartureOutcomeProbe(long now) {
            if(!hasConfirmedDeparture() || !clean || (!initiallyClean && cleanWindow!=window) || departureRequestedAt!=-1L
                    || now<departedAt || now-departedAt>1500L) return;
            departureRequestedAt=now;departureReads=0;firstEnd=-1;firstHint="";
        }
        synchronized boolean departureOutcomePending(long now) {
            return hasConfirmedDeparture() && bound.isEmpty() && departureRequestedAt>=0L
                    && now>=departureRequestedAt && now-departureRequestedAt<400L && departureReads<3;
        }
        private String observeDepartureOutcome(Reading r,long now) {
            if(!departureOutcomePending(now)) return bound;
            if(r==null || !r.complete || r.context==null || r.start<dispatch || r.start<=lastEnd
                    || r.end<r.start || r.end-r.start>150L || now<r.end || now-r.end>500L
                    || r.window!=window || r.epoch<epoch) {
                firstEnd=-1;firstHint="";status="DEPARTED_READ_INCOMPLETE";return bound;
            }
            departureReads++;validReads++;lastEnd=r.end;
            if(r.positive) {firstEnd=-1;firstHint="";departureRequestedAt=-2L;status="DEPARTED_POSITIVE_CANDIDATE";return bound;}
            if(!r.excerpt.isEmpty())lastExcerpt=r.excerpt;
            if(r.hint.isEmpty()) {firstEnd=-1;firstHint="";status="DEPARTED_CLEAR";return bound;}
            // Caller still fences this reader to the ORIGINAL active owner. No newer Accept/
            // Reject can run during this short proof, and the pre-dispatch/page baseline was clean.
            negativeVisible=true;pausePressure("NEGATIVE_VISIBLE",r.end);
            if(firstEnd<0 || !firstHint.equals(r.hint) || departureReadEpoch!=r.epoch) {
                firstStart=r.start;firstEnd=r.end;firstHint=r.hint;departureReadEpoch=r.epoch;
                status="DEPARTED_WAIT_SECOND_READ";return bound;
            }
            if(r.start-firstEnd>=80L) {bound=r.hint;status="CONFIRMED_DEPARTED_PAGE_EDGE";}
            return bound;
        }
        private long differentTopAt=-1;
        private long cleanReplacementAt=-1;

        synchronized boolean hasFreshCleanReplacement(long now) {
            return hasFreshDifferentTop(now) && cleanReplacementAt == differentTopAt
                    && !negativeVisible && bound.isEmpty();
        }

        synchronized boolean hasFreshDifferentTop(long now) {
            return differentTopAt>=0 && now>=differentTopAt && now-differentTopAt<=500L;
        }

        private long lastLoadingFrameAt=-1;

        synchronized boolean noteLoadingFrame(long frameAt,long now) {
            if (frameAt<dispatch || now<frameAt || now-frameAt>250L) return false;
            lastLoadingFrameAt=Math.max(lastLoadingFrameAt,frameAt);
            if (differentCandidateEnd<=lastLoadingFrameAt) {
                differentCandidateEnd=-1;
                differentCandidate="";
            }
            if (bound.isEmpty() && "DIFFERENT_CARD".equals(status)) {
                blocked=false;
                differentTopAt=cleanReplacementAt=departedAt=departureRequestedAt=-1;
                status="OWNED_LOADING_VISIBLE";
            }
            return true;
        }

        long lastEnd=-1,firstEnd=-1,firstStart; int window; long epoch;
        String firstHint="";
        private boolean firstNegativeHasSameEndpoint;
        volatile String bound="";
        volatile String status="NOT_READ";
        Tracker(long dispatch,String expected,Baseline baseline,boolean clean) {
            this.dispatch=dispatch;this.expected=expected;this.baseline=baseline;
            this.initiallyClean=clean;this.clean=clean;
            this.window=baseline==null?-1:baseline.window;
            this.epoch=baseline==null?-1:baseline.epoch;
        }
        synchronized String observe(Reading r,long now) {
            if (blocked) {return observeDepartureOutcome(r,now);}
            fastRecoveryPending=false;
            if (r==null) {ownedSuccessEnd=-1;ownedSuccessConfirmed=false;status="NO_READ";return bound;}
            if (!r.complete) {
                ownedSuccessEnd=-1;ownedSuccessConfirmed=false;
                differentCandidateEnd=-1;differentCandidate="";
                // Do not let an older queued foreign read pause a newer verified CTA.
                if(r.start>=dispatch && r.end>=r.start && now>=r.end && now-r.end<=500L
                        && ("FOREIGN_APP".equals(r.reason) || "NO_ROOT".equals(r.reason)))
                    pausePressure(r.reason,r.end);
                resetRetryCandidate();
                if(("UI_CHANGED".equals(r.reason) || "TIME_LIMIT".equals(r.reason) || r.reason.startsWith("INDEX_"))
                        && !"INDEX_BUSY".equals(r.reason) && transientRecoveryCredits<3) {
                    transientRecoveryCredits++;
                    fastRecoveryPending=true;
                }
                status="INCOMPLETE:"+r.reason;return bound;
            }
            if(r.ownedPositive && r.positive && r.hint.isEmpty()) {
                if(r.start<dispatch || r.end<r.start || r.end-r.start>150L || now<r.end
                        || now-r.end>180L || r.start<=lastEnd) {
                    ownedSuccessEnd=-1;ownedSuccessConfirmed=false;status="STALE_OWNED_SUCCESS";return bound;
                }
                validReads++;lastEnd=r.end;pausePressure("POSITIVE_JOB",r.end);resetRetryCandidate();
                if(ownedSuccessEnd>=0 && ownedSuccessWindow==r.window && ownedSuccessEpoch==r.epoch
                        && r.start-ownedSuccessEnd>=80L && r.start-ownedSuccessEnd<=750L) {
                    ownedSuccessConfirmed=true;status="CONFIRMED_OWNED_JOB";return bound;
                }
                ownedSuccessEnd=r.end;ownedSuccessWindow=r.window;ownedSuccessEpoch=r.epoch;
                status="WAIT_OWNED_SUCCESS";return bound;
            }
            ownedSuccessEnd=-1;ownedSuccessConfirmed=false;
            if (r.context==null) {
                differentCandidateEnd=-1;differentCandidate="";
                if(r.start>=dispatch && r.end>=r.start && now>=r.end && now-r.end<=500L)
                    pausePressure("INCOMPLETE_IDENTITY:"+r.reason,r.end);
                resetRetryCandidate();
                if(transientRecoveryCredits<3) {transientRecoveryCredits++;fastRecoveryPending=true;}
                status="CONTEXT_INCOMPLETE:"+r.reason;return bound;
            }
            if (r.start<dispatch || r.end<r.start || r.end-r.start>150
                    || now<r.end || now-r.end>500 || r.start<=lastEnd) {
                status="STALE_OR_REUSED_READ";return bound;
            }
            validReads++;
            lastEnd=r.end;
            if(r.positive || !r.hint.isEmpty() || !"ENABLED".equals(r.actionState)
                    || r.context.isEmpty())
                pausePressure(r.positive?"POSITIVE_JOB":!r.hint.isEmpty()?"NEGATIVE_VISIBLE":
                        r.context.isEmpty()?"OWNED_ROW_NOT_FOUND":"CONTROL_"+r.actionState,r.end);
            if (r.positive || !compatible(expected,r.context)
                    || (!retryIdentity.isEmpty() && !compatible(retryIdentity,r.context))) {
                if (!r.positive && lastLoadingFrameAt>=0 && (r.start<=lastLoadingFrameAt+250L
                        || (r.hint.isEmpty() && !r.evidenceDetail.contains("OWNED_ROW_SEARCH=COMPLETE")))) {
                    // An action-row text gap can expose another card while the owned button spins.
                    // Keep the owner and require two fresh departure reads after the visible loading.
                    if (!r.hint.isEmpty()) {
                        negativeVisible=true;
                        pausePressure("NEGATIVE_VISIBLE",r.end);
                    }
                    status="OWNED_LOADING_VISIBLE";
                    return bound;
                }
                boolean completeReplacement = !r.positive && r.evidenceDetail.contains("OWNED_ROW_SEARCH=COMPLETE")
                        && (r.hint.isEmpty() || (lastLoadingFrameAt>=0 && r.window==window && r.epoch==epoch
                            && CardText.amount(r.context)>=0f && CardText.miles(r.context)>=0f
                            && !OfferEnrichmentPolicy.endpointKey(r.context).isEmpty()));
                if (completeReplacement) {
                    // A list insertion can publish its new top before the displaced row.
                    // Two independent complete all-row reads must miss the active offer.
                    if (r.hint.isEmpty()) pausePressure("OWNED_ROW_NOT_FOUND",r.end);
                    else negativeVisible=true;
                    if(differentCandidateEnd<0 || differentCandidateWindow!=r.window || differentCandidateEpoch!=r.epoch
                            || r.start-differentCandidateEnd>700L
                            || !OfferEnrichmentPolicy.sameTransaction(differentCandidate,r.context)) {
                        differentCandidate=r.context;differentCandidateEnd=r.end;
                        differentCandidateClean=r.hint.isEmpty();
                        differentCandidateWindow=r.window;differentCandidateEpoch=r.epoch;
                        status="WAIT_OWNED_ROW";return "";
                    }
                    if(r.start-differentCandidateEnd<45L) {status="WAIT_OWNED_ROW";return "";}
                    if(r.window==window && r.epoch==epoch && CardText.amount(r.context)>=0f
                            && CardText.miles(r.context)>=0f
                            && !OfferEnrichmentPolicy.endpointKey(r.context).isEmpty()) {
                        differentTopAt=r.end;
                        if (differentCandidateClean && r.hint.isEmpty()) cleanReplacementAt=r.end;
                    }
                }
                if(!r.positive) {
                    String owner=!compatible(expected,r.context)?expected:retryIdentity;
                    if (r.window==window && r.epoch==epoch && r.hint.isEmpty()
                            && CardText.amount(r.context)>=0f && CardText.miles(r.context)>=0f
                            && !CardText.containsMultipleMileageRows(r.context)
                            && !CardText.containsConflictingOfferNumbers(r.context)
                            && CardText.amount(expected)>=0f && CardText.miles(expected)>=0f
                            && !OfferEnrichmentPolicy.endpointKey(r.context).isEmpty()
                            && Math.abs(CardText.amount(expected)-CardText.amount(r.context))>0.011f
                            && Math.abs(CardText.miles(expected)-CardText.miles(r.context))>0.051f)
                        differentTopAt=r.end;
                    mismatchDetail="field="+incompatibleField(owner,r.context)
                            +",expected="+identityBrief(owner)+",observed="+identityBrief(r.context);
                }
                if(!r.positive && differentCandidateEnd>=0L) departedAt=r.end;
                blocked=true;bound="";status=r.positive?"POSITIVE_JOB":"DIFFERENT_CARD";return "";
            }
            differentCandidateEnd=-1;differentCandidate="";
            negativeVisible=!r.hint.isEmpty();
            observePrompt(r);
            if (window<0) {window=r.window;epoch=r.epoch;}
            if (window==r.window && epoch!=r.epoch) {
                // Same active window with freshly re-proved original card: event churn is not
                // a foreign-window transition. Restart the two-frame proof at this new epoch.
                if (r.epoch<epoch || (r.context.isEmpty() && (!(initiallyClean || hasCurrentCleanContext(r)) || r.hint.isEmpty()))) {
                    firstEnd=-1;firstHint="";status="WAIT_WINDOW_CONTEXT";return bound;
                }
                epoch=r.epoch;firstEnd=-1;firstHint="";
            } else if (window!=r.window) {
                if (!(initiallyClean || hasCurrentCleanContext(r)) || r.epoch<=epoch || !r.context.isEmpty()
                        || r.hint.isEmpty()) {
                    blocked=true;bound="";status="FOREIGN_WINDOW";return "";
                }
                window=r.window;epoch=r.epoch;firstEnd=-1;firstHint="";
            }
            // Diagnostics use the same complete/fresh/compatible read gate as outcome evidence.
            // They never change bound, success, retry eligibility or the transaction identity.
            if (!r.excerpt.isEmpty()) lastExcerpt=r.excerpt;
            lastActionState=r.actionState;
            if ("ENABLED".equals(r.actionState) && enabledAt<0) enabledAt=r.end;
            if ("DISABLED".equals(r.actionState) && disabledAt<0) disabledAt=r.end;
            if (!r.context.isEmpty() && (!OfferEnrichmentPolicy.endpointKey(r.context).isEmpty()
                    || !OfferEnrichmentPolicy.pickupKey(r.context).isEmpty())) observedContext=r.context;
            observeRetryIdentity(r);
            if (r.hint.isEmpty()) {
                if(!r.context.isEmpty() && CardText.amount(r.context)>=0f && CardText.miles(r.context)>=0f
                        && (!OfferEnrichmentPolicy.endpointKey(r.context).isEmpty() || !CardText.orderId(r.context).isEmpty())) {
                    cleanWindow=r.window;cleanEpoch=r.epoch;
                }
                if("ENABLED".equals(r.actionState) && !r.context.isEmpty())
                    notePressureRevalidated(r.context,r.end);
                clean=true;firstEnd=-1;firstHint="";status="CLEAR_AFTER_DISPATCH";return bound;
            }
            if (!clean) {status="WAIT_NEW_ONSET";return "";}
            if (firstEnd<0 || !firstHint.equals(r.hint) || r.start-firstEnd>1500) {
                firstStart=r.start;firstEnd=r.end;firstHint=r.hint;
                firstNegativeHasSameEndpoint = hasSameNegativeEndpoint(r);
                status="WAIT_SECOND_READ";return "";
            }
            long separation = firstNegativeHasSameEndpoint && hasSameNegativeEndpoint(r) ? 45L : 80L;
            if (r.start-firstEnd>=separation) {bound=r.hint;status="CONFIRMED_PAGE_EDGE";}
            else status="READS_TOO_CLOSE";
            return bound;
        }
        private boolean hasSameNegativeEndpoint(Reading reading) {
            String endpoint = OfferEnrichmentPolicy.endpointKey(expected);
            return initiallyClean && baseline != null
                    && baseline.window == reading.window && baseline.epoch == reading.epoch
                    && !endpoint.isEmpty() && endpoint.equals(OfferEnrichmentPolicy.endpointKey(reading.context))
                    && CardText.amount(reading.context) >= 0f && CardText.miles(reading.context) >= 0f
                    && !CardText.containsConflictingOfferNumbers(reading.context)
                    && !CardText.containsMultipleMileageRows(reading.context);
        }

        // Two extra reads are reserved for a late onset, not spent on early clear pages.
        synchronized boolean hasPendingNegative() {
            return (!blocked || departureRequestedAt>=0L) && bound.isEmpty() && firstEnd>=0 && !firstHint.isEmpty();
        }

        synchronized boolean needsConfirmation(long now) {
            return (!blocked || departureRequestedAt>=0L) && bound.isEmpty() && firstEnd >= 0 && !firstHint.isEmpty()
                    && now >= firstEnd && now - firstEnd <= 600L;
        }
        /** Continuous monitored claims retain outcome observation for their whole active transaction. */
        synchronized boolean retryContextBlocked() {return blocked;}
        synchronized boolean mayProbeContinuous(long now) {
            return bound.isEmpty() && now>=dispatch && (!blocked || departureOutcomePending(now));
        }

        synchronized boolean mayProbe(int count, long startedAt, long now) {
            if (blocked || !bound.isEmpty() || now < dispatch || now - dispatch >= 3000L) return false;
            // Queue delays and invalid snapshots must not consume the useful-read budget.
            // Twelve useful reads, two invalid replacements, up to three transient replacements, two confirmations;
            // the dispatch-relative three-second ceiling always wins.
            return (count < 14+transientRecoveryCredits && validReads < 12)
                    || (count < 16+transientRecoveryCredits && needsConfirmation(now));
        }
        /** Faster invalid-read recovery has a separate allowance; never burn the late tail. */
        synchronized long nextProbeDelayMs(int count,long now) {
            return nextProbeDelayMs(count,now,false);
        }
        synchronized long nextContinuousProbeDelayMs(int count,long now) {
            return nextProbeDelayMs(count,now,true);
        }
        private long nextProbeDelayMs(int count,long now,boolean continuous) {
            if("WAIT_OWNED_SUCCESS".equals(status)) return Math.max(12L,ownedSuccessEnd+80L-now);
            if(departureOutcomePending(now)) {
                if(firstEnd>=0L && !firstHint.isEmpty()) return Math.max(12L,firstEnd+90L-now);
                return 12L;
            }
            if(count==0) return 20L;
            if("WAIT_OWNED_ROW".equals(status)) return Math.max(12L,differentCandidateEnd+50L-now);
            if (continuous && "INCOMPLETE:FOREIGN_APP".equals(status)) return 650L;
            if(needsConfirmation(now)) {
                long minimum = firstNegativeHasSameEndpoint ? 50L : 90L;
                return Math.max(15L, firstEnd + minimum - now);
            }
            if(promptFirst>=0 && !promptConfirmed && now>=promptFirst && now-promptFirst<600L)
                return Math.max(15L,promptFirst+90L-now);
            if(retryNeedsConfirmation(now)) return 12L;
            // Early recoveries must not spend the last ordinary clear read before a
            // slower server response can arrive. A fresh negative still gets its own confirmation slot.
            if(!continuous && validReads==11 && firstHint.isEmpty()) return Math.max(60L,dispatch+2400L-now);
            if (fastRecoveryPending) return 12L;
            // Every coherent clear read keeps the pending button responsive. The bounded
            // expanded read allowance prevents the early cadence from consuming the late tail.
            if ("CLEAR_AFTER_DISPATCH".equals(status)) {
                // The live visual loading signal already prevents any retry. While it is fresh,
                // avoid repeating seven deep queries on each unchanged missing/disabled row.
                // New events, negative/success evidence and recovery branches above still win.
                if (continuous && validReads>=3 && lastLoadingFrameAt>=dispatch
                        && now>=lastLoadingFrameAt && now-lastLoadingFrameAt<=120L
                        && ("NOT_EXPORTED".equals(lastActionState) || "DISABLED".equals(lastActionState)))
                    return 160L;
                if (disabledAt >= 0L && ("NOT_EXPORTED".equals(lastActionState)
                        || "DISABLED".equals(lastActionState))) return continuous?80L:170L;
                return continuous?80L:120L;
            }
            return continuous?120L:360L;
        }

        /** Scheduling only: one coherent page sample can replace overlapping OCR/control reads.
         * Never supplies geometry, authorizes a retry, or declares an outcome. */
        synchronized boolean deferVisualRead(long now) {
            return !blocked && bound.isEmpty() && now>=dispatch && now-dispatch<3000L
                    && ((lastEnd<0 && now-dispatch<200L)
                        || (lastEnd>=dispatch && now>=lastEnd && now-lastEnd<350L
                            && ("CLEAR_AFTER_DISPATCH".equals(status) || hasPendingNegative())));
        }
        synchronized boolean deferControlRead(long now) {
            return !blocked && bound.isEmpty() && "CLEAR_AFTER_DISPATCH".equals(status)
                    && lastEnd>=dispatch && now>=lastEnd && now-lastEnd<50L
                    && ("DISABLED".equals(lastActionState) || "NOT_EXPORTED".equals(lastActionState))
                    && retryDecision(now).isEmpty();
        }

        /** Observation only. The inspector must still prove the live enabled same card. */
        synchronized boolean shouldWakeEnabledRecheck(long now) {
            return retryNeedsConfirmation(now) || !retryDecision(now).isEmpty();
        }

        synchronized String retryDiagnostic(long now) {
            if (blocked) return "BLOCKED:"+status;
            if (!pressurePause.isEmpty()) return "PRESSURE_PAUSED:"+pressurePause;
            if (!bound.isEmpty() || hasPendingNegative()) return "NEGATIVE_PENDING";
            if ("DISABLED".equals(lastActionState)) return "CURRENT_CONTROL_DISABLED";
            if (!retryDecision(now).isEmpty()) return "IDENTITY_READY_NEEDS_LIVE_ENABLED_CONTROL";
            if (retryNeedsConfirmation(now)) return "WAIT_SECOND_CLEAN_IDENTITY";
            if ("NOT_EXPORTED".equals(lastActionState)) return "CONTROL_NOT_EXPORTED_OR_PROOF_STALE";
            return "WAIT_COHERENT_IDENTITY:"+status;
        }

        // Diagnostic only; does not change any outcome/retry eligibility state.
        synchronized void noteInspectorDisabled(String text,long at) {
            if(disabledAt<0 && at>=dispatch && !text.isEmpty()
                    && OfferEnrichmentPolicy.sameTransaction(expected,text)) disabledAt=at;
        }
        synchronized String audit() { return audit(-1L,-1L); }
        private static long firstObserved(long read,long control) {
            return read<0?control:control<0?read:Math.min(read,control);
        }
        private static String observationSource(long read,long control) {
            return read<0?(control<0?"NONE":"CONTROL"):control<0 || read<control?"READ"
                    :control<read?"CONTROL":"READ+CONTROL";
        }
        synchronized String audit(long controlEnabled,long controlDisabled) {
            // Diagnostic merging only: neither control notifications nor this audit can
            // change outcome attribution, retry identity or click permission.
            long firstEnabled=firstObserved(enabledAt,controlEnabled);
            long firstDisabled=firstObserved(disabledAt,controlDisabled);
            String fields=observedContext.isEmpty()?expected:observedContext;
            String pickup=OfferEnrichmentPolicy.pickupKey(fields);
            String endpoint=OfferEnrichmentPolicy.endpointKey(fields);
            return "ACCEPT_NODE="+lastActionState+",firstEnabled="
                    +(firstEnabled<0?"UNOBSERVED":(firstEnabled-dispatch)+"ms")+",firstDisabled="
                    +(firstDisabled<0?"UNOBSERVED":(firstDisabled-dispatch)+"ms")
                    +",firstEnabledSource="+observationSource(enabledAt,controlEnabled)
                    +",firstDisabledSource="+observationSource(disabledAt,controlDisabled)
                    +"；当前页取餐时间="+(pickup.isEmpty()?"未读到":pickup)
                    +"；当前页地址（仅诊断）="+(endpoint.isEmpty()?"未读到":endpoint.substring(0,Math.min(240,endpoint.length())))
                    +"；页面提示原文="+(lastExcerpt.isEmpty()?"未读到":lastExcerpt);
        }
        synchronized String diagnostic() {
            return "source="+(bound.isEmpty()?"PAGE_PROBE":"PAGE_EDGE")+",baseline="+(initiallyClean?"CLEAN":clean?"POST_CLEAR":"UNPROVEN")
                    +",first="+(firstEnd<0?"NONE":(firstStart-dispatch)+"ms")
                    +",last="+(lastEnd<0?"NONE":(lastEnd-dispatch)+"ms")+",window="+window+",epoch="+epoch+",status="+status+(mismatchDetail.isEmpty()?"":"；mismatch="+mismatchDetail);
        }
    }
    static boolean compatible(String expected,String current) {
        return incompatibleField(expected,current).isEmpty();
    }
    private static String incompatibleField(String expected,String current) {
        if(current==null) return "NO_CONTEXT";
        if(current.isEmpty()) return "";
        if(CardText.containsConflictingOfferNumbers(current)) return "MULTIPLE_NUMBERS";
        if(CardText.amount(current)<0 || CardText.miles(current)<0) return "PARTIAL_NUMBERS";
        if(Math.round(CardText.amount(expected)*100)!=Math.round(CardText.amount(current)*100)) return "AMOUNT";
        if(Math.abs(CardText.miles(expected)-CardText.miles(current))>0.0001f) return "MILEAGE";
        String a=CardText.orderId(expected),b=CardText.orderId(current);
        if(!a.isEmpty()&&!b.isEmpty()&&!a.equals(b)) return "ORDER_ID";
        a=OfferEnrichmentPolicy.pickupKey(expected);b=OfferEnrichmentPolicy.pickupKey(current);
        if(!a.isEmpty()&&!b.isEmpty()&&!a.equals(b)) return "PICKUP_TIME";
        a=OfferEnrichmentPolicy.endpointKey(expected);b=OfferEnrichmentPolicy.endpointKey(current);
        return a.isEmpty()||b.isEmpty()||a.equals(b)?"":"ENDPOINT";
    }
    private static String identityBrief(String text) {
        String endpoint=OfferEnrichmentPolicy.endpointKey(text);
        return CardText.amount(text)+"/"+CardText.miles(text)+"/"
                +OfferEnrichmentPolicy.pickupKey(text)+"/"+endpoint.substring(0,Math.min(160,endpoint.length()));
    }
    private PageOutcomePolicy() {}
}
