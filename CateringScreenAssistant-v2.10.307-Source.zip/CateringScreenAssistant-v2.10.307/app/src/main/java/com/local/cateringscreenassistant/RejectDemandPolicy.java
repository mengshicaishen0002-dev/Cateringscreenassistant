package com.local.cateringscreenassistant;

/** Scheduling classification only; unknown fragments must not hold Reject rescue indefinitely. */
final class RejectDemandPolicy {
    static boolean coherent(String text) {
        return text != null && CardText.amount(text) >= 0f && CardText.miles(text) >= 0f
                && !CardText.containsConflictingOfferNumbers(text)
                && !ClaimSuccessSignals.hasAcceptedJobDetail(text)
                && !ClaimSuccessSignals.hasBeginDeliveryControl(text);
    }

    static boolean sameOrUnprovenOwned(String owned, String incoming) {
        if (!coherent(owned) || !coherent(incoming)) return true;
        if (Math.round(CardText.amount(owned) * 100f) != Math.round(CardText.amount(incoming) * 100f)
                || Math.abs(CardText.miles(owned) - CardText.miles(incoming)) > 0.0001f) return false;
        String ownedId = CardText.orderId(owned), incomingId = CardText.orderId(incoming);
        if (!ownedId.isEmpty() && !incomingId.isEmpty() && !ownedId.equals(incomingId)) return false;
        String a = OfferEnrichmentPolicy.pickupKey(owned), b = OfferEnrichmentPolicy.pickupKey(incoming);
        if (!a.isEmpty() && !b.isEmpty() && !a.equals(b)) return false;
        String endpointA = OfferEnrichmentPolicy.rejectEndpointKey(owned), endpointB = OfferEnrichmentPolicy.rejectEndpointKey(incoming);
        if (!endpointA.isEmpty() && !endpointB.isEmpty() && !endpointA.equals(endpointB)) return false;
        // Matching numbers without a differing complete identity are not proof of a new card.
        return true;
    }

    static String deferReason(boolean accepting, boolean newOffer) {
        return accepting ? "ACCEPT_PRIORITY" : newOffer ? "NEW_OFFER_PRIORITY" : "NONE";
    }

    private RejectDemandPolicy() { }
}
