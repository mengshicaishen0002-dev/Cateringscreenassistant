package com.local.cateringscreenassistant;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Event-only classification: ambiguous content ALWAYS invalidates live evidence. */
public final class UiMutationPolicy {
    private UiMutationPolicy() {}
    private static final Pattern CLOCK = Pattern.compile(
            "expires(?: in)?\\s*:?\\s*(?:(\\d{1,2}):(\\d{2})|([0-9]{1,3})\\s*(?:s|sec|secs|second|seconds))",
            Pattern.CASE_INSENSITIVE);
    public static String benignReason(int type, int changes, int window, String before, String after) {
        if (window < 0) return "";
        // Android focus and hover events do not mutate card content or geometry.
        if (type == 8 || type == 128 || type == 256 || type == 32768 || type == 65536)
            return "FOCUS_HOVER";
        // Only a text edit with BOTH complete old/new pure countdown labels qualifies.
        // Subtree, undefined, description, state, click, scroll and window events never qualify.
        if (type != 16 || changes != 0) return "";
        int oldSeconds = seconds(before), newSeconds = seconds(after);
        return oldSeconds >= 0 && newSeconds >= 0 && newSeconds < oldSeconds
                && oldSeconds - newSeconds <= 5 ? "COUNTDOWN_TEXT" : "";
    }
    /** A click acknowledgement alone changes no layout. Actual subtree, text, scroll,
     * visibility and window publications still revoke cached coordinates. */
    public static boolean invalidatesPressureLayout(int type,String benignReason) {
        return type!=1 && (benignReason==null || benignReason.isEmpty());
    }
    private static int seconds(String value) {
        if (value == null || value.length() > 64) return -1;
        Matcher m = CLOCK.matcher(value.trim().toLowerCase(Locale.US));
        if (!m.matches()) return -1;
        if (m.group(3) != null) return Integer.parseInt(m.group(3));
        int seconds = Integer.parseInt(m.group(2));
        return seconds < 60 ? Integer.parseInt(m.group(1)) * 60 + seconds : -1;
    }
}
