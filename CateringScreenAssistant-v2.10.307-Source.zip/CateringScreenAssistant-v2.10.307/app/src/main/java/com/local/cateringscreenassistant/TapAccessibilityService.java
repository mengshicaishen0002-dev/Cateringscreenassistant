package com.local.cateringscreenassistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.Locale;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.regex.Pattern;

public class TapAccessibilityService extends AccessibilityService {
    private static final Pattern LIVE_MONEY = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_MILES = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_MONEY_RANGE = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)\\s*[-–—]\\s*\\$?(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_OFFER_TIME = Pattern.compile("(?:today|tomorrow)\\s*(?:at)?\\s*(\\d{1,2}:\\d{2})\\s*(am|pm)", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_CA_ZIP = Pattern.compile("\\bCA\\s+\\d{5}(?:-\\d{4})?\\b", Pattern.CASE_INSENSITIVE);
    private static final AtomicReference<TapAccessibilityService> INSTANCE = new AtomicReference<>();
    private static volatile String foregroundPackage = "";
    private static volatile PageGuard.Page pageHint = PageGuard.Page.UNKNOWN;
    private static volatile long pageHintAt;
    // v2.10.12: remember short-lived DeliverThat outcome messages (toast/snackbar/window text)
    // so a dispatched claim can distinguish backend rejection from a silent disappearance.
    private static volatile String lastClaimOutcomeHint = "";
    private static volatile long lastClaimOutcomeHintAt;
    // v2.10.68: keep terminal server evidence in its own cache. A later generic
    // Delivery Timeline event must never overwrite/erase an earlier offer-unavailable result.
    private static volatile String lastTerminalClaimOutcomeHint = "";
    private static volatile long lastTerminalClaimOutcomeHintAt;
    // Reject binds terminal outcomes to new Accessibility events, never to a stale tree toast.
    private static final AtomicLong CLAIM_OUTCOME_EVENT_EPOCH = new AtomicLong();
    private static volatile AcceptOutcomeFence.Observation lastScopedClaimEvent;
    private static volatile AcceptOutcomeFence.Observation lastScopedTerminalEvent;
    private static volatile AcceptOutcomeFence.Observation lastScopedPositiveEvent;
    private static volatile String lastEventClaimOutcomeHint = "";
    private static volatile long lastEventClaimOutcomeHintAt;
    private static volatile long lastEventClaimOutcomeEpoch;
    // v2.10.60: retain the raw accepted-job surface briefly so a positive Job/Timeline hint can
    // be bound to the exact Accept transaction instead of being confused with an older Job page.
    private static volatile String lastAcceptedJobDetailRaw = "";
    private static volatile long lastAcceptedJobDetailAt;
    // v2.10.23: cached Jobs badge baseline. A successful claim can leave the
    // user on Offers/No offers available, so page==JOBS alone is not enough.
    private static volatile int lastJobsBadgeCount = -1;
    private static volatile long lastJobsBadgeAt;
    // v2.10.28: generation for the visible DeliverThat UI. Cached Accessibility decision
    // evidence is valid only for the exact generation that produced it.
    private static final AtomicLong UI_GENERATION = new AtomicLong();
    private static final AtomicLong PRESSURE_LAYOUT_EPOCH = new AtomicLong();
    private static final PageOutcomePolicy.SurfaceGate CURRENT_SURFACE_GATE = new PageOutcomePolicy.SurfaceGate();
    public static boolean currentNegativeSurfaceBlocksAccept() {
        return CURRENT_SURFACE_GATE.blocks(WINDOW_TRANSITION_EPOCH.get());
    }
    static boolean hasCurrentNegativeBaseline(FastOfferSnapshot snapshot) {
        PageOutcomePolicy.Baseline b=snapshot==null?null:snapshot.pageOutcomeBaseline();
        long now=SystemClock.elapsedRealtime();
        return b!=null && b.complete && b.negative && b.generation==UI_GENERATION.get()
                && b.epoch==WINDOW_TRANSITION_EPOCH.get() && b.end>=b.start
                && now>=b.end && now-b.start<=180L;
    }
    private static final AtomicLong WINDOW_TRANSITION_EPOCH = new AtomicLong();
    private static volatile DecisionEvidence lastDecisionEvidence;
    // v2.10.52: retain the freshest complete numeric decision across harmless React-Native
    // event-generation churn. It is NEVER actionable by itself; OcrMonitorService may use it
    // only when the current Accept index/quick tree independently proves same-card compatibility.
    private static volatile DecisionEvidence lastCrossGenerationDecisionEvidence;
    // v2.10.56: diagnostic-only "first Accessibility sighting" timestamp by semantic offer
    // identity. This never authorizes an action. Entries roll over after a short gap so a
    // genuine re-broadcast gets a fresh baseline instead of inheriting an old appearance.
    private static final ConcurrentHashMap<String, Long> FIRST_SEEN_AT = new ConcurrentHashMap<>();
    private static final long FIRST_SEEN_ROLLOVER_MS = 8_000L;
    // v2.10.59: identity grows as React-Native exports time/merchant/address. Binding FIRST_SEEN
    // directly to the growing identity made the baseline restart and produced fake ~25-35ms
    // values. Preserve the earliest numeric-pair sighting across that enrichment burst, then
    // bind every later semantic identity for the same pair back to the original timestamp.
    private static volatile long firstSeenNumericKey;
    private static volatile long firstSeenNumericAt;
    private static volatile long firstSeenNumericLastAt;
    // v2.10.63 diagnostics: first moment a CURRENT semantic Accept/Claim anchor with the
    // numeric pair became usable. Comparing this with FIRST_SEEN separates DeliverThat UI-export
    // latency from our own dispatch latency; it never participates in eligibility.
    private static volatile long acceptAnchorNumericKey;
    private static volatile long acceptAnchorFirstAt;
    private static volatile long acceptAnchorLastAt;
    // v2.10.34: Large Order informational tooltip covers the Accept/Reject row. Keep a very
    // short hint so the action engine can freeze while OCR dismisses the X instead of treating
    // the covered card as a successful Reject disappearance.
    private static volatile long largeOrderPopupHintAt;
    private static volatile long largeOrderPopupCloseAttemptAt;
    private static final long LARGE_ORDER_CLOSE_SINGLE_FLIGHT_MS = 1_200L;

    public static final class DecisionEvidence {
        public final String text;
        public final float amount;
        public final float miles;
        public final String identity;
        public final long capturedAt;
        public final long uiGeneration;

        DecisionEvidence(String text, long capturedAt, long uiGeneration) {
            this.text = text == null ? "" : text;
            this.amount = CardText.amount(this.text);
            this.miles = CardText.miles(this.text);
            this.identity = CardText.identity(this.text);
            this.capturedAt = capturedAt;
            this.uiGeneration = uiGeneration;
        }
    }
    private long structuralRootPrefetchAt;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BoundedReadBatch witnessReadBatch = new BoundedReadBatch(4);
    // v2.10.292: first-shot amount/miles + action index cannot wait behind a slow
    // existing-transaction witness refresh. Exactly four prewarmed read slots, no extra
    // Binder queries and no change to eligibility or final click proof.
    private final BoundedReadBatch firstShotIndexBatch = new BoundedReadBatch(4,
            () -> android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY));
    // Enabled-owner renewal cannot lose its read slots to ordinary indices/page probes.
    private final BoundedReadBatch ownedResumeReadBatch = new BoundedReadBatch(4);
    // Outcome page reads must never occupy first-shot or current-node renewal slots.
    private final BoundedReadBatch outcomePageReadBatch = new BoundedReadBatch(4);
    private final BoundedReadBatch outcomeDeadlineReads=new BoundedReadBatch(1),successDeadlineReads=new BoundedReadBatch(1);
    private final BoundedReadBatch rejectIndexBatch = new BoundedReadBatch(5);
    // A presence probe must not consume first-shot numeric/Reject index read slots.
    private final BoundedReadBatch idlePresenceBatch = new BoundedReadBatch(3);
    private HandlerThread directThread;
    private final BoundedReadBatch actionDeadlineReads=new BoundedReadBatch(1);
    private final BoundedReadBatch rejectDeadlineReads=new BoundedReadBatch(1);
    private final BoundedReadBatch fallbackDeadlineReads=new BoundedReadBatch(1);
    private final BoundedReadBatch numericDeadlineReads=new BoundedReadBatch(1);
    private Handler directWorker;
    private final java.util.concurrent.atomic.AtomicInteger rejectReadTurn = new java.util.concurrent.atomic.AtomicInteger();
    private static final ThreadLocal<RejectReadProgress> REJECT_READ_PROGRESS = new ThreadLocal<>();
    private static final ThreadLocal<AccessibilityNodeInfo> REJECT_READ_ROOT = new ThreadLocal<>();

    private static AccessibilityNodeInfo rootForRejectRead(TapAccessibilityService service) {
        RejectReadProgress progress = REJECT_READ_PROGRESS.get();
        if (progress == null) return service.getRootInActiveWindow();
        if (!progress.mayRead(SystemClock.elapsedRealtime())) return null;
        AccessibilityNodeInfo root = REJECT_READ_ROOT.get();
        if (root == null) {
            progress.stage = "ROOT";
            root = service.getRootInActiveWindow();
            if (root != null) REJECT_READ_ROOT.set(root);
            progress.rootAt = SystemClock.elapsedRealtime();
        }
        return root == null ? null : AccessibilityNodeInfo.obtain(root);
    }

    private static long rejectReadDeadline(long proposed) {
        RejectReadProgress progress = REJECT_READ_PROGRESS.get();
        return progress == null ? proposed : Math.min(proposed, progress.deadlineAt);
    }

    private HandlerThread rejectRecheckThread;
    private Handler rejectRecheckWorker;
    private java.util.concurrent.ThreadPoolExecutor rootReadAhead;
    private HandlerThread controlWatchThread;
    private Handler controlWatchWorker;
    private volatile AcceptControlWatch activeControlWatch;
    private static final java.util.concurrent.atomic.AtomicReference<AcceptControlWatch> WATCH_CANDIDATE=
            new java.util.concurrent.atomic.AtomicReference<>();
    private static final class AcceptControlWatch implements AutoCloseable {
        AccessibilityNodeInfo node;
        final String text;
        final Rect rootBounds;
        final int window;
        final long windowEpoch,startedAt,actionAt;
        String previous="";
        int reads,rebinds;
        long nextRebindAt;
        AcceptControlWatch(AccessibilityNodeInfo node,String text,Rect bounds,int window,long epoch,long actionAt) {
            this.node=AccessibilityNodeInfo.obtain(node);this.text=text;this.rootBounds=new Rect(bounds);
            this.window=window;windowEpoch=epoch;this.actionAt=actionAt;startedAt=SystemClock.elapsedRealtime();
        }
        synchronized AcceptControlWatch bind(String expected,long at) {
            if(node==null || !IndexedWitnessPolicy.sameIdentity(expected,text)) return null;
            return new AcceptControlWatch(node,text,rootBounds,window,windowEpoch,at);
        }
        synchronized String read() {
            if(node==null || !node.refresh()) return "NOT_EXPORTED:REFRESH_FAILED";
            if(!node.isVisibleToUser()) return "NOT_EXPORTED:HIDDEN";
            if(node.getWindowId()!=window) return "NOT_EXPORTED:WINDOW_CHANGED";
            if(!matchesAccept(node.getText()) && !matchesAccept(node.getContentDescription())) return "NOT_EXPORTED:LABEL_CHANGED";
            AccessibilityNodeInfo action=resolveIndexedAction(node,rootBounds,true);
            if(action==null) return "NOT_EXPORTED:GEOMETRY";
            try {return actionNodeReady(action)?"ENABLED":"DISABLED";} finally {action.recycle();}
        }
        @Override public synchronized void close(){if(node!=null){node.recycle();node=null;}}
    }
    private static void rememberAcceptControl(AccessibilityNodeInfo node,String text,IndexedReadProof proof) {
        if(node==null || proof==null) return;
        try {
            AcceptControlWatch receipt=new AcceptControlWatch(node,text,proof.rootBounds,proof.windowId,proof.windowEpoch,0L);
            AcceptControlWatch old=WATCH_CANDIDATE.getAndSet(receipt);if(old!=null)old.close();
        } catch(RuntimeException ignored) { }
    }
    public static void startAcceptControlWatch(String text,long actionAt) {
        if(OcrMonitorService.acceptPressureActive(actionAt)) return;
        TapAccessibilityService service=INSTANCE.get();
        if(service==null || service.controlWatchWorker==null || actionAt<=0L) return;
        AcceptControlWatch existing=service.activeControlWatch;
        if(existing!=null) synchronized(existing) {
            if(existing.node!=null && existing.actionAt==actionAt
                    && existing.windowEpoch==WINDOW_TRANSITION_EPOCH.get()
                    && SystemClock.elapsedRealtime()-existing.startedAt<2200L && existing.reads<140
                    && IndexedWitnessPolicy.sameIdentity(existing.text,text)) return;
        }
        AcceptControlWatch candidate=WATCH_CANDIDATE.get();
        AcceptControlWatch watch=candidate==null?null:candidate.bind(text,actionAt);
        if(watch==null) {OcrMonitorService.onAcceptControlObserved(actionAt,"NOT_STARTED:NO_BINDABLE_CONTROL",0L);return;}
        AcceptControlWatch old=service.activeControlWatch;service.activeControlWatch=watch;
        if(old!=null)service.controlWatchWorker.post(old::close);
        service.controlWatchWorker.postDelayed(() -> service.pollAcceptControl(watch),0L);
    }
    // Spread caption-only rebinds across the processing interval so early hidden
    // frames cannot exhaust them. The observer never supplies click authority.
    private String rebindAcceptControl(AcceptControlWatch watch) {
        long generation=UI_GENERATION.get(),started=SystemClock.elapsedRealtime();
        AccessibilityNodeInfo root=null;
        try {
            if(!OcrMonitorService.acceptRetryGuard(watch.actionAt).isEmpty()) return "NOT_EXPORTED:TRANSACTION_BLOCKED";
            root=readCurrentIndexedRoot(this,generation);
            if(root==null || root.getWindowId()!=watch.window) return "NOT_EXPORTED:NO_CURRENT_ROOT";
            for(String caption:new String[]{"Accept","Claim"}) {
                if(SystemClock.elapsedRealtime()-started>80L) return "NOT_EXPORTED:REBIND_BUDGET";
                List<AccessibilityNodeInfo> nodes=root.findAccessibilityNodeInfosByText(caption);
                if(nodes==null) continue;
                try {
                    for(AccessibilityNodeInfo node:nodes) {
                        if(node==null || !node.isVisibleToUser() || node.getWindowId()!=watch.window
                                || (!matchesAccept(node.getText()) && !matchesAccept(node.getContentDescription()))) continue;
                        AccessibilityNodeInfo action=resolveIndexedAction(node,watch.rootBounds,true);
                        if(action==null) continue;
                        try {
                            if(UI_GENERATION.get()!=generation || WINDOW_TRANSITION_EPOCH.get()!=watch.windowEpoch
                                    || activeControlWatch!=watch || OcrMonitorService.pendingClaimSince()!=watch.actionAt
                                    || !OcrMonitorService.acceptRetryGuard(watch.actionAt).isEmpty()) return "NOT_EXPORTED:REBIND_CHANGED";
                            synchronized(watch) {
                                if(watch.node!=null) watch.node.recycle();
                                watch.node=AccessibilityNodeInfo.obtain(node);
                            }
                            return actionNodeReady(action)?"ENABLED":"DISABLED";
                        } finally {action.recycle();}
                    }
                } finally {for(AccessibilityNodeInfo node:nodes)if(node!=null)node.recycle();}
            }
            return "NOT_EXPORTED:NO_CURRENT_CAPTION";
        } catch(RuntimeException stale) {return "NOT_EXPORTED:REBIND_EXCEPTION";}
        finally {if(root!=null)root.recycle();}
    }
    private void pollAcceptControl(AcceptControlWatch watch) {
        if(activeControlWatch!=watch || INSTANCE.get()!=this || !OcrMonitorService.isMonitoring()
                || OcrMonitorService.pendingClaimSince()!=watch.actionAt
                || !OcrMonitorService.acceptRetryGuard(watch.actionAt).isEmpty()
                || watch.windowEpoch!=WINDOW_TRANSITION_EPOCH.get()
                || !"com.deliverthat.driver".equals(foregroundPackage)
                || SystemClock.elapsedRealtime()-watch.startedAt>=2200L || watch.reads>=140) {
            watch.close();if(activeControlWatch==watch)activeControlWatch=null;return;
        }
        String mode;
        try {mode=watch.read();}catch(RuntimeException stale){mode="NOT_EXPORTED:READ_EXCEPTION";}
        long now = SystemClock.elapsedRealtime();
        if (mode.startsWith("NOT_EXPORTED") && watch.rebinds < 5 && now >= watch.nextRebindAt) {
            watch.rebinds++;
            watch.nextRebindAt = now + 250L;
            mode = rebindAcceptControl(watch);
        }
        watch.reads++;
        if(!mode.equals(watch.previous)) {
            boolean recovered="ENABLED".equals(mode) && !watch.previous.isEmpty();
            watch.previous=mode;
            OcrMonitorService.onAcceptControlObserved(watch.actionAt,recovered?"ENABLED_RECOVERED":mode,
                    SystemClock.elapsedRealtime()-watch.startedAt);
        }
        long delay = mode.startsWith("NOT_EXPORTED") ? 32L : 16L;
        if(controlWatchWorker!=null)controlWatchWorker.postDelayed(() -> pollAcceptControl(watch),delay);
    }


    private final AtomicBoolean directQueued = new AtomicBoolean(false);
    private final ClaimBudget directClaimBudget = new ClaimBudget();
    private final RejectSequence directRejectSequence = RejectSequence.shared();
    private volatile long directCooldownUntil;
    private final Runnable directHeartbeat = new Runnable() {
        @Override public void run() {
            if (directWorker == null) return;
            queueDirectCheck();
            long burstAge = recentNumericOfferBurstAge(2500L);
            directWorker.postDelayed(this, HotOfferScanPolicy.standaloneHeartbeatDelay(
                    HotOfferScanPolicy.evidenceHot(burstAge)));
        }
    };

    private static final AtomicReference<IndexedWitness> LAST_INDEXED_WITNESS = new AtomicReference<>();
    private static volatile String lastUiMutationTrace = "UNKNOWN";
    private static final AtomicLong BENIGN_UI_EVENTS = new AtomicLong();

    public static String uiMutationDiagnostic() {
        return lastUiMutationTrace + ",benign=" + BENIGN_UI_EVENTS.get();
    }

    /** An immutable read result; worker jobs never click or mutate claim ownership. */
    private static final class WitnessNodeValue {
        final Rect bounds;
        final String text, description;
        final long readMs;
        WitnessNodeValue(Rect bounds, String text, String description, long readMs) {
            this.bounds = bounds; this.text = text; this.description = description; this.readMs = readMs;
        }
    }
    private static final class WitnessNodeRead implements BoundedReadBatch.Read<WitnessNodeValue> {
        final AccessibilityNodeInfo node;
        final Rect rootBounds;
        final int windowId;
        final boolean accept;
        Rect pressureFallbackBounds;
        volatile String failure = "NOT_STARTED";
        WitnessNodeRead(AccessibilityNodeInfo source, Rect rootBounds, int windowId, boolean accept) {
            node = AccessibilityNodeInfo.obtain(source);
            this.rootBounds = new Rect(rootBounds); this.windowId = windowId; this.accept = accept;
        }
        private WitnessNodeValue failed(String stage) {
            failure=stage;
            if(accept && pressureFallbackBounds!=null && ("DETACHED".equals(stage)
                    || "HIDDEN".equals(stage) || "LABEL_CHANGED".equals(stage)
                    || "DISABLED".equals(stage) || "ACTION_UNRESOLVED".equals(stage))) {
                failure="PRESSURE_GAP_"+stage;
                return new WitnessNodeValue(new Rect(pressureFallbackBounds),"","",0L);
            }
            return null;
        }
        @Override public WitnessNodeValue read() {
            long started = SystemClock.elapsedRealtime();
            try {
                if (!node.refresh()) return failed("DETACHED");
                if (node.getWindowId()!=windowId) return failed("WINDOW_CHANGED");
                if (!node.isVisibleToUser()) return failed("HIDDEN");
                Rect bounds = new Rect();
                if (accept) {
                    if (!matchesAccept(node.getText()) && !matchesAccept(node.getContentDescription())) {
                        String label=(String.valueOf(node.getText())+" "+node.getContentDescription()).replace("null","").trim();
                        return failed(pressureFallbackBounds==null || label.isEmpty() || label.toLowerCase(java.util.Locale.US).startsWith("loading")
                                ?"LABEL_CHANGED":"FOREIGN_ACTION_LABEL");
                    }
                    AccessibilityNodeInfo action=resolveIndexedAction(node,rootBounds,true);
                    if(action==null) return failed("ACTION_UNRESOLVED");
                    try {
                        action.getBoundsInScreen(bounds);
                        if(pressureFallbackBounds!=null) pressureFallbackBounds=new Rect(bounds);
                        if(!actionNodeReady(action)) return failed("DISABLED");
                        if(!safeActionBounds(rootBounds,bounds,true)) return failed("UNSAFE_BOUNDS");
                    } finally {action.recycle();}
                } else node.getBoundsInScreen(bounds);
                if(bounds.isEmpty()) return failed("EMPTY_BOUNDS");
                CharSequence text=node.getText(),desc=node.getContentDescription();
                failure="OK";
                return new WitnessNodeValue(bounds,text==null?"":text.toString(),
                        desc==null?"":desc.toString(),SystemClock.elapsedRealtime()-started);
            } catch(RuntimeException stale) {return failed("EXCEPTION_"+stale.getClass().getSimpleName());}
        }
        @Override public void close() { node.recycle(); }
    }

    /** Owns at most eight source-node copies plus the semantic Accept; expires in300ms. */
    private static final class IndexedWitness {
        final List<AccessibilityNodeInfo> fields = new ArrayList<>();
        final List<String> fieldText = new ArrayList<>();
        AccessibilityNodeInfo action;
        volatile boolean closed;
        boolean overflow;
        long capturedAt;
        volatile String reason = "UNAVAILABLE", failureDetail = "NONE";

        void action(AccessibilityNodeInfo seed) {
            if (action != null) action.recycle();
            action = AccessibilityNodeInfo.obtain(seed);
        }
        void field(AccessibilityNodeInfo node) {
            if (overflow || fields.contains(node)) return;
            CharSequence value=node.getText(),desc=node.getContentDescription();
            field(node,value==null?"":value.toString(),desc==null?"":desc.toString());
        }
        void field(AccessibilityNodeInfo node,String value,String desc) {
            if (overflow || fields.contains(node)) return;
            if (fields.size() >= 8) { overflow = true; return; }
            fields.add(AccessibilityNodeInfo.obtain(node));
            fieldText.add(value+(desc.isEmpty() || desc.equals(value)?"":" "+desc));
        }
        void publish(TapAccessibilityService service, long now) {
            capturedAt = now;
            IndexedWitness previous = LAST_INDEXED_WITNESS.getAndSet(this);
            if (previous != null && previous != this) previous.close();
            service.main.postDelayed(this::close, 300L);
        }
        synchronized void close() {
            if (closed) return;
            closed = true;
            if (action != null) { action.recycle(); action = null; }
            for (AccessibilityNodeInfo node : fields) node.recycle();
            fields.clear(); fieldText.clear();
            LAST_INDEXED_WITNESS.compareAndSet(this, null);
        }
        synchronized FastOfferSnapshot refreshCurrentRetryAction(TapAccessibilityService service,
                FastOfferSnapshot original,Rect liveRoot,int windowId) {
            long started=SystemClock.elapsedRealtime();
            long generation=UI_GENERATION.get();
            WitnessNodeRead job=null;
            try {
                if(closed || action==null) {reason="UNAVAILABLE";return null;}
                job=new WitnessNodeRead(action,liveRoot,windowId,true);
                BoundedReadBatch.Result<WitnessNodeValue> result=service.witnessReadBatch.read(
                        java.util.Collections.singletonList(job),Math.max(1L,80L-(started-original.capturedAt)));
                if(!result.complete()) {
                    reason=result.reason;failureDetail="ACTION_"+job.failure;return null;
                }
                Rect bounds=result.values.get(0).bounds;
                if(UI_GENERATION.get()!=generation || generation!=original.indexedRead.generation) {
                    reason="UI_CHANGED";return null;
                }
                if(!VisualGenerationReboundPolicy.sameGeometry(original.acceptBounds.left,original.acceptBounds.top,
                        original.acceptBounds.right,original.acceptBounds.bottom,bounds.left,bounds.top,bounds.right,bounds.bottom)) {
                    reason="GEOMETRY_CONFLICT";return null;
                }
                long now=SystemClock.elapsedRealtime();
                if(now<original.capturedAt || now-original.capturedAt>80L) {reason="BUDGET";return null;}
                IndexedReadProof proof=new IndexedReadProof(liveRoot,windowId,generation,
                        original.indexedRead.startedAt,now,"RETRY_CURRENT_INDEX;actionRefresh="+(now-started)+"ms");
                reason="OK";
                // Preserve the original field timestamp. Refreshing only the action must never
                // extend the life of the numeric/address evidence used to authorize this retry.
                return new FastOfferSnapshot(original.text,bounds,new Rect(),true,false,
                        original.capturedAt,original.amount,original.miles,proof);
            } catch(RuntimeException stale) {
                reason="REFRESH_FAILED";failureDetail="EXCEPTION_"+stale.getClass().getSimpleName();return null;
            } finally {close();}
        }
        synchronized IndexedWitness copyForOwner() {
            if(closed || overflow || action==null || fields.isEmpty()) return null;
            IndexedWitness copy=new IndexedWitness();
            try {
                copy.action=AccessibilityNodeInfo.obtain(action);
                for(AccessibilityNodeInfo field:fields) copy.fields.add(AccessibilityNodeInfo.obtain(field));
                copy.fieldText.addAll(fieldText);copy.capturedAt=capturedAt;
                return copy;
            } catch(RuntimeException stale) {copy.close();return null;}
        }
        synchronized FastOfferSnapshot refresh(FastOfferSnapshot original,Rect liveRoot,int windowId) {
            return refresh(original,liveRoot,windowId,false);
        }
        synchronized FastOfferSnapshot refresh(FastOfferSnapshot original,Rect liveRoot,int windowId,boolean currentOwner) {
            return refresh(original,liveRoot,windowId,currentOwner,false);
        }
        synchronized FastOfferSnapshot refresh(FastOfferSnapshot original,Rect liveRoot,int windowId,boolean currentOwner,boolean pressureRenewal) {
            long started = SystemClock.elapsedRealtime();
            if (closed || overflow || action == null || fields.isEmpty()
                    || (!currentOwner && (started < capturedAt || started - capturedAt > 300L))) {
                reason = "UNAVAILABLE"; return null;
            }
            // Select cached source handles locally; only the selected fields may authorize
            // the rebind, and their contents are all refreshed again below.
            int selected = IndexedWitnessPolicy.sourceCover(fieldText);
            if (Integer.bitCount(selected) > 1) {
                int single = IndexedWitnessPolicy.singleFoldedSource(fieldText);
                if (single != 0) selected = single;
            }
            if (selected == 0) selected = (1 << fields.size()) - 1;
            // Common split pay/miles/endpoint has no redundant text: avoid reparsing it.
            // Retain the semantic minimizer for larger sets so their old parallel eligibility
            // is preserved when unrelated/duplicated source nodes cannot be subsumed literally.
            if (Integer.bitCount(selected) > 3) {
                int semantic = IndexedWitnessPolicy.minimumCover(original.text, fieldText);
                if (semantic != 0 && Integer.bitCount(semantic) < Integer.bitCount(selected)) selected = semantic;
            }
            long selectedAt = SystemClock.elapsedRealtime();
            int sourceCount = fields.size();
            long generation = UI_GENERATION.get();
            long deadline = started + 60L;
            try {
                Rect bounds;
                List<CardText.Piece> pieces = new ArrayList<>();
                java.util.function.Supplier<String> readTrace;
                TapAccessibilityService service = INSTANCE.get();
                if (service == null) { reason = "UNAVAILABLE"; return null; }
                if (Integer.bitCount(selected) <= 3 || pressureRenewal) {
                    if (SystemClock.elapsedRealtime() >= started + 80L) { reason = "BUDGET"; return null; }
                    List<WitnessNodeRead> jobs = new ArrayList<>();
                    try {
                        WitnessNodeRead actionRead=new WitnessNodeRead(action,liveRoot,windowId,true);
                        if(pressureRenewal) actionRead.pressureFallbackBounds=new Rect(original.acceptBounds);
                        jobs.add(actionRead);
                        for (int i = 0; i < fields.size(); i++) if ((selected & (1 << i)) != 0)
                            jobs.add(new WitnessNodeRead(fields.get(i), liveRoot, windowId, false));
                    } catch (RuntimeException stale) {
                        for (WitnessNodeRead job : jobs) job.close();
                        reason = "REFRESH_FAILED"; return null;
                    }
                    BoundedReadBatch reader=currentOwner?service.ownedResumeReadBatch:service.witnessReadBatch;
                    long readBudget=Math.max(1L,started+(Integer.bitCount(selected)>3?60L:80L)-SystemClock.elapsedRealtime());
                    BoundedReadBatch.Result<WitnessNodeValue> read = pressureRenewal
                            ?reader.readWaves(jobs,readBudget):reader.read(jobs,readBudget);
                    if (!read.complete()) {
                        reason = read.reason;
                        failureDetail = witnessReadFailure(jobs,read.reason);
                        return null;
                    }
                    bounds = read.values.get(0).bounds;
                    for (int i = 0; i < read.values.size(); i++) {
                        WitnessNodeValue value = read.values.get(i);
                        if (i > 0) {
                            if (value.bounds.top >= bounds.top) { reason = "GEOMETRY_CONFLICT"; return null; }
                            if (!value.text.isEmpty()) addUniquePiece(pieces, value.text, value.bounds);
                            if (!value.description.isEmpty() && !value.description.equals(value.text))
                                addUniquePiece(pieces, value.description, value.bounds);
                        }
                    }
                    readTrace = () -> {
                        StringBuilder durations=new StringBuilder();
                        for (WitnessNodeValue value:read.values) {
                            if(durations.length()>0) durations.append('/');
                            durations.append(value.readMs);
                        }
                        return (jobs.size()>4?",readMode=PARALLEL_WAVES,readMs=":",readMode=PARALLEL,readMs=") + durations
                                + ",selectMs=" + (selectedAt-started) + ",batchMs=" + read.elapsedMs
                                + ",launchMs=" + read.launchMs + ",maxQueueMs=" + read.maxQueueMs
                                + ",action="+jobs.get(0).failure;
                    };
                } else {
                    reason = "REFRESH_FAILED";
                    if(pressureRenewal) {
                        WitnessNodeRead actionRead=new WitnessNodeRead(action,liveRoot,windowId,true);
                        actionRead.pressureFallbackBounds=new Rect(original.acceptBounds);
                        WitnessNodeValue value;
                        try {value=actionRead.read();} finally {actionRead.close();}
                        if(value==null) {failureDetail="ACTION_"+actionRead.failure;return null;}
                        bounds=value.bounds;
                    } else {
                    if (!action.refresh() || !action.isVisibleToUser() || action.getWindowId() != windowId
                            || (!matchesAccept(action.getText()) && !matchesAccept(action.getContentDescription()))) return null;
                    AccessibilityNodeInfo liveAction = resolveIndexedAction(action, liveRoot, true);
                    if (liveAction == null) return null;
                    bounds = new Rect();
                    try {
                        liveAction.getBoundsInScreen(bounds);
                        if (!actionNodeReady(liveAction)) { failureDetail="ACTION_DISABLED"; return null; }
                        if (!safeActionBounds(liveRoot, bounds, true)) return null;
                    } finally { liveAction.recycle(); }
                    }

                    for (int i = 0; i < fields.size(); i++) {
                        if ((selected & (1 << i)) == 0) continue;
                        AccessibilityNodeInfo node = fields.get(i);
                        if (SystemClock.elapsedRealtime() >= deadline) { reason = "BUDGET"; return null; }
                        if (!node.refresh() || !node.isVisibleToUser() || node.getWindowId() != windowId) return null;
                        Rect b = new Rect(); node.getBoundsInScreen(b);
                        if (b.isEmpty() || b.top >= bounds.top) { reason = "GEOMETRY_CONFLICT"; return null; }
                        CharSequence value = node.getText(), desc = node.getContentDescription();
                        if (value != null && value.length() > 0) addUniquePiece(pieces, value.toString(), b);
                        if (desc != null && desc.length() > 0 && !desc.equals(value)) addUniquePiece(pieces, desc.toString(), b);
                    }
                    readTrace = () -> ",readMode=SEQUENTIAL";
                }
                // All required nodes are already refreshed. Never throw away a complete
                // fresh proof solely because the final Binder call crossed the soft slice.
                if (UI_GENERATION.get() != generation) { reason = "UI_CHANGED"; return null; }
                String current = CardText.aboveButton(pieces, bounds.top, bounds.bottom);
                if (!IndexedWitnessPolicy.sameIdentity(original.text, current)) {
                    reason = "IDENTITY_CONFLICT"; return null;
                }
                if ((!currentOwner && (started < original.capturedAt
                        || started - original.capturedAt > VisualGenerationReboundPolicy.MAX_FRAME_AGE_MS))
                        || !VisualGenerationReboundPolicy.sameGeometry(original.acceptBounds.left, original.acceptBounds.top,
                        original.acceptBounds.right, original.acceptBounds.bottom,
                        bounds.left, bounds.top, bounds.right, bounds.bottom)) {
                    reason = "GEOMETRY_CONFLICT"; return null;
                }
                long now = SystemClock.elapsedRealtime();
                final int selectedCount=Integer.bitCount(selected)+1;
                IndexedReadProof proof = new IndexedReadProof(liveRoot, windowId, generation,
                        original.indexedRead.startedAt, now, "LIVE_NODE_RECHECK");
                proof.deferredStages=() -> "LIVE_NODE_RECHECK="+(now-started)+"ms,nodes="+selectedCount
                        +",sourceNodes="+(sourceCount+1)+readTrace.get();
                reason = "OK";
                return new FastOfferSnapshot(current, bounds, new Rect(), true, false, now,
                        original.amount, original.miles, proof);
            } catch (RuntimeException stale) { reason = "REFRESH_FAILED"; failureDetail="EXCEPTION_"+stale.getClass().getSimpleName(); return null; }
            finally { close(); }
        }
    }

    /** A complete current index already owns the fields; do not compete with its first shot
     * by climbing the same RN ancestors on the event thread. Event wake and outcomes stay live. */
    private static boolean hasFreshIndexedWitness() {
        IndexedWitness witness = LAST_INDEXED_WITNESS.get();
        long now = SystemClock.elapsedRealtime();
        return witness != null && !witness.closed && witness.capturedAt > 0L
                && now >= witness.capturedAt && now - witness.capturedAt <= 300L;
    }

    private static final class IndexedReadProof {
        final Rect rootBounds;
        final int windowId;
        final long generation, startedAt, verifiedAt, windowEpoch, pressureLayoutEpoch;
        final String stages;
        java.util.function.Supplier<String> deferredStages;
        String formattedStages() { return deferredStages==null?stages:deferredStages.get(); }
        IndexedWitness witness;
        long controlReadAt;
        PageOutcomePolicy.Baseline outcomeBaseline;
        IndexedReadProof(Rect rootBounds, int windowId, long generation, long startedAt,
                         long verifiedAt, String stages) {
            this.rootBounds = new Rect(rootBounds); this.windowId = windowId;
            this.generation = generation; this.startedAt = startedAt;
            this.verifiedAt = verifiedAt; this.stages = stages;
            this.windowEpoch=WINDOW_TRANSITION_EPOCH.get();this.pressureLayoutEpoch=PRESSURE_LAYOUT_EPOCH.get();
        }
    }

    public static final class FastOfferSnapshot {
        public final String text;
        public final Rect acceptBounds;
        public final Rect rejectBounds;
        public final boolean acceptEnabled;
        public final boolean rejectEnabled;
        // v2.10.26: decision-ready fields are derived once when the coherent Accessibility
        // snapshot is created. The hot path no longer repeats regex parsing / identity building
        // three or four times before the first gesture.
        public final float amount;
        public final float miles;
        public final String identity;
        // v2.10.5: timestamp the exact Accessibility snapshot used for the first-tap fast path.
        // The fast tap is only allowed for a very fresh top-card snapshot.
        public final long capturedAt;
        private final IndexedReadProof indexedRead;
        public long acceptProofStartedAt() { return indexedRead==null?0L:indexedRead.startedAt; }
        public long acceptControlReadAt() {
            if (indexedRead==null) return 0L;
            return indexedRead.controlReadAt>0L ? indexedRead.controlReadAt : indexedRead.startedAt;
        }
        private IndexedReadProof rejectProof;
        String rejectReuseReason = "";
        private long rejectReadStartedAt;
        private long rejectNumbersReadAt;
        public long rejectReadStartedAt() { return rejectReadStartedAt; }
        public long rejectNumbersReadAt() { return rejectNumbersReadAt; }
        public String rejectIndexTiming() { return rejectProof==null ? "" : rejectProof.formattedStages(); }

        private void stampSharedRejectRead(long rootAt, long labelsAt, long actionsAt, long numbersAt,
                String rootTrace, java.util.function.Supplier<String> queryTrace) {
            if (rejectProof==null) return;
            rejectNumbersReadAt=numbersAt;
            long proofAt=SystemClock.elapsedRealtime();
            rejectProof.deferredStages=() -> rejectProof.stages
                    +"；Reject索引分段 root="+(rootAt-rejectReadStartedAt)
                    +"ms query="+(labelsAt-rootAt)+"ms action="+(actionsAt-labelsAt)
                    +"ms numeric="+(numbersAt-actionsAt)+"ms fieldsAndProof="+(proofAt-numbersAt)+"ms；ROOT_READ="+rootTrace+"；ACTION_READ="+queryTrace.get();
        }

        FastOfferSnapshot(String text, Rect acceptBounds, Rect rejectBounds,
                          boolean acceptEnabled, boolean rejectEnabled) {
            this(text, acceptBounds, rejectBounds, acceptEnabled, rejectEnabled,
                    SystemClock.elapsedRealtime());
        }

        FastOfferSnapshot(String text, Rect acceptBounds, Rect rejectBounds,
                          boolean acceptEnabled, boolean rejectEnabled, long capturedAt) {
            this(text, acceptBounds, rejectBounds, acceptEnabled, rejectEnabled, capturedAt,
                    CardText.amount(text), CardText.miles(text), null);
        }

        private FastOfferSnapshot(String text, Rect acceptBounds, Rect rejectBounds,
                boolean acceptEnabled, boolean rejectEnabled, long capturedAt,
                float amount, float miles, IndexedReadProof indexedRead) {
            this.text = text;
            this.acceptBounds = new Rect(acceptBounds);
            this.rejectBounds = new Rect(rejectBounds);
            this.acceptEnabled = acceptEnabled;
            this.rejectEnabled = rejectEnabled;
            this.amount = amount;
            this.miles = miles;
            this.identity = CardText.identity(text);
            this.capturedAt = capturedAt;
            this.indexedRead = indexedRead;
        }

        FastOfferSnapshot withDecisionText(String merged) {
            FastOfferSnapshot mergedSnapshot = new FastOfferSnapshot(merged, acceptBounds, rejectBounds, acceptEnabled,
                    rejectEnabled, capturedAt, amount, miles, indexedRead);
            mergedSnapshot.rejectProof = rejectProof;
            mergedSnapshot.rejectReadStartedAt = rejectReadStartedAt;
            mergedSnapshot.rejectNumbersReadAt = rejectNumbersReadAt;
            return mergedSnapshot;
        }

        long liveReadGeneration() { return indexedRead==null?-1L:indexedRead.generation; }

        PageOutcomePolicy.Baseline pageOutcomeBaseline() {
            return indexedRead == null ? null : indexedRead.outcomeBaseline;
        }

        void recordReplayIndexStart() {
            if (indexedRead != null)
                OcrMonitorService.noteReplayDiscovery(indexedRead.startedAt, "ACCEPT_INDEX_READ_BEGIN");
        }

        String indexedReadTiming(long dispatchAt) {
            return indexedRead == null ? "" : "；INDEX_READ_BEGIN→dispatch="
                    + Math.max(0L, dispatchAt - indexedRead.startedAt) + "ms；" + indexedRead.formattedStages();
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        firstShotIndexBatch.warmUp();witnessReadBatch.warmUp();ownedResumeReadBatch.warmUp();outcomePageReadBatch.warmUp();outcomeDeadlineReads.warmUp();successDeadlineReads.warmUp();
        rejectIndexBatch.warmUp();idlePresenceBatch.warmUp();
        actionDeadlineReads.warmUp();rejectDeadlineReads.warmUp();
        fallbackDeadlineReads.warmUp();numericDeadlineReads.warmUp();
        rootReadAhead=new java.util.concurrent.ThreadPoolExecutor(1,1,0L,java.util.concurrent.TimeUnit.MILLISECONDS,
                new java.util.concurrent.ArrayBlockingQueue<>(1),run -> {
                    Thread thread=new Thread(() -> {
                        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY); }
                        catch (RuntimeException ignored) { }
                        run.run();
                    },"offer-root-read-ahead");thread.setDaemon(true);return thread;
                });
        rootReadAhead.prestartAllCoreThreads();
        controlWatchThread=new HandlerThread("accept-control-watch",android.os.Process.THREAD_PRIORITY_DISPLAY);
        controlWatchThread.start();controlWatchWorker=new Handler(controlWatchThread.getLooper());
        rejectRecheckThread = new HandlerThread("reject-recheck", android.os.Process.THREAD_PRIORITY_BACKGROUND);
        rejectRecheckThread.start();
        rejectRecheckWorker = new Handler(rejectRecheckThread.getLooper());
        ancestorEvidenceThread = new HandlerThread("offer-ancestor-evidence", android.os.Process.THREAD_PRIORITY_BACKGROUND);
        ancestorEvidenceThread.start();
        ancestorEvidenceWorker = new Handler(ancestorEvidenceThread.getLooper());
        INSTANCE.set(this);
        directThread = new HandlerThread("accessibility-direct", android.os.Process.THREAD_PRIORITY_DISPLAY);
        directThread.start();
        directWorker = new Handler(directThread.getLooper());
        directWorker.post(directHeartbeat);
    }

    // An actual Jobs/Ignored tab click is retained briefly as a navigation hint.
    // It never authorizes an action without current hub/tab geometry validation.
    private static volatile PageGuard.Page lastOtherHubTabClick=PageGuard.Page.UNKNOWN;
    private static volatile long lastOtherHubTabClickAt;
    private static volatile long lastOtherHubTabClickGeneration;

    private static volatile long automaticNavigationUntil;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        long eventReceivedAt = SystemClock.elapsedRealtime();
        String eventPackage = event.getPackageName() == null
                ? "" : event.getPackageName().toString();
        int type = event.getEventType();
        if ((type == AccessibilityEvent.TYPE_TOUCH_INTERACTION_START
                || type == AccessibilityEvent.TYPE_TOUCH_INTERACTION_END)
                && ("com.deliverthat.driver".equals(eventPackage)
                    || (eventPackage.isEmpty() && "com.deliverthat.driver".equals(foregroundPackage))))
            OcrMonitorService.noteManualTouch();
        if ("com.deliverthat.driver".equals(eventPackage)
                && (type == AccessibilityEvent.TYPE_VIEW_CLICKED
                    || type == AccessibilityEvent.TYPE_VIEW_SCROLLED)
                && SystemClock.elapsedRealtime() > automaticNavigationUntil)
            OcrMonitorService.noteUnownedUiInteraction();
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) WINDOW_TRANSITION_EPOCH.incrementAndGet();
        // Notification events from this assistant must not replace the actual
        // foreground app. Only real window transitions may do that.
        boolean returnedToDeliverThat="com.deliverthat.driver".equals(eventPackage)
                && !"com.deliverthat.driver".equals(foregroundPackage);
        if ("com.deliverthat.driver".equals(eventPackage)
                || type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            foregroundPackage = eventPackage;
            if (!"com.deliverthat.driver".equals(eventPackage)) {
                pageHint = PageGuard.Page.UNKNOWN;
                pageHintAt = 0;
            }
        }
        if (!"com.deliverthat.driver".equals(eventPackage)
                && (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED)) {
            UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
            lastUiMutationTrace = "foreignWindow,type=" + type + ",window=" + event.getWindowId();
        }
        if ("com.deliverthat.driver".equals(eventPackage)) {
            if (returnedToDeliverThat) OcrMonitorService.onDeliverThatForeground();
            String shallowDecisionText = eventOwnText(event);
            String benignReason = UiMutationPolicy.benignReason(type, event.getContentChangeTypes(),
                    event.getWindowId(), event.getBeforeText() == null ? "" : event.getBeforeText().toString(),
                    shallowDecisionText);
            boolean benignEvent = !benignReason.isEmpty();
            long generation;
            if (benignEvent) {
                BENIGN_UI_EVENTS.incrementAndGet();
                generation = UI_GENERATION.get();
            } else {
                generation = UI_GENERATION.incrementAndGet();
                if(UiMutationPolicy.invalidatesPressureLayout(type,benignReason)) PRESSURE_LAYOUT_EPOCH.incrementAndGet();
                lastUiMutationTrace = "type=" + type + ",changes=" + event.getContentChangeTypes()
                        + ",window=" + event.getWindowId();
            }
            // v2.10.59 latency fix: wake the urgent offer lane BEFORE the event-source ancestor
            // climb. On React-Native that climb can block for hundreds of ms (and in the field
            // contributed to a 4603ms FIRST_SEEN→dispatch trace). The fast lane still re-proves
            // the current live card/button before acting; this only removes avoidable wake delay.
            // An empty subtree event can be the first notification of a new card.
            // Use the live index for it rather than making the accessibility callback walk parents.
            boolean structuralOfferWake = !benignEvent
                    && type==AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                    && OcrMonitorService.isMonitoring();
            // v2.10.294: v293's presence-only idle lane did not publish Jobs empty-page
            // evidence, leaving the user on "You don't have any jobs." indefinitely.
            // Event text is only a wake hint: clickOffersNavigationFromOtherTab independently
            // verifies the CURRENT Deliveries/Jobs/Offers hub and Jobs selection before tapping.
            PageGuard.Page emptyOtherTab = PageGuard.explicitEmptyOtherTabText(shallowDecisionText);
            PageGuard.Page clickedOtherTab = type == AccessibilityEvent.TYPE_VIEW_CLICKED
                    ? PageGuard.clickedDeliveriesTab(shallowDecisionText) : PageGuard.Page.UNKNOWN;
            PageGuard.Page otherTab = clickedOtherTab != PageGuard.Page.UNKNOWN
                    ? clickedOtherTab : emptyOtherTab;
            if (otherTab == PageGuard.Page.JOBS || otherTab == PageGuard.Page.IGNORED) {
                if(clickedOtherTab != PageGuard.Page.UNKNOWN) {
                    lastOtherHubTabClick=clickedOtherTab;
                    lastOtherHubTabClickAt=eventReceivedAt;
                    lastOtherHubTabClickGeneration=generation;
                }
                // Page hint only: current navigation row must be re-read before click.
                updatePageHint(otherTab);
                OcrMonitorService.requestImmediateFastCheck(event.getEventTime(), true, eventReceivedAt);
            }
            if (!benignEvent) {
                boolean emptyStructuralWake = structuralOfferWake && shallowDecisionText.isEmpty();
                if (emptyStructuralWake)
                    OcrMonitorService.requestImmediateFastCheck(event.getEventTime(), true, eventReceivedAt);
                if(OcrMonitorService.isMonitoring() && OcrMonitorService.pendingClaimSince()==0L) {
                    long rootHintNow=SystemClock.elapsedRealtime();
                    boolean structuralHint=structuralOfferWake
                            && (structuralRootPrefetchAt==0L || rootHintNow-structuralRootPrefetchAt>=20L);
                    if(structuralHint || OcrMonitorService.shouldPrefetchOfferRoot(shallowDecisionText)) {
                        structuralRootPrefetchAt=rootHintNow;
                        prefetchIndexedRoot(this,generation);
                    }
                }
                if (!emptyStructuralWake) {
                    cacheDecisionEvidence(shallowDecisionText, generation);
                    OcrMonitorService.noteForegroundOfferDemand(shallowDecisionText);
                    OcrMonitorService.requestImmediateFastCheck(event.getEventTime(), structuralOfferWake, eventReceivedAt);
                }
            }
            // The first wake above intentionally happens before the ancestor climb. Pasadena
            // city/address evidence often appears only in a parent node, however. If that climb
            // enriched a numeric offer, wake the fast lane again immediately instead of waiting
            // for the next RN event/40ms heartbeat.
            // v2.10.118: if the event's own text already passes General OR is a numeric
            // Pasadena candidate, do not synchronously walk seven RN ancestors on the
            // Accessibility main thread. That climb blocked the already-woken claim worker
            // from obtaining the current root/button for ~129ms in a real Commerce trace.
            // General needs no city. The Pasadena candidate still cannot act from numbers:
            // FIRST_PUBLISH_PASADENA_INDEXED must independently bind the current endpoint city,
            // exact numeric pair and enabled Accept. Other events retain ancestor enrichment.
            boolean hasShallowText = !shallowDecisionText.isEmpty();
            boolean shallowGeneralReady = hasShallowText &&
                    OcrMonitorService.eventNumbersUniversallyQualified(shallowDecisionText);
            boolean shallowPasadenaIndexReady = hasShallowText &&
                    OcrMonitorService.eventNumbersPasadenaIndexCandidate(shallowDecisionText);
            boolean shallowRejectReady = hasShallowText && OcrMonitorService.eventNumbersUniversallyRejected(shallowDecisionText);
            if (!benignEvent && !(structuralOfferWake && shallowDecisionText.isEmpty())
                    && !shallowGeneralReady && !shallowRejectReady && !shallowPasadenaIndexReady
                    && !hasFreshIndexedWitness()) {
                queueAncestorEvidence(event, generation);
            }
            if (!shallowDecisionText.isEmpty() && LargeOrderPopupGuard.hasStrongFragment(shallowDecisionText))
                largeOrderPopupHintAt = SystemClock.elapsedRealtime();
            String claimEventRaw = shallowDecisionText;
            String hint = extractClaimOutcomeHint(claimEventRaw);
            if (!hint.isEmpty()) {
                long claimNow = SystemClock.elapsedRealtime();
                lastClaimOutcomeHint = hint;
                lastClaimOutcomeHintAt = claimNow;
                long outcomeEpoch = CLAIM_OUTCOME_EVENT_EPOCH.incrementAndGet();
                lastEventClaimOutcomeHint = hint;
                lastEventClaimOutcomeHintAt = claimNow;
                lastEventClaimOutcomeEpoch = outcomeEpoch;
                AcceptOutcomeFence.Observation observation = new AcceptOutcomeFence.Observation(
                        hint, outcomeEpoch, event.getEventTime(), claimNow);
                lastScopedClaimEvent = observation;
                if (ClaimSuccessSignals.isPositive(hint) && !ClaimSuccessSignals.isJobDetailHint(hint))
                    lastScopedPositiveEvent = observation;
                if (ClaimSuccessSignals.isTerminalNegative(hint)) {
                    lastScopedTerminalEvent = observation;
                    lastTerminalClaimOutcomeHint = hint;
                    lastTerminalClaimOutcomeHintAt = claimNow;
                }
                if (ClaimSuccessSignals.hasAcceptedJobDetail(claimEventRaw)) {
                    lastAcceptedJobDetailRaw = claimEventRaw;
                    lastAcceptedJobDetailAt = claimNow;
                }
            }
            if (!shallowDecisionText.isEmpty()) updateJobsBadgeFromEvent(event);
            if (!benignEvent) queueDirectCheck();
        }
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        if(rootReadAhead!=null) rootReadAhead.shutdownNow();
        clearIndexedRootReceipt();
        clearAcceptResumeNodes();
        if(controlWatchWorker!=null)controlWatchWorker.removeCallbacksAndMessages(null);
        AcceptControlWatch watch=activeControlWatch;activeControlWatch=null;
        if(watch!=null){if(controlWatchWorker!=null)controlWatchWorker.post(watch::close);else watch.close();}
        AcceptControlWatch candidate=WATCH_CANDIDATE.getAndSet(null);if(candidate!=null)candidate.close();
        if(controlWatchThread!=null)controlWatchThread.quitSafely();controlWatchWorker=null;
        if (rejectRecheckWorker != null) rejectRecheckWorker.removeCallbacksAndMessages(null);
        if (rejectRecheckThread != null) rejectRecheckThread.quitSafely();
        rejectRecheckWorker = null; rejectRecheckThread = null;
        INSTANCE.compareAndSet(this, null);
        synchronized (ancestorEvidenceLock) {
            if (ancestorEvidenceWorker != null) ancestorEvidenceWorker.removeCallbacksAndMessages(null);
            ancestorEvidenceWorker = null;
            if (pendingAncestorEvent != null) pendingAncestorEvent.recycle();
            pendingAncestorEvent = null;
            ancestorEvidenceQueued = false;
        }
        if (ancestorEvidenceThread != null) ancestorEvidenceThread.quitSafely();
        IndexedWitness witness = LAST_INDEXED_WITNESS.getAndSet(null);
        if (witness != null) witness.close();
        firstShotIndexBatch.close();witnessReadBatch.close();ownedResumeReadBatch.close();outcomePageReadBatch.close();outcomeDeadlineReads.close();successDeadlineReads.close();
        rejectIndexBatch.close();idlePresenceBatch.close();
        actionDeadlineReads.close();rejectDeadlineReads.close();fallbackDeadlineReads.close();numericDeadlineReads.close();
        if (directWorker != null) directWorker.removeCallbacksAndMessages(null);
        if (directThread != null) directThread.quitSafely();
        directWorker = null;
        directThread = null;
        super.onDestroy();
    }

    public static long currentUiGeneration() {
        return UI_GENERATION.get();
    }

    public static DecisionEvidence recentDecisionEvidence(long maxAgeMs) {
        DecisionEvidence evidence = lastDecisionEvidence;
        if (evidence == null) return null;
        long now = SystemClock.elapsedRealtime();
        if (evidence.uiGeneration != UI_GENERATION.get()) return null;
        if (now < evidence.capturedAt || now - evidence.capturedAt > Math.max(1L, maxAgeMs)) return null;
        if (evidence.amount < 0 || evidence.miles < 0
                || ClaimSuccessSignals.hasAcceptedJobDetail(evidence.text)) return null;
        return evidence;
    }

    public static void invalidateDecisionEvidence() {
        clearAcceptResumeNodes();
        UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
        lastDecisionEvidence = null;
        lastCrossGenerationDecisionEvidence = null;
        pageHint = PageGuard.Page.UNKNOWN;
        pageHintAt = 0;
    }

    /**
     * v2.10.52 evidence-only cache. Unlike recentDecisionEvidence(), this may cross a few
     * Accessibility event generations, so callers MUST pair it with current-card evidence and
     * current button geometry before acting. Kept tiny to avoid stale-card fusion.
     */
    public static DecisionEvidence recentCrossGenerationDecisionEvidence(long maxAgeMs) {
        DecisionEvidence evidence = lastCrossGenerationDecisionEvidence;
        if (evidence == null) return null;
        long now = SystemClock.elapsedRealtime();
        long currentGeneration = UI_GENERATION.get();
        if (now < evidence.capturedAt || now - evidence.capturedAt > Math.max(1L, maxAgeMs)) return null;
        if (currentGeneration < evidence.uiGeneration || currentGeneration - evidence.uiGeneration > 12L) return null;
        if (evidence.amount < 0 || evidence.miles < 0
                || ClaimSuccessSignals.hasAcceptedJobDetail(evidence.text)) return null;
        return evidence;
    }

    /**
     * v2.10.57 event-burst evidence. React-Native often emits the amount/mileage, card ancestry
     * and Accept node as several Accessibility events. This accessor is evidence-only and may
     * cross a slightly wider generation burst than the normal fusion cache. It is NEVER enough
     * to authorize a tap: callers must re-prove the current live Accept rectangle AND the same
     * numeric pair from the current action ancestry before using it.
     */
    public static DecisionEvidence recentEventBurstDecisionEvidence(long maxAgeMs) {
        DecisionEvidence evidence = lastCrossGenerationDecisionEvidence;
        if (evidence == null) return null;
        long now = SystemClock.elapsedRealtime();
        long currentGeneration = UI_GENERATION.get();
        if (now < evidence.capturedAt || now - evidence.capturedAt > Math.max(1L, maxAgeMs)) return null;
        if (currentGeneration < evidence.uiGeneration || currentGeneration - evidence.uiGeneration > 32L) return null;
        if (evidence.amount < 0 || evidence.miles < 0
                || evidence.identity.isEmpty()
                || ClaimSuccessSignals.hasAcceptedJobDetail(evidence.text)) return null;
        return evidence;
    }

    /** v2.10.56 diagnostics only; does not participate in action eligibility. */
    public static long recentFirstSeenAt(String identity, long maxAgeMs) {
        if (identity == null || identity.isEmpty()) return 0L;
        Long seen = FIRST_SEEN_AT.get(identity);
        if (seen == null || seen <= 0L) return 0L;
        long now = SystemClock.elapsedRealtime();
        long age = now - seen;
        if (age < 0L || age > Math.max(1L, maxAgeMs)) return 0L;
        return seen;
    }

    /** Age of the current numeric offer burst, or -1 when no recent offer evidence exists. */
    public static long recentNumericOfferBurstAge(long maxIdleMs) {
        long now = SystemClock.elapsedRealtime();
        synchronized (FIRST_SEEN_AT) {
            if (firstSeenNumericAt <= 0L || firstSeenNumericLastAt <= 0L
                    || now < firstSeenNumericAt || now < firstSeenNumericLastAt
                    || now - firstSeenNumericLastAt > Math.max(1L, maxIdleMs)) return -1L;
            return now - firstSeenNumericAt;
        }
    }

    public static long recentAcceptAnchorFirstSeenAt(String text, long maxAgeMs) {
        float amount = CardText.amount(text), miles = CardText.miles(text);
        if (amount < 0 || miles < 0) return 0L;
        long key = CardText.numericTimingKey(amount, miles);
        long now = SystemClock.elapsedRealtime();
        synchronized (FIRST_SEEN_AT) {
            if (key != acceptAnchorNumericKey || acceptAnchorFirstAt <= 0L
                    || now < acceptAnchorFirstAt || now - acceptAnchorFirstAt > Math.max(1L, maxAgeMs))
                return 0L;
            return acceptAnchorFirstAt;
        }
    }

    private static void noteIndexedAcceptAnchor(FastOfferSnapshot snapshot) {
        if (snapshot == null || snapshot.acceptBounds.isEmpty() || !snapshot.acceptEnabled
                || snapshot.amount < 0 || snapshot.miles < 0) return;
        noteAcceptAnchor(snapshot.amount, snapshot.miles, snapshot.capturedAt);
    }

    /** Diagnostics for the current frame's filled-blue Accept anchor. Never authorizes a tap. */
    public static void noteVisualAcceptAnchor(float amount, float miles, long capturedAt) {
        if (amount < 0 || miles < 0) return;
        noteAcceptAnchor(amount, miles, capturedAt);
    }

    private static void noteAcceptAnchor(float amount, float miles, long capturedAt) {
        long key = CardText.numericTimingKey(amount, miles);
        long now = capturedAt > 0L ? capturedAt : SystemClock.elapsedRealtime();
        synchronized (FIRST_SEEN_AT) {
            boolean sameBurst = key == acceptAnchorNumericKey && acceptAnchorFirstAt > 0L
                    && now >= acceptAnchorLastAt && now - acceptAnchorLastAt <= FIRST_SEEN_ROLLOVER_MS;
            if (!sameBurst) {
                acceptAnchorNumericKey = key;
                acceptAnchorFirstAt = now;
            }
            acceptAnchorLastAt = now;
        }
    }

    private static void cacheDecisionEvidence(String text, long generation) {
        if (text == null) return;
        String clean = text.replaceAll("\\s+", " ").trim();
        if (clean.isEmpty() || ClaimSuccessSignals.hasAcceptedJobDetail(clean)) return;
        DecisionEvidence candidate = new DecisionEvidence(clean, SystemClock.elapsedRealtime(), generation);
        if (candidate.amount < 0 || candidate.miles < 0) return;
        recordNumericFirstSeen(candidate);
        DecisionEvidence old = lastDecisionEvidence;
        if (old == null || old.uiGeneration != generation || clean.length() >= old.text.length())
            lastDecisionEvidence = candidate;
        DecisionEvidence cross = lastCrossGenerationDecisionEvidence;
        if (cross == null || candidate.capturedAt - cross.capturedAt > 260L
                || clean.length() >= cross.text.length())
            lastCrossGenerationDecisionEvidence = candidate;
    }

    private static void recordNumericFirstSeen(DecisionEvidence candidate) {
        recordNumericFirstSeen(candidate.identity, candidate.amount, candidate.miles, candidate.capturedAt);
    }

    private static void recordNumericFirstSeen(String identity, float amount, float miles, long capturedAt) {
        if (!identity.isEmpty()) {
            long numericKey = CardText.numericTimingKey(amount, miles);
            synchronized (FIRST_SEEN_AT) {
                boolean sameBurst = numericKey == firstSeenNumericKey
                        && firstSeenNumericAt > 0L
                        && Math.abs(capturedAt - firstSeenNumericLastAt) <= FIRST_SEEN_ROLLOVER_MS;
                if (!sameBurst) {
                    firstSeenNumericKey = numericKey;
                    firstSeenNumericAt = capturedAt;
                }
                if (sameBurst) firstSeenNumericAt = Math.min(firstSeenNumericAt, capturedAt);
                firstSeenNumericLastAt = sameBurst ? Math.max(firstSeenNumericLastAt, capturedAt) : capturedAt;
                final long stableFirst = firstSeenNumericAt;
                FIRST_SEEN_AT.compute(identity, (key, oldSeen) ->
                        oldSeen == null || capturedAt - oldSeen > FIRST_SEEN_ROLLOVER_MS
                                ? stableFirst : Math.min(oldSeen, stableFirst));
            }
            if (FIRST_SEEN_AT.size() > 96) {
                long cutoff = capturedAt - FIRST_SEEN_ROLLOVER_MS;
                FIRST_SEEN_AT.entrySet().removeIf(
                        e -> e.getValue() == null || e.getValue() < cutoff);
            }
        }
    }

    private static void noteIndexedNumericObservation(String text, long generation) {
        DecisionEvidence candidate = new DecisionEvidence(text, SystemClock.elapsedRealtime(), generation);
        if (candidate.amount >= 0f && candidate.miles >= 0f) recordNumericFirstSeen(candidate);
    }

    private static String eventOwnText(AccessibilityEvent event) {
        if (event == null) return "";
        StringBuilder joined = new StringBuilder();
        if (event.getText() != null) {
            for (CharSequence value : event.getText())
                if (value != null && value.length() > 0) joined.append(value).append(' ');
        }
        if (event.getContentDescription() != null)
            joined.append(event.getContentDescription()).append(' ');
        return joined.toString();
    }

    private static void cacheDecisionEvidenceShallowFromEvent(AccessibilityEvent event, long generation) {
        cacheDecisionEvidence(eventOwnText(event), generation);
    }

    private final Object ancestorEvidenceLock = new Object();
    private HandlerThread ancestorEvidenceThread;
    private Handler ancestorEvidenceWorker;
    private AccessibilityEvent pendingAncestorEvent;
    private long pendingAncestorGeneration;
    private boolean ancestorEvidenceQueued;

    private void queueAncestorEvidence(AccessibilityEvent event, long generation) {
        synchronized (ancestorEvidenceLock) {
            Handler worker = ancestorEvidenceWorker;
            if (worker == null) return;
            if (pendingAncestorEvent != null) pendingAncestorEvent.recycle();
            pendingAncestorEvent = AccessibilityEvent.obtain(event);
            pendingAncestorGeneration = generation;
            if (!ancestorEvidenceQueued) {
                ancestorEvidenceQueued = worker.post(this::readAncestorEvidence);
                if (!ancestorEvidenceQueued) {
                    pendingAncestorEvent.recycle();
                    pendingAncestorEvent = null;
                }
            }
        }
    }

    private void readAncestorEvidence() {
        AccessibilityEvent event;
        long generation;
        synchronized (ancestorEvidenceLock) {
            event = pendingAncestorEvent;
            generation = pendingAncestorGeneration;
            pendingAncestorEvent = null;
            ancestorEvidenceQueued = false;
        }
        if (event == null) return;
        try {
            if (INSTANCE.get() != this || currentUiGeneration() != generation
                    || !OcrMonitorService.isMonitoring()) return;
            if (cacheDecisionEvidenceAncestorsFromEvent(event, generation)
                    && INSTANCE.get() == this && currentUiGeneration() == generation) {
                DecisionEvidence enriched = recentDecisionEvidence(120L);
                if (enriched != null) OcrMonitorService.noteForegroundOfferDemand(enriched.text);
                OcrMonitorService.requestImmediateFastCheck(event.getEventTime());
            }
        } finally {
            event.recycle();
        }
    }

    private static boolean cacheDecisionEvidenceAncestorsFromEvent(
            AccessibilityEvent event, long generation) {
        if (event == null) return false;
        String shallow = eventOwnText(event);
        StringBuilder joined = new StringBuilder(shallow);
        boolean enrichedNumericDecision = false;
        long deadline = SystemClock.elapsedRealtime() + 20L;
        AccessibilityNodeInfo current = null;
        try {
            current = event.getSource();
            for (int depth = 0; depth < 3 && current != null; depth++) {
                if (SystemClock.elapsedRealtime() >= deadline || currentUiGeneration() != generation) break;
                String own = ownNodeText(current);
                if (!own.isEmpty()) {
                    if (joined.indexOf(own) < 0) joined.append(own).append(' ');
                    if (currentUiGeneration() != generation) break;
                    cacheDecisionEvidence(joined.toString(), generation);
                    String lower = joined.toString().toLowerCase(Locale.US);
                    boolean hasNumericPair = LIVE_MONEY.matcher(joined).find()
                            && LIVE_MILES.matcher(joined).find();
                    if (hasNumericPair && joined.length() > shallow.length())
                        enrichedNumericDecision = true;
                    if (hasNumericPair
                            && (lower.contains(", ca") || lower.contains(" california")
                            || LIVE_CA_ZIP.matcher(joined).find())) break;
                }
                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }
        } catch (RuntimeException ignored) {
            // React-Native may replace the source while the event is being inspected.
        } finally {
            if (current != null) current.recycle();
        }
        return enrichedNumericDecision;
    }

    private static void noteLargeOrderPopupFromEvent(AccessibilityEvent event) {
        if (event == null) return;
        StringBuilder text = new StringBuilder();
        if (event.getText() != null) {
            for (CharSequence value : event.getText())
                if (value != null && value.length() > 0) text.append(value).append(' ');
        }
        if (event.getContentDescription() != null)
            text.append(event.getContentDescription()).append(' ');
        if (LargeOrderPopupGuard.hasStrongFragment(text.toString()))
            largeOrderPopupHintAt = SystemClock.elapsedRealtime();
    }

    public static void noteLargeOrderPopupOcr(String text) {
        if (LargeOrderPopupGuard.isPopupText(text))
            largeOrderPopupHintAt = SystemClock.elapsedRealtime();
    }

    public static boolean largeOrderPopupRecentlyVisible(long maxAgeMs) {
        long seen = largeOrderPopupHintAt;
        long now = SystemClock.elapsedRealtime();
        return seen > 0 && now >= seen && now - seen <= Math.max(1L, maxAgeMs);
    }

    /** Expensive only on the exceptional popup path; never used in the normal first-shot lane. */
    public static boolean isLargeOrderInfoPopupVisible() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return false;
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return false;
        boolean visible = LargeOrderPopupGuard.isPopupText(scan.visibleText.toString());
        if (visible) largeOrderPopupHintAt = SystemClock.elapsedRealtime();
        return visible;
    }

    /**
     * OCR has already proved the exact Large Order tooltip and located its X. This gesture is
     * deliberately separate from Accept/Reject geometry; no order action may run while it fires.
     */

    /**
     * After a confirmed claim, leave the assigned-job detail page and return to Offers.
     * Prefer an explicit Offers/Offer navigation node; otherwise use the page back/up control.
     * This is deliberately separate from Accept/Reject so the detail page cannot be treated as
     * another offer. OcrMonitorService keeps post-claim isolation active until a fresh Offers
     * card is observed.
     */
    private static volatile BeginDeliveryOcrProof beginDeliveryOcrProof;
    private static final class BeginDeliveryOcrProof {
        final String owner;
        final long frameAt, generation;
        BeginDeliveryOcrProof(String owner, long frameAt, long generation) {
            this.owner = owner; this.frameAt = frameAt; this.generation = generation;
        }
    }

    public static void noteBeginDeliveryOcr(boolean visible, String owner, long frameAt, long generation) {
        if (generation != UI_GENERATION.get() || !isDeliverThatForeground()) return;
        beginDeliveryOcrProof = visible ? new BeginDeliveryOcrProof(owner, frameAt, generation) : null;
    }

    public static boolean hasFreshBeginDeliveryOcr(String owner) {
        BeginDeliveryOcrProof proof = beginDeliveryOcrProof;
        if (proof == null || !ClaimVisualProbePolicy.fresh(SystemClock.elapsedRealtime(),
                proof.frameAt, proof.generation, UI_GENERATION.get(), isDeliverThatForeground())) return false;
        return owner == null || (owner != null && !owner.isEmpty()
                && OfferEnrichmentPolicy.sameTransaction(owner, proof.owner));
    }

    /** Retire offer evidence without treating our own bookkeeping as a screen change. */
    public static void invalidateDecisionEvidenceAfterClaim() {
        BeginDeliveryOcrProof proof = beginDeliveryOcrProof;
        long before = UI_GENERATION.get();
        boolean fresh = proof != null && ClaimVisualProbePolicy.fresh(SystemClock.elapsedRealtime(),
                proof.frameAt, proof.generation, before, isDeliverThatForeground());
        invalidateDecisionEvidence();
        long after = UI_GENERATION.get();
        if (fresh && after == before + 1L && beginDeliveryOcrProof == proof)
            beginDeliveryOcrProof = new BeginDeliveryOcrProof(proof.owner, proof.frameAt, after);
    }

    public static boolean clickPostClaimBack(Consumer<String> completion, Consumer<String> mismatch) {
        if (OcrMonitorService.isManualInterventionPaused()) {
            if (mismatch != null) mismatch.accept("人工操作暂停中");
            return false;
        }
        automaticNavigationUntil = SystemClock.elapsedRealtime()+1500L;
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept("DeliverThat不在前台；未执行接单后返回");
            return false;
        }
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) {
            if (mismatch != null) mismatch.accept("接单详情页根节点不可用；等待返回");
            return false;
        }
        Rect rootBounds = new Rect();
        root.getBoundsInScreen(rootBounds);
        StringBuilder screenText = new StringBuilder();
        collectLimitedText(root, screenText, new int[]{260});
        boolean confirmedJobDetail = hasFreshBeginDeliveryOcr(null)
                || ClaimSuccessSignals.hasAcceptedJobDetail(screenText.toString())
                || ClaimSuccessSignals.hasBeginDeliveryControl(screenText.toString());
        AccessibilityNodeInfo target = findBackNavigationNode(root);
        boolean clicked = false;
        try {
            if (target != null) clicked = clickNavigationNode(target);
        } finally {
            if (target != null) target.recycle();
            root.recycle();
        }
        if (clicked) {
            invalidateNavigationPageHint();
            if (completion != null) completion.accept("已先执行左上角返回；等待上一层页面");
            return true;
        }

        // The accepted-job page in current DeliverThat builds draws this arrow without a
        // clickable Accessibility node. Only a freshly proven accepted-job detail page may use
        // the physical top-left hotspot captured from that layout.
        if (confirmedJobDetail && !rootBounds.isEmpty()) {
            float x = rootBounds.left + rootBounds.width() * 0.125f;
            float y = rootBounds.top + rootBounds.height() * 0.075f;
            if (dispatchNavigationGesture(service, rootBounds, x, y,
                    "POST_CLAIM_BACK_GESTURE 已点击左上角返回热区",
                    completion, mismatch)) return true;
        }

        // Keep Android Back as the last compatibility fallback. It is reached only from the
        // confirmed post-claim transaction owned by OcrMonitorService.
        if (OcrMonitorService.isManualInterventionPaused()) {
            if (mismatch != null) mismatch.accept("人工操作暂停中");
            return false;
        }
        clicked = service.performGlobalAction(GLOBAL_ACTION_BACK);
        if (clicked) {
            invalidateNavigationPageHint();
            if (completion != null) completion.accept("左上角控件不可用；已执行系统Back并等待上一层");
        } else if (mismatch != null) mismatch.accept("左上角返回/系统Back均未执行");
        return clicked;
    }

    public static boolean clickOffersNavigationFromOtherTab(Consumer<String> completion) {
        return clickOffersNavigation(completion, null, true, false, false, null);
    }

    public static boolean clickOffersNavigation(Consumer<String> completion, Consumer<String> mismatch) {
        return clickOffersNavigation(completion, mismatch, false, false, false, null);
    }

    static boolean clickOffersRecoveryNavigation(boolean preferGesture, java.util.function.BooleanSupplier mayNavigate,
                                                  Consumer<String> completion,
                                                  Consumer<String> mismatch) {
        return clickOffersNavigation(completion, mismatch, false, true, preferGesture, mayNavigate);
    }

    private static boolean clickOffersNavigation(Consumer<String> completion, Consumer<String> mismatch,
                                                  boolean requireOtherTab, boolean recovery,
                                                  boolean preferGesture, java.util.function.BooleanSupplier mayNavigate) {
        if (OcrMonitorService.isManualInterventionPaused()) {
            if (mismatch != null) mismatch.accept("人工操作暂停中");
            return false;
        }
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept("DeliverThat不在前台；未寻找Offers");
            return false;
        }
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) {
            if (mismatch != null) mismatch.accept("上一层根节点不可用；未找到Offers");
            return false;
        }
        Rect rootBounds = new Rect();
        root.getBoundsInScreen(rootBounds);
        StringBuilder screenText = new StringBuilder();
        collectLimitedText(root, screenText, new int[]{260});
        String raw = screenText.toString();
        String normalized = raw.toLowerCase(Locale.US).replaceAll("\\s+", " ");
        boolean deliveriesHub = normalized.contains("deliveries")
                && normalized.contains("jobs") && normalized.contains("offers")
                && (requireOtherTab || !ClaimSuccessSignals.hasAcceptedJobDetail(raw));
        if (recovery && (!deliveriesHub || root.getPackageName() == null
                || !"com.deliverthat.driver".contentEquals(root.getPackageName())
                || ClaimSuccessSignals.hasBeginDeliveryControl(raw) || !isDeliverThatForeground())) {
            root.recycle();
            if (mismatch != null) mismatch.accept("当前页面未确认导航入口或已进入配送");
            return false;
        }
        if (requireOtherTab) {
            PageGuard.Page livePage = quickPageOf(root, 96, PageGuard.emptyDeliveriesTab(raw));
            // A populated Jobs list may contain prices, delivery steps or Begin Delivery.
            // Such list text is not an accepted-job-detail proof. A fresh clicked-tab hint
            // is only a fallback when RN does not export the selected flag; it still needs
            // current Deliveries chrome and exact navigation geometry to be clickable.
            boolean selectedOtherTab = hasSelectedOtherTabNavigation(root, rootBounds, livePage, raw);
            if (!deliveriesHub || root.getPackageName() == null
                    || !"com.deliverthat.driver".contentEquals(root.getPackageName())
                    || !selectedOtherTab) {
                root.recycle();
                return false;
            }
        }
        AccessibilityNodeInfo target = findOffersNavigationNode(root, recovery ? rootBounds : null);
        Rect targetBounds = new Rect();
        boolean clicked = false;
        boolean exactRecoveryTarget = false;
        try {
            if (target != null) {
                target.getBoundsInScreen(targetBounds);
                exactRecoveryTarget = target.isVisibleToUser() && !targetBounds.isEmpty()
                        && rootBounds.contains(targetBounds.centerX(), targetBounds.centerY())
                        && targetBounds.centerY() < rootBounds.top + rootBounds.height() * 0.42f;
                if ((!recovery || (exactRecoveryTarget && !preferGesture))
                        && (!requireOtherTab || (!targetBounds.isEmpty()
                        && rootBounds.contains(targetBounds.centerX(), targetBounds.centerY())
                        && targetBounds.centerY() < rootBounds.top + rootBounds.height() * 0.42f))
                        && !OcrMonitorService.isManualInterventionPaused()
                        && (mayNavigate == null || mayNavigate.getAsBoolean())) {
                    automaticNavigationUntil = SystemClock.elapsedRealtime() + 1500L;
                    clicked = clickNavigationNode(target);
                }
            }
        } finally {
            if (target != null) target.recycle();
            root.recycle();
        }
        if (clicked) {
            invalidateNavigationPageHint();
            if (completion != null) completion.accept("已找到并点击Offers；等待Offers页确认");
            return true;
        }

        if (mayNavigate != null && !mayNavigate.getAsBoolean()) return false;
        // Prefer the exact exported Offers bounds when RN exposes text but not ACTION_CLICK.
        if ((!recovery || exactRecoveryTarget) && !targetBounds.isEmpty() && !rootBounds.isEmpty()
                && rootBounds.contains(targetBounds.centerX(), targetBounds.centerY())
                && targetBounds.centerY() < rootBounds.top + rootBounds.height() * 0.42f) {
            if (dispatchNavigationGesture(service, rootBounds,
                    targetBounds.exactCenterX(), targetBounds.exactCenterY(),
                    "POST_CLAIM_OFFERS_GESTURE 已点击中间Offers入口",
                    completion, mismatch)) return true;
        }

        // Screenshot-calibrated fallback for the Deliveries hub. Requiring all three labels
        // prevents this coordinate from ever being used on an offer card or assigned-job page.
        if (!recovery && !requireOtherTab && deliveriesHub && !rootBounds.isEmpty()) {
            float x = rootBounds.left + rootBounds.width() * 0.385f;
            float y = rootBounds.top + rootBounds.height() * 0.173f;
            if (dispatchNavigationGesture(service, rootBounds, x, y,
                    "POST_CLAIM_OFFERS_GESTURE 已点击中间Offers热区",
                    completion, mismatch)) return true;
        }
        if (mismatch != null) mismatch.accept(targetBounds.isEmpty()
                ? "上一层暂未证明Deliveries/Jobs/Offers导航页"
                : "Offers入口存在但点击未执行");
        return false;
    }

    /**
     * v2.10.120 unavailable recovery: leave the stale Offers card through the exact Jobs tab.
     * This deliberately has no coordinate fallback; only a live Deliveries/Jobs/Offers hub and
     * an exported exact Jobs node may authorize the navigation.
     */
    public static boolean clickJobsNavigation(Consumer<String> completion, Consumer<String> mismatch) {
        if (OcrMonitorService.isManualInterventionPaused()) {
            if (mismatch != null) mismatch.accept("人工操作暂停中");
            return false;
        }
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept("DeliverThat不在前台；未执行Jobs离场");
            return false;
        }
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) {
            if (mismatch != null) mismatch.accept("当前根节点不可用；未执行Jobs离场");
            return false;
        }
        StringBuilder screenText = new StringBuilder();
        collectLimitedText(root, screenText, new int[]{260});
        String raw = screenText.toString();
        String normalized = raw.toLowerCase(Locale.US).replaceAll("\\s+", " ");
        boolean deliveriesHub = normalized.contains("deliveries")
                && normalized.contains("jobs") && normalized.contains("offers")
                && !ClaimSuccessSignals.hasAcceptedJobDetail(raw);
        AccessibilityNodeInfo target = deliveriesHub ? findJobsNavigationNode(root) : null;
        boolean clicked = false;
        try {
            if (target != null && !OcrMonitorService.isManualInterventionPaused()) {
                automaticNavigationUntil = SystemClock.elapsedRealtime() + 1500L;
                clicked = clickNavigationNode(target);
            }
        } finally {
            if (target != null) target.recycle();
            root.recycle();
        }
        if (clicked) {
            invalidateNavigationPageHint();
            if (completion != null) completion.accept("已点击Jobs离开失效Offer；等待返回Offers");
            return true;
        }
        if (mismatch != null) mismatch.accept(deliveriesHub
                ? "Jobs入口存在但点击未执行" : "当前页未同时证明Deliveries/Jobs/Offers导航");
        return false;
    }

    /** Exceptional post-claim probe; never used on the normal Offer fast path. */
    public static boolean isPostClaimJobDetailVisible() {
        if (hasFreshBeginDeliveryOcr(null)) return true;
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        StringBuilder screenText = new StringBuilder();
        try {
            collectLimitedText(root, screenText, new int[]{260});
        } finally {
            root.recycle();
        }
        String raw = screenText.toString();
        return ClaimSuccessSignals.hasAcceptedJobDetail(raw)
                || ClaimSuccessSignals.hasBeginDeliveryControl(raw);
    }

    private static void invalidateNavigationPageHint() {
        beginDeliveryOcrProof = null;
        UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
        pageHint = PageGuard.Page.UNKNOWN;
        pageHintAt = 0L;
    }

    private static boolean dispatchNavigationGesture(TapAccessibilityService service,
                                                     Rect rootBounds, float x, float y,
                                                     String detail,
                                                     Consumer<String> completion,
                                                     Consumer<String> mismatch) {
        if (service == null || rootBounds == null || rootBounds.isEmpty()
                || !rootBounds.contains(Math.round(x), Math.round(y))) {
            if (mismatch != null) mismatch.accept("导航热区越界；未点击");
            return false;
        }
        if (OcrMonitorService.isManualInterventionPaused()) {
            if (mismatch != null) mismatch.accept("人工操作暂停中");
            return false;
        }
        automaticNavigationUntil = SystemClock.elapsedRealtime() + 1500L;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 45L))
                .build();
        boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                invalidateNavigationPageHint();
                if (completion != null) completion.accept(detail + " Gesture45ms tap=("
                        + Math.round(x) + "," + Math.round(y) + ")");
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                if (mismatch != null) mismatch.accept("系统取消导航手势：" + detail);
            }
        }, service.main);
        if (!dispatched && mismatch != null) mismatch.accept("系统未接受导航手势：" + detail);
        return dispatched;
    }

    private static boolean clickNavigationNode(AccessibilityNodeInfo node) {
        Rect targetBounds = new Rect(); node.getBoundsInScreen(targetBounds);
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(node);
        try {
            for (int depth = 0; depth < 6 && current != null; depth++) {
                if (OcrMonitorService.isManualInterventionPaused()) return false;
                Rect currentBounds = new Rect(); current.getBoundsInScreen(currentBounds);
                if (currentBounds.isEmpty() || currentBounds.width() > Math.max(240, targetBounds.width() * 3)
                        || currentBounds.height() > Math.max(160, targetBounds.height() * 3)) return false;
                if (current.isVisibleToUser() && current.isEnabled()
                        && (current.isClickable()
                        || (current.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0)
                        && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }
            return false;
        } finally { if (current != null) current.recycle(); }
    }

    private static AccessibilityNodeInfo findBackNavigationNode(AccessibilityNodeInfo root) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> candidates = new ArrayList<>();
        collectNavigationNodes(root, candidates);
        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo n : candidates) {
            String label = nodeLabel(n);
            if (!(label.contains("back") || label.contains("navigate up") || label.contains("返回")))
                continue;
            Rect b = new Rect(); n.getBoundsInScreen(b);
            int score = Math.max(0, b.centerX()) + Math.max(0, b.centerY());
            if (best == null || score < bestScore) {
                if (best != null) best.recycle();
                best = AccessibilityNodeInfo.obtain(n);
                bestScore = score;
            }
        }
        for (AccessibilityNodeInfo n : candidates) n.recycle();
        return best;
    }

    /** Strong current hub proof for automatic Jobs/Ignored -> Offers recovery. */
    private static boolean hasSelectedOtherTabNavigation(AccessibilityNodeInfo root,
                                                          Rect bounds, PageGuard.Page page, String raw) {
        if(root==null || bounds==null || bounds.isEmpty()) return false;
        long now=SystemClock.elapsedRealtime();
        boolean clickedRecently=lastOtherHubTabClickAt>0L && now>=lastOtherHubTabClickAt
                && now-lastOtherHubTabClickAt<=4_500L
                && UI_GENERATION.get()>=lastOtherHubTabClickGeneration;
        if(page==PageGuard.Page.UNKNOWN && clickedRecently)
            page=lastOtherHubTabClick; // still requires live row and no current Offers selection
        if(page!=PageGuard.Page.JOBS && page!=PageGuard.Page.IGNORED) return false;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();
        collectNavigationNodes(root,nodes);
        Rect active=new Rect(), offers=new Rect();
        boolean activeSelected=false, offersFound=false, offersSelected=false;
        Rect jobsPeer=new Rect();
        try {
            for(AccessibilityNodeInfo n:nodes) {
                if(!n.isVisibleToUser()) continue;
                Rect b=new Rect();n.getBoundsInScreen(b);
                if(b.isEmpty() || !bounds.contains(b.centerX(),b.centerY())
                        || b.centerY()>=bounds.top+bounds.height()*0.42f) continue;
                String label=nodeLabel(n);
                if(label.equals("offers")) {
                    offers.set(b);offersFound=true;
                    offersSelected |= n.isSelected() || n.isChecked();
                }
                if(label.equals("jobs")) jobsPeer.set(b);
                if((page==PageGuard.Page.JOBS && label.equals("jobs"))
                        || (page==PageGuard.Page.IGNORED && label.equals("ignored"))) {
                    if(n.isSelected() || n.isChecked()) {active.set(b);activeSelected=true;}
                }
            }
            // A selected Jobs tab is direct proof. If RN omits selected entirely,
            // allow an explicit Jobs-empty sentence OR a recent real Jobs tab click,
            // but never when the current Offers tab is visibly selected.
            boolean emptyOtherTab = PageGuard.emptyDeliveriesTab(raw)==page;
            boolean clickProof = clickedRecently && lastOtherHubTabClick==page;
            if(offersSelected) return false;
            // Ignored is icon-only on some builds. Preserve the previous independent
            // IGNORED/Restore page proof when its current Jobs + Offers nav row exists.
            if(page==PageGuard.Page.IGNORED && !activeSelected && !emptyOtherTab
                    && !clickProof && !jobsPeer.isEmpty() && offersFound
                    && jobsPeer.centerX()<offers.centerX()
                    && Math.abs(jobsPeer.centerY()-offers.centerY())
                        <=Math.max(jobsPeer.height(),offers.height())) return true;
            if(!activeSelected && !emptyOtherTab && !clickProof) return false;
            if(!activeSelected) {
                // Find the physical nonselected tab's bounds for safe row geometry.
                for(AccessibilityNodeInfo n:nodes) {
                    if(!n.isVisibleToUser()) continue;
                    String label=nodeLabel(n);
                    if((page==PageGuard.Page.JOBS && label.equals("jobs"))
                            || (page==PageGuard.Page.IGNORED && label.equals("ignored"))) {
                        Rect b=new Rect();n.getBoundsInScreen(b);
                        if(!b.isEmpty() && bounds.contains(b.centerX(),b.centerY())
                                && b.centerY()<bounds.top+bounds.height()*0.42f) {
                            active.set(b);break;
                        }
                    }
                }
            }
            return !active.isEmpty() && offersFound
                    && Math.abs(active.centerY()-offers.centerY())
                        <=Math.max(active.height(),offers.height())
                    && (page!=PageGuard.Page.JOBS || active.centerX()<offers.centerX());
        } finally {
            for(AccessibilityNodeInfo n:nodes) n.recycle();
        }
    }

    private static AccessibilityNodeInfo findOffersNavigationNode(AccessibilityNodeInfo root, Rect recoveryBounds) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> candidates = new ArrayList<>();
        collectNavigationNodes(root, candidates);
        AccessibilityNodeInfo best = null;
        int bestScore = -1;
        for (AccessibilityNodeInfo n : candidates) {
            String s = nodeLabel(n);
            if ("offers".equals(s) || (recoveryBounds == null && "offer".equals(s))) {
                if (recoveryBounds != null) {
                    Rect bounds = new Rect();
                    n.getBoundsInScreen(bounds);
                    if (!n.isVisibleToUser() || bounds.isEmpty()
                            || !recoveryBounds.contains(bounds.centerX(), bounds.centerY())
                            || bounds.centerY() >= recoveryBounds.top + recoveryBounds.height() * 0.42f)
                        continue;
                }
                Rect offer = new Rect(); n.getBoundsInScreen(offer);
                if (!n.isVisibleToUser() || offer.isEmpty()) continue;
                int score = 0;
                for (AccessibilityNodeInfo peer : candidates) {
                    if (!peer.isVisibleToUser()) continue;
                    String label = nodeLabel(peer);
                    if (!label.equals("jobs") && !label.equals("ignored")) continue;
                    Rect tab = new Rect(); peer.getBoundsInScreen(tab);
                    if (!tab.isEmpty() && Math.abs(tab.centerY()-offer.centerY())
                            <= Math.max(tab.height(),offer.height())) {
                        if (label.equals("jobs") && tab.centerX()<offer.centerX()) score += 2;
                        if (label.equals("ignored") && tab.centerX()>offer.centerX()) score += 2;
                    }
                }
                if (score > bestScore) {
                    if (best != null) best.recycle();
                    best = AccessibilityNodeInfo.obtain(n); bestScore = score;
                }
            }
        }
        for (AccessibilityNodeInfo n : candidates) n.recycle();
        if (recoveryBounds != null && bestScore < 2) {
            if (best != null) best.recycle();
            return null;
        }
        return best;
    }

    private static AccessibilityNodeInfo findJobsNavigationNode(AccessibilityNodeInfo root) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> candidates = new ArrayList<>();
        collectNavigationNodes(root, candidates);
        AccessibilityNodeInfo best = null;
        for (AccessibilityNodeInfo n : candidates) {
            if ("jobs".equals(nodeLabel(n))) {
                best = AccessibilityNodeInfo.obtain(n);
                break;
            }
        }
        for (AccessibilityNodeInfo n : candidates) n.recycle();
        return best;
    }

    private static void collectNavigationNodes(AccessibilityNodeInfo node,
                                                List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        String s = nodeLabel(node);
        if (!s.isEmpty() && (s.equals("offer") || s.equals("offers") || s.equals("jobs") || s.equals("ignored")
                || s.contains("back") || s.contains("navigate up") || s.contains("返回"))) {
            out.add(AccessibilityNodeInfo.obtain(node));
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectNavigationNodes(child, out);
                child.recycle();
            }
        }
    }

    private static String nodeLabel(AccessibilityNodeInfo node) {
        if (node == null) return "";
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        String s = text != null ? text.toString() : (desc == null ? "" : desc.toString());
        return s.toLowerCase(Locale.US).replaceAll("\\s+", " ").trim();
    }

    public static boolean tapLargeOrderPopupClose(Rect closeBounds, long evidenceAt,
                                                   Consumer<String> completion,
                                                   Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || closeBounds == null || closeBounds.isEmpty()) {
            if (mismatch != null) mismatch.accept("Large Order说明层X热区不可用");
            return false;
        }
        long now = SystemClock.elapsedRealtime();
        long age = Math.max(0L, now - evidenceAt);
        if (age > 900L || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept("Large Order说明层证据已过期或DeliverThat不在前台");
            return false;
        }
        // OCR itself is valid popup evidence. The tree hint is an independent bonus, not a
        // requirement, because React-Native occasionally keeps the tooltip text out of AX.
        if (!largeOrderPopupRecentlyVisible(1400L)) {
            if (mismatch != null) mismatch.accept("Large Order说明层证据已失效；未点X");
            return false;
        }
        // One physical popup owns one close gesture. OCR can finish several frames while the
        // React-Native layer animates away; a late frame must not send a second gesture onto
        // the restored offer card.
        if (now - largeOrderPopupCloseAttemptAt < LARGE_ORDER_CLOSE_SINGLE_FLIGHT_MS) return true;

        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null || !"com.deliverthat.driver".contentEquals(
                root.getPackageName() == null ? "" : root.getPackageName())) {
            if (root != null) root.recycle();
            if (mismatch != null) mismatch.accept("点X前DeliverThat窗口已变化");
            return false;
        }
        Rect rootBounds = new Rect();
        root.getBoundsInScreen(rootBounds);
        root.recycle();
        float x = closeBounds.exactCenterX(), y = closeBounds.exactCenterY();
        int minX = rootBounds.left + Math.round(rootBounds.width() * 0.65f);
        int minY = rootBounds.top + Math.round(rootBounds.height() * 0.22f);
        int maxY = rootBounds.top + Math.round(rootBounds.height() * 0.86f);
        if (!rootBounds.contains(Math.round(x), Math.round(y))
                || x < minX || y < minY || y > maxY) {
            if (mismatch != null) mismatch.accept("Large Order说明层X坐标异常；未点击");
            return false;
        }

        largeOrderPopupCloseAttemptAt = now;
        UI_GENERATION.incrementAndGet();PRESSURE_LAYOUT_EPOCH.incrementAndGet();
        lastDecisionEvidence = null;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 45L))
                .build();
        boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                if (completion != null) completion.accept("Gesture45ms rect=" + rectString(closeBounds)
                        + " tap=(" + Math.round(x) + "," + Math.round(y) + ")");
                service.main.postDelayed(() -> {
                    if (largeOrderPopupCloseAttemptAt == now) largeOrderPopupHintAt = 0;
                    OcrMonitorService.requestImmediateFastCheck(SystemClock.uptimeMillis());
                }, 520L);
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                if (largeOrderPopupCloseAttemptAt == now) largeOrderPopupCloseAttemptAt = 0L;
                if (mismatch != null) mismatch.accept("系统取消Large Order说明层X手势");
            }
        }, service.main);
        if (!dispatched) {
            if (largeOrderPopupCloseAttemptAt == now) largeOrderPopupCloseAttemptAt = 0L;
            if (mismatch != null) mismatch.accept("系统未接受Large Order说明层X手势");
        }
        return dispatched;
    }

    private void queueDirectCheck() {
        Handler worker = directWorker;
        if (worker == null) return;
        if (OcrMonitorService.isManualInterventionPaused()) return;
        if (OcrMonitorService.isMonitoring()) return; // the foreground monitor owns decisions when running
        if (!directQueued.compareAndSet(false, true)) return;
        worker.post(() -> {
            try { processStandaloneAccessibility(); }
            finally { directQueued.set(false); }
        });
    }

    /**
     * v2.10: true NovaFlow-style Accessibility-only execution path. It keeps working
     * even when MediaProjection/OCR is not started or was revoked by an APK update.
     * The screen-capture service remains an optional fallback, not a prerequisite.
     */
    private void processStandaloneAccessibility() {
        if (OcrMonitorService.isManualInterventionPaused()) return;
        long now = SystemClock.elapsedRealtime();
        if (now < directCooldownUntil || !isDeliverThatForeground()) return;
        // v2.10.16: DeliverThat's React-Native build can leave the Offers tab/page
        // classifier at UNKNOWN even while a fully readable offer card and its action row
        // are on screen. Do not discard the structural snapshot before we build it.
        // Explicit JOBS/IGNORED still block actions; UNKNOWN is allowed only when
        // getFastOfferSnapshots() independently proves money+miles+button structure.
        PageGuard.Page page = activePage();
        if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) return;
        List<FastOfferSnapshot> cards = getFastOfferSnapshots();
        if (cards.isEmpty()) return;

        android.content.SharedPreferences rules = getSharedPreferences("rules", MODE_PRIVATE);
        // v2.10.3: serial queue. Only the first visible card is ever actionable.
        // Once it disappears the next card naturally moves into this slot and is rescanned.
        FastOfferSnapshot selected = cards.get(0);
        float topAmount = directAmount(selected.text), topMiles = directMiles(selected.text);
        if (topAmount < 0 || topMiles < 0) return;
        String topFailure = directRuleFailure(selected.text, rules, topAmount, topMiles);
        if (topFailure.isEmpty()) {
            QualifiedOfferAlert.notifyIfNeeded(this, rules, selected.text, topAmount, topMiles);
            if (selected.acceptBounds.isEmpty()
                    || !directClaimBudget.available(CardText.identity(selected.text), now)) return;
        } else {
            String rejectId = directRejectSequence.bindObservation(selected.text, now);
            directRejectSequence.noteVisible(rejectId, now);
            if (!rules.getBoolean("autoIgnore", true) || selected.rejectBounds.isEmpty() || !selected.rejectEnabled
                    || directRejectSequence.observe(rejectId, now)
                    != RejectSequence.State.READY) return;
        }
        float amount = directAmount(selected.text), miles = directMiles(selected.text);
        String failure = directRuleFailure(selected.text, rules, amount, miles);
        String ruleAudit = PasadenaRuleGuard.auditTag(selected.text,
                rules.getBoolean("pasadenaRuleEnabled", false));
        boolean accept = failure.isEmpty();
        if (rules.getBoolean("dryRun", false)) {
            directCooldownUntil = now + 1500;
            writeDirectStatus("无障碍直通测试：$" + String.format(Locale.US,
                    "%.2f / %.1f mi；未点击；%s", amount, miles, ruleAudit));
            return;
        }

        String id = accept ? CardText.identity(selected.text)
                : directRejectSequence.bindObservation(selected.text, now);
        final int directRejectAttempt;
        if (accept) {
            if (directClaimBudget.reserve(id, now) == 0) return;
            directRejectAttempt = 0;
        } else {
            // Foreground direct mode may only originate Reject attempt #1. The service-owned
            // final rescue is the only path allowed to reserve attempt #2 after a fresh recheck.
            directRejectAttempt = directRejectSequence.reserveFirstIfReady(id, now);
            if (directRejectAttempt == 0) return;
        }
        directCooldownUntil = now + 700;
        Rect target = accept ? selected.acceptBounds : selected.rejectBounds;
        tapVerified(accept, target.exactCenterX(), target.exactCenterY(), amount, miles,
                selected.text, false, false,
                () -> {
                    writeDirectStatus(accept
                            ? String.format(Locale.US, "无障碍Accept已发送：$%.2f / %.1f mi；%s", amount, miles, ruleAudit)
                            : String.format(Locale.US, "无障碍Ignore第%d次已发送：$%.2f / %.1f mi；%s", directRejectAttempt, amount, miles, ruleAudit));
                    directCooldownUntil = SystemClock.elapsedRealtime() + 220;
                }, reason -> {
                    if (!accept) directRejectSequence.failed(id, SystemClock.elapsedRealtime());
                    writeDirectStatus((accept ? "无障碍Accept未执行：" : "无障碍Ignore未执行：") + reason);
                    directCooldownUntil = 0;
                });
    }

    private static float directAmount(String text) {
        if (text == null) return -1f;
        String normalized = text.replace(',', '.');
        java.util.regex.Matcher range = LIVE_MONEY_RANGE.matcher(normalized);
        if (range.find()) try { return Float.parseFloat(range.group(1)); } catch (Exception ignored) { }
        java.util.regex.Matcher one = LIVE_MONEY.matcher(normalized);
        if (one.find()) try { return Float.parseFloat(one.group(1)); } catch (Exception ignored) { }
        return -1f;
    }

    private static float directMiles(String text) {
        if (text == null) return -1f;
        java.util.regex.Matcher m = LIVE_MILES.matcher(text.replace(',', '.'));
        if (!m.find()) return -1f;
        try { return Float.parseFloat(m.group(1)); } catch (Exception ignored) { return -1f; }
    }

    private static String directRuleFailure(String text, android.content.SharedPreferences prefs,
                                            float amount, float miles) {
        String lower = text == null ? "" : text.toLowerCase(Locale.US);
        boolean pasadenaEnabled = prefs.getBoolean("pasadenaRuleEnabled", false);
        boolean pasadenaSpecial = pasadenaEnabled && PasadenaRuleGuard.isPasadenaOffer(text);
        float minimum = prefs.getFloat("minPay", 60f);
        float maximumMiles = prefs.getFloat("maxMiles", 10f);
        if (pasadenaSpecial) {
            minimum = prefs.getFloat("pasadenaMinPay", 25f);
            maximumMiles = prefs.getFloat("pasadenaMaxMiles", 5f);
        }
        if (amount < minimum || miles > maximumMiles)
            return pasadenaSpecial ? "Pasadena专属金额/里程不符合" : "普通金额/里程不符合";

        if (!pasadenaSpecial) {
            String configured = prefs.getString("cities", "").trim().toLowerCase(Locale.US);
            if (!configured.isEmpty()) {
                boolean ok = false;
                for (String city : configured.split(",")) {
                    String clean = city.trim();
                    if (!clean.isEmpty() && lower.contains(clean)) { ok = true; break; }
                }
                if (!ok) return "城市不符合";
            }
        }

        String startValue = prefs.getString("startTime", "").trim();
        String endValue = prefs.getString("endTime", "").trim();
        if (!startValue.isEmpty() && !endValue.isEmpty()) {
            try {
                java.util.regex.Matcher matcher = LIVE_OFFER_TIME.matcher(text);
                if (!matcher.find()) return "订单时间不符合";
                DateTimeFormatter offerFormat = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
                LocalTime offer = LocalTime.parse(matcher.group(1) + " "
                        + matcher.group(2).toUpperCase(Locale.US), offerFormat);
                DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
                LocalTime start = LocalTime.parse(startValue, f), end = LocalTime.parse(endValue, f);
                boolean allowed = end.isAfter(start) || end.equals(start)
                        ? !offer.isBefore(start) && !offer.isAfter(end)
                        : !offer.isBefore(start) || !offer.isAfter(end);
                if (!allowed) return "订单时间不符合";
            } catch (Exception ignored) { return "订单时间不符合"; }
        }
        return "";
    }

    private void writeDirectStatus(String status) {
        try {
            getSharedPreferences("rules", MODE_PRIVATE).edit()
                    .putString("lastStatus", status)
                    .putLong("lastStatusAt", System.currentTimeMillis())
                    .apply();
        } catch (RuntimeException ignored) { }
    }

    public static boolean isConnected() {
        return INSTANCE.get() != null;
    }

    public enum ForegroundState { DELIVERTHAT, OTHER_APP, UNKNOWN }

    public static ForegroundState deliverThatForegroundState() {
        TapAccessibilityService service=INSTANCE.get();
        if(service==null) return ForegroundState.UNKNOWN;
        AccessibilityNodeInfo root=null;
        try {
            root=service.getRootInActiveWindow();
            if(root==null || root.getPackageName()==null || root.getPackageName().length()==0)
                return ForegroundState.UNKNOWN;
            // A temporary system surface cannot prove that the user switched apps.
            // UNKNOWN suspends all clicks and lets the existing bounded navigation poll resume.
            CharSequence pkg = root.getPackageName();
            if ("com.android.systemui".contentEquals(pkg) || "android".contentEquals(pkg))
                return ForegroundState.UNKNOWN;
            return "com.deliverthat.driver".contentEquals(pkg)
                    ? ForegroundState.DELIVERTHAT : ForegroundState.OTHER_APP;
        } catch(RuntimeException unreadable) { return ForegroundState.UNKNOWN; }
        finally {if(root!=null) root.recycle();}
    }

    static boolean hasDeliverThatReplayForegroundHint() {
        return "com.deliverthat.driver".equals(foregroundPackage);
    }

    public static boolean isDeliverThatForeground() {
        return deliverThatForegroundState()==ForegroundState.DELIVERTHAT;
    }

    public static PageGuard.Page activePage() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return PageGuard.Page.UNKNOWN;
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return PageGuard.Page.UNKNOWN;
        PageGuard.Page page = pageFromScan(scan);
        updatePageHint(page);
        return page;
    }

    /**
     * Cheap page hint used by the OCR coordinate fallback. A full multi-window tree scan
     * on this Galaxy A15 has been observed to take ~400-800 ms, so the action path must
     * not repeat it after OCR has already located the current offer.
     */
    public static PageGuard.Page recentPageHint() {
        long now = SystemClock.elapsedRealtime();
        return pageHintAt > 0 && now >= pageHintAt && now - pageHintAt <= 1800
                ? pageHint : PageGuard.Page.UNKNOWN;
    }

    /**
     * v2.10.130 independent completion proof for stale-offer recovery.  Navigation clicks
     * intentionally invalidate the cached page hint, so confirmation must be able to use the
     * current live tree instead of waiting for the same hint that the click just erased.
     */
    public static boolean hasCurrentOffersSurfaceEvidence() {
        return hasCurrentOffersSurfaceEvidence(false);
    }

    static boolean hasCurrentOffersSurfaceEvidence(boolean requireClearPage) {
        return readOffersNavigationSurface(requireClearPage) == OffersNavigationSurface.OFFERS;
    }

    enum OffersNavigationSurface { OFFERS, JOBS, IGNORED, STALE_OFFER, DELIVERY, UNKNOWN }

    static OffersNavigationSurface readOffersNavigationSurface(boolean requireClearPage) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return OffersNavigationSurface.UNKNOWN;
        long generation=UI_GENERATION.get(), epoch=WINDOW_TRANSITION_EPOCH.get();
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return OffersNavigationSurface.UNKNOWN;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return OffersNavigationSurface.UNKNOWN;
            boolean[] flags = new boolean[7];
            StringBuilder visibleText = new StringBuilder();
            collectRecoveryPageFlags(root, flags, visibleText);
            if(generation!=UI_GENERATION.get() || epoch!=WINDOW_TRANSITION_EPOCH.get())
                return OffersNavigationSurface.UNKNOWN;
            String raw = visibleText.toString();
            if (ClaimSuccessSignals.hasAcceptedJobDetail(raw)
                    || ClaimSuccessSignals.hasBeginDeliveryControl(raw)) return OffersNavigationSurface.DELIVERY;
            if (requireClearPage && flags[1] && !flags[2]) return OffersNavigationSurface.JOBS;
            if (requireClearPage && (flags[0] || flags[3]) && !flags[2])
                return OffersNavigationSurface.IGNORED;
            String lower = raw.toLowerCase(Locale.US).replace(',', '.');
            boolean offerNumbers = LIVE_MONEY.matcher(lower).find() && LIVE_MILES.matcher(lower).find();
            // The live list can already be empty while a terminal toast remains visible.
            // React Native may omit the selected tab state while exporting the empty sentence.
            if (flags[6] && !offerNumbers && !flags[0] && !flags[1] && !flags[3]) {
                updatePageHint(PageGuard.Page.OFFERS);
                return OffersNavigationSurface.OFFERS;
            }
            if (requireClearPage
                    && ClaimSuccessSignals.isTerminalNegative(ClaimSuccessSignals.extractOutcomeHint(raw)))
                return OffersNavigationSurface.STALE_OFFER;
            PageGuard.Page page = PageGuard.classify(flags[0], flags[1], flags[2],
                    flags[3], flags[4], flags[5], flags[6]);
            if (page == PageGuard.Page.UNKNOWN) page = fallbackPageFromTreeText(raw);
            if (page == PageGuard.Page.OFFERS) {
                updatePageHint(page);
                return OffersNavigationSurface.OFFERS;
            }
            boolean deliveriesHub = lower.contains("deliveries")
                    && lower.contains("jobs") && lower.contains("offers");
            boolean currentOffer = offerNumbers && (flags[4] || flags[5]);
            boolean emptyOffers = flags[6] && deliveriesHub;
            if (currentOffer || emptyOffers) updatePageHint(PageGuard.Page.OFFERS);
            if (currentOffer || emptyOffers) return OffersNavigationSurface.OFFERS;
            if (page == PageGuard.Page.JOBS) return OffersNavigationSurface.JOBS;
            if (page == PageGuard.Page.IGNORED) return OffersNavigationSurface.IGNORED;
            return OffersNavigationSurface.UNKNOWN;
        } catch (RuntimeException ignored) {
            return OffersNavigationSurface.UNKNOWN;
        } finally {
            root.recycle();
        }
    }

    private static void updatePageHint(PageGuard.Page page) {
        if (page == null) page = PageGuard.Page.UNKNOWN;
        pageHint = page;
        pageHintAt = SystemClock.elapsedRealtime();
    }

    private static PageGuard.Page pageOf(AccessibilityNodeInfo root) {
        boolean[] flags = new boolean[7];
        StringBuilder visibleText = new StringBuilder();
        collectPageFlags(root, flags, visibleText);
        PageGuard.Page page = PageGuard.classify(flags[0], flags[1], flags[2], flags[3], flags[4], flags[5], flags[6]);
        updateClaimUiCaches(visibleText.toString());
        if (page != PageGuard.Page.UNKNOWN) return page;
        return fallbackPageFromTreeText(visibleText.toString());
    }

    private static PageGuard.Page fallbackPageFromTreeText(String text) {
        if (text == null) return PageGuard.Page.UNKNOWN;
        if (ClaimSuccessSignals.hasAcceptedJobDetail(text)) return PageGuard.Page.JOBS;
        String lower = text.toLowerCase(Locale.US).replace(',', '.');
        boolean hasMoney = LIVE_MONEY.matcher(lower).find();
        boolean hasMiles = LIVE_MILES.matcher(lower).find();
        // DeliverThat's Offers page exposes offer-specific tree text even on builds where
        // the Offers tab does not report selected=true and the action labels are blank.
        // "Exclusive" / "Expires" are strong offer-page evidence and are not used on Jobs.
        if ((lower.contains("exclusive") && lower.contains("offer"))
                || (lower.contains("expires") && hasMoney && hasMiles)) return PageGuard.Page.OFFERS;
        return PageGuard.emptyDeliveriesTab(text);
    }

    private static void collectPageFlags(AccessibilityNodeInfo node, boolean[] flags, StringBuilder visibleText) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean usable = node.isVisibleToUser() || !bounds.isEmpty()
                || node.isSelected() || node.isChecked() || node.isClickable();
        if (usable) {
            for (CharSequence value : new CharSequence[]{node.getText(), node.getContentDescription()}) {
                if (value == null) continue;
                visibleText.append(value).append(' ');
                String label = lettersOnlyLower(value);
                if (node.isSelected() || node.isChecked()) {
                    if (label.equals("ignored")) flags[0] = true;
                    if (label.equals("jobs")) flags[1] = true;
                    if (label.equals("offers") || label.startsWith("offers")) flags[2] = true;
                }
                if (label.equals("restore") || label.equals("restorebutton")) flags[3] = true;
                if (ButtonLabels.isReject(value)) flags[4] = true;
                if (matchesAccept(value)) flags[5] = true;
                if (EmptyOffersPolicy.isExplicitEmpty(value.toString())) flags[6] = true;
            }
        }
        // Do not prune an entire subtree just because an intermediate WebView/Compose
        // container reports isVisibleToUser=false. Several DeliverThat builds do exactly
        // that while their descendants still carry useful accessibility semantics.
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectPageFlags(child, flags, visibleText); child.recycle(); }
        }
    }

    private static void collectRecoveryPageFlags(AccessibilityNodeInfo node, boolean[] flags, StringBuilder visibleText) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean usable = node.isVisibleToUser() && !bounds.isEmpty();
        if (usable) {
            for (CharSequence value : new CharSequence[]{node.getText(), node.getContentDescription()}) {
                if (value == null) continue;
                visibleText.append(value).append(' ');
                String label = lettersOnlyLower(value);
                if (node.isSelected() || node.isChecked()) {
                    if (label.equals("ignored")) flags[0] = true;
                    if (label.equals("jobs")) flags[1] = true;
                    if (label.equals("offers") || label.startsWith("offers")) flags[2] = true;
                }
                if (label.equals("restore") || label.equals("restorebutton")) flags[3] = true;
                if (ButtonLabels.isReject(value)) flags[4] = true;
                if (matchesAccept(value)) flags[5] = true;
                if (EmptyOffersPolicy.isExplicitEmpty(value.toString())) flags[6] = true;
            }
        }
        // Do not prune an entire subtree just because an intermediate WebView/Compose
        // container reports isVisibleToUser=false. Several DeliverThat builds do exactly
        // that while their descendants still carry useful accessibility semantics.
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectRecoveryPageFlags(child, flags, visibleText); child.recycle(); }
        }
    }

    public static String debugTreeSummary() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return "辅助服务未连接";
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return "前台非DeliverThat或无活动窗口树";
        PageGuard.Page page = pageFromScan(scan);
        return "树页=" + page + "；窗口=" + scan.windowsScanned
                + "；文本块=" + scan.pieces.size() + "；可点击=" + scan.clickables.size()
                + "；语义Accept=" + scan.accepts.size() + "；语义Reject=" + scan.rejects.size();
    }

    public static FastOfferSnapshot getFastOfferSnapshot() {
        List<FastOfferSnapshot> cards = getFastOfferSnapshots();
        return cards.isEmpty() ? null : cards.get(0);
    }

    private static final ThreadLocal<String> ROUTING_READ_TRACE=ThreadLocal.withInitial(() -> "NOT_READ");
    private static final ThreadLocal<FallbackReadScope> FALLBACK_READ_SCOPE=new ThreadLocal<>();
    private static final class FallbackReadScope {
        final long deadline,generation,windowEpoch;
        final TapAccessibilityService service;
        final java.util.function.BooleanSupplier mayRun;
        volatile boolean cancelled;
        PageGuard.Page quickPage = PageGuard.Page.UNKNOWN;
        String quickText = "";
        FallbackReadScope(TapAccessibilityService owner,long budget,java.util.function.BooleanSupplier allow) {
            service=owner; deadline=SystemClock.elapsedRealtime()+Math.max(1L,budget-2L);
            generation=UI_GENERATION.get();windowEpoch=WINDOW_TRANSITION_EPOCH.get();mayRun=allow;
        }
        boolean sameScene() {
            return !cancelled && INSTANCE.get() == service && generation == UI_GENERATION.get()
                    && windowEpoch == WINDOW_TRANSITION_EPOCH.get() && mayRun.getAsBoolean();
        }

        boolean current() {
            return sameScene() && SystemClock.elapsedRealtime() < deadline;
        }
    }
    private static final class FallbackReadExpired extends RuntimeException { }
    private static void checkFallbackRead() {
        FallbackReadScope scope=FALLBACK_READ_SCOPE.get();
        if(scope!=null && !scope.current()) throw new FallbackReadExpired();
    }
    public static String routingReadTrace() { return ROUTING_READ_TRACE.get(); }

    private static <T> T readScanFallback(long budget, java.util.function.BooleanSupplier mayRun,
            java.util.function.Supplier<T> reader, String phase) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !mayRun.getAsBoolean()) {
            ROUTING_READ_TRACE.set(phase + "_YIELD");
            return null;
        }
        FallbackReadScope scope = new FallbackReadScope(service, budget, mayRun);
        BoundedReadBatch.Read<T> job = new BoundedReadBatch.Read<T>() {
            public T read() {
                FALLBACK_READ_SCOPE.set(scope);
                try {
                    checkFallbackRead();
                    T value = reader.get();
                    checkFallbackRead();
                    return value;
                } finally {
                    FALLBACK_READ_SCOPE.remove();
                }
            }
            public void close() { }
        };
        try (BoundedReadBatch.Pending<T> pending =
                     service.fallbackDeadlineReads.begin(java.util.Collections.singletonList(job), budget)) {
            BoundedReadBatch.Result<T> result = pending.takeOneWhile(scope::sameScene);
            boolean current = scope.current();
            String reason = !scope.sameScene() ? "YIELD"
                    : !current ? "BUDGET" : result.reason;
            ROUTING_READ_TRACE.set(phase + "_" + reason);
            if (!current || !result.complete()) return null;
            if (scope.quickPage != PageGuard.Page.UNKNOWN) updatePageHint(scope.quickPage);
            if (!scope.quickText.isEmpty()) cacheDecisionEvidence(scope.quickText, scope.generation);
            return result.values.get(0);
        } finally {
            scope.cancelled = true;
        }
    }

    static final class FullScanResult {
        final List<FastOfferSnapshot> cards;
        final PageGuard.Page page;
        final String visibleTop;
        final boolean explicitEmpty;

        FullScanResult(List<FastOfferSnapshot> cards, PageGuard.Page page,
                       String visibleTop, boolean explicitEmpty) {
            this.cards = cards;
            this.page = page;
            this.visibleTop = visibleTop;
            this.explicitEmpty = explicitEmpty;
        }
    }

    /** Read cards, page and optional locked-top evidence from one bounded traversal. */
    static FullScanResult getBoundedFastOfferSnapshots(long budget, boolean readLockedTop,
            java.util.function.BooleanSupplier mayRun) {
        return readScanFallback(budget, mayRun, () -> {
            TapAccessibilityService service = FALLBACK_READ_SCOPE.get().service;
            WindowScan scan = new WindowScan();
            if (!scanDeliverThatWindows(service, scan)) return null;
            checkFallbackRead();
            PageGuard.Page page = pageFromScan(scan);
            List<FastOfferSnapshot> cards = buildFastOfferSnapshots(scan, page);
            String top = !cards.isEmpty() ? cards.get(0).text
                    : readLockedTop ? topVisibleOfferText(scan) : "";
            boolean empty = page == PageGuard.Page.OFFERS && scan.flags[6]
                    && cards.isEmpty() && scan.accepts.isEmpty() && scan.rejects.isEmpty()
                    && !LIVE_MONEY.matcher(scan.visibleText).find()
                    && !LIVE_MILES.matcher(scan.visibleText).find();
            return new FullScanResult(cards, page, top, empty);
        }, "FULL");
    }

    static void publishFullScanPage(FullScanResult full) {
        updatePageHint(full.page);
    }

    static QuickTopResult getBoundedQuickTopOfferSnapshot(long budget,
            java.util.function.BooleanSupplier mayRun) {
        QuickTopResult quick = readScanFallback(budget, mayRun,
                TapAccessibilityService::getQuickTopOfferSnapshotResult, "QUICK");
        return quick != null ? quick : new QuickTopResult(null, true, 0, false, routingReadTrace());
    }

    /** Current top Reject with a live match to the event's numeric pair. */
    public static FastOfferSnapshot getBoundedNumericRejectSnapshot(float pay, float miles,
            boolean numericOnly, boolean requireTime, java.util.function.BooleanSupplier mayRun) {
        return readBoundedRejectIndex(40L, !numericOnly, !numericOnly && requireTime,
                numericOnly ? (a, b) -> true : null,
                snapshot -> quickNumericPairMatches(snapshot.text, pay, miles),
                mayRun, "NUMERIC", null);
    }

    static FastOfferSnapshot getBoundedCurrentRejectSnapshot(boolean requireLocation, boolean requireTime,
            java.util.function.BiPredicate<Float, Float> numericReject, StringBuilder phases,
            long budget, java.util.function.BooleanSupplier mayRun) {
        return readBoundedRejectIndex(budget, requireLocation, requireTime, numericReject,
                snapshot -> snapshot.rejectEnabled, mayRun, "REJECT", phases);
    }

    private static FastOfferSnapshot readBoundedRejectIndex(long budget,
            boolean requireLocation, boolean requireTime,
            java.util.function.BiPredicate<Float, Float> numericReject,
            java.util.function.Predicate<FastOfferSnapshot> acceptResult,
            java.util.function.BooleanSupplier mayRun, String phase, StringBuilder output) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !mayRun.getAsBoolean()) {
            ROUTING_READ_TRACE.set(phase + "_YIELD");
            if (output != null) output.append("=YIELD");
            return null;
        }
        long generation = UI_GENERATION.get(), epoch = WINDOW_TRANSITION_EPOCH.get();
        java.util.function.BooleanSupplier current = () -> mayRun.getAsBoolean()
                && generation == UI_GENERATION.get() && epoch == WINDOW_TRANSITION_EPOCH.get()
                && INSTANCE.get() == service;
        RejectReadProgress progress = new RejectReadProgress(SystemClock.elapsedRealtime(), budget, true);
        StringBuilder readPhases = new StringBuilder();
        BoundedReadBatch.Read<FastOfferSnapshot> read = new BoundedReadBatch.Read<FastOfferSnapshot>() {
            public FastOfferSnapshot read() {
                REJECT_READ_PROGRESS.set(progress);
                progress.workerAt = SystemClock.elapsedRealtime();
                try {
                    if (!current.getAsBoolean()) return null;
                    AccessibilityNodeInfo cached = recentIndexedRoot(
                            service, generation, SystemClock.elapsedRealtime(), epoch);
                    if (cached != null) {
                        REJECT_READ_ROOT.set(cached);
                        progress.rootAt = SystemClock.elapsedRealtime();
                    }
                    FastOfferSnapshot snapshot = getIndexedCurrentTopRejectSnapshot(
                            requireLocation, requireTime, budget, numericReject, readPhases);
                    return current.getAsBoolean() && progress.mayRead(SystemClock.elapsedRealtime())
                            && snapshot != null && acceptResult.test(snapshot) ? snapshot : null;
                } finally {
                    AccessibilityNodeInfo root = REJECT_READ_ROOT.get();
                    REJECT_READ_ROOT.remove();
                    REJECT_READ_PROGRESS.remove();
                    if (root != null) root.recycle();
                }
            }
            public void close() { }
        };
        try (BoundedReadBatch.Pending<FastOfferSnapshot> pending =
                     service.numericDeadlineReads.begin(java.util.Collections.singletonList(read), budget)) {
            BoundedReadBatch.Result<FastOfferSnapshot> result = pending.takeOneWhile(current);
            boolean coherent = current.getAsBoolean();
            boolean finished = result.complete() || "REFRESH_FAILED".equals(result.reason);
            String detail = !coherent ? "STALE" : "REFRESH_FAILED".equals(result.reason)
                    ? (readPhases.indexOf("NO_REJECT_ACTION") >= 0 ? "NO_REJECT_ACTION" : "NO_MATCH")
                    : result.reason;
            ROUTING_READ_TRACE.set(phase + "_" + detail);
            if (output != null) {
                if (finished && coherent && readPhases.length() > 0) output.append(readPhases);
                else output.append('=').append(detail);
            }
            return coherent && result.complete() ? result.values.get(0) : null;
        } finally {
            progress.cancelled = true;
        }
    }

    public static List<FastOfferSnapshot> getFastOfferSnapshots() {
        checkFallbackRead();
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return java.util.Collections.emptyList();
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return java.util.Collections.emptyList();
        checkFallbackRead();
        PageGuard.Page page = pageFromScan(scan);
        updatePageHint(page);
        return buildFastOfferSnapshots(scan, page);
    }

    private static List<FastOfferSnapshot> buildFastOfferSnapshots(WindowScan scan, PageGuard.Page page) {
        List<FastOfferSnapshot> cards = new ArrayList<>();
        if (page != PageGuard.Page.OFFERS) {
            String treeText = scan.visibleText.toString();
            boolean hasOfferNumbers = LIVE_MONEY.matcher(treeText).find() && LIVE_MILES.matcher(treeText).find();
            boolean hasActionStructure = !scan.accepts.isEmpty() || !scan.rejects.isEmpty()
                    || scan.clickables.size() >= 2;
            // v2.10: blank-label React-Native/WebView buttons can leave the page classifier
            // at UNKNOWN. Money+miles plus a real action-row structure is sufficient to
            // enter the read-only card builder; the final click still revalidates foreground,
            // card identity and numbers.
            if (!(page == PageGuard.Page.UNKNOWN && hasOfferNumbers && hasActionStructure)) return cards;
        }
        List<ActionHit> anchors = new ArrayList<>(scan.accepts);
        for (ActionHit reject : scan.rejects) {
            boolean paired = false;
            for (ActionHit accept : scan.accepts) if (sameRow(accept.bounds, reject.bounds)) { paired = true; break; }
            if (!paired) anchors.add(reject);
        }
        anchors.sort(java.util.Comparator.comparingInt(hit -> hit.bounds.top));
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (ActionHit anchor : anchors) {
            checkFallbackRead();
            Rect accept = new Rect(), reject = new Rect();
            boolean acceptEnabled = false, rejectEnabled = false;
            for (ActionHit candidate : scan.accepts) {
                if (sameRow(candidate.bounds, anchor.bounds)) {
                    accept.set(candidate.bounds); acceptEnabled = candidate.enabled; break;
                }
            }
            for (ActionHit candidate : scan.rejects) {
                if (sameRow(candidate.bounds, anchor.bounds)) {
                    reject.set(candidate.bounds); rejectEnabled = candidate.enabled; break;
                }
            }
            String text = CardText.aboveButton(scan.pieces, anchor.bounds.top, anchor.bounds.bottom);
            if (!CardText.MONEY.matcher(text).find() || !LIVE_MILES.matcher(text).find()) continue;

            // v2.10.8: never "upgrade" a semantic Ignore/Accept label to a larger clickable
            // ancestor. Real recordings showed that DeliverThat marks the entire offer card
            // clickable; v2.10.7 then replaced the correct Ignore label rectangle with the
            // card rectangle and opened details. Keep a semantic rectangle if it is geometrically
            // safe; use structural blank-label buttons only to fill a genuinely missing side.
            if (!accept.isEmpty() && !safeActionBounds(scan.rootBounds, accept, true)) {
                accept.setEmpty(); acceptEnabled = false;
            }
            if (!reject.isEmpty() && !safeActionBounds(scan.rootBounds, reject, false)) {
                reject.setEmpty(); rejectEnabled = false;
            }
            FastOfferSnapshot structuralFill = structuralActionsForText(scan, text);
            if (structuralFill != null) {
                if (accept.isEmpty() && !structuralFill.acceptBounds.isEmpty()
                        && safeActionBounds(scan.rootBounds, structuralFill.acceptBounds, true)) {
                    accept.set(structuralFill.acceptBounds); acceptEnabled = structuralFill.acceptEnabled;
                }
                if (reject.isEmpty() && !structuralFill.rejectBounds.isEmpty()
                        && safeActionBounds(scan.rootBounds, structuralFill.rejectBounds, false)) {
                    reject.set(structuralFill.rejectBounds); rejectEnabled = structuralFill.rejectEnabled;
                }
            }
            if (seen.add(CardText.identity(text)))
                cards.add(new FastOfferSnapshot(text, accept, reject, acceptEnabled, rejectEnabled));
        }

        // Structural Accessibility fallback: some DeliverThat releases expose the two
        // bottom action controls as clickable nodes with blank text/description. In that
        // case v2.9.1 reported zero cards and fell all the way back to ~1s OCR. Pair the
        // clickable controls by row and attach them to the nearest money+miles card text.
        if (cards.isEmpty() && !scan.clickables.isEmpty()) {
            List<ActionHit> structural = new ArrayList<>(scan.clickables);
            structural.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                    .thenComparingInt(hit -> hit.bounds.left));
            for (ActionHit anchor : structural) {
                checkFallbackRead();
                String text = CardText.aboveButton(scan.pieces, anchor.bounds.top, anchor.bounds.bottom);
                if (!CardText.MONEY.matcher(text).find() || !LIVE_MILES.matcher(text).find()) continue;
                String id = CardText.identity(text);
                if (seen.contains(id)) continue;
                FastOfferSnapshot structuralCard = structuralActionsForText(scan, text);
                if (structuralCard != null
                        && (!structuralCard.acceptBounds.isEmpty() || !structuralCard.rejectBounds.isEmpty())) {
                    seen.add(id);
                    cards.add(structuralCard);
                }
            }
        }
        return cards;
    }

    private static boolean sameRow(Rect a, Rect b) {
        return a.top < b.bottom && a.bottom > b.top;
    }

    private static float rectArea(Rect r) {
        if (r == null || r.isEmpty()) return 0f;
        return (float) r.width() * (float) r.height();
    }

    /** v2.10.8: action bounds must be button-sized and stay on the expected side. */
    private static boolean safeActionBounds(Rect rootBounds, Rect bounds, boolean accept) {
        if (rootBounds == null || rootBounds.isEmpty() || bounds == null || bounds.isEmpty()) return false;
        return ActionGeometry.plausibleActionRect(rootBounds.width(), rootBounds.height(),
                bounds.left - rootBounds.left, bounds.top - rootBounds.top,
                bounds.right - rootBounds.left, bounds.bottom - rootBounds.top, accept);
    }

    private static boolean safeStructuralBounds(Rect rootBounds, Rect bounds) {
        if (rootBounds == null || rootBounds.isEmpty() || bounds == null || bounds.isEmpty()) return false;
        return ActionGeometry.plausibleStructuralButton(rootBounds.width(), rootBounds.height(),
                bounds.left - rootBounds.left, bounds.top - rootBounds.top,
                bounds.right - rootBounds.left, bounds.bottom - rootBounds.top);
    }

    private static float safeTapX(Rect rootBounds, Rect bounds, boolean accept) {
        float local = bounds.exactCenterX() - rootBounds.left;
        return rootBounds.left + ActionGeometry.stableTapX(rootBounds.width(), local, accept);
    }

    /** Returns the first visible offer even when its action is missing or disabled. */
    private static String topVisibleOfferText(WindowScan scan) {
        java.util.List<CardText.Piece> pieces = new java.util.ArrayList<>(scan.pieces);
        pieces.sort(java.util.Comparator.comparingDouble((CardText.Piece p) -> p.top)
                .thenComparingDouble(p -> p.left));
        CardText.Piece money = null, miles = null;
        for (CardText.Piece p : pieces) {
            if (money == null && CardText.MONEY.matcher(p.text).find()) money = p;
            if (miles == null && LIVE_MILES.matcher(p.text).find()) miles = p;
            if (money != null && miles != null) {
                float row = Math.max(money.bottom - money.top, miles.bottom - miles.top);
                if (Math.abs(money.top - miles.top) <= Math.max(18f, row * 3f)) break;
                if (money.top < miles.top) money = null; else miles = null;
            }
        }
        if (money == null || miles == null) return "";
        float start = Math.min(money.top, miles.top);
        float end = start + 430f;
        // Stop before the next offer's money/miles row when multiple cards are visible.
        for (CardText.Piece p : pieces) {
            if (p.top <= start + 90f) continue;
            if (CardText.MONEY.matcher(p.text).find() || LIVE_MILES.matcher(p.text).find()) {
                end = Math.min(end, p.top - 4f);
                break;
            }
        }
        StringBuilder out = new StringBuilder();
        for (CardText.Piece p : pieces)
            if (p.top >= start && p.top < end) out.append(p.text).append(' ');
        return out.toString().trim();
    }

    public static FastOfferSnapshot findOffer(String expectedText) {
        for (FastOfferSnapshot card : getFastOfferSnapshots())
            if (CardText.sameOffer(expectedText, card.text)) return card;
        return null;
    }

    // One hierarchy traversal supplies page, button geometry and card text together.
    private static final class ActionHit {
        final Rect bounds;
        final boolean enabled;
        ActionHit(Rect bounds, boolean enabled) { this.bounds = new Rect(bounds); this.enabled = enabled; }
    }

    private static final class WindowScan {
        final boolean[] flags = new boolean[7];
        final List<ActionHit> accepts = new ArrayList<>();
        final List<ActionHit> rejects = new ArrayList<>();
        // v2.9.2+: collect raw clickable/actionable nodes even when their text/contentDescription
        // is blank. Semantics come from hierarchy + geometry first; OCR is only a fallback.
        final List<ActionHit> clickables = new ArrayList<>();
        final List<CardText.Piece> pieces = new ArrayList<>();
        final StringBuilder visibleText = new StringBuilder();
        final Rect rootBounds = new Rect();
        int windowsScanned;
    }

    /**
     * v2.9.3: scan the active DeliverThat window plus any additional interactive
     * DeliverThat windows exposed by Accessibility. React-Native/WebView/Compose builds
     * can split useful descendants across windows even though getRootInActiveWindow()
     * only exposes the shell container.
     *
     * Safety invariant: we still require the ACTIVE window to belong to DeliverThat.
     * Additional windows are used only as extra tree content while DeliverThat is truly
     * foreground, so pulling down notifications cannot accidentally authorize a click.
     */
    private static boolean scanDeliverThatWindows(TapAccessibilityService service, WindowScan scan) {
        if (service == null || scan == null) return false;
        checkFallbackRead();
        AccessibilityNodeInfo active = service.getRootInActiveWindow();
        if (active == null) return false;
        int activeWindowId = Integer.MIN_VALUE;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    active.getPackageName() == null ? "" : active.getPackageName())) return false;
            activeWindowId = active.getWindowId();
            active.getBoundsInScreen(scan.rootBounds);
            scanWindow(active, scan);
            scan.windowsScanned++;
        } finally {
            active.recycle();
        }

        checkFallbackRead();
        try {
            List<AccessibilityWindowInfo> windows = service.getWindows();
            if (windows == null) return true;
            for (AccessibilityWindowInfo window : windows) {
                checkFallbackRead();
                if (window == null) continue;
                // Samsung/React-Native normally returns the active Accessibility root again
                // from getWindows(). v2.10.17 walked that same hierarchy twice, which both
                // inflated card text and cost hundreds of milliseconds in field traces.
                // Keep secondary DeliverThat windows, but never rescan the active window id.
                if (window.getId() == activeWindowId) continue;
                AccessibilityNodeInfo root = null;
                try {
                    root = window.getRoot();
                    if (root == null || root.getWindowId() == activeWindowId
                            || !"com.deliverthat.driver".contentEquals(
                            root.getPackageName() == null ? "" : root.getPackageName())) continue;
                    Rect bounds = new Rect();
                    root.getBoundsInScreen(bounds);
                    if (scan.rootBounds.isEmpty() && !bounds.isEmpty()) scan.rootBounds.set(bounds);
                    scanWindow(root, scan);
                    scan.windowsScanned++;
                } finally {
                    if (root != null) root.recycle();
                }
            }
        } catch (RuntimeException ignored) {
            // Some OEM Accessibility implementations transiently throw while windows are
            // changing. The already-scanned active tree remains usable.
        }
        return true;
    }

    private static PageGuard.Page pageFromScan(WindowScan scan) {
        if (scan == null) return PageGuard.Page.UNKNOWN;
        PageGuard.Page page = PageGuard.classify(scan.flags[0], scan.flags[1], scan.flags[2],
                scan.flags[3], scan.flags[4], scan.flags[5], scan.flags[6]);
        String treeText = scan.visibleText.toString();
        boolean hasMoney = LIVE_MONEY.matcher(treeText).find();
        boolean hasMiles = LIVE_MILES.matcher(treeText).find();
        boolean hasLiveAction = !scan.accepts.isEmpty() || !scan.rejects.isEmpty();
        // v2.10.19: field evidence showed a real Offers card could stay visible for seconds
        // while React-Native exposed a stale selected Jobs/Ignored tab flag.  A live current
        // money+miles card plus a safe Accept/Reject node is stronger evidence than that stale
        // tab bit.  Restore still wins, so the real Ignored page cannot be promoted to Offers.
        if ((page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED)
                && !scan.flags[3] && hasMoney && hasMiles && hasLiveAction) {
            page = PageGuard.Page.OFFERS;
        }
        if (page == PageGuard.Page.UNKNOWN)
            page = fallbackPageFromTreeText(treeText);
        updateClaimUiCaches(treeText);
        return page;
    }

    private static void addUniquePiece(List<CardText.Piece> pieces, String value, Rect bounds) {
        if (pieces == null || value == null || value.isEmpty() || bounds == null || bounds.isEmpty()) return;
        String normalized = compactWhitespace(value);
        if (normalized.isEmpty()) return;
        for (CardText.Piece piece : pieces) {
            if (piece.left == bounds.left && piece.top == bounds.top && piece.bottom == bounds.bottom
                    // Every piece inserted through this helper is already normalized. Avoid
                    // re-running a regex over every previous piece on every node (O(n^2)
                    // regex work was a measurable source of 500ms+ quick-tree scans).
                    && normalized.equals(piece.text)) return;
        }
        pieces.add(new CardText.Piece(normalized, bounds.left, bounds.top, bounds.bottom));
    }

    /** Allocation-light whitespace compaction for the latency-critical accessibility walk. */
    private static String compactWhitespace(CharSequence raw) {
        if (raw == null) return "";
        int length = raw.length();
        StringBuilder out = new StringBuilder(length);
        boolean pendingSpace = false;
        for (int i = 0; i < length; i++) {
            char c = raw.charAt(i);
            if (Character.isWhitespace(c)) {
                if (out.length() > 0) pendingSpace = true;
                continue;
            }
            if (pendingSpace) { out.append(' '); pendingSpace = false; }
            out.append(c);
        }
        return out.toString();
    }

    private static FastOfferSnapshot structuralActionsForText(WindowScan scan, String text) {
        if (scan == null || text == null || text.isEmpty() || scan.clickables.isEmpty()) return null;
        List<ActionHit> row = new ArrayList<>();
        for (ActionHit candidate : scan.clickables) {
            String candidateText = CardText.aboveButton(scan.pieces,
                    candidate.bounds.top, candidate.bounds.bottom);
            if (CardText.sameOffer(text, candidateText)) row.add(candidate);
        }
        if (row.isEmpty()) return null;
        // Keep only the lowest same-row cluster associated with the card. A card container
        // or detail affordance higher up must not be mistaken for the action row.
        row.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                .thenComparingInt(hit -> hit.bounds.left));
        ActionHit lowest = row.get(row.size() - 1);
        List<ActionHit> actionRow = new ArrayList<>();
        for (ActionHit hit : row) if (sameActionRow(hit.bounds, lowest.bounds)) actionRow.add(hit);
        actionRow.sort(java.util.Comparator.comparingInt(hit -> hit.bounds.left));
        if (actionRow.isEmpty()) return null;
        Rect accept = new Rect(), reject = new Rect();
        boolean acceptEnabled = false, rejectEnabled = false;
        int mid = scan.rootBounds.centerX();
        ActionHit right = actionRow.get(actionRow.size() - 1);
        ActionHit left = actionRow.get(ActionRowPolicy.structuralRejectIndex(actionRow.size()));
        if (actionRow.size() >= 2 && right.bounds.centerX() > left.bounds.centerX()) {
            reject.set(left.bounds); rejectEnabled = left.enabled;
            accept.set(right.bounds); acceptEnabled = right.enabled;
        } else {
            ActionHit only = actionRow.get(0);
            if (only.bounds.centerX() >= mid) {
                accept.set(only.bounds); acceptEnabled = only.enabled;
            } else {
                reject.set(only.bounds); rejectEnabled = only.enabled;
            }
        }
        return new FastOfferSnapshot(text, accept, reject, acceptEnabled, rejectEnabled);
    }

    private static boolean sameActionRow(Rect a, Rect b) {
        int tolerance = Math.max(18, Math.max(a.height(), b.height()));
        return Math.abs(a.centerY() - b.centerY()) <= tolerance;
    }

    private static void addUniqueHit(List<ActionHit> hits, Rect bounds, boolean enabled) {
        if (bounds == null || bounds.isEmpty()) return;
        for (ActionHit hit : hits) {
            if (hit.bounds.equals(bounds)) return;
            Rect intersection = new Rect(hit.bounds);
            if (intersection.intersect(bounds)) {
                float overlap = (float) intersection.width() * intersection.height();
                float smaller = Math.min((float) hit.bounds.width() * hit.bounds.height(),
                        (float) bounds.width() * bounds.height());
                if (smaller > 0 && overlap / smaller > 0.92f) return;
            }
        }
        hits.add(new ActionHit(bounds, enabled));
    }

    private static boolean structuralActionShape(AccessibilityNodeInfo node, Rect bounds, Rect rootBounds) {
        if (node == null || bounds == null || bounds.isEmpty() || rootBounds.isEmpty()) return false;
        boolean actionable = node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0
                || (node.getClassName() != null
                    && node.getClassName().toString().toLowerCase(Locale.US).contains("button"));
        if (!actionable) return false;
        if (LargeOrderPopupGuard.isInfoTriggerLabel(node.getText())
                || LargeOrderPopupGuard.isInfoTriggerLabel(node.getContentDescription())) return false;
        // v2.10.8: structural/blank-label nodes are fallback-only. Reject any candidate
        // that resembles the whole offer card, row container, or tiny details arrow.
        return safeStructuralBounds(rootBounds, bounds);
    }

    private static void scanWindow(AccessibilityNodeInfo node, WindowScan scan) {
        if (node == null) return;
        checkFallbackRead();
        CharSequence text = node.getText(), description = node.getContentDescription();
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean intersectsScreen = !bounds.isEmpty() && (scan.rootBounds.isEmpty()
                || Rect.intersects(bounds, scan.rootBounds));
        boolean usable = node.isVisibleToUser() || intersectsScreen
                || node.isSelected() || node.isChecked() || node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0;
        CharSequence value = text == null || text.length() == 0 ? description : text;
        if (usable && value != null) {
            scan.visibleText.append(value).append(' ');
            if (!bounds.isEmpty()) addUniquePiece(scan.pieces, value.toString(), bounds);
        }
        if (usable) {
            boolean acceptMatch = matchesAccept(text) || matchesAccept(description);
            boolean rejectMatch = ButtonLabels.isReject(text) || ButtonLabels.isReject(description);
            boolean selected = node.isSelected() || node.isChecked();
            for (CharSequence labelValue : new CharSequence[]{text, description}) {
                if (labelValue == null) continue;
                String label = lettersOnlyLower(labelValue);
                if (selected) {
                    if (label.equals("ignored")) scan.flags[0] = true;
                    if (label.equals("jobs")) scan.flags[1] = true;
                    if (label.equals("offers") || label.startsWith("offers")) scan.flags[2] = true;
                }
                if (label.equals("restore") || label.equals("restorebutton")) scan.flags[3] = true;
                if (ButtonLabels.isReject(labelValue)) scan.flags[4] = true;
                if (matchesAccept(labelValue)) scan.flags[5] = true;
                if (EmptyOffersPolicy.isExplicitEmpty(labelValue.toString())) scan.flags[6] = true;
            }
            if (!bounds.isEmpty()) {
                // v2.10.22: actionNodeReady() may climb up to six Accessibility parents.
                // v2.10.21 called it for every visible node, so a 130-node quick scan could
                // trigger hundreds of extra binder traversals. Only semantic action candidates
                // need that parent readiness check. Structural buttons are already proven
                // actionable by structuralActionShape(), so enabled state is sufficient.
                if (acceptMatch && safeActionBounds(scan.rootBounds, bounds, true))
                    addUniqueHit(scan.accepts, bounds, actionNodeReady(node));
                if (rejectMatch && safeActionBounds(scan.rootBounds, bounds, false))
                    addUniqueHit(scan.rejects, bounds, actionNodeReady(node));
                if (!acceptMatch && !rejectMatch
                        && structuralActionShape(node, bounds, scan.rootBounds))
                    addUniqueHit(scan.clickables, bounds, node.isEnabled());
            }
        }

        // Always recurse. An invisible intermediate WebView/Compose container must not
        // suppress accessible descendants.
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { try { scanWindow(child, scan); } finally { child.recycle(); } }
        }
    }

    private static boolean findRejectBounds(AccessibilityNodeInfo node, Rect accept, Rect out) {
        if (node == null || !node.isVisibleToUser() || !node.isEnabled()) return false;
        if (ButtonLabels.isReject(node.getText()) || ButtonLabels.isReject(node.getContentDescription())) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (!bounds.isEmpty() && (accept.isEmpty() || (bounds.top < accept.bottom && bounds.bottom > accept.top))) {
                out.set(bounds);
                return true;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = findRejectBounds(child, accept, out);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    private static String cardText(AccessibilityNodeInfo root, Rect button) {
        List<CardText.Piece> pieces = new ArrayList<>();
        collectPieces(root, pieces);
        return CardText.aboveButton(pieces, button.top, button.bottom);
    }

    private static void collectPieces(AccessibilityNodeInfo node, List<CardText.Piece> pieces) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        CharSequence value = node.getText();
        if (value == null || value.length() == 0) value = node.getContentDescription();
        if (value != null && !bounds.isEmpty()) pieces.add(new CardText.Piece(
                value.toString(), bounds.left, bounds.top, bounds.bottom));
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectPieces(child, pieces); child.recycle(); }
        }
    }

    private static void collectSnapshot(AccessibilityNodeInfo node, StringBuilder text, Rect accept) {
        if (node == null || !node.isVisibleToUser()) return;
        CharSequence label = node.getText();
        CharSequence description = node.getContentDescription();
        if (label != null) text.append(label).append(' ');
        if (description != null && !description.equals(label)) text.append(description).append(' ');
        if (accept.isEmpty() && node.isEnabled()
                && (matchesAccept(label) || matchesAccept(description))) node.getBoundsInScreen(accept);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectSnapshot(child, text, accept);
                child.recycle();
            }
        }
    }

    private static boolean matchesAccept(CharSequence value) {
        return value != null && isAcceptLabel(lettersOnlyLower(value));
    }

    /** Allocation-light ASCII label normalization for the Accessibility hot path. */
    private static String lettersOnlyLower(CharSequence raw) {
        if (raw == null) return "";
        StringBuilder out = new StringBuilder(raw.length());
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c >= 'A' && c <= 'Z') c = (char) (c + ('a' - 'A'));
            if (c >= 'a' && c <= 'z') out.append(c);
        }
        return out.toString();
    }

    private static boolean findAcceptBounds(AccessibilityNodeInfo node, Rect out) {
        if (node == null) return false;
        String label = "";
        if (node.getText() != null) label += node.getText().toString();
        if (node.getContentDescription() != null) label += " " + node.getContentDescription();
        String normalized = lettersOnlyLower(label);
        if (isAcceptLabel(normalized)) {
            node.getBoundsInScreen(out);
            if (!out.isEmpty()) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = findAcceptBounds(child, out);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    /** v2.10.9 bounded active-window refresh for a stale first-tap snapshot. */
    private static final class QuickActionProbe {
        final Rect rootBounds = new Rect();
        final List<CardText.Piece> pieces = new ArrayList<>();
        final List<ActionHit> accepts = new ArrayList<>();
        final List<ActionHit> rejects = new ArrayList<>();
        final List<ActionHit> structural = new ArrayList<>();
        final boolean[] flags = new boolean[7];
        boolean sawMoney;
        boolean sawMiles;
        boolean sawLocation;
        boolean sawAction;
        boolean sawJobInstructions;
        boolean sawBeginDelivery;
        boolean sawJobTimeline;
        boolean sawDeliveriesHub;
        boolean sawOffersLabel;
        boolean sawJobsLabel;
        boolean sawApprover;
        boolean sawNuid;
        boolean sawGlString;
        long startedAt;
        long deadlineAt;
        int visited;
        boolean budgetExceeded;
        boolean completeTraversal;
    }

    /** Result object keeps the quick-tree timeout local to this one scan. */
    public static final class QuickTopResult {
        public final FastOfferSnapshot snapshot;
        public final boolean budgetExceeded;
        public final int visited;
        public final boolean emptyOffers;
        public final boolean emptyContradicted;
        public final String limitReason;

        QuickTopResult(FastOfferSnapshot snapshot, boolean budgetExceeded, int visited) {
            this(snapshot, budgetExceeded, visited, false);
        }

        QuickTopResult(FastOfferSnapshot snapshot, boolean budgetExceeded, int visited, boolean emptyOffers) {
            this(snapshot, budgetExceeded, visited, emptyOffers, budgetExceeded ? "UNSPECIFIED" : "NONE");
        }

        QuickTopResult(FastOfferSnapshot snapshot, boolean budgetExceeded, int visited,
                       boolean emptyOffers, String limitReason) {
            this(snapshot, budgetExceeded, visited, emptyOffers, limitReason, false);
        }

        QuickTopResult(FastOfferSnapshot snapshot, boolean budgetExceeded, int visited,
                       boolean emptyOffers, String limitReason, boolean emptyContradicted) {
            this.emptyContradicted = emptyContradicted;
            this.snapshot = snapshot;
            this.limitReason = limitReason;
            this.budgetExceeded = budgetExceeded;
            this.visited = visited;
            this.emptyOffers = emptyOffers;
        }
    }

    /**
     * Re-read only a bounded prefix of the ACTIVE DeliverThat Accessibility tree.  This is
     * deliberately much cheaper than getFastOfferSnapshots(): no secondary windows, no full
     * page/card reconstruction, no OCR.  A stale coordinate is revived only when the current
     * top action row still carries the exact same low-end pay and mileage values.
     */
    /**
     * v2.10.18 latency path: build only the CURRENT first offer from a bounded active-window
     * prefix. This avoids the expensive multi-window/full-tree scan when the Galaxy A15
     * already exposes the first card and its action row in the active React-Native tree.
     *
     * Safety: the quick path still blocks explicit Jobs/Ignored, requires a top numeric pair,
     * button-sized left/right geometry, and returns only the action row belonging to that
     * top numeric pair. Callers may fall back to the full scan/OCR when text is incomplete.
     */
    /**
     * v2.10.22 qualified-offer latency path. Android's Accessibility text index can jump
     * straight to the visible Accept/Claim label without walking ~130 unrelated React-Native
     * nodes. From that semantic label we climb only a few ancestors and reuse a card-level
     * contentDescription when it already contains pay+miles+pickup details.
     *
     * This is intentionally Accept-only: if the indexed node or ancestor text is incomplete,
     * callers fall back to the existing bounded quick tree. Reject remains on the conservative
     * structural path because an extra 100-200ms on a rejected offer does not cost the user a
     * valuable claim, while a false left-side action would.
     */
    /**
     * v2.10.56 same-generation qualified Accept lane.
     *
     * The event cache already owns complete pay/miles/location/time for the CURRENT
     * Accessibility generation. Instead of rebuilding those fields from the full card
     * ancestors, query only the live Accept/Claim action and verify that its local ancestor
     * still carries the same numeric pair. The current live button rectangle is always used.
     *
     * This method never evaluates user thresholds and never returns a Reject action.
     */
    public static FastOfferSnapshot getSameGenerationQualifiedAcceptSnapshot(
            DecisionEvidence evidence) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || evidence == null || evidence.identity.isEmpty()) return null;
        long generation = UI_GENERATION.get();
        long now = SystemClock.elapsedRealtime();
        if (evidence.uiGeneration != generation
                || now < evidence.capturedAt || now - evidence.capturedAt > 360L) return null;

        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return null;
        try {
            if (UI_GENERATION.get() != generation) return null;
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return null;
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            if (rootBounds.isEmpty()) return null;

            FastOfferSnapshot best = null;
            int bestTop = Integer.MAX_VALUE;
            String[] queries = new String[]{"Accept", "Claim"};
            for (String query : queries) {
                List<AccessibilityNodeInfo> indexed = null;
                try {
                    indexed = root.findAccessibilityNodeInfosByText(query);
                    if (indexed == null || indexed.isEmpty()) continue;
                    for (AccessibilityNodeInfo seed : indexed) {
                        if (seed == null || !(matchesAccept(seed.getText())
                                || matchesAccept(seed.getContentDescription()))) continue;
                        AccessibilityNodeInfo action = resolveIndexedAction(seed, rootBounds, true);
                        if (action == null) continue;
                        try {
                            Rect actionBounds = new Rect();
                            action.getBoundsInScreen(actionBounds);
                            if (!safeActionBounds(rootBounds, actionBounds, true)
                                    || actionBounds.top >= bestTop || !actionNodeReady(action)) continue;

                            // Cheap same-card proof only: no address/time reconstruction here.
                            String local = indexedCardTextFromAncestors(
                                    action, rootBounds, false, false);
                            if (!quickNumericPairMatches(local, evidence.amount, evidence.miles))
                                continue;
                            if (!CardText.compatiblePartialActionEvidence(evidence.text, local))
                                continue;
                            if (UI_GENERATION.get() != generation) return null;

                            bestTop = actionBounds.top;
                            best = new FastOfferSnapshot(evidence.text, actionBounds, new Rect(),
                                    true, false, SystemClock.elapsedRealtime());
                        } finally {
                            action.recycle();
                        }
                    }
                } finally {
                    if (indexed != null)
                        for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
                }
                if (best != null) break;
            }
            if (UI_GENERATION.get() != generation) return null;
            return best;
        } catch (RuntimeException ignored) {
            return null;
        } finally {
            root.recycle();
        }
    }

    public static FastOfferSnapshot getIndexedTopAcceptSnapshot() {
        return getIndexedTopActionSnapshot(true, true, false);
    }

    /** v2.10.27: caller supplies only evidence requirements, never threshold shortcuts. */
    public static FastOfferSnapshot getIndexedTopAcceptSnapshot(boolean requireLocation,
                                                                 boolean requireOfferTime) {
        return getIndexedTopActionSnapshot(true, requireLocation, requireOfferTime);
    }

    /** v2.10.22 semantic-index Reject sibling of the Accept fast path. */
    public static FastOfferSnapshot getIndexedTopRejectSnapshot() {
        return getIndexedTopActionSnapshot(false, true, false);
    }

    public static FastOfferSnapshot getIndexedTopRejectSnapshot(boolean requireLocation,
                                                                 boolean requireOfferTime) {
        return getIndexedTopActionSnapshot(false, requireLocation, requireOfferTime);
    }

    private static FastOfferSnapshot getIndexedTopActionSnapshot(boolean accept, boolean requireLocation,
                                                                 boolean requireOfferTime) {
        return getBoundedIndexedTopActionSnapshot(accept, requireLocation, requireOfferTime, 45L, () -> true);
    }

    static FastOfferSnapshot getBoundedIndexedTopActionSnapshot(boolean accept, boolean requireLocation,
            boolean requireOfferTime, long budget, java.util.function.BooleanSupplier mayRun) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || budget <= 0L) return null;
        long generation = UI_GENERATION.get(), epoch = WINDOW_TRANSITION_EPOCH.get();
        java.util.function.BooleanSupplier current = () -> mayRun.getAsBoolean() && INSTANCE.get() == service
                && generation == UI_GENERATION.get() && epoch == WINDOW_TRANSITION_EPOCH.get();
        if (!current.getAsBoolean()) return null;
        BoundedReadBatch.Read<FastOfferSnapshot> job = new BoundedReadBatch.Read<FastOfferSnapshot>() {
            public FastOfferSnapshot read() {
                return current.getAsBoolean() ? readIndexedTopActionSnapshot(accept, requireLocation, requireOfferTime) : null;
            }
            public void close() { }
        };
        try (BoundedReadBatch.Pending<FastOfferSnapshot> pending =
                     service.actionDeadlineReads.begin(java.util.Collections.singletonList(job), budget)) {
            BoundedReadBatch.Result<FastOfferSnapshot> read = pending.takeOneWhile(current);
            return read.complete() && current.getAsBoolean() ? read.values.get(0) : null;
        }
    }

    private static FastOfferSnapshot readIndexedTopActionSnapshot(boolean accept, boolean requireLocation,
                                                                       boolean requireOfferTime) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return null;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return null;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return null;
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            if (rootBounds.isEmpty()) return null;

            String[] queries = accept ? new String[]{"Accept", "Claim"}
                    : new String[]{"Ignore", "Decline", "Reject"};
            for (String query : queries) {
                FastOfferSnapshot hit = indexedTopActionForQuery(root, rootBounds, query, accept,
                        requireLocation, requireOfferTime);
                if (hit != null) return hit;
            }
            return null;
        } catch (RuntimeException ignored) {
            // OEM Accessibility indexes can transiently fail while React-Native replaces the
            // offer card. The ordinary bounded tree scan is the deterministic fallback.
            return null;
        } finally {
            root.recycle();
        }
    }

    private static FastOfferSnapshot indexedTopActionForQuery(AccessibilityNodeInfo root,
                                                               Rect rootBounds, String query,
                                                               boolean accept, boolean requireLocation,
                                                               boolean requireOfferTime) {
        List<AccessibilityNodeInfo> indexed = null;
        long readStartedAt=SystemClock.elapsedRealtime(),generation=UI_GENERATION.get();
        try {
            indexed = root.findAccessibilityNodeInfosByText(query);
            if (indexed == null || indexed.isEmpty()) return null;
            FastOfferSnapshot best = null;
            int bestTop = Integer.MAX_VALUE;
            for (AccessibilityNodeInfo seed : indexed) {
                if (seed == null) continue;
                boolean labelMatch = accept
                        ? (matchesAccept(seed.getText()) || matchesAccept(seed.getContentDescription()))
                        : (ButtonLabels.isReject(seed.getText()) || ButtonLabels.isReject(seed.getContentDescription()));
                if (!labelMatch) continue;
                AccessibilityNodeInfo action = resolveIndexedAction(seed, rootBounds, accept);
                if (action == null) continue;
                try {
                    Rect actionBounds = new Rect();
                    action.getBoundsInScreen(actionBounds);
                    if (!safeActionBounds(rootBounds, actionBounds, accept)) continue;
                    String cardText = indexedCardTextFromAncestors(action, rootBounds,
                            requireLocation, requireOfferTime);
                    if(generation!=UI_GENERATION.get()) return null;
                    cacheDecisionEvidence(cardText, generation);
                    if (ClaimSuccessSignals.hasAcceptedJobDetail(cardText)
                            || !LIVE_MONEY.matcher(cardText).find() || !LIVE_MILES.matcher(cardText).find())
                        continue;
                    if (actionBounds.top >= bestTop) continue;
                    bestTop = actionBounds.top;
                    Rect acceptBounds = new Rect(), rejectBounds = new Rect();
                    boolean acceptEnabled = false, rejectEnabled = false;
                    if (accept) {
                        acceptBounds.set(actionBounds);
                        acceptEnabled = actionNodeReady(action);
                    } else {
                        rejectBounds.set(actionBounds);
                        rejectEnabled = actionNodeReady(action);
                    }
                    best = new FastOfferSnapshot(cardText, acceptBounds, rejectBounds,
                            acceptEnabled, rejectEnabled, SystemClock.elapsedRealtime());
                    if(!accept) best.rejectReadStartedAt=readStartedAt;
                } finally {
                    action.recycle();
                }
            }
            if(generation!=UI_GENERATION.get()) return null;
            if (accept && best != null) noteIndexedAcceptAnchor(best);
            return best;
        } finally {
            if (indexed != null) {
                for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
            }
        }
    }


    /**
     * v2.10.29 Reject Fast-Exit: the Accept text index already proved the current top card and
     * its right-side action in tens of milliseconds. For an ineligible card, reuse that exact
     * anchor to locate only the left-side action in the SAME local action row instead of walking
     * the 180-node quick tree and then the full window. This never changes rule evaluation: the
     * caller must already have a complete decision-ready Accept snapshot and a failing rule.
     */
    public static FastOfferSnapshot getPairedRejectSnapshotFromIndexedAccept(
            FastOfferSnapshot acceptSnapshot) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || acceptSnapshot == null || acceptSnapshot.acceptBounds.isEmpty())
            return null;
        long age = SystemClock.elapsedRealtime() - acceptSnapshot.capturedAt;
        if (FastSnapshotPolicy.hardExpired(age)) return null;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return null;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return null;
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            if (rootBounds.isEmpty()
                    || !safeActionBounds(rootBounds, acceptSnapshot.acceptBounds, true)) return null;

            String[] queries = new String[]{"Accept", "Claim"};
            for (String query : queries) {
                List<AccessibilityNodeInfo> indexed = null;
                try {
                    indexed = root.findAccessibilityNodeInfosByText(query);
                    if (indexed == null) continue;
                    for (AccessibilityNodeInfo seed : indexed) {
                        if (seed == null || !(matchesAccept(seed.getText())
                                || matchesAccept(seed.getContentDescription()))) continue;
                        AccessibilityNodeInfo action = resolveIndexedAction(seed, rootBounds, true);
                        if (action == null) continue;
                        try {
                            Rect liveAccept = new Rect();
                            action.getBoundsInScreen(liveAccept);
                            if (!samePhysicalAction(liveAccept, acceptSnapshot.acceptBounds)) continue;
                            // Re-prove the same amount+mileage on the live Accept ancestor before
                            // trusting a left-side sibling. This prevents a fast card swap from
                            // reusing the previous card's row coordinates.
                            String liveText = indexedCardTextFromAncestors(action, rootBounds,
                                    false, false);
                            if (!quickNumericPairMatches(liveText,
                                    acceptSnapshot.amount, acceptSnapshot.miles)) continue;

                            ActionHit reject = findPairedRejectInLocalAncestors(
                                    action, liveAccept, rootBounds);
                            if (reject == null) continue;
                            Rect acceptBounds = new Rect(liveAccept);
                            Rect rejectBounds = new Rect(reject.bounds);
                            return new FastOfferSnapshot(acceptSnapshot.text,
                                    acceptBounds, rejectBounds,
                                    actionNodeReady(action), reject.enabled,
                                    SystemClock.elapsedRealtime());
                        } finally { action.recycle(); }
                    }
                } finally {
                    if (indexed != null)
                        for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
                }
            }
            return null;
        } catch (RuntimeException ignored) {
            return null;
        } finally { root.recycle(); }
    }

    private static boolean samePhysicalAction(Rect live, Rect expected) {
        if (live == null || expected == null || live.isEmpty() || expected.isEmpty()) return false;
        Rect overlap = new Rect(live);
        if (overlap.intersect(expected)) {
            float intersection = (float) overlap.width() * overlap.height();
            float smaller = Math.min((float) live.width() * live.height(),
                    (float) expected.width() * expected.height());
            if (smaller > 0 && intersection / smaller >= 0.55f) return true;
        }
        float dx = Math.abs(live.exactCenterX() - expected.exactCenterX());
        float dy = Math.abs(live.exactCenterY() - expected.exactCenterY());
        return dx <= Math.max(24f, expected.width() * 0.28f)
                && dy <= Math.max(18f, expected.height() * 0.45f);
    }

    private static ActionHit findPairedRejectInLocalAncestors(AccessibilityNodeInfo acceptAction,
                                                               Rect acceptBounds,
                                                               Rect rootBounds) {
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(acceptAction);
        try {
            for (int depth = 0; depth < 5 && current != null; depth++) {
                AccessibilityNodeInfo parent = current.getParent();
                if (parent == null) break;
                Rect parentBounds = new Rect();
                parent.getBoundsInScreen(parentBounds);
                current.recycle();
                current = parent;
                if (parentBounds.isEmpty()
                        || !parentBounds.contains(acceptBounds.centerX(), acceptBounds.centerY())) continue;
                // Never expand into the whole page/list. The candidate must remain inside a
                // compact ancestor around the anchored action row.
                if (parentBounds.height() > Math.max(320, (int) (rootBounds.height() * 0.45f))) break;
                ActionHit hit = findPairedRejectInSubtree(current, acceptBounds, rootBounds,
                        new int[]{48});
                if (hit != null) return hit;
            }
            return null;
        } finally { if (current != null) current.recycle(); }
    }

    private static ActionHit findPairedRejectInSubtree(AccessibilityNodeInfo node,
                                                        Rect acceptBounds, Rect rootBounds,
                                                        int[] budget) {
        if (node == null || budget[0]-- <= 0) return null;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        if (!bounds.isEmpty()) {
            boolean rejectLabel = ButtonLabels.isReject(node.getText())
                    || ButtonLabels.isReject(node.getContentDescription());
            // This paired fast lane must remain semantic. A structural Large Order row may be
            // [info, Ignore, Accept]; taking the first structural control left of Accept opened
            // the info popup instead of rejecting the offer in the real $69.65 trace.
            if (rejectLabel
                    && safeActionBounds(rootBounds, bounds, false)
                    && sameRow(bounds, acceptBounds)
                    && bounds.exactCenterX() < acceptBounds.exactCenterX()) {
                return new ActionHit(bounds, actionNodeReady(node));
            }
            // Prune unrelated branches aggressively. A nested candidate must either intersect
            // the action-row band or contain that row vertically.
            int band = Math.max(48, acceptBounds.height() * 2);
            if (bounds.bottom < acceptBounds.top - band
                    || bounds.top > acceptBounds.bottom + band) return null;
        }
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try {
                    ActionHit hit = findPairedRejectInSubtree(child, acceptBounds, rootBounds, budget);
                    if (hit != null) return hit;
                } finally { child.recycle(); }
            }
        }
        return null;
    }

    /** Return an owned node whose bounds are a real side-specific action button. */
    private static AccessibilityNodeInfo resolveIndexedAction(AccessibilityNodeInfo seed,
                                                                Rect rootBounds, boolean accept) {
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(seed);
        for (int depth = 0; depth < 4 && current != null; depth++) {
            Rect bounds = new Rect();
            current.getBoundsInScreen(bounds);
            if (safeActionBounds(rootBounds, bounds, accept)) return current;
            if (depth == 3) break;
            AccessibilityNodeInfo parent = current.getParent();
            current.recycle();
            current = parent;
        }
        if (current != null) current.recycle();
        return null;
    }

    /** A Reject caption may already have valid bounds but belong to a separate action node. */
    private static AccessibilityNodeInfo resolveIndexedRejectAction(AccessibilityNodeInfo seed,Rect rootBounds) {
        Rect label=new Rect();
        seed.getBoundsInScreen(label);
        if (!seed.isVisibleToUser()) return null;
        if (safeActionBounds(rootBounds,label,false) && nodeIsActionable(seed))
            return AccessibilityNodeInfo.obtain(seed);
        return resolveIndexedRejectParent(seed,rootBounds,label,seed.getWindowId(),new Rect());
    }

    private static AccessibilityNodeInfo resolveIndexedRejectParent(AccessibilityNodeInfo seed,Rect rootBounds,
            Rect label,int window,Rect resolvedBounds) {
        int x=label.centerX(),y=label.centerY();
        AccessibilityNodeInfo geometry=null;
        if (safeActionBounds(rootBounds,label,false)) {
            geometry=AccessibilityNodeInfo.obtain(seed);
            resolvedBounds.set(label);
        }
        AccessibilityNodeInfo current=null;
        try {
            current=seed.getParent();
            Rect bounds=new Rect();
            for (int depth=1;depth<4 && current!=null;depth++) {
                if (current.getWindowId()!=window || !current.isVisibleToUser()) break;
                current.getBoundsInScreen(bounds);
                if (safeActionBounds(rootBounds,bounds,false) && bounds.contains(x,y)) {
                    if (nodeIsActionable(current)) {
                        resolvedBounds.set(bounds);
                        return AccessibilityNodeInfo.obtain(current);
                    }
                    if (geometry==null) {
                        geometry=AccessibilityNodeInfo.obtain(current);
                        resolvedBounds.set(bounds);
                    }
                }
                if (depth==3) break;
                AccessibilityNodeInfo parent=current.getParent();
                current.recycle();
                current=parent;
            }
            AccessibilityNodeInfo result=geometry;
            geometry=null;
            return result;
        } finally {
            if (current!=null) current.recycle();
            if (geometry!=null) geometry.recycle();
        }
    }

    /**
     * React-Native commonly exports the whole card as one ancestor contentDescription and
     * repeats its children below it. Prefer that already-materialized string rather than
     * traversing all descendants again.
     */
    private static String indexedCardTextFromAncestors(AccessibilityNodeInfo action, Rect rootBounds,
                                                        boolean requireLocation,
                                                        boolean requireOfferTime) {
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(action);
        AccessibilityNodeInfo localCardRoot = null;
        String bestNumeric = "";
        Rect actionBounds = new Rect();
        action.getBoundsInScreen(actionBounds);
        boolean foundNumericAncestor = false;
        try {
            for (int depth = 0; depth < 8 && current != null; depth++) {
                String own = ownNodeText(current);
                boolean hasNumericPair = !own.isEmpty()
                        && LIVE_MONEY.matcher(own).find() && LIVE_MILES.matcher(own).find();
                if (hasNumericPair) {
                    foundNumericAncestor = true;
                    if (bestNumeric.isEmpty() || own.length() > bestNumeric.length()) bestNumeric = own;
                    if (indexedEvidenceComplete(own, requireLocation, requireOfferTime)) return own;
                }

                // v2.10.27 First-Shot Fast Lane: after the semantic Accept index has already
                // anchored the CURRENT action, retain only a plausible card ancestor. If the
                // ancestor's own contentDescription is missing address/time, we can scan this
                // small local subtree instead of walking the entire React-Native window.
                if (foundNumericAncestor && plausibleIndexedCardRoot(current, actionBounds, rootBounds)) {
                    if (localCardRoot != null) localCardRoot.recycle();
                    localCardRoot = AccessibilityNodeInfo.obtain(current);
                }

                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }

            if (localCardRoot != null) {
                String local = indexedCardTextFromLocalSubtree(localCardRoot, actionBounds);
                if (!local.isEmpty() && LIVE_MONEY.matcher(local).find()
                        && LIVE_MILES.matcher(local).find()) {
                    // Completeness is still rechecked by OcrMonitorService using the exact
                    // active rule configuration. Returning partial text here is safe: it merely
                    // falls through to the existing quick-tree/OCR path.
                    if (indexedEvidenceComplete(local, requireLocation, requireOfferTime)) return local;
                    if (local.length() > bestNumeric.length()) bestNumeric = local;
                }
            }
            return bestNumeric;
        } finally {
            if (current != null) current.recycle();
            if (localCardRoot != null) localCardRoot.recycle();
        }
    }

    private static boolean indexedEvidenceComplete(String text, boolean requireLocation,
                                                    boolean requireOfferTime) {
        if (text == null || text.isEmpty() || ClaimSuccessSignals.hasAcceptedJobDetail(text)
                || !LIVE_MONEY.matcher(text).find() || !LIVE_MILES.matcher(text).find()) return false;
        if (requireLocation) {
            String lower = text.toLowerCase(Locale.US);
            if (!(lower.contains(", ca") || lower.contains(" california")
                    || LIVE_CA_ZIP.matcher(text).find())) return false;
        }
        return !requireOfferTime || LIVE_OFFER_TIME.matcher(text).find();
    }

    private static boolean plausibleIndexedCardRoot(AccessibilityNodeInfo node, Rect actionBounds,
                                                     Rect rootBounds) {
        if (node == null || actionBounds == null || actionBounds.isEmpty()
                || rootBounds == null || rootBounds.isEmpty()) return false;
        Rect b = new Rect();
        node.getBoundsInScreen(b);
        if (b.isEmpty() || !b.contains(actionBounds.centerX(), actionBounds.centerY())) return false;
        if (b.top >= actionBounds.top - Math.max(48, actionBounds.height())) return false;
        // Never promote the whole page/list to a "local card"; that could mix adjacent offers.
        return b.height() <= Math.max(260, (int) (rootBounds.height() * 0.72f));
    }

    private static String indexedCardTextFromLocalSubtree(AccessibilityNodeInfo localRoot,
                                                            Rect actionBounds) {
        List<CardText.Piece> pieces = new ArrayList<>();
        int[] budget = new int[]{96};
        collectIndexedCardPieces(localRoot, actionBounds, pieces, budget);
        if (pieces.isEmpty()) return "";
        return CardText.aboveButton(pieces, actionBounds.top, actionBounds.bottom);
    }

    private static void collectIndexedCardPieces(AccessibilityNodeInfo node, Rect actionBounds,
                                                  List<CardText.Piece> pieces, int[] budget) {
        if (node == null || pieces == null || budget[0]-- <= 0) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        // Only card content at/above the anchored action row is relevant. Descendants below
        // Accept cannot supply decision fields and are skipped before string allocation.
        if (!bounds.isEmpty() && bounds.top <= actionBounds.bottom) {
            CharSequence text = node.getText(), desc = node.getContentDescription();
            if (text != null && text.length() > 0 && bounds.top < actionBounds.top)
                addUniquePiece(pieces, text.toString(), bounds);
            if (desc != null && desc.length() > 0 && !desc.equals(text) && bounds.top < actionBounds.top)
                addUniquePiece(pieces, desc.toString(), bounds);
        }
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectIndexedCardPieces(child, actionBounds, pieces, budget); }
                finally { child.recycle(); }
            }
        }
    }

    private static String ownNodeText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        if ((text == null || text.length() == 0) && (desc == null || desc.length() == 0)) return "";
        if (text == null || text.length() == 0) return compactWhitespace(desc);
        if (desc == null || desc.length() == 0 || desc.toString().contentEquals(text))
            return compactWhitespace(text);
        return compactWhitespace(text) + " " + compactWhitespace(desc);
    }

    public static FastOfferSnapshot getQuickTopOfferSnapshot() {
        return getQuickTopOfferSnapshotResult().snapshot;
    }

    /**
     * v2.10.35 bounded-latency variant. The semantic action index has already run before this
     * fallback. If React-Native makes the prefix traversal abnormally slow, expose that fact to
     * the caller so it can yield to OCR instead of immediately paying for a full-tree walk too.
     */
    public static QuickTopResult getQuickTopOfferSnapshotResult() {
        return getQuickTopOfferSnapshotResult(
                QuickTreeBudgetPolicy.softBudgetMs(), QuickTreeBudgetPolicy.maxNodes());
    }

    /**
     * v2.10.36 caller-supplied bounded variant. Reject background confirmation uses a much
     * smaller budget than the foreground decision lane, so an old low-value Reject can never
     * consume hundreds of milliseconds of Accessibility traversal while a new offer is arriving.
     */
    public static QuickTopResult getQuickTopOfferSnapshotResult(long softBudgetMs, int maxNodes) {
        return getQuickTopOfferSnapshotResult(softBudgetMs, maxNodes, false);
    }

    private static QuickTopResult getQuickTopOfferSnapshotResult(long softBudgetMs, int maxNodes,
                                                                  boolean completeTraversal) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return new QuickTopResult(null, false, 0);
        long requestedDeadline = rejectReadDeadline(SystemClock.elapsedRealtime() + Math.max(20L, softBudgetMs));
        AccessibilityNodeInfo root = rootForRejectRead(service);
        if (root == null) return new QuickTopResult(null, false, 0);
        try {
            checkFallbackRead();
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName()))
                return new QuickTopResult(null, false, 0);
            QuickActionProbe probe = new QuickActionProbe();
            probe.completeTraversal = completeTraversal;
            root.getBoundsInScreen(probe.rootBounds);
            if (probe.rootBounds.isEmpty()) return new QuickTopResult(null, false, 0);
            probe.startedAt = SystemClock.elapsedRealtime();
            long boundedMs = Math.max(20L, softBudgetMs);
            probe.deadlineAt = Math.min(requestedDeadline, probe.startedAt + boundedMs);
            RejectReadProgress progress = REJECT_READ_PROGRESS.get();
            if (progress != null) progress.stage = "TREE";
            int[] budget = new int[]{Math.max(16, maxNodes)};
            quickCollectActionEvidence(root, probe, budget);
            checkFallbackRead();
            boolean evidenceComplete = QuickEvidencePolicy.canStop(probe.sawMoney, probe.sawMiles,
                    probe.sawLocation, probe.sawAction);
            boolean limitExceeded = budget[0] <= 0 && (completeTraversal || !evidenceComplete);
            boolean exceeded = probe.budgetExceeded || limitExceeded;
            PageGuard.Page page = quickPageFromProbe(probe);
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED)
                return new QuickTopResult(null, exceeded, probe.visited, false,
                        RejectProbePolicy.limit(probe.budgetExceeded, limitExceeded) + ":" + page);
            return new QuickTopResult(quickTopSnapshotFromProbe(probe), exceeded, probe.visited,
                    !exceeded && page == PageGuard.Page.OFFERS && probe.flags[6]
                            && (probe.flags[2] || (probe.sawDeliveriesHub && probe.sawOffersLabel && probe.sawJobsLabel))
                            && !probe.sawMoney && !probe.sawMiles
                            // Blank structural controls may be map/navigation widgets. They
                            // cannot veto a complete explicit empty page by shape alone.
                            // Any semantic action or assigned-job evidence still blocks it.
                            && !probe.flags[3] && !probe.flags[4] && !probe.flags[5]
                            && probe.accepts.isEmpty() && probe.rejects.isEmpty()
                            && !probe.sawJobInstructions && !probe.sawBeginDelivery
                            && !probe.sawJobTimeline && !probe.sawApprover
                            && !probe.sawNuid && !probe.sawGlString,
                    RejectProbePolicy.limit(probe.budgetExceeded, limitExceeded)
                            + (completeTraversal ? "|" + rejectProbeEvidence(probe, page) : ""),
                    probe.sawMoney || probe.sawMiles || probe.flags[3] || probe.flags[4] || probe.flags[5]
                            || probe.sawJobInstructions || probe.sawBeginDelivery || probe.sawJobTimeline
                            || probe.sawApprover || probe.sawNuid || probe.sawGlString);
        } catch (RuntimeException staleTree) {
            // v2.10.91: React-Native can replace/recycle Accessibility nodes while this bounded
            // foreground walk is in progress. A single stale-node exception must degrade this
            // frame to OCR instead of terminating the Accessibility service/process.
            return new QuickTopResult(null, true, 0);
        } finally {
            try { root.recycle(); } catch (RuntimeException ignored) { }
        }
    }

    /**
     * Reuse the same bounded walk for page evidence instead of spending a second prefix walk
     * before every top-card scan. A live numeric/action row may override a stale selected tab;
     * Restore remains a hard Ignored-page signal.
     */
    private static PageGuard.Page quickPageFromProbe(QuickActionProbe probe) {
        if (probe == null) return PageGuard.Page.UNKNOWN;
        int jobMeta = (probe.sawApprover ? 1 : 0) + (probe.sawNuid ? 1 : 0)
                + (probe.sawGlString ? 1 : 0);
        if (probe.sawJobInstructions && jobMeta >= 2) {
            recordQuickPage(PageGuard.Page.JOBS);
            return PageGuard.Page.JOBS;
        }
        PageGuard.Page page = PageGuard.classify(probe.flags[0], probe.flags[1], probe.flags[2],
                probe.flags[3], probe.flags[4], probe.flags[5], probe.flags[6]);
        boolean liveOffer = probe.sawMoney && probe.sawMiles && probe.sawAction;
        if ((page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED)
                && !probe.flags[3] && liveOffer) page = PageGuard.Page.UNKNOWN;
        if (page != PageGuard.Page.UNKNOWN) recordQuickPage(page);
        return page;
    }

    private static void recordQuickPage(PageGuard.Page page) {
        FallbackReadScope scope = FALLBACK_READ_SCOPE.get();
        if (scope == null) updatePageHint(page);
        else scope.quickPage = page;
    }

    private static FastOfferSnapshot quickTopSnapshotFromProbe(QuickActionProbe probe) {
        if (probe == null || probe.rootBounds.isEmpty() || probe.pieces.isEmpty()) return null;
        String topText = topVisibleOfferTextFromPieces(probe.pieces);
        checkFallbackRead();
        FallbackReadScope scope = FALLBACK_READ_SCOPE.get();
        if (scope == null) cacheDecisionEvidence(topText, UI_GENERATION.get());
        else scope.quickText = topText;
        if (ClaimSuccessSignals.hasAcceptedJobDetail(topText)) return null;
        float topAmount = directAmount(topText), topMiles = directMiles(topText);
        if (topAmount < 0 || topMiles < 0) return null;

        List<ActionHit> anchors = new ArrayList<>();
        anchors.addAll(probe.accepts);
        anchors.addAll(probe.rejects);
        for (ActionHit hit : probe.structural) {
            if (safeActionBounds(probe.rootBounds, hit.bounds, true)
                    || safeActionBounds(probe.rootBounds, hit.bounds, false))
                addUniqueHit(anchors, hit.bounds, hit.enabled);
        }
        anchors.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                .thenComparingInt(hit -> hit.bounds.left));

        for (ActionHit anchor : anchors) {
            String cardText = CardText.aboveButton(probe.pieces, anchor.bounds.top, anchor.bounds.bottom);
            if (!quickNumericPairMatches(cardText, topAmount, topMiles)) continue;
            Rect accept = new Rect(), reject = new Rect();
            boolean acceptEnabled = false, rejectEnabled = false;
            for (ActionHit hit : probe.accepts) {
                if (sameRow(hit.bounds, anchor.bounds)
                        && safeActionBounds(probe.rootBounds, hit.bounds, true)) {
                    accept.set(hit.bounds); acceptEnabled = hit.enabled; break;
                }
            }
            for (ActionHit hit : probe.rejects) {
                if (sameRow(hit.bounds, anchor.bounds)
                        && safeActionBounds(probe.rootBounds, hit.bounds, false)) {
                    reject.set(hit.bounds); rejectEnabled = hit.enabled; break;
                }
            }
            if (accept.isEmpty()) {
                ActionHit structuralAccept = bestStructuralAction(
                        probe.structural, anchor.bounds, probe.rootBounds, true, reject);
                if (structuralAccept != null) {
                    accept.set(structuralAccept.bounds); acceptEnabled = structuralAccept.enabled;
                }
            }
            if (reject.isEmpty()) {
                ActionHit structuralReject = bestStructuralAction(
                        probe.structural, anchor.bounds, probe.rootBounds, false, accept);
                if (structuralReject != null) {
                    reject.set(structuralReject.bounds); rejectEnabled = structuralReject.enabled;
                }
            }
            if (!accept.isEmpty() || !reject.isEmpty())
                return new FastOfferSnapshot(cardText, accept, reject, acceptEnabled, rejectEnabled,
                        SystemClock.elapsedRealtime());
        }
        return null;
    }

    /**
     * Choose structural controls by their relationship to the action row. On a three-control
     * Large Order row, Reject is the nearest safe control to the LEFT of Accept, not the
     * leftmost control (which is the information entry).
     */
    private static ActionHit bestStructuralAction(List<ActionHit> hits, Rect rowAnchor,
                                                   Rect rootBounds, boolean accept,
                                                   Rect opposite) {
        if (hits == null || rowAnchor == null || rowAnchor.isEmpty()) return null;
        ActionHit best = null;
        for (ActionHit hit : hits) {
            if (hit == null || !sameRow(hit.bounds, rowAnchor)
                    || !safeActionBounds(rootBounds, hit.bounds, accept)) continue;
            if (!accept && opposite != null && !opposite.isEmpty()
                    && hit.bounds.exactCenterX() >= opposite.exactCenterX()) continue;
            if (accept && opposite != null && !opposite.isEmpty()
                    && hit.bounds.exactCenterX() <= opposite.exactCenterX()) continue;
            if (best == null || hit.bounds.exactCenterX() > best.bounds.exactCenterX()) best = hit;
        }
        return best;
    }

    private static String topVisibleOfferTextFromPieces(List<CardText.Piece> source) {
        if (source == null || source.isEmpty()) return "";
        List<CardText.Piece> pieces = new ArrayList<>(source);
        pieces.sort(java.util.Comparator.comparingDouble((CardText.Piece p) -> p.top)
                .thenComparingDouble(p -> p.left));
        CardText.Piece money = null, miles = null;
        for (CardText.Piece p : pieces) {
            if (money == null && CardText.MONEY.matcher(p.text).find()) money = p;
            if (miles == null && LIVE_MILES.matcher(p.text).find()) miles = p;
            if (money != null && miles != null) {
                float row = Math.max(money.bottom - money.top, miles.bottom - miles.top);
                if (Math.abs(money.top - miles.top) <= Math.max(18f, row * 3f)) break;
                if (money.top < miles.top) money = null; else miles = null;
            }
        }
        if (money == null || miles == null) return "";
        float start = Math.min(money.top, miles.top);
        float end = start + 430f;
        for (CardText.Piece p : pieces) {
            if (p.top <= start + 90f) continue;
            if (CardText.MONEY.matcher(p.text).find() || LIVE_MILES.matcher(p.text).find()) {
                end = Math.min(end, p.top - 4f);
                break;
            }
        }
        StringBuilder out = new StringBuilder();
        for (CardText.Piece p : pieces)
            if (p.top >= start && p.top < end) out.append(p.text).append(' ');
        return out.toString().trim();
    }

    /** v2.10.14: bounded active-window consensus used to retire a stale serial lock
     * without waiting a full second OCR cycle. It proves that the CURRENT top action row
     * carries the same amount+miles pair that OCR just read. */
    /**
     * v2.10.105 no-city hot lane. Query the live Accept and the two exact numeric labels through
     * Android's text index, then bind them spatially to the same top action row. This avoids the
     * 180-node prefix walk on React-Native frames where the Accept ancestor has not inherited
     * the card content yet. The returned snapshot still contains a CURRENT enabled Accept and
     * independently re-parsed amount+mileage; cached event coordinates are never reused.
     */
    public static FastOfferSnapshot getIndexedNumericTopAcceptSnapshot(float expectedAmount,
                                                                        float expectedMiles) {
        return getIndexedNumericTopActionSnapshot(expectedAmount, expectedMiles, true, false);
    }

    /**
     * v2.10.127 visual-numeric bridge. React Native can draw the filled-blue Accept before its
     * semantic Accept node is exported. In that short stage, bind the exact CURRENT indexed
     * amount+mileage to the CURRENT visual button rectangle and the same top-card band. The
     * caller independently proves the blue CTA pixels; this method proves package, live root,
     * right-action geometry, exact numeric pair, single-card isolation and a stable UI
     * generation. It does not infer or reuse an old coordinate.
     */
    public static FastOfferSnapshot getIndexedNumericVisualAcceptSnapshot(
            float expectedAmount, float expectedMiles, Rect visualAcceptBounds) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || expectedAmount < 0f || expectedMiles < 0f
                || visualAcceptBounds == null || visualAcceptBounds.isEmpty()) return null;
        long generation = UI_GENERATION.get();
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return null;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return null;
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            Rect actionBounds = new Rect(visualAcceptBounds);
            if (rootBounds.isEmpty() || !safeActionBounds(rootBounds, actionBounds, true)
                    || UI_GENERATION.get() != generation) return null;

            List<CardText.Piece> pieces = new ArrayList<>();
            String amountTwo = String.format(Locale.US, "$%.2f", expectedAmount);
            String amountPlain = String.format(Locale.US, "%.2f", expectedAmount);
            String amountWhole = Math.abs(expectedAmount - Math.round(expectedAmount)) <= 0.011f
                    ? String.format(Locale.US, "$%.0f", expectedAmount) : "";
            String milesOne = String.format(Locale.US, "%.1f mi", expectedMiles);
            String milesWhole = Math.abs(expectedMiles - Math.round(expectedMiles)) <= 0.051f
                    ? String.format(Locale.US, "%.0f mi", expectedMiles) : "";
            collectIndexedNumericPieces(root,
                    new String[]{amountTwo, amountPlain, amountWhole, milesOne, milesWhole},
                    actionBounds, pieces);
            if (UI_GENERATION.get() != generation) return null;
            String currentText = CardText.aboveButton(
                    pieces, actionBounds.top, actionBounds.bottom);
            if (currentText.isEmpty() || CardText.containsMultipleMileageRows(currentText)
                    || !quickNumericPairMatches(currentText, expectedAmount, expectedMiles))
                return null;
            return new FastOfferSnapshot(currentText, actionBounds, new Rect(),
                    true, false, SystemClock.elapsedRealtime());
        } catch (RuntimeException ignored) {
            return null;
        } finally {
            try { root.recycle(); } catch (RuntimeException ignored) { }
        }
    }

    /**
     * v2.10.123 first-publish filtered General lane. Bind the CURRENT enabled Accept and exact
     * amount/mileage to live indexed city and offer-time text from the same top-card band. This
     * lets an explicit city allow-list and active time window avoid the full React-Native tree
     * without ever treating cached rule fields or a numeric-only frame as sufficient.
     */
    public static FastOfferSnapshot getIndexedFilteredGeneralTopAcceptSnapshot(
            float expectedAmount, float expectedMiles, String[] cityQueries,
            boolean requireOfferTime) {
        return getIndexedNumericTopActionSnapshot(expectedAmount, expectedMiles, true, false,
                cityQueries, requireOfferTime);
    }

    /**
     * v2.10.122 numeric Reject lane. Query the CURRENT top semantic Reject plus the exact
     * amount/mileage pair without reconstructing the city/address tree. Callers may use this
     * only when fresh decision evidence already proves rejection or every numeric branch fails.
     */
    public static FastOfferSnapshot getIndexedNumericTopRejectSnapshot(float expectedAmount,
                                                                        float expectedMiles) {
        return getIndexedNumericTopActionSnapshot(expectedAmount, expectedMiles, false, false);
    }

    /**
     * v2.10.115: first-publish Pasadena-group lane. In addition to the exact current numeric
     * pair and enabled Accept, query the current Android text index for an endpoint address in
     * the configured Pasadena city group. This avoids a complete tree walk for Commerce,
     * Alhambra, Arcadia, etc. while keeping city proof bound to the same live action row.
     */
    public static FastOfferSnapshot getIndexedPasadenaTopAcceptSnapshot(float expectedAmount,
                                                                         float expectedMiles) {
        return getIndexedNumericTopActionSnapshot(expectedAmount, expectedMiles, true, true);
    }

    /**
     * v2.10.126 event-independent Pasadena first-publish lane. All returned fields come from
     * live indexed nodes spatially bound above the CURRENT top enabled Accept. Generic '$' and
     * 'mi' lookups are data discovery only; the returned text must parse as exactly one coherent
     * numeric pair and an endpoint city before it can reach the unchanged rule/action guards.
     */
    public static FastOfferSnapshot getIndexedPasadenaCurrentTopAcceptSnapshot(
            boolean requireOfferTime) {
        return getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(
                Float.POSITIVE_INFINITY, -1f, true, false, requireOfferTime);
    }

    public static FastOfferSnapshot getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(
            float generalMinPay, float generalMaxMiles, boolean pasadenaEnabled,
            boolean allowGeneralNumeric, boolean requireOfferTime) {
        return readIndexedCurrentTopAcceptSnapshot(generalMinPay,generalMaxMiles,pasadenaEnabled,
                allowGeneralNumeric,requireOfferTime,true);
    }

    /** Observation only: disabled current action remains readable, never authorizes a tap. */
    public static FastOfferSnapshot observeCurrentTopAcceptSnapshot() {
        return readIndexedCurrentTopAcceptSnapshot(0f,Float.MAX_VALUE,false,true,false,false);
    }

    private static final ThreadLocal<String> ACCEPT_INDEX_FAILURE=ThreadLocal.withInitial(() -> "NOT_READ");
    private static final Object INDEX_ROOT_LOCK=new Object();
    private static AccessibilityNodeInfo indexedRootReceipt;
    private static TapAccessibilityService indexedRootOwner;
    private static long indexedRootAt,indexedRootGeneration,indexedRootEpoch;
    private static long indexedRootQueueMs, indexedRootBinderMs;
    private static java.util.concurrent.FutureTask<String> indexedRootPending;
    private static TapAccessibilityService indexedRootPendingOwner;
    private static boolean wakeWhenIndexedRootReady;
    private static long indexedRootPendingGeneration,indexedRootPendingEpoch,indexedRootPendingAt;
    private static final ThreadLocal<String> ROOT_READ_TRACE=ThreadLocal.withInitial(() -> "COLD");
    private static java.util.concurrent.FutureTask<String> prefetchIndexedRoot(TapAccessibilityService service,long generation) {
        if(service.rootReadAhead==null || service.rootReadAhead.isShutdown()) return null;
        final long epoch=WINDOW_TRANSITION_EPOCH.get(),started=SystemClock.elapsedRealtime();
        synchronized(INDEX_ROOT_LOCK) {
            if(indexedRootReceipt!=null && indexedRootOwner==service && indexedRootGeneration==generation
                    && indexedRootEpoch==epoch && started>=indexedRootAt && started-indexedRootAt<=40L) return null;
            if(indexedRootPending!=null && !indexedRootPending.isDone()
                    && indexedRootPendingOwner==service && indexedRootPendingGeneration==generation
                    && indexedRootPendingEpoch==epoch) return indexedRootPending;
            if(indexedRootPending!=null) indexedRootPending.cancel(false);
            wakeWhenIndexedRootReady = false;
            service.rootReadAhead.purge();
            java.util.concurrent.FutureTask<String> task=new java.util.concurrent.FutureTask<>(() -> {
                AccessibilityNodeInfo root=null;
                try {
                    if(INSTANCE.get()!=service || service.rootReadAhead.isShutdown() || UI_GENERATION.get()!=generation
                            || WINDOW_TRANSITION_EPOCH.get()!=epoch) return "SUPERSEDED";
                    long workerStartedAt = SystemClock.elapsedRealtime();
                    root=service.getRootInActiveWindow();
                    long binderDoneAt = SystemClock.elapsedRealtime();
                    if(root==null) return "NO_ROOT";
                    if(!"com.deliverthat.driver".contentEquals(String.valueOf(root.getPackageName()))) return "FOREIGN_APP";
                    boolean wakeScanner;
                    synchronized(INDEX_ROOT_LOCK) {
                        if(INSTANCE.get()!=service || service.rootReadAhead.isShutdown() || UI_GENERATION.get()!=generation || WINDOW_TRANSITION_EPOCH.get()!=epoch) return "SUPERSEDED";
                        if(!"com.deliverthat.driver".equals(foregroundPackage)) return "FOREIGN_APP";
                        if(indexedRootReceipt!=null) indexedRootReceipt.recycle();
                        indexedRootReceipt=AccessibilityNodeInfo.obtain(root);indexedRootOwner=service;
                        indexedRootAt=SystemClock.elapsedRealtime();indexedRootGeneration=generation;indexedRootEpoch=epoch;
                        indexedRootQueueMs = workerStartedAt - started;
                        indexedRootBinderMs = binderDoneAt - workerStartedAt;
                        wakeScanner = wakeWhenIndexedRootReady;
                        wakeWhenIndexedRootReady = false;
                    }
                    if (wakeScanner) OcrMonitorService.requestImmediateFastCheck(SystemClock.uptimeMillis(), true);
                    return "READY";
                } finally {if(root!=null) root.recycle();}
            });
            indexedRootPending=task;indexedRootPendingOwner=service;
            indexedRootPendingGeneration=generation;indexedRootPendingEpoch=epoch;indexedRootPendingAt=started;
            try {service.rootReadAhead.execute(task);} catch(java.util.concurrent.RejectedExecutionException busy) {
                task.cancel(false);return null;
            }
            return task;
        }
    }

    private static AccessibilityNodeInfo recentIndexedRoot(TapAccessibilityService service,long generation,long now,long epoch) {
        synchronized(INDEX_ROOT_LOCK) {
            if(indexedRootReceipt!=null && indexedRootOwner==service && indexedRootGeneration==generation
                    && indexedRootEpoch==epoch && now>=indexedRootAt && now-indexedRootAt<=40L
                    && "com.deliverthat.driver".equals(foregroundPackage)) {
                ROOT_READ_TRACE.set("CACHED;rootQueueMs=" + indexedRootQueueMs
                        + ";rootBinderMs=" + indexedRootBinderMs + ";rootReceiptAgeMs=" + (now - indexedRootAt));
                return AccessibilityNodeInfo.obtain(indexedRootReceipt);
            }
            return null;
        }
    }

    private static AccessibilityNodeInfo readCurrentIndexedRoot(TapAccessibilityService service,long generation) {
        return readCurrentIndexedRoot(service, generation, 60L);
    }

    private static AccessibilityNodeInfo readCurrentIndexedRoot(
            TapAccessibilityService service, long generation, long callerBudgetMs) {
        long now=SystemClock.elapsedRealtime(),epoch=WINDOW_TRANSITION_EPOCH.get();
        if (UI_GENERATION.get() != generation) {
            ACCEPT_INDEX_FAILURE.set("ROOT_READ_SUPERSEDED");
            return null;
        }
        AccessibilityNodeInfo cached=recentIndexedRoot(service,generation,now,epoch);
        if (cached != null) return cached;
        java.util.concurrent.FutureTask<String> pending=prefetchIndexedRoot(service,generation);
        if(pending!=null) {
            long lead=Math.max(0L,now-indexedRootPendingAt);
            try {
                long waitBudgetMs = Math.min(callerBudgetMs,
                        Math.max(1L, 60L - Math.max(0L, SystemClock.elapsedRealtime() - indexedRootPendingAt)));
                long deadline = System.nanoTime() + java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(waitBudgetMs);
                String result;
                for (;;) {
                    if (UI_GENERATION.get() != generation || WINDOW_TRANSITION_EPOCH.get() != epoch) {
                        ACCEPT_INDEX_FAILURE.set("ROOT_READ_SUPERSEDED");
                        return null;
                    }
                    long left = deadline - System.nanoTime();
                    if (left <= 0L) throw new java.util.concurrent.TimeoutException();
                    try {
                        result = pending.get(Math.min(left, java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(4)),
                                java.util.concurrent.TimeUnit.NANOSECONDS);
                        break;
                    } catch (java.util.concurrent.TimeoutException slice) {
                        if (System.nanoTime() >= deadline) throw slice;
                    }
                }
                synchronized(INDEX_ROOT_LOCK) {
                    if("READY".equals(result) && indexedRootReceipt!=null && indexedRootOwner==service
                            && indexedRootGeneration==generation && indexedRootEpoch==epoch
                            && UI_GENERATION.get()==generation && WINDOW_TRANSITION_EPOCH.get()==epoch
                            && "com.deliverthat.driver".equals(foregroundPackage)) {
                        ROOT_READ_TRACE.set("READ_AHEAD;leadMs="+lead+";rootQueueMs="+indexedRootQueueMs
                                +";rootBinderMs="+indexedRootBinderMs+";rootJoinMs="
                                +(SystemClock.elapsedRealtime()-now));
                        return AccessibilityNodeInfo.obtain(indexedRootReceipt);
                    }
                }
                ROOT_READ_TRACE.set(result);ACCEPT_INDEX_FAILURE.set("FOREIGN_APP".equals(result)||"NO_ROOT".equals(result)?result:"ROOT_READ_SUPERSEDED");return null;
            } catch(java.util.concurrent.TimeoutException waiting) {
                synchronized (INDEX_ROOT_LOCK) {
                    if (indexedRootPending == pending && UI_GENERATION.get() == generation
                            && WINDOW_TRANSITION_EPOCH.get() == epoch) {
                        // Publication can win the race with the timed get; take the receipt now.
                        long receiptAge = SystemClock.elapsedRealtime() - indexedRootAt;
                        if (indexedRootReceipt != null && indexedRootOwner == service
                                && indexedRootGeneration == generation && indexedRootEpoch == epoch
                                && receiptAge >= 0L && receiptAge <= 40L
                                && "com.deliverthat.driver".equals(foregroundPackage)) {
                            ROOT_READ_TRACE.set("READ_AHEAD_READY_AT_TIMEOUT;rootQueueMs="+indexedRootQueueMs
                                    +";rootBinderMs="+indexedRootBinderMs);
                            return AccessibilityNodeInfo.obtain(indexedRootReceipt);
                        }
                        wakeWhenIndexedRootReady = true;
                    }
                }
                ROOT_READ_TRACE.set("PENDING");ACCEPT_INDEX_FAILURE.set("ROOT_READ_PENDING");return null;
            } catch(InterruptedException stopped) {
                Thread.currentThread().interrupt();ACCEPT_INDEX_FAILURE.set("ROOT_READ_INTERRUPTED");return null;
            } catch(java.util.concurrent.ExecutionException | java.util.concurrent.CancellationException failed) {
                ACCEPT_INDEX_FAILURE.set("ROOT_READ_SUPERSEDED");return null;
            }
        }
        // A prefetch may have published between the first cache check and enqueue check.
        synchronized(INDEX_ROOT_LOCK) {
            long ready=SystemClock.elapsedRealtime();
            if(indexedRootReceipt!=null && indexedRootOwner==service && indexedRootGeneration==generation
                    && indexedRootEpoch==epoch && UI_GENERATION.get()==generation
                    && WINDOW_TRANSITION_EPOCH.get()==epoch && ready>=indexedRootAt && ready-indexedRootAt<=40L
                    && "com.deliverthat.driver".equals(foregroundPackage)) {
                ROOT_READ_TRACE.set("CACHED_AFTER_PREFETCH;rootQueueMs=" + indexedRootQueueMs
                        + ";rootBinderMs=" + indexedRootBinderMs);
                return AccessibilityNodeInfo.obtain(indexedRootReceipt);
            }
        }
        // First-shot scans must not turn a saturated read-ahead queue into a second
        // synchronous Binder call on the scan lane. Retry on the existing heartbeat.
        if (callerBudgetMs<=20L && service.rootReadAhead!=null && !service.rootReadAhead.isShutdown()) {
            ROOT_READ_TRACE.set("READ_AHEAD_BUSY_YIELD");
            ACCEPT_INDEX_FAILURE.set("ROOT_READ_PENDING");
            return null;
        }
        long binderStartedAt = SystemClock.elapsedRealtime();
        AccessibilityNodeInfo root=service.getRootInActiveWindow();
        long binderMs = SystemClock.elapsedRealtime() - binderStartedAt;
        ROOT_READ_TRACE.set("COLD;rootBinderMs="+binderMs);
        if(root!=null && UI_GENERATION.get()==generation && WINDOW_TRANSITION_EPOCH.get()==epoch
                && "com.deliverthat.driver".contentEquals(root.getPackageName()==null?"":root.getPackageName())) {
            synchronized(INDEX_ROOT_LOCK) {
                if(indexedRootReceipt!=null) indexedRootReceipt.recycle();
                indexedRootReceipt=AccessibilityNodeInfo.obtain(root);indexedRootOwner=service;
                indexedRootAt=SystemClock.elapsedRealtime();indexedRootGeneration=generation;indexedRootEpoch=epoch;
                indexedRootQueueMs = 0L;
                indexedRootBinderMs = binderMs;
            }
        }
        return root;
    }
    private static void clearIndexedRootReceipt() {
        synchronized(INDEX_ROOT_LOCK) {
            if(indexedRootReceipt!=null) indexedRootReceipt.recycle();
            indexedRootReceipt=null;indexedRootOwner=null;
            if(indexedRootPending!=null) indexedRootPending.cancel(false);
            indexedRootPending=null;indexedRootPendingOwner=null;
            wakeWhenIndexedRootReady = false;
        }
    }

    private static final ThreadLocal<String> RETRY_WITNESS_FAILURE=ThreadLocal.withInitial(() -> "NONE");
    private static final ThreadLocal<String> RETRY_WITNESS_DETAIL=ThreadLocal.withInitial(() -> "NONE");
    private static final ThreadLocal<String> RETRY_TREE_FAILURE=ThreadLocal.withInitial(() -> "NOT_USED");
    private static FastOfferSnapshot failAcceptIndex(String reason) {
        ACCEPT_INDEX_FAILURE.set(reason); return null;
    }
    private static String acceptIndexFailure() { return ACCEPT_INDEX_FAILURE.get(); }
    public static String currentAcceptObservationReason() { return ACCEPT_INDEX_FAILURE.get(); }
    private static String retryWitnessFailure() { return RETRY_WITNESS_FAILURE.get(); }
    private static boolean hardRetryWitnessFailure(String reason) {
        return !("NONE".equals(reason) || "UNAVAILABLE".equals(reason) || "REFRESH_FAILED".equals(reason));
    }

    /** Each query owns a root copy. Returned nodes transfer only after the batch completes. */
    private static final class IndexedQueryResult implements AutoCloseable {
        private List<AccessibilityNodeInfo> nodes;
        long readMs;
        IndexedQueryResult(List<AccessibilityNodeInfo> nodes) { this.nodes = nodes; }
        List<AccessibilityNodeInfo> takeNodes() {
            List<AccessibilityNodeInfo> owned = nodes;
            nodes = null;
            return owned;
        }
        @Override public void close() {
            if (nodes != null) {
                for (AccessibilityNodeInfo node : nodes) if (node != null) node.recycle();
                nodes = null;
            }
        }
    }

    private static final class IndexedQueryRead implements BoundedReadBatch.Read<IndexedQueryResult> {
        private final AccessibilityNodeInfo root;
        private final String query;
        IndexedQueryRead(AccessibilityNodeInfo root, String query) {
            this.root = AccessibilityNodeInfo.obtain(root);
            this.query = query;
        }
        @Override public IndexedQueryResult read() {
            long startedAt = SystemClock.elapsedRealtime();
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(query);
            if (nodes == null) return null;
            IndexedQueryResult result = new IndexedQueryResult(nodes);
            result.readMs = SystemClock.elapsedRealtime() - startedAt;
            return result;
        }
        @Override public void close() { root.recycle(); }
    }

    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryPair(
            TapAccessibilityService service, AccessibilityNodeInfo root, String first, String second) {
        return readIndexedQueryPairWithBudget(service,root,first,second,90L);
    }

    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryPairWithBudget(
            TapAccessibilityService service,AccessibilityNodeInfo root,String first,String second,long timeoutMs) {
        return readIndexedQueryPairOnBatch(service.firstShotIndexBatch,root,first,second,timeoutMs);
    }

    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryPairOnBatch(
            BoundedReadBatch batch,AccessibilityNodeInfo root,String first,String second,long timeoutMs) {
        List<IndexedQueryRead> jobs = new ArrayList<>();
        try {
            jobs.add(new IndexedQueryRead(root, first));
            jobs.add(new IndexedQueryRead(root, second));
        } catch (RuntimeException stale) {
            for (IndexedQueryRead job : jobs) job.close();
            throw stale;
        }
        return batch.read(jobs, timeoutMs);
    }

    /** Same worker/budget as live proof reads, at most four current-window queries. */
    private static BoundedReadBatch.Result<IndexedQueryResult> readIndexedQueryGroupWithBudget(
            TapAccessibilityService service,AccessibilityNodeInfo root,String[] queries,int offset,int count,long budget) {
        List<IndexedQueryRead> jobs=new ArrayList<>();
        try {
            for(int i=0;i<count;i++) jobs.add(new IndexedQueryRead(root,queries[offset+i]));
        } catch(RuntimeException stale) {for(IndexedQueryRead job:jobs)job.close();throw stale;}
        return service.outcomePageReadBatch.read(jobs,budget);
    }

    private static BoundedReadBatch.Pending<IndexedQueryResult> readIndexedActionAndNumbers(
            TapAccessibilityService service,AccessibilityNodeInfo root,boolean fastUniversal) {
        List<IndexedQueryRead> jobs=new ArrayList<>();
        try {
            // THREE read slots rather than four for a fresh, already eligible General
            // publication. This still independently reads the CURRENT action and pair.
            // The normal Reject and location-dependent paths retain the full e boundary.
            String[] queries = fastUniversal ? new String[]{"a","$","mi"}
                    : new String[]{"a","e","$","mi"};
            for(String query:queries)
                jobs.add(new IndexedQueryRead(root,query));
        } catch(RuntimeException stale) {
            for(IndexedQueryRead job:jobs) job.close();
            throw stale;
        }
        return service.firstShotIndexBatch.begin(jobs,90L);
    }

    private static final ThreadLocal<RejectedIndexObservation> REJECTED_SELF_INDEX = new ThreadLocal<>();
    private static final class RejectedIndexObservation {
        final FastOfferSnapshot snapshot;
        final long generation, epoch;
        RejectedIndexObservation(FastOfferSnapshot value,long gen,long win) {
            snapshot=value; generation=gen; epoch=win;
        }
    }
    // Routing observation only: a fresh independent Reject control proof is still required.
    public static FastOfferSnapshot takeRejectedSelfIndexObservation() {
        RejectedIndexObservation value=REJECTED_SELF_INDEX.get(); REJECTED_SELF_INDEX.remove();
        if(value==null || value.generation!=UI_GENERATION.get()
                || value.epoch!=WINDOW_TRANSITION_EPOCH.get()) return null;
        long age=SystemClock.elapsedRealtime()-value.snapshot.capturedAt;
        return age>=0L && age<=80L ? value.snapshot : null;
    }

    private static FastOfferSnapshot readIndexedCurrentTopAcceptSnapshot(
            float generalMinPay, float generalMaxMiles, boolean pasadenaEnabled,
            boolean allowGeneralNumeric, boolean requireOfferTime, boolean requireEnabled) {
        REJECTED_SELF_INDEX.remove();
        ACCEPT_INDEX_FAILURE.set("STARTED");
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return failAcceptIndex("NO_SERVICE");
        long readStartedAt = SystemClock.elapsedRealtime();
        long generation = UI_GENERATION.get();
        long observationEpoch = WINDOW_TRANSITION_EPOCH.get();
        AccessibilityNodeInfo root;
        // A slow current root publishes a wake when ready; it need not occupy the
        // first-shot scan worker while the window can still change.
        try { root = readCurrentIndexedRoot(service, generation, requireEnabled ? 20L : 60L); }
        catch(RuntimeException failure) {return failAcceptIndex("ROOT_READ_EXCEPTION:"+failure.getClass().getSimpleName());}
        if (root == null) return failAcceptIndex(acceptIndexFailure().startsWith("ROOT_READ_")?acceptIndexFailure():"NO_ROOT");
        // Enabled observation snapshots retain refreshable nodes for the final retry too.
        // Disabled controls still never publish a dispatch witness.
        IndexedWitness witness = new IndexedWitness();
        boolean publishedWitness = false;
        IndexedWitness rejectWitness = new IndexedWitness();
        boolean publishedReject = false;
        Rect rejectBounds = new Rect();
        BoundedReadBatch.Pending<IndexedQueryResult> pendingQueries = null;

        BoundedReadBatch.Result<IndexedQueryResult> numericQueries = null;
        AccessibilityNodeInfo deferredAcceptReadiness = null;
        try {
            if (!"com.deliverthat.driver".contentEquals(String.valueOf(root.getPackageName())))
                return failAcceptIndex("FOREIGN_APP");
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            if (rootBounds.isEmpty()) return failAcceptIndex("NO_ROOT_BOUNDS");

            List<CardText.Piece> pieces = new ArrayList<>();
            java.util.HashSet<String> endpointSeeds = new java.util.HashSet<>();
            long rootReadyAt = SystemClock.elapsedRealtime();
            Rect actionBounds = new Rect();
            int bestTop = Integer.MAX_VALUE;
            boolean actionEnabled = false;
            boolean baselineComplete = false, baselineNegative = false;
            long baselineEpoch = WINDOW_TRANSITION_EPOCH.get();
            // a covers Accept/Claim and negative baselines; e adds Ignore/Reject/Decline
            // boundaries so a missing top Accept cannot borrow its numbers for a lower CTA.
            // Discover numbers concurrently with actions, then bind their geometry only after
            // the top action is known. All four reads still share the same generation fence.
            // A captured CURRENT root/CTA remains valid through ordinary RN content
            // generations. Only a real window transition or service switch aborts the
            // read; final foreground + spinner/terminal gates remain at gesture dispatch.
            java.util.function.BooleanSupplier currentScene = () -> INSTANCE.get() == service
                    && WINDOW_TRANSITION_EPOCH.get() == observationEpoch;
            if (!currentScene.getAsBoolean()) return failAcceptIndex("WINDOW_CHANGED_ROOT");
            DecisionEvidence hotEvent = recentEventBurstDecisionEvidence(180L);
            boolean fastUniversalIndex = allowGeneralNumeric && !requireOfferTime
                    && hotEvent != null && hotEvent.amount >= generalMinPay
                    && hotEvent.miles >= 0f && hotEvent.miles <= generalMaxMiles;
            pendingQueries = readIndexedActionAndNumbers(service, root, fastUniversalIndex);
            // Share one discovery batch: exact Accept/Claim labels select the CTA; a/e
            // results also retain negative baselines, Reject boundaries and local fields.
            // Do not add two extra Binder caption queries or rebuild fields for an interim CTA.
            final int liveWindow=root.getWindowId();
            List<AccessibilityNodeInfo> sharedNodes=new ArrayList<>();
            List<IndexedSeedValue> exactButtons=new ArrayList<>();
            List<IndexedSeedValue> sharedEvidence=new ArrayList<>();
            List<IndexedSeedValue> deferredRejectSeeds=new ArrayList<>();
            java.util.HashSet<AccessibilityNodeInfo> visitedSeeds=new java.util.HashSet<>();
            java.util.HashSet<String> sharedSeeds=new java.util.HashSet<>();
            long actionQueryWaitMs = 0L, seedFilterAndRejectMs = 0L;
            long[] actionReadMs = new long[2];
            BoundedReadBatch.Result<IndexedQueryResult> actionQuery = null;
            final long discoveryReadyAt, candidatesReadyAt, controlReadyAt, sharedFieldsReadyAt;
            AccessibilityNodeInfo resolvedWinner = null;
            try {
                Rect seedBounds = new Rect();
                Rect resolvedRejectBounds = new Rect();
                for (int queryIndex = 0; queryIndex < (fastUniversalIndex ? 1 : 2); queryIndex++) {
                    if (!currentScene.getAsBoolean()) return failAcceptIndex("UI_CHANGED_ACTION");
                    long waitingAt = SystemClock.elapsedRealtime();
                    actionQuery = pendingQueries.takeWhile(queryIndex, queryIndex + 1, currentScene);
                    List<AccessibilityNodeInfo> indexed;
                    if (actionQuery.complete()) {
                        try (IndexedQueryResult result = actionQuery.values.get(0)) {
                            actionReadMs[queryIndex] = result.readMs;
                            indexed = result.takeNodes();
                        }
                    } else if ("BUSY".equals(actionQuery.reason)) {
                        // v2.10.297: all four first-shot readers are still occupied by
                        // abandoned/slow Binder calls. A synchronous "a"/"e" fallback
                        // blocked the 12ms scan lane and COULD NOT complete the missing
                        // numeric pair (the same Pending batch already failed BUSY).
                        // Yield to the next heartbeat/new-publication event instead.
                        return failAcceptIndex("ACTION_INDEX_BUSY_YIELD");
                    } else {
                        return failAcceptIndex(currentScene.getAsBoolean()
                                ? "ACTION_INDEX_" + actionQuery.reason : "UI_CHANGED_ACTION");
                    }
                    long filteringAt = SystemClock.elapsedRealtime();
                    actionQueryWaitMs += filteringAt - waitingAt;
                    if (indexed == null) return failAcceptIndex("ACTION_INDEX_UNREADABLE");
                    sharedNodes.addAll(indexed);
                    if (!currentScene.getAsBoolean()) return failAcceptIndex("UI_CHANGED_ACTION");
                    // Filter the first result while the second query is still in flight.
                    // Both results still define the top-row boundaries and negative baseline.
                    for (AccessibilityNodeInfo seed : indexed) {
                        if (seed == null || !visitedSeeds.add(seed) || seed.getWindowId() != liveWindow
                                || !seed.isVisibleToUser()) continue;
                        CharSequence label = seed.getText(), description = seed.getContentDescription();
                        if (!baselineNegative && (label != null || description != null)
                                && !pageNegativeHint(String.valueOf(label) + " " + description).isEmpty())
                            baselineNegative = true;
                        CharSequence alternate = java.util.Objects.equals(label, description) ? null : description;
                        boolean exact = (label != null && label.length() <= 64 && matchesAccept(label))
                                || (alternate != null && alternate.length() <= 64 && matchesAccept(alternate));
                        boolean rejectLabel = ButtonLabels.isReject(label) || ButtonLabels.isReject(alternate);
                        boolean field = hasAsciiDigit(label) || hasAsciiDigit(alternate);
                        // Page hints still see every visible label. Only controls and potential
                        // card fields need geometry, enabled state, and a retained capture.
                        if (!exact && !rejectLabel && !field) continue;
                        seed.getBoundsInScreen(seedBounds);
                        boolean enabled = seed.isEnabled();
                        String key = String.valueOf(label) + "|" + description + "@" + seedBounds.left + ","
                                + seedBounds.top + "," + seedBounds.right + "," + seedBounds.bottom + ":" + enabled;
                        if (!sharedSeeds.add(key)) continue;
                        if (exact || field) {
                            IndexedSeedValue captured = new IndexedSeedValue(
                                    seed, label, description, seedBounds, true, liveWindow, enabled);
                            if (exact) exactButtons.add(captured);
                            if (field) sharedEvidence.add(captured);
                        }
                        if (rejectLabel && fastUniversalIndex) {
                            deferredRejectSeeds.add(new IndexedSeedValue(seed,label,description,seedBounds,true,liveWindow,enabled));
                        } else if (rejectLabel) {
                            AccessibilityNodeInfo resolved = safeActionBounds(rootBounds, seedBounds, false)
                                    && nodeIsActionable(seed) ? null
                                    : resolveIndexedRejectParent(seed, rootBounds, seedBounds, liveWindow, resolvedRejectBounds);
                            try {
                                Rect bounds = resolved == null ? seedBounds : resolvedRejectBounds;
                                if (safeActionBounds(rootBounds, bounds, false)) {
                                    addUniquePiece(pieces, "Reject", bounds);
                                    if (rejectBounds.isEmpty() || bounds.top < rejectBounds.top) {
                                        rejectBounds.set(bounds);
                                        rejectWitness.action(resolved == null ? seed : resolved);
                                    }
                                }
                            } finally {
                                if (resolved != null) resolved.recycle();
                            }
                        }
                    }
                    seedFilterAndRejectMs += SystemClock.elapsedRealtime() - filteringAt;
                }
                baselineComplete = true;
                discoveryReadyAt = rootReadyAt + actionQueryWaitMs;
                candidatesReadyAt = SystemClock.elapsedRealtime();
                AccessibilityNodeInfo winningSeed = null;
                Rect resolvedAcceptBounds = new Rect();
                for (IndexedSeedValue captured : exactButtons) {
                    AccessibilityNodeInfo seed = captured.node;
                    boolean direct = safeActionBounds(rootBounds, captured.bounds, true);
                    AccessibilityNodeInfo resolved = direct ? null : resolveIndexedAction(seed, rootBounds, true);
                    try {
                        if (!direct && resolved == null) continue;
                        if (resolved != null) resolved.getBoundsInScreen(resolvedAcceptBounds);
                        Rect bounds = direct ? captured.bounds : resolvedAcceptBounds;
                        if (!direct && !safeActionBounds(rootBounds, bounds, true)) continue;
                        addUniquePiece(pieces, "Accept", bounds);
                        if (bounds.top >= bestTop) continue;
                        bestTop = bounds.top;
                        actionBounds.set(bounds);
                        winningSeed = seed;
                        if (resolvedWinner != null) resolvedWinner.recycle();
                        resolvedWinner = resolved;
                        resolved = null;
                    } finally {
                        if (resolved != null) resolved.recycle();
                    }
                }
                if (winningSeed != null) {
                    // Only the top geometry can win. Avoid parent readiness reads on
                    // provisional lower candidates returned earlier by the text query.
                    witness.action(winningSeed);
                    // The universal-event bridge needs readiness immediately; otherwise finish
                    // the numeric routing first. A definite numeric rejection never needs an
                    // Accept ancestor walk. Keep an owned node for the unchanged readiness test.
                    if (fastUniversalIndex || !requireEnabled)
                        actionEnabled = actionNodeReady(resolvedWinner == null ? winningSeed : resolvedWinner);
                    else if (resolvedWinner != null)
                        deferredAcceptReadiness = AccessibilityNodeInfo.obtain(resolvedWinner);
                }
                controlReadyAt = SystemClock.elapsedRealtime();
                long deferredRejectStart=SystemClock.elapsedRealtime();
                for (IndexedSeedValue captured : deferredRejectSeeds) {
                    // A lower caption cannot be the boundary of the selected first row.
                    // Keep every upper/overlapping Reject, and all Rejects if Accept is absent/disabled.
                    if (actionEnabled && !actionBounds.isEmpty() && captured.bounds.top>=actionBounds.bottom)
                        continue;
                    AccessibilityNodeInfo seed=captured.node;
                    AccessibilityNodeInfo resolved=safeActionBounds(rootBounds,captured.bounds,false)
                            && nodeIsActionable(seed) ? null
                            : resolveIndexedRejectParent(seed,rootBounds,captured.bounds,liveWindow,resolvedRejectBounds);
                    try {
                        Rect bounds=resolved==null?captured.bounds:resolvedRejectBounds;
                        if (safeActionBounds(rootBounds,bounds,false)) {
                            addUniquePiece(pieces,"Reject",bounds);
                            if (rejectBounds.isEmpty() || bounds.top<rejectBounds.top) {
                                rejectBounds.set(bounds);
                                rejectWitness.action(resolved==null?seed:resolved);
                            }
                        }
                    } finally {if(resolved!=null) resolved.recycle();}
                }
                seedFilterAndRejectMs+=SystemClock.elapsedRealtime()-deferredRejectStart;
                if (!actionBounds.isEmpty())
                    collectCapturedIndexedEndpointPieces(sharedEvidence, actionBounds, pieces, witness, liveWindow, endpointSeeds);
                else if (requireEnabled && !rejectBounds.isEmpty() && baselineComplete && !baselineNegative)
                    collectCapturedIndexedEndpointPieces(sharedEvidence, rejectBounds, pieces, rejectWitness, liveWindow, endpointSeeds);
                sharedFieldsReadyAt = SystemClock.elapsedRealtime();
            } finally {
                if (resolvedWinner != null) resolvedWinner.recycle();
                for (AccessibilityNodeInfo node : sharedNodes) if (node != null) node.recycle();
            }
            boolean rejectOnly=actionBounds.isEmpty();
            if (rejectOnly && (!requireEnabled || rejectBounds.isEmpty() || !baselineComplete || baselineNegative
                    || rejectWitness.action==null || !actionNodeReady(rejectWitness.action)))
                return failAcceptIndex("NO_ACCEPT");
            Rect numberAnchor=rejectOnly ? rejectBounds : actionBounds;
            IndexedWitness numberWitness=rejectOnly ? rejectWitness : witness;
            for (CardText.Piece boundary : pieces)
                if (boundary.bottom < numberAnchor.top
                        && ("Reject".equals(boundary.text) || "Accept".equals(boundary.text)))
                    return failAcceptIndex("HIGHER_OFFER_ACTION");
            if (!currentScene.getAsBoolean()) return failAcceptIndex("WINDOW_CHANGED_ACTION");

            long actionReadyAt = SystemClock.elapsedRealtime();
            String actionText=CardText.aboveButton(pieces,numberAnchor.top,numberAnchor.bottom);
            boolean endpointReused = !OfferEnrichmentPolicy.endpointKey(actionText).isEmpty();
            boolean actionHasNumbers=CardText.amount(actionText)>=0f && CardText.miles(actionText)>=0f
                    && !CardText.containsMultipleMileageRows(actionText)
                    && !CardText.containsConflictingOfferNumbers(actionText);
            // v300: FIRST-SHOT EVENT BRIDGE. A fresh, universally eligible event
            // supplies the decision pair. The CURRENT enabled top CTA is still required.
            // Prefer descriptive overlap; when React Native exports ONLY the CTA label,
            // the user explicitly chose an aggressive <=80ms event/CTA bridge instead
            // of waiting for two slow numeric Binder calls. A wrong-card risk remains.
            boolean eventNumericBridge = false;
            if (fastUniversalIndex && !actionHasNumbers && !actionBounds.isEmpty()
                    && actionEnabled && !baselineNegative && hotEvent != null
                    && hotEvent.capturedAt <= SystemClock.elapsedRealtime()
                    && (CardText.compatiblePartialActionEvidence(hotEvent.text, actionText)
                        || (actionText.isEmpty() && hotEvent.identity != null
                            && !hotEvent.identity.isEmpty()
                            && SystemClock.elapsedRealtime() - hotEvent.capturedAt <= 80L))
                    && !CardText.containsMultipleMileageRows(hotEvent.text)
                    && !CardText.containsConflictingOfferNumbers(hotEvent.text)) {
                actionText = hotEvent.text;
                actionHasNumbers = true;
                eventNumericBridge = true;
            }
            final long numericWaitMs;
            if (actionQuery.complete() && !actionHasNumbers) {
                long numericWaitStartedAt = SystemClock.elapsedRealtime();
                int numericOffset = fastUniversalIndex ? 1 : 2;
                numericQueries = pendingQueries.takeWhile(numericOffset, numericOffset + 2, currentScene);
                numericWaitMs = SystemClock.elapsedRealtime() - numericWaitStartedAt;
                if (!numericQueries.complete()) return failAcceptIndex("ACTION_INDEX_" + numericQueries.reason);
                for (IndexedQueryResult result : numericQueries.values) {
                    List<AccessibilityNodeInfo> numericNodes=result.takeNodes();
                    try { collectIndexedNumericNodes(numericNodes,numberAnchor,pieces,numberWitness); }
                    finally { if(numericNodes!=null) for(AccessibilityNodeInfo node:numericNodes)
                        if(node!=null) node.recycle(); }
                }
            } else {
                numericWaitMs = 0L;
            }
            String numericText=actionHasNumbers?actionText:CardText.aboveButton(pieces,numberAnchor.top,numberAnchor.bottom);
            if(numericQueries==null && (CardText.amount(numericText)<0f || CardText.miles(numericText)<0f
                    || CardText.containsMultipleMileageRows(numericText) || CardText.containsConflictingOfferNumbers(numericText))) {
                collectIndexedOfferNumbers(root,numberAnchor,pieces,numberWitness);
                numericText=CardText.aboveButton(pieces,numberAnchor.top,numberAnchor.bottom);
            }
            long numericReadyAt = SystemClock.elapsedRealtime();
            final String rootReadTrace = ROOT_READ_TRACE.get();
            final BoundedReadBatch.Result<IndexedQueryResult> queryBatch = actionQuery;
            final long seedFilterMs = seedFilterAndRejectMs;
            final long actionWaitMs = actionQueryWaitMs;
            final BoundedReadBatch.Result<IndexedQueryResult> numberBatch = numericQueries;
            final boolean usedEventNumericBridge = eventNumericBridge;
            final java.util.function.Supplier<String> queryTrace = () -> !queryBatch.complete() ? "SERIAL_BUSY"
                    : (usedEventNumericBridge ? "PARALLEL_3_EVENT_BRIDGE_NO_NUMERIC_WAIT" :
                       fastUniversalIndex ? "PARALLEL_3_ELIGIBLE_ACCEPT" :
                       numberBatch == null ? "PARALLEL_4_ACTION_SUFFICIENT" : "PARALLEL_4_NUMBERS_NEEDED")
                    + ";discoveryMs=" + actionWaitMs + ";launchMs=" + queryBatch.launchMs
                    + ";queueMs=" + queryBatch.maxQueueMs
                    + ";seedFilterAndRejectMs=" + seedFilterMs
                    + ";acceptControlMs=" + (controlReadyAt-candidatesReadyAt)
                    + ";sharedFieldsMs=" + (sharedFieldsReadyAt-controlReadyAt)
                    + ";numericWaitMs=" + numericWaitMs
                    + ";queryMs(a/e/pay/mi)=" + actionReadMs[0] + "/" + actionReadMs[1]
                    + (numberBatch == null ? "/SKIPPED/SKIPPED"
                    : "/" + numberBatch.values.get(0).readMs + "/" + numberBatch.values.get(1).readMs);
            float parsedAmount = CardText.amount(numericText), parsedMiles = CardText.miles(numericText);
            // Routing only. Every configured numeric branch already fails; rebuilding city
            // cannot rescue this card. Publish the current pair for the independent Reject read.
            if (!CardText.containsConflictingOfferNumbers(numericText)
                    && UI_GENERATION.get() == generation
                    && OcrMonitorService.eventNumbersUniversallyRejected(parsedAmount, parsedMiles)) {
                cacheDecisionEvidence(numericText, generation);
                if (observationEpoch == WINDOW_TRANSITION_EPOCH.get()) {
                    FastOfferSnapshot rejected = boundIndexedReject(service, numericText, actionBounds,
                            rejectBounds, rejectWitness, rootBounds, liveWindow, generation,
                            observationEpoch, readStartedAt, baselineComplete && !baselineNegative);
                    rejected.stampSharedRejectRead(rootReadyAt, discoveryReadyAt, actionReadyAt, numericReadyAt,
                            rootReadTrace, queryTrace);
                    publishedReject = rejected.rejectProof != null;
                    REJECTED_SELF_INDEX.set(new RejectedIndexObservation(rejected, generation, observationEpoch));
                }
                return failAcceptIndex("NUMERIC_ALL_BRANCHES_REJECT");
            }

            // An unpaired Reject can only fast-route an offer that fails every numeric rule.
            if (rejectOnly) return failAcceptIndex("NO_ACCEPT");
            long lateAcceptReadinessStart=SystemClock.elapsedRealtime();
            if (!fastUniversalIndex && requireEnabled) {
                actionEnabled=actionNodeReady(deferredAcceptReadiness == null ? witness.action : deferredAcceptReadiness);
                if (!currentScene.getAsBoolean()) return failAcceptIndex("WINDOW_CHANGED_ACTION");
            }
            final long lateAcceptReadinessMs=SystemClock.elapsedRealtime()-lateAcceptReadinessStart;
            if (requireEnabled && !actionEnabled) return failAcceptIndex("ACCEPT_DISABLED");
            if(parsedAmount<0f || parsedMiles<0f) return failAcceptIndex("NUMERIC_MISSING");
            boolean generalQualified = allowGeneralNumeric
                    && parsedAmount >= generalMinPay
                    && parsedMiles >= 0f
                    && parsedMiles <= generalMaxMiles;
            int numericPieceCount = pieces.size();
            if (generalQualified) {
                // No extra merchant/endpoint Binder query before Accept: the configured
                // General numeric rule is already conclusive. Diagnostics/enrichment can
                // continue on later UI events without delaying the first gesture.
            } else {
                if (!pasadenaEnabled) return failAcceptIndex("NO_QUALIFIED_BRANCH");
                if (!LIVE_CA_ZIP.matcher(numericText).find())
                    collectIndexedLocationPieces(root, actionBounds, pieces, witness);
            }
            // Existing live siblings may already contain pickup time. Query it only when
            // absent; the final current-text/time and generation gates remain mandatory.
            // Field collectors only append unique pieces. Rebuild only after an actual addition.
            String currentText = pieces.size() == numericPieceCount ? numericText
                    : CardText.aboveButton(pieces, actionBounds.top, actionBounds.bottom);
            if (requireOfferTime && !LIVE_OFFER_TIME.matcher(currentText).find()) {
                collectIndexedOfferTimePieces(root, actionBounds, pieces, witness);
                currentText = CardText.aboveButton(pieces, actionBounds.top, actionBounds.bottom);
            }
            if (!currentScene.getAsBoolean()) return failAcceptIndex("WINDOW_CHANGED_FIELDS");
            if(currentText.isEmpty()) return failAcceptIndex("EMPTY_CARD");
            if(CardText.containsMultipleMileageRows(currentText)) return failAcceptIndex("MULTIPLE_CARDS");
            if(!generalQualified && !PasadenaRuleGuard.isPasadenaOffer(currentText)) {
                if(LIVE_CA_ZIP.matcher(currentText).find()
                        && !OfferEnrichmentPolicy.endpointKey(currentText).isEmpty()
                        && !CardText.containsConflictingOfferNumbers(currentText)
                        && quickNumericPairMatches(currentText,parsedAmount,parsedMiles)
                        && observationEpoch==WINDOW_TRANSITION_EPOCH.get()) {
                    FastOfferSnapshot rejected = boundIndexedReject(service, currentText, actionBounds,
                            rejectBounds, rejectWitness, rootBounds, liveWindow, generation,
                            observationEpoch, readStartedAt, baselineComplete && !baselineNegative);
                    rejected.stampSharedRejectRead(rootReadyAt, discoveryReadyAt, actionReadyAt, numericReadyAt,
                            rootReadTrace, queryTrace);
                    publishedReject = rejected.rejectProof != null;
                    REJECTED_SELF_INDEX.set(new RejectedIndexObservation(rejected, generation, observationEpoch));
                }
                return failAcceptIndex("SPECIAL_LOCATION_MISSING");
            }
            if(CardText.containsConflictingOfferNumbers(currentText)) return failAcceptIndex("NUMERIC_CONFLICT");
            if(!quickNumericPairMatches(currentText,parsedAmount,parsedMiles)) return failAcceptIndex("PAIR_CHANGED");
            if(requireOfferTime && !LIVE_OFFER_TIME.matcher(currentText).find()) return failAcceptIndex("PICKUP_TIME_MISSING");
            long verifiedAt = SystemClock.elapsedRealtime();
            IndexedReadProof proof = new IndexedReadProof(rootBounds,liveWindow,generation,
                    readStartedAt,verifiedAt,"INDEX_CURRENT_TOP");
            proof.deferredStages=() -> "INDEX_PHASE root=" + (rootReadyAt - readStartedAt)
                    + "ms,action=" + (actionReadyAt - rootReadyAt) + "ms,numeric="
                    + (numericReadyAt - actionReadyAt) + "ms,fields=" + (verifiedAt - numericReadyAt) + "ms,ACTION_INDEX=SHARED_A_E,ENDPOINT_REUSED=" + endpointReused
                    + ",ROOT_READ=" + rootReadTrace + ",ACTION_READ=" + queryTrace.get()
                    + ";exactLabels=SHARED"
                    + ";resolveMs=" + (actionReadyAt - discoveryReadyAt)
                    + ";queryCollectMs=0"
                    + ";seedFilterAndRejectMs=" + seedFilterMs
                    + ";acceptControlMs=" + (controlReadyAt - candidatesReadyAt)
                    + ";deferredAcceptControlMs=" + lateAcceptReadinessMs
                    + ";sharedFieldsMs=" + (sharedFieldsReadyAt - controlReadyAt)
                    + ";recycleAndRowGuardMs=" + (actionReadyAt - sharedFieldsReadyAt)
                    + ";numericWaitMs=" + numericWaitMs
                    + ";numericBindMs=" + Math.max(0L, numericReadyAt - actionReadyAt - numericWaitMs);
            proof.outcomeBaseline = new PageOutcomePolicy.Baseline(liveWindow, generation,
                    baselineEpoch, rootReadyAt, actionReadyAt, baselineComplete, baselineNegative);
            CURRENT_SURFACE_GATE.observe(baselineEpoch,rootReadyAt,actionReadyAt,
                    baselineComplete,baselineNegative,verifiedAt);
            if (actionEnabled && witness != null && !witness.overflow && witness.action != null
                    && !witness.fields.isEmpty()) {
                proof.witness = witness;
                if(requireEnabled && OcrMonitorService.pendingClaimSince()==0L)
                    rememberAcceptControl(witness.action,currentText,proof);
                if(requireEnabled) witness.publish(service,verifiedAt);
                else { // Retry-only ownership must not suppress ordinary event enrichment.
                    witness.capturedAt=verifiedAt;
                    service.main.postDelayed(witness::close,300L);
                }
                publishedWitness = true;
            }
            FastOfferSnapshot snapshot = new FastOfferSnapshot(currentText, actionBounds, new Rect(),
                    actionEnabled, false, verifiedAt, parsedAmount, parsedMiles, proof);
            recordNumericFirstSeen(snapshot.identity, parsedAmount, parsedMiles, numericReadyAt);
            noteAcceptAnchor(parsedAmount, parsedMiles, actionReadyAt);
            ACCEPT_INDEX_FAILURE.set("OK");
            return snapshot;
        } catch (RuntimeException failure) {
            return failAcceptIndex("READ_EXCEPTION:"+failure.getClass().getSimpleName());
        } finally {
            if (pendingQueries != null) pendingQueries.close();
            if (deferredAcceptReadiness != null) deferredAcceptReadiness.recycle();
            if (numericQueries != null)
                for (IndexedQueryResult result : numericQueries.values) result.close();
            if (!publishedReject) rejectWitness.close();
            if (witness != null && !publishedWitness) witness.close();
            try { root.recycle(); } catch (RuntimeException ignored) { }
        }
    }

    private static FastOfferSnapshot boundIndexedReject(TapAccessibilityService service, String text,
            Rect accept, Rect reject, IndexedWitness witness, Rect root, int window,
            long generation, long epoch, long startedAt, boolean clearPage) {
        long now = SystemClock.elapsedRealtime();
        String blocked = !clearPage ? "PAGE_NOT_CLEAN"
                : UI_GENERATION.get()!=generation || WINDOW_TRANSITION_EPOCH.get()!=epoch ? "UI_CHANGED"
                : witness.action==null ? "NO_REJECT_NODE"
                : CardText.containsMultipleMileageRows(text) || CardText.containsConflictingPickupEvidence(text)
                    || CardText.containsConflictingOfferNumbers(text) ? "CARD_CONFLICT"
                : !accept.isEmpty() && !ActionRowPolicy.pairedReject(reject.left, reject.top, reject.right, reject.bottom,
                        accept.left, accept.top, accept.right, accept.bottom) ? "DIFFERENT_ROW"
                : !witness.action.isEnabled() ? "REJECT_DISABLED"
                : !nodeIsActionable(witness.action) ? "REJECT_LABEL_ONLY"
                : "";
        boolean paired=blocked.isEmpty();
        FastOfferSnapshot snapshot = new FastOfferSnapshot(text, accept, paired ? reject : new Rect(),
                false, paired, now);
        if (paired) {
            if (!attachRejectProof(service, snapshot, witness, root, window, generation, epoch,
                    startedAt, accept.isEmpty() ? "SHARED_TOP_REJECT" : "SHARED_REJECT_ROW")) {
                snapshot=new FastOfferSnapshot(text, accept, new Rect(), false, false, now);
                blocked="WITNESS_CHANGED";
            } else snapshot.rejectReadStartedAt = startedAt;
        }
        snapshot.rejectReuseReason=blocked;
        return snapshot;
    }

    private static boolean attachRejectProof(TapAccessibilityService service, FastOfferSnapshot snapshot,
            IndexedWitness witness, Rect root, int window, long generation, long epoch,
            long startedAt, String source) {
        IndexedReadProof proof = new IndexedReadProof(root, window, generation, startedAt,
                snapshot.capturedAt, source);
        if (proof.windowEpoch != epoch || UI_GENERATION.get() != generation
                || witness.action == null || !witness.action.isEnabled() || !nodeIsActionable(witness.action))
            return false;
        proof.witness = witness;
        snapshot.rejectProof = proof;
        service.main.postDelayed(witness::close, 180L);
        return true;
    }

    /** Current first-card Reject data, independent of event-cache completeness. */
    public static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(
            boolean requireLocation, boolean requireOfferTime) {
        return getIndexedCurrentTopRejectSnapshot(requireLocation, requireOfferTime, 60L);
    }

    public static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(
            boolean requireLocation, boolean requireOfferTime, long softBudgetMs) {
        return getIndexedCurrentTopRejectSnapshot(requireLocation, requireOfferTime, softBudgetMs, null);
    }

    public static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(
            boolean requireLocation, boolean requireOfferTime, long softBudgetMs,
            java.util.function.BiPredicate<Float, Float> numericReject) {
        return getIndexedCurrentTopRejectSnapshot(requireLocation, requireOfferTime, softBudgetMs,
                numericReject, null);
    }

    public static FastOfferSnapshot getIndexedCurrentTopRejectSnapshot(
            boolean requireLocation, boolean requireOfferTime, long softBudgetMs,
            java.util.function.BiPredicate<Float, Float> numericReject, StringBuilder phases) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return failRejectRead(phases, "NO_SERVICE");
        long generation = UI_GENERATION.get();
        long startedAt = SystemClock.elapsedRealtime();
        long deadline = rejectReadDeadline(startedAt + Math.max(20L, Math.min(120L, softBudgetMs)));
        RejectReadProgress progress = REJECT_READ_PROGRESS.get();
        if (progress != null) progress.stage = "REJECT_INDEX";
        long epoch=WINDOW_TRANSITION_EPOCH.get();
        AccessibilityNodeInfo root = progress==null
                ? recentIndexedRoot(service,generation,startedAt,epoch) : null;
        boolean reusedRoot = root != null || REJECT_READ_ROOT.get() != null;
        if(root==null) root=rootForRejectRead(service);
        if (root == null) return failRejectRead(phases, "NO_ROOT");
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return failRejectRead(phases, "FOREIGN_APP");
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            if (rootBounds.isEmpty()) return failRejectRead(phases, "NO_ROOT_BOUNDS");

            long rootReadyAt = SystemClock.elapsedRealtime();
            List<CardText.Piece> pieces = new ArrayList<>();
            Rect actionBounds = new Rect();
            int bestTop = Integer.MAX_VALUE;
            boolean actionEnabled = false;
            for (String query : new String[]{"e"}) {
                if (SystemClock.elapsedRealtime() >= deadline) return failRejectRead(phases, "BUDGET");
                List<AccessibilityNodeInfo> indexed = null;
                try {
                    indexed = root.findAccessibilityNodeInfosByText(query);
                    if (indexed == null) continue;
                    for (AccessibilityNodeInfo seed : indexed) {
                        if (seed == null || seed.getWindowId() != root.getWindowId() || (!ButtonLabels.isReject(seed.getText())
                                && !ButtonLabels.isReject(seed.getContentDescription()))) continue;
                        AccessibilityNodeInfo action = resolveIndexedAction(
                                seed, rootBounds, false);
                        if (action == null) continue;
                        try {
                            Rect bounds = new Rect();
                            action.getBoundsInScreen(bounds);
                            if (!safeActionBounds(rootBounds, bounds, false)
                                    || bounds.top >= bestTop) continue;
                            bestTop = bounds.top;
                            actionBounds.set(bounds);
                            actionEnabled = actionNodeReady(action);
                        } finally { action.recycle(); }
                    }
                    if (!actionBounds.isEmpty())
                        collectIndexedNumericNodes(indexed, actionBounds, pieces, null);
                } finally {
                    if (indexed != null)
                        for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
                }
            }
            if (UI_GENERATION.get() != generation) return failRejectRead(phases, "UI_CHANGED_ACTION");
            if (actionBounds.isEmpty()) return failRejectRead(phases, "NO_REJECT_ACTION");
            if (!actionEnabled && REJECT_READ_PROGRESS.get() == null) return failRejectRead(phases, "REJECT_DISABLED");

            long actionReadyAt = SystemClock.elapsedRealtime();
            collectIndexedOfferNumbers(root, actionBounds, pieces);
            long numericReadyAt = SystemClock.elapsedRealtime();
            if (SystemClock.elapsedRealtime() >= deadline) return failRejectRead(phases, "BUDGET");
            String numericText = CardText.aboveButton(pieces, actionBounds.top, actionBounds.bottom);
            boolean finalNumericReject = numericReject != null
                    && numericReject.test(CardText.amount(numericText), CardText.miles(numericText));
            if (requireLocation && !finalNumericReject && !LIVE_CA_ZIP.matcher(numericText).find())
                collectIndexedLocationPieces(root, actionBounds, pieces);
            // Reuse current query fields; pickup identity remains mandatory before dispatch.
            if (!finalNumericReject && !LIVE_OFFER_TIME.matcher(numericText).find())
                collectIndexedOfferTimePieces(root, actionBounds, pieces);
            if (UI_GENERATION.get() != generation || WINDOW_TRANSITION_EPOCH.get()!=epoch)
                return failRejectRead(phases, "UI_CHANGED_FIELDS");
            if (SystemClock.elapsedRealtime() >= deadline) return failRejectRead(phases, "BUDGET_FIELDS");
            String currentText = finalNumericReject ? numericText : CardText.aboveButton(
                    pieces, actionBounds.top, actionBounds.bottom);
            if (currentText.isEmpty() || CardText.containsMultipleMileageRows(currentText)
                    || CardText.containsConflictingOfferNumbers(currentText)
                    || CardText.amount(currentText) < 0f || CardText.miles(currentText) < 0f)
                return failRejectRead(phases, "NUMERIC_INCOMPLETE_OR_CONFLICT");
            if (!finalNumericReject && (requireOfferTime || CardText.orderId(currentText).isEmpty())
                    && !LIVE_OFFER_TIME.matcher(currentText).find())
                return failRejectRead(phases, "PICKUP_TIME_MISSING");
            long readyAt = SystemClock.elapsedRealtime();
            if (phases != null) phases.append("；Reject索引分段 root=").append(rootReadyAt - startedAt)
                    .append("ms action=").append(actionReadyAt - rootReadyAt)
                    .append("ms numeric=").append(numericReadyAt - actionReadyAt)
                    .append("ms fields=").append(readyAt - numericReadyAt).append("ms")
                    .append(reusedRoot?"；Reject根节点=复用":"；Reject根节点=读取");
            FastOfferSnapshot snapshot = new FastOfferSnapshot(currentText, new Rect(), actionBounds, false, actionEnabled, readyAt);
            snapshot.rejectReadStartedAt = startedAt;
            return snapshot;
        } catch (RuntimeException ignored) {
            return failRejectRead(phases, "READ_EXCEPTION");
        } finally {
            try { root.recycle(); } catch (RuntimeException ignored) { }
        }
    }

    private static FastOfferSnapshot failRejectRead(StringBuilder phases, String reason) {
        if (phases != null) phases.append("=").append(reason);
        return null;
    }

    private static FastOfferSnapshot getIndexedNumericTopActionSnapshot(float expectedAmount,
                                                                         float expectedMiles,
                                                                         boolean accept,
                                                                         boolean requirePasadena) {
        return getIndexedNumericTopActionSnapshot(expectedAmount, expectedMiles, accept,
                requirePasadena, null, false);
    }

    private static FastOfferSnapshot getIndexedNumericTopActionSnapshot(float expectedAmount,
                                                                         float expectedMiles,
                                                                         boolean accept,
                                                                         boolean requirePasadena,
                                                                         String[] cityQueries,
                                                                         boolean requireOfferTime) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || expectedAmount < 0f || expectedMiles < 0f) return null;
        long readStartedAt = SystemClock.elapsedRealtime();
        long generation = UI_GENERATION.get();
        long windowEpoch = WINDOW_TRANSITION_EPOCH.get();
        AccessibilityNodeInfo root = accept ? readCurrentIndexedRoot(service,generation) : service.getRootInActiveWindow();
        if (root == null) return null;
        IndexedWitness witness = new IndexedWitness();
        boolean publishedWitness = false;
        List<CardText.Piece> pieces = new ArrayList<>();
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return null;
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            if (rootBounds.isEmpty()) return null;

            Rect actionBounds = new Rect();
            boolean actionEnabled = false;
            int bestTop = Integer.MAX_VALUE;
            long baselineStart = SystemClock.elapsedRealtime(), baselineEpoch = WINDOW_TRANSITION_EPOCH.get();
            boolean baselineComplete = false, baselineNegative = false;
            // All supported Reject labels contain e. Filter the single index result
            // through the same exact label and window/geometry checks below.
            String[] actionQueries = accept ? new String[]{"a", "e"} : new String[]{"e"};
            for (String query : actionQueries) {
                List<AccessibilityNodeInfo> indexed = null;
                try {
                    indexed = root.findAccessibilityNodeInfosByText(query);
                    if (indexed == null) { if (accept) return null; else continue; }
                    baselineComplete = true;
                    for (AccessibilityNodeInfo seed : indexed) {
                        if (seed == null || seed.getWindowId() != root.getWindowId()) continue;
                        if (accept) collectIndexedRejectBoundary(seed, rootBounds, pieces);
                        if (accept && seed.isVisibleToUser() && seed.getWindowId() == root.getWindowId()
                                && !pageNegativeHint(String.valueOf(seed.getText()) + " "
                                        + seed.getContentDescription()).isEmpty()) baselineNegative = true;
                        boolean labelMatch = accept
                                ? (matchesAccept(seed.getText())
                                || matchesAccept(seed.getContentDescription()))
                                : (ButtonLabels.isReject(seed.getText())
                                || ButtonLabels.isReject(seed.getContentDescription()));
                        if (!labelMatch) continue;
                        AccessibilityNodeInfo action = accept ? resolveIndexedAction(seed,rootBounds,true)
                                : resolveIndexedRejectAction(seed,rootBounds);
                        if (action == null) continue;
                        try {
                            Rect bounds = new Rect();
                            action.getBoundsInScreen(bounds);
                            if (!safeActionBounds(rootBounds, bounds, accept)) continue;
                            if (accept) addUniquePiece(pieces, "Accept", bounds);
                            if (bounds.top >= bestTop) continue;
                            bestTop = bounds.top;
                            actionBounds.set(bounds);
                            actionEnabled = actionNodeReady(action);
                            witness.action(accept ? seed : action);
                        } finally { action.recycle(); }
                    }
                    if (accept && !actionBounds.isEmpty())
                        collectIndexedEndpointPieces(indexed, actionBounds, pieces, witness, root.getWindowId());
                } finally {
                    if (indexed != null)
                        for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
                }
                if (!accept && !actionBounds.isEmpty()) break;
            }
            if (actionBounds.isEmpty() || !actionEnabled || UI_GENERATION.get() != generation)
                return null;

            if (accept) for (CardText.Piece boundary : pieces)
                if (boundary.bottom < actionBounds.top
                        && ("Reject".equals(boundary.text) || "Accept".equals(boundary.text))) return null;
            long baselineEnd = SystemClock.elapsedRealtime();
            String indexedText = CardText.aboveButton(pieces, actionBounds.top, actionBounds.bottom);
            if (!quickNumericPairMatches(indexedText, expectedAmount, expectedMiles)) {
                String amountTwo = String.format(Locale.US, "$%.2f", expectedAmount);
                String amountPlain = String.format(Locale.US, "%.2f", expectedAmount);
                String amountWhole = Math.abs(expectedAmount - Math.round(expectedAmount)) <= 0.011f
                        ? String.format(Locale.US, "$%.0f", expectedAmount) : "";
                String milesOne = String.format(Locale.US, "%.1f mi", expectedMiles);
                String milesWhole = Math.abs(expectedMiles - Math.round(expectedMiles)) <= 0.051f
                        ? String.format(Locale.US, "%.0f mi", expectedMiles) : "";
                for (String query : new String[]{amountTwo, amountPlain, amountWhole, milesOne, milesWhole}) {
                    if (quickNumericPairMatches(indexedText, expectedAmount, expectedMiles)
                            && !CardText.containsConflictingOfferNumbers(indexedText)) break;
                    if (query.isEmpty()) continue;
                    collectIndexedNumericPieces(root, new String[]{query}, actionBounds, pieces, accept ? witness : null);
                    String pair = CardText.aboveButton(pieces, actionBounds.top, actionBounds.bottom);
                    indexedText = pair;
                    if (!CardText.containsConflictingOfferNumbers(pair)
                            && quickNumericPairMatches(pair, expectedAmount, expectedMiles)) break;
                }
            }
            long numericReadyAt = SystemClock.elapsedRealtime();
            if (requirePasadena && !LIVE_CA_ZIP.matcher(CardText.aboveButton(
                    pieces, actionBounds.top, actionBounds.bottom)).find())
                collectIndexedLocationPieces(root, actionBounds, pieces, witness);
            if (cityQueries != null && cityQueries.length > 0)
                collectIndexedConfiguredCityPieces(root, actionBounds, cityQueries, pieces);
            if (requireOfferTime && !LIVE_OFFER_TIME.matcher(CardText.aboveButton(
                    pieces, actionBounds.top, actionBounds.bottom)).find())
                collectIndexedOfferTimePieces(root, actionBounds, pieces, witness);
            if (UI_GENERATION.get() != generation) return null;
            String currentText = CardText.aboveButton(
                    pieces, actionBounds.top, actionBounds.bottom);
            if (CardText.containsMultipleMileageRows(currentText)
                    || CardText.containsConflictingOfferNumbers(currentText)
                    || !quickNumericPairMatches(currentText, expectedAmount, expectedMiles)) return null;
            if (requirePasadena && !PasadenaRuleGuard.isPasadenaOffer(currentText)) return null;
            if (requireOfferTime && !LIVE_OFFER_TIME.matcher(currentText).find()) return null;
            Rect acceptBounds = accept ? actionBounds : new Rect();
            Rect rejectBounds = accept ? new Rect() : actionBounds;
            long verifiedAt = SystemClock.elapsedRealtime();
            IndexedReadProof proof = accept ? new IndexedReadProof(rootBounds, root.getWindowId(), generation,
                    readStartedAt, verifiedAt, "INDEX_EXACT") : null;
            if (proof != null) proof.deferredStages = () -> "INDEX_EXACT=" + (verifiedAt - readStartedAt)
                    + "ms,action=" + (baselineEnd - baselineStart) + "ms,numeric="
                    + (numericReadyAt - baselineEnd) + "ms,fields=" + (verifiedAt - numericReadyAt) + "ms";
            if (proof != null) proof.outcomeBaseline = new PageOutcomePolicy.Baseline(
                    root.getWindowId(), generation, baselineEpoch, baselineStart, baselineEnd,
                    baselineComplete, baselineNegative);
            if(accept) CURRENT_SURFACE_GATE.observe(baselineEpoch,baselineStart,baselineEnd,
                    baselineComplete,baselineNegative,verifiedAt);
            if (proof != null && witness != null && !witness.overflow
                    && witness.action != null && !witness.fields.isEmpty()) {
                proof.witness = witness;
                if(OcrMonitorService.pendingClaimSince()==0L) rememberAcceptControl(witness.action,currentText,proof);
                witness.publish(service, verifiedAt);
                publishedWitness = true;
            }
            FastOfferSnapshot snapshot = new FastOfferSnapshot(currentText, acceptBounds, rejectBounds,
                    accept, !accept, verifiedAt, CardText.amount(currentText), CardText.miles(currentText), proof);
            if (!accept) {
                if (WINDOW_TRANSITION_EPOCH.get() != windowEpoch || UI_GENERATION.get() != generation) return null;
                snapshot.rejectReadStartedAt = readStartedAt;
                publishedWitness = attachRejectProof(service, snapshot, witness, rootBounds,
                        root.getWindowId(), generation, windowEpoch, readStartedAt, "EXACT_REJECT_ROW");
            }
            return snapshot;
        } catch (RuntimeException ignored) {
            return null;
        } finally {
            if (witness != null && !publishedWitness) witness.close();
            try { root.recycle(); } catch (RuntimeException ignored) { }
        }
    }

    private static void collectIndexedPasadenaPieces(AccessibilityNodeInfo root,
                                                       Rect actionBounds,
                                                       List<CardText.Piece> pieces) {
        if (root == null || actionBounds == null || pieces == null) return;
        for (String city : PasadenaRuleGuard.indexedSearchCities()) {
            boolean foundCurrentEndpoint = false;
            List<AccessibilityNodeInfo> indexed = null;
            try {
                indexed = root.findAccessibilityNodeInfosByText(city);
                if (indexed == null) continue;
                for (AccessibilityNodeInfo node : indexed) {
                    if (node == null) continue;
                    Rect bounds = new Rect();
                    node.getBoundsInScreen(bounds);
                    if (bounds.isEmpty() || bounds.top >= actionBounds.top) continue;
                    CharSequence text = node.getText();
                    CharSequence desc = node.getContentDescription();
                    String rawText = text == null ? "" : text.toString();
                    String rawDesc = desc == null ? "" : desc.toString();
                    // Exact endpoint parsing prevents merchant names such as "Commerce Cafe"
                    // from becoming city evidence. Broad multi-card parents are rejected by
                    // CardText.aboveButton() and therefore cannot cross-bind adjacent cards.
                    if (PasadenaRuleGuard.isPasadenaOffer(rawText)
                            && !CardText.containsMultipleMileageRows(rawText)) {
                        addUniquePiece(pieces, rawText, bounds);
                        foundCurrentEndpoint = true;
                    }
                    if (!rawDesc.equals(rawText) && PasadenaRuleGuard.isPasadenaOffer(rawDesc)
                            && !CardText.containsMultipleMileageRows(rawDesc)) {
                        addUniquePiece(pieces, rawDesc, bounds);
                        foundCurrentEndpoint = true;
                    }
                }
            } finally {
                if (indexed != null)
                    for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
            }
            if (foundCurrentEndpoint) return;
        }
    }

    private static void collectIndexedConfiguredCityPieces(AccessibilityNodeInfo root,
                                                             Rect actionBounds,
                                                             String[] cityQueries,
                                                             List<CardText.Piece> pieces) {
        if (root == null || actionBounds == null || cityQueries == null || pieces == null) return;
        java.util.HashSet<String> used = new java.util.HashSet<>();
        for (String configured : cityQueries) {
            String city = configured == null ? "" : configured.trim();
            if (city.isEmpty() || !used.add(city.toLowerCase(Locale.US))) continue;
            List<AccessibilityNodeInfo> indexed = null;
            try {
                indexed = root.findAccessibilityNodeInfosByText(city);
                if (indexed == null) continue;
                for (AccessibilityNodeInfo node : indexed) {
                    if (node == null) continue;
                    Rect bounds = new Rect();
                    node.getBoundsInScreen(bounds);
                    if (bounds.isEmpty() || bounds.top >= actionBounds.top) continue;
                    CharSequence text = node.getText(), desc = node.getContentDescription();
                    String rawText = text == null ? "" : text.toString();
                    String rawDesc = desc == null ? "" : desc.toString();
                    String cityLower = city.toLowerCase(Locale.US);
                    if (rawText.toLowerCase(Locale.US).contains(cityLower)
                            && !CardText.containsMultipleMileageRows(rawText))
                        addUniquePiece(pieces, rawText, bounds);
                    if (!rawDesc.equals(rawText)
                            && rawDesc.toLowerCase(Locale.US).contains(cityLower)
                            && !CardText.containsMultipleMileageRows(rawDesc))
                        addUniquePiece(pieces, rawDesc, bounds);
                }
            } finally {
                if (indexed != null)
                    for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
            }
        }
    }

    private static void collectIndexedOfferTimePieces(AccessibilityNodeInfo root,
                                                        Rect actionBounds,
                                                        List<CardText.Piece> pieces) {
        collectIndexedOfferTimePieces(root,actionBounds,pieces,null);
    }

    private static void collectIndexedOfferTimePieces(AccessibilityNodeInfo root,
            Rect actionBounds,List<CardText.Piece> pieces,IndexedWitness witness) {
        if (root == null || actionBounds == null || pieces == null) return;
        for (String query : new String[]{"Today", "Tomorrow"}) {
            List<AccessibilityNodeInfo> indexed = null;
            try {
                indexed = root.findAccessibilityNodeInfosByText(query);
                if (indexed == null) continue;
                for (AccessibilityNodeInfo node : indexed) {
                    if (node == null) continue;
                    Rect bounds = new Rect();
                    node.getBoundsInScreen(bounds);
                    if (bounds.isEmpty() || bounds.top >= actionBounds.top) continue;
                    CharSequence text = node.getText(), desc = node.getContentDescription();
                    String rawText = text == null ? "" : text.toString();
                    String rawDesc = desc == null ? "" : desc.toString();
                    if(witness!=null && ((LIVE_OFFER_TIME.matcher(rawText).find()
                            && !CardText.containsMultipleMileageRows(rawText))
                            || (LIVE_OFFER_TIME.matcher(rawDesc).find()
                            && !CardText.containsMultipleMileageRows(rawDesc)))) witness.field(node);
                    if (LIVE_OFFER_TIME.matcher(rawText).find()
                            && !CardText.containsMultipleMileageRows(rawText))
                        addUniquePiece(pieces, rawText, bounds);
                    if (!rawDesc.equals(rawText) && LIVE_OFFER_TIME.matcher(rawDesc).find()
                            && !CardText.containsMultipleMileageRows(rawDesc))
                        addUniquePiece(pieces, rawDesc, bounds);
                }
            } finally {
                if (indexed != null)
                    for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
            }
        }
    }

    private static void collectIndexedLocationPieces(AccessibilityNodeInfo root, Rect actionBounds,
            List<CardText.Piece> pieces) {
        collectIndexedLocationPieces(root,actionBounds,pieces,null);
    }

    private static void collectIndexedLocationPieces(AccessibilityNodeInfo root,Rect actionBounds,
            List<CardText.Piece> pieces,IndexedWitness witness) {
        for (String query : new String[]{", CA", "California"}) {
            collectIndexedNumericPieces(root, new String[]{query}, actionBounds, pieces, witness);
            String text = CardText.aboveButton(pieces, actionBounds.top, actionBounds.bottom);
            if (LIVE_CA_ZIP.matcher(text).find()) return;
        }
    }

    /** Current action-query nodes can also contain the endpoint; no new Binder query needed. */
    /** Last-window check for snapshots without an indexed top-row receipt (tree/visual).
     * Disabled actions remain boundaries. No higher readable offer may be skipped. */
    private static boolean noHigherIndexedOfferAction(AccessibilityNodeInfo root, Rect rootBounds,
                                                       float expectedTop) {
        TapAccessibilityService service=INSTANCE.get();
        if(service==null) return false;
        long generation=UI_GENERATION.get();
        int window=root.getWindowId();
        BoundedReadBatch.Result<IndexedQueryResult> read=
                readIndexedQueryPairWithBudget(service,root,"a","e",45L);
        try {
            if(!read.complete()) return false;
            for(IndexedQueryResult result:read.values) {
                List<AccessibilityNodeInfo> indexed=result.takeNodes();
                try {
                    if(indexed==null) return false;
                    for(AccessibilityNodeInfo seed:indexed) {
                        if(seed==null || !seed.isVisibleToUser() || seed.getWindowId()!=window) continue;
                        CharSequence text=seed.getText(),desc=seed.getContentDescription();
                        if(!pageNegativeHint(String.valueOf(text)+" "+desc).isEmpty()) return false;
                        boolean accept=matchesAccept(text)||matchesAccept(desc);
                        boolean reject=ButtonLabels.isReject(text)||ButtonLabels.isReject(desc);
                        if(!accept && !reject) continue;
                        AccessibilityNodeInfo action=resolveIndexedAction(seed,rootBounds,accept);
                        if(action==null) continue;
                        try {
                            Rect bounds=new Rect();action.getBoundsInScreen(bounds);
                            if(safeActionBounds(rootBounds,bounds,accept) && bounds.bottom<expectedTop) return false;
                        } finally {action.recycle();}
                    }
                } finally {if(indexed!=null)for(AccessibilityNodeInfo node:indexed)if(node!=null)node.recycle();}
            }
            return UI_GENERATION.get()==generation;
        } catch(RuntimeException unreadable) {return false;}
        finally {for(IndexedQueryResult result:read.values)if(result!=null)result.close();}
    }

    /** Every exported left action is a card boundary, even disabled/processing. */
    private static void collectIndexedRejectBoundary(AccessibilityNodeInfo seed, Rect rootBounds,
                                                       List<CardText.Piece> pieces) {
        if (seed == null || !seed.isVisibleToUser()
                || (!ButtonLabels.isReject(seed.getText())
                    && !ButtonLabels.isReject(seed.getContentDescription()))) return;
        AccessibilityNodeInfo action = resolveIndexedAction(seed, rootBounds, false);
        if (action == null) return;
        try {
            Rect bounds = new Rect();
            action.getBoundsInScreen(bounds);
            if (safeActionBounds(rootBounds, bounds, false))
                addUniquePiece(pieces, "Reject", bounds);
        } finally { action.recycle(); }
    }

    private static void collectIndexedEndpointPieces(List<AccessibilityNodeInfo> indexed,
            Rect actionBounds, List<CardText.Piece> pieces, IndexedWitness witness, int windowId) {
        collectIndexedEndpointPieces(indexed,actionBounds,pieces,witness,windowId,null);
    }
    private static void collectIndexedEndpointPieces(List<AccessibilityNodeInfo> indexed,
            Rect actionBounds,List<CardText.Piece> pieces,IndexedWitness witness,int windowId,java.util.Set<String> seen) {
        if (indexed == null) return;
        for (AccessibilityNodeInfo node : indexed) {
            if (node == null || !node.isVisibleToUser() || node.getWindowId()!=windowId) continue;
            Rect bounds=new Rect();node.getBoundsInScreen(bounds);
            if(bounds.isEmpty() || bounds.top>=actionBounds.top) continue;
            CharSequence text = node.getText(), desc = node.getContentDescription();
            String raw = text == null ? "" : text.toString();
            String description = desc == null ? "" : desc.toString();
            appendIndexedEndpointPiece(node,raw,description,bounds,pieces,witness,seen);
        }
    }

    private static final class IndexedSeedValue {
        final AccessibilityNodeInfo node;
        final String text,description;
        final Rect bounds;
        final boolean visible,enabled;
        final int window;
        IndexedSeedValue(AccessibilityNodeInfo node,CharSequence text,CharSequence description,
                         Rect bounds,boolean visible,int window,boolean enabled) {
            this.node=node;this.text=text==null?"":text.toString();
            this.description=description==null?"":description.toString();
            this.bounds=new Rect(bounds);this.visible=visible;this.window=window;this.enabled=enabled;
        }
    }
    private static void collectCapturedIndexedEndpointPieces(List<IndexedSeedValue> indexed,
            Rect actionBounds,List<CardText.Piece> pieces,IndexedWitness witness,int windowId,java.util.Set<String> seen) {
        for(IndexedSeedValue seed:indexed) {
            if(!seed.visible || seed.window!=windowId || seed.bounds.isEmpty()
                    || seed.bounds.top>=actionBounds.top) continue;
            appendIndexedEndpointPiece(seed.node,seed.text,seed.description,seed.bounds,pieces,witness,seen);
        }
    }
    // Every supported amount, mileage and endpoint contains an ASCII digit.
    // Skip parsing toolbar/action captions before creating cached parse facts.
    private static boolean hasAsciiDigit(CharSequence value) {
        if (value == null) return false;
        for (int i=0;i<value.length();i++) {
            char ch=value.charAt(i);
            if (ch>='0' && ch<='9') return true;
        }
        return false;
    }

    private static void appendIndexedEndpointPiece(AccessibilityNodeInfo node,String raw,String description,
            Rect bounds,List<CardText.Piece> pieces,IndexedWitness witness,java.util.Set<String> seen) {
            if(seen!=null && !seen.add(raw+"|"+description+"@"+bounds.left+","+bounds.top+","+bounds.right+","+bounds.bottom)) return;
            boolean hasTextEndpoint = !OfferEnrichmentPolicy.endpointKey(raw).isEmpty();
            boolean hasDescEndpoint = !description.equals(raw)
                    && !OfferEnrichmentPolicy.endpointKey(description).isEmpty();
            boolean hasTextNumbers=CardText.amount(raw)>=0f || CardText.miles(raw)>=0f;
            boolean hasDescNumbers=!description.equals(raw)
                    && (CardText.amount(description)>=0f || CardText.miles(description)>=0f);
            if (!hasTextEndpoint && !hasDescEndpoint && !hasTextNumbers && !hasDescNumbers) return;
            if (((hasTextEndpoint || hasTextNumbers) && (CardText.containsMultipleMileageRows(raw)
                    || CardText.containsConflictingOfferNumbers(raw)))
                    || ((hasDescEndpoint || hasDescNumbers) && (CardText.containsMultipleMileageRows(description)
                    || CardText.containsConflictingOfferNumbers(description)))) return;
            if (witness != null) witness.field(node,raw,description);
            if (hasTextEndpoint || hasTextNumbers) addUniquePiece(pieces, raw, bounds);
            if (hasDescEndpoint || hasDescNumbers) addUniquePiece(pieces, description, bounds);
    }

    private static void collectIndexedOfferNumbers(AccessibilityNodeInfo root, Rect actionBounds,
            List<CardText.Piece> pieces) {
        collectIndexedOfferNumbers(root, actionBounds, pieces, null);
    }

    private static void collectIndexedOfferNumbers(AccessibilityNodeInfo root, Rect actionBounds,
            List<CardText.Piece> pieces, IndexedWitness witness) {
        String existing=CardText.aboveButton(pieces,actionBounds.top,actionBounds.bottom);
        if(!CardText.containsMultipleMileageRows(existing) && !CardText.containsConflictingOfferNumbers(existing)
                && CardText.amount(existing)>=0f && CardText.miles(existing)>=0f) return;
        boolean needsPay = CardText.amount(existing) < 0f;
        boolean needsMiles = CardText.miles(existing) < 0f;
        TapAccessibilityService service = INSTANCE.get();
        if (needsPay && needsMiles && service != null) {
            BoundedReadBatch.Result<IndexedQueryResult> reads =
                    readIndexedQueryPair(service, root, "$", "mi");
            try {
                if (reads.complete()) {
                    for (IndexedQueryResult result : reads.values) {
                        List<AccessibilityNodeInfo> nodes = result.takeNodes();
                        try { collectIndexedNumericNodes(nodes, actionBounds, pieces, witness); }
                        finally {
                            for (AccessibilityNodeInfo node : nodes) if (node != null) node.recycle();
                        }
                    }
                    return;
                }
                if (!"BUSY".equals(reads.reason))
                    throw new IllegalStateException("NUMERIC_INDEX_" + reads.reason);
            } finally {
                for (IndexedQueryResult result : reads.values) result.close();
            }
        }
        // Read only missing fields. "mi" covers both spaced and compact mileage.
        if (needsPay) collectIndexedNumericPieces(root, new String[]{"$"}, actionBounds, pieces, witness);
        String text = CardText.aboveButton(pieces, actionBounds.top, actionBounds.bottom);
        if (CardText.miles(text) < 0f)
            collectIndexedNumericPieces(root, new String[]{"mi"}, actionBounds, pieces, witness);
    }


    private static void collectIndexedNumericPieces(AccessibilityNodeInfo root, String[] queries,
                                                     Rect actionBounds,
                                                     List<CardText.Piece> pieces) {
        collectIndexedNumericPieces(root, queries, actionBounds, pieces, null);
    }

    private static void collectIndexedNumericPieces(AccessibilityNodeInfo root, String[] queries,
            Rect actionBounds, List<CardText.Piece> pieces, IndexedWitness witness) {
        if (root == null || queries == null || actionBounds == null || pieces == null) return;
        java.util.HashSet<String> used = new java.util.HashSet<>();
        for (String query : queries) {
            if (query == null || query.isEmpty() || !used.add(query.toLowerCase(Locale.US))) continue;
            List<AccessibilityNodeInfo> indexed = null;
            try {
                indexed = root.findAccessibilityNodeInfosByText(query);
                if (indexed == null) continue;
                collectIndexedNumericNodes(indexed, actionBounds, pieces, witness);
            } finally {
                if (indexed != null)
                    for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
            }
        }
    }

    private static void collectIndexedNumericNodes(List<AccessibilityNodeInfo> indexed,
            Rect actionBounds, List<CardText.Piece> pieces, IndexedWitness witness) {
        for (AccessibilityNodeInfo node : indexed) {
            if (node == null) continue;
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (bounds.isEmpty() || bounds.top >= actionBounds.top) continue;
            CharSequence text = node.getText(), desc = node.getContentDescription();
            String raw=text==null?"":text.toString();
            String description=desc==null?"":desc.toString();
            if (witness != null) witness.field(node,raw,description);
            if (!raw.isEmpty()) addUniquePiece(pieces,raw,bounds);
            if (!description.isEmpty() && !description.equals(raw))
                addUniquePiece(pieces,description,bounds);
        }
    }

    public static FastOfferSnapshot quickVerifyTopAction(float expectedAmount, float expectedMiles,
                                                          boolean accept) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return null;
        return quickRefreshTopAction(service, expectedAmount, expectedMiles, accept);
    }

    private static FastOfferSnapshot quickRefreshTopAction(TapAccessibilityService service,
                                                            float expectedAmount, float expectedMiles,
                                                            boolean accept) {
        if (service == null) return null;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return null;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return null;
            PageGuard.Page page = quickPageOf(root, 32);
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) return null;

            QuickActionProbe probe = new QuickActionProbe();
            root.getBoundsInScreen(probe.rootBounds);
            if (probe.rootBounds.isEmpty()) return null;
            // This is now only a fallback after exact numeric indexing. Bound both time and
            // nodes so one slow OEM binder read cannot recreate the former ~300ms hot-path tax.
            probe.startedAt = SystemClock.elapsedRealtime();
            probe.deadlineAt = probe.startedAt + 90L;
            int[] budget = new int[]{128};
            quickCollectActionEvidence(root, probe, budget);
            // Semantic action labels always win. This is both faster and prevents a structural
            // Large Order info entry from being treated as Ignore.
            List<ActionHit> semantic = new ArrayList<>(accept ? probe.accepts : probe.rejects);
            semantic.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                    .thenComparingInt(hit -> hit.bounds.left));
            for (ActionHit hit : semantic) {
                if (!safeActionBounds(probe.rootBounds, hit.bounds, accept)) continue;
                String text = CardText.aboveButton(probe.pieces, hit.bounds.top, hit.bounds.bottom);
                if (!quickNumericPairMatches(text, expectedAmount, expectedMiles)) continue;
                Rect a = new Rect(), r = new Rect();
                boolean ae = false, re = false;
                if (accept) { a.set(hit.bounds); ae = hit.enabled; }
                else { r.set(hit.bounds); re = hit.enabled; }
                return new FastOfferSnapshot(text, a, r, ae, re,
                        SystemClock.elapsedRealtime());
            }

            // Blank-label controls remain a fallback. Within the first matching row select the
            // rightmost side-valid control; for Reject this is the control nearest Accept and
            // skips a farther-left Large Order info entry.
            ActionHit structuralBest = null;
            String structuralText = "";
            for (ActionHit hit : probe.structural) {
                if (!safeActionBounds(probe.rootBounds, hit.bounds, accept)) continue;
                String text = CardText.aboveButton(probe.pieces, hit.bounds.top, hit.bounds.bottom);
                if (!quickNumericPairMatches(text, expectedAmount, expectedMiles)) continue;
                if (structuralBest == null) {
                    structuralBest = hit;
                    structuralText = text;
                    continue;
                }
                boolean sameCandidateRow = sameActionRow(hit.bounds, structuralBest.bounds);
                if ((sameCandidateRow && hit.bounds.exactCenterX() > structuralBest.bounds.exactCenterX())
                        || (!sameCandidateRow && hit.bounds.top < structuralBest.bounds.top)) {
                    structuralBest = hit;
                    structuralText = text;
                }
            }
            if (structuralBest != null) {
                Rect a = new Rect(), r = new Rect();
                boolean ae = false, re = false;
                if (accept) { a.set(structuralBest.bounds); ae = structuralBest.enabled; }
                else { r.set(structuralBest.bounds); re = structuralBest.enabled; }
                return new FastOfferSnapshot(structuralText, a, r, ae, re,
                        SystemClock.elapsedRealtime());
            }
            return null;
        } finally { root.recycle(); }
    }

    private static void quickCollectActionEvidence(AccessibilityNodeInfo node,
                                                    QuickActionProbe probe, int[] budget) {
        if (node == null || probe == null || budget[0] <= 0) return;
        checkFallbackRead();
        RejectReadProgress progress = REJECT_READ_PROGRESS.get();
        if (progress != null && !progress.mayRead(SystemClock.elapsedRealtime())) {
            probe.budgetExceeded = true; budget[0] = 0; return;
        }
        budget[0]--;
        probe.visited++;
        if (probe.deadlineAt > 0L && SystemClock.elapsedRealtime() >= probe.deadlineAt) {
            probe.budgetExceeded = true;
            budget[0] = 0;
            return;
        }
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        if (progress != null) progress.visited++;
        CharSequence text = node.getText(), desc = node.getContentDescription();
        boolean usable = node.isVisibleToUser() || node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0;
        if (usable && !bounds.isEmpty()) {
            if (text != null && text.length() > 0) {
                noteQuickEvidence(probe, node, text);
                addUniquePiece(probe.pieces, text.toString(), bounds);
            }
            if (desc != null && desc.length() > 0 && !desc.equals(text)) {
                noteQuickEvidence(probe, node, desc);
                addUniquePiece(probe.pieces, desc.toString(), bounds);
            }
            // Action labels are a tiny vocabulary. Long React-Native card descriptions can
            // never equal Accept/Claim/Reject, so do not normalize hundreds of characters.
            boolean acceptMatch = (text != null && text.length() <= 64 && matchesAccept(text))
                    || (desc != null && desc.length() <= 64 && matchesAccept(desc));
            boolean rejectMatch = (text != null && text.length() <= 64 && ButtonLabels.isReject(text))
                    || (desc != null && desc.length() <= 64 && ButtonLabels.isReject(desc));
            if (acceptMatch && safeActionBounds(probe.rootBounds, bounds, true)) {
                addUniqueHit(probe.accepts, bounds, actionNodeReady(node));
                probe.sawAction = true;
            }
            if (rejectMatch && safeActionBounds(probe.rootBounds, bounds, false)) {
                addUniqueHit(probe.rejects, bounds, actionNodeReady(node));
                probe.sawAction = true;
            }
            if (!acceptMatch && !rejectMatch
                    && structuralActionShape(node, bounds, probe.rootBounds)) {
                // structuralActionShape already proves this node itself is actionable.
                // Do not climb six parents merely to rediscover that fact.
                addUniqueHit(probe.structural, bounds, node.isEnabled());
                probe.sawAction = true;
            }
        }
        if (!probe.completeTraversal && QuickEvidencePolicy.canStop(probe.sawMoney, probe.sawMiles,
                probe.sawLocation, probe.sawAction)) { budget[0] = 0; return; }
        if (probe.deadlineAt > 0L && SystemClock.elapsedRealtime() >= probe.deadlineAt) {
            probe.budgetExceeded = true;
            budget[0] = 0;
            return;
        }
        for (int i = 0, children = node.getChildCount(); i < children && budget[0] > 0; i++) {
            if (probe.deadlineAt > 0L && SystemClock.elapsedRealtime() >= probe.deadlineAt) {
                probe.budgetExceeded = true;
                budget[0] = 0;
                break;
            }
            checkFallbackRead();
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { quickCollectActionEvidence(child, probe, budget); }
                finally { child.recycle(); }
            }
            if (!probe.completeTraversal && QuickEvidencePolicy.canStop(probe.sawMoney, probe.sawMiles,
                    probe.sawLocation, probe.sawAction)) { budget[0] = 0; break; }
            if (probe.budgetExceeded) break;
        }
    }

    private static void noteQuickEvidence(QuickActionProbe probe, AccessibilityNodeInfo node,
                                          CharSequence raw) {
        if (probe == null || raw == null) return;
        String value = raw.toString();
        String valueLower = value.toLowerCase(Locale.US);
        if (valueLower.contains("deliveries") && valueLower.contains("jobs") && valueLower.contains("offers")) {
            probe.sawDeliveriesHub = true; probe.sawOffersLabel = true; probe.sawJobsLabel = true;
        }
        if (valueLower.contains("pickup instructions") || valueLower.contains("dropoff instructions")
                || valueLower.contains("delivery instructions")) probe.sawJobInstructions = true;
        if (valueLower.contains("begin") && ClaimSuccessSignals.hasBeginDeliveryControl(value))
            probe.sawBeginDelivery = true;
        if (valueLower.contains("delivery timeline")) probe.sawJobTimeline = true;
        if (valueLower.contains("approver name")) probe.sawApprover = true;
        if (valueLower.contains("nuid")) probe.sawNuid = true;
        if (valueLower.contains("gl string")) probe.sawGlString = true;
        // Cheap lexical gates avoid launching regex engines on every generic RN container.
        if (!probe.sawMoney && (value.indexOf('$') >= 0 || valueLower.contains("usd"))
                && LIVE_MONEY.matcher(value).find()) probe.sawMoney = true;
        if (!probe.sawMiles && (valueLower.contains(" mi") || valueLower.contains("mile"))
                && LIVE_MILES.matcher(value).find()) probe.sawMiles = true;
        if (!probe.sawLocation) {
            probe.sawLocation = valueLower.contains(", ca") || valueLower.contains(" california");
            if (!probe.sawLocation && valueLower.contains("ca "))
                probe.sawLocation = LIVE_CA_ZIP.matcher(value).find();
        }
        // Page/action labels are short. Long card descriptions cannot equal these exact labels.
        if (value.length() <= 64) {
            String label = lettersOnlyLower(value);
            if (label.equals("deliveries")) probe.sawDeliveriesHub = true;
            if (label.equals("offers")) probe.sawOffersLabel = true;
            if (label.equals("jobs")) probe.sawJobsLabel = true;
            if (node != null && (node.isSelected() || node.isChecked())) {
                if (label.equals("ignored")) probe.flags[0] = true;
                if (label.equals("jobs")) probe.flags[1] = true;
                if (label.equals("offers") || label.startsWith("offers")) probe.flags[2] = true;
            }
            if (label.equals("restore") || label.equals("restorebutton")) probe.flags[3] = true;
            if (ButtonLabels.isReject(raw)) probe.flags[4] = true;
            if (matchesAccept(raw)) probe.flags[5] = true;
            if (EmptyOffersPolicy.isExplicitEmpty(value.toString())) probe.flags[6] = true;
        }
    }

    private static boolean quickNumericPairMatches(String text, float expectedAmount,
                                                   float expectedMiles) {
        if (text == null || text.isEmpty() || expectedAmount < 0 || expectedMiles < 0) return false;
        float amount = -1f, miles = -1f;
        java.util.regex.Matcher range = LIVE_MONEY_RANGE.matcher(text);
        java.util.regex.Matcher money = LIVE_MONEY.matcher(text);
        java.util.regex.Matcher mi = LIVE_MILES.matcher(text);
        try {
            if (range.find()) amount = Float.parseFloat(range.group(1).replace(',', '.'));
            else if (money.find()) amount = Float.parseFloat(money.group(1).replace(',', '.'));
            if (mi.find()) miles = Float.parseFloat(mi.group(1).replace(',', '.'));
        } catch (RuntimeException ignored) { return false; }
        return amount >= 0 && miles >= 0
                && Math.abs(amount - expectedAmount) <= 0.011f
                && Math.abs(miles - expectedMiles) <= 0.051f;
    }

    /**
     * v2.10.5 first-tap path. The card has already been read and isolated by the same
     * Accessibility scan, so do not spend another 200-800 ms walking the entire tree before
     * the first gesture. We only accept a very fresh snapshot, re-check the active package,
     * window bounds and a small forbidden-page probe, then tap the verified top-card button.
     */
    public static void tapSnapshotFast(FastOfferSnapshot snapshot, float amount, float miles,
                                       Runnable completion, Consumer<String> mismatch) {
        tapSnapshotFastDetailed(snapshot, amount, miles,
                detail -> { if (completion != null) completion.run(); }, mismatch);
    }

    /**
     * v2.10.12 Accept path: dispatch the verified top-card gesture immediately. Real-device
     * logs showed ACTION_CLICK consumed an extra observation round but did not change the UI,
     * while the 55ms gesture did move DeliverThat into disabled/processing state. Keep the
     * semantic machinery only as a diagnostic/fallback elsewhere; it is no longer on the
     * latency-critical first-claim path. A successful gesture dispatch is still not treated
     * as an accepted job by itself.
     */
    public static void tapSnapshotFastDetailed(FastOfferSnapshot snapshot, float amount, float miles,
                                                Consumer<String> completion, Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || snapshot == null || snapshot.acceptBounds.isEmpty()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "顶部Accept快照不可用");
            return;
        }
        // v2.10.117: this method is called from the dedicated urgent offer worker. Android's
        // dispatchGesture() is a Binder call and accepts a Handler for its callback; it does not
        // require the caller itself to wait in the Accessibility main-thread queue. All mutable
        // transaction fields are already volatile/atomic. Verify and dispatch on the current
        // urgent lane. Monitored Accept callbacks use the idle direct worker so UI-event
        // handling cannot delay gesture completion. This removes the
        // 20-60ms queue delay seen after the Accept anchor became visible.
        {
            long preflightStartedAt = SystemClock.elapsedRealtime();
            long initialAge = preflightStartedAt - snapshot.capturedAt;
            // v2.10.296 SPEED-FIRST: a previously indexed Accept rectangle remains actionable
            // even when its read receipt aged or a React-Native UI event changed generation.
            // There is no second Binder tree walk between the indexed decision and first tap.
            // The user explicitly prefers the risk of an outdated same-app tap to losing a bid.
            // v299: Accept candidates have already passed upstream amount/mileage
            // admission. Do not block first gesture on a 380/2200ms receipt TTL or
            // queue a second Binder action/number refresh. Wrong same-app tap is an
            // explicit user-accepted tradeoff; foreground and terminal gates stay.
            FastOfferSnapshot current = snapshot;
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消快速Accept");
                return;
            }
            // The common gesture sender checks for success immediately before dispatch.
            long rootWindowEpoch = WINDOW_TRANSITION_EPOCH.get();
            long rootUiGeneration = UI_GENERATION.get();
            long rootCheckAt = SystemClock.elapsedRealtime();
            Rect rootBounds = new Rect();
            IndexedReadProof proof = current.indexedRead;
            // The verified rectangle comes from the actual admitted offer index.  Reuse it
            // despite age, UI generation or window epoch churn; these are common during
            // high-frequency React-Native updates and cost real bid time when re-read.
            boolean windowReceipt = proof != null && !proof.rootBounds.isEmpty()
                    && "com.deliverthat.driver".equals(foregroundPackage);
            boolean sameWindow, reusedBounds, topRowCurrent;
            PageGuard.Page quickPage = PageGuard.Page.UNKNOWN;
            if (windowReceipt) {
                rootBounds.set(proof.rootBounds);
                sameWindow = true; reusedBounds = true; topRowCurrent = true;
            } else {
                AccessibilityNodeInfo root = service.getRootInActiveWindow();
                if (root == null || !"com.deliverthat.driver".contentEquals(
                        root.getPackageName() == null ? "" : root.getPackageName())) {
                    if (root != null) root.recycle();
                    if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                    return;
                }
                try {
                    sameWindow = proof != null && proof.windowId >= 0
                            && root.getWindowId() == proof.windowId;
                    reusedBounds = proof != null && IndexedReadPolicy.reuseBounds(
                            proof.generation, UI_GENERATION.get(), proof.verifiedAt,
                            SystemClock.elapsedRealtime(), sameWindow);
                    if (reusedBounds) rootBounds.set(proof.rootBounds);
                    else root.getBoundsInScreen(rootBounds);
                    // The initial upstream card selection is authoritative: no
                    // extra 16-node page walk at gesture submission. The cached
                    // foreground and job/negative surface gates still apply.
                    topRowCurrent = proof != null
                            || noHigherIndexedOfferAction(root, rootBounds, current.acceptBounds.top);
                } finally { root.recycle(); }
            }
            if (!topRowCurrent) {
                if (mismatch != null) mismatch.accept("HIGHER_OFFER_ACTION：上方订单仍在或动作行不可核验；未点击");
                return;
            }
            long rootCheckMs = SystemClock.elapsedRealtime() - rootCheckAt;
            if (proof == null && WINDOW_TRANSITION_EPOCH.get() != rootWindowEpoch) {
                if (mismatch != null) mismatch.accept("无索引窗口在读取期间切换；等待新帧");
                return;
            }
            if (quickPage == PageGuard.Page.JOBS || quickPage == PageGuard.Page.IGNORED) {
                if (mismatch != null) mismatch.accept("页面为" + quickPage + "；取消快速Accept");
                return;
            }
            if (!safeActionBounds(rootBounds, current.acceptBounds, true)) {
                if (mismatch != null) mismatch.accept("顶部Accept热区几何异常（疑似整卡/容器）；禁止点击并重新识别");
                return;
            }
            if (!current.acceptEnabled) {
                if (mismatch != null) mismatch.accept("顶部Accept已禁用/处理中；本次不占用重试次数");
                return;
            }

            long rebindMs = 0L;
            String rebindMode = "";
            String rebindCause = "";
            IndexedReadProof nodeTraceProof = null;
            // v2.10.296: no live-node rebind, generation rejection or window-epoch
            // revalidation once the same decision cycle supplied a usable Accept anchor.
            // Foreground, geometry, monitoring, terminal negative and spinner are still gated.
            if (proof == null && WINDOW_TRANSITION_EPOCH.get() != rootWindowEpoch) {
                if (mismatch != null) mismatch.accept("无索引窗口已切换；取消Accept");
                return;
            }
            if (!OcrMonitorService.isMonitoring() || INSTANCE.get() != service) {
                if (mismatch != null) mismatch.accept("监控或辅助服务已停止；取消快速Accept");
                return;
            }
            // No final staleness veto.  If an unindexed path could not establish
            // an Accept rectangle, the earlier root/button checks have already failed.

            String cardGuard = OcrMonitorService.firstAcceptCardGuard(current.text);
            if (!cardGuard.isEmpty()) {
                if (snapshot.indexedRead != null && snapshot.indexedRead.witness != null)
                    snapshot.indexedRead.witness.close();
                if (mismatch != null) mismatch.accept(cardGuard + "；取消快速Accept");
                return;
            }
            final long preflightReadyAt=SystemClock.elapsedRealtime();
            final boolean traceWindowReceipt=windowReceipt;
            final long traceRebindMs=rebindMs;
            final boolean traceReusedBounds=reusedBounds;
            final String traceRebindCause=rebindCause, traceRebindMode=rebindMode;
            final String traceMutation=lastUiMutationTrace;
            final IndexedReadProof traceNodeProof=nodeTraceProof;
            final long firstOwner = OcrMonitorService.pendingClaimSince();
            OcrMonitorService.prepareAcceptPageBaseline(current.pageOutcomeBaseline());
            final long dispatchGeneration=proof==null?rootUiGeneration:proof.generation;
            final long dispatchWindowEpoch=rootWindowEpoch;
            snapshot.recordReplayIndexStart();
            try {
                boolean sent = dispatchVerifiedSnapshotGesture(service, current.acceptBounds, rootBounds, true,
                        ActionDispatchPolicy.firstGestureDurationMs(true), 0, true,
                        detail -> {
                            String dispatchTrace = "；FIRST_TAP_PHASE snapshotToEntry="+initialAge
                                    +"ms,entryToRoot="+(rootCheckAt-preflightStartedAt)
                                    +"ms,root="+rootCheckMs+"ms,rebind="+traceRebindMs
                                    +"ms,afterRootOther="+Math.max(0L,preflightReadyAt-rootCheckAt-rootCheckMs-traceRebindMs)+"ms"
                                    +"；PREFLIGHT root=" + rootCheckMs
                                    + "ms,beforeRoot=" + (rootCheckAt - preflightStartedAt) + "ms"
                                    + (!traceRebindCause.isEmpty() ? "；RECHECK_EVENT=" + traceMutation : "")
                                    + (traceWindowReceipt ? "；LIVE_WINDOW_RECEIPT_REUSED" : "")
                                    + (traceReusedBounds ? "；LIVE_WINDOW_BOUNDS_REUSED" : "")
                                    + (!traceRebindMode.isEmpty() ? "；当前同卡复核=" + traceRebindMs + "ms；RECHECK_MODE=" + traceRebindMode
                                            + "；RECHECK_CAUSE=" + traceRebindCause + (traceNodeProof==null?"":"；"+traceNodeProof.formattedStages()) : "");
                            if (completion != null) completion.accept("来源=Gesture首击 " + detail + dispatchTrace
                                    + snapshot.indexedReadTiming(OcrMonitorService.acceptDispatchObservedAt()));
                        }, mismatch, () -> INSTANCE.get()==service && OcrMonitorService.isMonitoring()
                                && !OcrMonitorService.isManualInterventionPaused()
                                && "com.deliverthat.driver".equals(foregroundPackage)
                                && !currentNegativeSurfaceBlocksAccept());
                if (sent) rememberAcceptResumeNodes(current, firstOwner);
            } finally {
                // Release owned handles even if dispatch throws; never put cleanup ahead of the tap.
                if (snapshot.indexedRead != null && snapshot.indexedRead.witness != null)
                    snapshot.indexedRead.witness.close();
            }
        }
    }

    private static final class SemanticNodeHit {
        final AccessibilityNodeInfo node;
        final Rect bounds;
        SemanticNodeHit(AccessibilityNodeInfo node, Rect bounds) {
            this.node = AccessibilityNodeInfo.obtain(node);
            this.bounds = new Rect(bounds);
        }
        void recycle() { node.recycle(); }
    }

    private static final class SemanticNodeProbe {
        final Rect rootBounds = new Rect();
        final List<CardText.Piece> pieces = new ArrayList<>();
        final List<SemanticNodeHit> hits = new ArrayList<>();
        int visited;
        void recycle() { for (SemanticNodeHit hit : hits) hit.recycle(); hits.clear(); }
    }

    private static final class SemanticActionResult {
        final boolean clicked;
        final Rect bounds;
        final int visited;
        long clickStartedAt, clickCompletedAt;
        SemanticActionResult(boolean clicked, Rect bounds, int visited) {
            this.clicked = clicked;
            this.bounds = bounds == null ? new Rect() : new Rect(bounds);
            this.visited = visited;
        }
    }


    private static SemanticActionResult timedSemanticClick(AccessibilityNodeInfo node, boolean accept,
                                                            Rect rootBounds, Rect bounds, int visited) {
        long clickAt = SystemClock.elapsedRealtime();
        if (!performClickNodeOrParentSafe(node, accept, rootBounds)) return null;
        SemanticActionResult result = new SemanticActionResult(true, bounds, visited);
        result.clickStartedAt = clickAt;
        result.clickCompletedAt = SystemClock.elapsedRealtime();
        return result;
    }

    /**
     * v2.10.29: before a 180-node semantic probe, follow only the branches intersecting the
     * already-verified action rectangle. Blank-label React-Native buttons are common; clicking
     * the live ACTION_CLICK node at the exact fresh rectangle is both cheaper and stricter than
     * rediscovering every label in the window.
     */
    private static AccessibilityNodeInfo findLiveActionAtExpectedBounds(AccessibilityNodeInfo node,
                                                                         Rect expected,
                                                                         Rect rootBounds,
                                                                         boolean accept,
                                                                         int[] budget) {
        if (node == null || expected == null || expected.isEmpty() || budget[0]-- <= 0) return null;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean overlaps = bounds.isEmpty() || Rect.intersects(bounds, expected)
                || bounds.contains(expected.centerX(), expected.centerY());
        if (!overlaps) return null;
        if (!bounds.isEmpty() && samePhysicalAction(bounds, expected)
                && safeActionBounds(rootBounds, bounds, accept)
                && actionNodeReady(node)
                && (structuralActionShape(node, bounds, rootBounds)
                    || (accept ? (matchesAccept(node.getText()) || matchesAccept(node.getContentDescription()))
                               : (ButtonLabels.isReject(node.getText())
                                  || ButtonLabels.isReject(node.getContentDescription()))))) {
            return AccessibilityNodeInfo.obtain(node);
        }
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try {
                    AccessibilityNodeInfo hit = findLiveActionAtExpectedBounds(
                            child, expected, rootBounds, accept, budget);
                    if (hit != null) return hit;
                } finally { child.recycle(); }
            }
        }
        return null;
    }

    /**
     * v2.10.32 Reject dispatch fast path: the decision snapshot already owns an exact, fresh
     * action rectangle. Ask Android's text index for only the semantic action labels and accept
     * a live node only when its resolved clickable bounds match that SAME rectangle. This avoids
     * the second 120-180 node semantic probe seen after rule evaluation on otherwise-complete
     * Accessibility frames. Blank-label React-Native buttons still fall through to the strict
     * rectangle-pruned / semantic fallback below.
     */
    private static AccessibilityNodeInfo findIndexedLiveActionAtExpectedBounds(
            AccessibilityNodeInfo root, Rect rootBounds, Rect expected, boolean accept) {
        if (root == null || rootBounds == null || rootBounds.isEmpty()
                || expected == null || expected.isEmpty()) return null;
        String[] queries = accept ? new String[]{"Accept", "Claim"}
                : new String[]{"Ignore", "Decline", "Reject"};
        for (String query : queries) {
            List<AccessibilityNodeInfo> indexed = null;
            try {
                indexed = root.findAccessibilityNodeInfosByText(query);
                if (indexed == null || indexed.isEmpty()) continue;
                for (AccessibilityNodeInfo seed : indexed) {
                    if (seed == null) continue;
                    boolean labelMatch = accept
                            ? (matchesAccept(seed.getText()) || matchesAccept(seed.getContentDescription()))
                            : (ButtonLabels.isReject(seed.getText())
                               || ButtonLabels.isReject(seed.getContentDescription()));
                    if (!labelMatch) continue;
                    AccessibilityNodeInfo action = resolveIndexedAction(seed, rootBounds, accept);
                    if (action == null) continue;
                    Rect live = new Rect();
                    action.getBoundsInScreen(live);
                    if (samePhysicalAction(live, expected)
                            && safeActionBounds(rootBounds, live, accept)
                            && actionNodeReady(action)) {
                        return action; // owned result; caller recycles
                    }
                    action.recycle();
                }
            } catch (RuntimeException ignored) {
                // React-Native may replace the node while the index is being read. The strict
                // expected-rectangle fallback below remains available.
            } finally {
                if (indexed != null)
                    for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
            }
        }
        return null;
    }

    /** One bounded active-root pass that both validates the numeric pair and clicks a real node. */
    private static SemanticActionResult trySemanticActionClick(TapAccessibilityService service,
                                                                float amount, float miles,
                                                                Rect expectedBounds,
                                                                boolean accept) {
        if (service == null) return new SemanticActionResult(false, null, 0);
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return new SemanticActionResult(false, null, 0);
        SemanticNodeProbe probe = new SemanticNodeProbe();
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName()))
                return new SemanticActionResult(false, null, 0);
            // v2.10.30 action-chain fast path: the caller already owns a fresh, exact action
            // rectangle from the current top-card snapshot. Check cached page safety first, then
            // resolve only the live node overlapping that rectangle. Do not spend a page-chrome
            // walk in front of the first ACTION_CLICK. If the exact node is unavailable, the
            // original bounded semantic scan remains the conservative fallback.
            PageGuard.Page recentPage = recentPageHint();
            if (recentPage == PageGuard.Page.JOBS || recentPage == PageGuard.Page.IGNORED)
                return new SemanticActionResult(false, null, 0);
            root.getBoundsInScreen(probe.rootBounds);
            if (probe.rootBounds.isEmpty()) return new SemanticActionResult(false, null, 0);

            if (expectedBounds != null && !expectedBounds.isEmpty()) {
                // v2.10.32: semantic text index first. When the current Reject/Accept label is
                // exported, this is O(action-index) and reuses the exact rectangle already
                // proven by the decision snapshot instead of rescanning ~130 unrelated nodes.
                AccessibilityNodeInfo indexedExact = findIndexedLiveActionAtExpectedBounds(
                        root, probe.rootBounds, expectedBounds, accept);
                if (indexedExact != null) {
                    try {
                        Rect live = new Rect();
                        indexedExact.getBoundsInScreen(live);
                        SemanticActionResult sent = timedSemanticClick(indexedExact, accept, probe.rootBounds, live, 0);
                        if (sent != null) return sent;
                    } finally { indexedExact.recycle(); }
                }

                AccessibilityNodeInfo exact = findLiveActionAtExpectedBounds(
                        root, expectedBounds, probe.rootBounds, accept, new int[]{56});
                if (exact != null) {
                    try {
                        Rect live = new Rect();
                        exact.getBoundsInScreen(live);
                        SemanticActionResult sent = timedSemanticClick(exact, accept, probe.rootBounds, live, 0);
                        if (sent != null) return sent;
                    } finally { exact.recycle(); }
                }
            }

            PageGuard.Page page = recentPage == PageGuard.Page.OFFERS
                    ? PageGuard.Page.OFFERS : quickPageOf(root, 20);
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED)
                return new SemanticActionResult(false, null, 0);

            int[] budget = new int[]{180};
            collectSemanticNodeProbe(root, probe, accept, budget);
            probe.hits.sort((a, b) -> Float.compare(
                    actionHitScore(a.bounds, expectedBounds), actionHitScore(b.bounds, expectedBounds)));
            for (SemanticNodeHit hit : probe.hits) {
                if (!safeActionBounds(probe.rootBounds, hit.bounds, accept)) continue;
                if (expectedBounds != null && !expectedBounds.isEmpty()) {
                    float dy = Math.abs(hit.bounds.exactCenterY() - expectedBounds.exactCenterY());
                    float tolerance = Math.max(90f, expectedBounds.height() * 2.2f);
                    if (dy > tolerance) continue;
                }
                String liveText = CardText.aboveButton(probe.pieces, hit.bounds.top, hit.bounds.bottom);
                if (!quickNumericPairMatches(liveText, amount, miles)) continue;
                SemanticActionResult sent = timedSemanticClick(hit.node, accept, probe.rootBounds, hit.bounds, probe.visited);
                if (sent != null) return sent;
            }

            // React-Native sometimes exports the visible Ignore control as a blank clickable
            // node while the text itself is a non-clickable sibling. Resolve a structural
            // node only around the already-verified action rectangle; never search by a
            // fixed coordinate or climb into the full card.
            if (expectedBounds != null && !expectedBounds.isEmpty()) {
                AccessibilityNodeInfo structural = findActionNode(root, accept,
                        expectedBounds.exactCenterX(), expectedBounds.exactCenterY());
                if (structural != null) {
                    try {
                        Rect live = new Rect();
                        structural.getBoundsInScreen(live);
                        if (safeActionBounds(probe.rootBounds, live, accept)) {
                            String liveText = CardText.aboveButton(
                                    probe.pieces, live.top, live.bottom);
                            if (quickNumericPairMatches(liveText, amount, miles)) {
                                SemanticActionResult sent = timedSemanticClick(structural, accept, probe.rootBounds, live, probe.visited);
                                if (sent != null) return sent;
                            }
                        }
                    } finally { structural.recycle(); }
                }
            }
            return new SemanticActionResult(false, null, probe.visited);
        } finally {
            probe.recycle();
            root.recycle();
        }
    }

    /**
     * Reject-only hybrid dispatcher. ACTION_CLICK is the NovaFlow-style primary path on
     * Samsung because it targets the live accessibility node instead of merely injecting
     * coordinates. A gesture is used only when ACTION_CLICK is unavailable or the same
     * offer is still present with Reject enabled after the settle window.
     *
     * The semantic click + fallback gesture count as ONE RejectSequence attempt.
     */
    private static void dispatchRejectHybrid(TapAccessibilityService service,
                                             float amount, float miles, Rect expectedBounds,
                                             String expectedText, boolean requireMonitoring,
                                             Consumer<String> completion, Consumer<String> mismatch) {
        if (service == null || expectedBounds == null || expectedBounds.isEmpty()) {
            if (mismatch != null) mismatch.accept("Reject目标热区为空；未执行");
            return;
        }
        if (OcrMonitorService.isManualInterventionPaused()) {
            if (mismatch != null) mismatch.accept("人工介入中；取消Reject");
            return;
        }
        if (requireMonitoring && !OcrMonitorService.isMonitoring()) {
            if (mismatch != null) mismatch.accept("监控已停止；取消Reject");
            return;
        }
        if (largeOrderPopupRecentlyVisible(1_500L) && isLargeOrderInfoPopupVisible()) {
            if (mismatch != null) mismatch.accept("Large Order说明层仍可见；禁止Reject并等待X关闭后重新定位");
            return;
        }
        final Rect original = new Rect(expectedBounds);
        long verifyStartedAt = SystemClock.elapsedRealtime();
        SemanticActionResult semantic = trySemanticActionClick(
                service, amount, miles, original, false);
        if (!semantic.clicked) {
            dispatchActionGesture(service, original, false,
                    ActionDispatchPolicy.rejectFallbackGestureDurationMs(), 0,
                    detail -> {
                        if (completion != null) completion.accept(
                                "ACTION_CLICK不可用→" + detail);
                    }, mismatch);
            return;
        }

        final long semanticReturnedAt=SystemClock.elapsedRealtime();
        final Rect semanticBounds = semantic.bounds.isEmpty() ? original : new Rect(semantic.bounds);
        final int visited = semantic.visited;
        // v2.10.30: ACTION_CLICK dispatch and Reject confirmation are separate phases. Release
        // the action lane immediately after Android accepted the live-node click; the 160 ms UI
        // settle/fallback runs independently and must not make the next offer wait.
        if (completion != null) completion.accept(
                "ACTION_CLICK已发送；Reject确认异步进行（visited=" + visited + ")"
                        + "；点击前核验=" + (semantic.clickStartedAt - verifyStartedAt) + "ms"
                        + "；点击调用=" + (semantic.clickCompletedAt - semantic.clickStartedAt) + "ms"
                        + "；点击返回→回调=" + (SystemClock.elapsedRealtime() - semantic.clickCompletedAt) + "ms"
                        + "；点击返回→核验函数返回="+(semanticReturnedAt-semantic.clickCompletedAt)+"ms"
                        + "；核验函数返回→回调="+(SystemClock.elapsedRealtime()-semanticReturnedAt)+"ms");
        if (requireMonitoring) return;
        Handler rejectSettleWorker = service.directWorker != null ? service.directWorker : service.main;
        rejectSettleWorker.postDelayed(() -> {
            if (OcrMonitorService.isManualInterventionPaused()) return;
            if (requireMonitoring && !OcrMonitorService.isMonitoring()) {
                android.util.Log.d("CSA", "Reject异步确认：监控已停止，不再补手势");
                return;
            }
            if (!isDeliverThatForeground()) {
                android.util.Log.d("CSA", "Reject异步确认：DeliverThat已离开前台，不再补手势");
                return;
            }

            FastOfferSnapshot current = quickRefreshTopAction(service, amount, miles, false);
            if (current == null) {
                android.util.Log.d("CSA", "Reject异步确认：旧卡/Reject状态已变化；不补手势");
                return;
            }
            if (expectedText != null && !expectedText.isEmpty()
                    && !CardText.sameOfferForAction(expectedText, current.text)) {
                android.util.Log.d("CSA", "Reject异步确认：顶部已换单，不补手势");
                return;
            }
            if (!current.rejectEnabled) {
                String processingId = CardText.identity(
                        expectedText == null || expectedText.isEmpty() ? current.text : expectedText);
                RejectSequence.shared().markProcessing(processingId, SystemClock.elapsedRealtime());
                android.util.Log.d("CSA", "Reject异步确认：Reject已禁用/处理中");
                return;
            }

            Rect fallback = current.rejectBounds.isEmpty()
                    ? semanticBounds : new Rect(current.rejectBounds);
            dispatchActionGesture(service, fallback, false,
                    ActionDispatchPolicy.rejectFallbackGestureDurationMs(), 0,
                    detail -> android.util.Log.d("CSA", "Reject异步补手势：" + detail),
                    reason -> android.util.Log.d("CSA", "Reject异步补手势取消：" + reason));
        }, ActionDispatchPolicy.rejectSemanticSettleMs());
    }

    private static float actionHitScore(Rect bounds, Rect expected) {
        if (bounds == null || bounds.isEmpty()) return Float.MAX_VALUE;
        if (expected == null || expected.isEmpty()) return bounds.top;
        return Math.abs(bounds.exactCenterY() - expected.exactCenterY())
                + Math.abs(bounds.exactCenterX() - expected.exactCenterX()) * 0.25f;
    }

    private static void collectSemanticNodeProbe(AccessibilityNodeInfo node,
                                                  SemanticNodeProbe probe,
                                                  boolean accept, int[] budget) {
        if (node == null || probe == null || budget[0]-- <= 0) return;
        probe.visited++;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        CharSequence text = node.getText(), desc = node.getContentDescription();
        if (!bounds.isEmpty()) {
            if (text != null && text.length() > 0) addUniquePiece(probe.pieces, text.toString(), bounds);
            if (desc != null && desc.length() > 0) addUniquePiece(probe.pieces, desc.toString(), bounds);
            boolean labelMatch = accept ? (matchesAccept(text) || matchesAccept(desc))
                    : (ButtonLabels.isReject(text) || ButtonLabels.isReject(desc));
            if (labelMatch && actionNodeReady(node)
                    && safeActionBounds(probe.rootBounds, bounds, accept)) {
                probe.hits.add(new SemanticNodeHit(node, bounds));
            }
        }
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectSemanticNodeProbe(child, probe, accept, budget); }
                finally { child.recycle(); }
            }
        }
    }

    /**
     * v2.10.30 snapshot gesture: caller has just validated the DeliverThat root, page guard,
     * action geometry and enabled state in the same runnable. Reuse those root bounds instead
     * of opening the hierarchy a second time before the gesture.
     */
    private static void dispatchVerifiedSnapshotGesture(TapAccessibilityService service, Rect bounds,
                                                        Rect rootBounds, boolean accept, long durationMs,
                                                        int variant, Consumer<String> completion,
                                                        Consumer<String> mismatch) {
        dispatchVerifiedSnapshotGesture(service,bounds,rootBounds,accept,durationMs,variant,
                completion,mismatch,() -> true);
    }

    private static void dispatchVerifiedSnapshotGesture(TapAccessibilityService service,Rect bounds,
            Rect rootBounds,boolean accept,long durationMs,int variant,Consumer<String> completion,
            Consumer<String> mismatch,java.util.function.BooleanSupplier freshProof) {
        dispatchVerifiedSnapshotGesture(service, bounds, rootBounds, accept, durationMs, variant, false,
                completion, mismatch, freshProof);
    }

    private static GestureDescription buildSingleTap(Path path, long durationMs) {
        return new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs))
                .build();
    }

    private static boolean dispatchVerifiedSnapshotGesture(TapAccessibilityService service, Rect bounds,
            Rect rootBounds, boolean accept, long durationMs, int variant, boolean bindForPressure,
            Consumer<String> completion, Consumer<String> mismatch,
            java.util.function.BooleanSupplier freshProof) {
        if (service == null || bounds == null || bounds.isEmpty()
                || rootBounds == null || rootBounds.isEmpty()) {
            if (mismatch != null) mismatch.accept("已验证动作热区为空；未发送手势");
            return false;
        }
        if (!safeActionBounds(rootBounds, bounds, accept)) {
            if (mismatch != null) mismatch.accept("已验证动作热区几何异常；取消手势");
            return false;
        }
        float fx = 0.50f, fy = 0.50f;
        if (variant == 1) { fx = 0.62f; fy = 0.54f; }
        else if (variant == 2) { fx = 0.38f; fy = 0.46f; }
        float x = bounds.left + bounds.width() * fx;
        float y = bounds.top + bounds.height() * fy;
        if (!rootBounds.contains(Math.round(x), Math.round(y))) {
            if (mismatch != null) mismatch.accept("动作点已离开DeliverThat窗口；取消手势");
            return false;
        }
        Path path = new Path();
        path.moveTo(x, y);
        int mode = accept && bindForPressure ? OcrMonitorService.acceptFirstGestureMode()
                : ActionDispatchPolicy.SINGLE;
        long tapDuration = accept && bindForPressure ? ActionDispatchPolicy.firstStrokeMs(mode)
                : Math.max(accept ? 12L : 18L, durationMs);
        boolean firstBurst = accept && bindForPressure && mode==ActionDispatchPolicy.SEQUENTIAL;
        GestureDescription gesture;
        StringBuilder planned = new StringBuilder("mode=").append(!accept ? "REJECT" : !bindForPressure
                ? "RETRY_SINGLE" : mode==ActionDispatchPolicy.SEQUENTIAL ? "SEQUENTIAL_3" : "SINGLE_12");
        if (firstBurst) {
            GestureDescription.Builder batch = new GestureDescription.Builder();
            for (int stroke = 0; stroke < 3; stroke++) {
                float sx = x;
                if (!bounds.contains(Math.round(sx), Math.round(y)) || !rootBounds.contains(Math.round(sx),Math.round(y))) {
                    if (mismatch!=null) mismatch.accept("错时点击动作点离开按钮或窗口"); return false;
                }
                Path finger = new Path(); finger.moveTo(sx,y);
                long offset = ActionDispatchPolicy.firstStrokeStartMs(mode,stroke,tapDuration);
                batch.addStroke(new GestureDescription.StrokeDescription(finger, offset, tapDuration));
                planned.append(" stroke[").append(stroke).append("]=").append(Math.round(sx)).append(',')
                        .append(Math.round(y)).append(" down+").append(offset).append(" up+").append(offset+tapDuration);
            }
            gesture = batch.build();
        } else {
            gesture = buildSingleTap(path, tapDuration);
            planned.append(" stroke[0]=").append(Math.round(x)).append(',').append(Math.round(y))
                    .append(" down+0 up+").append(tapDuration);
        }
        final String gesturePlan=planned.toString();
        if (accept && OcrMonitorService.hasBoundAcceptSuccess()) {
            if (mismatch != null) mismatch.accept("检测到本次准备期间的新接单成功状态；取消重复Accept");
            return false;
        }
        // v2.10.296: proof age and UI-generation churn are NOT an Accept veto.
        // Callers now supply only live foreground/monitoring/terminal safety gates.
        if(!freshProof.getAsBoolean()) {
            if(mismatch!=null) mismatch.accept("ACCEPT_FINAL_LIVE_GATE_STOPPED：监控、前台或明确终态发生变化");
            return false;
        }
        if (accept) {
            String loading = OcrMonitorService.acceptLoadingRetryBlock(OcrMonitorService.pendingClaimSince());
            if (!loading.isEmpty()) { if (mismatch != null) mismatch.accept(loading); return false; }
        }
        if(accept && bindForPressure) bindPressureGeometry(bounds,rootBounds);
        final long callbackOwner=accept?OcrMonitorService.pendingClaimSince():0L;
        final AtomicLong returnedAt = new AtomicLong();
        if (accept) OcrMonitorService.noteAcceptGestureDispatchStarted();
        final long callAt = SystemClock.elapsedRealtime();
        boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                if(accept) OcrMonitorService.noteAcceptCallbackEntry(callbackOwner,callAt,returnedAt.get(),SystemClock.elapsedRealtime(),false);
                if (completion != null) completion.accept("Gesture" + tapDuration + "ms rect="
                        + rectString(bounds) + "；strokes=" + gesture.getStrokeCount()
                        + "；stroke计划间隔=" + (firstBurst && mode==ActionDispatchPolicy.SEQUENTIAL ? tapDuration + 1L : 0L) + "ms"
                        + "；stroke计划总长=" + (firstBurst ? ActionDispatchPolicy.firstStrokeTotalMs(mode,tapDuration) : tapDuration) + "ms"
                        + "；"+gesturePlan
                        + " tap=(" + Math.round(x) + "," + Math.round(y) + ")"
                        + "；dispatch调用=" + Math.max(0L, returnedAt.get() - callAt) + "ms"
                        + "；callback等待=" + Math.max(0L, SystemClock.elapsedRealtime()
                                - Math.max(callAt, returnedAt.get())) + "ms"
                        + "；CALL_ELAPSED="+callAt+",DISPATCH_ELAPSED="+returnedAt.get()
                        + ",CALLBACK_ELAPSED="+SystemClock.elapsedRealtime());
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                if(accept) OcrMonitorService.noteAcceptCallbackEntry(callbackOwner,callAt,returnedAt.get(),SystemClock.elapsedRealtime(),true);
                if (mismatch != null) mismatch.accept("系统取消了" + (accept ? "Accept" : "Reject")
                        + "手势；rect=" + rectString(bounds));
            }
        }, accept && OcrMonitorService.isMonitoring() && OcrMonitorService.acceptCallbackHandler()!=null
                ? OcrMonitorService.acceptCallbackHandler() : service.main);
        returnedAt.set(SystemClock.elapsedRealtime());
        if (dispatched && accept) {
            OcrMonitorService.noteAcceptGestureDispatched();
            OcrMonitorService.noteAcceptGesturePlan(callbackOwner,callAt,returnedAt.get(),gesturePlan);
        }
        if (!dispatched && mismatch != null)
            mismatch.accept("系统未接受" + (accept ? "Accept" : "Reject")
                    + "手势；rect=" + rectString(bounds));
        return dispatched;
    }

    /**
     * Dispatch one gesture strictly inside a currently verified action rectangle.
     * variant 0=center, 1=slightly right/bottom, 2=slightly left/top; all stay inside the button.
     */
    private static void dispatchActionGesture(TapAccessibilityService service, Rect bounds,
                                              boolean accept, long durationMs, int variant,
                                              Consumer<String> completion, Consumer<String> mismatch) {
        dispatchActionGesture(service,bounds,accept,durationMs,variant,completion,mismatch,() -> true);
    }

    private static void dispatchActionGesture(TapAccessibilityService service,Rect bounds,
            boolean accept,long durationMs,int variant,Consumer<String> completion,Consumer<String> mismatch,
            java.util.function.BooleanSupplier freshProof) {
        final long methodStarted = SystemClock.elapsedRealtime();
        if (service == null || bounds == null || bounds.isEmpty()) {
            if (mismatch != null) mismatch.accept("动作按钮热区为空；未发送手势");
            return;
        }
        if (OcrMonitorService.isManualInterventionPaused()) {
            if (mismatch != null) mismatch.accept("人工介入中；取消自动手势");
            return;
        }
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null || !"com.deliverthat.driver".contentEquals(
                root.getPackageName() == null ? "" : root.getPackageName())) {
            if (root != null) root.recycle();
            if (mismatch != null) mismatch.accept("手势前DeliverThat窗口已变化；未点击");
            return;
        }
        Rect rootBounds = new Rect();
        root.getBoundsInScreen(rootBounds);
        PageGuard.Page page = quickPageOf(root, 20);
        root.recycle();
        if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) {
            if (mismatch != null) mismatch.accept("手势前页面为" + page + "；取消动作");
            return;
        }
        if (!safeActionBounds(rootBounds, bounds, accept)) {
            if (mismatch != null) mismatch.accept("动作热区几何异常（疑似整卡/容器）；取消手势");
            return;
        }
        float fx = 0.50f, fy = 0.50f;
        if (variant == 1) { fx = 0.62f; fy = 0.54f; }
        else if (variant == 2) { fx = 0.38f; fy = 0.46f; }
        float x = bounds.left + bounds.width() * fx;
        float y = bounds.top + bounds.height() * fy;
        if (!rootBounds.contains(Math.round(x), Math.round(y))) {
            if (mismatch != null) mismatch.accept("动作点已离开DeliverThat窗口；取消手势");
            return;
        }
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, Math.max(accept ? 12L : 18L, durationMs)))
                .build();
        if (accept && OcrMonitorService.acceptDispatchObservedAt()>0L) {
            String guard=OcrMonitorService.acceptRetryGuard(OcrMonitorService.pendingClaimSince());
            if (!guard.isEmpty()) { if (mismatch!=null) mismatch.accept(guard); return; }
        }
        if(!freshProof.getAsBoolean()) {
            if(mismatch!=null) mismatch.accept("RETRY_VISUAL_PROOF_EXPIRED：手势发送前画面/事务已变化；未点击");
            return;
        }
        if (accept) {
            String loading = OcrMonitorService.acceptLoadingRetryBlock(OcrMonitorService.pendingClaimSince());
            if (!loading.isEmpty()) { if (mismatch != null) mismatch.accept(loading); return; }
        }
        final long beforeDispatch = SystemClock.elapsedRealtime();
        final AtomicLong dispatchReturnedAt = new AtomicLong(0L);
        if (accept) OcrMonitorService.noteAcceptGestureDispatchStarted();
        boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                long callbackAt = SystemClock.elapsedRealtime();
                long returnedAt = dispatchReturnedAt.get();
                if (returnedAt <= 0L) returnedAt = beforeDispatch;
                if (completion != null) completion.accept("Gesture" + durationMs + "ms rect="
                        + rectString(bounds) + " tap=(" + Math.round(x) + "," + Math.round(y) + ")"
                        + "；DISPATCH_ELAPSED=" + beforeDispatch + "；CALLBACK_ELAPSED=" + callbackAt
                        + "；准备" + Math.max(0L, beforeDispatch - methodStarted) + "ms"
                        + "；dispatch调用" + Math.max(0L, returnedAt - beforeDispatch) + "ms"
                        + "；callback" + Math.max(0L, callbackAt - returnedAt) + "ms");
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                long callbackAt = SystemClock.elapsedRealtime();
                long returnedAt = dispatchReturnedAt.get();
                if (returnedAt <= 0L) returnedAt = beforeDispatch;
                if (mismatch != null) mismatch.accept("系统取消了" + (accept ? "Accept" : "Reject")
                        + "手势；rect=" + rectString(bounds)
                        + "；DISPATCH_ELAPSED=" + beforeDispatch + "；CALLBACK_ELAPSED=" + callbackAt
                        + "；准备" + Math.max(0L, beforeDispatch - methodStarted) + "ms"
                        + "；dispatch调用" + Math.max(0L, returnedAt - beforeDispatch) + "ms"
                        + "；callback" + Math.max(0L, callbackAt - returnedAt) + "ms");
            }
        }, accept && OcrMonitorService.isMonitoring() && OcrMonitorService.acceptCallbackHandler()!=null
                ? OcrMonitorService.acceptCallbackHandler() : service.main);
        long afterDispatch = SystemClock.elapsedRealtime();
        dispatchReturnedAt.set(afterDispatch);
        if (dispatched && accept) OcrMonitorService.noteAcceptGestureDispatched();
        if (!dispatched && mismatch != null)
            mismatch.accept("系统未接受" + (accept ? "Accept" : "Reject")
                    + "手势；rect=" + rectString(bounds)
                    + "；DISPATCH_ELAPSED=" + beforeDispatch + "；RETURN_ELAPSED=" + afterDispatch
                        + "；准备" + Math.max(0L, beforeDispatch - methodStarted) + "ms"
                    + "；dispatch调用" + Math.max(0L, afterDispatch - beforeDispatch) + "ms");
    }

    private static String rectString(Rect r) {
        if (r == null || r.isEmpty()) return "[]";
        return "[" + r.left + "," + r.top + "," + r.right + "," + r.bottom + "]";
    }

    /**
     * v2.10.17 fast Ignore/Reject path. The Galaxy A15 traces proved that Android can
     * report a completed dispatchGesture while DeliverThat leaves the visible Ignore
     * button untouched. For Reject only, prefer a live Accessibility ACTION_CLICK on the
     * verified button node. If the same offer is still present with Reject still enabled
     * after a short settle window, issue one slower gesture fallback inside the SAME
     * logical Reject attempt.
     */
    public static void tapSnapshotRejectFast(FastOfferSnapshot snapshot, float amount, float miles,
                                             Consumer<String> completion, Consumer<String> mismatch) {
        tapSnapshotRejectFast(snapshot, amount, miles, completion, mismatch, null);
    }

    public static void tapSnapshotRejectFast(FastOfferSnapshot snapshot, float amount, float miles,
                                             Consumer<String> completion, Consumer<String> mismatch,
                                             java.util.function.BooleanSupplier mayDispatch) {
        tapSnapshotRejectFast(snapshot,amount,miles,completion,mismatch,mayDispatch,false);
    }

    /** A fresh final same-card proof already established semantic Reject did not clear it. */
    public static void tapSnapshotRejectRescue(FastOfferSnapshot snapshot,float amount,float miles,
            Consumer<String> completion,Consumer<String> mismatch,
            java.util.function.BooleanSupplier mayDispatch) {
        tapSnapshotRejectFast(snapshot,amount,miles,completion,mismatch,mayDispatch,true);
    }

    private static boolean boundRejectContextCurrent(TapAccessibilityService service, IndexedReadProof proof) {
        long age = SystemClock.elapsedRealtime() - proof.verifiedAt;
        PageGuard.Page page = recentPageHint();
        return age >= 0L && age <= 120L && page != PageGuard.Page.JOBS && page != PageGuard.Page.IGNORED
                && !largeOrderPopupRecentlyVisible(1_500L) && !currentNegativeSurfaceBlocksAccept()
                && INSTANCE.get() == service && OcrMonitorService.isMonitoring()
                && !OcrMonitorService.isManualInterventionPaused()
                && "com.deliverthat.driver".equals(foregroundPackage)
                && WINDOW_TRANSITION_EPOCH.get() == proof.windowEpoch
                && UI_GENERATION.get() == proof.generation;
    }

    static final String REJECT_PROOF_CHANGED_BEFORE_CLICK = "Reject证据已变化；按新证据复查当前顶部";

    private static void dispatchBoundReject(TapAccessibilityService service, FastOfferSnapshot snapshot,
            Consumer<String> completion, Consumer<String> mismatch,
            java.util.function.BooleanSupplier mayDispatch) {
        IndexedReadProof proof = snapshot.rejectProof;
        IndexedWitness witness = proof.witness;
        long enteredAt = SystemClock.elapsedRealtime();
        long callStarted = enteredAt;
        long returnedAt = enteredAt;
        boolean tried = false, sent = false;
        synchronized (witness) {
            AccessibilityNodeInfo action = witness.action;
            if (action != null && !witness.closed && action.getWindowId() == proof.windowId
                    && action.isVisibleToUser() && action.isEnabled() && nodeIsActionable(action)
                    && boundRejectContextCurrent(service, proof)
                    && (mayDispatch == null || mayDispatch.getAsBoolean())) {
                tried = true;
                callStarted = SystemClock.elapsedRealtime();
                try { sent = action.performAction(AccessibilityNodeInfo.ACTION_CLICK); }
                catch (RuntimeException stale) { sent = false; }
                returnedAt = SystemClock.elapsedRealtime();
            }
            witness.close();
        }
        if (sent) {
            if (completion != null) completion.accept("ACTION_CLICK已发送；" + proof.stages
                    + "；点击前核验=" + (callStarted - enteredAt) + "ms；点击调用=" + (returnedAt - callStarted) + "ms");
        } else if (tried && boundRejectContextCurrent(service, proof)) {
            dispatchVerifiedSnapshotGesture(service, snapshot.rejectBounds, proof.rootBounds, false,
                    ActionDispatchPolicy.rejectFallbackGestureDurationMs(), 0, completion, mismatch,
                    () -> boundRejectContextCurrent(service, proof)
                            && (mayDispatch == null || mayDispatch.getAsBoolean()));
        } else if (mismatch != null) {
            mismatch.accept(tried ? "Reject点击调用未确认且证据变化；重新读取当前顶部"
                    : REJECT_PROOF_CHANGED_BEFORE_CLICK);
        }
    }

    private static void tapSnapshotRejectFast(FastOfferSnapshot snapshot,float amount,float miles,
            Consumer<String> completion,Consumer<String> mismatch,
            java.util.function.BooleanSupplier mayDispatch,boolean gestureRescue) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || snapshot == null || snapshot.rejectBounds.isEmpty()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "顶部Reject快照不可用");
            return;
        }
        // Preserve the fast bound-node ACTION_CLICK even when a transaction-owner
        // gate is installed; do not turn first Reject into a queued slow fallback.
        if (!gestureRescue && snapshot.rejectProof != null) {
            if (mayDispatch != null && !mayDispatch.getAsBoolean()) {
                if (mismatch != null) mismatch.accept("新合格订单优先；旧Reject未执行");
                return;
            }
            dispatchBoundReject(service, snapshot, completion, mismatch, mayDispatch);
            return;
        }
        final long queuedAt=SystemClock.elapsedRealtime();
        Runnable action = () -> {
            final long enteredAt=SystemClock.elapsedRealtime();
            final long[] verificationAt={enteredAt};
            Consumer<String> timed=detail -> {if(completion!=null)completion.accept(detail
                    +"；Reject排队="+(enteredAt-queuedAt)+"ms；入口→动作核验="+(verificationAt[0]-enteredAt)+"ms；动作核验→完成="
                    +(SystemClock.elapsedRealtime()-verificationAt[0])+"ms；队列入口→完成="
                    +(SystemClock.elapsedRealtime()-enteredAt)+"ms");};
            if (mayDispatch != null && !mayDispatch.getAsBoolean()) {
                if (mismatch != null) mismatch.accept("新卡优先；取消后台Reject补击");
                return;
            }
            long initialAge = SystemClock.elapsedRealtime() - snapshot.capturedAt;
            if (FastSnapshotPolicy.hardExpired(initialAge)) {
                if (mismatch != null) mismatch.accept("顶部Reject证据已超过硬时限" + initialAge + "ms；等待新订单帧");
                return;
            }
            final long rescueGeneration=UI_GENERATION.get(),rescueWindow=WINDOW_TRANSITION_EPOCH.get();
            FastOfferSnapshot current = snapshot;
            if (FastSnapshotPolicy.needsRefresh(initialAge, false)) {
                current = quickRefreshTopAction(service, amount, miles, false);
                if (current == null) {
                    if (mismatch != null) mismatch.accept("顶部Reject快照" + initialAge
                            + "ms；轻量金额/里程/Ignore核验未通过，未点击");
                    return;
                }
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消快速Reject");
                return;
            }
            if (mayDispatch != null && !mayDispatch.getAsBoolean()) {
                if (mismatch != null) mismatch.accept("新卡优先；取消后台Reject补击");
                return;
            }
            Rect expected = new Rect(current.rejectBounds);
            verificationAt[0]=SystemClock.elapsedRealtime();
            if(gestureRescue) {
                if(!current.rejectEnabled || !OfferEnrichmentPolicy.sameTransaction(snapshot.text,current.text)) {
                    if(mismatch!=null) mismatch.accept("Reject补击当前同卡/启用状态未通过");
                    return;
                }
                if(largeOrderPopupRecentlyVisible(1_500L) && isLargeOrderInfoPopupVisible()) {
                    if(mismatch!=null) mismatch.accept("Large Order说明层仍可见；取消Reject补击");
                    return;
                }
                final long proofAt=current.capturedAt;
                dispatchActionGesture(service,expected,false,
                        ActionDispatchPolicy.rejectFallbackGestureDurationMs(),0,
                        detail -> timed.accept("新鲜同卡手势补击；"+detail),mismatch,
                        () -> INSTANCE.get()==service && OcrMonitorService.isMonitoring()
                                && !OcrMonitorService.isManualInterventionPaused()
                                && UI_GENERATION.get()==rescueGeneration
                                && WINDOW_TRANSITION_EPOCH.get()==rescueWindow
                                && SystemClock.elapsedRealtime()>=proofAt
                                && !FastSnapshotPolicy.hardExpired(SystemClock.elapsedRealtime()-proofAt)
                                && (mayDispatch==null || mayDispatch.getAsBoolean()));
            } else dispatchRejectHybrid(service, amount, miles, expected, current.text, true, timed, mismatch);
        };
        if (mayDispatch == null) service.main.postAtFrontOfQueue(action);
        else service.main.post(action);
    }

    private static String rejectProbeEvidence(QuickActionProbe p, PageGuard.Page page) {
        return "page=" + page + ",pay=" + p.sawMoney + ",mi=" + p.sawMiles
                + ",location=" + p.sawLocation + ",accept=" + p.accepts.size()
                + ",reject=" + p.rejects.size() + ",struct=" + p.structural.size()
                + ",empty=" + p.flags[6] + ",full=" + p.completeTraversal
                + ",selectedOffers=" + p.flags[2] + ",hub=" + p.sawDeliveriesHub
                + ",offersLabel=" + p.sawOffersLabel + ",jobsLabel=" + p.sawJobsLabel
                + ",jobEvidence=" + (p.sawJobInstructions || p.sawBeginDelivery || p.sawJobTimeline
                    || p.sawApprover || p.sawNuid || p.sawGlString);
    }

    private static boolean hasIndexedEmptyOffers(long softBudgetMs) {
        return hasIndexedEmptyOffers(softBudgetMs, () -> true);
    }

    private static boolean relevantRejectIndexText(String value) {
        // Broad vocabulary filter, not absence proof. Avoid geometry Binder calls for wrappers.
        for(String token : new String[]{"$","usd","mi","accept","claim","reject","ignore",
                "decline","restore","deliver","offer","jobs","begin","instruction","timeline",
                "approver","nuid","gl string","loading","please wait"})
            if(value.contains(token)) return true;
        return false;
    }

    private enum EmptyIndexStatus { EMPTY, JOBS_EMPTY, IGNORED_EMPTY, JOBS_LIST, IGNORED_LIST, NOT_EMPTY, OFFER_VISIBLE,
        BUDGET, BUSY, UI_CHANGED, YIELD, UNAVAILABLE, NO_SERVICE, NO_ROOT, FOREIGN_ROOT,
        EMPTY_ROOT_BOUNDS, NO_QUERY_RESULT, NO_PAGE_EVIDENCE, STALE_NODE }

    enum OfferPresence { PRESENT, EMPTY, JOBS_EMPTY, IGNORED_EMPTY, JOBS_LIST, IGNORED_LIST, UNKNOWN }
    private static volatile String lastPresenceProbeDetail = "UNOBSERVED";
    static String lastPresenceProbeDetail() { return lastPresenceProbeDetail; }

    /** Presence-only, no numeric/button decision or clicks; runs on the idle thread. */
    static OfferPresence probeCurrentOffersPresence(long budgetMs,
            java.util.function.BooleanSupplier mayRun) {
        EmptyIndexStatus status=readIndexedEmptyOffers(budgetMs,mayRun,true);
        lastPresenceProbeDetail=status.name();
        if(status==EmptyIndexStatus.OFFER_VISIBLE) return OfferPresence.PRESENT;
        if(status==EmptyIndexStatus.EMPTY) return OfferPresence.EMPTY;
        if(status==EmptyIndexStatus.JOBS_EMPTY) return OfferPresence.JOBS_EMPTY;
        if(status==EmptyIndexStatus.IGNORED_EMPTY) return OfferPresence.IGNORED_EMPTY;
        if(status==EmptyIndexStatus.JOBS_LIST) return OfferPresence.JOBS_LIST;
        if(status==EmptyIndexStatus.IGNORED_LIST) return OfferPresence.IGNORED_LIST;
        return OfferPresence.UNKNOWN; // BUSY/BUDGET/UI_CHANGED/UNAVAILABLE are never absence proof.
    }

    /** Only the idle lane calls this after verifying its UI generation is still current. */
    static void recordIdleOtherTabHint(OfferPresence presence) {
        if(presence==OfferPresence.JOBS_EMPTY || presence==OfferPresence.JOBS_LIST) updatePageHint(PageGuard.Page.JOBS);
        else if(presence==OfferPresence.IGNORED_EMPTY || presence==OfferPresence.IGNORED_LIST) updatePageHint(PageGuard.Page.IGNORED);
    }

    private static boolean hasIndexedEmptyOffers(long softBudgetMs,
            java.util.function.BooleanSupplier mayRun) {
        return readIndexedEmptyOffers(softBudgetMs, mayRun) == EmptyIndexStatus.EMPTY;
    }

    private static EmptyIndexStatus readIndexedEmptyOffers(long softBudgetMs,
            java.util.function.BooleanSupplier mayRun) {
        return readIndexedEmptyOffers(softBudgetMs,mayRun,false);
    }

    private static EmptyIndexStatus readIndexedEmptyOffers(long softBudgetMs,
            java.util.function.BooleanSupplier mayRun,boolean idleProbe) {
        if (!mayRun.getAsBoolean()) return EmptyIndexStatus.YIELD;
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return EmptyIndexStatus.NO_SERVICE;
        final long generation = UI_GENERATION.get();
        RejectReadProgress progress = REJECT_READ_PROGRESS.get();
        if (progress != null) progress.stage = "EMPTY_INDEX_ROOT";
        AccessibilityNodeInfo root;
        try { root = rootForRejectRead(service); }
        catch (RuntimeException stale) { return EmptyIndexStatus.STALE_NODE; }
        if (root == null) return EmptyIndexStatus.NO_ROOT;
        try {
            CharSequence rootPackage = root.getPackageName();
            if (rootPackage==null || !"com.deliverthat.driver".contentEquals(rootPackage))
                return EmptyIndexStatus.FOREIGN_ROOT;
            Rect rootBounds = new Rect(); root.getBoundsInScreen(rootBounds);
            if (rootBounds.isEmpty()) return EmptyIndexStatus.EMPTY_ROOT_BOUNDS;
            // Root acquisition is a separate non-interruptible operation. Start the bounded
            // index phase only after root/window geometry is available.
            final long deadline = rejectReadDeadline(SystemClock.elapsedRealtime() + softBudgetMs);
            if (progress != null) progress.stage = "EMPTY_INDEX";
            java.util.ArrayDeque<List<AccessibilityNodeInfo>> pending = new java.util.ArrayDeque<>();
            try {
            boolean empty = false, selectedOffers = false;
            boolean emptyJobs = false, emptyIgnored = false;
            boolean selectedJobs = false, selectedIgnored = false;
            boolean idleMoney = false, idleMiles = false, idleOfferAction = false;
            boolean idleDetails = false;
            boolean deliveriesHub = false, offersLabel = false, jobsLabel = false;
            // v2.10.297: the idle worker runs three independent, bounded index
            // queries in parallel. Four sequential queries regularly exceeded 34ms,
            // producing UNKNOWN even on an unchanged Offers-empty page. "Jobs"
            // detects the Jobs tab/empty text; "e" detects Offers, empty, Accept,
            // Reject and Ignored; "$" detects priced offers (even a Claim-only CTA).
            // Mileage-only text cannot authorize an Accept/Reject, so it need not
            // consume the idle-presence budget. No deep tree or city query here.
            final String[] queries = idleProbe
                    ? new String[]{"Jobs", "e", "$"}
                    : new String[]{"e", "$", "USD", "i", "Jobs"};
            if (progress != null || idleProbe) {
                List<IndexedQueryRead> jobs = new ArrayList<>();
                try { for (String query : queries)
                    jobs.add(new IndexedQueryRead(root,query)); }
                catch (RuntimeException failure) { for (IndexedQueryRead job:jobs) job.close(); throw failure; }
                if(progress != null) progress.queries += jobs.size();
                BoundedReadBatch.Result<IndexedQueryResult> batch = (idleProbe
                        ?service.idlePresenceBatch:service.rejectIndexBatch).read(jobs,
                        Math.max(1L,deadline-SystemClock.elapsedRealtime()));
                if (!batch.complete()) return "BUSY".equals(batch.reason)
                        ? EmptyIndexStatus.BUSY : EmptyIndexStatus.BUDGET;
                try { for (IndexedQueryResult result:batch.values) pending.addLast(result.takeNodes()); }
                finally { for (IndexedQueryResult result:batch.values) result.close(); }
            }
            for (String query : queries) {
                if (!mayRun.getAsBoolean()) return EmptyIndexStatus.YIELD;
                if (SystemClock.elapsedRealtime() >= deadline) return EmptyIndexStatus.BUDGET;
                List<AccessibilityNodeInfo> nodes = pending.isEmpty() ? root.findAccessibilityNodeInfosByText(query) : pending.removeFirst();
                if (nodes == null) return EmptyIndexStatus.NO_QUERY_RESULT; // not a complete miss
                try {
                    for (AccessibilityNodeInfo node : nodes) {
                        if (!mayRun.getAsBoolean()) return EmptyIndexStatus.YIELD;
                        if (SystemClock.elapsedRealtime() >= deadline) return EmptyIndexStatus.BUDGET;
                        if (node == null || !node.isVisibleToUser()) continue;
                        CharSequence nodeText=node.getText(), nodeDescription=node.getContentDescription();
                        String searchable=(String.valueOf(nodeText)+" "+nodeDescription).toLowerCase(Locale.US);
                        if (!relevantRejectIndexText(searchable)) continue;
                        Rect b = new Rect(); node.getBoundsInScreen(b);
                        if (progress != null) progress.visited++;
                        if (b.isEmpty()) continue;
                        for (CharSequence raw : new CharSequence[]{nodeText, nodeDescription}) {
                            if (raw == null) continue;
                            String value = raw.toString(), label = lettersOnlyLower(value);
                            if (idleProbe) {
                                PageGuard.Page otherTab = PageGuard.explicitEmptyOtherTabText(value);
                                if (otherTab==PageGuard.Page.JOBS) emptyJobs = true;
                                if (otherTab==PageGuard.Page.IGNORED) emptyIgnored = true;
                            }
                            boolean money = LIVE_MONEY.matcher(value).find();
                            boolean miles = LIVE_MILES.matcher(value).find();
                            boolean action = matchesAccept(raw) || ButtonLabels.isReject(raw);
                            if(idleProbe) {
                                idleMoney |= money; idleMiles |= miles; idleOfferAction |= action;
                            } else if(money || miles || action) return EmptyIndexStatus.NOT_EMPTY;
                            if (label.equals("restore") || label.equals("restorebutton")
                                    || ClaimSuccessSignals.hasAcceptedJobDetail(value)
                                    || ClaimSuccessSignals.hasBeginDeliveryControl(value)) {
                                if(idleProbe) idleDetails=true;
                                else return EmptyIndexStatus.NOT_EMPTY;
                            }
                            if (label.equals("deliveries")) deliveriesHub = true;
                            if (label.equals("offers")) offersLabel = true;
                            if (label.equals("jobs")) jobsLabel = true;
                            String lower = value.toLowerCase(Locale.US);
                            if (lower.contains("deliveries") && lower.contains("jobs") && lower.contains("offers")) {
                                deliveriesHub = true; offersLabel = true; jobsLabel = true;
                            }
                            if (lower.contains("pickup instructions") || lower.contains("dropoff instructions")
                                    || lower.contains("delivery instructions") || lower.contains("delivery timeline")
                                    || lower.contains("approver name") || lower.contains("nuid")
                                    || lower.contains("gl string") || lower.contains("loading")
                                    || lower.contains("please wait")) return EmptyIndexStatus.NOT_EMPTY;
                            if (EmptyOffersPolicy.isExplicitEmpty(value.toString())) empty = true;
                            if (node.isSelected() || node.isChecked()) {
                                if(label.equals("offers") || label.startsWith("offers")) selectedOffers = true;
                                if(label.equals("jobs")) selectedJobs = true;
                                if(label.equals("ignored")) selectedIgnored = true;
                                if(!idleProbe && (selectedJobs || selectedIgnored))
                                    return EmptyIndexStatus.NOT_EMPTY;
                            }
                        }
                    }
                } finally { for (AccessibilityNodeInfo node : nodes) if (node != null) node.recycle(); }
                // An explicit empty sentence must be present in the first e query.
                // Full current hub chrome may substitute for a missing RN selected bit.
                if (!idleProbe && query.equals("e") && !empty && !selectedOffers)
                    return EmptyIndexStatus.NOT_EMPTY;
                if (!mayRun.getAsBoolean()) return EmptyIndexStatus.YIELD;
            }
            if (UI_GENERATION.get() != generation) return EmptyIndexStatus.UI_CHANGED;
            if (SystemClock.elapsedRealtime() >= deadline) return EmptyIndexStatus.BUDGET;
            // Explicit empty Jobs/Ignored text is not an Offers-empty result. v293 lost
            // that distinction and the scanner could idle on the Jobs tab forever.
            // These statuses ONLY wake current-page re-verification; they never click.
            // Never classify a partial/late/off-package query as a navigation hint.
            if(idleProbe && (deliveriesHub || (offersLabel && jobsLabel))) {
                // A Jobs list with assigned work is still an OTHER TAB. Do not interpret
                // job prices/mileage as a live Offers card. Require CURRENT selected tab
                // and no conflicting Offers selection or live offer action row.
                if(selectedJobs && !selectedOffers && !selectedIgnored
                        && !(idleMoney && idleMiles && idleOfferAction))
                    return emptyJobs ? EmptyIndexStatus.JOBS_EMPTY : EmptyIndexStatus.JOBS_LIST;
                if(selectedIgnored && !selectedOffers && !selectedJobs
                        && !(idleMoney && idleMiles && idleOfferAction))
                    return emptyIgnored ? EmptyIndexStatus.IGNORED_EMPTY : EmptyIndexStatus.IGNORED_LIST;
                if(emptyJobs && !emptyIgnored && !empty && !selectedOffers)
                    return EmptyIndexStatus.JOBS_EMPTY;
                if(emptyIgnored && !emptyJobs && !empty && !selectedOffers)
                    return EmptyIndexStatus.IGNORED_EMPTY;
            }
            if(idleProbe && (idleMoney || idleMiles || idleOfferAction || idleDetails))
                return EmptyIndexStatus.OFFER_VISIBLE;
            // An explicit "No offers available" sentence read from the CURRENT
            // DeliverThat root is sufficient on an unselected Jobs/Ignored page too:
            // React-Native sometimes omits the nav labels/selected bit after Accept
            // fails, which previously produced UNKNOWN on every idle probe forever.
            // Any live offer amount/action above wins over the empty sentence.
            // A Jobs/Ignored selection always prevents the Offers-empty verdict.
            if(idleProbe) return empty && !selectedJobs && !selectedIgnored
                    ? EmptyIndexStatus.EMPTY : EmptyIndexStatus.NO_PAGE_EVIDENCE;
            return ((empty && (selectedOffers || (deliveriesHub && offersLabel && jobsLabel)))
                    || (selectedOffers && deliveriesHub && offersLabel && jobsLabel))
                    ? EmptyIndexStatus.EMPTY : EmptyIndexStatus.NO_PAGE_EVIDENCE;
            } finally { for (List<AccessibilityNodeInfo> nodes:pending)
                if(nodes!=null) for(AccessibilityNodeInfo node:nodes) if(node!=null) node.recycle(); }
        } catch (RuntimeException stale) { return EmptyIndexStatus.STALE_NODE; }
        finally { root.recycle(); }
    }

    /** Final-tail reads do not re-run a 96-node prefix or a missing Reject index first. */
    private static QuickTopResult readRejectRecheck() {
        return readRejectRecheck("");
    }

    private static QuickTopResult readRejectRecheck(String expectedText) {
        return readRejectRecheck(expectedText, () -> true, false);
    }

    private static QuickTopResult readRejectRecheck(String expectedText,
            java.util.function.BooleanSupplier mayRun, boolean preferEmpty) {
        TapAccessibilityService service=INSTANCE.get();
        if(service==null || !mayRun.getAsBoolean()) return new QuickTopResult(null,false,0,false,"YIELD_PRIORITY");
        long generation=UI_GENERATION.get(),epoch=WINDOW_TRANSITION_EPOCH.get();
        RejectReadProgress progress = new RejectReadProgress(SystemClock.elapsedRealtime(),
                RejectProbePolicy.treeMs(), preferEmpty || (service.rejectReadTurn.incrementAndGet() & 1) == 1);
        BoundedReadBatch.Result<QuickTopResult> read=service.rejectDeadlineReads.read(
                java.util.Collections.singletonList(new BoundedReadBatch.Read<QuickTopResult>() {
                    public QuickTopResult read(){
                        REJECT_READ_PROGRESS.set(progress);
                        progress.workerAt = SystemClock.elapsedRealtime();
                        try {
                            return readRejectRecheckWithinBudget(expectedText,
                                () -> progress.mayRead(SystemClock.elapsedRealtime())
                                    && INSTANCE.get()==service && generation==UI_GENERATION.get()
                                    && epoch==WINDOW_TRANSITION_EPOCH.get() && mayRun.getAsBoolean());
                        } finally {
                            AccessibilityNodeInfo root = REJECT_READ_ROOT.get();
                            REJECT_READ_ROOT.remove(); REJECT_READ_PROGRESS.remove();
                            if (root != null) try {root.recycle();} catch(RuntimeException ignored){}
                        }
                    }
                    public void close(){}
                }),RejectProbePolicy.treeMs());
        progress.cancelled = true;
        String detail = progress.detail(SystemClock.elapsedRealtime());
        if(!read.complete()) return new QuickTopResult(null,true,progress.visited,false,
                "READ_DEADLINE_"+read.reason+"|"+detail);
        QuickTopResult result = read.values.get(0);
        if (result.snapshot == null && !result.emptyOffers && SystemClock.elapsedRealtime() >= progress.deadlineAt)
            return new QuickTopResult(null,true,Math.max(result.visited,progress.visited),false,
                    "TOTAL_READ_BUDGET|"+detail);
        if(!mayRun.getAsBoolean()) return new QuickTopResult(null,false,progress.visited,false,"YIELD_PRIORITY|"+detail);
        if(generation!=UI_GENERATION.get() || epoch!=WINDOW_TRANSITION_EPOCH.get())
            return new QuickTopResult(null,false,progress.visited,false,"UI_CHANGED|"+detail);
        return new QuickTopResult(result.snapshot, result.budgetExceeded,
                Math.max(result.visited, progress.visited),result.emptyOffers,
                result.limitReason+"|"+detail,result.emptyContradicted);
    }
    private static QuickTopResult readRejectRecheckWithinBudget(String expectedText,
            java.util.function.BooleanSupplier mayRun) {
        if (!mayRun.getAsBoolean()) return new QuickTopResult(null, false, 0, false, "YIELD_PRIORITY");
        long generation = UI_GENERATION.get();
        long deadline=rejectReadDeadline(SystemClock.elapsedRealtime()+RejectProbePolicy.treeMs());
        RejectReadProgress progress = REJECT_READ_PROGRESS.get();
        if (progress != null) {
            // Observe current controls first on alternate reads. No action is sent here.
            if (!progress.indexFirst) {
                FastOfferSnapshot indexed = getIndexedCurrentTopRejectSnapshot(true, true,
                        Math.max(1L,deadline-SystemClock.elapsedRealtime()));
                if (indexed != null) return new QuickTopResult(indexed,false,progress.visited,false,"INDEXED_REJECT_FIRST");
            }
            if (!mayRun.getAsBoolean()) return new QuickTopResult(null,true,progress.visited,false,"TOTAL_READ_BUDGET");
            EmptyIndexStatus empty = readIndexedEmptyOffers(Math.max(1L,deadline-SystemClock.elapsedRealtime()), mayRun);
            if (empty == EmptyIndexStatus.EMPTY)
                return new QuickTopResult(null,false,progress.visited,true,"INDEXED_EMPTY_FIRST");
            if (empty == EmptyIndexStatus.BUDGET || !progress.mayRead(SystemClock.elapsedRealtime()))
                return new QuickTopResult(null,true,progress.visited,false,"TOTAL_READ_BUDGET");
            if (progress.indexFirst && mayRun.getAsBoolean()) {
                FastOfferSnapshot indexed = getIndexedCurrentTopRejectSnapshot(true,true,
                        Math.max(1L,deadline-SystemClock.elapsedRealtime()));
                if (indexed != null) return new QuickTopResult(indexed,false,progress.visited,false,"INDEXED_REJECT");
            }
            if (empty == EmptyIndexStatus.NOT_EMPTY && mayRun.getAsBoolean())
                return getQuickTopOfferSnapshotResult(Math.max(1L,deadline-SystemClock.elapsedRealtime()),
                        RejectProbePolicy.treeNodes(),true);
            return new QuickTopResult(null,false,progress.visited,false,"INDEXED_UNKNOWN_"+empty);
        }
        QuickTopResult tree = getQuickTopOfferSnapshotResult(
                Math.max(1L,deadline-SystemClock.elapsedRealtime()), RejectProbePolicy.treeNodes(), true);
        if(SystemClock.elapsedRealtime()>=deadline)
            return new QuickTopResult(null,true,tree.visited,false,"TOTAL_READ_BUDGET");
        if (!mayRun.getAsBoolean())
            return new QuickTopResult(null, false, tree.visited, false, "YIELD_PRIORITY");
        if (UI_GENERATION.get() != generation)
            return new QuickTopResult(null, false, tree.visited, false, "UI_CHANGED");
        if (tree.limitReason.endsWith(":JOBS") || tree.limitReason.endsWith(":IGNORED")) return tree;
        boolean identityReady = tree.snapshot != null && (expectedText.isEmpty()
                || !RejectDemandPolicy.sameOrUnprovenOwned(expectedText, tree.snapshot.text)
                || OfferEnrichmentPolicy.sameTransaction(expectedText, tree.snapshot.text)
                || CardText.identity(expectedText).equals(CardText.identity(tree.snapshot.text)));
        if (!tree.budgetExceeded && (identityReady || tree.emptyOffers)) return tree;
        // Explicit empty proof goes first: do not look for an already-removed Reject row.
        // Partial traversals still cannot prove absence; independent index proof must complete.
        if (!tree.emptyContradicted) {
            EmptyIndexStatus emptyIndex = readIndexedEmptyOffers(Math.max(1L,deadline-SystemClock.elapsedRealtime()), mayRun);
            if (emptyIndex == EmptyIndexStatus.EMPTY)
                return new QuickTopResult(null, false, tree.visited, true, "INDEXED_EMPTY");
            if (emptyIndex == EmptyIndexStatus.BUDGET || emptyIndex == EmptyIndexStatus.UI_CHANGED
                    || emptyIndex == EmptyIndexStatus.UNAVAILABLE
                    || emptyIndex == EmptyIndexStatus.NO_SERVICE || emptyIndex == EmptyIndexStatus.NO_ROOT
                    || emptyIndex == EmptyIndexStatus.FOREIGN_ROOT || emptyIndex == EmptyIndexStatus.EMPTY_ROOT_BOUNDS
                    || emptyIndex == EmptyIndexStatus.NO_QUERY_RESULT || emptyIndex == EmptyIndexStatus.NO_PAGE_EVIDENCE
                    || emptyIndex == EmptyIndexStatus.STALE_NODE)
                return new QuickTopResult(null, emptyIndex == EmptyIndexStatus.BUDGET, tree.visited,
                        false, "EMPTY_INDEX_" + emptyIndex + "|" + tree.limitReason);
        }
        if (!mayRun.getAsBoolean())
            return new QuickTopResult(null, false, tree.visited, false, "YIELD_PRIORITY");
        if(SystemClock.elapsedRealtime()>=deadline)
            return new QuickTopResult(null,true,tree.visited,false,"TOTAL_READ_BUDGET");
        FastOfferSnapshot indexed = getIndexedCurrentTopRejectSnapshot(true, true,
                Math.max(1L,deadline-SystemClock.elapsedRealtime()));
        if (indexed != null)
            return new QuickTopResult(indexed, false, tree.visited, false, "INDEXED_REJECT");
        return tree;
    }

    /**
     * Final Reject-tail inspection. It runs on the dedicated Reject worker and reports a
     * coherent result: a different/absent top means the rejected order has left the top; the
     * same top is returned only with freshly-read action geometry. No coordinate is reused here.
     */
    private static String rejectRecheckForegroundBlock() {
        if (OcrMonitorService.isManualInterventionPaused()) return "MANUAL_PAUSE";
        if (!OcrMonitorService.isMonitoring()) return "MONITOR_STOPPED";
        if (hasDeliverThatReplayForegroundHint()) return "";
        ForegroundState foreground=deliverThatForegroundState();
        if (foreground==ForegroundState.OTHER_APP) return "OUTSIDE_DELIVERTHAT";
        return foreground==ForegroundState.UNKNOWN ? "WINDOW_UNREADABLE" : "";
    }

    public static void recheckRejectedTop(String expectedText, boolean preferEmpty,
                                          Consumer<FastOfferSnapshot> sameTop,
                                          Consumer<String> disappeared,
                                          Consumer<String> unavailable,
                                          java.util.function.BooleanSupplier mayRun, Runnable deferred,
                                          java.util.function.BiConsumer<Long, Boolean> probeStats,
                                          Consumer<QuickTopResult> treeStats) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) {
            if (unavailable != null) unavailable.accept("辅助点击服务未连接");
            return;
        }
        Handler probeWorker = service.rejectRecheckWorker;
        if (probeWorker == null) {
            if (unavailable != null) unavailable.accept("Reject复核线程不可用");
            return;
        }
        Runnable verifiedAction = () -> {
            if (!mayRun.getAsBoolean()) { deferred.run(); return; }
            String firstForeground=rejectRecheckForegroundBlock();
            if (!firstForeground.isEmpty()) {
                if (unavailable != null) unavailable.accept(firstForeground);
                return;
            }
            long probeAt = SystemClock.elapsedRealtime();
            long firstGeneration=UI_GENERATION.get(), firstEpoch=WINDOW_TRANSITION_EPOCH.get();
            QuickTopResult first = readRejectRecheck(expectedText, mayRun, preferEmpty);
            probeStats.accept(SystemClock.elapsedRealtime() - probeAt, first.budgetExceeded);
            treeStats.accept(first);
            if (!mayRun.getAsBoolean()) { deferred.run(); return; }
            if (first.budgetExceeded) {
                if (unavailable != null) unavailable.accept("顶部复核达到扫描预算；" + first.limitReason + "；未按消失处理");
                return;
            }
            if (first.snapshot == null && !first.emptyOffers) {
                if (unavailable != null) unavailable.accept("顶部证据不完整；" + first.limitReason + "；未按消失处理");
                return;
            }
            if (first.emptyOffers) {
                // Confirm an empty/transitional React-Native frame once more. Two bounded misses
                // prevent a momentary blank hierarchy from being misreported as a completed Reject.
                probeWorker.postDelayed(() -> {
                    if (!mayRun.getAsBoolean()) { deferred.run(); return; }
                    String retryForeground=rejectRecheckForegroundBlock();
                    if (!retryForeground.isEmpty()) {
                        if (unavailable != null) unavailable.accept(retryForeground);
                        return;
                    }
                    long retryAt = SystemClock.elapsedRealtime();
                    QuickTopResult retry = readRejectRecheck(expectedText, mayRun, true);
                    probeStats.accept(SystemClock.elapsedRealtime() - retryAt, retry.budgetExceeded);
                    treeStats.accept(retry);
                    if (!mayRun.getAsBoolean()) { deferred.run(); return; }
                    if (retry.budgetExceeded) {
                        if (unavailable != null) unavailable.accept("第二次顶部复核达到预算；" + retry.limitReason + "；未按消失处理");
                        return;
                    }
                    if (retry.emptyOffers) {
                        if (firstGeneration != UI_GENERATION.get() || firstEpoch != WINDOW_TRANSITION_EPOCH.get()) {
                            if (unavailable != null) unavailable.accept("UI_CHANGED；空页复核期间页面发生变化");
                            return;
                        }
                        if (disappeared != null) disappeared.accept("后台连续两次确认Offers空页；原拒绝卡已消失");
                        return;
                    }
                    if (retry.snapshot == null) {
                        if (unavailable != null) unavailable.accept("第二次顶部证据不完整；"+retry.limitReason+"；未按消失处理");
                        return;
                    }
                    deliverRejectRecheckTop(expectedText, retry.snapshot, sameTop, disappeared, unavailable);
                }, RejectConfirmPriorityPolicy.finalEmptyRecheckMs());
                return;
            }
            deliverRejectRecheckTop(expectedText, first.snapshot, sameTop, disappeared, unavailable);
        };
        probeWorker.post(verifiedAction);
    }


    static final String REJECT_RECHECK_TOP_CHANGED = "顶部已切换为新订单；原拒绝卡已消失";

    private static void deliverRejectRecheckTop(String expectedText, FastOfferSnapshot top,
            Consumer<FastOfferSnapshot> sameTop, Consumer<String> disappeared, Consumer<String> unavailable) {
        if (top == null || !RejectDemandPolicy.coherent(top.text)) {
            if (unavailable != null) unavailable.accept("顶部同卡身份不完整；数值/地址字段未成卡；不补击");
        } else if (CardText.sameRejectObservation(expectedText, top.text)
                && !CardText.sameOffer(expectedText, top.text)) {
            if (unavailable != null) unavailable.accept("疑似同卡OCR漂移；不按换单处理，也不使用旧数值补击");
        } else if (!RejectDemandPolicy.sameOrUnprovenOwned(expectedText, top.text)) {
            if (disappeared != null) disappeared.accept(REJECT_RECHECK_TOP_CHANGED);
        } else if (OfferEnrichmentPolicy.sameTransaction(expectedText, top.text)
                || CardText.identity(expectedText).equals(CardText.identity(top.text))) {
            if (sameTop != null) sameTop.accept(top);
        } else if (unavailable != null) unavailable.accept("同卡身份证据不完整；不补击");
    }

    private static String claimOutcomeTextFromEvent(AccessibilityEvent event) {
        if (event == null) return "";
        StringBuilder text = new StringBuilder();
        if (event.getText() != null) {
            for (CharSequence value : event.getText()) if (value != null) text.append(value).append(' ');
        }
        if (event.getContentDescription() != null) text.append(event.getContentDescription()).append(' ');
        return text.toString();
    }

    private static String extractClaimOutcomeHint(String raw) {
        return ClaimSuccessSignals.extractOutcomeHint(raw);
    }

    private static void updateJobsBadgeFromEvent(AccessibilityEvent event) {
        if (event == null) return;
        StringBuilder text = new StringBuilder();
        if (event.getText() != null)
            for (CharSequence value : event.getText()) if (value != null) text.append(value).append(' ');
        if (event.getContentDescription() != null) text.append(event.getContentDescription()).append(' ');
        int count = ClaimSuccessSignals.jobsBadgeCount(text.toString());
        if (count >= 0) {
            lastJobsBadgeCount = count;
            lastJobsBadgeAt = SystemClock.elapsedRealtime();
            OcrMonitorService.onJobsBadgeObserved(count);
        }
    }

    private static void updateClaimUiCaches(String raw) {
        if (raw == null || raw.isEmpty()) return;
        long now = SystemClock.elapsedRealtime();
        int count = ClaimSuccessSignals.jobsBadgeCount(raw);
        if (count >= 0) {
            lastJobsBadgeCount = count;
            lastJobsBadgeAt = now;
            OcrMonitorService.onJobsBadgeObserved(count);
        }
        String hint = ClaimSuccessSignals.extractOutcomeHint(raw);
        if (!hint.isEmpty()) {
            lastClaimOutcomeHint = hint;
            lastClaimOutcomeHintAt = now;
            if (ClaimSuccessSignals.isTerminalNegative(hint)) {
                lastTerminalClaimOutcomeHint = hint;
                lastTerminalClaimOutcomeHintAt = now;
            }
        }
        if (ClaimSuccessSignals.hasAcceptedJobDetail(raw)) {
            lastAcceptedJobDetailRaw = raw;
            lastAcceptedJobDetailAt = now;
        }
    }

    /**
     * v2.10.128: a visible exact Begin Delivery control on DeliverThat's live foreground page
     * is authoritative claim-success evidence.  The accepted-job page is allowed to omit the
     * offer amount, mileage, pickup time and merchant text; requiring those fields caused a real
     * claimed job to be misclassified as unavailable.  The caller still owns a current
     * post-Accept/terminal-verification transaction, so this is never used as an Offer rule input.
     */
    public static boolean liveBeginDeliveryMatches(String offerText) {
        TapAccessibilityService service=INSTANCE.get();if(service==null)return false;
        long gen=UI_GENERATION.get(),epoch=WINDOW_TRANSITION_EPOCH.get();AtomicBoolean cancelled=new AtomicBoolean();
        java.util.function.BooleanSupplier live=()->!cancelled.get() && INSTANCE.get()==service
                && gen==UI_GENERATION.get() && epoch==WINDOW_TRANSITION_EPOCH.get();
        try {
            BoundedReadBatch.Result<Boolean> result=service.successDeadlineReads.read(
                java.util.Collections.singletonList(new BoundedReadBatch.Read<Boolean>() {
                    public Boolean read(){return readLiveBeginDeliveryMatches(offerText,live);}
                    public void close(){}
                }),65L);
            return result.complete() && live.getAsBoolean() && result.values.get(0);
        } finally {cancelled.set(true);}
    }
    private static boolean readLiveBeginDeliveryMatches(String offerText,java.util.function.BooleanSupplier mayRun) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return false;
            if (!hasVisibleBeginDeliveryNode(root)) return false;
            StringBuilder text = new StringBuilder();
            collectLimitedText(root, text, new int[]{320});
            String raw = text.toString();
            if(!mayRun.getAsBoolean() || !CardText.knownJobFieldsAgree(offerText,raw)) return false;
            long now = SystemClock.elapsedRealtime();
            lastAcceptedJobDetailRaw = raw;
            lastAcceptedJobDetailAt = now;
            lastClaimOutcomeHint = "Begin Delivery/assigned Job";
            lastClaimOutcomeHintAt = now;
            return true;
        } catch (RuntimeException ignored) {
            return false;
        } finally {
            try { root.recycle(); } catch (RuntimeException ignored) { }
        }
    }

    private static boolean hasVisibleBeginDeliveryNode(AccessibilityNodeInfo root) {
        for (String query : new String[]{"Begin Delivery", "Begin to Delivery"}) {
            List<AccessibilityNodeInfo> indexed = null;
            try {
                indexed = root.findAccessibilityNodeInfosByText(query);
                if (indexed == null) continue;
                for (AccessibilityNodeInfo node : indexed) {
                    if (node == null || !node.isVisibleToUser()) continue;
                    CharSequence text = node.getText();
                    CharSequence desc = node.getContentDescription();
                    if (!ClaimSuccessSignals.isExactBeginDeliveryControl(
                            text == null ? "" : text.toString())
                            && !ClaimSuccessSignals.isExactBeginDeliveryControl(
                            desc == null ? "" : desc.toString())) continue;
                    return true;
                }
            } finally {
                if (indexed != null)
                    for (AccessibilityNodeInfo node : indexed) if (node != null) node.recycle();
            }
        }
        return false;
    }

    /** Cached only: never walks the tree. Used before retry dispatch. */
    public static String recentCachedClaimOutcomeSince(long sinceElapsed) {
        long now = SystemClock.elapsedRealtime();
        String cached = lastClaimOutcomeHint;
        return !cached.isEmpty() && lastClaimOutcomeHintAt >= Math.max(0L, sinceElapsed - 120L)
                && now - lastClaimOutcomeHintAt <= 5_000L ? cached : "";
    }

    public static long outcomeUiGeneration() { return UI_GENERATION.get(); }
    public static long outcomeWindowEpoch() { return WINDOW_TRANSITION_EPOCH.get(); }

    private static String pageNegativeHint(String text) {
        if (text == null) return "";
        String lower = text.toLowerCase(Locale.US);
        if (!(lower.contains("unavailable") || lower.contains("available")
                || lower.contains("claimed") || lower.contains("assigned") || lower.contains("to accept")
                || lower.contains("conflict") || lower.contains("overlap"))) return "";
        String hint = ClaimSuccessSignals.extractOutcomeHint(text);
        return ClaimSuccessSignals.isTerminalNegative(hint) ? hint : "";
    }

    private static final class PageRetryReceipt {
        final long actionAt,dispatchAt;
        final FastOfferSnapshot snapshot;
        PageRetryReceipt(long actionAt,long dispatchAt,FastOfferSnapshot snapshot) {
            this.actionAt=actionAt;this.dispatchAt=dispatchAt;this.snapshot=snapshot;
        }
    }
    private static final AtomicReference<PageRetryReceipt> PAGE_RETRY_RECEIPT=new AtomicReference<>();

    private static void clearPageRetryReceipt(long actionAt) {
        PageRetryReceipt old=PAGE_RETRY_RECEIPT.get();
        if(old!=null && old.actionAt==actionAt && PAGE_RETRY_RECEIPT.compareAndSet(old,null)
                && old.snapshot.indexedRead.witness!=null) old.snapshot.indexedRead.witness.close();
    }

    private static boolean freshPageRetrySnapshot(FastOfferSnapshot snapshot,long actionAt) {
        if(snapshot==null || snapshot.indexedRead==null || !snapshot.acceptEnabled
                || snapshot.acceptBounds.isEmpty()) return false;
        IndexedReadProof proof=snapshot.indexedRead;
        long now=SystemClock.elapsedRealtime();
        return proof.stages.startsWith("RETRY_CURRENT_INDEX_PAGE")
                && now>=snapshot.capturedAt && !snapshot.acceptBounds.isEmpty()
                && "com.deliverthat.driver".equals(foregroundPackage)
                && actionAt>0 && OcrMonitorService.pendingClaimSince()==actionAt
                && OcrMonitorService.isMonitoring() && !OcrMonitorService.isManualInterventionPaused()
                && OcrMonitorService.acceptRetryGuard(actionAt).isEmpty();
    }


    public static FastOfferSnapshot takeAcceptPageRetrySnapshot(String expected,long actionAt) {
        PageRetryReceipt receipt=PAGE_RETRY_RECEIPT.get();
        if(receipt==null || receipt.actionAt!=actionAt
                || !PAGE_RETRY_RECEIPT.compareAndSet(receipt,null)) return null;
        FastOfferSnapshot snapshot=receipt.snapshot;
        boolean usable=receipt.dispatchAt==OcrMonitorService.acceptDispatchObservedAt()
                && snapshot!=null && snapshot.indexedRead!=null && snapshot.acceptEnabled
                && snapshot.indexedRead.windowEpoch==WINDOW_TRANSITION_EPOCH.get()
                && SystemClock.elapsedRealtime()>=snapshot.capturedAt
                && SystemClock.elapsedRealtime()-snapshot.capturedAt<=250L
                && OcrMonitorService.pendingClaimSince()==actionAt
                && OcrMonitorService.isMonitoring() && !OcrMonitorService.isManualInterventionPaused()
                && OcrMonitorService.acceptRetryGuard(actionAt).isEmpty()
                && IndexedWitnessPolicy.sameIdentity(expected,snapshot.text);
        if(!usable && snapshot.indexedRead.witness!=null) snapshot.indexedRead.witness.close();
        return usable?snapshot:null;
    }

    private static final AtomicReference<AcceptPageObservation> LAST_ACCEPT_PAGE=new AtomicReference<>();
    private static final class AcceptPageObservation {
        final TapAccessibilityService service;
        final long owner,dispatch,generation,epoch;
        final PageOutcomePolicy.Reading reading;
        AcceptPageObservation(TapAccessibilityService service,long owner,long dispatch,
                long generation,long epoch,PageOutcomePolicy.Reading reading) {
            this.service=service;this.owner=owner;this.dispatch=dispatch;
            this.generation=generation;this.epoch=epoch;this.reading=reading;
        }
    }
    /** Only the primary result probe reads a page; a secondary inspector may consume its
     * current proof. Cached text alone never supplies click geometry or a new confirmation. */
    public static FastOfferSnapshot observeCurrentOwnedAcceptSnapshot(String expected,long owner) {
        AcceptPageObservation page=LAST_ACCEPT_PAGE.get();
        long now=SystemClock.elapsedRealtime();
        if(page==null || page.service!=INSTANCE.get() || owner<=0L || page.owner!=owner
                || owner!=OcrMonitorService.pendingClaimSince()
                || page.dispatch!=OcrMonitorService.acceptDispatchObservedAt()
                || page.generation!=UI_GENERATION.get() || page.epoch!=WINDOW_TRANSITION_EPOCH.get()
                || !OcrMonitorService.isMonitoring() || OcrMonitorService.isManualInterventionPaused()
                || !OcrMonitorService.acceptRetryGuard(owner).isEmpty()) return null;
        PageOutcomePolicy.Reading reading=page.reading;
        if(reading==null || !reading.complete || now<reading.end || now-reading.end>120L
                || reading.context==null || reading.positive || !reading.hint.isEmpty()
                || !IndexedWitnessPolicy.sameIdentity(expected,reading.context)) return null;
        FastOfferSnapshot receipt=takeAcceptPageRetrySnapshot(expected,owner);
        if(receipt!=null) return receipt;
        return !"ENABLED".equals(reading.actionState)
                ?new FastOfferSnapshot(reading.context,new Rect(),new Rect(),false,false):null;
    }

    /** Bounded fresh active-window read, used only AFTER an actual Accept dispatch. */
    public static PageOutcomePolicy.Reading sampleAcceptPageOutcome(java.util.function.BooleanSupplier mayRun) {
        TapAccessibilityService service=INSTANCE.get();long start=SystemClock.elapsedRealtime(),epoch=WINDOW_TRANSITION_EPOCH.get();
        long generation=UI_GENERATION.get(),dispatch=OcrMonitorService.acceptDispatchObservedAt();
        long owner=OcrMonitorService.pendingClaimSince();AtomicBoolean cancelled=new AtomicBoolean();
        java.util.function.BooleanSupplier live=()->!cancelled.get() && INSTANCE.get()==service
                && owner==OcrMonitorService.pendingClaimSince() && epoch==WINDOW_TRANSITION_EPOCH.get() && mayRun.getAsBoolean();
        if(service==null || !live.getAsBoolean()) return new PageOutcomePolicy.Reading(-1,epoch,start,start,false,false,"",null,"YIELD",0,0);
        try {
            BoundedReadBatch.Result<PageOutcomePolicy.Reading> result=service.outcomeDeadlineReads.read(
                java.util.Collections.singletonList(new BoundedReadBatch.Read<PageOutcomePolicy.Reading>() {
                    public PageOutcomePolicy.Reading read(){return readAcceptPageOutcome(live);}
                    public void close(){}
                }),140L);
            if(result.complete() && live.getAsBoolean()) {
                PageOutcomePolicy.Reading reading=result.values.get(0);
                if(reading!=null && reading.complete && owner>0L && generation==UI_GENERATION.get()
                        && dispatch==OcrMonitorService.acceptDispatchObservedAt())
                    LAST_ACCEPT_PAGE.set(new AcceptPageObservation(service,owner,dispatch,generation,epoch,reading));
                return reading;
            }
            return new PageOutcomePolicy.Reading(-1,epoch,start,SystemClock.elapsedRealtime(),false,false,"",null,"INDEX_"+result.reason,0,0);
        } finally {cancelled.set(true);}
    }
    private static PageOutcomePolicy.Reading readAcceptPageOutcome(java.util.function.BooleanSupplier mayRun) {
        // One fresh-root restart can catch the stable RN frame immediately after subtree churn.
        // Both passes independently enforce the full generation/window fence; no mixed read survives.
        long batchStart=SystemClock.elapsedRealtime();
        final long sampleActionAt=OcrMonitorService.pendingClaimSince();
        final String expectedOwned=OcrMonitorService.pendingClaimText(sampleActionAt);
        final long sampleDispatchAt=OcrMonitorService.acceptDispatchObservedAt();
        // A new read does not invalidate an unconsumed enabled-control receipt. Freshness,
        // generation/window, transaction and terminal checks still guard its eventual use.
        for (int pass=0;;pass++) {
        TapAccessibilityService service = INSTANCE.get();
        long start = SystemClock.elapsedRealtime();
        long generation = UI_GENERATION.get(), epoch = WINDOW_TRANSITION_EPOCH.get();
        int window=-1, queries=0, visited=0;
        AccessibilityNodeInfo root=null,retryAction=null;
        List<AccessibilityNodeInfo> visibleAcceptRows=new ArrayList<>();
        List<Rect> visibleActionRows=new ArrayList<>();
        IndexedWitness pageWitness=new IndexedWitness();
        boolean pageWitnessPublished=false;
        java.util.ArrayDeque<List<AccessibilityNodeInfo>> pendingQueryGroups=new java.util.ArrayDeque<>();
        try {
            if (service==null || !mayRun.getAsBoolean()) throw new IllegalStateException("YIELD");
            root=service.getRootInActiveWindow();
            if (root==null) throw new IllegalStateException("NO_ROOT");
            if (!"com.deliverthat.driver".contentEquals(root.getPackageName()==null?"":root.getPackageName()))
                throw new IllegalStateException("FOREIGN_APP");
            window=root.getWindowId();
            Rect rootBounds=new Rect();root.getBoundsInScreen(rootBounds);
            if (rootBounds.isEmpty()) throw new IllegalStateException("NO_BOUNDS");
            StringBuilder raw = new StringBuilder();
            List<CardText.Piece> pieces=new ArrayList<>();
            Rect topAction=new Rect(), topAccept=new Rect();
            String actionState="NOT_EXPORTED", controlCause="NO_ACCEPT_LABEL", excerpt="";
            boolean conflictExcerpt=false,visibleBegin=false;
            java.util.HashSet<String> actionSeeds=new java.util.HashSet<>();
            java.util.HashSet<String> seen = new java.util.HashSet<>();
            String[] pageQueries={"e", "$", "USD", "mi", "a", "Jobs", "conflict"};
            for(int queryIndex=0;queryIndex<pageQueries.length;queryIndex++) {
                String query=pageQueries[queryIndex];
                if (!mayRun.getAsBoolean()) throw new IllegalStateException("YIELD");
                if(generation!=UI_GENERATION.get() || epoch!=WINDOW_TRANSITION_EPOCH.get())
                    throw new IllegalStateException("UI_CHANGED");
                if (SystemClock.elapsedRealtime()-start>150L) throw new IllegalStateException("TIME_LIMIT");
                List<AccessibilityNodeInfo> nodes;
                if(!pendingQueryGroups.isEmpty()) {
                    nodes=pendingQueryGroups.removeFirst();
                } else if(queryIndex+1<pageQueries.length) {
                    int groupSize=Math.min(4,pageQueries.length-queryIndex);
                    BoundedReadBatch.Result<IndexedQueryResult> group=
                            readIndexedQueryGroupWithBudget(service,root,pageQueries,queryIndex,groupSize,
                                    Math.max(1L,Math.min(90L,start+150L-SystemClock.elapsedRealtime())));
                    if(group.complete()) {
                        queries+=groupSize;
                        try {
                            for(IndexedQueryResult value:group.values) pendingQueryGroups.addLast(value.takeNodes());
                            nodes=pendingQueryGroups.removeFirst();
                        } finally {for(IndexedQueryResult value:group.values)value.close();}
                    } else if("BUSY".equals(group.reason)) {
                        nodes=root.findAccessibilityNodeInfosByText(query);queries++;
                    } else {queries+=groupSize;throw new IllegalStateException("INDEX_"+group.reason);}
                } else {nodes=root.findAccessibilityNodeInfosByText(query);queries++;}
                if (nodes==null) throw new IllegalStateException("NULL_INDEX");
                try {
                    if(generation!=UI_GENERATION.get() || epoch!=WINDOW_TRANSITION_EPOCH.get())
                        throw new IllegalStateException("UI_CHANGED");
                    for (AccessibilityNodeInfo node:nodes) {
                        if (!mayRun.getAsBoolean()) throw new IllegalStateException("YIELD");
                        if(generation!=UI_GENERATION.get() || epoch!=WINDOW_TRANSITION_EPOCH.get())
                            throw new IllegalStateException("UI_CHANGED");
                        if (SystemClock.elapsedRealtime()-start>150L) throw new IllegalStateException("TIME_LIMIT");
                        visited++;
                        if (node==null || !node.isVisibleToUser() || node.getWindowId()!=window) continue;
                        Rect bounds=new Rect();node.getBoundsInScreen(bounds);
                        if (bounds.isEmpty()) continue;
                        CharSequence label=node.getText(),desc=node.getContentDescription();
                        if(ClaimSuccessSignals.isExactBeginDeliveryControl(label==null?"":label.toString())
                                || ClaimSuccessSignals.isExactBeginDeliveryControl(desc==null?"":desc.toString())) visibleBegin=true;
                        String text=(label==null?"":label.toString())+" "+(desc==null?"":desc.toString());
                        text=text.trim();if (text.isEmpty()) continue;
                        String key=text+"@"+bounds.left+","+bounds.top+","+bounds.bottom;
                        boolean newPiece=seen.add(key);
                        if (newPiece) {
                            raw.append(text).append('\n');addUniquePiece(pieces,text,bounds);
                            if(CardText.amount(text)>=0f || CardText.miles(text)>=0f
                                    || LIVE_CA_ZIP.matcher(text).find() || LIVE_OFFER_TIME.matcher(text).find())
                                pageWitness.field(node);
                        }
                        String nodeHint=newPiece?pageNegativeHint(text):"";
                        if (!nodeHint.isEmpty()) {
                            // Stop queued retries as soon as the current window exposes a negative.
                            // The full fenced read below still owns terminal attribution.
                            long hintAt=SystemClock.elapsedRealtime();
                            if (mayRun.getAsBoolean() && generation==UI_GENERATION.get()
                                    && epoch==WINDOW_TRANSITION_EPOCH.get())
                                CURRENT_SURFACE_GATE.observe(epoch,start,hintAt,true,true,hintAt);
                        }
                        if (!nodeHint.isEmpty() && (!conflictExcerpt || ClaimSuccessSignals.isTimeConflict(nodeHint))) {
                            String nodeExcerpt=ClaimSuccessSignals.outcomeExcerpt(text);
                            if (!nodeExcerpt.isEmpty() && (excerpt.isEmpty() || nodeExcerpt.length()>excerpt.length()
                                    || ClaimSuccessSignals.isTimeConflict(nodeHint))) {
                                excerpt=nodeExcerpt;conflictExcerpt=ClaimSuccessSignals.isTimeConflict(nodeHint);
                            }
                        }
                        boolean acceptLabel=(label!=null&&label.length()<=64&&matchesAccept(label))
                                || (desc!=null&&desc.length()<=64&&matchesAccept(desc));
                        if (acceptLabel && actionSeeds.add(key)) {
                            controlCause="ACTION_GEOMETRY_OR_HIDDEN";
                            AccessibilityNodeInfo action=resolveIndexedAction(node,rootBounds,true);
                            if(action!=null) try {
                                Rect actionBounds=new Rect();action.getBoundsInScreen(actionBounds);
                                if(action.isVisibleToUser() && action.getWindowId()==window
                                        && safeActionBounds(rootBounds,actionBounds,true)) {
                                    boolean duplicate=false;
                                    for(AccessibilityNodeInfo prior:visibleAcceptRows) {
                                        Rect known=new Rect();prior.getBoundsInScreen(known);
                                        if(known.left==actionBounds.left && known.top==actionBounds.top
                                                && known.right==actionBounds.right && known.bottom==actionBounds.bottom) {duplicate=true;break;}
                                    }
                                    if(!duplicate) {
                                        if(visibleAcceptRows.size()>=24) throw new IllegalStateException("OWNED_ROW_LIMIT");
                                        visibleAcceptRows.add(AccessibilityNodeInfo.obtain(action));
                                    }
                                }
                                if(action.isVisibleToUser() && action.getWindowId()==window
                                        && safeActionBounds(rootBounds,actionBounds,true)
                                        && (topAccept.isEmpty() || actionBounds.top<topAccept.top)) {
                                    topAccept.set(actionBounds);
                                    actionState=actionNodeReady(action)?"ENABLED":"DISABLED";
                                    controlCause="INDEXED_CONTROL";
                                    if(retryAction!=null) retryAction.recycle();
                                    retryAction=AccessibilityNodeInfo.obtain(action);
                                    pageWitness.action(node);
                                }
                            } finally {action.recycle();}
                        }
                        boolean action=(label!=null&&label.length()<=64&&matchesAccept(label))
                                || (desc!=null&&desc.length()<=64&&matchesAccept(desc))
                                || ButtonLabels.isReject(label)||ButtonLabels.isReject(desc);
                        if(action) visibleActionRows.add(new Rect(bounds));
                        if (action && (topAction.isEmpty() || bounds.top<topAction.top)) topAction.set(bounds);
                    }
                } finally {for (AccessibilityNodeInfo node:nodes) if (node!=null) node.recycle();}
            }
            long end=SystemClock.elapsedRealtime();
            if (generation!=UI_GENERATION.get() || epoch!=WINDOW_TRANSITION_EPOCH.get())
                throw new IllegalStateException("UI_CHANGED");
            if (end-start>150L) throw new IllegalStateException("TIME_LIMIT");
            if (!mayRun.getAsBoolean()) throw new IllegalStateException("YIELD");
            // One coherent index already contains every visible card's fields/actions.
            // Bind the pending identity to its current row before interpreting the top row.
            boolean ownedSearch=!expectedOwned.isEmpty()
                    && (!OfferEnrichmentPolicy.endpointKey(expectedOwned).isEmpty() || !CardText.orderId(expectedOwned).isEmpty());
            Rect ownedBounds=new Rect();AccessibilityNodeInfo ownedAction=null;
            boolean ambiguousOwned=false,ownedRebound=false,ownedRowsComplete=true;
            if(ownedSearch) {
                for(AccessibilityNodeInfo candidate:visibleAcceptRows) {
                    if(SystemClock.elapsedRealtime()-start>150L) throw new IllegalStateException("TIME_LIMIT");
                    Rect row=new Rect();candidate.getBoundsInScreen(row);
                    String card=CardText.aboveButton(pieces,row.top,row.bottom);
                    if(!IndexedWitnessPolicy.sameIdentity(expectedOwned,card)) {
                        if(card.isEmpty() || PageOutcomePolicy.compatible(expectedOwned,card)) ownedRowsComplete=false;
                        continue;
                    }
                    if(ownedAction!=null && (row.top>=ownedBounds.bottom || row.bottom<=ownedBounds.top)) {
                        ambiguousOwned=true;break;
                    }
                    ownedBounds.set(row);ownedAction=candidate;
                }
                if(!ambiguousOwned && ownedAction!=null) {
                    ownedRebound=topAccept.isEmpty() || topAccept.top!=ownedBounds.top || topAccept.bottom!=ownedBounds.bottom;
                    topAccept.set(ownedBounds);topAction.set(ownedBounds);
                    if(retryAction!=null) retryAction.recycle();
                    retryAction=AccessibilityNodeInfo.obtain(ownedAction);
                    actionState=actionNodeReady(ownedAction)?"ENABLED":"DISABLED";
                    controlCause=ownedRebound?"OWNED_ROW_REBOUND":"OWNED_ROW_CURRENT";
                } else if(!ambiguousOwned) {
                    // A Reject-only/temporarily hidden Accept row is still visible identity.
                    for(Rect row:visibleActionRows) {
                        String card=CardText.aboveButton(pieces,row.top,row.bottom);
                        if(!IndexedWitnessPolicy.sameIdentity(expectedOwned,card)) {
                            if(card.isEmpty() || PageOutcomePolicy.compatible(expectedOwned,card)) ownedRowsComplete=false;
                            continue;
                        }
                        if(!ownedBounds.isEmpty() && (row.top>=ownedBounds.bottom || row.bottom<=ownedBounds.top)) {
                            ambiguousOwned=true;break;
                        }
                        ownedBounds.set(row);
                    }
                    if(ownedBounds.isEmpty()) {
                        String tail=CardText.aboveButton(pieces,rootBounds.bottom,rootBounds.bottom+1f);
                        if(IndexedWitnessPolicy.sameIdentity(expectedOwned,tail))
                            ownedBounds.set(new Rect(rootBounds.left,rootBounds.bottom,rootBounds.right,rootBounds.bottom+1));
                        else if(!tail.isEmpty() && PageOutcomePolicy.compatible(expectedOwned,tail)) ownedRowsComplete=false;
                    }
                    if(!ownedBounds.isEmpty() && !ambiguousOwned) {
                        topAction.set(ownedBounds);topAccept.setEmpty();
                        if(retryAction!=null) {retryAction.recycle();retryAction=null;}
                        actionState="NOT_EXPORTED";controlCause="OWNED_ROW_WITHOUT_ACCEPT";
                    }
                }
            }
            String text=raw.toString(), reason="OK";
            float pay=CardText.amount(text),miles=CardText.miles(text);
            String context="",evidenceDetail="";
            if (pay>=0 || miles>=0) {
                context=CardText.aboveButton(pieces,topAction.isEmpty()?rootBounds.bottom:topAction.top,
                        topAction.isEmpty()?rootBounds.bottom+1:topAction.bottom);
                String numericScope=text;
                if (!topAction.isEmpty()) {
                    numericScope=CardText.numericScopeAboveButton(pieces,topAction.top);
                }
                if (CardText.containsConflictingOfferNumbers(numericScope)) {
                    context=null;reason="CONFLICTING_NUMBERS";
                    evidenceDetail=CardText.numericConflictSummary(numericScope);
                }
                // Parent+child duplicates are resolved by the existing spatial card assembler;
                // never run containsMultipleMileageRows on the flattened whole-page text.
                else if (topAction.isEmpty() && pageHasSeparateNumericRows(pieces)) {
                    context=null;reason="AMBIGUOUS_ROWS";
                } else if (CardText.amount(context)<0 || CardText.miles(context)<0) {
                    context=null;reason="PARTIAL_CARD";
                }
            }
            if(ambiguousOwned) {context=null;reason="AMBIGUOUS_OWNED_ROWS";actionState="UNKNOWN";}
            if(ownedSearch && ownedBounds.isEmpty() && !ownedRowsComplete) {
                context=null;reason="OWNED_ROW_INCOMPLETE";actionState="UNKNOWN";
            }
            if(ownedSearch) evidenceDetail+=(evidenceDetail.isEmpty()?"":";")
                    +"OWNED_ROW_SEARCH="+(ownedRowsComplete?"COMPLETE":"INCOMPLETE");
            // A lower card's enabled Accept cannot prove the top card actionable.
            if (!topAccept.isEmpty() && !topAction.isEmpty()
                    && (topAccept.bottom <= topAction.top || topAccept.top >= topAction.bottom))
                actionState="OTHER_ROW";
            if("OTHER_ROW".equals(actionState)) controlCause="LOWER_CARD_ACTION";
            boolean positive=ClaimSuccessSignals.hasBeginDeliveryControl(text)||ClaimSuccessSignals.hasAcceptedJobDetail(text);
            String negative=pageNegativeHint(text);
            boolean ownedPositive=positive && visibleBegin && negative.isEmpty() && visibleAcceptRows.isEmpty()
                    && !expectedOwned.isEmpty() && !OfferEnrichmentPolicy.pickupKey(expectedOwned).isEmpty()
                    && !CardText.containsConflictingOfferNumbers(text)
                    && ClaimSuccessSignals.acceptedJobMatchesOffer(expectedOwned,text);
            FastOfferSnapshot pageSnapshot=null;
            if(sampleActionAt>0 && sampleDispatchAt>0 && start>=sampleDispatchAt
                    && context!=null && !context.isEmpty() && !positive && negative.isEmpty()
                    && "ENABLED".equals(actionState) && retryAction!=null) {
                // Keep live control evidence even if the second clear frame is still queued.
                // The full read remains generation-fenced; only this final refresh proves the CTA.
                Rect live=new Rect();
                long controlReadAt=SystemClock.elapsedRealtime();
                if(retryAction.refresh()) {
                    retryAction.getBoundsInScreen(live);
                    if(retryAction.isVisibleToUser() && retryAction.getWindowId()==window
                            && live.left==topAccept.left && live.top==topAccept.top
                            && live.right==topAccept.right && live.bottom==topAccept.bottom
                            && safeActionBounds(rootBounds,live,true)) {
                        actionState=actionNodeReady(retryAction)?"ENABLED":"DISABLED";
                    } else {actionState="NOT_EXPORTED";controlCause="FINAL_GEOMETRY_WINDOW_OR_VISIBILITY";}
                    if("ENABLED".equals(actionState)) {
                        long readyAt=SystemClock.elapsedRealtime();
                        IndexedReadProof proof=new IndexedReadProof(rootBounds,window,generation,start,readyAt,
                                "RETRY_CURRENT_INDEX_PAGE;"+(ownedRebound?"OWNED_ROW_REBOUND;":"")+"queries="+queries+";nodes="+visited);
                        proof.controlReadAt=controlReadAt;
                        if(!ownedRebound && !pageWitness.overflow && pageWitness.action!=null && !pageWitness.fields.isEmpty()) {
                            proof.witness=pageWitness;pageWitness.capturedAt=readyAt;
                        }
                        pageSnapshot=new FastOfferSnapshot(context,live,new Rect(),true,false,
                                readyAt,CardText.amount(context),CardText.miles(context),proof);
                    }
                } else {actionState="NOT_EXPORTED";controlCause="FINAL_REFRESH_FAILED";}
            }
            end=SystemClock.elapsedRealtime();
            if(generation!=UI_GENERATION.get() || epoch!=WINDOW_TRANSITION_EPOCH.get())
                throw new IllegalStateException("UI_CHANGED");
            if(end-start>150L) throw new IllegalStateException("TIME_LIMIT");
            if(!mayRun.getAsBoolean()) throw new IllegalStateException("YIELD");
            if(pageSnapshot!=null && OcrMonitorService.pendingClaimSince()==sampleActionAt
                    && OcrMonitorService.acceptDispatchObservedAt()==sampleDispatchAt)
            {
                rememberAcceptResumeNodes(pageSnapshot,sampleActionAt);
                PageRetryReceipt previous=PAGE_RETRY_RECEIPT.getAndSet(
                        new PageRetryReceipt(sampleActionAt,sampleDispatchAt,pageSnapshot));
                if(previous!=null && previous.snapshot.indexedRead.witness!=null)
                    previous.snapshot.indexedRead.witness.close();
                if(pageSnapshot.indexedRead.witness!=null) {
                    pageWitnessPublished=true;service.main.postDelayed(pageWitness::close,400L);
                }
            }
            else if(pageSnapshot==null) clearPageRetryReceipt(sampleActionAt);
            CURRENT_SURFACE_GATE.observe(epoch,start,end,true,!positive && !negative.isEmpty(),end);
            return new PageOutcomePolicy.Reading(window,epoch,start,end,true,positive,
                    negative,context,reason,queries,visited,excerpt,actionState,
                    evidenceDetail+(evidenceDetail.isEmpty()?"":";")+"CONTROL_CAUSE="+controlCause
                            +(pageSnapshot==null?"":";PAGE_PROOF_READ_START="+start
                                +";PAGE_PROOF_CONTROL_READ="+pageSnapshot.acceptControlReadAt()),ownedPositive);
        } catch (RuntimeException ex) {
            String reason=ex instanceof IllegalStateException?ex.getMessage():"READ_EXCEPTION";
            if (pass==0 && "UI_CHANGED".equals(reason) && mayRun.getAsBoolean()
                    && SystemClock.elapsedRealtime()-batchStart<80L) continue;
            return new PageOutcomePolicy.Reading(window,epoch,start,SystemClock.elapsedRealtime(),false,
                    false,"",null,reason,queries,visited,"","UNKNOWN",
                    "START_GEN="+generation+",END_GEN="+UI_GENERATION.get()+";UI_EVENT="+lastUiMutationTrace);
        } finally {
            if(!pageWitnessPublished) pageWitness.close();
            for(List<AccessibilityNodeInfo> pending:pendingQueryGroups)
                for(AccessibilityNodeInfo node:pending)
                    if(node!=null) try {node.recycle();} catch(RuntimeException ignored) {}
            for(AccessibilityNodeInfo row:visibleAcceptRows) try {row.recycle();} catch(RuntimeException ignored) {}
            if(retryAction!=null) try {retryAction.recycle();} catch(RuntimeException ignored) {}
            if(root!=null) try {root.recycle();} catch(RuntimeException ignored) {}
        }
        }
    }

    private static boolean pageHasSeparateNumericRows(List<CardText.Piece> pieces) {
        // Ignore broad multi-card parents. Repeated fields within an overlapping parent/child
        // region are one row; disjoint mileage regions without an action boundary are ambiguous.
        float top=Float.NaN,bottom=Float.NaN;
        for (CardText.Piece p:pieces) {
            if (CardText.miles(p.text)<0 || CardText.containsMultipleMileageRows(p.text)) continue;
            if (Float.isNaN(top)) {top=p.top;bottom=p.bottom;continue;}
            if (p.top>bottom+2f || p.bottom<top-2f) return true;
            top=Math.min(top,p.top);bottom=Math.max(bottom,p.bottom);
        }
        return false;
    }

    public static long claimOutcomeEventEpoch() {
        return CLAIM_OUTCOME_EVENT_EPOCH.get();
    }

    /** Event-only outcome lookup used by Reject; tree scans cannot refresh an old toast. */
    public static String recentEventClaimOutcomeAfter(long baselineEpoch, long actionAt) {
        long now = SystemClock.elapsedRealtime();
        String hint = lastEventClaimOutcomeHint;
        return !hint.isEmpty() && OutcomeEventFence.accepts(lastEventClaimOutcomeEpoch,
                baselineEpoch, lastEventClaimOutcomeHintAt, actionAt, now, 5_000L) ? hint : "";
    }

    public static String recentAcceptTerminalOutcomeAfter(AcceptOutcomeFence fence) {
        AcceptOutcomeFence.Observation event = lastScopedTerminalEvent;
        return fence != null && fence.accepts(event, SystemClock.elapsedRealtime(), SystemClock.uptimeMillis())
                ? event.hint : "";
    }

    public static String recentAcceptOutcomeAfter(AcceptOutcomeFence fence) {
        String terminal = recentAcceptTerminalOutcomeAfter(fence);
        if (!terminal.isEmpty()) return terminal;
        AcceptOutcomeFence.Observation positive = lastScopedPositiveEvent;
        if (fence != null && fence.accepts(positive, SystemClock.elapsedRealtime(), SystemClock.uptimeMillis()))
            return positive.hint;
        AcceptOutcomeFence.Observation event = lastScopedClaimEvent;
        return fence != null && fence.accepts(event, SystemClock.elapsedRealtime(), SystemClock.uptimeMillis())
                ? event.hint : "";
    }

    public static String acceptOutcomeEventDiagnostic(AcceptOutcomeFence fence) {
        return fence == null ? "dispatchFence=NONE" : fence.timing(lastScopedTerminalEvent);
    }

    /** Cached authoritative server failure; isolated from later generic Job/detail UI events. */
    public static String recentTerminalNegativeClaimOutcomeSince(long sinceElapsed) {
        long now = SystemClock.elapsedRealtime();
        String cached = lastTerminalClaimOutcomeHint;
        return !cached.isEmpty()
                && lastTerminalClaimOutcomeHintAt >= Math.max(0L, sinceElapsed - 120L)
                && now >= lastTerminalClaimOutcomeHintAt
                && now - lastTerminalClaimOutcomeHintAt < 10_000L ? cached : "";
    }

    /** Cached only; no tree walk. Positive Job/Timeline evidence must match this Accept. */
    public static boolean recentAcceptedJobDetailMatches(String offerText, long sinceElapsed) {
        long now = SystemClock.elapsedRealtime();
        String raw = lastAcceptedJobDetailRaw;
        return !raw.isEmpty()
                && lastAcceptedJobDetailAt >= Math.max(0L, sinceElapsed - 120L)
                && now >= lastAcceptedJobDetailAt && now - lastAcceptedJobDetailAt <= 5_000L
                && ClaimSuccessSignals.acceptedJobMatchesOffer(offerText, raw);
    }

    public static int recentJobsBadgeCount() {
        long now = SystemClock.elapsedRealtime();
        return lastJobsBadgeAt > 0 && now >= lastJobsBadgeAt && now - lastJobsBadgeAt <= 5_000L
                ? lastJobsBadgeCount : -1;
    }

    public static boolean jobsBadgeIncreasedSince(int before) {
        return ClaimSuccessSignals.jobsBadgeIncreased(before, recentJobsBadgeCount());
    }

    public static String recentClaimOutcomeSince(long sinceElapsed) {
        long now = SystemClock.elapsedRealtime();
        String cached = recentCachedClaimOutcomeSince(sinceElapsed);
        if (!cached.isEmpty()) return cached;
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return "";
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return "";
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return "";
            StringBuilder text = new StringBuilder();
            int[] budget = new int[]{220};
            collectLimitedText(root, text, budget);
            String raw = text.toString();
            updateClaimUiCaches(raw);
            return extractClaimOutcomeHint(raw);
        } finally { root.recycle(); }
    }

    public static boolean isPositiveClaimOutcome(String hint) {
        return ClaimSuccessSignals.isPositive(hint);
    }

    /** Server-side terminal loss. Once seen, do not burn more local retries on that offer. */
    public static boolean isTerminalNegativeClaimOutcome(String hint) {
        return ClaimSuccessSignals.isTerminalNegative(hint);
    }

    /**
     * Positive confirmation only. A card disappearing from Offers is deliberately NOT
     * considered success because another driver/server refresh can remove it at the same time.
     */
    public static boolean hasAcceptSuccessEvidence() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return false;
            PageGuard.Page page = pageOf(root);
            if (page == PageGuard.Page.JOBS) return true;
            StringBuilder text = new StringBuilder();
            int[] budget = new int[]{180};
            collectLimitedText(root, text, budget);
            String raw = text.toString();
            updateClaimUiCaches(raw);
            String hint = ClaimSuccessSignals.extractOutcomeHint(raw);
            return ClaimSuccessSignals.isPositive(hint);
        } finally { root.recycle(); }
    }

    private static void collectLimitedText(AccessibilityNodeInfo node, StringBuilder out, int[] budget) {
        if (node == null || budget[0]-- <= 0) return;
        CharSequence text = node.getText(), desc = node.getContentDescription();
        if (text != null) out.append(text).append(' ');
        if (desc != null) out.append(desc).append(' ');
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectLimitedText(child, out, budget); }
                finally { child.recycle(); }
            }
        }
    }

    public static void tapSnapshotRetry(FastOfferSnapshot snapshot, float amount, float miles,
                                       Runnable completion, Consumer<String> mismatch) {
        tapSnapshotRetryDetailed(snapshot, amount, miles, 2,
                detail -> { if (completion != null) completion.run(); }, mismatch);
    }

    /** v2.10.11 retries use a newly refreshed top-card button, never the stale old coordinate. */
    private static String witnessReadFailure(List<WitnessNodeRead> jobs,String fallback) {
        for(int i=0;i<jobs.size();i++) {
            String failure=jobs.get(i).failure;
            if(!"OK".equals(failure)) return (i==0?"ACTION":"FIELD_"+i)+"_"+failure;
        }
        return fallback;
    }

    private static boolean canReuseRetryIndex(FastOfferSnapshot original,Rect bounds,long now) {
        IndexedReadProof proof=original.indexedRead;
        return proof!=null && original.acceptEnabled
                && IndexedReadPolicy.reuseBounds(proof.generation,UI_GENERATION.get(),original.capturedAt,now,
                        proof.windowEpoch==WINDOW_TRANSITION_EPOCH.get())
                && proof.verifiedAt>=proof.startedAt && proof.verifiedAt-proof.startedAt<=150L
                && proof.rootBounds.left==bounds.left && proof.rootBounds.top==bounds.top
                && proof.rootBounds.right==bounds.right && proof.rootBounds.bottom==bounds.bottom
                && IndexedWitnessPolicy.sameIdentity(original.text,original.text);
    }

    private static FastOfferSnapshot refreshRetryWitnessSnapshot(TapAccessibilityService service,
            FastOfferSnapshot original) {
        RETRY_WITNESS_FAILURE.set("NONE");
        RETRY_WITNESS_DETAIL.set("NONE");
        IndexedReadProof proof=original.indexedRead;
        if(proof==null || proof.witness==null) return null;
        long now=SystemClock.elapsedRealtime();
        if(proof.witness.closed || proof.witness.overflow || now<proof.witness.capturedAt
                || now-proof.witness.capturedAt>300L) {
            RETRY_WITNESS_FAILURE.set("UNAVAILABLE");return null;
        }
        long epoch=WINDOW_TRANSITION_EPOCH.get();
        AccessibilityNodeInfo root=null;
        try {
            if(proof.stages.startsWith("RETRY_CURRENT_INDEX_PAGE")
                    && proof.windowEpoch==epoch && now>=original.capturedAt
                    && now-original.capturedAt<=250L
                    && "com.deliverthat.driver".equals(foregroundPackage)) {
                FastOfferSnapshot rebound=proof.witness.refresh(original,proof.rootBounds,proof.windowId);
                RETRY_WITNESS_FAILURE.set(proof.witness.reason);
                RETRY_WITNESS_DETAIL.set(proof.witness.failureDetail);
                if(epoch!=WINDOW_TRANSITION_EPOCH.get()) {
                    RETRY_WITNESS_FAILURE.set("WINDOW_CHANGED");return null;
                }
                return rebound;
            }
            root=service.getRootInActiveWindow();
            if(root==null || !"com.deliverthat.driver".contentEquals(root.getPackageName()==null?"":root.getPackageName())) {
                RETRY_WITNESS_FAILURE.set("FOREIGN_OR_UNREADABLE_ROOT");return null;
            }
            int window=root.getWindowId();Rect bounds=new Rect();root.getBoundsInScreen(bounds);
            if(bounds.isEmpty() || window!=proof.windowId || epoch!=proof.windowEpoch) {
                RETRY_WITNESS_FAILURE.set("WINDOW_CHANGED");return null;
            }
            FastOfferSnapshot fresh=canReuseRetryIndex(original,bounds,SystemClock.elapsedRealtime())
                    ? proof.witness.refreshCurrentRetryAction(service,original,bounds,window)
                    : proof.witness.refresh(original,bounds,window);
            if(epoch!=WINDOW_TRANSITION_EPOCH.get()) {
                RETRY_WITNESS_FAILURE.set("WINDOW_CHANGED");return null;
            }
            RETRY_WITNESS_FAILURE.set(fresh==null?proof.witness.reason:"OK");
            if(fresh==null) RETRY_WITNESS_DETAIL.set(proof.witness.failureDetail);
            return fresh;
        } catch(RuntimeException failure) {
            RETRY_WITNESS_FAILURE.set("REFRESH_FAILED");
            RETRY_WITNESS_DETAIL.set("ROOT_EXCEPTION_"+failure.getClass().getSimpleName());return null;
        } finally {if(root!=null) root.recycle();}
    }

    /** v94 could recover a current action from the tree when RN's text index lagged.
     * Only missing index evidence enters this small rescue; identity/window conflicts do not. */
    private static FastOfferSnapshot readRetryQuickTreeSnapshot(TapAccessibilityService service,
            FastOfferSnapshot original,float amount,float miles,long actionAt,String indexFailure) {
        RETRY_TREE_FAILURE.set("NOT_USED");
        if(!"NO_ACCEPT".equals(indexFailure) && !"NUMERIC_MISSING".equals(indexFailure)
                && !"ACTION_INDEX_UNREADABLE".equals(indexFailure)) return null;
        long started=SystemClock.elapsedRealtime();
        long generation=UI_GENERATION.get(),epoch=WINDOW_TRANSITION_EPOCH.get();
        if(!OcrMonitorService.isMonitoring() || OcrMonitorService.isManualInterventionPaused()
                || !OcrMonitorService.acceptRetryGuard(actionAt).isEmpty()) {
            RETRY_TREE_FAILURE.set("TRANSACTION_BLOCKED");return null;
        }
        AccessibilityNodeInfo root=null;
        int window;
        Rect initialBounds=new Rect();
        try {
            root=service.getRootInActiveWindow();
            if(root==null || !"com.deliverthat.driver".contentEquals(root.getPackageName()==null?"":root.getPackageName())) {
                RETRY_TREE_FAILURE.set("FOREIGN_OR_UNREADABLE_ROOT");return null;
            }
            window=root.getWindowId();root.getBoundsInScreen(initialBounds);
            if(initialBounds.isEmpty() || (original.indexedRead!=null
                    && (window!=original.indexedRead.windowId || epoch!=original.indexedRead.windowEpoch))) {
                RETRY_TREE_FAILURE.set("WINDOW_CHANGED");return null;
            }
        } catch(RuntimeException stale) {
            RETRY_TREE_FAILURE.set("ROOT_EXCEPTION_"+stale.getClass().getSimpleName());return null;
        } finally {if(root!=null) root.recycle();}
        QuickTopResult tree;
        try {tree=getQuickTopOfferSnapshotResult(45L,96);}
        catch(RuntimeException stale) {
            RETRY_TREE_FAILURE.set("TREE_EXCEPTION_"+stale.getClass().getSimpleName());return null;
        }
        if(tree==null || tree.budgetExceeded || tree.snapshot==null) {
            RETRY_TREE_FAILURE.set(tree!=null&&tree.budgetExceeded?"BUDGET":"NO_CURRENT_CARD");return null;
        }
        FastOfferSnapshot current=tree.snapshot;
        if(generation!=UI_GENERATION.get() || epoch!=WINDOW_TRANSITION_EPOCH.get()) {
            RETRY_TREE_FAILURE.set("UI_CHANGED");return null;
        }
        if(!quickNumericPairMatches(current.text,amount,miles)
                || !IndexedWitnessPolicy.sameIdentity(original.text,current.text)
                || ClaimSuccessSignals.hasAcceptedJobDetail(current.text)) {
            RETRY_TREE_FAILURE.set("IDENTITY_CONFLICT");return null;
        }
        root=null;
        try {
            root=service.getRootInActiveWindow();Rect bounds=new Rect();
            if(root==null || !"com.deliverthat.driver".contentEquals(root.getPackageName()==null?"":root.getPackageName())) {
                RETRY_TREE_FAILURE.set("FOREGROUND_CHANGED");return null;
            }
            root.getBoundsInScreen(bounds);
            if(root.getWindowId()!=window || epoch!=WINDOW_TRANSITION_EPOCH.get()
                    || bounds.left!=initialBounds.left || bounds.top!=initialBounds.top
                    || bounds.right!=initialBounds.right || bounds.bottom!=initialBounds.bottom) {
                RETRY_TREE_FAILURE.set("WINDOW_CHANGED");return null;
            }
            if(generation!=UI_GENERATION.get()) {RETRY_TREE_FAILURE.set("UI_CHANGED");return null;}
            long now=SystemClock.elapsedRealtime();
            if(now<started || now-started>150L || !safeActionBounds(bounds,current.acceptBounds,true)) {
                RETRY_TREE_FAILURE.set("EXPIRED_OR_UNSAFE");return null;
            }
            if(!OcrMonitorService.isMonitoring() || OcrMonitorService.isManualInterventionPaused()
                    || OcrMonitorService.pendingClaimSince()!=actionAt
                    || !OcrMonitorService.acceptRetryGuard(actionAt).isEmpty()) {
                RETRY_TREE_FAILURE.set("TRANSACTION_BLOCKED");return null;
            }
            IndexedReadProof proof=new IndexedReadProof(bounds,window,generation,started,now,
                    "RETRY_QUICK_TREE;visited="+tree.visited+";read="+(now-started)+"ms");
            RETRY_TREE_FAILURE.set("OK");
            return new FastOfferSnapshot(current.text,current.acceptBounds,current.rejectBounds,
                    current.acceptEnabled,current.rejectEnabled,now,current.amount,current.miles,proof);
        } catch(RuntimeException stale) {
            RETRY_TREE_FAILURE.set("ROOT_EXCEPTION_"+stale.getClass().getSimpleName());return null;
        } finally {if(root!=null) root.recycle();}
    }

    private static void dispatchRetryFromCurrentProof(TapAccessibilityService service,FastOfferSnapshot current,
            boolean witnessVerified,int attempt,long actionAt,Consumer<String> completion,Consumer<String> mismatch) {
        IndexedReadProof proof=current.indexedRead;
        if(proof==null) {if(mismatch!=null) mismatch.accept("RETRY_NO_LIVE_PROOF");return;}
        Rect bounds=new Rect(proof.rootBounds);
        if(!witnessVerified && !"com.deliverthat.driver".equals(foregroundPackage)) {
            // Only query a root when the foreground cache itself cannot establish
            // DeliverThat. Normal same-owner retry submits the already bound CTA.
            AccessibilityNodeInfo root=service.getRootInActiveWindow();
            if(root==null) {if(mismatch!=null) mismatch.accept("RETRY_NO_CURRENT_ROOT");return;}
            try {
                if(!"com.deliverthat.driver".contentEquals(root.getPackageName()==null?"":root.getPackageName())
                        || root.getWindowId()!=proof.windowId) {
                    if(mismatch!=null) mismatch.accept("RETRY_FOREGROUND_CHANGED");return;
                }
                root.getBoundsInScreen(bounds);
            } finally {root.recycle();}
        }
        java.util.function.BooleanSupplier fresh=() -> INSTANCE.get()==service && OcrMonitorService.isMonitoring()
                && !OcrMonitorService.isManualInterventionPaused()
                && OcrMonitorService.pendingClaimSince()==actionAt
                && OcrMonitorService.acceptRetryGuard(actionAt).isEmpty()
                && "com.deliverthat.driver".equals(foregroundPackage)
                && !currentNegativeSurfaceBlocksAccept();
        if(!fresh.getAsBoolean()) {if(mismatch!=null) mismatch.accept("RETRY_LIVE_GATE_STOPPED");return;}
        String source=proof.stages.startsWith("RETRY_CURRENT_INDEX_PAGE")?"RETRY_PAGE_PROOF"
                :proof.stages.startsWith("RETRY_QUICK_TREE")?"RETRY_QUICK_TREE"
                :proof.stages.startsWith("RETRY_CURRENT_INDEX")?"RETRY_CURRENT_INDEX"
                :witnessVerified?"RETRY_LIVE_NODE":"RETRY_INDEX_FALLBACK";
        try {
            dispatchVerifiedSnapshotGesture(service,current.acceptBounds,bounds,true,
                    ActionDispatchPolicy.retryGestureDurationMs(attempt),ActionDispatchPolicy.retryVariant(attempt),
                    detail -> {if(completion!=null) completion.accept("重试#"+attempt+" "+source+" "+detail);},
                    mismatch,fresh);
        } finally {if(proof.witness!=null) proof.witness.close();}
    }

    private static void bindPressureGeometry(Rect bounds,Rect rootBounds) {
        FastOfferSnapshot admitted=OcrMonitorService.acceptPressureSnapshotForBinding();
        if(admitted==null) return;
        long at=SystemClock.elapsedRealtime();
        IndexedReadProof receipt=new IndexedReadProof(rootBounds,
                admitted.indexedRead==null?-1:admitted.indexedRead.windowId,
                UI_GENERATION.get(),at,at,"PRESSURE_ADMITTED_CTA");
        OcrMonitorService.bindAcceptPressureSnapshot(new FastOfferSnapshot(admitted.text,bounds,
                admitted.rejectBounds,true,false,at,admitted.amount,admitted.miles,receipt));
    }

    private static final AtomicReference<ResumeNodeReceipt> RESUME_NODES=new AtomicReference<>();
    private static final class ResumeNodeReceipt {
        final long owner;
        final FastOfferSnapshot original;
        final IndexedWitness nodes;
        ResumeNodeReceipt(long owner,FastOfferSnapshot original,IndexedWitness nodes) {
            this.owner=owner;this.original=original;this.nodes=nodes;
        }
    }
    private static void clearAcceptResumeNodes() {
        LAST_ACCEPT_PAGE.set(null);
        ResumeNodeReceipt old=RESUME_NODES.getAndSet(null);
        if(old!=null) old.nodes.close();
    }
    private static void rememberAcceptResumeNodes(FastOfferSnapshot snapshot,long owner) {
        if(owner<=0L || owner!=OcrMonitorService.pendingClaimSince() || snapshot==null
                || snapshot.indexedRead==null || snapshot.indexedRead.witness==null
                || snapshot.indexedRead.windowEpoch!=WINDOW_TRANSITION_EPOCH.get()
                || !IndexedWitnessPolicy.sameIdentity(snapshot.text,snapshot.text)) return;
        IndexedWitness copy=snapshot.indexedRead.witness.copyForOwner();
        if(copy==null) return;
        ResumeNodeReceipt receipt=new ResumeNodeReceipt(owner,snapshot,copy);
        ResumeNodeReceipt old=RESUME_NODES.getAndSet(receipt);
        if(old!=null) old.nodes.close();
        if(owner!=OcrMonitorService.pendingClaimSince() && RESUME_NODES.compareAndSet(receipt,null))copy.close();
    }
    /** Refresh owns independent node copies. Replacing the published receipt with another
     * receipt for this transaction must not invalidate a completed live read. Actual owner,
     * window, identity and root geometry changes still revoke it. */
    private static boolean ownedResumeReceiptCurrent(ResumeNodeReceipt reading,String expected) {
        return "CURRENT".equals(ownedResumeReceiptState(reading,expected));
    }
    private static String ownedResumeReceiptState(ResumeNodeReceipt reading,String expected) {
        ResumeNodeReceipt published=RESUME_NODES.get();
        if(reading==null)return "NO_READING";
        if(published==null)return "NO_PUBLISHED_RECEIPT";
        if(published.owner!=reading.owner || published.owner!=OcrMonitorService.pendingClaimSince())return "OWNER_CHANGED";
        if(reading.original.indexedRead==null || published.original.indexedRead==null)return "PROOF_MISSING";
        IndexedReadProof before=reading.original.indexedRead,after=published.original.indexedRead;
        if(before.windowEpoch!=WINDOW_TRANSITION_EPOCH.get() || after.windowEpoch!=before.windowEpoch)return "WINDOW_EPOCH_CHANGED";
        if(after.windowId!=before.windowId)return "WINDOW_CHANGED";
        if(before.rootBounds.left!=after.rootBounds.left || before.rootBounds.top!=after.rootBounds.top
                || before.rootBounds.right!=after.rootBounds.right || before.rootBounds.bottom!=after.rootBounds.bottom)return "ROOT_BOUNDS_CHANGED";
        if(!IndexedWitnessPolicy.sameIdentity(expected,reading.original.text))return "BASELINE_IDENTITY_CHANGED";
        if(!IndexedWitnessPolicy.sameIdentity(expected,published.original.text))return "PUBLISHED_IDENTITY_CHANGED";
        if(!IndexedWitnessPolicy.sameIdentity(reading.original.text,published.original.text)
                && !IndexedWitnessPolicy.sameIdentity(published.original.text,reading.original.text))return "KNOWN_FIELD_CONFLICT";
        return "CURRENT";
    }
    private static final ThreadLocal<String> OWNED_NODE_REFRESH_DETAIL=ThreadLocal.withInitial(() -> "NOT_READ");
    private static final ThreadLocal<Boolean> OWNED_NODE_PROCESSING=ThreadLocal.withInitial(() -> false);
    public static String ownedAcceptNodeRefreshDetail() {return OWNED_NODE_REFRESH_DETAIL.get();}
    public static boolean ownedAcceptNodeProcessingObserved() {return OWNED_NODE_PROCESSING.get();}
    /** Refresh handles, never old values: all selected identity fields and action are read live. */
    public static FastOfferSnapshot refreshCurrentOwnedAcceptNodes(String expected,long owner) {
        return refreshCurrentOwnedAcceptNodes(expected,owner,false);
    }

    /** Pressure renewal reads only the already-owned action/identity handles. The current
     * surface gate and transaction outcome still win; no seven-query page rediscovery. */
    private static FastOfferSnapshot refreshCurrentOwnedAcceptNodes(String expected,long owner,boolean pressureRenewal) {
        long started=SystemClock.elapsedRealtime();
        OWNED_NODE_REFRESH_DETAIL.set("NO_CURRENT_RECEIPT");OWNED_NODE_PROCESSING.set(false);
        ResumeNodeReceipt receipt=RESUME_NODES.get();
        TapAccessibilityService service=INSTANCE.get();
        long generation=UI_GENERATION.get(),epoch=WINDOW_TRANSITION_EPOCH.get();
        if(service==null || receipt==null || receipt.owner!=owner || owner<=0L
                || owner!=OcrMonitorService.pendingClaimSince() || !OcrMonitorService.isMonitoring()
                || OcrMonitorService.isManualInterventionPaused() || currentNegativeSurfaceBlocksAccept()
                || !OcrMonitorService.acceptRetryGuard(owner).isEmpty()
                || receipt.original.indexedRead.windowEpoch!=epoch
                || !IndexedWitnessPolicy.sameIdentity(expected,receipt.original.text)) return null;
        IndexedWitness work=receipt.nodes.copyForOwner();
        if(work==null) {OWNED_NODE_REFRESH_DETAIL.set("RECEIPT_NODES_UNAVAILABLE");return null;}
        AccessibilityNodeInfo root=null;
        try {
            OWNED_NODE_REFRESH_DETAIL.set("ROOT_OR_WINDOW_CHANGED");
            Rect bounds=new Rect(receipt.original.indexedRead.rootBounds);
            int liveWindow=receipt.original.indexedRead.windowId;
            if(!pressureRenewal) {
                root=readCurrentIndexedRoot(service,generation);
                if(root==null || !"com.deliverthat.driver".contentEquals(root.getPackageName()==null?"":root.getPackageName())
                        || root.getWindowId()!=liveWindow) return null;
                root.getBoundsInScreen(bounds);
            } else if(!"com.deliverthat.driver".equals(foregroundPackage)) return null;
            if(bounds.isEmpty() || WINDOW_TRANSITION_EPOCH.get()!=epoch)return null;
            if(UI_GENERATION.get()!=generation) {
                OWNED_NODE_REFRESH_DETAIL.set("UI_CHANGED:BEFORE_NODE_READ");return null;
            }
            long rootAt=SystemClock.elapsedRealtime();
            // Reject a dead/processing handle before paying for broad page queries. This is
            // observation only: no old field value or old rectangle gains click permission.
            FastOfferSnapshot current=work.refresh(receipt.original,bounds,liveWindow,true,pressureRenewal);
            long nodesAt=SystemClock.elapsedRealtime();
            OWNED_NODE_REFRESH_DETAIL.set(work.reason+":"+work.failureDetail
                    +";root="+(rootAt-started)+"ms,nodes="+(nodesAt-rootAt)+"ms");
            if(current==null) {
                boolean processing="REFRESH_FAILED".equals(work.reason)
                        && "ACTION_DISABLED".equals(work.failureDetail)
                        && UI_GENERATION.get()==generation && WINDOW_TRANSITION_EPOCH.get()==epoch
                        && ownedResumeReceiptCurrent(receipt,expected) && owner==OcrMonitorService.pendingClaimSince()
                        && OcrMonitorService.isMonitoring() && !OcrMonitorService.isManualInterventionPaused()
                        && OcrMonitorService.acceptRetryGuard(owner).isEmpty();
                OWNED_NODE_PROCESSING.set(processing);
                return null;
            }
            // Node identity alone cannot see a new toast outside the card. Keep the same
            // a/e negative vocabulary as first-shot indexing, without rediscovering pay/miles/rows.
            long negativeStart=SystemClock.elapsedRealtime();boolean negative=false;
            BoundedReadBatch.Result<IndexedQueryResult> guard=pressureRenewal?null:
                    readIndexedQueryPairOnBatch(service.ownedResumeReadBatch,root,"a","e",45L);
            try {
                if(guard!=null && !guard.complete()) {OWNED_NODE_REFRESH_DETAIL.set("NEGATIVE_QUERY_"+guard.reason);return null;}
                for(IndexedQueryResult result:guard==null?java.util.Collections.<IndexedQueryResult>emptyList():guard.values) {
                    List<AccessibilityNodeInfo> nodes=result.takeNodes();
                    try {
                        if(nodes==null)return null;
                        for(AccessibilityNodeInfo node:nodes) if(node!=null && node.isVisibleToUser()
                                && node.getWindowId()==root.getWindowId()
                                && !pageNegativeHint(String.valueOf(node.getText())+" "+node.getContentDescription()).isEmpty()) negative=true;
                    } finally {if(nodes!=null)for(AccessibilityNodeInfo node:nodes)if(node!=null)node.recycle();}
                }
            } finally {if(guard!=null)for(IndexedQueryResult result:guard.values)if(result!=null)result.close();}
            if(UI_GENERATION.get()!=generation || WINDOW_TRANSITION_EPOCH.get()!=epoch) {
                OWNED_NODE_REFRESH_DETAIL.set("CONTEXT_CHANGED_AFTER_NEGATIVE_READ");return null;
            }
            // A node-only renewal must never publish a fictitious clean page observation.
            if(!pressureRenewal)
                CURRENT_SURFACE_GATE.observe(epoch,negativeStart,SystemClock.elapsedRealtime(),true,negative,SystemClock.elapsedRealtime());
            if(negative || currentNegativeSurfaceBlocksAccept()) {OWNED_NODE_REFRESH_DETAIL.set("NEGATIVE_VISIBLE");return null;}
            ResumeNodeReceipt latest=RESUME_NODES.get();
            if(ownedResumeReceiptCurrent(receipt,expected) && latest!=null
                    && !IndexedWitnessPolicy.sameIdentity(latest.original.text,current.text)) {
                // New fields must be read live. Keep the existing pressure reservation while
                // the newer owned handles fill those fields; explicit conflicts still stop.
                OWNED_NODE_REFRESH_DETAIL.set(OfferEnrichmentPolicy.sameTransaction(current.text,latest.original.text)
                        ?"RECEIPT_ENRICHED_NEEDS_READ":"PUBLISHED_IDENTITY_CONFLICT");
                return null;
            }
            if(pressureRenewal && current!=null && UI_GENERATION.get()!=generation
                    && WINDOW_TRANSITION_EPOCH.get()==epoch && owner==OcrMonitorService.pendingClaimSince()
                    && ownedResumeReceiptCurrent(receipt,expected)) {
                OWNED_NODE_REFRESH_DETAIL.set("UI_CHANGED:FINAL_GUARD");return null;
            }
            if(current==null || !ownedResumeReceiptCurrent(receipt,expected) || owner!=OcrMonitorService.pendingClaimSince()
                    || !OcrMonitorService.isMonitoring() || OcrMonitorService.isManualInterventionPaused()
                    || UI_GENERATION.get()!=generation || WINDOW_TRANSITION_EPOCH.get()!=epoch
                    || currentNegativeSurfaceBlocksAccept() || !OcrMonitorService.acceptRetryGuard(owner).isEmpty()
                    || !IndexedWitnessPolicy.sameIdentity(expected,current.text)) {
                OWNED_NODE_REFRESH_DETAIL.set("FINAL_CONTEXT_CHANGED;receipt="+ownedResumeReceiptCurrent(receipt,expected)
                        +";receiptReason="+ownedResumeReceiptState(receipt,expected)
                        +";generation="+(UI_GENERATION.get()==generation)+";window="+(WINDOW_TRANSITION_EPOCH.get()==epoch)
                        +";owner="+(owner==OcrMonitorService.pendingClaimSince()));
                return null;
            }
            OWNED_NODE_REFRESH_DETAIL.set("OK;root="+(rootAt-started)+"ms,rootMode="+(pressureRenewal?"WINDOW_RECEIPT":"LIVE")
                    +",nodes="+(nodesAt-rootAt)+"ms,finalGuards="+(SystemClock.elapsedRealtime()-nodesAt)+"ms;"
                    +current.indexedRead.formattedStages());
            return current;
        } catch(RuntimeException stale) {
            OWNED_NODE_REFRESH_DETAIL.set("EXCEPTION_"+stale.getClass().getSimpleName());return null;
        }
        finally {work.close();if(root!=null)root.recycle();}
    }

    /** Resume authority is a current same-card enabled CTA, never the original pressure rect. */
    public static boolean isCurrentPressureResumeSnapshot(FastOfferSnapshot snapshot,String expected,long owner) {
        return pressureResumeProofBlock(snapshot,expected,owner).isEmpty();
    }

    static String pressureResumeProofBlock(FastOfferSnapshot snapshot,String expected,long owner) {
        if(snapshot==null || snapshot.indexedRead==null) return "NO_CURRENT_PROOF";
        if(!snapshot.acceptEnabled || snapshot.acceptBounds.isEmpty()) return "CONTROL_NOT_ENABLED";
        if(owner<=0L || owner!=OcrMonitorService.pendingClaimSince()) return "OWNER_CHANGED";
        IndexedReadProof proof=snapshot.indexedRead;
        if(proof.windowEpoch!=WINDOW_TRANSITION_EPOCH.get()) return "WINDOW_CHANGED";
        if(proof.generation!=UI_GENERATION.get()) return "UI_GENERATION_CHANGED";
        long age=SystemClock.elapsedRealtime()-snapshot.capturedAt;
        if(age<0L || age>250L) return "PROOF_EXPIRED";
        if(!safeActionBounds(proof.rootBounds,snapshot.acceptBounds,true)) return "CONTROL_GEOMETRY_CHANGED";
        if(!"com.deliverthat.driver".equals(foregroundPackage)) return "FOREGROUND_CHANGED";
        if(!IndexedWitnessPolicy.sameIdentity(expected,snapshot.text)) return "IDENTITY_MISMATCH";
        return OcrMonitorService.acceptRetryGuard(owner);
    }

    /** Continuous pressure retry at the admitted CTA. The unchanged path is cache-only;
     * layout churn renews owned live nodes inside the existing reservation before dispatch.
     * Terminal, foreground, spinner and owner checks still run at the final send fence. */
    private static String pressureStopReason(TapAccessibilityService service,FastOfferSnapshot snapshot,long owner) {
        if(service==null || INSTANCE.get()!=service) return "SERVICE_CHANGED";
        if(snapshot==null || snapshot.indexedRead==null) return "NO_RECEIPT";
        if(!OcrMonitorService.isMonitoring()) return "MONITOR_STOPPED";
        if(OcrMonitorService.isManualInterventionPaused()) return "MANUAL_PAUSE";
        if(!"com.deliverthat.driver".equals(foregroundPackage)) return "FOREIGN_APP";
        IndexedReadProof proof=snapshot.indexedRead;
        // UI/window epochs are not a reason to block an already admitted cached CTA.
        // React-Native can update them several times before Android dispatchGesture.
        String guard=OcrMonitorService.acceptPressureGuard(owner);
        if(!guard.isEmpty()) return guard;
        if(!OcrMonitorService.acceptPressureActive(owner)) return "PRESSURE_INACTIVE_OR_SPINNER";
        return "";
    }

    private static boolean samePressureGeometry(FastOfferSnapshot before,FastOfferSnapshot after) {
        return before!=null && after!=null && before.indexedRead!=null && after.indexedRead!=null
                && before.indexedRead.windowId==after.indexedRead.windowId
                && before.indexedRead.windowEpoch==after.indexedRead.windowEpoch
                && before.indexedRead.rootBounds.left==after.indexedRead.rootBounds.left
                && before.indexedRead.rootBounds.top==after.indexedRead.rootBounds.top
                && before.indexedRead.rootBounds.right==after.indexedRead.rootBounds.right
                && before.indexedRead.rootBounds.bottom==after.indexedRead.rootBounds.bottom
                && before.acceptBounds.left==after.acceptBounds.left
                && before.acceptBounds.top==after.acceptBounds.top
                && before.acceptBounds.right==after.acceptBounds.right
                && before.acceptBounds.bottom==after.acceptBounds.bottom
                && IndexedWitnessPolicy.sameIdentity(before.text,after.text);
    }

    /** Reuse a proof already published for THIS live layout, rather than reading the
     * same handles again. No root/node queries and no age/layout/negative gate bypass. */
    private static FastOfferSnapshot currentPressureRenewalSnapshot(FastOfferSnapshot before,long owner) {
        ResumeNodeReceipt nodes=RESUME_NODES.get();
        FastOfferSnapshot shared=OcrMonitorService.acceptPressureSnapshotForBinding();
        FastOfferSnapshot published=nodes!=null && nodes.owner==owner?nodes.original:null;
        for(int i=0;i<2;i++) {
            FastOfferSnapshot candidate=i==0?shared:published;
            if(candidate!=null && candidate!=before && samePressureGeometry(before,candidate)
                    && isCurrentPressureResumeSnapshot(candidate,before.text,owner)
                    && pressureStopReason(INSTANCE.get(),candidate,owner).isEmpty()) return candidate;
        }
        return null;
    }

    public static void tapPressureRetry(FastOfferSnapshot snapshot,long owner,int attempt,
            Consumer<String> completed,Consumer<String> failed) {
        tapPressureRetryPrepared(snapshot,owner,attempt,completed,failed,0,"");
    }

    private static void renewPressureRetry(FastOfferSnapshot snapshot,long owner,int attempt,
            Consumer<String> completed,Consumer<String> failed,int renewals,String previousTrace) {
        Handler proof=OcrMonitorService.acceptRenewalHandler(),clicks=OcrMonitorService.acceptCallbackHandler();
        if(proof==null || clicks==null) {if(failed!=null)failed.accept("PRESSURE_STOPPED:NO_RENEWAL_WORKER");return;}
        FastOfferSnapshot published=currentPressureRenewalSnapshot(snapshot,owner);
        if(published!=null) {
            OcrMonitorService.bindAcceptPressureSnapshot(published);
            tapPressureRetryPrepared(published,owner,attempt,completed,failed,renewals,
                    previousTrace+";CURRENT_LAYOUT_PROOF_REUSED=1");return;
        }
        final long queuedAt=SystemClock.elapsedRealtime();
        proof.postAtFrontOfQueue(() -> {
            long enteredAt=SystemClock.elapsedRealtime();
            FastOfferSnapshot newer=currentPressureRenewalSnapshot(snapshot,owner);
            if(newer!=null) {
                clicks.postAtFrontOfQueue(() -> {
                    String gate=pressureStopReason(INSTANCE.get(),newer,owner);
                    if(!gate.isEmpty() && !"LAYOUT_CHANGED".equals(gate)) {
                        if(failed!=null)failed.accept("PRESSURE_STOPPED:"+gate+previousTrace);return;
                    }
                    if(!isCurrentPressureResumeSnapshot(newer,snapshot.text,owner)) {
                        renewPressureRetry(snapshot,owner,attempt,completed,failed,renewals,previousTrace);return;
                    }
                    OcrMonitorService.bindAcceptPressureSnapshot(newer);
                    tapPressureRetryPrepared(newer,owner,attempt,completed,failed,renewals,
                            previousTrace+";CURRENT_LAYOUT_PROOF_REUSED=1");
                });return;
            }
            TapAccessibilityService service=INSTANCE.get();
            String stop=pressureStopReason(service,snapshot,owner);
            if(!stop.isEmpty() && !"LAYOUT_CHANGED".equals(stop)) {
                clicks.postAtFrontOfQueue(() -> {if(failed!=null)failed.accept("PRESSURE_STOPPED:"+stop);});return;
            }
            FastOfferSnapshot current=refreshCurrentOwnedAcceptNodes(snapshot.text,owner,true);
            long finishedAt=SystemClock.elapsedRealtime();
            final String refreshDetail=ownedAcceptNodeRefreshDetail();
            final boolean retryCurrentRead=current==null && ("RECEIPT_ENRICHED_NEEDS_READ".equals(refreshDetail)
                    || refreshDetail.startsWith("UI_CHANGED:")
                    || "CONTEXT_CHANGED_AFTER_NEGATIVE_READ".equals(refreshDetail));
            String detail=previousTrace+";renewal="+(renewals+1)+",queue="+(enteredAt-queuedAt)
                    +"ms,read="+(finishedAt-enteredAt)+"ms,"+refreshDetail;
            final String trace=detail.length()>1400?detail.substring(detail.length()-1400):detail;
            clicks.postAtFrontOfQueue(() -> {
                String guard=pressureStopReason(INSTANCE.get(),current==null?snapshot:current,owner);
                if(retryCurrentRead && (guard.isEmpty() || "LAYOUT_CHANGED".equals(guard))) {
                    FastOfferSnapshot ready=currentPressureRenewalSnapshot(snapshot,owner);
                    if(ready!=null) {
                        OcrMonitorService.bindAcceptPressureSnapshot(ready);
                        tapPressureRetryPrepared(ready,owner,attempt,completed,failed,renewals+1,
                                trace+";CURRENT_LAYOUT_PROOF_REUSED=1");
                    } else if("RECEIPT_ENRICHED_NEEDS_READ".equals(refreshDetail)) {
                        renewPressureRetry(snapshot,owner,attempt,completed,failed,renewals+1,trace);
                    } else if(failed!=null) {
                        failed.accept("PRESSURE_STOPPED:LAYOUT_RENEWAL_YIELD"+trace);
                    }
                    return;
                }
                if(current==null || !samePressureGeometry(snapshot,current)
                        || (!guard.isEmpty() && !"LAYOUT_CHANGED".equals(guard))) {
                    if(failed!=null)failed.accept("PRESSURE_STOPPED:"+(guard.isEmpty()?"NO_CURRENT_NODE_PROOF":guard)+trace);return;
                }
                OcrMonitorService.bindAcceptPressureSnapshot(current);
                tapPressureRetryPrepared(current,owner,attempt,completed,failed,renewals+1,trace);
            });
        });
    }

    private static void tapPressureRetryPrepared(FastOfferSnapshot snapshot,long owner,int attempt,
            Consumer<String> completed,Consumer<String> failed,int renewals,String trace) {
        TapAccessibilityService service=INSTANCE.get();
        String stop=pressureStopReason(service,snapshot,owner);
        if("LAYOUT_CHANGED".equals(stop)) {renewPressureRetry(snapshot,owner,attempt,completed,failed,renewals,trace);return;}
        if(!stop.isEmpty()) {if(failed!=null)failed.accept("PRESSURE_STOPPED:"+stop+trace);return;}
        java.util.function.BooleanSupplier ready=() -> pressureStopReason(service,snapshot,owner).isEmpty();
        Consumer<String> stopped=reason -> {
            String currentStop=pressureStopReason(service,snapshot,owner);
            if("LAYOUT_CHANGED".equals(currentStop) && reason.startsWith("RETRY_PROOF_EXPIRED")) {
                renewPressureRetry(snapshot,owner,attempt,completed,failed,renewals,trace);return;
            }
            if(failed!=null)failed.accept("PRESSURE_STOPPED:"+(currentStop.isEmpty()?reason:currentStop)+trace
                    +";uiGen="+UI_GENERATION.get()+";layout="+PRESSURE_LAYOUT_EPOCH.get()
                    +";windowEpoch="+WINDOW_TRANSITION_EPOCH.get()+";event="+lastUiMutationTrace);
        };
        dispatchVerifiedSnapshotGesture(service,snapshot.acceptBounds,snapshot.indexedRead.rootBounds,true,12L,
                ActionDispatchPolicy.retryVariant(attempt),
                detail -> {if(completed!=null)completed.accept("重试#"+attempt+" PRESSURE_CACHED_CTA "+detail
                        +(renewals>0?"；ASYNC_LAYOUT_RENEWED="+renewals:"")+trace);},stopped,ready);
    }

    public static void tapSnapshotRetryDetailed(FastOfferSnapshot snapshot, float amount, float miles,
                                                 int attempt, Consumer<String> completion,
                                                 Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || snapshot == null) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "Accept重试快照为空");
            return;
        }
        final long expectedActionAt=OcrMonitorService.pendingClaimSince();
        // Same urgent worker as first dispatch; Android callbacks still use service.main.
        {
            String retryGuard=OcrMonitorService.acceptRetryGuard(expectedActionAt);
            if (!retryGuard.isEmpty()) { if (mismatch!=null) mismatch.accept(retryGuard); return; }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消Accept重试");
                return;
            }
            long pendingSince = OcrMonitorService.pendingClaimSince();
            if (pendingSince > 0 && OcrMonitorService.hasBoundAcceptSuccess()) {
                if (mismatch != null) mismatch.accept("已出现接单成功状态；取消Accept重试");
                return;
            }
            clearPageRetryReceipt(expectedActionAt);
            // Speed-first: keep the existing verified target while the same owner is active.
            // Do not make a fresh tree/Binder proof a prerequisite for dispatching a retry.
            if (snapshot.indexedRead != null && !snapshot.acceptBounds.isEmpty()
                    && quickNumericPairMatches(snapshot.text,amount,miles)
                    && "com.deliverthat.driver".equals(foregroundPackage)
                    && OcrMonitorService.pendingClaimSince()==expectedActionAt
                    && !OcrMonitorService.isManualInterventionPaused()) {
                dispatchRetryFromCurrentProof(service,snapshot,true,attempt,expectedActionAt,completion,mismatch);
                return;
            }
            if(freshPageRetrySnapshot(snapshot,expectedActionAt)) {
                if(!quickNumericPairMatches(snapshot.text,amount,miles)) {
                    if(mismatch!=null) mismatch.accept("RETRY_PAGE_NUMERIC_CONFLICT");return;
                }
                dispatchRetryFromCurrentProof(service,snapshot,true,attempt,expectedActionAt,completion,mismatch);
                return;
            }
            FastOfferSnapshot current=refreshRetryWitnessSnapshot(service,snapshot);
            boolean witnessVerified=current!=null;
            String witnessReason=retryWitnessFailure();
            RETRY_TREE_FAILURE.set("NOT_USED");
            if(current==null && snapshot.indexedRead!=null
                    && snapshot.indexedRead.stages.startsWith("RETRY_CURRENT_INDEX_PAGE")) {
                // A detached witness can be replaced once by a bounded live same-card read.
                // Other witness failures (including page/window changes) await fresh evidence.
                if ("REFRESH_FAILED".equals(witnessReason))
                    current=readRetryQuickTreeSnapshot(service,snapshot,amount,miles,
                            expectedActionAt,"NO_ACCEPT");
                if(current==null) {
                    if(mismatch!=null) mismatch.accept("RETRY_PAGE_REPROBE_REQUIRED：页面证明已变化；节点复核="
                            +witnessReason+"/"+RETRY_WITNESS_DETAIL.get()
                            +"；有界复核="+RETRY_TREE_FAILURE.get()+"；等待下一份当前证明");
                    return;
                }
            }
            if(current==null && hardRetryWitnessFailure(witnessReason)) {
                if(mismatch!=null) mismatch.accept("RETRY_NODE_NO_PROOF："+witnessReason+"/"+RETRY_WITNESS_DETAIL.get()+"；保留原事务，等待新鲜复核");return;
            }
            if(current==null) current=readIndexedCurrentTopAcceptSnapshot(
                    0f,Float.MAX_VALUE,false,true,LIVE_OFFER_TIME.matcher(snapshot.text).find(),false);
            String indexFailure=acceptIndexFailure();
            if(current==null) current=readRetryQuickTreeSnapshot(service,snapshot,amount,miles,
                    expectedActionAt,indexFailure);
            if(current==null || current.acceptBounds.isEmpty()) {
                if(mismatch!=null) mismatch.accept("RETRY_INDEX_NO_PROOF：原因="+indexFailure
                        +"；节点复核="+witnessReason+"/"+RETRY_WITNESS_DETAIL.get()
                        +"；有界页面复核="+RETRY_TREE_FAILURE.get()+"；未点击，不转完整树");return;
            }
            if (!quickNumericPairMatches(current.text, amount, miles)
                    || !OfferEnrichmentPolicy.sameTransaction(snapshot.text, current.text)
                    || ClaimSuccessSignals.hasAcceptedJobDetail(current.text)) {
                if (mismatch != null) mismatch.accept("RETRY_IDENTITY_CHANGED：当前订单身份不一致或已进入订单详情；未点击");
                return;
            }
            if (!current.acceptEnabled) {
                if (mismatch != null) mismatch.accept("Accept重试时按钮已禁用/处理中；不重复点击");
                return;
            }
            if (current.liveReadGeneration()<0) {
                if (mismatch != null) mismatch.accept("RETRY_NO_CURRENT_CONTROL：缺少已定位按钮");
                return;
            }
            retryGuard=OcrMonitorService.acceptRetryGuard(expectedActionAt);
            if (!retryGuard.isEmpty()) { if (mismatch!=null) mismatch.accept(retryGuard); return; }
            dispatchRetryFromCurrentProof(service,current,witnessVerified,attempt,expectedActionAt,completion,mismatch);
        }
    }

    public static void tapVisualSnapshotRetryDetailed(FastOfferSnapshot snapshot,long frameAt,long generation,
            long actionAt,int attempt,Consumer<String> completion,Consumer<String> mismatch) {
        clearPageRetryReceipt(actionAt);
        TapAccessibilityService service=INSTANCE.get();
        if(service==null || snapshot==null || attempt<2 || attempt>3) {
            if(mismatch!=null) mismatch.accept("RETRY_VISUAL_UNAVAILABLE：服务/快照/重试次数无效");return;
        }
        java.util.function.BooleanSupplier fresh=() -> OcrMonitorService.isMonitoring()
                && OcrMonitorService.pendingClaimSince()==actionAt
                && OcrMonitorService.acceptRetryGuard(actionAt).isEmpty()
                && !OcrMonitorService.isManualInterventionPaused()
                && "com.deliverthat.driver".equals(foregroundPackage)
                && !currentNegativeSurfaceBlocksAccept();
        if(!fresh.getAsBoolean()) {if(mismatch!=null) mismatch.accept("RETRY_VISUAL_PROOF_EXPIRED");return;}
        // SPEED-FIRST visual continuation: the owner, Accept rectangle and numeric pair
        // were admitted upstream. Avoid a semantic node read PLUS a second numeric Binder
        // sweep before every touch; terminal/foreground gates still run at dispatch time.
        if(snapshot.acceptBounds.isEmpty()) {
            if(mismatch!=null) mismatch.accept("RETRY_VISUAL_NO_CTA_RECT");
            return;
        }
        dispatchActionGesture(service,snapshot.acceptBounds,true,ActionDispatchPolicy.retryGestureDurationMs(attempt),
                ActionDispatchPolicy.retryVariant(attempt),
                detail -> {if(completion!=null) completion.accept("重试#"+attempt+" VISUAL_RETRY_TWO_FRAME "+detail);},
                mismatch,fresh);
    }

    public static void tapIfOfferStillMatches(float x, float y, float amount, float miles,
                                               Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, x, y, amount, miles, null, completion, mismatch);
    }

    /**
     * Fresh screen-evidence fallback. Accessibility remains the preferred action path,
     * but DeliverThat builds exist where the visible button is not exported as an
     * actionable node. In that case a fresh OCR/visual coordinate may dispatch a gesture
     * after foreground/page checks. This is used for BOTH Accept and Reject in v2.9.3.
     */
    /**
     * v2.10.28 blank-label first-shot lane. Decision fields come from a same-generation
     * Accessibility event/card ancestor while the button rectangle comes from the just-captured
     * screen. The UI generation is rechecked immediately before Gesture55ms, so a stale card can
     * never borrow a newer blue rectangle (or vice versa).
     */
    /** One live/current top-card read on a UI-generation change; never reuse stale coordinates. */
    private static final class VisualGenerationRebound {
        final Rect bounds;
        final long generation;
        VisualGenerationRebound(Rect bounds, long generation) {
            this.bounds = new Rect(bounds);
            this.generation = generation;
        }
    }

    private static VisualGenerationRebound tryVisualGenerationRebound(
            Rect previousBounds, String expectedText, float amount, float miles,
            long frameAt) {
        long now = SystemClock.elapsedRealtime();
        if (now < frameAt || now - frameAt > VisualGenerationReboundPolicy.MAX_FRAME_AGE_MS
                || !isDeliverThatForeground() || !OcrMonitorService.isMonitoring()) return null;
        PageGuard.Page page = recentPageHint();
        if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) return null;
        long generation = UI_GENERATION.get();
        FastOfferSnapshot live = getIndexedNumericTopAcceptSnapshot(amount, miles);
        // Restart once on publication churn before spending time on wider fallback reads.
        // The restarted read must independently prove the same enabled top offer.
        if (UI_GENERATION.get() != generation) {
            long restartAt = SystemClock.elapsedRealtime();
            if (restartAt - now > 80L
                    || restartAt - frameAt > VisualGenerationReboundPolicy.MAX_FRAME_AGE_MS
                    || !isDeliverThatForeground() || !OcrMonitorService.isMonitoring()) return null;
            generation = UI_GENERATION.get();
            live = getIndexedNumericTopAcceptSnapshot(amount, miles);
            if (UI_GENERATION.get() != generation) return null;
        } else {
            if (live == null || live.acceptBounds.isEmpty() || !live.acceptEnabled)
                live = getIndexedTopAcceptSnapshot(false, false);
            if (UI_GENERATION.get() != generation) return null;
            if (live == null || live.acceptBounds.isEmpty() || !live.acceptEnabled)
                live = getQuickTopOfferSnapshotResult(45L, 96).snapshot;
        }
        if (live == null || live.acceptBounds.isEmpty() || !live.acceptEnabled
                || UI_GENERATION.get() != generation
                || ClaimSuccessSignals.hasAcceptedJobDetail(live.text)) return null;
        if (!VisualGenerationReboundPolicy.canRebind(
                expectedText, live.text, amount, miles,
                previousBounds.left, previousBounds.top, previousBounds.right, previousBounds.bottom,
                live.acceptBounds.left, live.acceptBounds.top,
                live.acceptBounds.right, live.acceptBounds.bottom,
                SystemClock.elapsedRealtime() - frameAt)) return null;
        return new VisualGenerationRebound(live.acceptBounds, generation);
    }

    public static void tapVisualAccessibilityOffer(Rect acceptBounds, float amount, float miles,
                                                    String expectedText,
                                                    long evidenceAt, long expectedUiGeneration,
                                                    Consumer<String> completion,
                                                    Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || acceptBounds == null || acceptBounds.isEmpty()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "视觉Accept热区不可用");
            return;
        }
        final Rect expected = new Rect(acceptBounds);
        // v2.10.117: the just-captured frame is already on the dedicated display-priority
        // screen lane. Do not enqueue the first claim behind React-Native Accessibility events;
        // verify package, page generation and right-button geometry here, then let
        // dispatchGesture deliver its callback on service.main.
        {
            long now = SystemClock.elapsedRealtime();
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消视觉首击");
                return;
            }
            if (!ScanPolicy.actionFresh(now, evidenceAt)) {
                if (mismatch != null) mismatch.accept("视觉首击证据过旧"
                        + ScanPolicy.actionAge(now, evidenceAt) + "ms；等待新帧");
                return;
            }
            Rect liveAccept = new Rect(expected);
            long boundGeneration = expectedUiGeneration;
            String reboundTrace = "";
            final long rootStartedAt=SystemClock.elapsedRealtime();
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            final long rootFinishedAt=SystemClock.elapsedRealtime();
            // Explicit non-offer page hints block. Current visual/numeric evidence shares the
            // frame generation; on churn a fresh live Accept must re-prove the same top below.
            PageGuard.Page page = recentPageHint();
            // Current-frame numeric evidence + visual CTA share this generation. On churn,
            // the live enabled Accept and exact pair below independently re-prove the row.
            // A blind chrome-prefix walk adds no stronger same-card proof here.
            final long topRowStartedAt=SystemClock.elapsedRealtime();
            boolean topRowCurrent = noHigherIndexedOfferAction(root, rootBounds, liveAccept.top);
            root.recycle();
            final long topRowFinishedAt=SystemClock.elapsedRealtime();
            if (!topRowCurrent) {
                if (mismatch != null) mismatch.accept("HIGHER_OFFER_ACTION：上方订单仍在；取消视觉首击");
                return;
            }
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) {
                if (mismatch != null) mismatch.accept("页面为" + page + "；取消视觉首击");
                return;
            }
            if (UI_GENERATION.get() != boundGeneration) {
                // Root/page reads precede one exact same-card rebind. Never repeat a generic
                // tree rebuild before and after those reads in the same first attempt.
                long reboundAt = SystemClock.elapsedRealtime();
                VisualGenerationRebound rebound = tryVisualGenerationRebound(
                        liveAccept, expectedText, amount, miles, evidenceAt);
                if (rebound == null) {
                    if (mismatch != null) mismatch.accept("手势前界面变更且同卡核验失败；取消视觉首击");
                    return;
                }
                boundGeneration = rebound.generation;
                liveAccept.set(rebound.bounds);
                reboundTrace = " VISUAL_GENERATION_REBOUND "
                        + expectedUiGeneration + "→" + boundGeneration
                        + "；当前数值/Accept复核=" + (SystemClock.elapsedRealtime() - reboundAt) + "ms";
            }
            if (UI_GENERATION.get() != boundGeneration || !safeActionBounds(rootBounds, liveAccept, true)) {
                if (mismatch != null) mismatch.accept("视觉Accept热区几何异常；取消首击");
                return;
            }
            // v2.10.55: root/package/page/generation/geometry were just verified above.
            // Re-opening the Accessibility root inside dispatchActionGesture duplicated
            // foreground/page checks on the latency-critical claim path. Dispatch against
            // the already verified rootBounds instead; all stale-generation and geometry
            // guards remain in force.
            if (UI_GENERATION.get() != boundGeneration) {
                if (mismatch != null) mismatch.accept("Gesture派发前界面再次变化；不点击");
                return;
            }
            String cardGuard = OcrMonitorService.firstAcceptCardGuard(expectedText);
            if (!cardGuard.isEmpty()) {
                if (mismatch != null) mismatch.accept(cardGuard + "；取消视觉首击");
                return;
            }
            final String reboundDetail = reboundTrace;
            final long boundGenerationForTap = boundGeneration;
            final long verifyFinishedAt=SystemClock.elapsedRealtime();
            dispatchVerifiedSnapshotGesture(service, liveAccept, rootBounds, true,
                    ActionDispatchPolicy.firstGestureDurationMs(true), 0, true,
                    detail -> {
                        if (completion != null)
                            completion.accept("来源=Accessibility字段+视觉Accept FAST_DISPATCH "
                                    + detail + reboundDetail
                                    + "；VISUAL_VERIFY_START_ELAPSED=" + now
                                    + "；VISUAL_VERIFY_END_ELAPSED=" + verifyFinishedAt
                                    + "；视觉首击核验=" + (verifyFinishedAt-now) + "ms"
                                    + "；窗口读取=" + (rootFinishedAt-rootStartedAt) + "ms"
                                    + "；顶部订单核验=" + (topRowFinishedAt-topRowStartedAt) + "ms");
                    }, mismatch, () -> UI_GENERATION.get() == boundGenerationForTap
                            && !currentNegativeSurfaceBlocksAccept());
        }
    }

    public static void tapOcrOffer(float x, float y, float amount, float miles, long evidenceAt,
                                   Runnable completion, Consumer<String> mismatch) {
        tapFreshOcrAction(true, x, y, amount, miles, evidenceAt, completion, mismatch);
    }

    public static void tapOcrReject(float x, float y, float amount, float miles, long evidenceAt,
                                    Runnable completion, Consumer<String> mismatch) {
        tapFreshOcrAction(false, x, y, amount, miles, evidenceAt, completion, mismatch);
    }

    /** v2.10.17 OCR Reject path with a full verified action rectangle and order identity. */
    public static void tapOcrReject(Rect rejectBounds, float amount, float miles, long evidenceAt,
                                    String expectedText, Consumer<String> completion,
                                    Consumer<String> mismatch) {
        tapOcrReject(rejectBounds, amount, miles, evidenceAt, expectedText,
                completion, mismatch, null);
    }

    public static void tapOcrReject(Rect rejectBounds, float amount, float miles, long evidenceAt,
                                    String expectedText, Consumer<String> completion,
                                    Consumer<String> mismatch,
                                    java.util.function.BooleanSupplier mayDispatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || rejectBounds == null || rejectBounds.isEmpty()
                || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "Reject热区不可用或DeliverThat不在前台");
            return;
        }
        final Rect expected = new Rect(rejectBounds);
        service.main.post(() -> {
            if (mayDispatch != null && !mayDispatch.getAsBoolean()) {
                if (mismatch != null) mismatch.accept("新合格订单优先；旧OCR Reject已取消");
                return;
            }
            long now = SystemClock.elapsedRealtime();
            long age = ScanPolicy.actionAge(now, evidenceAt);
            if (!ScanPolicy.actionFresh(now, evidenceAt)) {
                if (mismatch != null) mismatch.accept("OCR/视觉Reject证据过旧" + age + "ms；等待新帧");
                return;
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消OCR Reject");
                return;
            }
            dispatchRejectHybrid(service, amount, miles, expected, expectedText, true, completion, mismatch);
        });
    }

    private static void tapFreshOcrAction(boolean accept, float x, float y, float amount, float miles,
                                          long evidenceAt, Runnable completion,
                                          Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "DeliverThat不在前台或无法读取窗口");
            return;
        }
        final long queuedAt = SystemClock.elapsedRealtime();
        final long acceptActionAt=accept?OcrMonitorService.pendingClaimSince():0L;
        Runnable action = () -> {
            long now = SystemClock.elapsedRealtime();
            long age = ScanPolicy.actionAge(now, evidenceAt);
            if (!ScanPolicy.actionFresh(now, evidenceAt)) {
                if (mismatch != null) mismatch.accept("OCR/视觉证据过旧" + age + "ms；等待新帧");
                return;
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消屏幕坐标点击");
                return;
            }
            if (accept) {
                String guard=OcrMonitorService.ocrAcceptDispatchGuard(acceptActionAt,amount,miles);
                if(!guard.isEmpty()) {if(mismatch!=null) mismatch.accept(guard);return;}
            }
            // Fast foreground verification only. Do not rescan every Accessibility window here:
            // on the user's Galaxy A15 that second tree walk alone can consume 400-800 ms and
            // was the direct cause of both v2.10 timeout errors.
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            float localX = x - rootBounds.left;
            float localY = y - rootBounds.top;
            boolean sideOk = accept ? ActionGeometry.plausibleRightAction(rootBounds.width(), localX)
                    : ActionGeometry.plausibleLeftAction(rootBounds.width(), localX);
            if (rootBounds.isEmpty() || !rootBounds.contains(Math.round(x), Math.round(y))
                    || !sideOk || !ActionGeometry.plausibleActionY(rootBounds.height(), localY)) {
                root.recycle();
                if (mismatch != null) mismatch.accept("目标坐标不在安全" + (accept ? "Accept" : "Reject")
                        + "按钮区域；取消点击");
                return;
            }

            // Use the recent full-scan hint first, then a bounded active-root probe. UNKNOWN is
            // intentionally allowed because the OCR frame already has money+miles+action-row
            // evidence; only a positive JOBS/IGNORED result blocks the gesture.
            PageGuard.Page recent = recentPageHint();
            PageGuard.Page quickPage = recent == PageGuard.Page.OFFERS
                    ? PageGuard.Page.OFFERS : quickPageOf(root, accept ? 16 : 24);
            PageGuard.Page page = quickPage != PageGuard.Page.UNKNOWN ? quickPage : recent;

            // v2.10.39: React-Native can briefly leave the Ignored tab marked selected while
            // a real Offers card is already visible.  The short 16-node probe can encounter
            // that stale selected bit before it reaches the card's Accept/Reject semantics,
            // causing a valid high-value offer to be vetoed.  Only on this exact conflict,
            // perform one wider bounded probe.  If that probe finds current offer/action
            // evidence, quickPageOf() downgrades the stale Ignored bit to UNKNOWN/OFFERS;
            // a real Ignored page still blocks because Restore remains hard evidence.
            if (page == PageGuard.Page.IGNORED && accept) {
                PageGuard.Page conflictProbe = quickPageOf(root, 96);
                if (conflictProbe == PageGuard.Page.OFFERS
                        || conflictProbe == PageGuard.Page.UNKNOWN) {
                    page = conflictProbe;
                }
            }
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) {
                root.recycle();
                if (mismatch != null) mismatch.accept("页面为" + page + "；禁止屏幕坐标点击");
                return;
            }
            long rowProofGeneration = UI_GENERATION.get();
            if (accept && !noHigherIndexedOfferAction(root, rootBounds, y)) {
                root.recycle();
                if (mismatch != null) mismatch.accept("HIGHER_OFFER_ACTION：上方订单仍在；取消OCR Accept");
                return;
            }
            root.recycle();

            long beforeGesture = SystemClock.elapsedRealtime();
            long finalAge = ScanPolicy.actionAge(beforeGesture, evidenceAt);
            if (!ScanPolicy.actionFresh(beforeGesture, evidenceAt)) {
                if (mismatch != null) mismatch.accept("坐标核验后证据过旧" + finalAge + "ms；等待新帧");
                return;
            }
            float gestureX = rootBounds.left + ActionGeometry.stableTapX(
                    rootBounds.width(), x - rootBounds.left, accept);
            Path path = new Path();
            path.moveTo(gestureX, y);
            long gestureDuration = ActionDispatchPolicy.firstGestureDurationMs(accept);
            GestureDescription gesture = buildSingleTap(path, gestureDuration);
            if (accept) {
                if (UI_GENERATION.get() != rowProofGeneration) {
                    if (mismatch != null) mismatch.accept("TOP_ROW_PROOF_STALE：核验后页面变化；取消OCR Accept");
                    return;
                }
                String guard=OcrMonitorService.ocrAcceptDispatchGuard(acceptActionAt,amount,miles);
                if(!guard.isEmpty()) {if(mismatch!=null) mismatch.accept(guard);return;}
                FastOfferSnapshot admitted=OcrMonitorService.acceptPressureSnapshotForBinding();
                if(admitted!=null) bindPressureGeometry(admitted.acceptBounds,rootBounds);
                OcrMonitorService.noteAcceptGestureDispatchStarted();
            }
        boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (completion != null) completion.run();
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    if (mismatch != null) mismatch.accept("系统取消了"
                            + (accept ? "Accept坐标点击手势" : "Reject坐标点击手势"));
                }
            }, accept && OcrMonitorService.isMonitoring() && OcrMonitorService.acceptCallbackHandler()!=null
                    ? OcrMonitorService.acceptCallbackHandler() : service.main);
            if (dispatched && accept) OcrMonitorService.noteAcceptGestureDispatched();
            if (!dispatched && mismatch != null) mismatch.accept("系统未接受"
                    + (accept ? "Accept" : "Reject") + "坐标点击手势");
        };
        if(accept && OcrMonitorService.isMonitoring() && OcrMonitorService.acceptCallbackHandler()!=null)
            OcrMonitorService.acceptCallbackHandler().postAtFrontOfQueue(action);
        else if (accept && OcrMonitorService.isMonitoring() && service.directWorker != null)
            service.directWorker.postAtFrontOfQueue(action);
        else if (accept) service.main.postAtFrontOfQueue(action);
        else service.main.post(action);
    }

    /**
     * Bounded page probe for the time-critical coordinate path. It examines at most
     * maxNodes nodes from the active root and returns only strong page evidence.
     */
    private static PageGuard.Page quickPageOf(AccessibilityNodeInfo root, int maxNodes) {
        return quickPageOf(root, maxNodes, PageGuard.Page.UNKNOWN);
    }

    private static PageGuard.Page quickPageOf(AccessibilityNodeInfo root, int maxNodes,
                                              PageGuard.Page emptyHubTab) {
        if (root == null || maxNodes <= 0) return PageGuard.Page.UNKNOWN;
        boolean[] flags = new boolean[11];
        int[] budget = new int[]{maxNodes};
        collectQuickPageFlags(root, flags, budget);
        int jobMeta = (flags[8] ? 1 : 0) + (flags[9] ? 1 : 0) + (flags[10] ? 1 : 0);
        if (flags[7] && jobMeta >= 2) {
            updatePageHint(PageGuard.Page.JOBS);
            return PageGuard.Page.JOBS;
        }
        PageGuard.Page page = PageGuard.classify(flags[0], flags[1], flags[2],
                flags[3], flags[4], flags[5], flags[6]);
        // v2.10.19: do not let a conflicting stale selected-tab bit veto a structurally
        // verified top offer.  UNKNOWN is intentional here: callers still have to prove
        // money+miles+button geometry before any action is allowed.
        if (page == PageGuard.Page.UNKNOWN) page = emptyHubTab;
        boolean conflictingOfferEvidence = !flags[3] && (flags[2] || flags[4] || flags[5]);
        if ((page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED)
                && conflictingOfferEvidence) page = PageGuard.Page.UNKNOWN;
        if (page != PageGuard.Page.UNKNOWN) updatePageHint(page);
        return page;
    }

    private static void collectQuickPageFlags(AccessibilityNodeInfo node, boolean[] flags, int[] budget) {
        if (node == null || budget[0]-- <= 0) return;
        CharSequence text = node.getText(), desc = node.getContentDescription();
        for (CharSequence value : new CharSequence[]{text, desc}) {
            if (value == null) continue;
            String label = lettersOnlyLower(value);
            if (node.isSelected() || node.isChecked()) {
                if (label.equals("ignored")) flags[0] = true;
                if (label.equals("jobs")) flags[1] = true;
                if (label.equals("offers") || label.startsWith("offers")) flags[2] = true;
            }
            String lower = value.toString().toLowerCase(Locale.US);
            if (lower.contains("pickup instructions") || lower.contains("dropoff instructions")
                    || lower.contains("delivery instructions")) flags[7] = true;
            if (lower.contains("approver name")) flags[8] = true;
            if (lower.contains("nuid")) flags[9] = true;
            if (lower.contains("gl string")) flags[10] = true;
            if (label.equals("restore") || label.equals("restorebutton")) flags[3] = true;
            if (ButtonLabels.isReject(value)) flags[4] = true;
            if (matchesAccept(value)) flags[5] = true;
            if (EmptyOffersPolicy.isExplicitEmpty(value.toString())) flags[6] = true;
        }
        // v2.10.19: keep scanning the bounded prefix even if a selected Jobs/Ignored bit
        // appears. React-Native can leave that bit stale while the visible Offers card and
        // its action row are already current.
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectQuickPageFlags(child, flags, budget); }
                finally { child.recycle(); }
            }
        }
    }

    public static void tapSnapshot(FastOfferSnapshot snapshot, float amount, float miles,
                                   Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, snapshot.acceptBounds.exactCenterX(), snapshot.acceptBounds.exactCenterY(),
                amount, miles, snapshot.text, completion, mismatch);
    }

    public static void ignoreIfOfferStillMatches(float x, float y, float amount, float miles, String expectedText,
                                               Runnable completion, Consumer<String> mismatch) {
        tapVerified(false, x, y, amount, miles, expectedText, completion, mismatch);
    }

    private static void tapVerified(boolean accept, float x, float y, float amount, float miles, String expectedText,
                                    Runnable completion, Consumer<String> mismatch) {
        tapVerified(accept, x, y, amount, miles, expectedText, false, true, completion, mismatch);
    }

    private static void tapVerified(boolean accept, float x, float y, float amount, float miles,
                                    String expectedText, boolean gestureOnly, boolean requireMonitoring,
                                    Runnable completion, Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null ? "辅助点击服务未连接" : "DeliverThat不在前台或无法读取窗口");
            return;
        }
        final long queuedAt = android.os.SystemClock.elapsedRealtime();
        Runnable verifiedAction = () -> {
            long queueMs = android.os.SystemClock.elapsedRealtime() - queuedAt;
            if (!ScanPolicy.fresh(android.os.SystemClock.elapsedRealtime(), queuedAt)) {
                if (mismatch != null) mismatch.accept("点击排队超时" + queueMs + "ms；取消旧判断，等待重新识别");
                return;
            }
            if (OcrMonitorService.isManualInterventionPaused()) {
                if (mismatch != null) mismatch.accept("人工介入中；已取消排队点击");
                return;
            }
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (requireMonitoring && !OcrMonitorService.isMonitoring()) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("监控已停止；已取消排队点击");
                return;
            }
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            PageGuard.Page page = pageOf(root);
            if (page == PageGuard.Page.UNKNOWN) page = activePage();
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED
                    || (page == PageGuard.Page.UNKNOWN && expectedText == null)) {
                root.recycle();
                if (mismatch != null) mismatch.accept("页面为" + page + "；当前证据不足，未点击");
                return;
            }

            // v2.10.8: reject a coordinate before touching the tree if it is not in the
            // expected left/right action column. This is the final barrier against an offer
            // card/detail container being mistaken for Ignore/Accept.
            float localX = x - rootBounds.left;
            float localY = y - rootBounds.top;
            boolean sideOk = accept ? ActionGeometry.plausibleRightAction(rootBounds.width(), localX)
                    : ActionGeometry.plausibleLeftAction(rootBounds.width(), localX);
            if (rootBounds.isEmpty() || !sideOk
                    || !ActionGeometry.plausibleActionY(rootBounds.height(), localY)) {
                root.recycle();
                if (mismatch != null) mismatch.accept("动作坐标不在安全按钮区域；疑似整卡/详情容器，已禁止点击");
                return;
            }

            AccessibilityNodeInfo button = findActionNode(root, accept, x, y);
            Rect liveBounds = new Rect();
            if (button != null) {
                button.getBoundsInScreen(liveBounds);
                if (!safeActionBounds(rootBounds, liveBounds, accept)) {
                    // Never keep a semantic fallback whose bounds are a whole card/container.
                    button.recycle();
                    button = null;
                    liveBounds.setEmpty();
                }
            }
            if (button == null) {
                // The coordinate came from a verified OCR/Accessibility label. Build only a
                // tiny local evidence box; do not substitute a large clickable ancestor.
                int halfW = 26, halfH = 16;
                liveBounds.set(Math.round(x) - halfW, Math.round(y) - halfH,
                        Math.round(x) + halfW, Math.round(y) + halfH);
            }

            String liveText = cardText(root, liveBounds).toLowerCase(Locale.US).replace(',', '.');
            if (expectedText != null && !CardText.sameOfferForAction(expectedText.replace(',', '.'), liveText)) {
                if (button != null) button.recycle();
                root.recycle();
                if (mismatch != null) mismatch.accept("目标卡片稳定内容已变化；本次未点击");
                return;
            }
            if (!NumericGuard.containsExpected(liveText, LIVE_MONEY, amount, 0.011f)
                    || !NumericGuard.containsExpected(liveText, LIVE_MILES, miles, 0.051f)) {
                if (button != null) button.recycle();
                root.recycle();
                if (mismatch != null) mismatch.accept("目标卡片金额/里程未能一致核对；未点击");
                return;
            }
            if (!ScanPolicy.fresh(android.os.SystemClock.elapsedRealtime(), queuedAt)) {
                if (button != null) button.recycle();
                root.recycle();
                if (mismatch != null) mismatch.accept("本次核验超过1秒；取消旧点击，重新读取");
                return;
            }

            final AccessibilityNodeInfo semanticFallback = button == null ? null
                    : AccessibilityNodeInfo.obtain(button);
            if (button != null) button.recycle();
            root.recycle();

            float gestureX = rootBounds.left + ActionGeometry.stableTapX(
                    rootBounds.width(), x - rootBounds.left, accept);
            float gestureY = y;
            if (!rootBounds.contains(Math.round(gestureX), Math.round(gestureY))) {
                if (semanticFallback != null) semanticFallback.recycle();
                if (mismatch != null) mismatch.accept("动作中心已离开DeliverThat窗口；取消点击");
                return;
            }
            Path path = new Path();
            path.moveTo(gestureX, gestureY);
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, ActionDispatchPolicy.firstGestureDurationMs(accept)))
                    .build();
            if (accept) OcrMonitorService.noteAcceptGestureDispatchStarted();
        boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (semanticFallback != null) semanticFallback.recycle();
                    if (completion != null) completion.run();
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    boolean clicked = false;
                    if (semanticFallback != null) {
                        try {
                            clicked = !gestureOnly && performClickNodeOrParentSafe(
                                    semanticFallback, accept, rootBounds);
                        } finally { semanticFallback.recycle(); }
                    }
                    if (clicked) {
                        if (completion != null) completion.run();
                    } else if (mismatch != null) mismatch.accept("系统取消了坐标手势，安全语义点击也未执行");
                }
            }, accept && OcrMonitorService.isMonitoring() && OcrMonitorService.acceptCallbackHandler()!=null
                    ? OcrMonitorService.acceptCallbackHandler() : service.main);
            if (dispatched && accept) OcrMonitorService.noteAcceptGestureDispatched();
            if (!dispatched) {
                boolean clicked = false;
                if (semanticFallback != null) {
                    try {
                        clicked = !gestureOnly && performClickNodeOrParentSafe(
                                semanticFallback, accept, rootBounds);
                    } finally { semanticFallback.recycle(); }
                }
                if (clicked) {
                    if (completion != null) completion.run();
                } else if (mismatch != null) mismatch.accept("系统未接受坐标手势，安全语义点击也未执行");
            }
        };
        // Accept is a race against the server and other drivers. Put only the already-verified
        // Accept transaction at the front of the main looper; Reject stays FIFO so it can never
        // preempt a newly arrived claim. All live page/card/numeric guards above remain intact.
        if (accept) service.main.postAtFrontOfQueue(verifiedAction);
        else service.main.post(verifiedAction);
    }

    private static AccessibilityNodeInfo findSemanticActionNode(AccessibilityNodeInfo node,
                                                                  boolean accept, float x, float y) {
        NodeCandidate best = new NodeCandidate();
        findActionCandidate(node, accept, x, y, best);
        return best.node;
    }

    private static AccessibilityNodeInfo findActionNode(AccessibilityNodeInfo node, boolean accept, float x, float y) {
        NodeCandidate best = new NodeCandidate();
        findActionCandidate(node, accept, x, y, best);
        if (best.node != null) return best.node;
        // If the label is blank, resolve the freshly read clickable node by the structural
        // coordinate obtained from the same Accessibility tree snapshot.
        findStructuralActionCandidate(node, x, y, best);
        return best.node;
    }

    private static final class NodeCandidate {
        AccessibilityNodeInfo node;
        float score = Float.MAX_VALUE;
    }

    private static void findActionCandidate(AccessibilityNodeInfo node, boolean accept, float x, float y, NodeCandidate best) {
        if (node == null) return;
        CharSequence label = node.getText();
        CharSequence description = node.getContentDescription();
        boolean matches = accept ? (matchesAccept(label) || matchesAccept(description))
                : (ButtonLabels.isReject(label) || ButtonLabels.isReject(description));
        if (matches) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (!bounds.isEmpty()) {
                float dy = Math.abs(bounds.exactCenterY() - y);
                float dx = Math.abs(bounds.exactCenterX() - x);
                float yTolerance = Math.max(90f, bounds.height() * 2.25f);
                float xTolerance = Math.max(140f, bounds.width() * 1.25f);
                if ((bounds.contains(Math.round(x), Math.round(y)) || (dy <= yTolerance && dx <= xTolerance))) {
                    float score = dy + dx * 0.25f;
                    if (score < best.score) {
                        if (best.node != null) best.node.recycle();
                        best.node = AccessibilityNodeInfo.obtain(node);
                        best.score = score;
                    }
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { findActionCandidate(child, accept, x, y, best); }
                finally { child.recycle(); }
            }
        }
    }

    private static void findStructuralActionCandidate(AccessibilityNodeInfo node, float x, float y, NodeCandidate best) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean actionable = node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0
                || (node.getClassName() != null
                    && node.getClassName().toString().toLowerCase(Locale.US).contains("button"));
        boolean infoTrigger = LargeOrderPopupGuard.isInfoTriggerLabel(node.getText())
                || LargeOrderPopupGuard.isInfoTriggerLabel(node.getContentDescription());
        if (actionable && !infoTrigger && actionNodeReady(node) && !bounds.isEmpty()) {
            float dy = Math.abs(bounds.exactCenterY() - y);
            float dx = Math.abs(bounds.exactCenterX() - x);
            float yTolerance = Math.max(48f, bounds.height() * 1.35f);
            float xTolerance = Math.max(80f, bounds.width() * 0.75f);
            if (bounds.contains(Math.round(x), Math.round(y)) || (dy <= yTolerance && dx <= xTolerance)) {
                float areaPenalty = Math.min(250f, (bounds.width() * bounds.height()) / 12000f);
                float score = dy + dx * 0.35f + areaPenalty;
                if (score < best.score) {
                    if (best.node != null) best.node.recycle();
                    best.node = AccessibilityNodeInfo.obtain(node);
                    best.score = score;
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { findStructuralActionCandidate(child, x, y, best); }
                finally { child.recycle(); }
            }
        }
    }

    private static boolean actionNodeReady(AccessibilityNodeInfo node) {
        if (node == null) return false;
        // Most DeliverThat action nodes are directly clickable. Avoid an obtain()+parent walk
        // in the overwhelmingly common case; only a text-label child needs ancestor probing.
        if (node.isEnabled() && nodeIsActionable(node)) return true;
        AccessibilityNodeInfo current = node.getParent();
        try {
            for (int depth = 0; depth < 5 && current != null; depth++) {
                if (current.isEnabled() && nodeIsActionable(current)) return true;
                if (depth == 4) break;
                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }
            return false;
        } finally {
            if (current != null) current.recycle();
        }
    }

    private static boolean nodeIsActionable(AccessibilityNodeInfo node) {
        if (node == null) return false;
        if (node.isClickable() || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0)
            return true;
        CharSequence cls = node.getClassName();
        return cls != null && cls.toString().toLowerCase(Locale.US).contains("button");
    }

    private static boolean performClickNodeOrParentSafe(AccessibilityNodeInfo node,
                                                        boolean accept, Rect rootBounds) {
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(node);
        try {
            for (int depth = 0; depth < 6 && current != null; depth++) {
                boolean actionable = current.isClickable()
                        || (current.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0;
                Rect bounds = new Rect();
                current.getBoundsInScreen(bounds);
                // Critical v2.10.8 invariant: climbing parents may never cross into the
                // whole offer card. Stop using an ancestor as soon as its geometry is no
                // longer a real left/right action button.
                if (current.isEnabled() && actionable
                        && safeActionBounds(rootBounds, bounds, accept)
                        && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }
            return false;
        } finally {
            if (current != null) current.recycle();
        }
    }

    private static boolean performAcceptAction(AccessibilityNodeInfo node) {
        if (node == null) return false;
        String label = "";
        if (node.getText() != null) label += node.getText().toString();
        if (node.getContentDescription() != null) label += " " + node.getContentDescription();
        String normalized = lettersOnlyLower(label);
        if (isAcceptLabel(normalized)) {
            AccessibilityNodeInfo target = node;
            AccessibilityNodeInfo ownedParent = null;
            for (int depth = 0; depth < 3 && target != null; depth++) {
                if (target.isClickable()
                        && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    if (ownedParent != null) ownedParent.recycle();
                    return true;
                }
                AccessibilityNodeInfo parent = target.getParent();
                if (ownedParent != null) ownedParent.recycle();
                ownedParent = parent;
                target = parent;
            }
            if (ownedParent != null) ownedParent.recycle();
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean clicked = performAcceptAction(child);
                child.recycle();
                if (clicked) return true;
            }
        }
        return false;
    }

    private static boolean isAcceptLabel(String normalized) {
        if (normalized == null) return false;
        switch (normalized) {
            case "accept": case "claim":
            case "acceptbutton": case "buttonaccept":
            case "claimbutton": case "buttonclaim":
            case "acceptoffer": case "claimoffer":
            case "acceptdelivery": case "claimdelivery":
            case "acceptjob": case "claimjob":
            case "acceptorder": case "claimorder":
            case "acceptrequest": case "claimrequest":
                return true;
            default:
                return false;
        }
    }

    private static String collectText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder out = new StringBuilder();
        if (node.getText() != null) out.append(node.getText()).append(' ');
        if (node.getContentDescription() != null) out.append(node.getContentDescription()).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                out.append(collectText(child));
                child.recycle();
            }
        }
        return out.toString();
    }

}
