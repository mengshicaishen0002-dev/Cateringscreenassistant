package com.local.cateringscreenassistant;

/** Small, read-only post-Accept visual lane; never changes first-shot capture. */
final class ClaimVisualProbePolicy {
    private ClaimVisualProbePolicy() { }
    static boolean due(boolean context, boolean busy, long now, long last) {
        return context && !busy && (last <= 0L || now - last >= 500L);
    }
    static int top() { return 0; }
    static int headerBottom(int height) { return Math.max(2, Math.round(height * 0.20f)); }
    // A clear page tree cannot exclude a toast which is absent from Accessibility.
    // Only after dispatch and observed loading: no work is added before the first tap.
    static boolean headerDue(boolean context, boolean dispatched, boolean loading,
                             boolean busy, long now, long last) {
        return dispatched && loading && due(context, busy, now, last);
    }

    /** Two fresh OCR frames after an observed clear header, scoped to this dispatch/window. */
    static final class NegativeProof {
        private long action, epoch=-1, clear=-1, first=-1, last=-1;
        private String candidate="", confirmed="";
        synchronized boolean observe(long owner, long dispatch, long windowEpoch,
                                     long frame, long now, String hint) {
            if(owner<=0 || dispatch<owner || frame<dispatch || now<frame || now-frame>750L) return false;
            if(action!=owner || epoch!=windowEpoch) {
                action=owner;epoch=windowEpoch;clear=first=last=-1;candidate="";confirmed="";
            }
            if(frame<=last) return false;
            last=frame;
            if(hint.isEmpty()) {clear=frame;first=-1;candidate="";confirmed="";return false;}
            if(clear<dispatch || frame<=clear) return false;
            if(!candidate.equals(hint) || first<0 || frame-first>1500L) {
                candidate=hint;first=frame;return false;
            }
            if(frame-first<60L) return false;
            confirmed=hint;return true;
        }
        synchronized String read(long owner, long windowEpoch, long now) {
            return action==owner && epoch==windowEpoch && last>=0 && now>=last
                    && now-last<=2500L ? confirmed : "";
        }
    }
    static int bottom(int height) { return Math.round(height * 0.90f); }
    static boolean fresh(long now, long frameAt, long frameGeneration, long generation, boolean foreground) {
        return foreground && frameAt > 0L && now >= frameAt && now - frameAt <= 750L
                && frameGeneration == generation;
    }
}
