package com.local.cateringscreenassistant;

/**
 * Adaptive scheduling for the first seconds of a newly-exported offer.  Idle scans stay cheap,
 * but a numeric offer burst gets a short race window and may not be starved forever by a stream
 * of incomplete React-Native accessibility events.
 */
final class HotOfferScanPolicy {
    private static final long HOT_EVIDENCE_MS = 2500L;
    private static final long HOT_HEARTBEAT_MS = 12L;
    private static final long EVENT_YIELD_MAX_MS = 32L;
    // A fresh numeric Accessibility burst means a new offer is being exported. During this
    // short window a screen frame may cheaply locate the filled-blue Accept rectangle even
    // when the normal OCR scheduler is still suppressed by the previous readable card.
    private static final long VISUAL_PROBE_WINDOW_MS = 900L;
    // v2.10.95: ImageReader commonly delivers one frame every ~16ms.  A 24ms gate skipped
    // every other useful frame on the Galaxy A15 and could miss the first tappable stage of
    // DeliverThat's Accept fade-in.  This path runs only inside the bounded 900ms numeric burst
    // and performs no OCR/tree walk, so one probe per display frame is the right race profile.
    private static final long VISUAL_PROBE_GAP_MS = 12L;

    static long heartbeatDelay(boolean hot) {
        return HOT_HEARTBEAT_MS;
    }

    static long standaloneHeartbeatDelay(boolean hot) {
        return HOT_HEARTBEAT_MS;
    }

    static boolean evidenceHot(long evidenceAgeMs) {
        return evidenceAgeMs >= 0L && evidenceAgeMs <= HOT_EVIDENCE_MS;
    }

    static boolean shouldYieldToNewEvent(boolean dirty, long numericBurstAgeMs) {
        return dirty && (numericBurstAgeMs < 0L || numericBurstAgeMs < EVENT_YIELD_MAX_MS);
    }

    static long eventYieldMaxMs() { return EVENT_YIELD_MAX_MS; }

    static boolean shouldProbeVisual(long numericBurstAgeMs, long sinceLastProbeMs,
                                     boolean busy, boolean actionBlocked) {
        // Raw Image-plane visual probes neither reuse the OCR bitmap nor start OCR.
        // An in-flight recognition task must not hide a newly visible Accept button.
        return !actionBlocked
                && numericBurstAgeMs >= 0L && numericBurstAgeMs <= VISUAL_PROBE_WINDOW_MS
                && sinceLastProbeMs >= VISUAL_PROBE_GAP_MS;
    }

    static long visualProbeWindowMs() { return VISUAL_PROBE_WINDOW_MS; }

    /**
     * A screen frame may be captured between two React-Native accessibility generations.
     * For an offer that already passes the General numeric rule, a very recent nearby-generation
     * numeric event plus the CURRENT filled-blue Accept rectangle is enough to avoid starting a
     * 200-500ms OCR/tree fallback. The caller still owns foreground/page/geometry/tombstone and
     * transaction checks; this policy only bounds evidence freshness.
     */
    static boolean recentVisualNumericEvidence(long ageMs, long generationDelta,
                                               boolean numericallyUniversal,
                                               boolean acceptedJobDetail) {
        return numericallyUniversal && !acceptedJobDetail
                && ageMs >= 0L && ageMs <= 160L
                && generationDelta >= 0L && generationDelta <= 3L;
    }

    private HotOfferScanPolicy() { }
}
