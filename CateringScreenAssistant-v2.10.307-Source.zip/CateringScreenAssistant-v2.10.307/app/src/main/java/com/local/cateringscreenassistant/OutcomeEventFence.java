package com.local.cateringscreenassistant;

/** Bind a server/UI outcome to events that appeared after one specific action transaction. */
final class OutcomeEventFence {
    static boolean accepts(long observedEpoch, long baselineEpoch,
                           long observedAt, long actionAt, long now, long maxAgeMs) {
        return observedEpoch > baselineEpoch
                && observedAt >= actionAt
                && now >= observedAt
                && now - observedAt <= Math.max(1L, maxAgeMs);
    }

    private OutcomeEventFence() { }
}
