package com.local.cateringscreenassistant;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** User-initiated handoff from an Accept-result alarm to manual DeliverThat control. */
public final class ClaimInterventionActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        ClaimSuccessAlert.stop(this);
        // Confirmed alarms no longer pre-pause because Back -> Offers must run automatically.
        // Tapping the notification is the explicit handoff, so create and confirm the pause now.
        OcrMonitorService.pauseForManualIntervention(this);
        OcrMonitorService.confirmManualIntervention(this);

        Intent deliverThat = getPackageManager()
                .getLaunchIntentForPackage("com.deliverthat.driver");
        if (deliverThat != null) {
            deliverThat.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(deliverThat);
        } else {
            startActivity(new Intent(this, MainActivity.class));
        }
        finish();
    }
}
