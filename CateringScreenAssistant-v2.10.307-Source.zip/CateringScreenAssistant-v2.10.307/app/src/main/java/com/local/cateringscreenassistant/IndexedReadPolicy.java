package com.local.cateringscreenassistant;

/** A short current-window receipt can replace a redundant root Binder read. */
final class IndexedReadPolicy {
    static boolean reuseBounds(long proofGeneration, long currentGeneration,
                               long proofAt, long now, boolean sameWindow) {
        return sameWindow && proofGeneration == currentGeneration
                && proofAt > 0L && now >= proofAt && now - proofAt <= 80L;
    }
    static boolean reuseWindow(long proofEpoch, long currentEpoch, long proofAt, long now,
                               boolean foregroundKnown, boolean hasWitness) {
        return foregroundKnown && hasWitness && proofEpoch == currentEpoch
                && proofAt > 0L && now >= proofAt && now - proofAt <= 80L;
    }
    private IndexedReadPolicy() { }
}
