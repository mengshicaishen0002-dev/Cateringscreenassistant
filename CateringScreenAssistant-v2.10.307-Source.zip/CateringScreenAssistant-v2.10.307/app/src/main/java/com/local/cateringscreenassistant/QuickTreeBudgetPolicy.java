package com.local.cateringscreenassistant;

/**
 * v2.10.35 latency guard for the bounded Accessibility quick-tree pass.
 *
 * The quick tree is a fallback after semantic action indexing. On Samsung/React-Native
 * frames a single traversal can occasionally stretch from the normal 20-80 ms range into
 * several hundred milliseconds. Once the fallback exceeds this soft budget it is cheaper
 * and safer to yield to the already-running OCR path than to continue into a full-tree scan.
 */
final class QuickTreeBudgetPolicy {
    private static final int MAX_NODES = 128;
    private static final long SOFT_BUDGET_MS = 80L;
    private static final long OCR_BACKOFF_MS = 120L;
    private static final long SCAN_BUDGET_MS = 125L;
    static final long MIN_TREE_SLICE_MS = 12L;
    static final long QUICK_RESERVE_MS = 25L;

    static long remainingScanMs(long startedAt, long now, long stageCap, long reserve) {
        return Math.max(0L, Math.min(stageCap, SCAN_BUDGET_MS - Math.max(0L, now - startedAt) - reserve));
    }

    // Indexed first-shot paths keep their original budgets. Only the chained fallback
    // shares this smaller total soft budget; the next event/normal OCR stays eligible.
    static long remainingFallbackMs(long startedAt,long now,long stageCap,long reserve) {
        return Math.max(0L,Math.min(stageCap,80L-Math.max(0L,now-startedAt)-reserve));
    }

    static int maxNodes() { return MAX_NODES; }
    static long softBudgetMs() { return SOFT_BUDGET_MS; }
    static long ocrBackoffMs() { return OCR_BACKOFF_MS; }

    static boolean elapsedBudgetExceeded(long startedAt, long now) {
        return startedAt > 0L && now >= startedAt && now - startedAt >= SOFT_BUDGET_MS;
    }

    static boolean shouldYieldToOcr(boolean budgetExceeded, boolean decisionReady) {
        return budgetExceeded && !decisionReady;
    }

    private QuickTreeBudgetPolicy() { }
}
