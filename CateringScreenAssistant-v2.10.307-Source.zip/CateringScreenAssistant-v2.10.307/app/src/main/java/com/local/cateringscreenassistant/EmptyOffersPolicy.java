package com.local.cateringscreenassistant;

import java.util.Locale;

/** Explicit empty-state sentences only; no inference from a blank or loading page. */
final class EmptyOffersPolicy {
    static boolean isExplicitEmpty(String value) {
        if (value == null || value.length() > 160) return false;
        String lower = value.toLowerCase(Locale.US);
        if (!lower.contains("offer")) return false;
        String s = lower.replaceAll("[^a-z]", "");
        return s.equals("nooffers") || s.equals("nooffersavailable")
                || s.equals("noavailableoffers") || s.equals("nooffersrightnow")
                || s.equals("nooffersavailableatthistime")
                || s.equals("nooffersavailableatthemoment")
                || s.equals("therearenooffersavailable")
                || s.equals("therearenooffersavailableatthistime")
                || s.equals("youhavenooffers") || s.equals("youhavenooffersavailable")
                || s.equals("youcurrentlyhavenooffers");
    }
    private EmptyOffersPolicy() { }
}
