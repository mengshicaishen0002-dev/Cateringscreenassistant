package com.local.cateringscreenassistant;

/**
 * Bound expensive *idle-only* Accessibility fallback work without suspending monitoring.
 * New-offer/event and indexed action lanes always retain their original deadline and path.
 * These caps are upper wait budgets, not sleeps or scan intervals.
 */
final class IdleFallbackPolicy {
    private static final long IDLE_QUICK_CAP_MS = 40L;
    private static final long IDLE_FULL_CAP_MS = 28L;
    private static final long FAILED_FULL_COALESCE_MS = 48L;

    static long quickBudget(long original, boolean idle) {
        return idle ? Math.min(original, IDLE_QUICK_CAP_MS) : original;
    }

    static long fullBudget(long original, boolean idle) {
        return idle ? Math.min(original, IDLE_FULL_CAP_MS) : original;
    }

    static boolean coalesceFailedFull(long now, long lastFailedAt,
                                       long generation, long lastGeneration,
                                       boolean idle) {
        return idle && lastFailedAt > 0L && generation == lastGeneration
                && now >= lastFailedAt && now - lastFailedAt < FAILED_FULL_COALESCE_MS;
    }

    private IdleFallbackPolicy() { }
}
