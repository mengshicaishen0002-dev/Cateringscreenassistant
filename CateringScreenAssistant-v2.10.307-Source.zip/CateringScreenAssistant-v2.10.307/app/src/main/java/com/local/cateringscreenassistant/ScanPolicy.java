package com.local.cateringscreenassistant;
final class ScanPolicy {
    static final int DEFAULT_OCR_INTERVAL_MS = 20;
    private static final int MIN_OCR_INTERVAL_MS = 12;
    private static final long OCR_RESULT_FRESH_MS = 1200;
    private static final long ACTION_EVIDENCE_FRESH_MS = 2200;

    static int clampOcrInterval(int configured) {
        return Math.max(MIN_OCR_INTERVAL_MS, Math.min(2000, configured));
    }

    static int ocrIntervalForFrame(int configured, boolean freshFirstOffer) {
        return freshFirstOffer ? Math.min(configured, MIN_OCR_INTERVAL_MS)
                : Math.max(DEFAULT_OCR_INTERVAL_MS, configured);
    }

    static boolean needsOcr(long now, long lastFrame, long lastReadable, int interval, boolean busy) {
        return !busy && now - lastFrame >= interval && (lastReadable == 0 || now - lastReadable >= 500);
    }

    /** Fresh enough to keep evaluating an OCR result. */
    static boolean fresh(long now, long started) {
        return now >= started && now - started <= OCR_RESULT_FRESH_MS;
    }

    /**
     * Fresh enough for a coordinate action after OCR + Samsung Accessibility/Binder latency.
     * The action path still re-checks foreground package and performs a bounded page guard
     * immediately before dispatching the gesture.
     */
    static boolean actionFresh(long now, long started) {
        return now >= started && now - started <= ACTION_EVIDENCE_FRESH_MS;
    }

    static long actionAge(long now, long started) {
        return now >= started ? now - started : Long.MAX_VALUE;
    }
}
