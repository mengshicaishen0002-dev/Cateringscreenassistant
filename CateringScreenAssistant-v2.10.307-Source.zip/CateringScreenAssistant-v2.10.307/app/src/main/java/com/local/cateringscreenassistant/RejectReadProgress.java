package com.local.cateringscreenassistant;

/** Diagnostics only. Partial work never supplies an action or empty-page proof. */
final class RejectReadProgress {
    final long startedAt, deadlineAt;
    final boolean indexFirst;
    volatile long workerAt = -1L, rootAt = -1L;
    volatile int visited, queries;
    volatile String stage = "QUEUED";
    volatile boolean cancelled;
    RejectReadProgress(long now, long budget, boolean indexFirst) {
        this.startedAt = now;
        // Reserve a small return margin inside the existing caller budget, not a new budget.
        this.deadlineAt = now + Math.max(1L, budget - 2L);
        this.indexFirst = indexFirst;
    }
    boolean mayRead(long now) { return !cancelled && now < deadlineAt; }
    String detail(long now) {
        return "stage=" + stage + ",visitedAtReturn=" + visited + ",queries=" + queries
                + ",queueMs=" + (workerAt >= 0L ? workerAt-startedAt : Math.max(0L,now-startedAt))
                + ",rootMs=" + (rootAt >= 0L && workerAt >= 0L ? rootAt-workerAt : -1L)
                + ",totalMs=" + Math.max(0L,now-startedAt);
    }
}
