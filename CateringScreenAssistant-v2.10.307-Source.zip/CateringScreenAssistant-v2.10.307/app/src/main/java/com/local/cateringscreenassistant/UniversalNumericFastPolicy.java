package com.local.cateringscreenassistant;

/**
 * Pure numeric policy for deciding whether location evidence is mathematically irrelevant.
 * General is the base acceptance branch; Pasadena is an additional exception branch for offers
 * that do not pass General. It never authorizes an action by itself; callers must still own a
 * fresh current action rectangle and independently re-prove the current amount/mileage pair.
 */
final class UniversalNumericFastPolicy {
    private UniversalNumericFastPolicy() { }

    static boolean qualifies(float amount, float miles,
                             float generalMinPay, float generalMaxMiles,
                             boolean pasadenaEnabled,
                             float pasadenaMinPay, float pasadenaMaxMiles,
                             boolean hasExplicitCityFilter,
                             boolean hasActiveTimeFilter) {
        if (amount < 0f || miles < 0f || hasExplicitCityFilter || hasActiveTimeFilter) return false;
        // v2.10.65: General is the base rule and Pasadena is an ADDITIONAL lower-threshold
        // branch, not an override that can invalidate an offer already accepted by General.
        // Therefore once General passes, location cannot turn the decision into Reject.
        // Pasadena evidence is needed only for offers that FAIL General and may qualify solely
        // through the Pasadena branch.
        return amount >= generalMinPay && miles <= generalMaxMiles;
    }

    /**
     * True only when every enabled numeric branch fails. City/time evidence can further reject
     * an offer, but can never turn this result into Accept, so a current Reject action may be
     * dispatched without paying for address reconstruction.
     */
    static boolean rejects(float amount, float miles,
                           float generalMinPay, float generalMaxMiles,
                           boolean pasadenaEnabled,
                           float pasadenaMinPay, float pasadenaMaxMiles) {
        if (amount < 0f || miles < 0f) return false;
        boolean generalPasses = amount >= generalMinPay && miles <= generalMaxMiles;
        if (generalPasses) return false;
        if (!pasadenaEnabled) return true;
        boolean pasadenaPasses = amount >= pasadenaMinPay && miles <= pasadenaMaxMiles;
        return !pasadenaPasses;
    }
}
