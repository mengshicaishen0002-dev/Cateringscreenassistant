package com.local.cateringscreenassistant;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.util.LinkedHashMap;
import java.util.Map;

/** Confirmed claims use an alarm; unconfirmed results use a short notification cue. */
final class ClaimSuccessAlert {
    static final String ACTION_STOP =
            "com.local.cateringscreenassistant.action.STOP_CLAIM_SUCCESS_ALARM";
    private static final String CHANNEL = "claim_success_alerts_v2";
    private static final String CHANNEL_NAME = "接单结果人工核对提醒";
    private static final long[] VIBRATION = {0, 320, 120, 320, 120, 850};
    private static final long VERIFY_ALARM_DURATION_MS = 1_000L;
    private static final long[] VERIFY_VIBRATION = {0, 100};
    private static final long SUCCESS_ALARM_DURATION_MS = 8_000L;
    private static final long KEEP_MS = 30L * 60L * 1000L;
    private static final Map<String, Long> SENT = new LinkedHashMap<>();
    private static final Object ALARM_LOCK = new Object();
    private static final Object STOP_TOKEN = new Object();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static Ringtone activeTone;
    private static Vibrator activeVibrator;
    private static int activeNotificationId;
    private static boolean activeConfirmed;

    private ClaimSuccessAlert() { }

    static synchronized boolean shouldSend(String identity, long now) {
        SENT.entrySet().removeIf(e -> now - e.getValue() > KEEP_MS);
        if (identity == null || identity.isEmpty()) identity = "claim-" + now;
        if (SENT.containsKey(identity)) return false;
        SENT.put(identity, now);
        while (SENT.size() > 64) SENT.remove(SENT.keySet().iterator().next());
        return true;
    }

    static void notifyConfirmed(Context context,String cardText,String evidence) {
        notifyConfirmed(context,cardText,evidence,0L);
    }
    static void notifyConfirmed(Context context,String cardText,String evidence,long owner) {
        notify(context,cardText,evidence,true,owner);
    }
    /** An unavailable reply is not success: retain verification without the success alarm. */
    static void notifyVerificationRequired(Context context,String cardText,String evidence,long owner) {
        notify(context,cardText,evidence,false,owner);
    }
    private static String alertIdentity(boolean confirmed,long owner,String cardText) {
        return (confirmed?"confirmed:":"verify:")+(owner>0L?"tx="+owner:CardText.identity(cardText));
    }
    private static void notify(Context context,String cardText,String evidence,boolean confirmed,long owner) {
        if(context==null) return;
        String identity=alertIdentity(confirmed,owner,cardText);
        long now = SystemClock.elapsedRealtime();
        if (!shouldSend(identity, now)) return;

        Context app = context.getApplicationContext();
        int notificationId = 26041 + (identity.hashCode() & 0x0fff);
        // Neither result may freeze the monitor merely because an alarm was emitted. In
        // particular, an "offer unavailable" card still has to be retired so the next Offer can
        // be processed. Tapping the notification remains the explicit manual-intervention path.
        long alarmDuration = confirmed ? SUCCESS_ALARM_DURATION_MS : VERIFY_ALARM_DURATION_MS;
        startAlarm(app, notificationId, alarmDuration, confirmed);

        NotificationManager nm = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel channel = nm.getNotificationChannel(CHANNEL);
            if (channel == null) {
                channel = new NotificationChannel(CHANNEL, CHANNEL_NAME,
                        NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("接单成功或结果待核对时短响提醒，可立即切换为人工介入");
                channel.setSound(null, null);
                channel.enableVibration(false);
                nm.createNotificationChannel(channel);
            }
        }

        Intent open = new Intent(app, ClaimInterventionActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(app, 26041, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(app, ClaimAlertReceiver.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getBroadcast(app, 26042, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String text = confirmed
                ? "正在自动返回Offers并恢复监控；点此可立即人工接管"
                : "正在核对Begin Delivery并自动清除失效卡片；点此可立即人工接管";
        if (evidence != null && !evidence.isEmpty()) text += " · " + evidence;
        NotificationCompat.Builder builder = new NotificationCompat.Builder(app, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(confirmed ? "DeliverThat 接单成功" : "DeliverThat 待核对（未确认接单）")
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_menu_view, "人工介入并核对 Jobs", openPi)
                .addAction(android.R.drawable.ic_lock_silent_mode, "仅停止声音", stopPi)
                .setOngoing(true)
                .setAutoCancel(false)
                .setSilent(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setTimeoutAfter(alarmDuration);

        boolean allowed = Build.VERSION.SDK_INT < 33
                || ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
        if (allowed && nm != null) nm.notify(notificationId, builder.build());
    }

    static void sendTest(Context context) {
        notifyConfirmed(context, "test-success-alarm-" + SystemClock.elapsedRealtime(),
                "测试警报（非真实订单）");
    }

    static void stop(Context context) {
        Context app = context == null ? null : context.getApplicationContext();
        synchronized (ALARM_LOCK) {
            MAIN.removeCallbacksAndMessages(STOP_TOKEN);
            if (activeTone != null) {
                try { activeTone.stop(); } catch (RuntimeException ignored) { }
                activeTone = null;
            }
            if (activeVibrator != null) {
                try { activeVibrator.cancel(); } catch (RuntimeException ignored) { }
                activeVibrator = null;
            }
            if (app != null && activeNotificationId != 0) {
                NotificationManager nm = (NotificationManager)
                        app.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.cancel(activeNotificationId);
            }
            activeNotificationId = 0;
            activeConfirmed = false;
        }
    }

    private static void startAlarm(Context context, int notificationId, long durationMs,
                                   boolean looping) {
        synchronized (ALARM_LOCK) {
            // A later ambiguous result must not silence an already-confirmed claim alarm.
            if(!looping && activeConfirmed) return;
            stop(context);
            activeNotificationId = notificationId;
            activeConfirmed = looping;
            Uri sound = RingtoneManager.getDefaultUri(looping
                    ?RingtoneManager.TYPE_ALARM:RingtoneManager.TYPE_NOTIFICATION);
            if (looping && sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            try {
                Ringtone tone = sound==null?null:RingtoneManager.getRingtone(context, sound);
                if (tone != null) {
                    tone.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(looping?AudioAttributes.USAGE_ALARM:AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) tone.setLooping(looping);
                    tone.play();
                    activeTone = tone;
                }
            } catch (RuntimeException ignored) { }
            try {
                Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
                if (vibrator != null && vibrator.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        vibrator.vibrate(VibrationEffect.createWaveform(looping?VIBRATION:VERIFY_VIBRATION, -1));
                    else vibrator.vibrate(looping?VIBRATION:VERIFY_VIBRATION, -1);
                    activeVibrator = vibrator;
                }
            } catch (RuntimeException ignored) { }
            MAIN.postAtTime(() -> stop(context), STOP_TOKEN,
                    SystemClock.uptimeMillis() + Math.max(1_000L, durationMs));
        }
    }
}
