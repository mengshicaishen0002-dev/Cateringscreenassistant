package com.local.cateringscreenassistant;

/** Pure policy for the v2.10.95 early Accept fade detector. */
final class VisualAcceptFadePolicy {
    static boolean isEarlyBlue(int color) {
        int r = (color >> 16) & 0xff;
        int g = (color >> 8) & 0xff;
        int b = color & 0xff;
        return b >= 178 && g >= 132 && r <= 225
                && b - r >= 22 && g - r >= 12;
    }

    static boolean isStrictRightCta(int left, int top, int right, int bottom,
                                    int frameWidth, int frameHeight) {
        int width = right - left;
        int height = bottom - top;
        if (width <= 0 || height <= 0 || frameWidth <= 0 || frameHeight <= 0) return false;
        float aspect = (float) width / height;
        int centerX = left + width / 2;
        int centerY = top + height / 2;
        return width >= Math.round(frameWidth * 0.28f)
                && width <= Math.round(frameWidth * 0.43f)
                && height >= Math.max(28, Math.round(frameHeight * 0.035f))
                && height <= Math.round(frameHeight * 0.14f)
                && aspect >= 2.4f && aspect <= 7.2f
                && centerX > frameWidth * 0.66f
                && centerY > frameHeight * 0.50f;
    }

    private VisualAcceptFadePolicy() { }
}
