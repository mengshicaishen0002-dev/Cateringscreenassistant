package com.local.cateringscreenassistant;

/** Work scheduling only. These decisions never authorize an order action. */
final class RejectWorkPolicy {
    private static final long PIXEL_REUSE_MS = 1200L;

    static boolean mayReusePixels(boolean activeOwner, long ageMs) {
        return activeOwner && ageMs >= 0L && ageMs < PIXEL_REUSE_MS;
    }

    static boolean sameOwnedOffer(String expected, String observed) {
        return expected != null && observed != null
                && !CardText.containsConflictingOfferNumbers(observed)
                && !OfferEnrichmentPolicy.containsConflictingAddresses(observed)
                && !ClaimSuccessSignals.hasAcceptedJobDetail(observed)
                && !ClaimSuccessSignals.hasBeginDeliveryControl(observed)
                && !LargeOrderPopupGuard.isPopupText(observed)
                && !CardText.containsConflictingPickupEvidence(observed)
                && Math.round(CardText.amount(expected)*100f)==Math.round(CardText.amount(observed)*100f)
                && Math.abs(CardText.miles(expected)-CardText.miles(observed))<0.0001f
                && !OfferEnrichmentPolicy.endpointKey(expected).isEmpty()
                && OfferEnrichmentPolicy.endpointKey(expected).equals(OfferEnrichmentPolicy.endpointKey(observed))
                && OfferEnrichmentPolicy.sameTransaction(expected, observed);
    }

    static boolean yieldRescue(boolean dirty, boolean freshDemand, boolean accepting) {
        return dirty || freshDemand || accepting;
    }

    private RejectWorkPolicy() { }
}
