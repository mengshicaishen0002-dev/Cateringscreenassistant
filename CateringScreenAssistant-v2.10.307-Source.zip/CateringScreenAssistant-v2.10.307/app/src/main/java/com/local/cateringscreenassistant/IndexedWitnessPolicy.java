package com.local.cateringscreenassistant;

/** A refreshed witness needs explicit same-transaction identity, never numbers alone. */
final class IndexedWitnessPolicy {
    private static final java.util.regex.Pattern SOURCE_SPACE = java.util.regex.Pattern.compile("\\s+");
    /** Lossless cached-text cover. Selection never authorizes a click; fresh identity does. */
    static int sourceCover(java.util.List<String> sources) {
        int n = sources.size();
        if (n == 0 || n > 8) return 0;
        String[] text = new String[n];
        int[] coverage = new int[n];
        int required = 0;
        for (int i = 0; i < n; i++) {
            text[i] = sources.get(i) == null ? "" : sources.get(i).trim();
            coverage[i] = 1 << i;
            if (!text[i].isEmpty()) required |= 1 << i;
        }
        for (int i = 0; i < n; i++) {
            Boolean cardLocal = null;
            for (int j = 0; j < n; j++) {
                if (i == j || text[j].isEmpty() || !text[i].contains(text[j])) continue;
                if (cardLocal == null) cardLocal = !CardText.containsMultipleMileageRows(text[i]);
                if (cardLocal) coverage[i] |= 1 << j;
            }
        }
        // Literal containment is transitive. Keep only maximal source covers; equivalent
        // duplicates retain the first handle. This replaces an exhaustive 2^n subset walk.
        int best=required;
        for (int i=0;i<n;i++) {
            if ((required & (1<<i))==0) continue;
            for (int j=0;j<n;j++) {
                if (i==j || (required & (1<<j))==0) continue;
                if ((coverage[j] & coverage[i])==coverage[i]
                        && (coverage[j]!=coverage[i] || j<i)) {
                    best &= ~(1<<i);break;
                }
            }
        }
        return best;
    }

    /** Lossless single source after case/whitespace folding; all source text must be retained. */
    static int singleFoldedSource(java.util.List<String> sources) {
        if(sources.isEmpty() || sources.size()>8) return 0;
        String[] folded=new String[sources.size()];
        for(int i=0;i<folded.length;i++) folded[i]=sources.get(i)==null?"":SOURCE_SPACE.matcher(sources.get(i))
                .replaceAll(" ").trim().toLowerCase(java.util.Locale.US);
        for(int i=0;i<folded.length;i++) {
            if(folded[i].isEmpty() || CardText.containsMultipleMileageRows(sources.get(i))
                    || CardText.containsConflictingOfferNumbers(sources.get(i))) continue;
            boolean all=true;
            for(String field:folded) if(!folded[i].contains(field)){all=false;break;}
            if(all) return 1<<i;
        }
        return 0;
    }

    /** Minimum source set covering every known identity field. Pure local work, no Binder. */
    static int minimumCover(String expected, java.util.List<String> sources) {
        if (!RejectDemandPolicy.coherent(expected) || sources.isEmpty() || sources.size() > 8) return 0;
        String id = CardText.orderId(expected), time = OfferEnrichmentPolicy.pickupKey(expected);
        String endpoint = OfferEnrichmentPolicy.endpointKey(expected);
        if (id.isEmpty() && endpoint.isEmpty()) return 0;
        int required = 3 | (id.isEmpty() ? 0 : 4) | (time.isEmpty() ? 0 : 8)
                | (endpoint.isEmpty() ? 0 : 16);
        int cents = Math.round(CardText.amount(expected) * 100f);
        float expectedMiles = CardText.miles(expected);
        int[] coverage = new int[sources.size()];
        for (int i = 0; i < coverage.length; i++) {
            String text = sources.get(i);
            if (CardText.containsMultipleMileageRows(text)
                    || CardText.containsConflictingOfferNumbers(text)
                    || ClaimSuccessSignals.hasAcceptedJobDetail(text)
                    || ClaimSuccessSignals.hasBeginDeliveryControl(text)) continue;
            float pay = CardText.amount(text), miles = CardText.miles(text);
            if (pay >= 0f && Math.round(pay * 100f) == cents) coverage[i] |= 1;
            if (miles >= 0f && Math.abs(miles - expectedMiles) <= .0001f) coverage[i] |= 2;
            if (!id.isEmpty() && id.equals(CardText.orderId(text))) coverage[i] |= 4;
            if (!time.isEmpty() && time.equals(OfferEnrichmentPolicy.pickupKey("$0 0 mi " + text))) coverage[i] |= 8;
            if (!endpoint.isEmpty() && endpoint.equals(OfferEnrichmentPolicy.endpointKey(text))) coverage[i] |= 16;
        }
        int best = 0, count = Integer.MAX_VALUE;
        for (int mask = 1; mask < (1 << coverage.length); mask++) {
            int bits = Integer.bitCount(mask);
            if (bits >= count) continue;
            int covered = 0;
            for (int i = 0; i < coverage.length; i++) if ((mask & (1 << i)) != 0) covered |= coverage[i];
            if ((covered & required) == required) { best = mask; count = bits; }
        }
        if (best == 0) return 0;
        StringBuilder joined = new StringBuilder();
        for (int i = 0; i < sources.size(); i++) if ((best & (1 << i)) != 0)
            joined.append(sources.get(i)).append('\n');
        return sameIdentity(expected, joined.toString()) ? best : 0;
    }

    static boolean sameIdentity(String expected, String current) {
        // Parse each numeric field once; coherent() would parse them again before comparison.
        if (expected == null || current == null) return false;
        float expectedPay=CardText.amount(expected), currentPay=CardText.amount(current);
        float expectedMiles=CardText.miles(expected), currentMiles=CardText.miles(current);
        if (expectedPay<0f || currentPay<0f || expectedMiles<0f || currentMiles<0f
                || CardText.containsConflictingOfferNumbers(expected)
                || CardText.containsConflictingOfferNumbers(current)
                || ClaimSuccessSignals.hasAcceptedJobDetail(expected)
                || ClaimSuccessSignals.hasAcceptedJobDetail(current)
                || ClaimSuccessSignals.hasBeginDeliveryControl(expected)
                || ClaimSuccessSignals.hasBeginDeliveryControl(current)) return false;
        if (Math.round(expectedPay * 100f) != Math.round(currentPay * 100f)
                || Math.abs(expectedMiles - currentMiles) > .0001f) return false;
        String a = CardText.orderId(expected), b = CardText.orderId(current);
        if (!a.isEmpty() && !a.equals(b)) return false;
        String time = OfferEnrichmentPolicy.pickupKey(expected);
        if (!time.isEmpty() && !time.equals(OfferEnrichmentPolicy.pickupKey(current))) return false;
        String endpoint = OfferEnrichmentPolicy.endpointKey(expected);
        if (!endpoint.isEmpty() && !endpoint.equals(OfferEnrichmentPolicy.endpointKey(current))) return false;
        return !a.isEmpty() || !endpoint.isEmpty();
    }
    private IndexedWitnessPolicy() { }
}
