package com.local.cateringscreenassistant;

/** Per-run local timing, never reused as evidence or an action permission. */
final class PipelineTiming {
    private final long startedAt;
    private long lastAt;
    private final StringBuilder stages = new StringBuilder();
    private long queuedAt, finishedAt;
    private String trigger, exit;

    // Written by the scan worker and read only after volatile publication at scan completion.
    void completeScan(long queued, long finished, boolean structural, boolean priority, String reason) {
        queuedAt = queued;
        finishedAt = finished;
        trigger = structural ? "STRUCTURAL" : priority ? "PRIORITY" : "REGULAR";
        exit = reason;
    }

    boolean isSlowScan() {
        return startedAt-queuedAt>=32L || finishedAt-startedAt>=60L;
    }

    String scanSummary(long latestScanAt) {
        return " completed_scan_start_ms="+startedAt+" completed_scan_end_ms="+finishedAt
                +" completed_scan_is_latest="+(startedAt==latestScanAt)
                +" trigger="+trigger+" queue_ms="+(startedAt-queuedAt)
                +" exit="+exit+" phases="+stages+(stages.length()>0?",":"")
                +"tail="+Math.max(0L,finishedAt-lastAt)+"ms,total="+Math.max(0L,finishedAt-startedAt)+"ms";
    }

    PipelineTiming(long now) { startedAt = lastAt = now; }
    void mark(String stage, long now) {
        long at = Math.max(lastAt, now);
        if (stages.length() > 0) stages.append(',');
        stages.append(stage).append('=').append(at-lastAt).append("ms");
        lastAt = at;
    }
    String finish(long now) {
        return stages + (stages.length()>0?",":"") + "admit=" + Math.max(0L,now-lastAt)
                + "ms,total=" + Math.max(0L,now-startedAt) + "ms";
    }
}
