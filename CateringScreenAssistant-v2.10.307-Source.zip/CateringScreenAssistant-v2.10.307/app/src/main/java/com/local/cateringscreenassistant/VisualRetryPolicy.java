package com.local.cateringscreenassistant;
/** A fallback within the existing attempt budget, never a new transaction. */
final class VisualRetryPolicy {
 static final long MAX_FRAME_MS=400L;
 static boolean due(long age,long sinceProbe,int probes,boolean needed,boolean busy) {
  return needed && !busy && age>=180 && age<=3000 && sinceProbe>=120 && probes<6;
 }
 static boolean fresh(long frameAt,long now){return frameAt>0 && now>=frameAt && now-frameAt<=MAX_FRAME_MS;}
 static boolean label(String raw){String s=ClaimSuccessSignals.normalize(raw);return s.equals("accept")||s.equals("claim");}
 static boolean card(String expected,String current,String page){
  return current!=null && page!=null && !ClaimSuccessSignals.isTerminalNegative(page)
   && ClaimSuccessSignals.timeConflictHint(page).isEmpty()
   && !ClaimSuccessSignals.hasBeginDeliveryControl(page) && !ClaimSuccessSignals.hasAcceptedJobDetail(page)
   && !OfferEnrichmentPolicy.endpointKey(current).isEmpty()
   && (!OfferEnrichmentPolicy.pickupKey(current).isEmpty() || !CardText.orderId(current).isEmpty())
   && OfferEnrichmentPolicy.sameTransaction(expected,current);
 }
 static final class Proof {
  long frame;String text="";int left,top,right,bottom;
  boolean observe(String current,long at,int l,int t,int r,int b){
   boolean ready=frame>0 && at>frame && at-frame>=80 && at-frame<=900
    && OfferEnrichmentPolicy.sameTransaction(text,current)
    && Math.abs(l-left)<=16 && Math.abs(t-top)<=16 && Math.abs(r-right)<=16 && Math.abs(b-bottom)<=16;
   frame=at;text=current;left=l;top=t;right=r;bottom=b;return ready;
  }
 }
 private VisualRetryPolicy(){}
}
