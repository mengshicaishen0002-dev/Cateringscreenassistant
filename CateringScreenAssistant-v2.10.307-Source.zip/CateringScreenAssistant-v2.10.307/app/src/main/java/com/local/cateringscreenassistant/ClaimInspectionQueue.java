package com.local.cateringscreenassistant;
/** One pending inspection per claim epoch; superseded callbacks do no Binder work. */
final class ClaimInspectionQueue {
 private long sequence,ticket,owner,due=Long.MAX_VALUE;
 synchronized long request(long epoch,long now,long delay){
  if(epoch<owner)return 0L;
  long next=now+Math.max(0L,delay);
  if(ticket!=0&&owner==epoch&&due<=next)return 0L;
  owner=epoch;due=next;ticket=++sequence;return ticket;
 }
 synchronized long urgent(long epoch,long now){
  if(epoch<owner)return 0L;
  owner=epoch;due=now;ticket=++sequence;return ticket;
 }
 synchronized boolean begin(long requested,long epoch){
  if(requested==0||ticket!=requested||owner!=epoch)return false;
  ticket=0L;due=Long.MAX_VALUE;return true;
 }
}
