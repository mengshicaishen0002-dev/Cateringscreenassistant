package com.local.cateringscreenassistant;

/**
 * v2.10.121: permit a bounded same-card visual Accept rebind after harmless
 * React-Native accessibility event-generation churn. A numeric match by itself
 * does not authorize an action: the foreground service also requires a new,
 * enabled top Accept and a matching physical action rectangle.
 */
final class VisualGenerationReboundPolicy {
    static final long MAX_FRAME_AGE_MS = 420L;

    static boolean canRebind(String original, String current,
                             float amount, float miles,
                             int oldLeft, int oldTop, int oldRight, int oldBottom,
                             int liveLeft, int liveTop, int liveRight, int liveBottom,
                             long frameAgeMs) {
        if (frameAgeMs < 0L || frameAgeMs > MAX_FRAME_AGE_MS) return false;
        if (original == null || current == null || original.isEmpty() || current.isEmpty()) return false;
        if (amount < 0f || miles < 0f) return false;
        if (Math.abs(CardText.amount(original) - amount) > .011f
                || Math.abs(CardText.miles(original) - miles) > .051f
                || Math.abs(CardText.amount(current) - amount) > .011f
                || Math.abs(CardText.miles(current) - miles) > .051f) return false;
        if (!CardText.sameOfferForAction(original, current)) return false;
        // Never fuse two fully identified offers with different scheduled times.
        String a = CardText.identity(original), b = CardText.identity(current);
        String aTime = keyValue(a, "time="), bTime = keyValue(b, "time=");
        if (!aTime.isEmpty() && !bTime.isEmpty() && !aTime.equals(bTime)) return false;

        return sameGeometry(oldLeft, oldTop, oldRight, oldBottom, liveLeft, liveTop, liveRight, liveBottom);
    }

    static boolean sameGeometry(int oldLeft, int oldTop, int oldRight, int oldBottom,
                                int liveLeft, int liveTop, int liveRight, int liveBottom) {
        int oldW = oldRight - oldLeft, oldH = oldBottom - oldTop;
        int liveW = liveRight - liveLeft, liveH = liveBottom - liveTop;
        if (oldW <= 0 || oldH <= 0 || liveW <= 0 || liveH <= 0) return false;
        // A navigation/tab control must not inherit a blue Accept rectangle.
        if (liveW < oldW * .58f || liveW > oldW * 1.6f
                || liveH < oldH * .58f || liveH > oldH * 1.6f) return false;
        int ix = Math.max(0, Math.min(oldRight, liveRight) - Math.max(oldLeft, liveLeft));
        int iy = Math.max(0, Math.min(oldBottom, liveBottom) - Math.max(oldTop, liveTop));
        float smaller = Math.min((float) oldW * oldH, (float) liveW * liveH);
        if ((float) ix * iy / smaller >= .65f) return true;
        float dx = Math.abs((oldLeft + oldRight - liveLeft - liveRight) * .5f);
        float dy = Math.abs((oldTop + oldBottom - liveTop - liveBottom) * .5f);
        return dx <= Math.max(16f, oldW * .17f)
                && dy <= Math.max(12f, oldH * .3f);
    }

    private static String keyValue(String identity, String key) {
        int at = identity.indexOf(key);
        if (at < 0) return "";
        int start = at + key.length(), end = identity.indexOf('|', start);
        return identity.substring(start, end < 0 ? identity.length() : end);
    }

    private VisualGenerationReboundPolicy() { }
}
