package com.local.cateringscreenassistant;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Filters map/transition OCR fragments before the bounded anchorless rescue loop. */
final class AnchorlessOfferGuard {
    private static final Pattern MONEY = Pattern.compile("(?:\\$|USD\\s*)\\d{1,4}(?:[.,]\\d{1,2})?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern MILES = Pattern.compile("\\d{1,3}(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern OFFER_TIME = Pattern.compile(
            "(?:today|tomorrow)\\s*(?:at)?\\s*\\d{1,2}:\\d{2}\\s*(?:am|pm)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern CA_ZIP = Pattern.compile("\\bCA\\s+\\d{5}(?:-\\d{4})?\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern STREET = Pattern.compile(
            "(?:[•·]\\s*)?\\d{1,6}\\s+[A-Za-z0-9.'#-]+(?:\\s+[A-Za-z0-9.'#-]+){0,7}");
    private static final Pattern ACTION = Pattern.compile("\\b(?:accept|claim|ignore|decline|reject)\\b",
            Pattern.CASE_INSENSITIVE);

    static boolean eligibleForRescue(String text) {
        if (text == null || text.trim().isEmpty()) return false;
        if (!MONEY.matcher(text).find() || !MILES.matcher(text).find()) return false;
        if (count(OFFER_TIME.matcher(text), 2) != 1) return false;
        if (ACTION.matcher(text).find()) return true;
        return CA_ZIP.matcher(text).find()
                && (text.indexOf('•') >= 0 || text.indexOf('·') >= 0 || STREET.matcher(text).find());
    }

    private static int count(Matcher matcher, int stopAt) {
        int count = 0;
        while (matcher.find() && count < stopAt) count++;
        return count;
    }

    private AnchorlessOfferGuard() { }
}
