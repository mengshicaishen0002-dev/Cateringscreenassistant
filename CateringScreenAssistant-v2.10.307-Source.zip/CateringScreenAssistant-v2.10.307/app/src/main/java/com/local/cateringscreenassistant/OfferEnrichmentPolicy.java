package com.local.cateringscreenassistant;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A suppression/ownership bridge only; never supplies numbers, geometry or permission to tap. */
final class OfferEnrichmentPolicy {
    private static final Pattern PICKUP = Pattern.compile(
            "\\b(?:(?:today|tomorrow)|(?:january|february|march|april|may|june|july|august|september|october|november|december)\\s+\\d{1,2})\\s*(?:at)?\\s*\\d{1,2}:\\d{2}\\s*(?:am|pm)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern ADDRESS = Pattern.compile(
            "\\b\\d{1,6}\\s+[^•\\n]+?\\b(?:ca|california)\\s+\\d{5}(?:-\\d{4})?\\b",
            Pattern.CASE_INSENSITIVE);

    // Hot-path replacements are immutable/thread-safe; avoid recompiling on every node.
    private static final Pattern PARENS = Pattern.compile("\\([^)]*\\)");
    private static final Pattern PAY = Pattern.compile("(?:\\$|usd\\s*)\\d+(?:[.,]\\d+)?");
    private static final Pattern MILEAGE = Pattern.compile("\\d+(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b");
    private static final Pattern NOISE = Pattern.compile("\\b(?:est|large order|accept|claim)\\b");
    private static final Pattern NON_WORD = Pattern.compile("[^a-z0-9]+");
    private static final Pattern SPACE = Pattern.compile("\\s+");

    static String pickupKey(String text) {
        CardText.ParseFacts f=CardText.parseFacts(text);
        if(f.pickup==null) f.pickup=pickupKeyUncached(text);
        return f.pickup;
    }

    private static String pickupKeyUncached(String text) {
        String completion = CardText.completionKey(text);
        int offset = completion.indexOf("|time=");
        return offset < 0 ? "" : completion.substring(offset + 6);
    }

    static String endpointKey(String text) {
        CardText.ParseFacts f=CardText.parseFacts(text);
        if(f.endpoint==null) f.endpoint=endpointKeyUncached(text);
        return f.endpoint;
    }

    private static String endpointKeyUncached(String text) {
        if (text == null || text.indexOf('•') < 0) return "";
        String raw = CardText.withoutPickupZone(text).toLowerCase(Locale.US).replace('’', '\'');
        Matcher address = ADDRESS.matcher(raw);
        if (!address.find()) return "";
        int bullet = raw.lastIndexOf('•', address.start());
        if (bullet < 0) return "";
        String prefix = raw.substring(0, bullet);
        int travelEnd = prefix.lastIndexOf(')');
        if (travelEnd >= 0) prefix = prefix.substring(travelEnd + 1);
        String merchant = PICKUP.matcher(prefix).replaceAll(" ");
        merchant=PARENS.matcher(merchant).replaceAll(" ");
        merchant=PAY.matcher(merchant).replaceAll(" ");
        merchant=MILEAGE.matcher(merchant).replaceAll(" ");
        merchant=NOISE.matcher(merchant).replaceAll(" ");
        merchant = normalize(merchant);
        return merchant.isEmpty() ? "" : merchant + "|" + normalize(address.group());
    }

    private static final Pattern REJECT_OCR_EL_SEGUNDO = Pattern.compile(
            "(\\|\\d{1,6} )wei segundo (blvd hawthorne ca 90250)$");

    /** Observed OCR W El -> WEI confusion at this exact street/city/ZIP.
     * Ownership only. Do not canonicalize street digits, other streets or live Accept proof. */
    static String rejectEndpointKey(String text) {
        CardText.ParseFacts f=CardText.parseFacts(text);
        if (f.rejectEndpoint==null) {
            String endpoint=endpointKey(text);
            f.rejectEndpoint=endpoint.contains("wei segundo")
                    ? REJECT_OCR_EL_SEGUNDO.matcher(endpoint).replaceFirst("$1w el segundo $2") : endpoint;
        }
        return f.rejectEndpoint;
    }

    /** Duplicate OCR fields are suppressible only when every exported street agrees. */
    static boolean containsConflictingAddresses(String text) {
        if (text == null) return false;
        CardText.ParseFacts facts = CardText.parseFacts(text);
        if (facts.conflictingAddresses == null)
            facts.conflictingAddresses = computeConflictingAddresses(text);
        return facts.conflictingAddresses;
    }

    private static boolean computeConflictingAddresses(String text) {
        Matcher addresses = ADDRESS.matcher(text);
        String first = "";
        while (addresses.find()) {
            String address = normalize(addresses.group());
            if (!first.isEmpty() && !first.equals(address)) return true;
            first = address;
        }
        return false;
    }

    private static String normalize(String value) {
        return SPACE.matcher(NON_WORD.matcher(value).replaceAll(" ").trim()).replaceAll(" ");
    }

    static boolean sameTransaction(String left, String right) {
        if (left == null || right == null || left.isEmpty() || right.isEmpty()
                || CardText.containsConflictingOfferNumbers(left)
                || CardText.containsConflictingOfferNumbers(right)) return false;
        if (CardText.amount(left) < 0 || CardText.miles(left) < 0
                || Math.round(CardText.amount(left) * 100f) != Math.round(CardText.amount(right) * 100f)
                || Math.abs(CardText.miles(left) - CardText.miles(right)) > 0.0001f) return false;
        String orderLeft = CardText.orderId(left), orderRight = CardText.orderId(right);
        if (!orderLeft.isEmpty() && !orderRight.isEmpty() && !orderLeft.equals(orderRight)) return false;
        String timeLeft = pickupKey(left), timeRight = pickupKey(right);
        if (!timeLeft.isEmpty() && !timeRight.isEmpty() && !timeLeft.equals(timeRight)) return false;
        String leftEndpoint = endpointKey(left), rightEndpoint = endpointKey(right);
        if (!leftEndpoint.isEmpty() && !rightEndpoint.isEmpty()
                && !leftEndpoint.equals(rightEndpoint)) return false;
        if (CardText.identity(left).equals(CardText.identity(right))) return true;
        // Only missing-field enrichment is eligible, not two independently complete offers.
        if (!timeLeft.isEmpty() && !timeRight.isEmpty()) return false;
        String endpoint = endpointKey(left);
        return !endpoint.isEmpty() && endpoint.equals(endpointKey(right));
    }

    /** Ownership/suppression only: a merchant-free detail cannot acquire a new attempt budget.
     * This deliberately does NOT authorize an action or relax sameTransaction's live proof. */
    static boolean sameBudgetOwner(String left, String right) {
        if (sameTransaction(left, right)) return true;
        if (left == null || right == null || CardText.containsConflictingOfferNumbers(left)
                || CardText.containsConflictingOfferNumbers(right)
                || CardText.amount(left) < 0 || CardText.miles(left) < 0
                || Math.round(CardText.amount(left)*100f) != Math.round(CardText.amount(right)*100f)
                || Math.abs(CardText.miles(left)-CardText.miles(right)) > 0.0001f) return false;
        String a=CardText.orderId(left), b=CardText.orderId(right);
        if (!a.isEmpty() && !b.isEmpty() && !a.equals(b)) return false;
        a=pickupKey(left); b=pickupKey(right);
        if (!a.isEmpty() && !b.isEmpty() && !a.equals(b)) return false;
        a=endpointKey(left); b=endpointKey(right);
        if (!a.isEmpty() && !b.isEmpty()) return false; // both merchants known: strict matcher owns it
        String address=budgetAddressKey(left);
        return !address.isEmpty() && address.equals(budgetAddressKey(right));
    }

    private static String budgetAddressKey(String text) {
        // Bound address parsing after the travel label / merchant bullet. Never let a price,
        // mileage or pickup-time number become the street number on a partial detail page.
        int start=text.lastIndexOf('•');
        if (start<0) start=text.lastIndexOf(')');
        if (start<0) return "";
        Matcher address=ADDRESS.matcher(text.substring(start+1));
        if (!address.find()) return "";
        String key=normalize(address.group());
        if (address.find()) return ""; // multiple routes are ambiguous
        return key;
    }

    private OfferEnrichmentPolicy() { }
}
