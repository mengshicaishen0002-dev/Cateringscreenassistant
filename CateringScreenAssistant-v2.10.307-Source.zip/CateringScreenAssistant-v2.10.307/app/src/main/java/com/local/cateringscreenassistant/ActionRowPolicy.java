package com.local.cateringscreenassistant;

/** Pure structural action-row policy, separated for regression testing. */
final class ActionRowPolicy {
    private ActionRowPolicy() { }

    /**
     * Rows are ordered left-to-right and the rightmost control is Accept. A Large Order card
     * may insert an information control before Ignore, so Reject is the control immediately to
     * the left of Accept—not blindly the leftmost control.
     */
    static int structuralRejectIndex(int rowSize) {
        if (rowSize <= 0) return -1;
        if (rowSize == 1) return 0;
        return rowSize - 2;
    }
    /** A fresh Reject must belong to the same physical row as the observed top Accept. */
    static boolean pairedReject(int left,int top,int right,int bottom,
            int acceptLeft,int acceptTop,int acceptRight,int acceptBottom) {
        if(right<=left || bottom<=top || acceptRight<=acceptLeft || acceptBottom<=acceptTop
                || right>acceptLeft) return false;
        int overlap=Math.min(bottom,acceptBottom)-Math.max(top,acceptTop);
        return overlap>0 && overlap*2>=Math.min(bottom-top,acceptBottom-acceptTop);
    }
}
