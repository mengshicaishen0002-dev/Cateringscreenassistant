package com.local.cateringscreenassistant;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Handler;
import android.os.Process;
import android.os.SystemClock;
import android.util.AtomicFile;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicReference;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class AcceptReplay {
    private static final long PRE_MS = 1_200L;
    private static final long POST_MS = 15_000L;
    private static final long PRE_SAMPLE_MS = 32L;
    private static final long SAMPLE_MS = 100L;
    private static final int MAX_PRE_FRAMES = 39;
    private static final int MAX_PRE_MARKERS = 96;
    private static final int MAX_FRAMES = 88;
    private final AtomicReference<Clip> active = new AtomicReference<>();
    private final ArrayDeque<Frame> recent = new ArrayDeque<>();
    private final ArrayDeque<Marker> recentMarkers = new ArrayDeque<>();
    private final File file;
    private long lastSampleAt;
    private volatile long pinAt=-1L;
    private String lastScreenProbe = "UNPROBED";
    private Frame lastNoCtaFrame;
    private Frame edgeBefore, edgeAfter;
    private final Object exportLock=new Object();
    private long lastWrittenAt=-1L;

    AcceptReplay(Context context) {
        file = latestFile(context);
    }

    static File latestFile(Context context) {
        return new File(new File(context.getCacheDir(), "accept-replay"), "DeliverThat-Accept-Replay.zip");
    }

    // Called from the action lane only after Android has accepted the gesture.
    void dispatched(Handler captureWorker, long tx, long at, long numericAt) {
        if(captureWorker==null)return;
        while(true) {
            Clip current=active.get();
            if(current!=null && current.tx==tx) {
                current.events.add(at+"\tDISPATCH_ACCEPTED");return;
            }
            Clip clip=new Clip(tx,at,System.currentTimeMillis());
            if (numericAt > 0 && numericAt <= at)
                clip.events.add(numericAt + "\tFIRST_LOCAL_NUMERIC tx=" + tx);
            clip.events.add(at+"\tDISPATCH_ACCEPTED");
            if(!active.compareAndSet(current,clip))continue;
            captureWorker.post(() -> {
                copyPreRoll(clip);
                if(current!=null) export(current);
            });
            captureWorker.postDelayed(() -> finish(clip),POST_MS);
            return;
        }
    }

    void event(long at, String event) {
        Clip clip = active.get();
        if (clip != null && at >= clip.firstAt && at - clip.firstAt <= POST_MS)
            clip.events.add(at + "\t" + event.replace("\n", "\\n").replace("\t", " "));
    }

    void markDiscovery(long at, String stage) {
        if (at <= 0L) return;
        synchronized (recentMarkers) {
            if (recentMarkers.size() >= MAX_PRE_MARKERS) recentMarkers.removeFirst();
            recentMarkers.addLast(new Marker(at, stage));
        }
    }

    private static final class Marker {
        final long at;
        final String stage;

        Marker(long at, String stage) {
            this.at = at;
            this.stage = stage;
        }
    }

    // Pin only the exact acquired frame on which the visual state machine made a transition.
    void pinFrameAt(long at) { pinAt=at; }

    // Screen worker only. Keep a bounded, downsampled buffer before OCR or dispatch.
    void sample(Image image, long now, String screenProbe, long callbackAt) {
        Clip clip = active.get();
        boolean screenChanged = !"UNPROBED".equals(screenProbe) && !screenProbe.equals(lastScreenProbe);
        boolean pinned=pinAt==now;
        if (pinned) pinAt=-1L;
        if (now - lastSampleAt < PRE_SAMPLE_MS && !screenChanged && !pinned) return;
        try {
            Frame frame = Frame.copy(image, now, screenProbe, callbackAt);
            if (frame == null) return;
            lastSampleAt = now;
            if (!"UNPROBED".equals(screenProbe)) lastScreenProbe = screenProbe;
            while (!recent.isEmpty() && (recent.size() >= MAX_PRE_FRAMES || now - recent.peekFirst().at > PRE_MS))
                recent.removeFirst();
            recent.addLast(frame);
            if ("NO_CTA_CANDIDATE".equals(screenProbe)) {
                lastNoCtaFrame = frame;
            } else if (screenChanged && "CTA_CANDIDATE".equals(screenProbe)) {
                // A static Offers screen may stop producing frames for far longer
                // than the rolling pre-buffer. Pin the two sides of this edge.
                edgeBefore = lastNoCtaFrame;
                edgeAfter = frame;
                lastNoCtaFrame = null;
            }
            if (clip != null && now >= clip.firstAt && now - clip.firstAt <= POST_MS
                    && clip.frames.size() < MAX_FRAMES) {
                long age = now - clip.firstAt;
                long interval = age < 420L ? PRE_SAMPLE_MS : age < 1_000L ? SAMPLE_MS : 250L;
                if (clip.lastPostSampleAt == 0L || now - clip.lastPostSampleAt >= interval || screenChanged || pinned) {
                    clip.frames.add(frame);
                    clip.lastPostSampleAt = now;
                }
            }
        } catch (RuntimeException e) {
            Log.w("AcceptReplay", "Skipped unavailable capture frame", e);
        }
    }

    void clearPreRoll() {
        recent.clear();
        lastSampleAt = 0L;
        pinAt=-1L;
        lastScreenProbe = "UNPROBED";
        lastNoCtaFrame = edgeBefore = edgeAfter = null;
    }

    private void copyPreRoll(Clip clip) {
        List<Frame> pre = new ArrayList<>();
        for (Frame frame : recent) {
            if (frame.at < clip.firstAt && clip.firstAt - frame.at <= PRE_MS) pre.add(frame);
        }
        Frame visible = edgeAfter;
        if (visible != null && visible.at <= clip.firstAt && clip.firstAt - visible.at <= PRE_MS
                && (lastNoCtaFrame == null || lastNoCtaFrame.at > clip.firstAt)) {
            clip.visibleEdgeAt = visible.at;
            Frame baseline = edgeBefore;
            if (baseline != null) {
                clip.absentEdgeAt = baseline.at;
                if (!pre.contains(baseline)) pre.add(0, baseline);
            }
        }
        clip.frames.addAll(0, pre);
        synchronized (recentMarkers) {
            for (Marker marker : recentMarkers) {
                if (marker.at <= clip.firstAt && clip.firstAt - marker.at <= PRE_MS)
                    clip.events.add(marker.at + "\t" + marker.stage);
            }
        }
    }

    private void finish(Clip clip) {
        if(active.compareAndSet(clip,null))export(clip);
    }
    private void export(Clip clip) {
        new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            synchronized(exportLock) {
                if(clip.firstAt<=lastWrittenAt)return;
                try {write(clip);lastWrittenAt=clip.firstAt;}
                catch(IOException | RuntimeException e){Log.w("AcceptReplay","Replay export failed",e);}
            }
        },"accept-replay-export").start();
    }

    private void write(Clip clip) throws IOException {
        AtomicFile output = new AtomicFile(file);
        FileOutputStream stream = output.startWrite();
        try (ZipOutputStream zip = new ZipOutputStream(new FilterOutputStream(stream) {
            @Override public void close() throws IOException { flush(); }
        })) {
            StringBuilder timeline = new StringBuilder()
                    .append("tx_elapsed_ms=").append(clip.tx)
                    .append("\nfirst_dispatch_elapsed_ms=").append(clip.firstAt)
                    .append("\nfirst_dispatch_unix_ms=").append(clip.wallAt)
                    .append("\npre_dispatch_frames=").append(clip.frames.stream()
                            .filter(frame -> frame.at < clip.firstAt).count())
                    .append("\ncta_edge_status=").append(clip.visibleEdgeAt < 0 ? "NO_FRESH_EDGE"
                            : clip.absentEdgeAt < 0 ? "NO_PRECEDING_NO_CTA_FRAME"
                            : clip.visibleEdgeAt-clip.absentEdgeAt > PRE_MS ? "BRACKETED_WIDE" : "BRACKETED")
                    .append("\nlast_no_cta_elapsed_ms=").append(clip.absentEdgeAt)
                    .append("\nfirst_cta_elapsed_ms=").append(clip.visibleEdgeAt)
                    .append("\ncta_edge_gap_ms=").append(clip.visibleEdgeAt>=0 && clip.absentEdgeAt>=0
                            ? clip.visibleEdgeAt-clip.absentEdgeAt : -1L)
                    .append("\ncta_sample_to_dispatch_ms=").append(clip.visibleEdgeAt>=0
                            ? clip.firstAt-clip.visibleEdgeAt : -1L)
                    .append("\nFRAME uses local acquire time. FRAME_CLOCKS records callback elapsed ms and producer ns without assuming a shared clock.")
                    .append("\nCTA markers are visual cues, not click or server evidence.\n");
            zip.setLevel(java.util.zip.Deflater.NO_COMPRESSION);
            List<String> entries = new ArrayList<>(clip.events);
            int index = 0;
            for (Frame frame : clip.frames) {
                String name = String.format(java.util.Locale.US, "frames/%03d.jpg", ++index);
                entries.add(frame.at + "\tFRAME\t" + name);
                entries.add(frame.at + "\tFRAME_CLOCKS\t" + name + " callback_elapsed_ms="
                        + frame.callbackAt + " producer_timestamp_ns=" + frame.producerTimestampNs);
                if (!"UNPROBED".equals(frame.screenProbe))
                    entries.add(frame.at + "\tSCREEN_CTA_SAMPLE\t" + frame.screenProbe);
                zip.putNextEntry(new ZipEntry(name));
                frame.writeJpeg(zip);
                zip.closeEntry();
            }
            entries.sort(java.util.Comparator.comparingLong(
                    entry -> Long.parseLong(entry.substring(0, entry.indexOf('\t')))));
            for (String entry : entries) timeline.append(entry).append('\n');
            zip.putNextEntry(new ZipEntry("timeline.txt"));
            zip.write(timeline.toString().getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
            zip.finish();
            zip.flush();
        } catch (IOException | RuntimeException e) {
            output.failWrite(stream);
            throw e;
        }
        output.finishWrite(stream);
    }

    private static final class Clip {
        final long tx, firstAt, wallAt;
        long lastPostSampleAt;
        long absentEdgeAt = -1L, visibleEdgeAt = -1L;
        final List<Frame> frames = new ArrayList<>();
        final ConcurrentLinkedQueue<String> events = new ConcurrentLinkedQueue<>();

        Clip(long tx, long firstAt, long wallAt) {
            this.tx = tx;
            this.firstAt = firstAt;
            this.wallAt = wallAt;
        }
    }

    private static final class Frame {
        final long at;
        final int width, height;
        final String screenProbe;
        final int[] pixels;

        final long callbackAt, producerTimestampNs;

        Frame(long at, int width, int height, String screenProbe, long callbackAt, long producerTimestampNs) {
            this.at = at;
            this.callbackAt = callbackAt;
            this.producerTimestampNs = producerTimestampNs;
            this.width = width;
            this.screenProbe = screenProbe;
            this.height = height;
            this.pixels = new int[width * height];
        }

        static Frame copy(Image image, long at, String screenProbe, long callbackAt) {
            Image.Plane plane = image.getPlanes()[0];
            if (plane.getPixelStride() != 4 || plane.getRowStride() % 4 != 0) return null;
            int step = Math.max(4, (image.getWidth() + 319) / 320);
            Frame frame = new Frame(at, image.getWidth() / step, image.getHeight() / step,
                    screenProbe, callbackAt, image.getTimestamp());
            ByteBuffer buffer = plane.getBuffer().duplicate().order(ByteOrder.LITTLE_ENDIAN);
            IntBuffer rgba = buffer.asIntBuffer();
            int stride = plane.getRowStride() / 4;
            int index = 0;
            for (int y = 0; y < frame.height; y++) {
                int offset = y * step * stride;
                for (int x = 0; x < frame.width; x++) frame.pixels[index++] = rgba.get(offset + x * step);
            }
            return frame;
        }

        void writeJpeg(ZipOutputStream zip) throws IOException {
            int[] colors = new int[pixels.length];
            for (int i = 0; i < pixels.length; i++) {
                int pixel = pixels[i];
                colors[i] = 0xff000000 | (pixel & 0xff00) | ((pixel & 0xff) << 16) | ((pixel >>> 16) & 0xff);
            }
            Bitmap bitmap = Bitmap.createBitmap(colors, width, height, Bitmap.Config.ARGB_8888);
            try {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 72, zip)) throw new IOException("JPEG encode failed");
            } finally {
                bitmap.recycle();
            }
        }
    }
}
