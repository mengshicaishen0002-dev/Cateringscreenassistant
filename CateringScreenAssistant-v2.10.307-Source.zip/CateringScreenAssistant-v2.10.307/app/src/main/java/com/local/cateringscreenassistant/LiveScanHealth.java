package com.local.cateringscreenassistant;

import java.util.concurrent.atomic.AtomicLong;

/** Fast lane only records primitives; strings and counter resets belong to diagnostics. */
final class LiveScanHealth {
    private static final java.util.function.LongBinaryOperator MAX = Math::max;
    private final AtomicLong starts=new AtomicLong(),ended=new AtomicLong();
    private final AtomicLong gapOver32=new AtomicLong(),gapOver64=new AtomicLong();
    private final AtomicLong queueOver16=new AtomicLong(),wakeOver16=new AtomicLong();
    private final AtomicLong scanOver48=new AtomicLong(),scanOver96=new AtomicLong();
    private final AtomicLong maxGap=new AtomicLong(),maxQueue=new AtomicLong();
    private final AtomicLong maxWake=new AtomicLong(),maxScan=new AtomicLong();
    private volatile long mostRecentEntry;

    void enter(long now,long queuedAt,long structuralWakeAt,long priorScanAt) {
        starts.incrementAndGet();
        mostRecentEntry=now;
        if(priorScanAt>0L && now>=priorScanAt) {
            long gap=now-priorScanAt;
            maxGap.accumulateAndGet(gap,MAX);
            if(gap>32L)gapOver32.incrementAndGet();
            if(gap>64L)gapOver64.incrementAndGet();
        }
        if(queuedAt>0L && now>=queuedAt) {
            long queue=now-queuedAt;
            maxQueue.accumulateAndGet(queue,MAX);
            if(queue>16L)queueOver16.incrementAndGet();
        }
        if(structuralWakeAt>0L && now>=structuralWakeAt) {
            long wake=now-structuralWakeAt;
            maxWake.accumulateAndGet(wake,MAX);
            if(wake>16L)wakeOver16.incrementAndGet();
        }
    }

    void finish(long elapsedMs) {
        ended.incrementAndGet();
        maxScan.accumulateAndGet(elapsedMs,MAX);
        if(elapsedMs>48L)scanOver48.incrementAndGet();
        if(elapsedMs>96L)scanOver96.incrementAndGet();
    }

    /** Called only by the independent diagnostic worker; never from Accept or Reject paths. */
    String snapshotAndReset(long now) {
        long latest=mostRecentEntry;
        return "starts="+starts.getAndSet(0L)
                +" ends="+ended.getAndSet(0L)
                +" last_start_age_ms="+(latest>0L?Math.max(0L,now-latest):"UNOBSERVED")
                +" max_start_gap_ms="+maxGap.getAndSet(0L)
                +" gaps_gt32="+gapOver32.getAndSet(0L)
                +" gaps_gt64="+gapOver64.getAndSet(0L)
                +" max_queue_ms="+maxQueue.getAndSet(0L)
                +" queue_gt16="+queueOver16.getAndSet(0L)
                +" max_wake_to_start_ms="+maxWake.getAndSet(0L)
                +" wake_gt16="+wakeOver16.getAndSet(0L)
                +" max_scan_ms="+maxScan.getAndSet(0L)
                +" scans_gt48="+scanOver48.getAndSet(0L)
                +" scans_gt96="+scanOver96.getAndSet(0L);
    }
}
