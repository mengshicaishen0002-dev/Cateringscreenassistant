package com.local.cateringscreenassistant;

/** v2.10.298: a qualified different TOP offer outranks an earlier Reject transaction. */
final class AcceptPreemptionPolicy {
    static boolean isDifferentCoherentTop(String rejected, String current) {
        return isDifferentCoherentTop(rejected, current, false);
    }

    /**
     * "liveIndexedTop" means the caller independently proved the CURRENT enabled
     * top Accept button and bound its exact amount/mileage. Only in that case can
     * a new numeric pair suffice before RN exports the merchant/time/address.
     */
    static boolean isDifferentCoherentTop(String rejected,String current,boolean liveIndexedTop) {
        // v300: a CURRENT enabled top Accept plus a DIFFERENT live numeric pair is
        // sufficient for takeover even before RN exports merchant/address. Without
        // the CURRENT action proof this is only a wake hint, never a Reject retirement.
        if (liveIndexedTop && distinctQualifiedNumericWake(rejected, current)) return true;
        if (!RejectDemandPolicy.coherent(current)) return false;
        if (!liveIndexedTop && OfferEnrichmentPolicy.pickupKey(current).isEmpty()
                && OfferEnrichmentPolicy.endpointKey(current).isEmpty()
                && CardText.orderId(current).isEmpty()) return false;
        return RejectConfirmPriorityPolicy.shouldDeferForNewTop(rejected,current)
                && !RejectDemandPolicy.sameOrUnprovenOwned(rejected,current);
    }

    /** A new numeric pair published AFTER the Reject started is a useful wake even
     * when React Native has not yet exported a merchant/address. This alone NEVER
     * retires the Reject: the caller still binds a CURRENT enabled top Accept and
     * proves that it is different before dispatching. */
    static boolean distinctQualifiedNumericWake(String oldReject, String nextEvent) {
        float oldAmount = CardText.amount(oldReject), oldMiles = CardText.miles(oldReject);
        float nextAmount = CardText.amount(nextEvent), nextMiles = CardText.miles(nextEvent);
        return oldAmount >= 0f && oldMiles >= 0f
                && nextAmount >= 0f && nextMiles >= 0f
                && (Math.abs(oldAmount - nextAmount) > 0.011f
                    || Math.abs(oldMiles - nextMiles) > 0.051f);
    }

    /** A NEW eligible event bypasses the stale Reject cooldown; repeated probes of
     * the same event retain a bounded throttle to protect the Binder worker. */
    static boolean shouldProbeNow(boolean qualifiedEvent,long eventAt,long previousEventAt,
                                  long now,long previousProbeAt) {
        if (qualifiedEvent && eventAt > 0L && eventAt != previousEventAt) return true;
        return previousProbeAt <= 0L || now < previousProbeAt || now - previousProbeAt >= 36L;
    }
    private AcceptPreemptionPolicy() { }
}
