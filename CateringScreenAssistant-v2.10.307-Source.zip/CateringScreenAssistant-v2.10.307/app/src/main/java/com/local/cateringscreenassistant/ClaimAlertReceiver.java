package com.local.cateringscreenassistant;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Explicit notification action that stops the confirmed-claim alarm. */
public final class ClaimAlertReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && ClaimSuccessAlert.ACTION_STOP.equals(intent.getAction())) {
            ClaimSuccessAlert.stop(context);
        } else if (intent != null
                && OcrMonitorService.ACTION_RESUME_MANUAL.equals(intent.getAction())) {
            OcrMonitorService.resumeAfterManualIntervention(context);
        }
    }
}
