package com.local.cateringscreenassistant;

/** Reject-only read policy: short time slices, enough cheap nodes, finite work. */
final class RejectProbePolicy {
    static long treeMs() { return 45L; }
    static int treeNodes() { return 1024; }
    static int maxReads() { return 10; }
    static long retryMs(int reads) { return Math.min(240L, 80L * Math.max(1, reads)); }
    static String limit(boolean time, boolean nodes) {
        return time ? "TIME_LIMIT" : nodes ? "NODE_LIMIT" : "NONE";
    }
    private RejectProbePolicy() { }
}
