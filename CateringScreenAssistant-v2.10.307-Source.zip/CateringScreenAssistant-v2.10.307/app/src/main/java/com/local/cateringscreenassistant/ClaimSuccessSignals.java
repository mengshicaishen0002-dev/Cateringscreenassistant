package com.local.cateringscreenassistant;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure parser for post-Accept UI evidence. Kept Android-free for regression tests. */
final class ClaimSuccessSignals {
    private static final Pattern SPACE=Pattern.compile("\\s+");
    private static final Pattern BEGIN_DELIVERY=Pattern.compile(".*\\bbegin\\s+(?:to\\s+)?delivery\\b.*");
    private static final Pattern EXACT_BEGIN_DELIVERY=Pattern.compile("^begin\\s+(?:to\\s+)?delivery$");
    private static final Pattern NO_CONFLICT=Pattern.compile(".*\\b(?:no|without)\\s+(?:(?:time|schedule|scheduling|route)\\s+)?conflicts?\\b.*");
    private static final Pattern JOBS_WORD=Pattern.compile(".*\\bjobs\\b.*");
    private static final Pattern CONFLICT=Pattern.compile(
                "(?:\\b(?:time|schedule|scheduling|route|delivery|job|order)\\b.{0,65}\\bconflict(?:s|ing)?\\b|"
                + "\\bconflict(?:s|ing)?\\b.{0,65}\\b(?:time|schedule|route|delivery|job|order)\\b|"
                + "\\b(?:overlap|overlapping|overlaps)\\b.{0,65}\\b(?:route|delivery|job|order|schedule|time)\\b|"
                + "\\b(?:route|delivery|job|order|schedule|time)\\b.{0,65}\\b(?:overlap|overlapping|overlaps)\\b)",
                Pattern.CASE_INSENSITIVE);

    private static final Pattern JOBS_BADGE = Pattern.compile("\\bjobs\\s*[:#-]?\\s*(\\d{1,3})\\b", Pattern.CASE_INSENSITIVE);
    // DeliverThat assigned-job ids look like MENDO_46474511540436997. They are not
    // shown on a normal offer card and are therefore strong post-claim evidence when
    // paired with an assigned-job control/section.
    private static final Pattern ASSIGNED_JOB_ID = Pattern.compile("\\b[a-z0-9]{2,20}_[0-9]{8,}\\b", Pattern.CASE_INSENSITIVE);

    private ClaimSuccessSignals() { }

    /**
     * Real DeliverThat builds have exported the accepted-job CTA as both "Begin Delivery" and
     * "Begin to Delivery".  Keep this parser deliberately narrow: it is a button phrase, not a
     * generic occurrence of the words begin/delivery in an offer description.
     */
    static boolean hasBeginDeliveryControl(String raw) {
        String lower = normalize(raw);
        return BEGIN_DELIVERY.matcher(lower).matches();
    }

    /** Exact visible CTA label; live Accessibility callers separately prove foreground visibility. */
    static boolean isExactBeginDeliveryControl(String raw) {
        return EXACT_BEGIN_DELIVERY.matcher(normalize(raw)).matches();
    }

    static String normalize(String raw) {
        if (raw == null) return "";
        return SPACE.matcher(raw.toLowerCase(Locale.US)).replaceAll(" ").trim();
    }

    static boolean hasAcceptedJobDetail(String raw) {
        String lower = normalize(raw);
        if (lower.isEmpty()) return false;
        // Field evidence: after a successful claim DeliverThat replaces the offer card with
        // the assigned-job detail view containing these labels. Require a pair, not one lone
        // generic word, so an offer description cannot accidentally confirm a claim.
        boolean timeline = lower.contains("delivery timeline");
        boolean instructions = lower.contains("dropoff instructions")
                || lower.contains("pickup instructions")
                || lower.contains("delivery instructions");
        // DeliverThat's accepted-job detail view is not consistent across builds. Some
        // versions omit "Delivery Timeline" but expose accounting/approval metadata that never
        // belongs to an offer card. Requiring instructions plus two independent job-only fields
        // blocks the real-device false-positive seen after a successful claim without treating a
        // normal offer note containing the word "instructions" as a completed job.
        int jobMeta = 0;
        if (lower.contains("approver name")) jobMeta++;
        if (lower.contains("nuid")) jobMeta++;
        if (lower.contains("gl string")) jobMeta++;

        // v2.10.42: current DeliverThat builds may show the assigned-job page as
        // Begin Delivery + Delivery Timeline + a merchant order id, without any
        // pickup/dropoff-instructions label.  This exact layout was observed in the
        // field after a successful claim.  Require paired job-only evidence so a
        // normal offer card containing generic delivery wording cannot confirm itself.
        boolean beginDelivery = hasBeginDeliveryControl(lower);
        boolean assignedId = ASSIGNED_JOB_ID.matcher(lower).find();
        boolean assignedJobLayout = (beginDelivery && (timeline || assignedId))
                || (timeline && assignedId);

        return assignedJobLayout || (timeline && instructions)
                || (instructions && jobMeta >= 2);
    }

    static boolean isTimeConflict(String hint) {
        return normalize(hint).startsWith("time_conflict:");
    }

    static String timeConflictHint(String raw) {
        if (raw==null) return "";
        String lower=raw.toLowerCase(Locale.US);
        if (!lower.contains("conflict") && !lower.contains("overlap")) return "";
        if (NO_CONFLICT.matcher(lower).matches()) return "";
        String text=SPACE.matcher(raw).replaceAll(" ").trim();
        Matcher conflict=CONFLICT.matcher(text);
        if (!conflict.find()) return "";
        // Keep a bounded original-case excerpt around the actual conflict phrase, not the
        // whole page (which can contain addresses and customer instructions).
        int start=Math.max(0,conflict.start()-50),end=Math.min(text.length(),conflict.end()+100);
        return "TIME_CONFLICT: "+text.substring(start,end);
    }

    static String extractOutcomeHint(String raw) {
        String lower = normalize(raw);
        if (lower.isEmpty()) return "";
        String conflict=timeConflictHint(raw);
        if (!conflict.isEmpty()) return conflict;
        if (hasAcceptedJobDetail(lower)) {
            if (hasBeginDeliveryControl(lower)) return "Begin Delivery/assigned Job";
            if (ASSIGNED_JOB_ID.matcher(lower).find()) return "Assigned Job ID/Delivery Timeline";
            return "Delivery Timeline/Dropoff Instructions";
        }
        String[] phrases = new String[]{
                "successfully accepted", "job accepted", "delivery accepted", "offer accepted",
                "assigned to you", "you are assigned",
                "assigned to another driver", "job already assigned",
                "offer unavailable", "no longer available", "already claimed",
                "claimed by another", "someone else claimed", "unable to accept",
                "failed to accept", "something went wrong", "try again", "error"
        };
        for (String phrase : phrases) if (lower.contains(phrase)) return phrase;
        return "";
    }

    /** Diagnostic excerpt only: never supplies a terminal classification or click permission. */
    static String outcomeExcerpt(String raw) {
        String hint=extractOutcomeHint(raw);
        if (hint.isEmpty()) return "";
        if (isTimeConflict(hint)) return hint.substring("TIME_CONFLICT: ".length());
        String text=SPACE.matcher(raw).replaceAll(" ").trim();
        int at=text.toLowerCase(Locale.US).indexOf(hint.toLowerCase(Locale.US));
        if (at<0) return "";
        return text.substring(Math.max(0,at-40),Math.min(text.length(),at+hint.length()+160));
    }

    static boolean isPositive(String hint) {
        if (isTimeConflict(hint)) return false;
        String lower = normalize(hint);
        return lower.contains("accepted") || lower.contains("assigned to you")
                || lower.contains("you are assigned")
                || lower.contains("delivery timeline/dropoff instructions")
                || lower.contains("assigned job id/delivery timeline")
                || lower.contains("begin delivery/assigned job");
    }

    /** Job-detail hints are strong UI evidence, but must still be tied to the live Accept. */
    static boolean isJobDetailHint(String hint) {
        String lower = normalize(hint);
        return lower.contains("delivery timeline/dropoff instructions")
                || lower.contains("assigned job id/delivery timeline")
                || lower.contains("begin delivery/assigned job");
    }

    /**
     * Bind an accepted-job detail surface to the offer that was just clicked.  DeliverThat keeps
     * pay/distance/pickup time on the assigned-job page in current builds.  completionKey ignores
     * merchant/body churn but requires those three independent values, preventing an already-open
     * unrelated Job page from confirming a fresh Accept transaction.
     */
    static boolean acceptedJobMatchesOffer(String offerText, String jobDetailText) {
        // A live exact Begin Delivery button is sufficient assigned-job evidence when the
        // page still carries the exact amount + mileage + scheduled time from this Accept.
        // TapAccessibilityService proves the CTA is a current actionable node before caching
        // this text; the three-field completion key prevents an unrelated open Job from binding.
        if (!hasAcceptedJobDetail(jobDetailText)
                && !hasBeginDeliveryControl(jobDetailText)) return false;
        String offerKey = CardText.completionKey(offerText);
        String jobKey = CardText.completionKey(jobDetailText);
        return !offerKey.isEmpty() && offerKey.equals(jobKey);
    }

    static boolean isTerminalNegative(String hint) {
        String lower = normalize(hint);
        return isTimeConflict(hint) || lower.contains("offer unavailable") || lower.contains("no longer available")
                || lower.contains("assigned to another driver") || lower.contains("job already assigned")
                || lower.contains("already claimed") || lower.contains("claimed by another")
                || lower.contains("someone else claimed") || lower.contains("unable to accept")
                || lower.contains("failed to accept");
    }

    /** -1 = Jobs tab not observed, 0 = Jobs tab observed with no badge, >0 = badge value. */
    static int jobsBadgeCount(String raw) {
        String lower = normalize(raw).replace(',', ' ').replace('|', ' ');
        if (!JOBS_WORD.matcher(lower).matches()) return -1;
        Matcher m = JOBS_BADGE.matcher(lower);
        if (!m.find()) return 0;
        try { return Integer.parseInt(m.group(1)); }
        catch (NumberFormatException ignored) { return -1; }
    }

    static boolean jobsBadgeIncreased(int before, int after) {
        return before >= 0 && after >= 0 && after > before;
    }
}
