package com.local.cateringscreenassistant;

/** Pure timing/variant policy for the DeliverThat action dispatcher. */
final class ActionDispatchPolicy {
    private ActionDispatchPolicy() { }

    // Retained for backward regression visibility; semantic-first is no longer on the fast path.
    static long semanticObserveDelayMs() { return 85L; }

    static final long RETRY_RECHECK_MS = 50L;

    static boolean retryInFlight(long now,long startedAt) {
        // v300: callbacks sometimes never arrive. Let a same-transaction watchdog
        // re-enter pressure at 160ms; terminal/spinner/ownership gates remain.
        return startedAt>0 && now>=startedAt && now-startedAt<160L;
    }

    static boolean previousGestureFinished(long now, long completedAt) {
        return completedAt > 0L && now >= completedAt;
    }

    static long processingRecheckDelayMs(long elapsed,boolean first) {
        long deadline=first?firstProcessingRecheckMs():processingTreeRecheckMs();
        return Math.max(1L,Math.min(processingPollMs(),deadline-elapsed));
    }
    static long firstProcessingRecheckMs() { return RETRY_RECHECK_MS; }
    static boolean useFastProcessingWindow(int checks) { return checks>0 && checks<=3; }

    static long processingPollMs() { return 60L; }

    // v2.10.26: once Accept is visibly disabled/processing, do not rebuild the full
    // Accessibility tree every poll. Cached success/failure events remain immediate; one
    // coherent tree recheck per quiet window is enough to detect rollback/retry state.
    static long processingTreeRecheckMs() { return 240L; }

    static int processingMaxChecks() { return 16; }

    // Preserve the persisted v301 sequential value (2). Retired values 1/3
    // migrate to the single-tap + existing independent retry mode.
    static final int SINGLE = 0, SEQUENTIAL = 2;
    static int gestureMode(int value) { return value == SEQUENTIAL ? SEQUENTIAL : SINGLE; }
    static int gestureSelection(int stored) { return gestureMode(stored) == SEQUENTIAL ? 1 : 0; }
    static int gestureModeForSelection(int selection) { return selection == 1 ? SEQUENTIAL : SINGLE; }
    static long firstStrokeMs(int mode) { return 12L; }
    static long firstStrokeStartMs(int mode, int stroke, long duration) {
        return gestureMode(mode) == SEQUENTIAL ? stroke * (duration + 1L) : 0L;
    }
    static long firstStrokeTotalMs(int mode, long duration) {
        return gestureMode(mode) == SEQUENTIAL ? 3L * duration + 2L : duration;
    }
    static long initialOutcomeReadDelayMs(boolean pressureActive, long callAt, long now) {
        return pressureActive && callAt > 0L && now >= callAt ? Math.max(0L, 300L - (now - callAt)) : 0L;
    }

    static long firstGestureDurationMs(boolean accept) {
        // Short strokes apply only to freshly verified Accept controls.
        return accept ? 12L : 55L;
    }

    // v2.10.17: Galaxy A15 real-device traces showed successful dispatchGesture callbacks
    // while DeliverThat left Ignore enabled and the card unchanged. Reject now tries a
    // live Accessibility ACTION_CLICK first, then verifies the same card before a slower
    // gesture fallback within the same logical Reject attempt.
    static long rejectSemanticSettleMs() { return 160L; }

    static long rejectFallbackGestureDurationMs() { return 90L; }

    static long retryGestureDurationMs(int attempt) {
        return 12L;
    }

    static int retryVariant(int attempt) {
        return attempt >= 3 ? 1 : 0;
    }
}
