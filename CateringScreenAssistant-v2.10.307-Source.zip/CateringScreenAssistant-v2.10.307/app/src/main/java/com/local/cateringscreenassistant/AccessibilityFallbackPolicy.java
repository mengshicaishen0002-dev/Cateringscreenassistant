package com.local.cateringscreenassistant;

/**
 * v2.10.26 OCR arbitration.
 *
 * Once a coherent Accessibility snapshot contains every rule-sensitive field and the
 * side-specific action rectangle for the current top card, OCR cannot make a disabled,
 * processing, retry-gated or budget-gated button safer to click. Keep Accessibility as
 * owner of that frame and reserve OCR for genuinely incomplete/missing action evidence.
 */
final class AccessibilityFallbackPolicy {
    private AccessibilityFallbackPolicy() { }

    /** Only an older OCR frame yields to a newer readable Accessibility decision. */
    static boolean shouldYieldOcrFrame(long frameAt,long readableAt,long now) {
        if(readableAt<=0L) return false;
        if(frameAt<=0L || frameAt>now || now<readableAt) return true;
        return frameAt<readableAt && now-readableAt<500L;
    }

    static boolean accessibilityOwnsFrame(boolean decisionComplete, boolean expectedActionAnchored) {
        return decisionComplete && expectedActionAnchored;
    }

    static boolean shouldRunOcrFallback(boolean decisionComplete, boolean expectedActionAnchored) {
        return !accessibilityOwnsFrame(decisionComplete, expectedActionAnchored);
    }
}
