package com.local.cateringscreenassistant;

final class PageGuard {
    enum Page { OFFERS, IGNORED, JOBS, UNKNOWN }

    /** Explicit Jobs/Ignored empty-state sentence; no Binder call or regex for ordinary events. */
    static Page explicitEmptyOtherTabText(String text) {
        if (text == null || text.length() < 18) return Page.UNKNOWN;
        // Nearly every offer, price and button event exits here; do not allocate/normalize
        // on the time-critical Accessibility callback for unrelated content.
        if (text.indexOf("jobs") < 0 && text.indexOf("Jobs") < 0
                && text.indexOf("ignored") < 0 && text.indexOf("Ignored") < 0)
            return Page.UNKNOWN;
        String lower = text.toLowerCase(java.util.Locale.US).replace('’', '\'')
                .replaceAll("\\s+", " ");
        return explicitEmptyOtherTabNormalized(lower);
    }

    /** A tab click is only a navigation wake hint, never permission to tap. */
    static Page clickedDeliveriesTab(String raw) {
        if(raw==null || raw.length()>64) return Page.UNKNOWN;
        String label=raw.trim().toLowerCase(java.util.Locale.US);
        if(label.equals("jobs")) return Page.JOBS;
        if(label.equals("ignored")) return Page.IGNORED;
        return Page.UNKNOWN;
    }

    static Page emptyDeliveriesTab(String text) {
        if (text == null) return Page.UNKNOWN;
        String lower = text.toLowerCase(java.util.Locale.US).replace('’', '\'')
                .replaceAll("\\s+", " ");
        if (!lower.contains("deliveries") || !lower.contains("jobs") || !lower.contains("offers"))
            return Page.UNKNOWN;
        return explicitEmptyOtherTabNormalized(lower);
    }

    private static Page explicitEmptyOtherTabNormalized(String lower) {
        if (lower.contains("you don't have any jobs") || lower.contains("you do not have any jobs"))
            return Page.JOBS;
        if (lower.contains("you don't have any ignored offers")
                || lower.contains("you do not have any ignored offers"))
            return Page.IGNORED;
        return Page.UNKNOWN;
    }

    static Page classify(boolean ignoredSelected, boolean jobsSelected, boolean offersSelected,
                         boolean restoreVisible, boolean rejectVisible,
                         boolean acceptVisible, boolean emptyOffersVisible) {
        // Explicit non-offer states always win. This prevents a stale/background action
        // node from accidentally authorizing a click while Jobs/Ignored is active.
        if (ignoredSelected || restoreVisible) return Page.IGNORED;
        if (jobsSelected) return Page.JOBS;

        // DeliverThat does not consistently expose the Offers tab as selected on every
        // Android/WebView build. Treat either action button, or the empty-state text,
        // as positive evidence that the user is on the Offers page.
        return offersSelected || rejectVisible || acceptVisible || emptyOffersVisible
                ? Page.OFFERS : Page.UNKNOWN;
    }
}
