package com.local.cateringscreenassistant;

/** Diagnostic ledger only; never controls a tap, retry, success or navigation. */
final class AcceptAttemptAudit {
    private long owner, first, last;
    private int sends;
    private long controlEnabled=-1L,controlDisabled=-1L;
    private String controlState="UNOBSERVED";
    private String text="";
    synchronized void begin(long actionAt,String offer) {
        owner=actionAt;text=offer==null?"":offer;first=last=0;sends=0;
        controlEnabled=controlDisabled=-1L;controlState="UNOBSERVED";
    }
    synchronized void dispatched(long actionAt,long at) {
        if (owner!=actionAt || actionAt<=0 || at<actionAt) return;
        if (sends==0) first=at;
        last=at;sends++;
    }
    synchronized void observedControl(long actionAt,String state,long at) {
        if(owner!=actionAt || sends==0 || at<first || state==null) return;
        controlState=state;
        if(("ENABLED".equals(state) || "ENABLED_RECOVERED".equals(state))
                && (controlEnabled<0L || at<controlEnabled)) controlEnabled=at;
        if("DISABLED".equals(state) && (controlDisabled<0L || at<controlDisabled)) controlDisabled=at;
    }
    synchronized int sendsFor(long actionAt) { return owner==actionAt?sends:0; }
    synchronized String summary(String offer,PageOutcomePolicy.Tracker tracker) {
        if (sends==0 || text.isEmpty() || !CardText.identity(text).equals(CardText.identity(offer))) return "";
        return summary(owner,offer,tracker);
    }
    synchronized String summary(long expectedOwner,String offer,PageOutcomePolicy.Tracker tracker) {
        if(expectedOwner<=0L || owner!=expectedOwner || sends==0 || text.isEmpty()
                || !OfferEnrichmentPolicy.sameTransaction(text,offer)) return "";
        String out="；TX="+owner+",dispatchCount="+sends+",FIRST_DISPATCH_ELAPSED="+first
                +",LAST_DISPATCH_ELAPSED="+last;
        if (tracker!=null && tracker.dispatch>=owner && tracker.dispatch<=first
                && OfferEnrichmentPolicy.sameTransaction(tracker.expected,text)) out+="；"+tracker.audit(controlEnabled,controlDisabled)+",CONTROL_NODE="+controlState;
        return out;
    }
}
