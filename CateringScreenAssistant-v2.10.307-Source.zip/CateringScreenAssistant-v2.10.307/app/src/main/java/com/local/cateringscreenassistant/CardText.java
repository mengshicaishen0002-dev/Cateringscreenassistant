package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

final class CardText {
    // Pure immutable text facts only: never UI enabledness, windows or freshness.
    static final class ParseFacts {
        float amount=Float.NaN,miles=Float.NaN;
        String identity,orderId,pickup,endpoint,rejectEndpoint,stable,completion,rejectTail;
        Boolean multipleMileageRows, conflictingAddresses;
    }
    private static final ThreadLocal<java.util.LinkedHashMap<String,ParseFacts>> PARSE_FACTS=
            ThreadLocal.withInitial(java.util.LinkedHashMap::new);
    static ParseFacts parseFacts(String text) {
        if(text!=null && text.length()>8192) return new ParseFacts();
        java.util.LinkedHashMap<String,ParseFacts> cache=PARSE_FACTS.get();
        ParseFacts facts=cache.get(text);
        if(facts==null) {
            if(cache.size()>=32) cache.remove(cache.keySet().iterator().next());
            facts=new ParseFacts();cache.put(text,facts);
        }
        return facts;
    }

    // A display-precision key for timing metrics only. Never used to authorize an action.
    static long numericTimingKey(float amount, float miles) {
        long cents = Math.round((double) amount * 100.0);
        long hundredthsOfMile = Math.round((double) miles * 100.0);
        return (cents << 32) | (hundredthsOfMile & 0xffffffffL);
    }

    private static final Pattern WHITESPACE = Pattern.compile("\\s+");
    static final Pattern MONEY = Pattern.compile("(?:\\$|USD\\s*)\\s*\\d", Pattern.CASE_INSENSITIVE);
    static final Pattern MILES = Pattern.compile("\\d(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern ACTION_WORDS = Pattern.compile(
            "\\b(?:accept|claim|ignore|decline|reject)(?:\\s+button)?\\b|\\bbutton\\s+(?:accept|claim|ignore|decline|reject)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPIRES_CLOCK = Pattern.compile(
            "\\bexpires(?:\\s+in)?\\s*:?\\s*\\d{1,2}:\\d{2}(?::\\d{2})?\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPIRES_SECONDS = Pattern.compile(
            "\\bexpires(?:\\s+in)?\\s*:?\\s*\\d+\\s*(?:s|sec|secs|second|seconds)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY_VALUE = Pattern.compile(
            "(?:\\$|usd\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MILES_VALUE = Pattern.compile(
            "(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    // Repair only an explicit numeric split zero ("0 8 mi" -> "0.8 mi").  A letter O is
    // ambiguous punctuation emitted between UI columns: the real trace "O 4 mi" meant 4 mi,
    // not 0.4 mi. Fresh Accessibility evidence can still supply a true decimal value.
    private static final Pattern OCR_SPLIT_DECIMAL_MILES = Pattern.compile(
            "(?<![A-Za-z0-9])0\\s+([1-9])\\s*((?:mi|miles?))\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern OFFER_TIME_VALUE = Pattern.compile(
            "\\b((?:today|tomorrow)|(?:january|february|march|april|may|june|july|august|september|october|november|december)\\s+\\d{1,2})"
                    + "\\s*(?:at)?\\s*(\\d{1,2}:\\d{2})\\s*(am|pm)\\b", Pattern.CASE_INSENSITIVE);
    // A zone caption belongs to the pickup label, never to the merchant. Match only
    // immediately after a complete supported pickup time; preserve names such as PDT Cafe.
    private static final Pattern PICKUP_ZONE_SUFFIX = Pattern.compile(
            "(" + OFFER_TIME_VALUE.pattern() + ")[\\s,]*(?:PDT|PST|PT|EDT|EST|ET|CDT|CST|CT|MDT|MST|MT|UTC|GMT)\\b(?=\\s*(?:,|$|\\n))[\\s,]*",
            Pattern.CASE_INSENSITIVE);
    static String withoutPickupZone(String text) {
        return text == null ? "" : PICKUP_ZONE_SUFFIX.matcher(text).replaceAll("$1 ");
    }
    // DeliverThat exposes provider/order tokens such as burq_3744670, d_01m2nnqx9..., 
    // GOP_DT_LSRQ302 and MENDO_46474511540436997. Prefer these immutable ids over card hashes.
    private static final Pattern ORDER_ID_TOKEN = Pattern.compile(
            "\\b[a-z][a-z0-9]{0,15}_[a-z0-9][a-z0-9_-]{5,}\\b", Pattern.CASE_INSENSITIVE);

    // A second named pickup is not a route destination. Bare/labelled destination
    // addresses remain allowed; repeated parent/child exports of one pickup are harmless.
    private static final Pattern PICKUP_BULLET_ADDRESS = Pattern.compile(
            "•\\s*\\d{1,6}\\s+[^•\\n]+?\\b(?:ca|california)\\s+\\d{5}(?:-\\d{4})?\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PICKUP_COUNTRY = Pattern.compile(
            "(?i)^\\s*[,;:.]*\\s*(?:(?:united states(?: of america)?|usa|us)\\b[,;:. ]*)?");
    private static final Pattern PICKUP_DISPLAY_NOISE = Pattern.compile(
            "(?:\\$|usd\\s*)\\s*\\d+(?:[.,]\\d+)?(?:\\s*[-–—]\\s*\\$?\\d+(?:[.,]\\d+)?)?"
                    + "|\\d+(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b|\\([^)]*\\)"
                    + "|\\b(?:est|large order|accept|claim|ignore|decline|reject)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern ROUTE_DESTINATION = Pattern.compile(
            "(?i)\\b(?:drop\\s*off|deliver(?:y| to)?|destination)\\b");
    private static final Pattern PICKUP_KEY_NOISE = Pattern.compile("[^a-z0-9]+");

    private static final class BooleanMemo {
        final String text; final boolean value;
        BooleanMemo(String text,boolean value) {this.text=text;this.value=value;}
    }
    private static final ThreadLocal<BooleanMemo> PICKUP_MEMO=new ThreadLocal<>();
    private static final ThreadLocal<BooleanMemo> NUMERIC_MEMO=new ThreadLocal<>();
    private static boolean memoizedConflict(String text,boolean pickup) {
        ThreadLocal<BooleanMemo> cache=pickup?PICKUP_MEMO:NUMERIC_MEMO;
        BooleanMemo memo=cache.get();
        if(memo!=null && memo.text.equals(text)) return memo.value;
        boolean result=pickup?computeConflictingPickupEvidence(text):computeConflictingOfferNumbers(text);
        if(text!=null && text.length()<=8192) cache.set(new BooleanMemo(text,result));
        return result;
    }

    /** Local identity ambiguity check, not a rule threshold or a permission to tap. */
    static boolean containsConflictingPickupEvidence(String text) {
        return memoizedConflict(text,true);
    }
    private static boolean computeConflictingPickupEvidence(String text) {
        if (text == null || text.isEmpty()) return false;
        java.util.regex.Matcher times = OFFER_TIME_VALUE.matcher(text);
        String firstTime = "";
        while (times.find()) {
            String key = (times.group(1) + times.group(2) + times.group(3))
                    .toLowerCase(Locale.US).replaceAll("\\s+", "");
            if (!firstTime.isEmpty() && !firstTime.equals(key)) return true;
            firstTime = key;
        }
        if (text.indexOf('•') < 0 || text.indexOf('•', text.indexOf('•') + 1) < 0) return false;
        java.util.regex.Matcher addresses = PICKUP_BULLET_ADDRESS.matcher(text);
        String firstPickup = "";
        int previousEnd = 0;
        while (addresses.find()) {
            String prefix = withoutPickupZone(text.substring(previousEnd, addresses.start()));
            previousEnd = addresses.end();
            java.util.regex.Matcher pickupTime = OFFER_TIME_VALUE.matcher(prefix);
            int start = 0;
            while (pickupTime.find()) start = pickupTime.end();
            prefix = PICKUP_COUNTRY.matcher(prefix.substring(start)).replaceFirst("");
            if (ROUTE_DESTINATION.matcher(prefix).find()) continue;
            prefix = PICKUP_DISPLAY_NOISE.matcher(prefix).replaceAll(" ");
            String merchant = PICKUP_KEY_NOISE.matcher(prefix.toLowerCase(Locale.US)).replaceAll("");
            if (merchant.isEmpty()) continue; // unlabelled route address, not another merchant
            String address = PICKUP_KEY_NOISE.matcher(addresses.group().toLowerCase(Locale.US)).replaceAll("");
            String key = merchant + "|" + address;
            if (!firstPickup.isEmpty() && !firstPickup.equals(key)) return true;
            firstPickup = key;
        }
        return false;
    }

    static final class Piece {
        final String text;
        final float left, top, bottom;
        Piece(String text, float left, float top, float bottom) {
            this.text = text; this.left = left; this.top = top; this.bottom = bottom;
        }
    }

    static String aboveButton(List<Piece> pieces, float buttonTop, float buttonBottom) {
        // Use the previous action row as the hard upper-card boundary. Without this,
        // if the current card temporarily loses its amount/distance accessibility node,
        // v2.7 could accidentally reuse numbers from the card above it.
        float previousActionBottom = Float.NEGATIVE_INFINITY;
        for (Piece p : pieces) {
            if (p.bottom < buttonTop && ACTION_WORDS.matcher(p.text).find())
                previousActionBottom = Math.max(previousActionBottom, p.bottom);
        }
        Piece pay = null, miles = null;
        for (Piece p : pieces) {
            if (p.bottom > buttonTop || p.top < previousActionBottom) continue;
            // React Native can expose one broad parent description containing two adjacent
            // offers during a list transition.  Such a node has multiple mileage rows and is
            // not card-local evidence; using its first amount and first mileage can cross-pair
            // two different cards.  Ignore the broad parent and rebuild from its card-local
            // children.  A normal amount range still has exactly one mileage row.
            if (containsMultipleMileageRows(p.text)) continue;
            if (MONEY.matcher(p.text).find() && (pay == null || p.top > pay.top)) pay = p;
            if (MILES.matcher(p.text).find() && (miles == null || p.top > miles.top)) miles = p;
        }
        if (pay == null || miles == null) return "";
        float rowHeight = Math.max(pay.bottom - pay.top, miles.bottom - miles.top);
        if (Math.abs(pay.top - miles.top) > Math.max(8, rowHeight * 2)) return "";
        float start = Math.min(pay.top, miles.top);
        List<Piece> sorted = new ArrayList<>(pieces);
        sorted.sort(Comparator.comparingDouble((Piece p) -> p.top).thenComparingDouble(p -> p.left));
        StringBuilder out = new StringBuilder();
        // The button row is UI state, not order content. Excluding it prevents a
        // transient Accept/Decline disabled/label change from changing card identity.
        float contentEnd = buttonTop + 2f;
        for (Piece p : sorted) {
            if (p.top < start || p.bottom > contentEnd) continue;
            String candidate = p.text == null ? "" : WHITESPACE.matcher(p.text).replaceAll(" ").trim();
            if (candidate.isEmpty()) continue;
            if (containsMultipleMileageRows(candidate)) continue;
            // React-Native frequently exports one parent contentDescription containing the
            // whole card and then exports its child labels again. If a later child phrase is
            // already present verbatim in the accumulated parent text, appending it only
            // bloats identity/logging and makes the next comparison more expensive.
            if (out.indexOf(candidate) >= 0) continue;
            out.append(candidate).append(' ');
        }
        String assembled = out.toString().trim();
        // React Native can briefly publish two independent sets of card-local children at
        // identical screen coordinates while FlatList swaps rows.  The broad-parent guard
        // above cannot catch that shape because every individual child contains only one
        // value.  Never let a flattened composite become an actionable card: duplicated copies
        // of the SAME value are harmless, but two distinct pays or mileages prove cross-card
        // contamination.  The caller will immediately retry on the next generation/OCR frame.
        return containsConflictingOfferNumbers(assembled)
                || containsConflictingPickupEvidence(assembled) ? "" : assembled;
    }

    /** Only the nearest numeric row and its immediate overlapping/adjacent fragments.
     * A distant old row above the card is not a conflicting value for this action. */
    static String numericScopeAboveButton(List<Piece> pieces,float buttonTop) {
        float previous=Float.NEGATIVE_INFINITY;
        for(Piece p:pieces) if(p.bottom<buttonTop && ACTION_WORDS.matcher(p.text).find())
            previous=Math.max(previous,p.bottom);
        Piece pay=null,mileage=null;
        for(Piece p:pieces) {
            if(p.bottom>buttonTop || p.top<previous || containsMultipleMileageRows(p.text)) continue;
            if(MONEY.matcher(p.text).find() && (pay==null || p.top>pay.top)) pay=p;
            if(MILES.matcher(p.text).find() && (mileage==null || p.top>mileage.top)) mileage=p;
        }
        if(pay==null || mileage==null) return "";
        float row=Math.max(pay.bottom-pay.top,mileage.bottom-mileage.top);
        float start=Math.max(previous,Math.min(pay.top,mileage.top)-Math.max(8f,row*2f));
        StringBuilder out=new StringBuilder();
        for(Piece p:pieces) if(p.top>=start && p.bottom<=buttonTop+2f
                && !containsMultipleMileageRows(p.text)) out.append(p.text).append('\n');
        return out.toString();
    }

    static String numericConflictSummary(String text) {
        java.util.Set<String> pay=new java.util.LinkedHashSet<>(),miles=new java.util.LinkedHashSet<>();
        java.util.regex.Matcher money=MONEY_VALUE.matcher(text),distance=MILES_VALUE.matcher(text);
        while(money.find()) {pay.add(normalizeNumber(money.group(1)));if(pay.size()>=4) break;}
        while(distance.find()) {miles.add(normalizeNumber(distance.group(1)));if(miles.size()>=4) break;}
        return "pay="+pay+",mi="+miles;
    }

    /** True only for a page/parent blob that contains more than one offer distance row. */
    static boolean containsMultipleMileageRows(String text) {
        if (text == null || text.isEmpty()) return false;
        ParseFacts facts = parseFacts(text);
        if (facts.multipleMileageRows == null) {
            java.util.regex.Matcher matcher = MILES_VALUE.matcher(text.replace(',', '.'));
            facts.multipleMileageRows = matcher.find() && matcher.find();
        }
        return facts.multipleMileageRows;
    }

    /** True when flattened text contains numeric evidence from more than one distinct offer. */
    static boolean containsConflictingOfferNumbers(String text) {
        return memoizedConflict(text,false);
    }
    private static boolean computeConflictingOfferNumbers(String text) {
        if (text == null || text.isEmpty()) return false;
        String normalized = text.replace(',', '.');
        return hasDistinctValues(MONEY_VALUE.matcher(normalized))
                || hasDistinctValues(MILES_VALUE.matcher(normalized));
    }

    private static boolean hasDistinctValues(java.util.regex.Matcher values) {
        if (!values.find()) return false;
        String first = values.group(1);
        if (!values.find()) return false;
        String normalizedFirst = normalizeNumber(first);
        do {
            if (!normalizedFirst.equals(normalizeNumber(values.group(1)))) return true;
        } while (values.find());
        return false;
    }

    private static String normalizeNumber(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        try { return Float.toString(Float.parseFloat(raw.replace(',', '.'))); }
        catch (NumberFormatException ignored) { return raw; }
    }

    /** Parse the first/low-end offer amount once for decision-ready snapshots. */
    static boolean knownJobFieldsAgree(String offer,String job) {
        if(CardText.containsConflictingOfferNumbers(job)) return false;
        float a=CardText.amount(offer),b=CardText.amount(job);
        if(a>=0 && b>=0 && Math.abs(a-b)>0.001f) return false;
        a=CardText.miles(offer);b=CardText.miles(job);
        if(a>=0 && b>=0 && Math.abs(a-b)>0.001f) return false;
        String x=CardText.completionKey(offer),y=CardText.completionKey(job);
        x=x.substring(Math.max(0,x.indexOf("|time=")));y=y.substring(Math.max(0,y.indexOf("|time=")));
        if(x.length()>6 && y.length()>6 && !x.equals(y)) return false;
        x=CardText.orderId(offer);y=CardText.orderId(job);
        return x.isEmpty() || y.isEmpty() || x.equals(y);
    }
    static float amount(String text) {
        ParseFacts f=parseFacts(text);
        if(Float.isNaN(f.amount)) f.amount=amountUncached(text);
        return f.amount;
    }

    private static float amountUncached(String text) {
        if (text == null) return -1f;
        java.util.regex.Matcher m = MONEY_VALUE.matcher(text.replace(',', '.'));
        if (!m.find()) return -1f;
        try { return Float.parseFloat(m.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    /** Parse DeliverThat delivery distance once for decision-ready snapshots. */
    static float miles(String text) {
        ParseFacts f=parseFacts(text);
        if(Float.isNaN(f.miles)) f.miles=milesUncached(text);
        return f.miles;
    }

    private static float milesUncached(String text) {
        if (text == null) return -1f;
        java.util.regex.Matcher m = MILES_VALUE.matcher(text.replace(',', '.'));
        if (!m.find()) return -1f;
        try { return Float.parseFloat(m.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    /** Normalize ML Kit's unambiguous numeric split-zero mileage before rule evaluation. */
    static String normalizeOcrSplitDecimalMiles(String text) {
        if (text == null || text.isEmpty()) return text;
        java.util.regex.Matcher m = OCR_SPLIT_DECIMAL_MILES.matcher(text);
        if (!m.find()) return text;
        String replacement = "0." + m.group(1) + " " + m.group(2);
        return m.replaceFirst(java.util.regex.Matcher.quoteReplacement(replacement));
    }

    private static final class IdentityMemo {
        final String text, value;
        IdentityMemo(String text,String value) {this.text=text;this.value=value;}
    }
    private static final ThreadLocal<IdentityMemo> IDENTITY_MEMO=new ThreadLocal<>();
    static String identity(String text) {
        ParseFacts f=parseFacts(text);
        if(f.identity==null) f.identity=identityUncached(text);
        return f.identity;
    }

    private static String identityUncached(String text) {
        IdentityMemo memo=IDENTITY_MEMO.get();
        if(memo!=null && memo.text.equals(text)) return memo.value;
        String result=computeIdentity(text);
        // Cache immutable input/output only; no UI evidence or permission is cached here.
        if(text!=null && text.length()<=8192) IDENTITY_MEMO.set(new IdentityMemo(text,result));
        return result;
    }
    private static String computeIdentity(String text) {
        String stable = normalizeStable(text);
        if (stable.isEmpty()) return stable;
        String money = captured(MONEY_VALUE, stable);
        String miles = captured(MILES_VALUE, stable);
        if (money.isEmpty() || miles.isEmpty()) return stable;

        String time = "";
        java.util.regex.Matcher tm = OFFER_TIME_VALUE.matcher(stable);
        int tailStart = -1;
        if (tm.find()) {
            time = tm.group(1).toLowerCase(Locale.US).replaceAll("\\s+", "") + "-"
                    + tm.group(2).toLowerCase(Locale.US) + tm.group(3).toLowerCase(Locale.US);
            tailStart = tm.end();
        }
        String merchant = merchantKey(stable, tailStart);
        return "pay=" + money + "|mi=" + miles + "|time=" + time + "|merchant=" + merchant;
    }

    /**
     * v2.10.31 coarse completion alias used ONLY to invalidate callbacks from an offer that has
     * already been accepted. It intentionally excludes merchant/detail text because DeliverThat
     * replaces the offer body with internal job-detail strings immediately after success.
     * Fresh offer dispatch never uses this coarse key, so two later offers with the same numbers
     * are not merged by the action engine.
     */
    static String completionKey(String text) {
        ParseFacts f=parseFacts(text);
        if(f.completion==null) f.completion=completionKeyUncached(text);
        return f.completion;
    }
    private static String completionKeyUncached(String text) {
        String stable = normalizeStable(text);
        if (stable.isEmpty()) return "";
        String money = captured(MONEY_VALUE, stable);
        String miles = captured(MILES_VALUE, stable);
        if (money.isEmpty() || miles.isEmpty()) return "";
        String time = "";
        java.util.regex.Matcher tm = OFFER_TIME_VALUE.matcher(stable);
        if (tm.find()) {
            time = tm.group(1).toLowerCase(Locale.US).replaceAll("\\s+", "") + "-"
                    + tm.group(2).toLowerCase(Locale.US) + tm.group(3).toLowerCase(Locale.US);
        }
        return "pay=" + money + "|mi=" + miles + "|time=" + time;
    }

    /**
     * Stable identity for an offer-looking OCR frame whose action row is not yet anchored.
     *
     * The full OCR frame is deliberately unsuitable here: DeliverThat's map labels move and
     * flicker between frames (for example Studio City / Glendale / Calabasas), even though the
     * physical offer has not changed.  Amount + distance + pickup time are the stable fields we
     * can safely use for short-lived retry/log coalescing.  This key never authorizes a tap and
     * therefore cannot weaken the action-row verification used by the claim engine.
     */
    static String anchorlessKey(String text) {
        String stable = normalizeStable(text);
        if (stable.isEmpty()) return "";
        String money = captured(MONEY_VALUE, stable);
        String miles = captured(MILES_VALUE, stable);
        if (money.isEmpty() || miles.isEmpty()) return "";
        String time = "";
        java.util.regex.Matcher tm = OFFER_TIME_VALUE.matcher(stable);
        if (tm.find()) {
            time = tm.group(1).toLowerCase(Locale.US).replaceAll("\\s+", "") + "-"
                    + tm.group(2).toLowerCase(Locale.US) + tm.group(3).toLowerCase(Locale.US);
        }
        return "anchorless|pay=" + money + "|mi=" + miles + "|time=" + time;
    }

    /** Strongest immutable order/provider token exported by the current card, or empty. */
    static String orderId(String text) {
        ParseFacts f=parseFacts(text);
        if(f.orderId==null) f.orderId=orderIdUncached(text);
        return f.orderId;
    }

    private static String orderIdUncached(String text) {
        if (text == null || text.isEmpty()) return "";
        java.util.regex.Matcher m = ORDER_ID_TOKEN.matcher(text.toLowerCase(Locale.US));
        String best = "";
        while (m.find()) {
            String token = m.group();
            if (!token.matches(".*\\d.*")) continue;
            // d_<long token> is DeliverThat's most specific delivery id when present.
            if (token.startsWith("d_") && token.length() >= 12) return token;
            if (token.length() > best.length()) best = token;
        }
        return best;
    }

    /** Long-lived unavailable tombstone key: immutable order id first, semantic fallback second. */
    static String unavailableKey(String text) {
        String order = orderId(text);
        if (!order.isEmpty()) return "order:" + order;
        String semantic = identity(text);
        return semantic.isEmpty() ? "" : "semantic:" + semantic;
    }

    /**
     * Short-lived bridge between a full unavailable card and a later sparse OCR/detail frame.
     * It deliberately requires pay + miles + scheduled time. This alias never authorizes an
     * action; it only promotes a newly exposed immutable order id into the unavailable tombstone.
     */
    static String unavailablePromotionAlias(String text) {
        String completion = completionKey(text);
        if (completion.isEmpty() || completion.endsWith("|time=")) return "";
        return "completion:" + completion;
    }

    /**
     * Short identity used only to suppress a sparse numeric-only redisplay after the server has
     * already returned offer-unavailable.  It intentionally contains no merchant/city fields:
     * those are exactly the fields React Native can omit during a fast re-render.  Callers must
     * never use this key to authorize a tap, and should consult it only while the current frame
     * still lacks the scheduled-time identity used by unavailablePromotionAlias().
     */
    static String unavailableNumericAlias(String text) {
        String stable = normalizeStable(text);
        if (stable.isEmpty()) return "";
        String money = captured(MONEY_VALUE, stable);
        String miles = captured(MILES_VALUE, stable);
        if (money.isEmpty() || miles.isEmpty()) return "";
        return "numeric:pay=" + money + "|mi=" + miles;
    }

    private static String captured(Pattern pattern, String value) {
        java.util.regex.Matcher m = pattern.matcher(value);
        if (!m.find()) return "";
        return m.group(1).replace(',', '.').toLowerCase(Locale.US);
    }

    /**
     * Stable descriptive key used only for identity/dedupe. DeliverThat frequently duplicates
     * address/content-description nodes between adjacent frames, so the full OCR/tree string is
     * intentionally excluded. Prefer the merchant phrase immediately after Today/Tomorrow time;
     * otherwise use a short sorted token signature.
     */
    private static String merchantKey(String stable, int tailStart) {
        String candidate = "";
        if (tailStart >= 0 && tailStart < stable.length()) {
            candidate = stable.substring(tailStart).trim();
            int bullet = candidate.indexOf('•');
            if (bullet >= 0) candidate = candidate.substring(0, bullet);
            java.util.regex.Matcher repeatedTime = OFFER_TIME_VALUE.matcher(candidate);
            if (repeatedTime.find()) candidate = candidate.substring(0, repeatedTime.start());
            candidate = candidate.replaceFirst("^[-–—,:\\s]+", "");
            // v2.10.34: popup/OCR reading order can insert Est.$ / distance / Large Order
            // immediately after the merchant and before the street. None of those are merchant
            // identity. Cut them before normal address stripping so the same physical offer keeps
            // one semantic fingerprint while the Large Order info tooltip is open/closing.
            candidate = candidate.replaceFirst("(?i)\\s+(?:est\\.?\\s*)?\\$.*$", "");
            candidate = candidate.replaceFirst("(?i)\\s+\\d+(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b.*$", "");
            candidate = candidate.replaceFirst("(?i)\\s+large\\s+order\\b.*$", "");
            candidate = candidate.replaceFirst("(?i)\\s+this\\s+order\\s+is\\b.*$", "");
            // Normalize OCR-collapsed street suffix spacing (e.g. 300S -> 300 S) before address stripping.
            candidate = candidate.replaceAll("(?<=\\d)(?=[a-z])", " ");
            candidate = candidate.replaceFirst("\\s+[-–—]\\s+\\d.*$", "");
            candidate = candidate.replaceFirst("\\s+\\d{2,5}\\s+.*$", "");
            candidate = candidate.replaceAll("[^a-z0-9 ]+", " ").replaceAll("\\s+", " ").trim();
            if (candidate.length() > 64) candidate = candidate.substring(0, 64).trim();
        }
        if (!candidate.isEmpty()) return candidate;

        java.util.List<String> tokens = new java.util.ArrayList<>(descriptiveTokens(stable));
        java.util.Collections.sort(tokens);
        StringBuilder out = new StringBuilder();
        for (String token : tokens) {
            if (out.length() > 0) out.append('-');
            out.append(token);
            if (out.length() >= 48) break;
        }
        return out.toString();
    }

    /**
     * v2.10.28 cross-source matcher used only to repair OCR numeric drift from a fresh
     * Accessibility representation of the same card. Amount remains exact; mileage is
     * intentionally excluded from the comparison so a lost decimal (0.7 -> 7) can be corrected
     * from the independent source. Descriptive overlap is still required.
     */
    static boolean sameOfferIgnoringMiles(String expected, String actual) {
        String a = identity(expected);
        String b = identity(actual);
        if (!a.startsWith("pay=") || !b.startsWith("pay=")) return false;
        // identity() already binds pay + pickup time + merchant. Strip only mileage so an
        // independently read 0.7 mi can correct OCR's 7 mi without ever merging two merchants,
        // pickup times or pay values.
        String aWithoutMiles = a.replaceFirst("\\|mi=[^|]*", "");
        String bWithoutMiles = b.replaceFirst("\\|mi=[^|]*", "");
        return aWithoutMiles.equals(bWithoutMiles);
    }

    /** Suppression only. Never authorizes Accept, Reject, or a coordinate reuse. */
    static boolean sameRejectObservation(String expected, String actual) {
        if (expected == null || actual == null || containsConflictingOfferNumbers(expected)
                || containsConflictingOfferNumbers(actual)) return false;
        String orderA = orderId(expected), orderB = orderId(actual);
        if (!orderA.isEmpty() && !orderB.isEmpty() && !orderA.equals(orderB)) return false;
        String timeA = completionKey(expected), timeB = completionKey(actual);
        timeA = timeA.substring(Math.max(0, timeA.indexOf("|time=")));
        timeB = timeB.substring(Math.max(0, timeB.indexOf("|time=")));
        if (timeA.length() > 6 && timeB.length() > 6 && !timeA.equals(timeB)) return false;
        if (sameOffer(expected, actual)) return true;
        float payA = amount(expected), payB = amount(actual);
        if (payA < 0 || payB < 0 || Math.abs(payA - payB) > 0.101f
                || miles(expected) < 0 || Math.abs(miles(expected) - miles(actual)) > 0.0001f) return false;
        String a = rejectObservationTail(expected), b = rejectObservationTail(actual);
        if (a.isEmpty() || b.isEmpty()
                || !a.replaceAll("[^0-9]", "").equals(b.replaceAll("[^0-9]", ""))) return false;
        // Bounded edit distance tolerates Westla/Westlake; every street/ZIP digit must agree.
        if (Math.abs(a.length() - b.length()) > 2) return false;
        int[] row = new int[b.length() + 1];
        for (int k = 0; k < row.length; k++) row[k] = k;
        for (int i = 1; i <= a.length(); i++) {
            int diagonal = row[0]; row[0] = i;
            for (int k = 1; k <= b.length(); k++) {
                int old = row[k];
                row[k] = Math.min(Math.min(row[k] + 1, row[k - 1] + 1),
                        diagonal + (a.charAt(i - 1) == b.charAt(k - 1) ? 0 : 1));
                diagonal = old;
            }
        }
        return row[b.length()] <= 2;
    }

    private static String rejectObservationTail(String text) {
        ParseFacts f=parseFacts(text);
        if(f.rejectTail==null) f.rejectTail=rejectObservationTailUncached(text);
        return f.rejectTail;
    }
    private static String rejectObservationTailUncached(String text) {
        String stable = normalizeStable(text);
        java.util.regex.Matcher time = OFFER_TIME_VALUE.matcher(stable);
        if (!time.find()) return "";
        String pickup = time.group().replaceAll("\\s+", "");
        String tail = stable.substring(time.end());
        java.util.regex.Matcher zip = Pattern.compile("\\b(?:ca|california)\\s+(\\d{5})\\b").matcher(tail);
        if (!zip.find()) return "";
        tail = tail.substring(0, zip.end()).replaceAll("[^a-z0-9]", "");
        return tail.length() >= 25 && tail.length() <= 180 ? pickup + "|" + tail : "";
    }

    static boolean sameOffer(String expected, String actual) {
        String a = normalizeStable(expected);
        String b = normalizeStable(actual);
        if (a.isEmpty() || b.isEmpty()) return false;
        if (!sameCapturedValue(MONEY_VALUE, a, b) || !sameCapturedValue(MILES_VALUE, a, b)) return false;
        if (a.equals(b)) return true;

        // Accessibility trees sometimes duplicate/omit content-description nodes
        // between frames. Numeric values are independently verified before clicking;
        // this comparison only tolerates duplicate/missing stable descriptive tokens.
        Set<String> aa = tokens(a), bb = tokens(b);
        if (aa.isEmpty() || bb.isEmpty()) return false;
        int overlap = 0;
        for (String token : aa) if (bb.contains(token)) overlap++;
        int smaller = Math.min(aa.size(), bb.size());
        return smaller >= 4 && ((double) overlap / smaller) >= 0.92d;
    }


    /**
     * Revalidation matcher for the already-isolated top action row.
     * OCR/accessibility descriptions on DeliverThat can add/drop duplicate descriptive
     * nodes between two adjacent frames. For an actual tap we keep money+miles exact,
     * then allow a looser descriptive overlap than sameOffer(). This prevents a harmless
     * tree mutation from cancelling the action while still rejecting a different card
     * whose numeric values changed.
     */
    static boolean sameOfferForAction(String expected, String actual) {
        String a = normalizeStable(expected);
        String b = normalizeStable(actual);
        if (a.isEmpty() || b.isEmpty()) return false;
        if (!sameCapturedValue(MONEY_VALUE, a, b) || !sameCapturedValue(MILES_VALUE, a, b)) return false;
        if (a.equals(b) || sameOffer(a, b)) return true;

        Set<String> aa = descriptiveTokens(a), bb = descriptiveTokens(b);
        if (aa.isEmpty() || bb.isEmpty()) {
            // The numeric pair is independently revalidated immediately before the gesture.
            // If one side lost all descriptive accessibility nodes, do not treat that alone
            // as a different top card.
            return true;
        }
        int overlap = 0;
        for (String token : aa) if (bb.contains(token)) overlap++;
        int smaller = Math.min(aa.size(), bb.size());
        if (overlap >= 2) return true;
        return smaller == 1 && overlap == 1;
    }

    /**
     * v2.10.46 FastAccept fusion matcher. The bounded quick tree is authoritative for the
     * decision fields; the semantic Action index may legitimately expose only part of the
     * card ancestry while still giving an exact enabled Accept rectangle. Missing indexed
     * fields are therefore tolerated, but any field that is present must agree exactly.
     * We also require descriptive overlap so a bare action label can never be fused across cards.
     */
    static boolean compatiblePartialActionEvidence(String authoritative, String partial) {
        String a = normalizeStable(authoritative);
        String b = normalizeStable(partial);
        if (a.isEmpty() || b.isEmpty()) return false;

        String aMoney = captured(MONEY_VALUE, a);
        String aMiles = captured(MILES_VALUE, a);
        if (aMoney.isEmpty() || aMiles.isEmpty()) return false;

        String bMoney = captured(MONEY_VALUE, b);
        String bMiles = captured(MILES_VALUE, b);
        if (!bMoney.isEmpty() && !aMoney.equals(bMoney)) return false;
        if (!bMiles.isEmpty() && !aMiles.equals(bMiles)) return false;

        Set<String> aa = descriptiveTokens(a), bb = descriptiveTokens(b);
        int overlap = 0;
        for (String token : bb) if (aa.contains(token)) overlap++;

        int presentNumeric = (bMoney.isEmpty() ? 0 : 1) + (bMiles.isEmpty() ? 0 : 1);
        // With both numeric fields independently matching, one descriptive token is enough.
        // With only one numeric field, require two descriptive tokens. With neither numeric
        // field, require three descriptive tokens so an isolated Accept node cannot fuse.
        if (presentNumeric == 2) return overlap >= 1 || bb.isEmpty();
        if (presentNumeric == 1) return overlap >= 2;
        return overlap >= 3;
    }

    /**
     * v2.10.49 complementary Accessibility matcher. Neither side has to be complete by itself:
     * Action-index ancestry and bounded quick-tree ancestry may expose different pieces of the
     * same top card. Any numeric field present on both sides must match, and descriptive overlap
     * is required before their text may be merged into one decision snapshot.
     */
    static boolean compatibleComplementaryEvidence(String left, String right) {
        String a = normalizeStable(left);
        String b = normalizeStable(right);
        if (a.isEmpty() || b.isEmpty()) return false;

        String aMoney = captured(MONEY_VALUE, a), bMoney = captured(MONEY_VALUE, b);
        String aMiles = captured(MILES_VALUE, a), bMiles = captured(MILES_VALUE, b);
        if (!aMoney.isEmpty() && !bMoney.isEmpty() && !aMoney.equals(bMoney)) return false;
        if (!aMiles.isEmpty() && !bMiles.isEmpty() && !aMiles.equals(bMiles)) return false;

        Set<String> aa = descriptiveTokens(a), bb = descriptiveTokens(b);
        int overlap = 0;
        for (String token : aa) if (bb.contains(token)) overlap++;
        int sharedNumeric = (!aMoney.isEmpty() && !bMoney.isEmpty() ? 1 : 0)
                + (!aMiles.isEmpty() && !bMiles.isEmpty() ? 1 : 0);
        if (sharedNumeric == 2) return overlap >= 1 || aa.isEmpty() || bb.isEmpty();
        if (sharedNumeric == 1) return overlap >= 2;
        return overlap >= 3;
    }

    private static Set<String> descriptiveTokens(String value) {
        Set<String> out = new HashSet<>();
        for (String token : value.split("[^a-z0-9]+")) {
            if (token.length() < 3 || token.matches("\\d+(?:\\.\\d+)?")) continue;
            if (token.equals("est") || token.equals("mi") || token.equals("mins")
                    || token.equals("min") || token.equals("today") || token.equals("tomorrow")
                    || token.equals("delivery") || token.equals("pickup") || token.equals("dropoff")
                    || token.equals("united") || token.equals("states") || token.equals("the")
                    || token.equals("and") || token.equals("for")) continue;
            out.add(token);
        }
        return out;
    }

    private static String normalizeStable(String text) {
        ParseFacts f=parseFacts(text);
        if(f.stable==null) f.stable=normalizeStableUncached(text);
        return f.stable;
    }
    private static String normalizeStableUncached(String text) {
        if (text == null) return "";
        String value = withoutPickupZone(text).toLowerCase(Locale.US);
        value = EXPIRES_CLOCK.matcher(value).replaceAll(" ");
        value = EXPIRES_SECONDS.matcher(value).replaceAll(" ");
        value = ACTION_WORDS.matcher(value).replaceAll(" ");
        return value.replaceAll("[|•·]+", " ").replaceAll("\\s+", " ").trim();
    }


    private static boolean sameCapturedValue(Pattern pattern, String a, String b) {
        java.util.regex.Matcher ma = pattern.matcher(a), mb = pattern.matcher(b);
        if (!ma.find() || !mb.find()) return false;
        return ma.group(1).replace(',', '.').equals(mb.group(1).replace(',', '.'));
    }

    private static Set<String> tokens(String value) {
        Set<String> out = new HashSet<>();
        for (String token : value.split("[^a-z0-9$.:]+")) {
            if (token.length() >= 2) out.add(token);
        }
        return out;
    }
}
