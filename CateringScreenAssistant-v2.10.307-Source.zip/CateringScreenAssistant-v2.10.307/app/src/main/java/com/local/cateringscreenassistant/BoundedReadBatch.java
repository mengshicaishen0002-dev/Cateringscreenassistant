package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReferenceArray;

/** Read-only work only. Each job owns its handles, including after a caller timeout. */
final class BoundedReadBatch implements AutoCloseable {
    interface Read<T> {
        T read();
        void close();
    }
    static final class Result<T> {
        final String reason;
        final List<T> values;
        final long elapsedMs, launchMs, maxQueueMs;
        Result(String reason, List<T> values) { this(reason, values, 0L, 0L, 0L); }
        Result(String reason, List<T> values, long elapsedMs, long launchMs, long maxQueueMs) {
            this.reason = reason; this.values = values;
            this.elapsedMs = elapsedMs; this.launchMs = launchMs; this.maxQueueMs = maxQueueMs;
        }
        boolean complete() { return "OK".equals(reason); }
    }
    private final int width;
    private final Semaphore slots;
    private final ThreadPoolExecutor pool;

    BoundedReadBatch(int width) { this(width, () -> {}); }

    BoundedReadBatch(int width, Runnable onWorkerStart) {
        this.width = width;
        slots = new Semaphore(width);
        AtomicInteger names = new AtomicInteger();
        pool = new ThreadPoolExecutor(width, width, 15L, TimeUnit.SECONDS,
                new ArrayBlockingQueue<>(width), runnable -> {
                    Thread thread = new Thread(() -> {
                        try { onWorkerStart.run(); } catch (RuntimeException ignored) { }
                        runnable.run();
                    }, "offer-live-read-" + names.incrementAndGet());
                    thread.setDaemon(true);
                    return thread;
                });
        // Keep the four idle readers for the service lifetime. The next rare eligible offer
        // must not pay thread creation on its first shot. close() releases them on teardown.
    }

    int warmUp() { return pool.isShutdown() ? 0 : pool.prestartAllCoreThreads(); }

    <T> Result<T> read(List<? extends Read<T>> jobs, long timeoutMs) {
        try (Pending<T> pending = begin(jobs, timeoutMs)) {
            return pending.take(0, jobs.size());
        }
    }

    /** Wait for only the requested group, within the original deadline. */
    final class Pending<T> implements AutoCloseable {
        private final long startedNs = System.nanoTime();
        private final long deadline;
        private final AtomicLong maxQueueNs = new AtomicLong();
        private final AtomicBoolean abandoned = new AtomicBoolean();
        private final AtomicReferenceArray<T> results;
        private final CountDownLatch[] done;
        private long launchedAt;
        private String failure = "";

        Pending(int count, long timeoutMs) {
            deadline = startedNs + TimeUnit.MILLISECONDS.toNanos(Math.max(1L, timeoutMs));
            results = new AtomicReferenceArray<>(count);
            done = new CountDownLatch[count];
            for (int i = 0; i < count; i++) done[i] = new CountDownLatch(1);
        }

        private void submit(int index, Read<T> job) {
            long submittedAt = System.nanoTime();
            pool.execute(() -> {
                maxQueueNs.accumulateAndGet(System.nanoTime() - submittedAt, Math::max);
                try {
                    if (!abandoned.get()) {
                        results.set(index, job.read());
                        if (abandoned.get()) closeValue(results.getAndSet(index, null));
                    }
                } catch (RuntimeException stale) {
                    // An incomplete group never publishes evidence.
                } finally {
                    closeQuietly(job);
                    slots.release();
                    done[index].countDown();
                }
            });
        }

        Result<T> take(int from, int to) {
            if (!failure.isEmpty()) return new Result<>(failure, new ArrayList<>());
            try {
                for (int i = from; i < to; i++) {
                    long left = deadline - System.nanoTime();
                    if (done[i].getCount() != 0
                            && (left <= 0L || !done[i].await(left, TimeUnit.NANOSECONDS)))
                        return new Result<>("BUDGET", new ArrayList<>());
                }
                for (int i = from; i < to; i++)
                    if (results.get(i) == null) return new Result<>("REFRESH_FAILED", new ArrayList<>());
                List<T> values = new ArrayList<>(to - from);
                for (int i = from; i < to; i++) values.add(results.getAndSet(i, null));
                return new Result<>("OK", values,
                        TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startedNs),
                        TimeUnit.NANOSECONDS.toMillis(launchedAt - startedNs),
                        TimeUnit.NANOSECONDS.toMillis(maxQueueNs.get()));
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                return new Result<>("BUDGET", new ArrayList<>());
            }
        }

        Result<T> takeOneWhile(java.util.function.BooleanSupplier current) {
            return takeWhile(0, 1, current);
        }

        /** Let a superseded screen read yield without waiting for its Binder call to return. */
        Result<T> takeWhile(int from, int to, java.util.function.BooleanSupplier current) {
            if (!failure.isEmpty()) return take(from, to);
            try {
                for (int i = from; i < to; i++) {
                    while (done[i].getCount() != 0) {
                        if (!current.getAsBoolean()) return new Result<>("YIELD", new ArrayList<>());
                        long left = deadline - System.nanoTime();
                        if (left <= 0L) return new Result<>("BUDGET", new ArrayList<>());
                        done[i].await(Math.min(left, TimeUnit.MILLISECONDS.toNanos(4)), TimeUnit.NANOSECONDS);
                    }
                }
                return current.getAsBoolean() ? take(from, to) : new Result<>("YIELD", new ArrayList<>());
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                return new Result<>("YIELD", new ArrayList<>());
            }
        }

        @Override public void close() {
            abandoned.set(true);
            for (int i = 0; i < results.length(); i++) closeValue(results.getAndSet(i, null));
        }
    }

    <T> Pending<T> begin(List<? extends Read<T>> jobs, long timeoutMs) {
        int count = jobs.size();
        Pending<T> pending = new Pending<>(count, timeoutMs);
        if (count == 0 || count > width || !slots.tryAcquire(count)) {
            for (Read<T> job : jobs) closeQuietly(job);
            pending.failure = "BUSY";
            return pending;
        }
        int submitted = 0;
        try {
            for (; submitted < count; submitted++) pending.submit(submitted, jobs.get(submitted));
            pending.launchedAt = System.nanoTime();
        } catch (RuntimeException rejected) {
            pending.close();
            for (int i = submitted; i < count; i++) {
                closeQuietly(jobs.get(i));
                slots.release();
            }
            pending.failure = "BUSY";
        }
        return pending;
    }
    /** Use the same bounded readers for a larger owned-node proof; never add threads.
     * A single deadline covers all waves, and an incomplete wave publishes no values. */
    <T> Result<T> readWaves(List<? extends Read<T>> jobs,long timeoutMs) {
        if(jobs.size()<=width) return read(jobs,timeoutMs);
        long started=System.nanoTime(),deadline=started+TimeUnit.MILLISECONDS.toNanos(Math.max(1L,timeoutMs));
        List<T> values=new ArrayList<>();long launches=0L,maxQueue=0L;
        for(int at=0;at<jobs.size();) {
            long left=deadline-System.nanoTime();
            if(left<=0L) {
                for(T value:values)closeValue(value);
                for(int i=at;i<jobs.size();i++)closeQuietly(jobs.get(i));
                return new Result<>("BUDGET",new ArrayList<>());
            }
            int end=Math.min(jobs.size(),at+width);
            Result<T> wave=read(jobs.subList(at,end),Math.max(1L,TimeUnit.NANOSECONDS.toMillis(left)));
            launches+=wave.launchMs;maxQueue=Math.max(maxQueue,wave.maxQueueMs);
            if(!wave.complete()) {
                for(T value:values)closeValue(value);
                for(int i=end;i<jobs.size();i++)closeQuietly(jobs.get(i));
                return new Result<>(wave.reason,new ArrayList<>(),
                        TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started),launches,maxQueue);
            }
            values.addAll(wave.values);at=end;
        }
        return new Result<>("OK",values,TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-started),launches,maxQueue);
    }

    private static void closeValue(Object value) {
        if (value instanceof AutoCloseable)
            try { ((AutoCloseable) value).close(); } catch (Exception ignored) { }
    }
    private static void closeQuietly(Read<?> job) {
        try { job.close(); } catch (RuntimeException ignored) { }
    }
    @Override public void close() { pool.shutdown(); }
}
