package com.local.cateringscreenassistant;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CAPTURE = 7001;
    private SharedPreferences prefs;
    private EditText minPay;
    private EditText maxMiles;
    private EditText pasadenaMinPay;
    private EditText pasadenaMaxMiles;
    private EditText cities;
    private EditText startTime;
    private EditText endTime;
    private EditText interval;
    private CheckBox requireCity;
    private CheckBox dryRun;
    private CheckBox autoIgnore;
    private android.widget.Spinner acceptGestureMode;
    private CheckBox pasadenaRuleEnabled;
    private CheckBox qualifiedAlertEnabled;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("rules", MODE_PRIVATE);
        if (!prefs.getBoolean("finalModeInitialized", false)) {
            prefs.edit()
                    .putBoolean("dryRun", false)
                    .putBoolean("finalModeInitialized", true)
                    .apply();
        }
        setContentView(buildUi());
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3);
        }
    }

    private View buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView intro = new TextView(this);
        intro.setText("v2.10.307：单点12ms＋补击，或错时三次12ms。Spinner停止补击，最终仍需确认服务器结果。");
        intro.setTextSize(16);
        root.addView(intro, row());

        String savedStatus = prefs.getString("lastStatus", "暂无识别记录");
        long savedStatusAt = prefs.getLong("lastStatusAt", 0L);
        TextView lastStatus = new TextView(this);
        lastStatus.setText(savedStatusAt > 0
                ? "最近识别记录（停止监控后仍保留）：\n"
                    + DateFormat.getDateTimeInstance().format(new Date(savedStatusAt))
                    + "\n" + savedStatus
                : "最近识别记录：暂无");
        lastStatus.setTextSize(15);
        root.addView(lastStatus, row());

        Button events = new Button(this);
        events.setText("查看处理记录（最近100条，可复制）");
        events.setOnClickListener(v -> {
            StringBuilder text = new StringBuilder();
            try {
                org.json.JSONArray records = new org.json.JSONArray(prefs.getString("decisionEvents", "[]"));
                for (int i = 0; i < records.length(); i++) text.append(records.getString(i)).append("\n\n────────\n\n");
            } catch (org.json.JSONException ignored) { }
            TextView view = new TextView(this);
            view.setPadding(dp(16),dp(16),dp(16),dp(16));
            view.setTextIsSelectable(true);
            view.setText(text.length() == 0 ? "暂无新版本处理记录" : text.toString());
            ScrollView scroll = new ScrollView(this); scroll.addView(view);
            new android.app.AlertDialog.Builder(this).setTitle("每条对应同一次判断")
                    .setView(scroll).setPositiveButton("关闭", null).show();
        });
        root.addView(events, row());

        Button scanDiagnostic = new Button(this);
        scanDiagnostic.setText("查看实时扫描诊断（可复制）");
        scanDiagnostic.setOnClickListener(v -> {
            String trace=OcrMonitorService.recentLiveScanTrace();
            TextView detail=new TextView(this);
            detail.setTextIsSelectable(true);
            detail.setPadding(dp(16),dp(16),dp(16),dp(16));
            detail.setText(trace.isEmpty() ? "本次监控尚无扫描诊断。" : trace);
            ScrollView scroll=new ScrollView(this);
            scroll.addView(detail);
            new android.app.AlertDialog.Builder(this).setTitle("本次监控的近期扫描")
                    .setView(scroll).setPositiveButton("关闭",null).show();
        });
        root.addView(scanDiagnostic,row());

        Button shareReplay = new Button(this);
        shareReplay.setText("分享最近一次接单诊断（画面 + 时间日志）");
        shareReplay.setOnClickListener(v -> {
            java.io.File replay = AcceptReplay.latestFile(this);
            if (!replay.isFile()) {
                Toast.makeText(this, "暂无诊断包。发出 Accept 后约 7 秒生成。", Toast.LENGTH_LONG).show();
                return;
            }
            Uri uri = androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".acceptreplay", replay);
            Intent share = new Intent(Intent.ACTION_SEND)
                    .setType("application/zip")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "分享接单诊断包"));
        });
        root.addView(shareReplay, row());

        TextView ignoredTitle = new TextView(this);
        ignoredTitle.setText("旧式筛选历史（不对应当前报错；排查请用上方处理记录）：");
        ignoredTitle.setTextSize(16);
        root.addView(ignoredTitle, row());
        TextView ignoredHistory = new TextView(this);
        ignoredHistory.setText(prefs.getString("ignoredHistory", "暂无记录"));
        ignoredHistory.setTextSize(14);
        ignoredHistory.setTextIsSelectable(true);
        root.addView(ignoredHistory, row());

        Button clearHistory = new Button(this);
        clearHistory.setText("清空未通过订单记录");
        clearHistory.setOnClickListener(v -> {
            prefs.edit().remove("ignoredHistory").apply();
            ignoredHistory.setText("暂无记录");
        });
        root.addView(clearHistory, row());

        minPay = field("普通规则最低预估金额，例如 60", String.valueOf(prefs.getFloat("minPay", 60f)), true);
        root.addView(minPay, row());
        maxMiles = field("普通规则最高里程，例如 10", String.valueOf(prefs.getFloat("maxMiles", 10f)), true);
        root.addView(maxMiles, row());
        TextView pasadenaTitle = new TextView(this);
        pasadenaTitle.setText("Pasadena 专属规则（命中 Pasadena 时优先于普通规则）");
        pasadenaTitle.setTextSize(16);
        root.addView(pasadenaTitle, row());
        pasadenaRuleEnabled = new CheckBox(this);
        pasadenaRuleEnabled.setText("启用 Pasadena 专属规则");
        pasadenaRuleEnabled.setChecked(prefs.getBoolean("pasadenaRuleEnabled", false));
        root.addView(pasadenaRuleEnabled, row());
        pasadenaMinPay = field("Pasadena 最低预估金额", String.valueOf(prefs.getFloat("pasadenaMinPay", 25f)), true);
        root.addView(pasadenaMinPay, row());
        pasadenaMaxMiles = field("Pasadena 最高里程", String.valueOf(prefs.getFloat("pasadenaMaxMiles", 5f)), true);
        root.addView(pasadenaMaxMiles, row());
        cities = field("允许城市（留空=不限制）", prefs.getString("cities", ""), false);
        root.addView(cities, row());
        startTime = field("开始时间（留空=不限制）", prefs.getString("startTime", ""), false);
        root.addView(startTime, row());
        endTime = field("结束时间（留空=不限制）", prefs.getString("endTime", ""), false);
        root.addView(endTime, row());
        interval = field("OCR兜底间隔（默认20ms，最低12ms，新单信号时加速）", String.valueOf(prefs.getInt("interval", 20)), true);
        root.addView(interval, row());
        requireCity = new CheckBox(this);
        requireCity.setText("允许城市非空时自动强制限制（留空才不限城市）");
        requireCity.setEnabled(false);
        requireCity.setChecked(!cities.getText().toString().trim().isEmpty());
        cities.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                requireCity.setChecked(s != null && !s.toString().trim().isEmpty());
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        root.addView(requireCity, row());
        qualifiedAlertEnabled = new CheckBox(this);
        qualifiedAlertEnabled.setText("符合条件订单提醒：高优先级通知 + 声音 + 震动（建议开启）");
        qualifiedAlertEnabled.setChecked(prefs.getBoolean("qualifiedAlertEnabled", true));
        root.addView(qualifiedAlertEnabled, row());

        Button testAlert = new Button(this);
        testAlert.setText("测试符合条件订单提醒");
        testAlert.setOnClickListener(v -> {
            prefs.edit().putBoolean("qualifiedAlertEnabled", qualifiedAlertEnabled.isChecked()).apply();
            QualifiedOfferAlert.sendTest(this, prefs);
            Toast.makeText(this, "已发送测试提醒；应出现通知、声音和震动", Toast.LENGTH_LONG).show();
        });
        root.addView(testAlert, row());

        Button testSuccessAlarm = new Button(this);
        testSuccessAlarm.setText("测试接单结果提醒（单次响铃，最多4秒）");
        testSuccessAlarm.setOnClickListener(v -> {
            ClaimSuccessAlert.sendTest(this);
            Toast.makeText(this, "已启动测试警报；这不是接单成功记录", Toast.LENGTH_LONG).show();
        });
        root.addView(testSuccessAlarm, row());

        dryRun = new CheckBox(this);
        dryRun.setText("测试模式：只识别和响铃，不点击（正式接单请勿勾选）");
        dryRun.setChecked(prefs.getBoolean("dryRun", false));
        root.addView(dryRun, row());

        autoIgnore = new CheckBox(this);
        autoIgnore.setText("不符合条件时，可靠识别到Ignore/Decline/Reject后立即点击");
        autoIgnore.setChecked(prefs.getBoolean("autoIgnore", true));
        root.addView(autoIgnore, row());

        TextView gestureTitle = new TextView(this);
        gestureTitle.setText("Accept 首击模式（两种互斥，保存规则后生效）");
        root.addView(gestureTitle, row());
        acceptGestureMode = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> gestureAdapter = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new String[]{
                "单点12ms＋原连续补击", "错时三次12ms＋原连续补击"});
        gestureAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        acceptGestureMode.setAdapter(gestureAdapter);
        acceptGestureMode.setSelection(ActionDispatchPolicy.gestureSelection(prefs.getInt("acceptGestureMode",
                prefs.getBoolean("threeTapFirstGesture", false) ? 2 : 0)));
        root.addView(acceptGestureMode, row());

        Button accessibility = new Button(this);
        accessibility.setText("1. 开启辅助功能点击服务");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility, row());

        Button battery = new Button(this);
        battery.setText(isIgnoringBatteryOptimizations()
                ? "电池优化：已允许后台持续运行"
                : "建议：允许忽略电池优化（防三星杀后台）");
        battery.setOnClickListener(v -> requestBatteryOptimizationExemption());
        root.addView(battery, row());

        Button start = new Button(this);
        start.setText("2. 保存规则并开始监控");
        start.setOnClickListener(v -> saveAndRequestCapture());
        root.addView(start, row());

        Button stop = new Button(this);
        stop.setText("停止监控");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OcrMonitorService.class));
            Toast.makeText(this, "监控已停止", Toast.LENGTH_SHORT).show();
        });
        root.addView(stop, row());

        Button resume = new Button(this);
        resume.setText("人工处理完成：恢复自动监控");
        resume.setOnClickListener(v -> {
            OcrMonitorService.resumeAfterManualIntervention(this);
            Toast.makeText(this, OcrMonitorService.isMonitoring()
                    ? "自动监控已恢复，请返回Offers页面"
                    : "监控服务未运行，请重新开始监控", Toast.LENGTH_LONG).show();
        });
        root.addView(resume, row());

        TextView warning = new TextView(this);
        warning.setText("限制：仅在DeliverThat前台Offers页点击；每次动作前重新核对当前卡片金额/里程/按钮。OCR无法可靠核对时不点击。自动化可能受平台规则限制。");
        root.addView(warning, row());

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private EditText field(String hint, String value, boolean numeric) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private void saveAndRequestCapture() {
        try {
            float pay = Float.parseFloat(minPay.getText().toString().trim());
            float miles = Float.parseFloat(maxMiles.getText().toString().trim());
            float pasadenaPay = Float.parseFloat(pasadenaMinPay.getText().toString().trim());
            float pasadenaMiles = Float.parseFloat(pasadenaMaxMiles.getText().toString().trim());
            if (!Float.isFinite(pay) || !Float.isFinite(miles) || !Float.isFinite(pasadenaPay)
                    || !Float.isFinite(pasadenaMiles) || pay < 0 || miles < 0 || pasadenaPay < 0 || pasadenaMiles < 0) {
                throw new NumberFormatException();
            }
            int scan = Integer.parseInt(interval.getText().toString().trim());
            scan = ScanPolicy.clampOcrInterval(scan);
            String cityList = cities.getText().toString().trim();
            prefs.edit()
                    .putFloat("minPay", pay)
                    .putFloat("maxMiles", miles)
                    .putBoolean("pasadenaRuleEnabled", pasadenaRuleEnabled.isChecked())
                    .putFloat("pasadenaMinPay", pasadenaPay)
                    .putFloat("pasadenaMaxMiles", pasadenaMiles)
                    .putString("cities", cityList)
                    .putString("startTime", startTime.getText().toString().trim())
                    .putString("endTime", endTime.getText().toString().trim())
                    .putInt("interval", scan)
                    // Compatibility value for older builds. v2.10.124+ derives the rule
                    // directly from whether the allow-list is empty.
                    .putBoolean("requireCity", !cityList.isEmpty())
                    .putBoolean("qualifiedAlertEnabled", qualifiedAlertEnabled.isChecked())
                    .putBoolean("dryRun", dryRun.isChecked())
                    .putBoolean("autoIgnore", autoIgnore.isChecked())
                    .putInt("acceptGestureMode", ActionDispatchPolicy.gestureModeForSelection(acceptGestureMode.getSelectedItemPosition()))
                    .putBoolean("threeTapFirstGesture", ActionDispatchPolicy.gestureModeForSelection(acceptGestureMode.getSelectedItemPosition()) == ActionDispatchPolicy.SEQUENTIAL)
                    .apply();
        } catch (NumberFormatException ex) {
            Toast.makeText(this, "金额或扫描间隔格式不正确", Toast.LENGTH_LONG).show();
            return;
        }
        if (!TapAccessibilityService.isConnected()) {
            Toast.makeText(this, "请先开启辅助功能点击服务", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    private boolean isIgnoringBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
        return power != null && power.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void requestBatteryOptimizationExemption() {
        if (isIgnoringBatteryOptimizations()) {
            Toast.makeText(this, "已允许后台持续运行，无需重复设置", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent request = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(request);
        } catch (RuntimeException unavailable) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE || resultCode != Activity.RESULT_OK || data == null) return;
        Intent service = new Intent(this, OcrMonitorService.class);
        service.putExtra("resultCode", resultCode);
        service.putExtra("resultData", data);
        startForegroundService(service);
        Toast.makeText(this, "监控已启动；现在打开DeliverThat订单页", Toast.LENGTH_LONG).show();
    }

    private LinearLayout.LayoutParams row() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(12));
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
