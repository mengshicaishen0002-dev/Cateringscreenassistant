package com.local.cateringscreenassistant;

/** Actual dispatch boundary; repaint timestamps cannot establish outcome ownership. */
final class AcceptOutcomeFence {
    final long actionEpoch, actionAt, baselineEventEpoch, dispatchElapsed, dispatchUptime;
    AcceptOutcomeFence(long actionEpoch, long actionAt, long baselineEventEpoch,
                       long dispatchElapsed, long dispatchUptime) {
        this.actionEpoch = actionEpoch; this.actionAt = actionAt;
        this.baselineEventEpoch = baselineEventEpoch;
        this.dispatchElapsed = dispatchElapsed; this.dispatchUptime = dispatchUptime;
    }
    static final class Observation {
        final String hint;
        final long epoch, originUptime, receivedElapsed;
        Observation(String hint, long epoch, long originUptime, long receivedElapsed) {
            this.hint = hint == null ? "" : hint;
            this.epoch = epoch; this.originUptime = originUptime; this.receivedElapsed = receivedElapsed;
        }
    }
    boolean accepts(Observation event, long nowElapsed, long nowUptime) {
        return event != null && !event.hint.isEmpty() && dispatchUptime > 0L
                && event.epoch > baselineEventEpoch
                && event.originUptime >= dispatchUptime && event.originUptime <= nowUptime
                && event.receivedElapsed >= dispatchElapsed && nowElapsed >= event.receivedElapsed
                && nowElapsed - event.receivedElapsed <= 5_000L;
    }
    String timing(Observation event) {
        return event == null ? "event=NONE" : "eventEpoch=" + event.epoch
                + ",originAfterDispatchStart=" + (event.originUptime - dispatchUptime) + "ms"
                + ",receiptAfterDispatchStart=" + (event.receivedElapsed - dispatchElapsed) + "ms";
    }
}
