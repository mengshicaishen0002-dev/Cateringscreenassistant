v2.10.300: versionCode 326; 3 speed improvements + migrated legacy assertions. Read CHANGELOG-v2.10.300.md. APK not built locally.
