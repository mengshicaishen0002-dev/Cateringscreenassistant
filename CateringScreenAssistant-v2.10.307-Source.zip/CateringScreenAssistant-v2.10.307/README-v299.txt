v2.10.299 / versionCode 325
Accept 优先 / 三项并行索引 / 去首击重复复核 / 热态OCR 12ms / 空闲OCR 20ms。
