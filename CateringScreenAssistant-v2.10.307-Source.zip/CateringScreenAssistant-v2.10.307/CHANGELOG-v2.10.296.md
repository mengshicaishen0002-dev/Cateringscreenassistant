# v2.10.296 — 速抢优先：不以过期证据阻断 Accept

**用户授权的风险偏好：宁可可能误点，也不要因几十毫秒内的 UI generation、window epoch 或快照年龄变化取消已经定位好的 Accept。**

- `tapSnapshotFastDetailed`: 当前 DeliverThat 前台、同轮已识别金额/里程/Accept 的 indexedRead 直接复用根窗口和 CTA 坐标；不再额外刷新、rebind 或以代际变化取消第一次手势。
- `dispatchVerifiedSnapshotGesture`: 最终只进行前台、监控、手动暂停、已接单、Spinner/明确失效等实时状态的阻断；不以 `RETRY_PROOF_EXPIRED` 阻断 UI 代际变更。
- `pressureStopReason`: 已绑定同单 Accept 的补击不因 UI/window/layout epoch 改变而中断、重新读树。继续停止于转圈、成功、已明确失效、前台离开、暂停。
- `tapSnapshotRetryDetailed`: 优先利用已有金额/里程和 CTA 索引直接补击；避免压力补击被慢速节点重读卡住。
- `tapVisualSnapshotRetryDetailed`: 视觉补击不再因帧年龄或 UI 代际变化直接失败，但保留前台和明确终态门槛。
- Reject、Jobs→Offers、Offers 空页监控、规则阈值保持 v295 不变。

**明确风险**：当同一界面在数十毫秒内换单或重排时，可能点到其它按钮或新卡；这是用户授权的速度优先权衡。此源码尚需 Android CI 实际编译和实机回放确认。

## 空页/未知恢复与125ms长尾
- `OcrMonitorService`: 无当前有效索引、也无可用数值事件时，即使有未验证的 STRUCTURAL 或屏幕残留Accept提示，也**不再在12ms线程**走 `ActionIndex→RejectIndex→QuickTree→FullTree`；交给独立 `idlePresenceWorker`。每个新事件仍可立即进入下一轮 current index 读取。
- `SCAN_HEALTH`: 加入低开销 `presence_last=...`（`EMPTY`/`BUDGET`/`UNAVAILABLE`/`UI_CHANGED` 等），以辨别为什么长期 UNKNOWN，禁止把 UNKNOWN 直接当空页或操作按钮。
- 这些路径仅在**当前索引没有证明存在订单**时触发；已经发现的金额/里程/Accept 仍按原高优先级流程处理，绝不会主动延迟。
- 仅依赖此处日志不能断定服务器为何返回 `This offer is no longer available`；转圈不是抢单成功证明。
- `TapAccessibilityService` 空页存在性探测：当前 DeliverThat 根节点明确包含 `No offers available` 且没有 Jobs/Ignored 选中、没有新卡金额/按钮时，即使 RN 没导出 Offers 选中状态，也可确认 `EMPTY`；`UNKNOWN` 依旧不伪装为 EMPTY。
- 同单视觉 Accept 补击也不再要求旧帧 TTL 或额外的语义节点+数值 Binder 二次读取，只核对当前事务、前台、监控、停止与明确服务器失效。
