# v2.10.297 — 首单索引忙时让路 + 3 查询并行空页探测

基线：v2.10.296。保留金额/里程/城市阈值、正常重发订单重新判断、Accept 速度优先及 Reject Spinner/Jobs 导航。

1. **ACTION_INDEX_BUSY**：首次索引四路并行读取器被之前超时的 Binder 任务占满时，以前继续在主扫描线程同步查询 `a/e`，但同一批缺失的金额/里程读取仍返回 BUSY，既耗时又无法得到可用订单证据。现在直接记录 `ACTION_INDEX_BUSY_YIELD` 并在主扫描流程退出 `FIRST_SHOT_INDEX_BUSY_YIELD`；依靠持续心跳或新的事件重新读当前卡片，避免加码 `Reject→Quick→Full` 兜底。注意：没有切断真正的 Android Binder 调用；仍可能有系统侧延迟。
2. **Idle presence**：把 `Jobs/e/$/i` 四项串行查询缩减为 `Jobs/e/$` 三项，始终使用专属的 `idlePresenceBatch` 三路并行索引。在同样 34ms 上限内更有机会返回明确空页/有单/Jobs 信息；若工作线程被占满，`presence_last=BUSY` 与真正 `BUDGET` 分开报告。`i` 单独匹配到的无金额/无动作文案不能直接构成可点击订单，因此不再浪费空闲预算。空页确认仍需当前页面证明。
3. **不改变重新发布订单**：平台 Reject 后相同报价的订单重新发布仍按当前卡片重新判定，不按商家、金额、地址永久屏蔽。保留当前订单成功/失败后的原终态处理。

验证：需运行 `python3 tools/check_latency_v297.py`、原回归与 Android Gradle 构建；静态源码测试不代表实机性能保证。此改动是针对实机日志中的读取竞争与高比例 presence UNKNOWN，不宣称已经证明 700–1200ms 首次可用快照延迟全部由同一原因造成。
