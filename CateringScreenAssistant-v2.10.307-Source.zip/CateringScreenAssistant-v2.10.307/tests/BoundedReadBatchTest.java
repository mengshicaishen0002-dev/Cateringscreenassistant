package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public final class BoundedReadBatchTest {
    static int checks;
    static void check(boolean ok, String why) { checks++; if (!ok) throw new AssertionError(why); }
    static void await(CountDownLatch latch) {
        try { if (!latch.await(2, TimeUnit.SECONDS)) throw new AssertionError("test coordination timed out"); }
        catch (InterruptedException e) { throw new AssertionError(e); }
    }
    static BoundedReadBatch.Read<Integer> job(int value, CountDownLatch entered,
            CountDownLatch release, AtomicInteger closes) {
        return new BoundedReadBatch.Read<Integer>() {
            public Integer read() { if (entered != null) entered.countDown(); if (release != null) await(release); return value; }
            public void close() { closes.incrementAndGet(); }
        };
    }
    public static void main(String[] args) throws Exception {
        try (BoundedReadBatch pool = new BoundedReadBatch(4)) {
            check(pool.warmUp() == 4, "service setup starts readers before an eligible offer arrives");
            check(pool.warmUp() == 0, "repeated setup reuses existing readers");
            CountDownLatch entered = new CountDownLatch(4), release = new CountDownLatch(1);
            AtomicInteger closes = new AtomicInteger();
            List<BoundedReadBatch.Read<Integer>> jobs = new ArrayList<>();
            for (int i = 0; i < 4; i++) jobs.add(job(i, entered, release, closes));
            AtomicReference<BoundedReadBatch.Result<Integer>> out = new AtomicReference<>();
            Thread reader = new Thread(() -> out.set(pool.read(jobs, 1000)));
            reader.start(); await(entered);
            check(closes.get() == 0, "all four reads enter before any is released: not sequential");
            AtomicInteger rejectedCloses = new AtomicInteger();
            BoundedReadBatch.Result<Integer> busy = pool.read(List.of(job(5,null,null,rejectedCloses)), 500);
            check("BUSY".equals(busy.reason) && busy.values.isEmpty(), "in-flight work cannot queue more reads");
            check(rejectedCloses.get() == 1, "rejected job releases its own handles");
            release.countDown();reader.join(2000);
            check(out.get() != null && out.get().complete() && out.get().values.equals(List.of(0,1,2,3)), "out-of-order jobs retain source ordering");
            check(closes.get() == 4, "completed handles close once");
            check(out.get().elapsedMs >= 0 && out.get().launchMs >= 0 && out.get().maxQueueMs >= 0,
                    "batch timing is available without changing evidence admission");
            BoundedReadBatch.Result<Integer> failed = pool.read(List.of(new BoundedReadBatch.Read<Integer>() {
                public Integer read() { throw new IllegalStateException("stale source"); }
                public void close() { closes.incrementAndGet(); }
            }), 500);
            check("REFRESH_FAILED".equals(failed.reason) && failed.values.isEmpty(), "exception is incomplete proof");
            check(closes.get() == 5, "throwing read closes owned handle");
        }
        try (BoundedReadBatch pool = new BoundedReadBatch(4)) {
            CountDownLatch numbersEntered = new CountDownLatch(2), releaseNumbers = new CountDownLatch(1);
            AtomicInteger closes = new AtomicInteger();
            var jobs = List.of(job(0,null,null,closes), job(1,null,null,closes),
                    job(2,numbersEntered,releaseNumbers,closes), job(3,numbersEntered,releaseNumbers,closes));
            try (var pending = pool.begin(jobs, 800L)) {
                await(numbersEntered);
                try {
                    check(pending.take(0,2).values.equals(List.of(0,1)),
                            "required actions arrive without waiting for the numeric reads");
                } finally {
                    releaseNumbers.countDown();
                }
                check(pending.take(2,4).values.equals(List.of(2,3)),
                        "missing numbers can use the original in-flight reads");
                check(closes.get()==4, "both groups release their query handles");
            }
        }
        try (BoundedReadBatch pool = new BoundedReadBatch(1)) {
            CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1), closed = new CountDownLatch(1);
            AtomicReference<BoundedReadBatch.Result<Integer>> out = new AtomicReference<>();
            Thread reader = new Thread(() -> out.set(pool.read(List.of(new BoundedReadBatch.Read<Integer>() {
                public Integer read() { entered.countDown();await(release);return 9; }
                public void close() { closed.countDown(); }
            }), 30)));
            reader.start();await(entered);reader.join(2000);
            check(out.get() != null && "BUDGET".equals(out.get().reason), "timeout returns while read remains blocked");
            check(closed.getCount() == 1, "caller never recycles in-flight node");
            check("BUSY".equals(pool.read(List.of(job(1,null,null,new AtomicInteger())),500).reason), "timeout still occupies bounded slot until actual completion");
            release.countDown();await(closed);
            check(out.get().values.isEmpty(), "late completion cannot publish evidence to abandoned caller");
        }
        try (BoundedReadBatch pool = new BoundedReadBatch(2)) {
            AtomicInteger recycled = new AtomicInteger();
            CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
            CountDownLatch completed = new CountDownLatch(1);
            BoundedReadBatch.Read<AutoCloseable> late = new BoundedReadBatch.Read<AutoCloseable>() {
                public AutoCloseable read() {
                    entered.countDown(); await(release);
                    return () -> recycled.incrementAndGet();
                }
                public void close() { completed.countDown(); }
            };
            BoundedReadBatch.Result<AutoCloseable> timeout = pool.read(List.of(late), 30);
            check("BUDGET".equals(timeout.reason), "query timeout cannot publish retained node lists");
            await(entered);release.countDown();await(completed);
            check(recycled.get() == 1, "late query result recycles all returned handles exactly once");

            BoundedReadBatch.Result<AutoCloseable> success = pool.read(List.of(
                    new BoundedReadBatch.Read<AutoCloseable>() {
                        public AutoCloseable read() { return () -> recycled.incrementAndGet(); }
                        public void close() { }
                    }), 500);
            check(success.complete() && recycled.get() == 1,
                    "successful query transfers result ownership to the caller");
            success.values.get(0).close();
            check(recycled.get() == 2, "caller releases transferred query result");

            BoundedReadBatch.Result<AutoCloseable> incomplete = pool.read(List.of(
                    new BoundedReadBatch.Read<AutoCloseable>() {
                        public AutoCloseable read() { return () -> recycled.incrementAndGet(); }
                        public void close() { }
                    },
                    new BoundedReadBatch.Read<AutoCloseable>() {
                        public AutoCloseable read() { return null; }
                        public void close() { }
                    }), 500);
            check("REFRESH_FAILED".equals(incomplete.reason) && recycled.get() == 3,
                    "partial query batch releases already-completed sibling results");
        }
        try (BoundedReadBatch rejectPool = new BoundedReadBatch(5)) {
            CountDownLatch allStarted = new CountDownLatch(5);
            AtomicInteger released = new AtomicInteger();
            List<BoundedReadBatch.Read<Integer>> independent = new ArrayList<>();
            for(int i=0;i<5;i++) {
                final int index=i;
                independent.add(new BoundedReadBatch.Read<Integer>() {
                    public Integer read() { allStarted.countDown(); await(allStarted); return index; }
                    public void close() { released.incrementAndGet(); }
                });
            }
            BoundedReadBatch.Result<Integer> five=rejectPool.read(independent,1500L);
            check(five.complete() && five.values.equals(List.of(0,1,2,3,4)) && released.get()==5,
                    "five Reject vocabulary queries execute concurrently and close independently");
        }
        try(BoundedReadBatch pool=new BoundedReadBatch(4)) {
            CountDownLatch started=new CountDownLatch(4),release=new CountDownLatch(1);
            AtomicInteger closes=new AtomicInteger();List<BoundedReadBatch.Read<Integer>> reads=new ArrayList<>();
            for(int i=0;i<4;i++)reads.add(job(i,started,release,closes));
            reads.add(job(4,null,null,closes));AtomicReference<BoundedReadBatch.Result<Integer>> result=new AtomicReference<>();
            Thread reader=new Thread(()->result.set(pool.readWaves(reads,1000)));reader.start();await(started);
            check(closes.get()==0,"five-node proof starts first four readers concurrently rather than serializing all five");
            release.countDown();reader.join(2000);
            check(result.get()!=null&&result.get().complete()&&result.get().values.equals(List.of(0,1,2,3,4))&&closes.get()==5,
                    "bounded waves retain all values in source order and close every input exactly once");
        }
        try(BoundedReadBatch pool=new BoundedReadBatch(1)) {
            AtomicInteger recycled=new AtomicInteger(),closes=new AtomicInteger();
            List<BoundedReadBatch.Read<AutoCloseable>> reads=List.of(
                new BoundedReadBatch.Read<AutoCloseable>(){public AutoCloseable read(){return ()->recycled.incrementAndGet();}public void close(){closes.incrementAndGet();}},
                new BoundedReadBatch.Read<AutoCloseable>(){public AutoCloseable read(){return null;}public void close(){closes.incrementAndGet();}},
                new BoundedReadBatch.Read<AutoCloseable>(){public AutoCloseable read(){throw new AssertionError("unsent wave executed");}public void close(){closes.incrementAndGet();}});
            BoundedReadBatch.Result<AutoCloseable> result=pool.readWaves(reads,1000);
            check(!result.complete()&&result.values.isEmpty()&&recycled.get()==1&&closes.get()==3,
                    "failed later wave closes completed values and never launches the remaining source");
        }
        try (BoundedReadBatch pool = new BoundedReadBatch(2)) {
            CountDownLatch entered = new CountDownLatch(2), release = new CountDownLatch(1);
            AtomicInteger closes = new AtomicInteger();
            var current = new java.util.concurrent.atomic.AtomicBoolean(true);
            var out = new AtomicReference<BoundedReadBatch.Result<Integer>>();
            try (var pending = pool.begin(List.of(job(1, entered, release, closes),
                    job(2, entered, release, closes)), 1500L)) {
                Thread reader = new Thread(() -> out.set(pending.takeWhile(0, 2, current::get)));
                reader.start();
                try {
                    await(entered);
                    current.set(false);
                    reader.join(500L);
                    check(out.get() != null && "YIELD".equals(out.get().reason) && closes.get() == 0,
                            "outdated indexed query group yields before its workers return");
                } finally {
                    release.countDown();
                }
            }
        }
        AtomicInteger initialized = new AtomicInteger();
        try (BoundedReadBatch priorityPool = new BoundedReadBatch(2, () -> {
            initialized.incrementAndGet();
            throw new SecurityException("priority denied by OS");
        })) {
            check(priorityPool.warmUp()==2, "priority workers prestart before first read");
            CountDownLatch started = new CountDownLatch(2);
            AtomicInteger released = new AtomicInteger();
            var res=priorityPool.read(List.of(
                new BoundedReadBatch.Read<Integer>() {
                    public Integer read(){started.countDown();await(started);return 1;}
                    public void close(){released.incrementAndGet();}
                },
                new BoundedReadBatch.Read<Integer>() {
                    public Integer read(){started.countDown();await(started);return 2;}
                    public void close(){released.incrementAndGet();}
                }), 1000L);
            check(initialized.get()==2 && res.complete() && res.values.equals(List.of(1,2))
                && released.get()==2, "priority denial cannot stop reads or leak bounded slots");
        }
        BoundedReadBatch closed = new BoundedReadBatch(1);closed.close();
        AtomicInteger cleans = new AtomicInteger();
        check("BUSY".equals(closed.read(List.of(job(1,null,null,cleans)),10).reason) && cleans.get()==1,
                "service teardown rejects reads and closes handles");
        System.out.println(checks + " bounded concurrent read lifecycle cases passed");
    }
}
