package com.local.cateringscreenassistant;
public final class AcceptSpinnerPolicyTest {
    static void check(boolean b){if(!b)throw new AssertionError();}
    public static void main(String[] args){
        int bg=0x2266cc;
        check(!AcceptSpinnerPolicy.ring(0,0,150,60,(x,y)->bg));
        check(!AcceptSpinnerPolicy.ring(0,0,150,60,(x,y)->Math.abs(y-30)<3?0xffffff:bg));
        check(!AcceptSpinnerPolicy.ring(0,0,150,60,(x,y)->Math.hypot(x-75,y-30)<16?0xffffff:bg));
        check(AcceptSpinnerPolicy.ring(0,0,150,60,(x,y)->{
            double r=Math.hypot(x-75,y-30);return r>11&&r<15&&y<39?0xffffff:bg;
        }));
        check(AcceptSpinnerPolicy.arcMask(0,0,150,60,
                (x,y)->x==75&&y==8?0xffffff:bg)!=0);
        check(AcceptSpinnerPolicy.arcMask(0,0,150,60,
                (x,y)->x==75&&y==8?0xffffff:0x333333)==0);
        AcceptSpinnerPolicy.Tracker t=new AcceptSpinnerPolicy.Tracker();
        check(!t.observe(1,100,15));check(!t.observe(1,100,15));
        check(t.observe(1,116,30));check(!t.observe(2,132,15));
        check(!t.observe(2,148,0));check(!t.observe(2,164,15));
        check(!t.observe(2,400,15));check(t.observe(2,416,30));
        System.out.println("AcceptSpinnerPolicyTest passed");
    }
}
