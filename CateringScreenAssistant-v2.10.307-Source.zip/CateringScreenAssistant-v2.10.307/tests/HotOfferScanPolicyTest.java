package com.local.cateringscreenassistant;

public final class HotOfferScanPolicyTest {
    private static int tests;
    private static void check(boolean value, String name) {
        tests++;
        if (!value) throw new AssertionError(name);
    }

    public static void main(String[] args) {
        check(HotOfferScanPolicy.heartbeatDelay(true) == 12L, "hot heartbeat");
        check(HotOfferScanPolicy.heartbeatDelay(false) == 12L, "idle heartbeat");
        check(HotOfferScanPolicy.standaloneHeartbeatDelay(true) == 12L,
                "standalone hot heartbeat");
        check(HotOfferScanPolicy.standaloneHeartbeatDelay(false) == 12L,
                "standalone idle heartbeat");
        check(HotOfferScanPolicy.evidenceHot(0L), "new evidence hot");
        check(HotOfferScanPolicy.evidenceHot(2500L), "hot boundary");
        check(!HotOfferScanPolicy.evidenceHot(2501L), "expired evidence");
        check(!HotOfferScanPolicy.evidenceHot(-1L), "missing evidence");
        check(HotOfferScanPolicy.shouldYieldToNewEvent(true, 31L), "brief event yield");
        check(!HotOfferScanPolicy.shouldYieldToNewEvent(true, 32L), "anti-starvation boundary");
        check(!HotOfferScanPolicy.shouldYieldToNewEvent(false, 20L), "clean queue");
        check(HotOfferScanPolicy.shouldProbeVisual(0L, 12L, false, false),
                "fresh numeric burst opens visual probe");
        check(HotOfferScanPolicy.shouldProbeVisual(900L, 80L, false, false),
                "visual probe window boundary");
        check(!HotOfferScanPolicy.shouldProbeVisual(901L, 80L, false, false),
                "expired burst closes visual probe");
        check(!HotOfferScanPolicy.shouldProbeVisual(20L, 11L, false, false),
                "visual probes are rate limited");
        check(HotOfferScanPolicy.shouldProbeVisual(20L, 80L, true, false),
                "in-flight OCR does not block independent raw visual probe");
        check(!HotOfferScanPolicy.shouldProbeVisual(20L, 80L, true, true),
                "busy OCR cannot bypass active transaction");
        check(!HotOfferScanPolicy.shouldProbeVisual(20L, 80L, false, true),
                "active action blocks visual probe");
        check(HotOfferScanPolicy.recentVisualNumericEvidence(0L, 0L, true, false),
                "same-generation universal numeric evidence");
        check(HotOfferScanPolicy.recentVisualNumericEvidence(160L, 3L, true, false),
                "near-generation evidence boundary");
        check(!HotOfferScanPolicy.recentVisualNumericEvidence(161L, 1L, true, false),
                "stale visual numeric evidence rejected");
        check(!HotOfferScanPolicy.recentVisualNumericEvidence(20L, 4L, true, false),
                "distant generation rejected");
        check(!HotOfferScanPolicy.recentVisualNumericEvidence(20L, 1L, false, false),
                "non-universal offer still needs complete rules");
        check(!HotOfferScanPolicy.recentVisualNumericEvidence(20L, 1L, true, true),
                "job detail cannot authorize offer action");
        System.out.println(tests + " hot-offer scan policy cases passed");
    }
}
