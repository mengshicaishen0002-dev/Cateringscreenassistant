package com.local.cateringscreenassistant;

public class QuickTreeBudgetPolicyTest {
    private static int n;
    private static void check(boolean value) { n++; if (!value) throw new AssertionError("case " + n); }
    public static void main(String[] args) {
        check(QuickTreeBudgetPolicy.maxNodes() == 128);
        check(QuickTreeBudgetPolicy.softBudgetMs() == 80L);
        check(QuickTreeBudgetPolicy.ocrBackoffMs() == 120L);
        check(!QuickTreeBudgetPolicy.elapsedBudgetExceeded(1000L, 1079L));
        check(QuickTreeBudgetPolicy.elapsedBudgetExceeded(1000L, 1080L));
        check(QuickTreeBudgetPolicy.shouldYieldToOcr(true, false));
        check(!QuickTreeBudgetPolicy.shouldYieldToOcr(true, true));
        check(!QuickTreeBudgetPolicy.shouldYieldToOcr(false, false));
        check(QuickTreeBudgetPolicy.remainingScanMs(1000L, 1040L, 45L, 25L) == 45L);
        check(QuickTreeBudgetPolicy.remainingScanMs(1000L, 1080L, 60L, 25L) == 20L);
        check(QuickTreeBudgetPolicy.remainingScanMs(1000L, 1100L, 80L, 0L) == 25L);
        check(QuickTreeBudgetPolicy.remainingScanMs(1000L, 1123L, 60L, 0L)
                < QuickTreeBudgetPolicy.MIN_TREE_SLICE_MS);
        check(QuickTreeBudgetPolicy.remainingScanMs(1000L, 1127L, 60L, 0L) == 0L);
        check(QuickTreeBudgetPolicy.remainingFallbackMs(1000L, 1037L, 80L, 0L) == 43L);
        check(QuickTreeBudgetPolicy.remainingFallbackMs(1000L, 1075L, 80L, 0L) < QuickTreeBudgetPolicy.MIN_TREE_SLICE_MS);
        check(QuickTreeBudgetPolicy.remainingFallbackMs(1000L, 1090L, 60L, 0L) == 0L);
        System.out.println(n + " quick-tree budget cases passed");
    }
}
