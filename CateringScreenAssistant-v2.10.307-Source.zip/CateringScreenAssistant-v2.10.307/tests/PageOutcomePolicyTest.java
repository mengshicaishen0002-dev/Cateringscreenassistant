package com.local.cateringscreenassistant;
public class PageOutcomePolicyTest {
 static int n;static final String OFFER="$96.40 10.8 mi Urbane Cafe • 2692 Canyon Springs Pkwy, Riverside, CA 92507";
 static void check(boolean ok,String name){n++;if(!ok)throw new AssertionError(name);}
 static PageOutcomePolicy.Baseline base(boolean negative){return new PageOutcomePolicy.Baseline(1,2,3,900,950,true,negative);}
 static PageOutcomePolicy.Tracker tracker(boolean clean){return new PageOutcomePolicy.Tracker(1000,OFFER,base(!clean),clean);}
 static PageOutcomePolicy.Reading read(long t,String hint,String context){return new PageOutcomePolicy.Reading(1,3,t,t+10,true,false,hint,context);}
 static String observe(PageOutcomePolicy.Tracker t,long at,String hint,String text){return t.observe(read(at,hint,text),at+10);}
 static PageOutcomePolicy.Reading completeSearch(long at,String text) {
  return new PageOutcomePolicy.Reading(1,3,at,at+10,true,false,"",text,
        "OK",7,36,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE");
 }
 public static void main(String[] args){
 PageOutcomePolicy.SurfaceGate surface=new PageOutcomePolicy.SurfaceGate();
 check(!surface.blocks(3),"unobserved surface adds no historical suppression");
 surface.observe(3,100,110,true,true,110);check(surface.blocks(3),"fresh live negative vetoes initial Accept");
 surface.observe(3,90,120,true,false,120);check(surface.blocks(3),"overlapping old clear read cannot erase newer failure");
 surface.observe(3,120,130,false,false,130);check(surface.blocks(3),"partial read cannot clear visible failure");
 surface.observe(3,120,130,true,false,400);check(surface.blocks(3),"stale clear publication cannot reopen dispatch");
 surface.observe(3,120,140,true,false,140);check(!surface.blocks(3),"independent clean current publication immediately reopens same card");
 surface.observe(3,150,160,true,true,160);check(surface.blocks(3)&&!surface.blocks(4),"old window never blocks a new live window");
 surface.observe(4,170,180,true,false,180);surface.observe(3,190,200,true,true,200);
 check(!surface.blocks(4),"late old-window negative cannot contaminate new page");
 surface.observe(4,200,400,true,true,400);check(!surface.blocks(4),"over-budget read cannot publish surface veto");
 check(base(false).cleanAt(1000,2,3),"fresh clean before evidence");
 check(!base(true).cleanAt(1000,2,3),"existing prompt is not clean");
 check(!base(false).cleanAt(1000,3,3),"generation mutation invalidates baseline");
 check(!base(false).cleanAt(1000,2,4),"window transition invalidates baseline");
 check(!base(false).cleanAt(1200,2,3),"old baseline expires");
 PageOutcomePolicy.Tracker t=tracker(true);
 check(observe(t,1100,"offer unavailable",OFFER).isEmpty(),"one post frame cannot confirm");
 check(!observe(t,1220,"offer unavailable",OFFER).isEmpty(),"eventless onset confirms on two fresh reads");
 check(t.diagnostic().contains("PAGE_EDGE"),"page source is explicit");
 t=tracker(false);observe(t,1100,"offer unavailable",OFFER);check(observe(t,1220,"offer unavailable",OFFER).isEmpty(),"persistent old prompt cannot bind");
 t=new PageOutcomePolicy.Tracker(1000,OFFER,null,false);observe(t,1100,"offer unavailable",OFFER);check(observe(t,1220,"offer unavailable",OFFER).isEmpty(),"unknown before cannot assert old or new");
 observe(t,1340,"",OFFER);observe(t,1460,"offer unavailable",OFFER);check(!observe(t,1580,"offer unavailable",OFFER).isEmpty(),"postdispatch clear then fresh onset can bind");
 t=tracker(true);t.observe(read(990,"offer unavailable",OFFER),1000);check(observe(t,1100,"offer unavailable",OFFER).isEmpty(),"capture started before tap never counts");
 t=tracker(true);observe(t,1100,"offer unavailable",OFFER);check(observe(t,1100,"offer unavailable",OFFER).isEmpty(),"same cached frame cannot count twice");
 check(observe(t,1130,"offer unavailable",OFFER).isEmpty(),"too close samples cannot count twice");
 t=tracker(true);observe(t,1100,"offer unavailable",null);check(observe(t,1220,"offer unavailable",OFFER).isEmpty(),"partial read cannot prove absence");
 t=tracker(true);observe(t,1100,"offer unavailable","$98 8.6 mi Other Cafe");check(observe(t,1220,"offer unavailable",OFFER).isEmpty(),"other top order permanently blocks old transaction proof");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,true,"offer unavailable",OFFER),1110);check(observe(t,1220,"offer unavailable",OFFER).isEmpty(),"positive job surface vetoes loss");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(2,4,1100,1110,true,false,"offer unavailable",""),1110);
 check(!t.observe(new PageOutcomePolicy.Reading(2,4,1220,1230,true,false,"offer unavailable",""),1230).isEmpty(),"new prompt-only modal after clean before is accepted");
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(2,4,1100,1110,true,false,"offer unavailable",""),1110);
 check(t.observe(new PageOutcomePolicy.Reading(2,4,1220,1230,true,false,"offer unavailable",""),1230).isEmpty(),"unknown old modal cannot bind");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1310,true,false,"offer unavailable",OFFER),1310);check(observe(t,1430,"offer unavailable",OFFER).isEmpty(),"overbudget sample cannot count");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,false,false,"offer unavailable",OFFER),1110);check(observe(t,1220,"offer unavailable",OFFER).isEmpty(),"incomplete query cannot count");
 String replacement="$28.00 6.3 mi Tomorrow at 10:30 AM Mendocino Farms • 450 E 17th St, Costa Mesa, CA 92627";
 t=tracker(true);
 check(t.noteLoadingFrame(1289,1300),"visible in-transaction spinner is fresh");
 t.observe(completeSearch(1350,replacement),1360);
 check(t.noteLoadingFrame(1400,1410),"next spinner frame extends the same owner");
 t.observe(completeSearch(1496,replacement),1506);
 check(!t.hasConfirmedDeparture()&&!t.hasFreshDifferentTop(1506),"Erewhon replay: lower action row cannot release the spinning owner");
 check(observe(t,1550,"offer unavailable",OFFER).isEmpty(),"first current failure remains provisional during loading");
 check(!observe(t,1610,"offer unavailable",OFFER).isEmpty(),"same-offer terminal evidence still closes a spinning owner");

 t=tracker(true);
 t.noteLoadingFrame(1289,1300);
 t.observe(completeSearch(1350,replacement),1360);
 observe(t,1550,"",replacement);
 check(!t.hasFreshDifferentTop(1560),"partial owned-row search cannot release after loading");
 t.observe(completeSearch(1620,replacement),1630);
 check(!t.hasConfirmedDeparture(),"first full miss after loading does not reuse an earlier miss");
 t.observe(completeSearch(1690,replacement),1700);
 check(t.hasConfirmedDeparture(),"two full misses after loading release the vanished offer");

 t=tracker(true);
 t.observe(completeSearch(1350,replacement),1360);
 t.observe(completeSearch(1496,replacement),1506);
 check(t.hasConfirmedDeparture(),"departure proof can race with frame publication");
 check(t.noteLoadingFrame(1450,1510)&&!t.hasConfirmedDeparture()&&!t.hasFreshDifferentTop(1510),
       "fresh spinner evidence cancels provisional departure at commit");

 t=tracker(true);
 t.noteLoadingFrame(1400,1410);
 for (long at : new long[]{1700L, 1790L}) {
  t.observe(new PageOutcomePolicy.Reading(1,3,at,at+10,true,false,"offer unavailable",replacement,
      "OK",7,24,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),at+10);
  check(t.bound.isEmpty(),"negative banner on the replacement never becomes the prior order's terminal result");
  check(t.hasFreshDifferentTop(at+10)==(at==1790L),
        "two complete replacement reads release the old order even while a negative banner is visible");
 }
 check(t.hasConfirmedDeparture() && !t.mayProbeContinuous(1800),"confirmed departure ends regular polling");
 t=tracker(true);
 t.observe(new PageOutcomePolicy.Reading(1,3,1700,1710,false,false,"",null,"FOREIGN_APP",0,0),1710);
 check(t.nextContinuousProbeDelayMs(20,1710)>=500L,"foreground mismatch backs off continuous reads");

 t=tracker(true);observe(t,1100,"",replacement);
 check(t.hasFreshDifferentTop(1110)&&t.hasFreshDifferentTop(1610)&&!t.hasFreshDifferentTop(1611),"coherent replacement releases only while fresh");
 t=tracker(true);observe(t,1100,"","$28 6.3 mi");
 check(!t.hasFreshDifferentTop(1110),"partial identity cannot release early");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(2,4,1100,1110,true,false,"",replacement),1110);
 check(!t.hasFreshDifferentTop(1110),"foreign window cannot release early");
 t=tracker(true);observe(t,1100,"offer unavailable",replacement);
 check(!t.hasFreshDifferentTop(1110),"unbound negative on replacement cannot release early");
 check(!PageOutcomePolicy.compatible(OFFER,OFFER.replace("2692","2693")),"different endpoint rejected");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,4,1100,1110,true,false,"offer unavailable",OFFER),1110);
 check(!t.blocked&&t.status.equals("WAIT_SECOND_READ"),"same window and re-proved card survive window-event epoch change");
 check(!t.observe(new PageOutcomePolicy.Reading(1,4,1230,1240,true,false,"offer unavailable",OFFER),1240).isEmpty(),"two fresh frames at new epoch confirm real onset");
 t=tracker(true);observe(t,1100,"offer unavailable",OFFER);t.observe(new PageOutcomePolicy.Reading(1,4,1230,1240,true,false,"offer unavailable",OFFER),1240);
 check(t.bound.isEmpty(),"epoch change restarts proof; never reuses a frame from old epoch");
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,4,1100,1110,true,false,"offer unavailable",""),1110);
 check(!t.blocked&&t.status.equals("WAIT_WINDOW_CONTEXT"),"same-window epoch change without card context waits without accepting arbitrary UI");
 check(t.observe(new PageOutcomePolicy.Reading(1,4,1230,1240,true,false,"offer unavailable",""),1240).isEmpty(),"empty context cannot bypass epoch ownership guard");
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,4,1100,1110,true,false,"offer unavailable",OFFER),1110);
 check(t.observe(new PageOutcomePolicy.Reading(1,4,1230,1240,true,false,"offer unavailable",OFFER),1240).isEmpty(),"old baseline prompt still cannot bind after same-window churn");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,false,false,"",null,"TIME_LIMIT",2,40),1110);
 check(t.status.equals("INCOMPLETE:TIME_LIMIT"),"budget exit stays distinct from page absence");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,4,1100,1110,true,false,"offer unavailable",""),1110);
 check(!t.observe(new PageOutcomePolicy.Reading(1,4,1230,1240,true,false,"offer unavailable",""),1240).isEmpty(),"prompt-only same-window modal after clean baseline survives epoch change");
 check(tracker(false).diagnostic().contains("first=NONE,last=NONE"),"missing clocks never subtract boot uptime");
 check(tracker(false).diagnostic().contains("baseline=UNPROVEN"),"unknown baseline is not labelled post-clear");
 t=tracker(false);observe(t,1100,"",OFFER);
 check(t.diagnostic().contains("baseline=POST_CLEAR"),"post-clear only after actual fresh absence");
 t=tracker(true);observe(t,2126,"offer unavailable",OFFER);
 check(t.mayProbe(6,1000,2146),"last normal read with onset reserves confirmation");
 check(!observe(t,2270,"offer unavailable",OFFER).isEmpty(),"late extra read confirms onset");
 check(!t.mayProbe(7,1000,2300),"confirmed result stops reads");
 t=tracker(true);observe(t,2302,"offer unavailable",OFFER);
 check(t.mayProbe(3,1000,2330),"late candidate survives normal time budget");
 check(!t.mayProbe(16,1000,2400),"extra reads remain bounded");
 check(!t.mayProbe(10,1000,4000),"candidate grace expires");
 t=tracker(true);observe(t,2100,"",OFFER);
 check(t.mayProbe(2,1000,2751),"1660ms queue gap retains useful-read budget");
 check(!t.mayProbe(14,1000,2800),"invalid replacement attempts bounded");
 check(!t.mayProbe(2,1000,4000),"hard deadline prevents infinite wait");
 t=tracker(true);
 for(int i=0;i<12;i++)observe(t,1040+i*250,"",OFFER);
 check(!t.mayProbe(12,1000,2400),"six valid clear reads stop");
 t=tracker(true);
 for(int i=0;i<2;i++)t.observe(new PageOutcomePolicy.Reading(1,3,1100+i*100,1110+i*100,false,false,"",null,"UI_CHANGED",6,49),1110+i*100);
 check(t.validReads==0&&t.mayProbe(2,1000,2300),"Portos zero valid reads get bounded replacements");
 observe(t,2350,"offer unavailable",OFFER);
 check(!observe(t,2600,"offer unavailable",OFFER).isEmpty(),"replacement reads bind fresh failure");
 t=tracker(true);
 t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",OFFER+" Today at 11:10 AM","OK",7,20,
        "Offer unavailable. Please contact support.","DISABLED"),1110);
 check(t.audit().contains("firstDisabled=110ms")&&t.audit().contains("contact support")
        &&t.audit().contains("11:10"),"fresh compatible page preserves raw prompt, state and pickup diagnostics");
 check(t.bound.isEmpty(),"diagnostic excerpt and disabled node never assert failure or success");
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,false,false,"",OFFER,"UI_CHANGED",7,20,
        "MUST NOT RECORD","ENABLED"),1210);
 check(!t.audit().contains("MUST NOT RECORD")&&t.audit().contains("ACCEPT_NODE=DISABLED"),"invalid frame cannot replace diagnostic evidence");
 check(ClaimSuccessSignals.outcomeExcerpt("Offer unavailable. This route conflicts with an existing job.").contains("route conflicts"),"conflict raw excerpt wins generic unavailable");
 check(ClaimSuccessSignals.outcomeExcerpt("OFFER UNAVAILABLE: Please retry later.").contains("Please retry later"),"generic error retains original case and reason");
 check(ClaimSuccessSignals.outcomeExcerpt("Today at 11:10 AM Cafe").isEmpty(),"ordinary card is not an error excerpt");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",OFFER,"OK",7,20,"","ENABLED"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"",OFFER,"OK",7,20,"","NOT_EXPORTED"),1210);
 check(t.audit().contains("firstEnabled=110ms")&&t.audit().contains("ACCEPT_NODE=NOT_EXPORTED"),"later absence does not erase historical enabled node observation");
 // v174 bounded transient recovery preserves useful evidence, confirmation and the late tail.
 t=tracker(true);check(t.nextProbeDelayMs(0,1000)==20,"initial observation targets20ms");
 for(int i=0;i<4;i++) {
  long at=1100+i*70;t.observe(new PageOutcomePolicy.Reading(1,3,at,at+10,false,false,"",null,"UI_CHANGED",1,0),at+10);
  check(t.nextProbeDelayMs(i+1,at+10)==(i<3?12:360),"only three quick recoveries: "+i);
 }
 check(t.validReads==0&&t.bound.isEmpty(),"invalid reads remain non-evidence");
 check(t.mayProbe(16,1000,2000)&&!t.mayProbe(17,1000,2000),"three credits extend total attempts by exactly three");
 check(!t.mayProbe(1,1000,4000),"credits never extend three-second ceiling");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,false,false,"",null,"TIME_LIMIT",6,40),1110);
 check(t.nextProbeDelayMs(1,1110)==12,"timeout gets short bounded recovery");
 t.observe(null,1120);check(t.nextProbeDelayMs(2,1120)==360,"null read cannot perpetuate a short-retry loop");
 for(String reason:new String[]{"YIELD","FOREIGN_APP","NO_ROOT","READ_EXCEPTION"}) {
  t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,false,false,"",null,reason,0,0),1110);
  check(t.nextProbeDelayMs(1,1110)==360&&!t.mayProbe(14,1000,2000),"non-transient failure cannot earn credits: "+reason);
 }
 t=tracker(true);for(int i=0;i<11;i++)observe(t,1100+i*60,"",OFFER);
 check(t.nextProbeDelayMs(11,1710)==1690,"fifth useful clear read reserves last read near dispatch+2400ms");
 check(t.nextContinuousProbeDelayMs(11,1710)==80,"continuous active observation never waits for the obsolete last-read reservation");
 for(int reads:new int[]{10,11,12,40,500}) check(t.nextContinuousProbeDelayMs(reads,1710)==80,"continuous cadence stays responsive across any read count");

 t=tracker(true);
 for(int i=0;i<3;i++){long at=1100+i*100;t.observe(new PageOutcomePolicy.Reading(1,3,at,at+10,true,false,"",OFFER,"OK",7,47,"","NOT_EXPORTED"),at+10);}
 check(t.noteLoadingFrame(1315,1315),"valid live loading cue");
 check(t.nextContinuousProbeDelayMs(3,1315)==160,"stable visual loading coalesces ordinary page queries");
 check(t.nextContinuousProbeDelayMs(3,1440)==80,"stale visual loading does not slow ordinary outcome observation");
 t.observe(new PageOutcomePolicy.Reading(1,3,1450,1460,true,false,"offer unavailable",OFFER,"OK",7,47),1460);
 check(t.nextContinuousProbeDelayMs(4,1460)<160,"negative confirmation bypasses loading coalescer");
 t=tracker(true);int count=0;long now=1000;
 while(t.mayProbe(count,1000,now)) {
  now+=t.nextProbeDelayMs(count,now);if(now>=4000)break;
  boolean complete=count>=3;String hint=complete&&now>=3241?"offer unavailable":"";
  t.observe(new PageOutcomePolicy.Reading(1,3,now,now+10,complete,false,hint,complete?OFFER:null,complete?"OK":"UI_CHANGED",complete?7:1,20),now+10);
  now+=10;count++;
 }
 check(t.bound.equals("offer unavailable")&&now<4000&&count<=19,"fast early recovery still confirms a2241ms late response before deadline");
 String full=OFFER+" Tomorrow at 10:10 AM";
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",full,"OK",7,20,"","ENABLED"),1110);
 check(t.shouldWakeEnabledRecheck(1110)&&!t.retryDecision(1110).isEmpty(),"known original endpoint plus first full enabled reading immediately wakes guarded retry");
 check(t.nextProbeDelayMs(1,1110)==120,"background observations do not delay the immediate current-proof wake");
 check(!t.shouldWakeEnabledRecheck(1400),"old enabled observation cannot wake inspector");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",full,"OK",7,20,"","DISABLED"),1110);
 check(!t.shouldWakeEnabledRecheck(1110),"disabled control never wakes retry from new path");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"offer unavailable",full,"OK",7,20,"","ENABLED"),1110);
 check(!t.shouldWakeEnabledRecheck(1110)&&t.nextProbeDelayMs(1,1110)==50,"new negative outranks enabled state and short recovery");
 check(observe(t,1154,"offer unavailable",full).isEmpty(),"strong proof still requires fresh spacing");
 t=tracker(true);observe(t,1100,"offer unavailable",full);
 check(!observe(t,1160,"offer unavailable",full).isEmpty(),"same-endpoint fresh confirmation uses shorter spacing");
 t=tracker(true);observe(t,1100,"offer unavailable","");
 check(t.nextProbeDelayMs(1,1110)==90,"prompt without card retains ordinary spacing");
 check(observe(t,1160,"offer unavailable",full).isEmpty(),"weak first proof cannot use short spacing");
 check(!observe(t,1200,"offer unavailable",full).isEmpty(),"weak first proof confirms on ordinary spacing");
 // v176 early RN action export gap uses a bounded faster observation cadence.
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",OFFER,"OK",7,20,"","NOT_EXPORTED"),1110);
 check(t.nextProbeDelayMs(1,1110)==120 && !t.shouldWakeEnabledRecheck(1110) && t.bound.isEmpty(),"missing action shortens observation only, never authorizes retry");
 t.observe(new PageOutcomePolicy.Reading(1,3,1220,1230,true,false,"",OFFER,"OK",7,20,"","NOT_EXPORTED"),1230);
 check(t.nextProbeDelayMs(2,1230)==120,"second early gap remains responsive");
 t.observe(new PageOutcomePolicy.Reading(1,3,1340,1350,true,false,"",OFFER,"OK",7,20,"","NOT_EXPORTED"),1350);
 check(t.nextProbeDelayMs(3,1350)==120,"third useful read retains fast cadence");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1800,1810,true,false,"",OFFER,"OK",7,20,"","NOT_EXPORTED"),1810);
 check(t.nextProbeDelayMs(1,1810)==120,"later clear page stays responsive within read budget");
 // v179 two clean full identities survive a missing exported button; current control still owns dispatch.
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",full,"OK",7,20,"","ENABLED"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1220,1230,true,false,"",full,"OK",7,20,"","NOT_EXPORTED"),1230);
 check(!t.retryDecision(1230).isEmpty() && t.shouldWakeEnabledRecheck(1230),"fresh enabled observation plus independent clean full identity wakes current control check");
 check(!t.retryDecision(1361).isEmpty(),"fresh two-read identity may request a final live button check despite an older enabled observation");
 check(t.retryDecision(1481).isEmpty(),"identity proof expires after250ms even when the button is not exported");
 t.observe(new PageOutcomePolicy.Reading(1,3,1250,1260,true,false,"",full,"OK",7,20,"","DISABLED"),1260);
 check(t.retryDecision(1260).isEmpty(),"explicit disabled control immediately blocks retry decision");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",full,"OK",7,20,"","NOT_EXPORTED"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1220,1230,true,false,"",full,"OK",7,20,"","NOT_EXPORTED"),1230);
 check(!t.retryDecision(1230).isEmpty() && t.shouldWakeEnabledRecheck(1230),
         "two clean full identities request final live same-card enabled check despite missing exports");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",full,"OK",7,20,"","ENABLED"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1220,1230,false,false,"",full,"UI_CHANGED",2,3,"","UNKNOWN"),1230);
 t.observe(new PageOutcomePolicy.Reading(1,3,1250,1260,true,false,"",full,"OK",7,20,"","NOT_EXPORTED"),1260);
 check(t.retryDecision(1260).isEmpty(),"invalid frame discards previous enabled bridge");
 // v194: coalescing changes read scheduling only, never retry/terminal evidence.
 t=tracker(true);check(t.deferVisualRead(1100),"short first page-read head start avoids immediate competing OCR");
 check(!t.deferVisualRead(1200),"no page response reopens OCR after200ms");
 t.observe(new PageOutcomePolicy.Reading(1,3,1220,1230,true,false,"",OFFER,"OK",7,20,"","NOT_EXPORTED"),1230);
 check(t.deferVisualRead(1300)&&t.deferControlRead(1279),"fresh missing export coalesces heavy OCR and duplicate index");
 check(!t.deferControlRead(1280),"control reread returns at50ms");
 check(!t.deferVisualRead(1580),"visual fallback returns at350ms without refreshed evidence");
 check(t.retryDecision(1300).isEmpty()&&t.bound.isEmpty(),"coalescing grants no action or outcome");
 t.observe(new PageOutcomePolicy.Reading(1,3,1360,1370,false,false,"",null,"UI_CHANGED",1,0),1370);
 check(!t.deferVisualRead(1380)&&!t.deferControlRead(1380),"invalid UI read immediately reopens fallback");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",full,"OK",7,20,"","NOT_EXPORTED"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1220,1230,true,false,"",full,"OK",7,20,"","NOT_EXPORTED"),1230);
 check(!t.deferControlRead(1240),"two clean identities wake current live enabled check immediately");
 check(t.deferVisualRead(1240)&&!t.retryDecision(1240).isEmpty(),"coalescing preserves identity evidence");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",full,"OK",7,20,"","ENABLED"),1110);
 check(!t.deferControlRead(1120),"enabled export never delays retry inspector");
 t=tracker(true);observe(t,1100,"offer unavailable",OFFER);
 check(t.deferVisualRead(1120)&&!t.deferControlRead(1120),"pending negative keeps terminal checks and skips duplicate OCR");
 observe(t,1250,"offer unavailable",OFFER);
 check(!t.deferVisualRead(1270),"bound terminal restores independent verification OCR");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,true,"",full,"OK",7,20,"","UNKNOWN"),1110);
 check(!t.deferVisualRead(1120),"positive detail opens visual verification");
 check(!tracker(true).deferVisualRead(999),"clock reversal never suppresses OCR");
 // v241: a coherent live row with a temporary action export gap is not a spinner.
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",OFFER,"OK",7,20,"","NOT_EXPORTED"),1110);
 check(t.pressureBlockReason().isEmpty(),"same-card missing caption does not pause pre-spinner pressure");
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"","","OK",7,20,"","NOT_EXPORTED"),1210);
 check(!t.pressureBlockReason().isEmpty(),"missing owned row still revokes old coordinates");
 // v230: pressure authority and terminal ownership are independent.
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,false,false,"",null,"FOREIGN_APP",0,0),1110);
 check(t.pressureBlockReason().equals("FOREIGN_APP")&&!t.retryContextBlocked()&&t.bound.isEmpty(),"foreign root pauses physical taps without inventing a server result");
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"",OFFER,"OK",7,20,"","NOT_EXPORTED"),1210);
 check(!t.pressureBlockReason().isEmpty(),"missing label never restores cached CTA authority");
 t.observe(new PageOutcomePolicy.Reading(1,3,1300,1310,true,false,"",OFFER,"OK",7,20,"","ENABLED"),1310);
 check(t.pressureBlockReason().isEmpty(),"coherent current enabled same-card proof restores authority");
 t.observe(new PageOutcomePolicy.Reading(1,3,1400,1410,true,false,"",OFFER,"OK",7,20,"","DISABLED"),1410);
 check(t.pressureBlockReason().isEmpty()&&t.bound.isEmpty(),"same-card disabled state does not replace visual spinner stop");
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",OFFER,"OK",7,20,"","ENABLED"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,4,1200,1210,true,false,"offer unavailable","","OK",7,16,"This offer is no longer available.","NOT_EXPORTED"),1210);
 check(t.status.equals("WAIT_SECOND_READ")&&t.hasPendingNegative(),"post-dispatch clean original card owns newer same-window prompt onset");
 check(!t.observe(new PageOutcomePolicy.Reading(1,4,1300,1310,true,false,"offer unavailable","","OK",7,16,"This offer is no longer available.","NOT_EXPORTED"),1310).isEmpty(),"POST_CLEAR modal confirms after two fresh frames at new epoch");
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,4,1100,1110,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),1110);
 check(t.hasVisibleNegative()&&!t.hasFreshUnboundPrompt(1110),"single unbound prompt pauses immediately but does not navigate");
 t.notePressureRevalidated(OFFER,1150);check(!t.pressureBlockReason().isEmpty(),"button-only rebind cannot erase a visible unbound negative");
 t.observe(new PageOutcomePolicy.Reading(1,4,1200,1210,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),1210);
 check(t.bound.isEmpty()&&t.hasFreshUnboundPrompt(1210),"two unknown prompts authorize guarded recovery without false failure attribution");
 check(!t.hasFreshUnboundPrompt(1711),"unbound navigation hint expires");
 t.observe(new PageOutcomePolicy.Reading(1,4,1300,1310,true,false,"",OFFER,"OK",7,20,"","ENABLED"),1310);
 check(!t.hasVisibleNegative()&&!t.hasFreshUnboundPrompt(1310)&&t.pressureBlockReason().isEmpty(),"fresh clear enabled original cancels prompt recovery and allows current rebind");
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"","","OK",7,16,"","NOT_EXPORTED"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,4,1200,1210,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),1210);
 check(t.status.equals("WAIT_WINDOW_CONTEXT")&&t.bound.isEmpty(),"empty clear page cannot fabricate original-card modal ownership");
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,4,1100,1110,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,5,1200,1210,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),1210);
 check(!t.hasFreshUnboundPrompt(1210),"different epochs cannot combine into unbound navigation proof");
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",OFFER,"OK",7,20,"","ENABLED"),1110);
 t.observe(new PageOutcomePolicy.Reading(2,4,1200,1210,true,false,"offer unavailable","","OK",7,16,"prompt","NOT_EXPORTED"),1210);
 check(t.bound.isEmpty(),"post-clear original does not own arbitrary other-window prompt");
 // A different top is provisional until two all-row observations miss the active offer.
 String injected="$19 4.8 mi Today at 10:50 AM Urbane Cafe • 4001 N Lakewood Blvd Suite 100, Long Beach, CA 90846";
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1110);
 check(!t.blocked&&!t.hasFreshDifferentTop(1110)&&t.status.equals("WAIT_OWNED_ROW"),"one coherent new top never retires the active transaction");
 check(!t.pressureBlockReason().isEmpty()&&t.nextProbeDelayMs(1,1110)==50L,"first absence revokes old coordinates and promptly rechecks all rows");
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"",OFFER,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1210);
 check(!t.blocked&&t.pressureBlockReason().isEmpty()&&t.bound.isEmpty(),"owned row reappearing below inserted top keeps the original transaction alive");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1140,1150,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1150);
 check(!t.blocked&&!t.hasFreshCleanReplacement(1150),"two close reads cannot release the foreground");
 t.observe(new PageOutcomePolicy.Reading(1,3,1170,1180,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1180);
 check(t.blocked&&t.hasFreshCleanReplacement(1180)&&t.bound.isEmpty(),"two clean misses release foreground as UNKNOWN");
 check(!t.hasFreshCleanReplacement(1681),"stale replacement cannot release the foreground");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,4,1200,1210,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1210);
 check(!t.blocked,"different window epochs cannot combine into departure proof");
  t=tracker(true);String repriced=OFFER.replace("96.40","97.40");
 t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",repriced,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"",repriced,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1210);
 check(t.hasFreshDifferentTop(1210),"two complete misses release even when replacement differs in just one identity field");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1150,1160,false,false,"",null,"UI_CHANGED",7,34),1160);
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1210);
 check(!t.blocked&&t.status.equals("WAIT_OWNED_ROW"),"incomplete transition breaks consecutive absence proof");
  // v232: read-only failure onset may finish a still-active departed transaction.
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1210);
 check(t.hasConfirmedDeparture()&&!t.mayProbeContinuous(1210),"departure blocks ordinary probes and every retry");
 t.requestDepartureOutcomeProbe(1250);check(t.departureOutcomePending(1250)&&t.mayProbeContinuous(1250),"fresh unbound hint opens bounded observation-only final proof");
 t.observe(new PageOutcomePolicy.Reading(1,3,1300,1310,true,false,"offer unavailable",injected,"OK",7,16,"This offer is no longer available.","NOT_EXPORTED"),1310);
 check(t.bound.isEmpty()&&t.retryContextBlocked()&&t.retryDecision(1310).isEmpty(),"first departed failure read never reauthorizes a click");
 t.observe(new PageOutcomePolicy.Reading(1,3,1400,1410,true,false,"offer unavailable",injected,"OK",7,16,"This offer is no longer available.","NOT_EXPORTED"),1410);
 check(t.bound.equals("offer unavailable")&&t.status.equals("CONFIRMED_DEPARTED_PAGE_EDGE")&&!t.mayProbeContinuous(1410),"two fresh page onsets close original active transaction after list departure");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1210);t.requestDepartureOutcomeProbe(1250);
 t.observe(new PageOutcomePolicy.Reading(1,3,1300,1310,true,false,"offer unavailable","","OK",7,16),1310);
 t.observe(new PageOutcomePolicy.Reading(1,3,1350,1360,false,false,"",null,"FOREIGN_APP",0,0),1360);
 t.observe(new PageOutcomePolicy.Reading(1,3,1420,1430,true,false,"offer unavailable","","OK",7,16),1430);
 check(t.bound.isEmpty(),"foreign/incomplete reading breaks final negative proof");
 check(!t.departureOutcomePending(1650),"final read-only grace has a hard400ms deadline");
 t.requestDepartureOutcomeProbe(1700);check(!t.departureOutcomePending(1700),"repeated hints cannot extend final observation or restart clicking");
 t=tracker(false);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1210);t.requestDepartureOutcomeProbe(1250);
 check(!t.departureOutcomePending(1250),"no clean owned baseline cannot fabricate late failure ownership");
 t=tracker(true);t.observe(new PageOutcomePolicy.Reading(1,3,1100,1110,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1110);
 t.observe(new PageOutcomePolicy.Reading(1,3,1200,1210,true,false,"",injected,"OK",7,34,"","ENABLED","OWNED_ROW_SEARCH=COMPLETE"),1210);t.requestDepartureOutcomeProbe(1250);
 t.observe(new PageOutcomePolicy.Reading(1,3,1300,1310,true,true,"offer unavailable",OFFER,"OK",7,16),1310);
 check(t.bound.isEmpty()&&!t.departureOutcomePending(1310),"positive surface vetoes final failure attribution");
 t.requestDepartureOutcomeProbe(1350);
 check(!t.departureOutcomePending(1350),"repeated negative hints cannot reopen proof after positive surface");
 System.out.println(n+" fresh-page outcome policy cases passed");
 }
}
