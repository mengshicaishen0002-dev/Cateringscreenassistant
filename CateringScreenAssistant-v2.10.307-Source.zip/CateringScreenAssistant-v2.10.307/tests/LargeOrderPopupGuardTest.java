package com.local.cateringscreenassistant;

public class LargeOrderPopupGuardTest {
    public static void main(String[] args) {
        check(LargeOrderPopupGuard.isPopupText(
                "Large Order This order is eligible to have multiple drivers assigned to complete the delivery. "
                        + "Earnings are split equally between all assigned drivers."), "real popup");
        check(LargeOrderPopupGuard.isPopupText(
                "This order is eligible to have multiple drivers assigned to complete the delivAy Earnins ara snlit eguellv X"),
                "ocr popup");
        check(LargeOrderPopupGuard.hasStrongFragment("drivers assigned to complete the delivery"), "event fragment");
        check(!LargeOrderPopupGuard.isPopupText(
                "Today 1 Offer 12.7 mi Est. $38.11 Chicken Maison Large Order"), "plain large order card");
        check(LargeOrderPopupGuard.isInfoTriggerLabel("Large Order"), "large order info trigger");
        check(LargeOrderPopupGuard.isInfoTriggerLabel("Large Order information"), "info label");
        check(!LargeOrderPopupGuard.isInfoTriggerLabel("Ignore"), "Ignore is not info trigger");
        System.out.println("LargeOrderPopupGuardTest passed");
    }

    private static void check(boolean value, String name) {
        if (!value) throw new AssertionError(name);
    }
}
