package com.local.cateringscreenassistant;

public final class AnchorlessOfferGuardTest {
    private static int tests;
    private static void check(boolean value, String message) {
        tests++;
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        check(AnchorlessOfferGuard.eligibleForRescue(
                "$64.79 Est. 7.1 mi (~16 mins) Tomorrow at 11:10 AM, Rubio's Coastal Grill • "
                        + "12010 Lakewood Blvd, Downey, CA 90242, United States"),
                "complete card without action label remains rescue eligible");
        check(AnchorlessOfferGuard.eligibleForRescue(
                "$120.68 17.4 mi Tomorrow at 11:15 AM Accept"),
                "semantic action is sufficient");
        check(!AnchorlessOfferGuard.eligibleForRescue(
                "South Gate Bell Gardens 7.1 mi Pickup 11:10 AM Est. $64.79 Tomorrow at 11:10 AM"),
                "map fragment has no bound address/action");
        check(!AnchorlessOfferGuard.eligibleForRescue(
                "Tomorrow 2 Jobs Tomorrow at 11:10 AM Rubio's • 12010 Lakewood Blvd, Downey, "
                        + "CA 90242 5 mi Est. $31-41 Tomorrow at 2:45 PM"),
                "multi-card composite is rejected");
        check(!AnchorlessOfferGuard.eligibleForRescue(
                "7.1 mi Est. $64.79 Tomorrow at 11:10 AM olo_46757685450031106"),
                "id-only transition fragment is rejected");
        System.out.println(tests + " anchorless OCR guard cases passed");
    }
}
