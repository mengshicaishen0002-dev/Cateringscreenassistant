package com.local.cateringscreenassistant;

public final class RejectConfirmPriorityPolicyTest {
    private static int tests;
    private static void check(boolean condition, String message) { tests++; if (!condition) throw new AssertionError(message); }
    public static void main(String[] args) {
        check(RejectConfirmPriorityPolicy.finalTailMs() == 160L, "final tail");
        check(RejectConfirmPriorityPolicy.finalTailPollMs() == 40L, "tail poll");
        check(RejectConfirmPriorityPolicy.finalEmptyRecheckMs() == 120L, "empty recheck");
        String oldOffer = "$29–39 Est. 2.1 mi Tomorrow at 10:15 AM Mendocino Farms • Huntington Beach, CA";
        String sameOffer = "$29-39 2.1 mi Tomorrow at 10:15 AM Mendocino Farms Huntington Beach CA";
        String newOffer = "$66.67 Est. 1.8 mi Tomorrow at 10:00 AM Mendocino Farms • El Segundo, CA";
        check(!RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldOffer, sameOffer), "same offer");
        check(RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldOffer, newOffer), "new offer");
        check(!RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldOffer, ""), "blank top");
        String ocrA = "Est. $7.75 O 0.7 mi (-3 mins) Tomorrow at 7:00 AM Corner Bakery Cafe • 111S Westlake Blvd, Westlake Village, CA 91362, United States";
        String ocrB = ocrA.replace("7.75", "7.7").replace("Westlake Blvd", "Westla Blvd");
        check(CardText.sameRejectObservation(ocrA, ocrB), "observed OCR amount/street drift is suppression only");
        check(!CardText.sameOfferForAction(ocrA, ocrB), "drift cannot authorize an action");
        check(!RejectConfirmPriorityPolicy.shouldDeferForNewTop(ocrA, ocrB), "drift cannot prove departure");
        check(!CardText.sameRejectObservation(ocrA, ocrB.replace("7:00", "8:00")), "new pickup cannot merge");
        check(!CardText.sameRejectObservation(ocrA, ocrB.replace("111S", "112S")), "street digits cannot merge");
        check(!CardText.sameRejectObservation(ocrA, ocrB.replace("91362", "91363")), "ZIP digits cannot merge");
        check(!CardText.sameRejectObservation(ocrA, ocrB.replace("Corner Bakery Cafe", "Luna Grill")), "different merchant cannot merge");
        check(!CardText.sameRejectObservation(ocrA, ocrB.replace("0.7 mi", "1.7 mi")), "different mileage cannot merge");
        check(!CardText.sameRejectObservation(ocrA, ocrB.replace("7.7", "8.7")), "large amount difference cannot merge");
        check(!CardText.sameRejectObservation("$7.75 0.7 mi", "$7.70 0.7 mi"), "numeric-only fragments cannot merge by tolerance");
        System.out.println(tests + " reject-confirm cache-only priority cases passed");
    }
}
