package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CardTextTest {
    static CardText.Piece p(String text, float x, float y) {
        return new CardText.Piece(text, x, y, y + 20);
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        List<CardText.Piece> screenshotSingle = new ArrayList<>(Arrays.asList(
                p("2.5 mi (~11 mins)", 92, 451), p("Est. $30–40", 371, 459),
                p("Tomorrow at 11:15 AM", 76, 542),
                p("Mendocino Farms • 2847 Park Ave, Tustin, CA 92782, United States", 76, 592),
                p("Ignore", 166, 727), p("Accept", 462, 727)));
        String screenshotTop = CardText.aboveButton(screenshotSingle, 700, 775);
        check(CardText.amount(screenshotTop) == 30f && CardText.miles(screenshotTop) == 2.5f,
                "single-card screenshot with distance on left and pay on right parses correctly");
        screenshotSingle.addAll(Arrays.asList(
                p("1.5 mi (~5 mins)", 92, 888), p("Est. $32–42", 380, 893),
                p("Tomorrow at 11:25 AM", 76, 979),
                p("Mendocino Farms • 840 S Sepulveda Blvd, El Segundo, CA 90245, United States", 76, 1030),
                p("Ignore", 166, 1210), p("Accept", 462, 1210)));
        check(CardText.aboveButton(screenshotSingle, 700, 775).equals(screenshotTop),
                "second screenshot card cannot contaminate first card or bind lower Accept");
        String mend = "$29–39 0.3 mi Today at 10:45 AM Mendocino Farms • 444 Flower St, Los Angeles, CA 90071, United States";
        String porto = "Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040, United States";
        check(CardText.containsConflictingPickupEvidence(mend + " " + porto), "different merchants with one numeric row must conflict");
        check(!CardText.containsConflictingPickupEvidence(mend + " " + mend), "identical parent/child copies remain valid");
        check(CardText.containsConflictingPickupEvidence(mend + " " + mend.replace("10:45 AM", "11:45 AM")), "different pickup times must conflict");
        check(CardText.containsConflictingPickupEvidence(mend + " " + mend.replace("444 Flower St", "555 Flower St")), "same merchant at two pickup addresses must conflict");
        check(!CardText.containsConflictingPickupEvidence(mend + " • 100 E Colorado Blvd, Pasadena, CA 91105"), "bare route destination is not a second pickup");
        check(!CardText.containsConflictingPickupEvidence(mend + " Delivery to Office • 100 E Colorado Blvd, Pasadena, CA 91105"), "labelled destination is not a second pickup");
        List<CardText.Piece> crossCard = Arrays.asList(p("$29–39 0.3 mi", 80, 850), p(mend, 80, 920), p(porto, 80, 1710));
        check(CardText.aboveButton(crossCard, 1964, 2021).isEmpty(), "field trace must not bind first numbers to lower merchant and CTA");
        List<CardText.Piece> screen = Arrays.asList(
                p("13 mi (~27 mins)", 10, 100), p("Est. $23–33", 300, 100),
                p("Tomorrow at 10:35 AM", 10, 150), p("Urbane Cafe Burbank", 10, 200),
                p("Expires: 09:42", 10, 300), p("Decline", 10, 400), p("Accept", 300, 400),
                p("1 mi (~6 mins)", 10, 500), p("Est. $21.45", 300, 500),
                p("Tomorrow at 10:35 AM Mendocino Farms Los Angeles", 10, 550),
                p("Decline", 10, 800), p("Accept", 300, 800));
        String first = CardText.aboveButton(screen, 400, 420);
        String second = CardText.aboveButton(screen, 800, 820);
        check(first.contains("$23–33") && first.contains("13 mi"), "first fields missing");
        check(!first.contains("21.45") && !first.contains("Mendocino"), "next card leaked into first");
        check(second.contains("$21.45") && second.contains("1 mi"), "second fields missing");
        check(!second.contains("Burbank") && !second.contains("$23"), "previous card leaked into second");
        List<CardText.Piece> incomplete = new ArrayList<>(screen);
        incomplete.removeIf(p -> p.text.contains("21.45"));
        check(CardText.aboveButton(incomplete, 800, 820).isEmpty(), "mixed fields from separate cards");
        List<CardText.Piece> noSecondNumbers = new ArrayList<>(screen);
        noSecondNumbers.removeIf(p -> p.text.contains("21.45") || p.text.contains("1 mi"));
        check(CardText.aboveButton(noSecondNumbers, 800, 820).isEmpty(), "previous card reused when current numbers absent");
        check(CardText.identity(first).equals(CardText.identity(first.replace("09:42", "09:41"))), "countdown invalidates identity");
        check(!CardText.identity(first).equals(CardText.identity(first.replace("10:35 AM", "11:35 AM"))), "pickup time change hidden");
        check(!CardText.identity(first).equals(CardText.identity(first.replace("Burbank", "Pasadena"))), "city change hidden");
        check(CardText.aboveButton(screen, 50, 70).isEmpty(), "missing fields accepted");
        check(!first.toLowerCase().contains("accept") && !first.toLowerCase().contains("decline"), "action row leaked into card text");
        check(CardText.identity(first + " Accept Decline").equals(CardText.identity(first + " Claim Ignore")), "action labels invalidate identity");
        check(CardText.identity(first).equals(CardText.identity(first + " " + first)), "duplicate tree text changes stable identity");
        String stableMerchantA = "Est. $74.33 1.7 mi Tomorrow at 3:30 PM Mendocino Farms • 11960 Ventura Blvd, Studio City, CA";
        String stableMerchantB = stableMerchantA + " Tomorrow at 3:30 PM Mendocino Farms • 11960 Ventura Blvd, Studio City, CA";
        check(CardText.identity(stableMerchantA).equals(CardText.identity(stableMerchantB)), "duplicated merchant/address changes identity");
        check(CardText.sameOffer(first, first + " Accept button Decline button"), "same offer rejected after action-node change");
        check(CardText.sameOffer(first, first + " " + first), "duplicated accessibility description rejected");
        check(!CardText.sameOffer(first, first.replace("Burbank", "Pasadena").replace("10:35", "11:35")), "different card accepted as same");
        check(!CardText.sameOffer(first, first.replace("$23", "$24")), "changed amount accepted as same offer");
        check(!CardText.sameOffer(first, first.replace("13 mi", "14 mi")), "changed miles accepted as same offer");
        String sparseLive = "Est. $23–33 13 mi Urbane Cafe";
        check(CardText.sameOfferForAction(first, sparseLive), "action revalidation rejected sparse same-card tree");
        check(!CardText.sameOfferForAction(first, sparseLive.replace("$23", "$24")), "action revalidation accepted changed amount");
        check(!CardText.sameOfferForAction(first, sparseLive.replace("13 mi", "14 mi")), "action revalidation accepted changed miles");

        List<CardText.Piece> duplicatedParent = Arrays.asList(
                p("Est. $30–40 14.1 mi September 11 at 10:35 AM Porto's Bakery 6100 S Malt Ave, Commerce, CA 90040, United States", 10, 100),
                p("September 11 at 10:35 AM", 10, 150),
                p("Porto's Bakery", 10, 180),
                p("6100 S Malt Ave, Commerce, CA 90040, United States", 10, 210),
                p("Reject", 10, 300), p("Accept", 300, 300));
        String deduped = CardText.aboveButton(duplicatedParent, 300, 320);
        check(deduped.indexOf("Porto's Bakery") == deduped.lastIndexOf("Porto's Bakery"),
                "parent/child accessibility text duplicated merchant");
        check(deduped.indexOf("6100 S Malt Ave") == deduped.lastIndexOf("6100 S Malt Ave"),
                "parent/child accessibility text duplicated address");

        // v2.10.115 field regression: during a list transition RN exported one broad parent
        // containing two offers. The parent must not cross-pair the first card's amount with
        // the second card's mileage/city; card-local children remain authoritative.
        List<CardText.Piece> transitioningCards = Arrays.asList(
                new CardText.Piece("$49.34 $27–37 Est. 5.6 mi (~17 mins) 4.3 mi (~12 mins) "
                        + "Tomorrow at 11:30 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040 "
                        + "Tomorrow at 7:00 AM Erewhon Market • 4121 Santa Monica Blvd, Los Angeles, CA 90029",
                        0, 80, 680),
                p("$49.34", 300, 100), p("4.3 mi (~12 mins)", 10, 100),
                p("Tomorrow at 7:00 AM Erewhon Market • 4121 Santa Monica Blvd, Los Angeles, CA 90029",
                        10, 150),
                p("Reject", 10, 300), p("Accept", 300, 300),
                p("$27–37", 300, 420), p("5.6 mi (~17 mins)", 10, 420),
                p("Tomorrow at 11:30 AM Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040",
                        10, 470),
                p("Reject", 10, 650), p("Accept", 300, 650));
        String transitionFirst = CardText.aboveButton(transitioningCards, 300, 320);
        String transitionSecond = CardText.aboveButton(transitioningCards, 650, 670);
        check(transitionFirst.contains("$49.34") && transitionFirst.contains("4.3 mi")
                        && !transitionFirst.contains("5.6 mi") && !transitionFirst.contains("Commerce"),
                "broad two-card parent contaminated first card");
        check(transitionSecond.contains("$27–37") && transitionSecond.contains("5.6 mi")
                        && !transitionSecond.contains("4.3 mi") && !transitionSecond.contains("Los Angeles"),
                "broad two-card parent contaminated second card");
        check(CardText.containsMultipleMileageRows(transitioningCards.get(0).text),
                "multi-card parent was not recognized");

        // v2.10.122 field shape: two independent RN child sets temporarily occupied the same
        // card coordinates. No individual node was a broad parent, so the aggregate itself
        // must be rejected instead of logging/evaluating both cards as one.
        List<CardText.Piece> overlappingChildren = Arrays.asList(
                p("$20–30", 300, 100), p("4.2 mi (~9 mins)", 10, 100),
                p("Today at 10:40 AM Urbane Cafe • Santa Clarita, CA 91355", 10, 140),
                p("$19.13", 300, 100), p("7.5 mi (~14 mins)", 10, 100),
                p("Today at 10:25 AM Chicken Maison • Torrance, CA 90502", 10, 140),
                p("Reject", 10, 300), p("Accept", 300, 300));
        check(CardText.aboveButton(overlappingChildren, 300, 320).isEmpty(),
                "overlapping child sets were merged into an actionable card");
        check(CardText.containsConflictingOfferNumbers(
                        "$20–30 4.2 mi $19.13 7.5 mi"),
                "conflicting aggregate numbers were not recognized");
        check(!CardText.containsConflictingOfferNumbers(
                        "$20–30 4.2 mi $20–30 4.2 mi"),
                "harmless duplicate numeric exports were rejected");

        // v2.10.21 real-device regression: the same Mendocino Grand Ave card was read
        // once as OCR (distance first / "300S") and once as Accessibility (pay first /
        // "300 S"). Old identity lacked calendar-date pickup parsing, so the two sources
        // generated different reject budgets and both tapped the same physical card.
        String grandOcr = "4.3 mi (~12 mins) Est. $29-39 O September 11 at 10:45 AM "
                + "Mendocino Farms • 300S Grand Ave, Los Angeles, CA 90071, United States Expires: 09:59";
        String grandAx = "$29-39 Est. 4.3 mi (~12 mins) September 11 at 10:45 AM, "
                + "Mendocino Farms • 300 S Grand Ave, Los Angeles, CA 90071, United States Expires: 09:59";
        check(CardText.identity(grandOcr).equals(CardText.identity(grandAx)),
                "calendar-date OCR/accessibility variants split one physical offer identity");
        check(!CardText.identity(grandAx).equals(CardText.identity(grandAx.replace("10:45 AM", "11:05 AM"))),
                "calendar-date pickup-time change hidden");
        check(!CardText.identity(grandAx).equals(CardText.identity(grandAx.replace("Mendocino Farms", "Porto's Bakery"))),
                "calendar-date merchant change hidden");
        check(Math.abs(CardText.amount("$70.00 22.5 mi") - 70f) < 0.001f, "decision amount parse");
        check(Math.abs(CardText.amount("$40-$65 3.2 mi") - 40f) < 0.001f, "range low-end amount parse");
        check(Math.abs(CardText.miles("$40 22.5 mi") - 22.5f) < 0.001f, "decision miles parse");
        check(CardText.amount("no money") < 0f && CardText.miles("no miles") < 0f, "missing decision fields");
        String splitDecimalOcr = "Est. $20-30 0 8 mi (~11 mins) Today at 11:05 AM Urbane Cafe";
        String repairedSplitDecimal = CardText.normalizeOcrSplitDecimalMiles(splitDecimalOcr);
        check(repairedSplitDecimal.contains("0.8 mi"), "OCR numeric split decimal not repaired");
        check(Math.abs(CardText.miles(repairedSplitDecimal) - 0.8f) < 0.001f,
                "repaired OCR mileage did not parse as 0.8");
        String ambiguousLetterO = CardText.normalizeOcrSplitDecimalMiles(
                "Est. $15.11 O 4 mi (~11 mins) Tomorrow at 7:15 AM Sidecar");
        check(ambiguousLetterO.contains("O 4 mi"), "ambiguous O 4 mi was rewritten as 0.4");
        check(Math.abs(CardText.miles(ambiguousLetterO) - 4f) < 0.001f,
                "ambiguous O separator did not preserve 4 miles");
        check(Math.abs(CardText.miles(CardText.normalizeOcrSplitDecimalMiles(
                        "Est. $80 8 mi Tomorrow at 11:05 AM")) - 8f) < 0.001f,
                "plain 8 mi was incorrectly rewritten as decimal");
        check(CardText.normalizeOcrSplitDecimalMiles("Store GO 8 mi away").equals("Store GO 8 mi away"),
                "letter inside a word was incorrectly treated as split zero");
        String decimalAx = "Est. $20-30 0.7 mi Tomorrow at 10:35 AM Urbane Cafe 26921 Aliso Creek Rd, Aliso Viejo, CA 92656";
        String decimalOcrDrift = "Est. $20-30 7 mi Tomorrow at 10:35 AM Urbane Cafe 26921 Aliso Creek Rd, Aliso Viejo, CA 92656";
        check(CardText.sameOfferIgnoringMiles(decimalAx, decimalOcrDrift), "same-card decimal drift not reconciled");
        check(!CardText.sameOfferIgnoringMiles(decimalAx, decimalOcrDrift.replace("Urbane Cafe", "Kite Hill")),
                "different merchant accepted by decimal-drift matcher");
        check(!CardText.sameOfferIgnoringMiles(decimalAx, decimalOcrDrift.replace("10:35 AM", "11:35 AM")),
                "different pickup time accepted by decimal-drift matcher");
        check(!CardText.sameOfferIgnoringMiles(decimalAx, decimalOcrDrift.replace("$20-30", "$21-31")),
                "different amount accepted by decimal-drift matcher");
        // v2.10.31 real 4:47 regression: one accepted Urbane card produced several OCR
        // spellings before/after the claim. Offer variants must share the semantic fingerprint,
        // while the post-claim detail can still share a completion alias for stale-callback drop.
        String urbaneA = "Est. $20-30 O 7 mi (~12 mins) Tomorrow at 10:35 AM Urbane Cafe • "
                + "26921 Aliso Creek Rd suite 2c & 2d, Aliso Viejo, CA 92656, United States";
        String urbaneB = "Est. $20-5 7 mi (~12 mins) Tomorrow at 10:35 AM Urbane Cafe • "
                + "26921 Aliso Creek suite 2c & 2d, Aliso Viejo, CA 926!5 United States";
        String urbaneDetail = "$20–30 Est. 7 mi (~12 mins) Tomorrow at 10:35 AM UBC_dev214_194958 "
                + "Pickup Instructions: Approver Name: Julie Rivera NUID: K100435 GL String: 0806811874910";
        check(CardText.identity(urbaneA).equals(CardText.identity(urbaneB)),
                "4:47 OCR variants split one offer semantic fingerprint");
        check(CardText.completionKey(urbaneA).equals(CardText.completionKey(urbaneDetail)),
                "accepted offer/detail stale callback alias changed after success");

        // v2.10.66 field regression: one $87.94/8mi offer was OCR'd against moving map
        // labels and produced many different card hashes while its action row was unavailable.
        // Anchorless coalescing must ignore those map-label changes.
        String anchorlessA = "Calabasas Topanga State Park 8 mi (~19 mins) Dropoff 11:35 AM "
                + "GOP_DT_LSRQ302 Beverly Hills Glendale Tomorrow at 11:00 AM Est. $87.94";
        String anchorlessB = "ENCINO STUDIO CITY 405 8 mi (-19 mins) GOP_DT_LSRO302 "
                + "Dropoff 11:35 AM LOS FELIZ Est. $87.94 Tomorrow at 11:00 AM";
        check(CardText.anchorlessKey(anchorlessA).equals(CardText.anchorlessKey(anchorlessB)),
                "moving map labels split one anchorless offer retry transaction");
        check(!CardText.anchorlessKey(anchorlessA).equals(CardText.anchorlessKey(
                        anchorlessB.replace("11:00 AM", "11:15 AM"))),
                "different pickup time merged into anchorless offer transaction");

        // v2.10.34 Large Order tooltip/OCR order regression. The tooltip can cause ML Kit
        // to read Est.$ / Large Order between pickup time and merchant/address. These are UI
        // decorations, not a new physical offer, so all variants must keep one identity.
        String chickenAx = "$38.11 Est. 12.7 mi (~23 mins) Today at 10:15 AM, Chicken Maison • "
                + "3605 S Bristol St, Santa Ana, CA 92704, United States";
        String chickenOcrA = "Today 1 Offer 12.7 mi (~23 mins) Today at 10:15 AM Chicken Maison "
                + "Est. $38.11 O Large Order 3605 S Bristol St, Santa Ana, CA 92704, United States "
                + "This order is eligible to have multiple drivers assigned to complete the delivery X";
        String chickenOcrB = "Today 1 Offer 12.7 mi (~23 mins) Est. $38.11 Today at 10:15 AM "
                + "Chicken Maison 3605 S Bristol St, Santa Ana, CA 92704, United States Large Order "
                + "This order is eligible to have multiple drivers assigned to complete the delivery X";
        check(CardText.identity(chickenAx).equals(CardText.identity(chickenOcrA)),
                "Large Order tooltip OCR A split physical offer identity");
        check(CardText.identity(chickenAx).equals(CardText.identity(chickenOcrB)),
                "Large Order tooltip OCR B split physical offer identity");
        // v2.10.46 FastAccept fusion: Action index can lose one ancestry field while the
        // bounded quick tree still has the complete decision. Missing is allowed; conflict is not.
        String fastQuick = "$91.18 Est. 1 mi (~4 mins) Tomorrow at 11:05 AM Erewhon Market • "
                + "9300 Culver Blvd Suite 101, Culver City, CA 90232, United States";
        check(CardText.compatiblePartialActionEvidence(fastQuick, "$91.18 Erewhon Market Culver City"),
                "FastAccept rejected same-card indexed evidence missing miles");
        check(CardText.compatiblePartialActionEvidence(fastQuick, "1 mi Erewhon Market Culver City"),
                "FastAccept rejected same-card indexed evidence missing amount");
        check(CardText.compatiblePartialActionEvidence(fastQuick, "Erewhon Market Culver City 9300 Culver"),
                "FastAccept rejected descriptive same-card indexed evidence");
        check(!CardText.compatiblePartialActionEvidence(fastQuick, "$92.18 Erewhon Market Culver City"),
                "FastAccept accepted conflicting amount");
        check(!CardText.compatiblePartialActionEvidence(fastQuick, "2 mi Erewhon Market Culver City"),
                "FastAccept accepted conflicting miles");
        check(!CardText.compatiblePartialActionEvidence(fastQuick, "Accept"),
                "FastAccept fused bare action label without card evidence");
        check(!CardText.compatiblePartialActionEvidence(fastQuick, "$91.18 1 mi Mendocino Farms Irvine"),
                "FastAccept fused numerically-equal different descriptive card");

        // v2.10.49 complementary fusion: neither snapshot has to be complete by itself.
        String partialIndex = "$116.67 Mendocino Farms 11911 San Vicente Los Angeles";
        String partialQuick = "1.7 mi (~8 mins) Today at 11:05 AM Mendocino Farms San Vicente Los Angeles CA 90049";
        check(CardText.compatibleComplementaryEvidence(partialIndex, partialQuick),
                "complementary same-card evidence was rejected");
        check(!CardText.compatibleComplementaryEvidence(partialIndex.replace("$116.67", "$117.67"),
                        "$116.67 1.7 mi Mendocino Farms San Vicente Los Angeles"),
                "complementary fusion accepted conflicting amount");
        check(!CardText.compatibleComplementaryEvidence("$116.67 2.7 mi Mendocino Farms San Vicente Los Angeles",
                        "$116.67 1.7 mi Mendocino Farms San Vicente Los Angeles"),
                "complementary fusion accepted conflicting miles");
        check(!CardText.compatibleComplementaryEvidence("$116.67 Accept",
                        "1.7 mi Claim"),
                "complementary fusion accepted bare action fragments");
        check(!CardText.compatibleComplementaryEvidence("$116.67 Mendocino Farms Los Angeles",
                        "1.7 mi Porto's Bakery Commerce CA 90040"),
                "complementary fusion crossed merchants/cities");
        String tokenCard = "$85.10 Est. 1 mi Today at 7:50 AM burq_3744670 - d_01m2nnqx9vfms9v8hazby79";
        check(CardText.orderId(tokenCard).equals("d_01m2nnqx9vfms9v8hazby79"),
                "strong delivery order id not preferred");
        check(CardText.orderId("$87.94 8 mi GOP_DT_LSRQ302 Tomorrow at 11:00 AM")
                        .equals("gop_dt_lsrq302"), "merchant order id not extracted");
        check(CardText.orderId("$17.65 1.7 mi Waba Grill Riverside").isEmpty(),
                "ordinary card text misclassified as order id");
        check(CardText.unavailableKey(tokenCard).startsWith("order:d_01m2nnqx9vfms9v8hazby79"),
                "unavailable tombstone did not prefer immutable order id");
        check(CardText.unavailableKey("$17.65 Est. 1.7 mi Tomorrow at 11:25 AM Waba Grill")
                        .startsWith("semantic:pay="), "unavailable fallback key missing");
        String unavailableFull = "$20–30 Est. 0.9 mi September 22 at 11:15 AM, Urbane Cafe • "
                + "218 S Lake Ave, Pasadena, CA 91101, United States Expires: 09:44";
        String unavailableSparse = "0.9 mi (~4 mins) Est. $20-30 September 22 at 11:15 AM "
                + "UBC_dev214_195558";
        check(CardText.orderId(unavailableSparse).equals("ubc_dev214_195558"),
                "late UBC order id not extracted");
        check(CardText.unavailablePromotionAlias(unavailableFull).equals(
                        CardText.unavailablePromotionAlias(unavailableSparse)),
                "full unavailable card did not bridge to sparse internal-id frame");
        check(!CardText.unavailablePromotionAlias(unavailableFull).equals(
                        CardText.unavailablePromotionAlias(
                                unavailableSparse.replace("11:15 AM", "11:25 AM"))),
                "different scheduled time crossed unavailable promotion aliases");
        // v2.10.105: a terminal card can later expose only the two numbers. The compact alias
        // must survive loss of time/merchant/city, but must not merge a different pair.
        String terminalFull = "$122.14 Est. 6.3 mi (~24 mins) Tomorrow at 10:20 AM, CAVA • "
                + "6200 W Sunset Blvd, Los Angeles, CA 90028, United States Large Order";
        String terminalNumericOnly = "$122.14 Est. 6.3 mi (~24 mins)";
        check(CardText.unavailableNumericAlias(terminalFull).equals(
                        CardText.unavailableNumericAlias(terminalNumericOnly)),
                "numeric-only unavailable redisplay bypassed compact tombstone identity");
        check(!CardText.unavailableNumericAlias(terminalFull).equals(
                        CardText.unavailableNumericAlias("$122.14 Est. 6.4 mi")),
                "different mileage merged into compact unavailable identity");
        check(CardText.unavailableNumericAlias("no offer").isEmpty(),
                "non-offer text produced compact unavailable identity");
        System.out.println("66 card-isolation, identity, OCR decimal, and FastAccept fusion regression cases passed");
    }
}
