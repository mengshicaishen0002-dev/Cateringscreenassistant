package com.local.cateringscreenassistant;

public final class UniversalNumericFastPolicyTest {
    private static void expect(boolean value, boolean expected, String name) {
        if (value != expected) throw new AssertionError(name + " expected=" + expected + " got=" + value);
    }

    public static void main(String[] args) {
        // Real traces: General-qualified offers are eligible without waiting for city.
        // Pasadena is additive: it can accept extra short local offers, but cannot invalidate
        // an offer that already passes General.
        expect(UniversalNumericFastPolicy.qualifies(140.40f, 3f, 60f, 10f,
                true, 20f, 5f, false, false), true, "Brea 140/3");
        expect(UniversalNumericFastPolicy.qualifies(73.47f, 1.2f, 60f, 10f,
                true, 20f, 5f, false, false), true, "Irvine 73/1.2");

        // v2.10.65 real-rule semantics: $65/8 already passes General, so Pasadena location
        // cannot turn it into Reject merely because it misses the Pasadena-extra 5mi limit.
        expect(UniversalNumericFastPolicy.qualifies(65f, 8f, 60f, 10f,
                true, 20f, 5f, false, false), true, "General remains sufficient");
        // Real 2026-09-16 trace: $106.53/6.6 with General $70/15 must be fast-eligible.
        expect(UniversalNumericFastPolicy.qualifies(106.53f, 6.6f, 70f, 15f,
                true, 20f, 5f, false, false), true, "Urbane 106.53/6.6 General fast");
        // Low Pasadena-only offers still require location evidence.
        expect(UniversalNumericFastPolicy.qualifies(27f, 1f, 60f, 10f,
                true, 20f, 5f, false, false), false, "Pasadena-only amount");
        // Explicit city/time filters always require their evidence.
        expect(UniversalNumericFastPolicy.qualifies(140f, 3f, 60f, 10f,
                true, 20f, 5f, true, false), false, "city filter");
        expect(UniversalNumericFastPolicy.qualifies(140f, 3f, 60f, 10f,
                true, 20f, 5f, false, true), false, "time filter");
        // If Pasadena special is disabled, ordinary thresholds alone are sufficient.
        expect(UniversalNumericFastPolicy.qualifies(65f, 8f, 60f, 10f,
                false, 20f, 5f, false, false), true, "ordinary only");

        // v2.10.93 universal Reject: every enabled numeric branch must fail. Location, city
        // allow-lists and time filters cannot rescue a card that fails all numeric branches.
        expect(UniversalNumericFastPolicy.rejects(19f, 2.5f, 60f, 10f,
                true, 25f, 5f), true, "19/2.5 fails General and Pasadena");
        expect(UniversalNumericFastPolicy.rejects(30f, 12f, 60f, 10f,
                true, 25f, 5f), true, "mixed failure still universal Reject");
        expect(UniversalNumericFastPolicy.rejects(30f, 3f, 60f, 10f,
                true, 25f, 5f), false, "Pasadena could accept");
        expect(UniversalNumericFastPolicy.rejects(65f, 12f, 60f, 10f,
                true, 25f, 5f), true, "mileage fails both branches");
        expect(UniversalNumericFastPolicy.rejects(59f, 2f, 60f, 10f,
                false, 25f, 5f), true, "ordinary-only rejection");
        expect(UniversalNumericFastPolicy.rejects(60f, 10f, 60f, 10f,
                false, 25f, 5f), false, "ordinary boundary passes");
        expect(UniversalNumericFastPolicy.rejects(-1f, 2f, 60f, 10f,
                true, 25f, 5f), false, "invalid amount never authorizes action");
        System.out.println("15 universal numeric fast policy cases passed");
    }
}
