package com.local.cateringscreenassistant;

public final class OutcomeEventFenceTest {
    private static int tests;
    private static void check(boolean value, String name) {
        tests++;
        if (!value) throw new AssertionError(name);
    }

    public static void main(String[] args) {
        check(!OutcomeEventFence.accepts(7, 7, 1100, 1000, 1200, 5000), "same epoch stale");
        check(!OutcomeEventFence.accepts(6, 7, 1100, 1000, 1200, 5000), "older epoch stale");
        check(!OutcomeEventFence.accepts(8, 7, 999, 1000, 1200, 5000), "pre-action event");
        check(OutcomeEventFence.accepts(8, 7, 1000, 1000, 1200, 5000), "new bound event");
        check(!OutcomeEventFence.accepts(8, 7, 1000, 1000, 6001, 5000), "expired event");
        System.out.println(tests + " outcome event fence cases passed");
    }
}
