package com.local.cateringscreenassistant;
import java.util.Random;
public class HotpathEquivalenceTest {
 static int checks;
 static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 public static void main(String[] args){
  String[] merchants={"Mendocino Farms","Porto’s Bakery","Nobu","PDT Cafe","Est Market","USD Kitchen","A & B (West)"};
  String[] times={"", "Today at 9:50 AM ", "Tomorrow at 9:50 AM, PDT, ","November 2 at 9:50 AM, PST, "};
  for(String merchant:merchants)for(String time:times)for(int i=0;i<15;i++){
   String t="$174.23 5.5 mi (~9 mins) "+time+merchant+" • "+(24420+i)+" Alicia Pkwy Suite A, Mission Viejo, CA 92691, United States";
   check(OfferEnrichmentPolicy.endpointKey(t).equals(OfferEnrichmentPolicyLegacy171.endpointKey(t)),"precompiled pattern endpoint equivalence");
   check(OfferEnrichmentPolicy.sameTransaction(t,t+" Accept")==OfferEnrichmentPolicyLegacy171.sameTransaction(t,t+" Accept"),"transaction equivalence");
   check(OfferEnrichmentPolicy.sameTransaction(t,t.replace("92691","92692"))==OfferEnrichmentPolicyLegacy171.sameTransaction(t,t.replace("92691","92692")),"address conflict equivalence");
  }
  for(int seed=0;seed<16;seed++){
   Random random=new Random(seed);ClaimBudget now=new ClaimBudget();ClaimBudgetLegacy171 old=new ClaimBudgetLegacy171();
   for(int i=0;i<48;i++){
    int n=random.nextInt(16);String text="$"+(80+n)+".23 "+(1+n%5)+" mi (~9 mins) "+(random.nextBoolean()?"Tomorrow at 9:50 AM ":"")+"Cafe "+n+" • "+(24000+n)+" Alicia Pkwy, Mission Viejo, CA 92691";
    String id=CardText.identity(text);long at=1000+i*30;
    check(now.reserve(id,text,at)==old.reserve(id,text,at),"budget aliases preserve reserve result "+seed+":"+i);
    check(now.available(id,at)==old.available(id,at)&&now.exhausted(id,at)==old.exhausted(id,at),"numeric prefilter preserves budget/cooldown");
    if(i%7==0){now.cancelUndispatched(id);old.cancelUndispatched(id);}
   }
  }
  System.out.println(checks+" hot-path regex and budget differential cases passed");
 }
}
