package com.local.cateringscreenassistant;

public class ActionDispatchPolicyTest {
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        check(ActionDispatchPolicy.semanticObserveDelayMs() == 85L, "semantic observe delay changed");
        check(ActionDispatchPolicy.processingPollMs() == 60L, "processing poll changed");
        check(ActionDispatchPolicy.processingTreeRecheckMs() == 240L, "processing tree recheck window changed");
        check(ActionDispatchPolicy.processingMaxChecks() == 16, "processing window changed");
        check(ActionDispatchPolicy.firstGestureDurationMs(true) == 12L, "Accept first gesture duration changed");
        check(ActionDispatchPolicy.firstGestureDurationMs(false) == 55L, "Reject compatibility gesture changed");
        check(ActionDispatchPolicy.rejectSemanticSettleMs() == 160L, "Reject semantic settle window");
        check(ActionDispatchPolicy.rejectFallbackGestureDurationMs() == 90L, "Reject fallback gesture must be Samsung-safe");
        check(ActionDispatchPolicy.retryGestureDurationMs(2) == 12L, "second Accept retry duration");
        check(ActionDispatchPolicy.retryGestureDurationMs(3) == 12L, "third Accept retry duration");
        check(ActionDispatchPolicy.retryVariant(2) == 0, "second retry should use center");
        check(ActionDispatchPolicy.retryVariant(3) == 1, "third retry should use alternate interior point");
        check(ActionDispatchPolicy.firstProcessingRecheckMs()==50L,"first quiet window shortened only");
        check(ActionDispatchPolicy.useFastProcessingWindow(1)&&ActionDispatchPolicy.useFastProcessingWindow(3),"first three processing windows get bounded early checks");
        check(!ActionDispatchPolicy.useFastProcessingWindow(4)&&!ActionDispatchPolicy.useFastProcessingWindow(0),"continued processing backs off");
        check(ActionDispatchPolicy.processingRecheckDelayMs(40,true)==10,"first quiet recheck lands at50");
        check(ActionDispatchPolicy.processingRecheckDelayMs(195,false)==45,"continued processing lands at240");
        check(ActionDispatchPolicy.processingRecheckDelayMs(0,false)==60,"long quiet interval keeps normal cache poll");
        System.out.println("28 action-dispatch policy cases passed");
    }
}
