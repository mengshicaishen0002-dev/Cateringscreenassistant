package com.local.cateringscreenassistant;
public class ScanPolicyTest {
    static int count;
    static void check(boolean x) { count++; if (!x) throw new AssertionError("case " + count); }
    public static void main(String[] args) {
        check(ScanPolicy.needsOcr(10000, 9000, 0, 250, false));
        check(!ScanPolicy.needsOcr(10000, 9950, 0, 250, false));
        check(!ScanPolicy.needsOcr(10000, 9000, 9800, 250, false));
        check(ScanPolicy.needsOcr(10000, 9000, 9500, 250, false));
        check(!ScanPolicy.needsOcr(10000, 9000, 0, 250, true));
        check(ScanPolicy.clampOcrInterval(5) == 12);
        check(ScanPolicy.clampOcrInterval(3500) == 2000);
        check(ScanPolicy.ocrIntervalForFrame(20, true) == 12);
        check(ScanPolicy.ocrIntervalForFrame(12, false) == 20);
        check(ScanPolicy.ocrIntervalForFrame(12, true) == 12);
        check(ScanPolicy.ocrIntervalForFrame(75, true) == 12);
        check(ScanPolicy.needsOcr(10016, 10000, 0, ScanPolicy.ocrIntervalForFrame(12, true), false));
        check(!ScanPolicy.needsOcr(10016, 10000, 0, ScanPolicy.ocrIntervalForFrame(12, false), false));
        check(!ScanPolicy.needsOcr(10016, 10000, 0, ScanPolicy.ocrIntervalForFrame(12, true), true));
        check(ScanPolicy.fresh(11200, 10000));
        check(!ScanPolicy.fresh(11201, 10000));
        check(!ScanPolicy.fresh(10000, 11000));
        check(!ScanPolicy.fresh(900000, 10000));
        check(ScanPolicy.actionFresh(12200, 10000));
        check(!ScanPolicy.actionFresh(12201, 10000));
        check(ScanPolicy.actionAge(10785, 10000) == 785);
        check(ScanPolicy.actionAge(9000, 10000) == Long.MAX_VALUE);
        System.out.println(count + " scan timing regression cases passed");
    }
}
