package com.local.cateringscreenassistant;

public class PageGuardTest {
    public static void main(String[] args) {
        int cases = 0;
        for (int bits = 0; bits < 128; bits++) {
            boolean ignored = (bits & 1) != 0;
            boolean jobs = (bits & 2) != 0;
            boolean offers = (bits & 4) != 0;
            boolean restore = (bits & 8) != 0;
            boolean reject = (bits & 16) != 0;
            boolean accept = (bits & 32) != 0;
            boolean emptyOffers = (bits & 64) != 0;
            PageGuard.Page page = PageGuard.classify(
                    ignored, jobs, offers, restore, reject, accept, emptyOffers);
            cases++;
            if ((ignored || restore || jobs) && page == PageGuard.Page.OFFERS)
                throw new AssertionError("Non-offer page permitted: " + bits);
            if (!ignored && !restore && !jobs && (offers || reject || accept || emptyOffers)
                    && page != PageGuard.Page.OFFERS)
                throw new AssertionError("Offers evidence blocked: " + bits);
            if (bits == 0 && page != PageGuard.Page.UNKNOWN) throw new AssertionError();
        }
        if (PageGuard.emptyDeliveriesTab("Deliveries Jobs Offers You don’t have any jobs.")
                != PageGuard.Page.JOBS) throw new AssertionError("Empty Jobs without selected state");
        if (PageGuard.emptyDeliveriesTab("Deliveries Jobs Offers You don't have any ignored offers.")
                != PageGuard.Page.IGNORED) throw new AssertionError("Empty Ignored without selected state");
        if (PageGuard.emptyDeliveriesTab("Deliveries Jobs Offers You don't have any offers.")
                != PageGuard.Page.UNKNOWN) throw new AssertionError("Offers must not recover to itself");
        if (PageGuard.emptyDeliveriesTab("You don't have any jobs.")
                != PageGuard.Page.UNKNOWN) throw new AssertionError("Require Deliveries tab row");
        // Real 2026-11-23 screenshot: selected Jobs, empty jobs message, Offers tab visible.
        if (PageGuard.explicitEmptyOtherTabText("You don't have any jobs.")
                != PageGuard.Page.JOBS) throw new AssertionError("Jobs idle event hint");
        if (PageGuard.explicitEmptyOtherTabText("You don’t have any jobs.")
                != PageGuard.Page.JOBS) throw new AssertionError("Unicode apostrophe Jobs hint");
        if (PageGuard.explicitEmptyOtherTabText("You don't have any ignored offers.")
                != PageGuard.Page.IGNORED) throw new AssertionError("Ignored idle event hint");
        if (PageGuard.explicitEmptyOtherTabText("No offers available")
                != PageGuard.Page.UNKNOWN) throw new AssertionError("Never navigate away from Offers empty");
        if (PageGuard.explicitEmptyOtherTabText("Begin Delivery")
                != PageGuard.Page.UNKNOWN) throw new AssertionError("Never navigate from active Job");
        if(PageGuard.clickedDeliveriesTab("Jobs")!=PageGuard.Page.JOBS)
            throw new AssertionError("Populated Jobs click should wake recovery");
        if(PageGuard.clickedDeliveriesTab("Ignored")!=PageGuard.Page.IGNORED)
            throw new AssertionError("Ignored tab click should wake recovery");
        if(PageGuard.clickedDeliveriesTab("Jobs Offer $200")!=PageGuard.Page.UNKNOWN)
            throw new AssertionError("Card text must not authorize Jobs navigation");
        if(PageGuard.clickedDeliveriesTab("Offers")!=PageGuard.Page.UNKNOWN)
            throw new AssertionError("Offers selection cannot trigger return");
        System.out.println(cases + " page guard combinations passed");
    }
}
