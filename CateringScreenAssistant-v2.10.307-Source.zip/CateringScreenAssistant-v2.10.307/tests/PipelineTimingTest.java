package com.local.cateringscreenassistant;
public final class PipelineTimingTest {
 public static void main(String[] args) {
  PipelineTiming p=new PipelineTiming(1000);p.mark("preflight",1020);p.mark("selfIndex",1106);p.mark("reject",1143);
  String s=p.finish(1149);
  if(!s.equals("preflight=20ms,selfIndex=86ms,reject=37ms,admit=6ms,total=149ms"))throw new AssertionError(s);
  if(!p.finish(1149).equals(s))throw new AssertionError("snapshot mutates timing");
  p.completeScan(940,1155,true,true,"PATH_RETURNED");
  String scan=p.scanSummary(1200);
  if(!scan.contains("completed_scan_is_latest=false trigger=STRUCTURAL queue_ms=60 exit=PATH_RETURNED")
          || !scan.endsWith("tail=12ms,total=155ms") || !p.isSlowScan()) throw new AssertionError(scan);
  PipelineTiming waiting=new PipelineTiming(2000);
  waiting.completeScan(1999,2001,false,false,"EVENT_BURST_WAIT");
  scan=waiting.scanSummary(2000);
  if(!scan.contains("completed_scan_is_latest=true trigger=REGULAR queue_ms=1 exit=EVENT_BURST_WAIT")
          || !scan.endsWith("phases=tail=1ms,total=1ms") || waiting.isSlowScan()) throw new AssertionError(scan);
  System.out.println("4 pipeline stage accounting cases passed");
 }
}
