package com.local.cateringscreenassistant;

public final class VisualAcceptFadePolicyTest {
    private static int tests;

    private static void check(boolean value, String name) {
        tests++;
        if (!value) throw new AssertionError(name);
    }

    public static void main(String[] args) {
        check(VisualAcceptFadePolicy.isEarlyBlue(0xff2196f3), "saturated Accept blue");
        check(VisualAcceptFadePolicy.isEarlyBlue(0xffd3eafd), "early alpha-composited blue");
        check(!VisualAcceptFadePolicy.isEarlyBlue(0xffffffff), "white rejected");
        check(!VisualAcceptFadePolicy.isEarlyBlue(0xffdedede), "disabled neutral gray rejected");
        check(!VisualAcceptFadePolicy.isEarlyBlue(0xffffd080), "warm control rejected");
        check(VisualAcceptFadePolicy.isStrictRightCta(
                563, 900, 965, 1012, 1080, 1400), "observed right Accept geometry");
        check(!VisualAcceptFadePolicy.isStrictRightCta(
                760, 900, 900, 1012, 1080, 1400), "narrow icon rejected");
        check(!VisualAcceptFadePolicy.isStrictRightCta(
                80, 900, 482, 1012, 1080, 1400), "left Reject geometry rejected");
        check(!VisualAcceptFadePolicy.isStrictRightCta(
                563, 200, 965, 312, 1080, 1400), "upper tab geometry rejected");
        System.out.println(tests + " early Accept fade policy cases passed");
    }
}
