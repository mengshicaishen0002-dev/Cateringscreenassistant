package com.local.cateringscreenassistant;

public final class AcceptPreemptionPolicyTest {
    private static int total;
    private static void check(boolean result,String label) {
        total++;if(!result)throw new AssertionError(label);
    }
    public static void main(String[] args) {
        String old="$28.00 0.1 mi Tomorrow at 11:00 AM Mendocino Farms • 444 Flower St Los Angeles CA 90071";
        String eligible="$95.77 1.8 mi Tomorrow at 8:35 AM Mimi's Cafe • 10909 Foothill Blvd Rancho Cucamonga CA 91730";
        check(AcceptPreemptionPolicy.isDifferentCoherentTop(old,eligible),"qualified new top is different");
        check(!AcceptPreemptionPolicy.isDifferentCoherentTop(old,old),"same rejected top not preempted");
        check(AcceptPreemptionPolicy.distinctQualifiedNumericWake(old,"$95.77 1.8 mi"),
                "fresh numeric change wakes qualified top indexing before address export");
        check(!AcceptPreemptionPolicy.distinctQualifiedNumericWake(old,"$28 0.1 mi"),
                "unchanged reposted order does not flood Binder probes");
        check(!AcceptPreemptionPolicy.distinctQualifiedNumericWake(old,"Accept"),
                "missing numeric pair is not a new publication signal");
        check(!AcceptPreemptionPolicy.isDifferentCoherentTop(old,"$95.77 1.8 mi"),"event numeric-only cannot take over");
        check(AcceptPreemptionPolicy.isDifferentCoherentTop(old,"$95.77 1.8 mi",true),"indexed live Accept new numeric pair can preempt fast");
        check(!AcceptPreemptionPolicy.isDifferentCoherentTop(old,"$28.00 0.1 mi",true),"same indexed numeric pair never proves new offer");
        check(!AcceptPreemptionPolicy.isDifferentCoherentTop(old,""),"blank not a top");
        check(AcceptPreemptionPolicy.isDifferentCoherentTop(eligible,old),"different rejected top semantics independent of thresholds");
        String newSamePrice="$28.00 0.1 mi Tomorrow at 11:15 AM Mendocino Farms • 444 Flower St Los Angeles CA 90071";
        check(AcceptPreemptionPolicy.isDifferentCoherentTop(old,newSamePrice),"different pickup slot same price");
        String repost=old.replace("$28.00","$28").replace("0.1 mi","0.1 mi");
        check(!AcceptPreemptionPolicy.isDifferentCoherentTop(old,repost),"repost same transaction not fake new top");
        check(AcceptPreemptionPolicy.shouldProbeNow(true,150,100,151,148),"new qualified publication bypasses 36ms");
        check(!AcceptPreemptionPolicy.shouldProbeNow(true,150,150,151,148),"same event throttled");
        check(AcceptPreemptionPolicy.shouldProbeNow(true,150,150,185,148),"same event retries after 36ms");
        check(!AcceptPreemptionPolicy.shouldProbeNow(false,0,0,151,148),"ordinary unqualified events throttled");
        System.out.println(total+" accept-over-reject takeover policy cases passed");
    }
}
