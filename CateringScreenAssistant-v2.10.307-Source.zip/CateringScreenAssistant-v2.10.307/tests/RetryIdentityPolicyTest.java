package com.local.cateringscreenassistant;
public class RetryIdentityPolicyTest {
 static int checks;
 static final String SPARSE="$195.36 Est. 0.3 mi (~2 mins)";
 static final String FULL=SPARSE+" Tomorrow at 11:35 AM Mendocino Farms • 631 Wilshire Blvd, Santa Monica, CA 90401";
 static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
 static PageOutcomePolicy.Tracker fresh(){return new PageOutcomePolicy.Tracker(1000,SPARSE,null,false);}
 static void read(PageOutcomePolicy.Tracker t,long at,String context,String state,String hint){t.observe(new PageOutcomePolicy.Reading(1,1,at,at+10,true,false,hint,context,"OK",7,26,"",state),at+10);}
 static PageOutcomePolicy.Tracker ready(){PageOutcomePolicy.Tracker t=fresh();read(t,1100,FULL,"ENABLED","");read(t,1220,FULL,"ENABLED","");return t;}
 public static void main(String[] args){
  check(!OfferEnrichmentPolicy.sameTransaction(SPARSE,FULL),"global numeric-only matching stays strict");
  PageOutcomePolicy.Tracker t=fresh();read(t,1100,FULL,"ENABLED","");
  check(t.retryDecision(1110).isEmpty()&&t.retryNeedsConfirmation(1110),"one complete top proof requests fast confirmation without permission to retry");
  read(t,1220,FULL,"ENABLED","");check(t.retryDecision(1230).equals(FULL),"two full current proofs enrich active numeric transaction");
  check(t.retryMatches(FULL)&&!t.retryMatches(SPARSE),"rich alias ownership never broadens arbitrary numeric match");
  check(t.retryDecision(1481).isEmpty(),"dispatch evidence expires at250ms");
  check(t.retryMatches(FULL),"callback ownership survives proof age without authorizing a new click");
  t=ready();read(t,1340,FULL.replace("631","632"),"ENABLED","");check(t.blocked&&t.retryDecision(1350).isEmpty(),"enriched address conflict stops transaction proof");
  t=ready();read(t,1340,FULL,"ENABLED","offer unavailable");check(t.retryDecision(1350).isEmpty(),"first fresh negative immediately blocks retry before final loss");
  for(String state:new String[]{"DISABLED","OTHER_ROW","UNKNOWN"}){t=fresh();read(t,1100,FULL,state,"");read(t,1220,FULL,state,"");check(t.retryDecision(1230).isEmpty(),"non-enabled action cannot retry "+state);}
  t=fresh();read(t,1100,FULL,"DISABLED","");read(t,1220,FULL,"ENABLED","");check(t.retryDecision(1230).equals(FULL),"observed processing then enabled permits verified recovery");
  t=fresh();read(t,1100,FULL,"ENABLED","");read(t,1129,FULL,"ENABLED","");check(t.retryDecision(1139).isEmpty(),"two too-close reads never suffice");
  t=fresh();read(t,1100,FULL,"ENABLED","");read(t,1950,FULL,"ENABLED","");check(t.retryDecision(1960).isEmpty(),"long observation gap restarts proof");
  t=fresh();read(t,1100,FULL,"ENABLED","");read(t,1220,"","NOT_EXPORTED","");read(t,1340,FULL,"ENABLED","");check(t.retryDecision(1350).isEmpty(),"card disappearance breaks continuity");
  t=fresh();read(t,1100,FULL,"ENABLED","");t.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,false,false,"",null,"UI_CHANGED",7,26),1230);read(t,1340,FULL,"ENABLED","");check(t.retryDecision(1350).isEmpty(),"incomplete UI cannot bridge two proofs");
  t=fresh();read(t,1100,FULL,"ENABLED","");t.observe(new PageOutcomePolicy.Reading(1,2,1220,1230,true,false,"",FULL,"OK",7,26,"","ENABLED"),1230);check(t.retryDecision(1230).isEmpty(),"new epoch needs new proof pair");
  t=fresh();read(t,1100,FULL,"ENABLED","");t.observe(new PageOutcomePolicy.Reading(2,2,1220,1230,true,false,"",FULL,"OK",7,26,"","ENABLED"),1230);check(t.blocked,"foreign window never enriches");
  t=ready();read(t,1340,FULL.replace("11:35","11:45"),"ENABLED","");check(t.blocked,"pickup changes remain hard conflicts");
  t=fresh();read(t,1100,FULL,"ENABLED","");read(t,1220,FULL.replace("195.36","196.36"),"ENABLED","");check(t.blocked,"pay change blocks enrichment");
  t=ready();t.observe(new PageOutcomePolicy.Reading(1,1,1340,1350,true,true,"",FULL),1350);check(t.retryDecision(1350).isEmpty(),"success beats retry");
  ClaimBudget budget=new ClaimBudget();String owner=CardText.identity(SPARSE),alias=CardText.identity(FULL);
  check(budget.reserve(owner,SPARSE,1000)==1,"first sparse attempt reserved");
  check(budget.bindVerifiedAlias(owner,alias,1230),"verified identity binds same budget entry");
  check(budget.reserve(alias,FULL,1230)==2,"rich second attempt stays number2");
  check(budget.releaseUndispatchedRetry(alias,2,1240),"failed final proof releases only unsent retry");
  check(!budget.available(owner,1259)&&!budget.available(alias,1259),"unsent retry cooldown shared by both aliases");
  check(budget.bindVerifiedAlias(owner,alias,1259)&&!budget.available(alias,1259),"rebinding never resets cooldown");
  check(budget.reserve(alias,FULL,1500)==2&&budget.reserve(owner,SPARSE,1700)==3,"aliases share maximum3 attempts");
  check(budget.reserve(alias,FULL,1900)==0,"enrichment never reopens exhausted budget");
  budget=new ClaimBudget();check(!budget.bindVerifiedAlias(owner,alias,1000),"cannot bind absent transaction");
  budget.reserve(owner,1000);budget.reserve(alias,1001);check(!budget.bindVerifiedAlias(owner,alias,1100),"independent existing alias cannot be overwritten");
  t=new PageOutcomePolicy.Tracker(1000,FULL,null,false);read(t,1100,FULL,"ENABLED","");
  check(t.retryDecision(1110).equals(FULL),"complete original identity needs one current enabled same-card proof");
  t=fresh();read(t,1100,FULL,"ENABLED","");read(t,1130,FULL,"ENABLED","");
  check(t.retryDecision(1140).equals(FULL),"numeric-only original uses independent proofs separated by20ms");
  t=new PageOutcomePolicy.Tracker(1000,FULL,null,false);read(t,1100,FULL,"DISABLED","");
  check(t.retryDecision(1110).isEmpty(),"one disabled reading can never use complete-original shortcut");
  t=new PageOutcomePolicy.Tracker(1000,FULL,null,false);read(t,1100,FULL.replace("631","632"),"ENABLED","");
  check(t.blocked&&t.diagnostic().contains("field=ENDPOINT")&&t.diagnostic().contains("632"),"different-card diagnosis retains actual endpoint difference and blocks retries");
  t=new PageOutcomePolicy.Tracker(1000,FULL,null,false);read(t,1100,FULL.replace("195.36","196.36"),"ENABLED","");
  check(t.blocked&&t.diagnostic().contains("field=AMOUNT"),"amount mismatch stays a hard veto with a precise cause");
  String noTime="$64.12 2.4 mi Erewhon Market • 475 S Lake Ave, Pasadena, CA 91101";
  String complete="$64.12 2.4 mi Today at 4:40 PM Erewhon Market • 475 S Lake Ave, Pasadena, CA 91101";
  t=new PageOutcomePolicy.Tracker(1000,noTime,null,false);read(t,1100,complete,"ENABLED","");
  check(t.retryDecision(1110).equals(complete),"Erewhon trace: known address and numbers bind current pickup in one fresh enabled proof");
  t=new PageOutcomePolicy.Tracker(1000,noTime,null,false);read(t,1100,complete.replace("475 S","476 S"),"ENABLED","");
  check(t.blocked&&t.retryDecision(1110).isEmpty(),"missing pickup cannot excuse a different current address");
  System.out.println(checks+" sparse-first retry identity/budget/timing cases passed");
 }
}
