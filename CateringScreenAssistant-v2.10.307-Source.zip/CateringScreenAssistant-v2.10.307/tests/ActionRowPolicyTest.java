package com.local.cateringscreenassistant;

public class ActionRowPolicyTest {
    public static void main(String[] args) {
        check(ActionRowPolicy.structuralRejectIndex(0) == -1, "empty row");
        check(ActionRowPolicy.structuralRejectIndex(1) == 0, "single left control");
        check(ActionRowPolicy.structuralRejectIndex(2) == 0, "Ignore, Accept row");
        check(ActionRowPolicy.structuralRejectIndex(3) == 1,
                "Large Order info, Ignore, Accept row must choose middle Ignore");
        check(ActionRowPolicy.structuralRejectIndex(4) == 2,
                "nearest control left of Accept must win");
        check(ActionRowPolicy.pairedReject(248,1159,386,1227,689,1162,840,1219),"live same row");
        check(!ActionRowPolicy.pairedReject(248,1359,386,1427,689,1162,840,1219),"identical numeric pair on a lower card cannot inherit Reject");
        check(!ActionRowPolicy.pairedReject(248,1000,386,1068,689,1162,840,1219),"upper card cannot inherit Reject");
        check(!ActionRowPolicy.pairedReject(850,1159,990,1227,689,1162,840,1219),"right-side control is never Reject");
        check(!ActionRowPolicy.pairedReject(248,1218,386,1286,689,1162,840,1219),"one pixel overlap is not a shared row");
        check(!ActionRowPolicy.pairedReject(248,1159,248,1227,689,1162,840,1219),"empty geometry cannot match");
        System.out.println("ActionRowPolicyTest passed");
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
