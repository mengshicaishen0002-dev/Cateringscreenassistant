package com.local.cateringscreenassistant;
class VisualRetryPolicyTest {
 static int n;static void check(boolean b,String s){n++;if(!b)throw new AssertionError(s);}
 static String card="$88.40 0.4 mi (~4 mins) Today at 5:00 PM Mendocino Farms • 4531 Hollywood Blvd, Los Angeles, CA 90027";
 public static void main(String[] args){
 check(VisualRetryPolicy.due(180,120,0,true,false),"bounded pending probe due");
 check(!VisualRetryPolicy.due(179,120,0,true,false),"settle first");
 check(!VisualRetryPolicy.due(3001,240,0,true,false),"bounded lifetime");
 check(!VisualRetryPolicy.due(180,119,0,true,false),"rate limit");
 check(!VisualRetryPolicy.due(180,120,6,true,false),"OCR budget");
 check(!VisualRetryPolicy.due(180,120,0,false,false),"known semantic state owns flow");
 check(!VisualRetryPolicy.due(180,120,0,true,true),"no overlapping OCR");
 check(VisualRetryPolicy.fresh(1000,1400),"frame boundary");check(!VisualRetryPolicy.fresh(1000,1401),"stale");check(!VisualRetryPolicy.fresh(1000,999),"clock reversal");
 check(VisualRetryPolicy.label(" Accept "),"exact accept label");check(VisualRetryPolicy.label("Claim"),"claim label");check(!VisualRetryPolicy.label("Accepting"),"processing not label");check(!VisualRetryPolicy.label("Begin Delivery"),"not a delivery action");
 check(VisualRetryPolicy.card(card,card,card+" Accept"),"same complete frame");
 check(!VisualRetryPolicy.card(card,card.replace("5:00","6:00"),card),"different pickup");
 check(!VisualRetryPolicy.card(card,"$88.40 0.4 mi",card),"sparse card cannot authorize");
 for(String tail:new String[]{"This offer is no longer available.","Offer Unavailable","Your route conflicts with an existing order","Begin Delivery","Delivery Timeline Pickup Instructions"})check(!VisualRetryPolicy.card(card,card,card+" "+tail),"terminal/positive frame excluded "+tail);
 VisualRetryPolicy.Proof proof=new VisualRetryPolicy.Proof();
 check(!proof.observe(card,1000,563,1145,965,1259),"first frame never taps");
 check(proof.observe(card,1240,563,1145,965,1259),"two coherent frames");
 proof=new VisualRetryPolicy.Proof();proof.observe(card,1000,563,1145,965,1259);
 check(!proof.observe(card,1040,563,1145,965,1259),"too close");
 proof=new VisualRetryPolicy.Proof();proof.observe(card,1000,563,1145,965,1259);
 check(!proof.observe(card,2000,563,1145,965,1259),"old first frame");
 proof=new VisualRetryPolicy.Proof();proof.observe(card,1000,563,1145,965,1259);
 check(!proof.observe(card,1240,563,1245,965,1359),"moved row");
 proof=new VisualRetryPolicy.Proof();proof.observe(card,1000,563,1145,965,1259);
 check(!proof.observe(card.replace("88.40","89.40"),1240,563,1145,965,1259),"changed card");
 check(ActionDispatchPolicy.retryInFlight(1000,900),"an accepted retry awaiting callback blocks another dispatch");
 check(!ActionDispatchPolicy.retryInFlight(2100,900),"lost callback cannot hold transaction forever");
 check(!ActionDispatchPolicy.retryInFlight(1000,0),"no pending retry");
 System.out.println(n+" visual retry policy cases passed");
 }
}