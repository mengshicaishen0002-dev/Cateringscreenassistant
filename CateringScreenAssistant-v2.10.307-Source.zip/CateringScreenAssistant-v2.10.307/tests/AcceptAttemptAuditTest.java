package com.local.cateringscreenassistant;
public class AcceptAttemptAuditTest {
    static int checks;static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        AcceptAttemptAudit a=new AcceptAttemptAudit();String offer="$92.80 3.7 mi";
        a.begin(1000,offer);check(a.summary(offer,null).isEmpty(),"reservation is not a sent gesture");
        a.dispatched(999,1100);check(a.summary(offer,null).isEmpty(),"stale owner cannot count dispatch");
        a.dispatched(1000,999);check(a.summary(offer,null).isEmpty(),"inverted time rejected");
        a.dispatched(1000,1100);a.dispatched(1000,1900);
        String summary=a.summary(offer,null);
        check(summary.contains("dispatchCount=2")&&summary.contains("FIRST_DISPATCH_ELAPSED=1100")
                &&summary.contains("LAST_DISPATCH_ELAPSED=1900"),"actual sends preserve first and latest anchors");
        check(a.summary("$93 3.7 mi",null).isEmpty(),"another offer cannot inherit ledger");
        PageOutcomePolicy.Tracker t=new PageOutcomePolicy.Tracker(1098,offer,null,false);
        t.observe(new PageOutcomePolicy.Reading(1,1,1200,1210,true,false,"",offer,"OK",7,20,
                "","DISABLED"),1210);
        check(a.summary(offer,t).contains("firstDisabled=112ms"),"matching tracker supplies diagnostic state");
        String diagnostic=t.diagnostic();
        a.observedControl(999,"ENABLED_RECOVERED",1300);
        a.observedControl(1000,"ENABLED",1099);
        check(a.summary(offer,t).contains("firstEnabled=UNOBSERVED"),"foreign/pre-dispatch control cannot fill current state");
        a.observedControl(1000,"ENABLED_RECOVERED",1800);
        check(a.summary(offer,t).contains("firstEnabled=702ms")
                && a.summary(offer,t).contains("firstEnabledSource=CONTROL"),"Long Beach regression: recovered control fills missing page enabled observation");
        a.observedControl(1000,"ENABLED",1900);
        check(a.summary(offer,t).contains("firstEnabled=702ms"),"later control cannot replace first seen");
        a.observedControl(1000,"DISABLED",1400);
        check(a.summary(offer,t).contains("firstDisabled=112ms")
                && a.summary(offer,t).contains("firstDisabledSource=READ"),"earliest read wins over later control");
        check(t.enabledAt<0 && diagnostic.equals(t.diagnostic()),"diagnostic merge never fabricates page/retry evidence");
        PageOutcomePolicy.Tracker foreign=new PageOutcomePolicy.Tracker(2000,offer,null,false);
        check(!a.summary(offer,foreign).contains("ACCEPT_NODE"),"later tracker cannot attach to old ledger");
        a.begin(3000,offer);check(a.summary(offer,t).isEmpty(),"rebroadcast starts a fresh empty ledger");
        a.dispatched(1000,3100);check(a.summary(offer,t).isEmpty(),"late old dispatch cannot enter new ledger");
        check(a.sendsFor(3000)==0&&a.sendsFor(1000)==0,"new transaction has zero actual sends regardless of old budget ordinal");
        a.dispatched(3000,3200);check(a.sendsFor(3000)==1,"new transaction actual sends begin at one");
        a.observedControl(1000,"ENABLED",3300);
        PageOutcomePolicy.Tracker fresh=new PageOutcomePolicy.Tracker(3200,offer,null,false);
        check(a.summary(offer,fresh).contains("firstEnabled=UNOBSERVED"),"new transaction never inherits old control");
        a.observedControl(3000,"DISABLED",3300);
        check(a.summary(offer,fresh).contains("firstDisabled=100ms")
                && a.summary(offer,fresh).contains("firstDisabledSource=CONTROL"),"control-only disabled is preserved");
        String thin="$30–40 1.9 mi Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101";
        String rich="$30–40 1.9 mi Tomorrow at 10:20 AM Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101";
        AcceptAttemptAudit aliases=new AcceptAttemptAudit();aliases.begin(4000,thin);aliases.dispatched(4000,4010);
        PageOutcomePolicy.Tracker aliasTracker=new PageOutcomePolicy.Tracker(4008,thin,null,false);
        check(!CardText.identity(thin).equals(CardText.identity(rich)),"Pasadena trace really has two text identities");
        check(aliases.summary(4000,rich,aliasTracker).contains("TX=4000")
                && aliases.summary(4000,rich,aliasTracker).contains("dispatchCount=1"),"explicit current TX preserves audit across pickup enrichment");
        check(aliases.summary(4001,rich,aliasTracker).isEmpty(),"another TX cannot borrow compatible text audit");
        check(aliases.summary(4000,rich.replace("238","239"),aliasTracker).isEmpty(),"same TX cannot hide address conflict");
        aliases.begin(5000,rich);aliases.dispatched(5000,5010);
        check(aliases.summary(4000,rich,aliasTracker).isEmpty(),"late reporter cannot attach a new rebroadcast ledger");
        check(aliases.summary(5000,rich.replace("10:20","10:25"),null).isEmpty(),"known pickup conflict never merges");
        System.out.println(checks+" Accept diagnostic ledger cases passed");
    }
}
