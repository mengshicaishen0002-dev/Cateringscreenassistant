package com.local.cateringscreenassistant;

public final class VisualGenerationReboundPolicyTest {
    private static int passed;
    private static void check(boolean ok, String name) {
        if (!ok) throw new AssertionError(name);
        passed++;
    }
    private static boolean accept(String before, String after, int xShift, int yShift, long age) {
        return VisualGenerationReboundPolicy.canRebind(before, after, 51.20f, 3.2f,
                563, 900, 965, 1012, 563 + xShift, 900 + yShift,
                965 + xShift, 1012 + yShift, age);
    }
    public static void main(String[] args) {
        String offer = "$51.20 Est. 3.2 mi Tomorrow at 11:05 AM, Mendocino Farms • 300 S Grand Ave";
        check(accept(offer, offer, 0, 0, 50), "same top card rebound");
        check(accept(offer, "$51.20 Est. 3.2 mi", 0, 1, 60), "same sparse numeric top");
        check(accept(offer, offer, 4, 5, 100), "subtle RN layout shift");
        check(!accept(offer, offer, 0, 0, 500), "old frame blocked");
        check(!accept(offer, "$52.20 Est. 3.2 mi", 0, 0, 90), "different pay blocked");
        check(!accept(offer, "$51.20 Est. 4.2 mi", 0, 0, 90), "different miles blocked");
        check(!accept(offer, "$51.20 Est. 3.2 mi Today at 11:05 AM, Mendocino Farms", 0, 0, 90),
                "same numbers different scheduled day blocked");
        check(!accept(offer, "$51.20 Est. 3.2 mi Tomorrow at 11:05 AM, Panera Bread", 0, 0, 90),
                "same numbers different merchant blocked");
        check(!accept(offer, offer, 0, -340, 90), "different action row blocked");
        check(!accept(offer, offer, -450, 0, 90), "left Reject rejected");
        check(!accept(offer, offer, 0, 0, -1), "clock inversion blocked");
        check(!VisualGenerationReboundPolicy.canRebind(offer, offer, 51.20f, 3.2f,
                563, 900, 965, 1012, 563, 900, 570, 905, 100), "small tab-shaped action blocked");
        System.out.println(passed + " visual generation rebound policy cases passed");
    }
}
