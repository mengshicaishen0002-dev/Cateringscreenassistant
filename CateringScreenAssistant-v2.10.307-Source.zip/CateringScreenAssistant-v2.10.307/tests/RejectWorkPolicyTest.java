package com.local.cateringscreenassistant;

public final class RejectWorkPolicyTest {
    private static int checks;
    private static void check(boolean value) {
        checks++;
        if (!value) throw new AssertionError("check " + checks);
    }
    public static void main(String[] args) {
        check(RejectWorkPolicy.mayReusePixels(true, 0L));
        check(RejectWorkPolicy.mayReusePixels(true, 1199L));
        check(!RejectWorkPolicy.mayReusePixels(true, 1200L));
        check(!RejectWorkPolicy.mayReusePixels(true, -1L));
        check(!RejectWorkPolicy.mayReusePixels(false, 10L));
        // A new event or Accept that arrives after queueing must take priority too.
        check(!RejectWorkPolicy.yieldRescue(false, false, false));
        check(RejectWorkPolicy.yieldRescue(true, false, false));
        check(RejectWorkPolicy.yieldRescue(false, true, false));
        check(RejectWorkPolicy.yieldRescue(false, false, true));
        check(RejectWorkPolicy.yieldRescue(true, true, true));
        String old = "$28.00 2.1 mi Tomorrow at 2:40 PM Mendocino Farms • 9300 Culver Blvd, Culver City, CA 90232";
        check(RejectWorkPolicy.sameOwnedOffer(old, old));
        check(RejectWorkPolicy.sameOwnedOffer(old.replace("Tomorrow at 2:40 PM ",""),old));
        check(!RejectWorkPolicy.sameOwnedOffer(old,old.replace("9300","9301")));
        check(!RejectWorkPolicy.sameOwnedOffer(old, old.replace("2:40", "3:40")));
        check(!RejectWorkPolicy.sameOwnedOffer(old, old.replace("Mendocino Farms", "Luna Grill")));
        check(!RejectWorkPolicy.sameOwnedOffer(old, "$28.00 2.1 mi"));
        check(!RejectWorkPolicy.sameOwnedOffer(old, old.replace("$28.00", "$29.00")));
        check(!RejectWorkPolicy.sameOwnedOffer(old, old + " Begin Delivery"));
        check(!RejectWorkPolicy.sameOwnedOffer(old, null));
        check(RejectWorkPolicy.sameOwnedOffer(old, old + " " + old));
        check(!RejectWorkPolicy.sameOwnedOffer(old, old + " $29.00 2.1 mi"));
        check(!RejectWorkPolicy.sameOwnedOffer(old, old + " $28.00 3.1 mi"));
        check(!RejectWorkPolicy.sameOwnedOffer(old, old + " " + old.replace("2:40", "3:40")));
        check(!RejectWorkPolicy.sameOwnedOffer(old, old + " " + old.replace("9300", "9301")));
        System.out.println(checks + " Reject work-priority and pixel-reuse cases passed");
    }
}
