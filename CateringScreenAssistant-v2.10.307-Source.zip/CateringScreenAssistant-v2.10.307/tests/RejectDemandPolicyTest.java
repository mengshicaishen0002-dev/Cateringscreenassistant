package com.local.cateringscreenassistant;

public final class RejectDemandPolicyTest {
    private static int checks;
    private static void check(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    public static void main(String[] args) {
        String old="$29.00 2.6 mi Tomorrow at 10:15 AM Mendocino Farms • 631 Wilshire Blvd, Santa Monica, CA 90401";
        check(!RejectDemandPolicy.coherent("Accept"),"button-only refresh has no new-offer proof");
        check(!RejectDemandPolicy.coherent(""),"blank refresh");
        check(RejectDemandPolicy.coherent(old),"coherent original");
        check(RejectDemandPolicy.sameOrUnprovenOwned(old,old),"old coherent redraw");
        check(RejectDemandPolicy.sameOrUnprovenOwned(old,"$29.00 2.6 mi"),"sparse matching pair cannot monopolize priority");
        check(!RejectDemandPolicy.sameOrUnprovenOwned(old,old.replace("29.00","125.23")),"different pay");
        check(!RejectDemandPolicy.sameOrUnprovenOwned(old,old.replace("2.6 mi","4.3 mi")),"different distance");
        check(!RejectDemandPolicy.sameOrUnprovenOwned(old,old.replace("10:15","11:15")),"different scheduled time");
        check(!RejectDemandPolicy.sameOrUnprovenOwned(old,old.replace("631","632")),"different street");
        check(!RejectDemandPolicy.sameOrUnprovenOwned(old,old.replace("Mendocino Farms","Luna Grill")),"different merchant");
        check(!RejectDemandPolicy.coherent(old+" Begin Delivery"),"accepted job is not new offer");
        check(!RejectDemandPolicy.coherent(old+" $100 8 mi"),"conflicting multiple offers");
        check("NONE".equals(RejectDemandPolicy.deferReason(false,false)),"dirty same-card queue alone never yields");
        check("ACCEPT_PRIORITY".equals(RejectDemandPolicy.deferReason(true,false)),"Accept always has priority");
        check("NEW_OFFER_PRIORITY".equals(RejectDemandPolicy.deferReason(false,true)),"proven new demand yields");
        System.out.println(checks+" same-card demand and Reject priority cases passed");
    }
}
