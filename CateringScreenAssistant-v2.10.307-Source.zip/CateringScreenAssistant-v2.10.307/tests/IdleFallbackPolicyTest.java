package com.local.cateringscreenassistant;

public final class IdleFallbackPolicyTest {
    private static int assertions;
    private static void check(boolean pass, String description) {
        assertions++;
        if (!pass) throw new AssertionError(description);
    }
    public static void main(String[] args) {
        check(IdleFallbackPolicy.quickBudget(80L,true)==40L,"idle quick cap");
        check(IdleFallbackPolicy.fullBudget(60L,true)==28L,"idle full cap");
        check(IdleFallbackPolicy.quickBudget(80L,false)==80L,"new-card quick budget unchanged");
        check(IdleFallbackPolicy.fullBudget(60L,false)==60L,"new-card full budget unchanged");
        check(IdleFallbackPolicy.coalesceFailedFull(1030L,1000L,17L,17L,true),"idle immediate repeat coalesced");
        check(!IdleFallbackPolicy.coalesceFailedFull(1048L,1000L,17L,17L,true),"48ms boundary retries");
        check(!IdleFallbackPolicy.coalesceFailedFull(1030L,1000L,18L,17L,true),"UI generation reopens fallback");
        check(!IdleFallbackPolicy.coalesceFailedFull(1030L,1000L,17L,17L,false),"new-offer bypasses coalescer");
        check(!IdleFallbackPolicy.coalesceFailedFull(1030L,0L,17L,17L,true),"first fallback always runs");
        check(!IdleFallbackPolicy.coalesceFailedFull(998L,1000L,17L,17L,true),"clock reset retries");
        System.out.println(assertions+" idle fallback continuity cases passed");
    }
}
