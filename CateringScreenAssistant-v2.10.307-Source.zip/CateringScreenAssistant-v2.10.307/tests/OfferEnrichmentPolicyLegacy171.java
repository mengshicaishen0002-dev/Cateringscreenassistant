package com.local.cateringscreenassistant;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A suppression/ownership bridge only; never supplies numbers, geometry or permission to tap. */
final class OfferEnrichmentPolicyLegacy171 {
    private static final Pattern PICKUP = Pattern.compile(
            "\\b(?:(?:today|tomorrow)|(?:january|february|march|april|may|june|july|august|september|october|november|december)\\s+\\d{1,2})\\s*(?:at)?\\s*\\d{1,2}:\\d{2}\\s*(?:am|pm)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern ADDRESS = Pattern.compile(
            "\\b\\d{1,6}\\s+[^•\\n]+?\\b(?:ca|california)\\s+\\d{5}(?:-\\d{4})?\\b",
            Pattern.CASE_INSENSITIVE);

    static String pickupKey(String text) {
        String completion = CardText.completionKey(text);
        int offset = completion.indexOf("|time=");
        return offset < 0 ? "" : completion.substring(offset + 6);
    }

    static String endpointKey(String text) {
        if (text == null) return "";
        String raw = CardText.withoutPickupZone(text).toLowerCase(Locale.US).replace('’', '\'');
        Matcher address = ADDRESS.matcher(raw);
        if (!address.find()) return "";
        int bullet = raw.lastIndexOf('•', address.start());
        if (bullet < 0) return "";
        String prefix = raw.substring(0, bullet);
        int travelEnd = prefix.lastIndexOf(')');
        if (travelEnd >= 0) prefix = prefix.substring(travelEnd + 1);
        String merchant = PICKUP.matcher(prefix).replaceAll(" ")
                .replaceAll("\\([^)]*\\)", " ")
                .replaceAll("(?:\\$|usd\\s*)\\d+(?:[.,]\\d+)?", " ")
                .replaceAll("\\d+(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b", " ")
                .replaceAll("\\b(?:est|large order|accept|claim)\\b", " ");
        merchant = normalize(merchant);
        return merchant.isEmpty() ? "" : merchant + "|" + normalize(address.group());
    }

    private static String normalize(String value) {
        return value.replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+", " ");
    }

    static boolean sameTransaction(String left, String right) {
        if (left == null || right == null || left.isEmpty() || right.isEmpty()
                || CardText.containsConflictingOfferNumbers(left)
                || CardText.containsConflictingOfferNumbers(right)) return false;
        if (CardText.amount(left) < 0 || CardText.miles(left) < 0
                || Math.round(CardText.amount(left) * 100f) != Math.round(CardText.amount(right) * 100f)
                || Math.abs(CardText.miles(left) - CardText.miles(right)) > 0.0001f) return false;
        String orderLeft = CardText.orderId(left), orderRight = CardText.orderId(right);
        if (!orderLeft.isEmpty() && !orderRight.isEmpty() && !orderLeft.equals(orderRight)) return false;
        String timeLeft = pickupKey(left), timeRight = pickupKey(right);
        if (!timeLeft.isEmpty() && !timeRight.isEmpty() && !timeLeft.equals(timeRight)) return false;
        String leftEndpoint = endpointKey(left), rightEndpoint = endpointKey(right);
        if (!leftEndpoint.isEmpty() && !rightEndpoint.isEmpty()
                && !leftEndpoint.equals(rightEndpoint)) return false;
        if (CardText.identity(left).equals(CardText.identity(right))) return true;
        // Only missing-field enrichment is eligible, not two independently complete offers.
        if (!timeLeft.isEmpty() && !timeRight.isEmpty()) return false;
        String endpoint = endpointKey(left);
        return !endpoint.isEmpty() && endpoint.equals(endpointKey(right));
    }

    /** Ownership/suppression only: a merchant-free detail cannot acquire a new attempt budget.
     * This deliberately does NOT authorize an action or relax sameTransaction's live proof. */
    static boolean sameBudgetOwner(String left, String right) {
        if (sameTransaction(left, right)) return true;
        if (left == null || right == null || CardText.containsConflictingOfferNumbers(left)
                || CardText.containsConflictingOfferNumbers(right)
                || CardText.amount(left) < 0 || CardText.miles(left) < 0
                || Math.round(CardText.amount(left)*100f) != Math.round(CardText.amount(right)*100f)
                || Math.abs(CardText.miles(left)-CardText.miles(right)) > 0.0001f) return false;
        String a=CardText.orderId(left), b=CardText.orderId(right);
        if (!a.isEmpty() && !b.isEmpty() && !a.equals(b)) return false;
        a=pickupKey(left); b=pickupKey(right);
        if (!a.isEmpty() && !b.isEmpty() && !a.equals(b)) return false;
        a=endpointKey(left); b=endpointKey(right);
        if (!a.isEmpty() && !b.isEmpty()) return false; // both merchants known: strict matcher owns it
        String address=budgetAddressKey(left);
        return !address.isEmpty() && address.equals(budgetAddressKey(right));
    }

    private static String budgetAddressKey(String text) {
        // Bound address parsing after the travel label / merchant bullet. Never let a price,
        // mileage or pickup-time number become the street number on a partial detail page.
        int start=text.lastIndexOf('•');
        if (start<0) start=text.lastIndexOf(')');
        if (start<0) return "";
        Matcher address=ADDRESS.matcher(text.substring(start+1));
        if (!address.find()) return "";
        String key=normalize(address.group());
        if (address.find()) return ""; // multiple routes are ambiguous
        return key;
    }

    private OfferEnrichmentPolicyLegacy171() { }
}
