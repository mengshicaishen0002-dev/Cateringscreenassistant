package com.local.cateringscreenassistant;
public class UiMutationPolicyTest {
 static int checks;
 static void check(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
 static boolean benign(int type,int changes,int window,String old,String now){return !UiMutationPolicy.benignReason(type,changes,window,old,now).isEmpty();}
 public static void main(String[] args){
  for(int type:new int[]{8,128,256,32768,65536}) check(benign(type,0,3,"",""),"focus hover");
  for(int type:new int[]{1,2,4,32,64,512,1024,2048,4096,8192,16384,131072,262144,4194304})
   check(!benign(type,0,3,"Expires in 12s","Expires in 11s"),"mutating event "+type);
  check(benign(16,0,3,"Expires in 12s","Expires in 11s"),"seconds");
  check(benign(16,0,3,"Expires 01:00","Expires 00:59"),"minute rollover");
  for(int flags:new int[]{1,2,4,8,16,32,64,128})check(!benign(16,flags,3,"Expires 00:12","Expires 00:11"),"combined flags");
  for(String text:new String[]{"","Accept","Begin Delivery","This offer is no longer available.","$120 2 mi","Expires 00:11 $120 2 mi","Expires 00:60","Expires 99:99","Expires 00:13","Expires 00:01"})
   check(!benign(16,0,3,"Expires 00:12",text),"reject mixed/state/reset/large jump "+text);
  check(!benign(16,0,-1,"Expires 00:12","Expires 00:11"),"unknown window");
  check(!benign(16,0,3,null,"Expires 00:11"),"missing old text");
  for(int i=1;i<600;i++){
   String before="Expires "+(i/60)+":"+String.format("%02d",i%60);
   String after="Expires "+((i-1)/60)+":"+String.format("%02d",(i-1)%60);
   check(benign(16,0,3,before,after),"countdown "+i);
   check(!benign(2048,2,3,before,after),"content changed remains fenced "+i);
   check(!benign(16,0,3,before,after+" Accept"),"mixed payload "+i);
  }
  System.out.println(checks+" UI mutation classification cases passed");
 }
}
