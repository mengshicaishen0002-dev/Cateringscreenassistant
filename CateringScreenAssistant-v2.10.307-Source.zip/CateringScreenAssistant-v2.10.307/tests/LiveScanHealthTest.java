package com.local.cateringscreenassistant;
public final class LiveScanHealthTest {
    private static void check(boolean b, String msg) { if (!b) throw new AssertionError(msg); }
    public static void main(String[] args) {
        LiveScanHealth health = new LiveScanHealth();
        health.enter(100,99,90,0);health.finish(8);
        health.enter(112,111,110,100);health.finish(5);
        health.enter(165,145,130,112);health.finish(60);
        String s=health.snapshotAndReset(200);
        check(s.contains("starts=3 ends=3"),"counts");
        check(s.contains("max_start_gap_ms=53 gaps_gt32=1 gaps_gt64=0"),"scan start gap");
        check(s.contains("max_queue_ms=20 queue_gt16=1"),"queue delay");
        check(s.contains("max_wake_to_start_ms=35 wake_gt16=1"),"wake delay");
        check(s.contains("max_scan_ms=60 scans_gt48=1 scans_gt96=0"),"slow scan detection");
        check(s.contains("last_start_age_ms=35"),"heartbeat age");
        String reset=health.snapshotAndReset(201);
        check(reset.contains("starts=0 ends=0") && reset.contains("max_scan_ms=0"),"interval reset");
        health.enter(265,264,263,165);health.finish(98);
        check(health.snapshotAndReset(265).contains("gaps_gt64=1"),"heartbeat stall");
        System.out.println("Live scan health counter cases passed");
    }
}
