package com.local.cateringscreenassistant;
public final class RejectReadProgressTest {
 public static void main(String[] args) {
  RejectReadProgress p=new RejectReadProgress(1000,45,true);
  if(!p.mayRead(1042)||p.mayRead(1043))throw new AssertionError("shared deadline margin");
  p.workerAt=1007;p.rootAt=1027;p.stage="TREE";p.visited=17;p.queries=2;
  String s=p.detail(1045);
  if(!s.contains("visitedAtReturn=17")||!s.contains("queueMs=7")||!s.contains("rootMs=20")||!s.contains("totalMs=45"))throw new AssertionError(s);
  p.cancelled=true;if(p.mayRead(1028))throw new AssertionError("abandoned caller stops future reads");
  System.out.println("3 Reject shared deadline/progress cases passed");
 }
}
