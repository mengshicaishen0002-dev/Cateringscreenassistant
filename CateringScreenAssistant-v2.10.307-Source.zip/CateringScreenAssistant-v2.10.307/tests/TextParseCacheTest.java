package com.local.cateringscreenassistant;
public final class TextParseCacheTest {
 private static int checks;private static void check(boolean ok){checks++;if(!ok)throw new AssertionError("cache case "+checks);}
 public static void main(String[] args)throws Exception {
  String offer="$179.13 0.4 mi Today at 2:50 PM Luna Grill • 10877 Foothill Blvd, Rancho Cucamonga, CA 91730";
  String identity=CardText.identity(offer),time=OfferEnrichmentPolicy.pickupKey(offer),endpoint=OfferEnrichmentPolicy.endpointKey(offer);
  for(int i=0;i<100;i++){check(CardText.amount(offer)==179.13f&&CardText.miles(offer)==.4f);check(CardText.identity(offer).equals(identity)&&OfferEnrichmentPolicy.pickupKey(offer).equals(time)&&OfferEnrichmentPolicy.endpointKey(offer).equals(endpoint));}
  String changed=offer.replace("2:50 PM","3:50 PM").replace("10877","10878");check(!OfferEnrichmentPolicy.pickupKey(changed).equals(time));check(!OfferEnrichmentPolicy.endpointKey(changed).equals(endpoint));
  for(int i=0;i<80;i++)CardText.identity(offer+" unique"+i);check(CardText.identity(offer).equals(identity));
  java.util.concurrent.atomic.AtomicReference<Throwable> failure=new java.util.concurrent.atomic.AtomicReference<>();Thread[] threads=new Thread[8];
  for(int i=0;i<8;i++){final int number=i;threads[i]=new Thread(()->{try{String text=offer.replace("10877",String.valueOf(10877+number));String wanted=OfferEnrichmentPolicy.endpointKey(text);for(int n=0;n<1000;n++)if(!wanted.equals(OfferEnrichmentPolicy.endpointKey(text)))throw new AssertionError("thread contamination");}catch(Throwable ex){failure.set(ex);}});threads[i].start();}
  for(Thread thread:threads)thread.join();check(failure.get()==null);System.out.println(checks+" immutable text parsing/eviction/concurrency cases passed");
 }
}
