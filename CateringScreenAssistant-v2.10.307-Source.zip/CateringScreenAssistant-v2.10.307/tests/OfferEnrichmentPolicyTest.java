package com.local.cateringscreenassistant;

public final class OfferEnrichmentPolicyTest {
    private static int checks;
    private static void check(boolean value, String why) {
        checks++;
        if (!value) throw new AssertionError(why);
    }
    public static void main(String[] args) {
        String sparse = "$139.93 16 mi (~27 mins) Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040, United States";
        String rich = "$139.93 Est. 16 mi (~27 mins) Tomorrow at 3:05 PM, Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040, United States Large Order";
        check(!OfferEnrichmentPolicy.endpointKey(sparse).isEmpty(), "trace endpoint exists");
        check(OfferEnrichmentPolicy.sameTransaction(sparse, rich), "real trace missing-time enrichment");
        check(OfferEnrichmentPolicy.sameTransaction(rich, sparse), "reverse partial redraw");
        check(OfferEnrichmentPolicy.sameTransaction(rich, rich), "same complete frame");
        check(!OfferEnrichmentPolicy.sameTransaction(rich, rich.replace("3:05", "4:05")), "different pickup time");
        check(!OfferEnrichmentPolicy.sameTransaction(rich, rich.replace("Tomorrow", "Today")), "different pickup day");
        check(!OfferEnrichmentPolicy.sameTransaction(sparse, rich.replace("139.93", "139.94")), "different pay");
        check(!OfferEnrichmentPolicy.sameTransaction(sparse, rich.replace("16 mi", "16.5 mi")), "different distance");
        check(!OfferEnrichmentPolicy.sameTransaction(sparse, rich.replace("Porto's Bakery", "Luna Grill")), "different merchant");
        check(!OfferEnrichmentPolicy.sameTransaction(sparse, rich.replace("6100", "6200")), "different street address");
        check(!OfferEnrichmentPolicy.sameTransaction(sparse, rich.replace("90040", "90041")), "different ZIP");
        check(!OfferEnrichmentPolicy.sameTransaction("$139.93 16 mi", rich), "numeric-only cannot bind rich frame");
        check(!OfferEnrichmentPolicy.sameTransaction(sparse + " burq_3744670", rich + " burq_3744671"), "conflicting immutable ids");
        check(!OfferEnrichmentPolicy.sameTransaction(sparse, rich + " $80 2 mi"), "conflicting multiple offers");
        check(!OfferEnrichmentPolicy.sameTransaction(rich, rich.replace("6100", "6200")), "full frames with different addresses");
        check(!OfferEnrichmentPolicy.sameTransaction(null, rich), "null frame");
        check(AcceptObservationPolicy.shouldObserveOnly(true, 100, 150, sparse, rich), "dispatched transaction owns enriched OCR");
        check(!AcceptObservationPolicy.shouldObserveOnly(true, 100, 0, sparse, rich), "undispatched reservation cannot claim observation");
        check(!AcceptObservationPolicy.shouldObserveOnly(false, 100, 150, sparse, rich), "inactive transaction cannot claim observation");
        check(UniversalNumericFastPolicy.qualifies(139.93f, 16f, 80f, 20f, true, 25f, 5f, false, false), "trace passes General despite special mileage");
        check(!UniversalNumericFastPolicy.qualifies(139.93f, 16f, 80f, 20f, true, 25f, 5f, true, false), "city filter keeps full verification");
        check(!UniversalNumericFastPolicy.qualifies(139.93f, 16f, 80f, 20f, true, 25f, 5f, false, true), "time filter keeps full verification");
        String nobu="$85.67 Est. 1.2 mi (~8 mins) Today at 8:00 PM, Nobu • 903 N La Cienega Blvd, Los Angeles, CA 90069, United States";
        for (String zone : new String[]{"PDT", "PST", "PT"}) {
            String zoned=nobu.replace("PM, Nobu", "PM , " + zone + ", Nobu");
            check(CardText.identity(nobu).equals(CardText.identity(zoned)), "zone caption keeps one budget identity " + zone);
            check(OfferEnrichmentPolicy.endpointKey(nobu).equals(OfferEnrichmentPolicy.endpointKey(zoned)), "zone is not merchant " + zone);
            check(OfferEnrichmentPolicy.sameTransaction(nobu,zoned), "same full transaction with zone " + zone);
            check(PageOutcomePolicy.compatible(zoned,nobu), "outcome probe remains bound " + zone);
            check(!PageOutcomePolicy.compatible(zoned,nobu.replace("903 N", "904 N")), "different address still fails " + zone);
            check(!OfferEnrichmentPolicy.sameTransaction(zoned,nobu.replace("8:00", "9:00")), "different pickup still fails " + zone);
        }
        check(!OfferEnrichmentPolicy.endpointKey(nobu.replace("Nobu", "PDT Cafe")).equals(
                OfferEnrichmentPolicy.endpointKey(nobu.replace("Nobu", "Cafe"))), "zone-like merchant word is preserved");
        PageOutcomePolicy.Tracker trace=new PageOutcomePolicy.Tracker(1000,nobu.replace("PM, Nobu","PM , PDT, Nobu"),null,false);
        trace.observe(new PageOutcomePolicy.Reading(1,1,1100,1110,true,false,"",nobu),1110);
        check(!trace.blocked && trace.status.equals("CLEAR_AFTER_DISPATCH"), "real Nobu trace no longer becomes DIFFERENT_CARD");
        trace.observe(new PageOutcomePolicy.Reading(1,1,1220,1230,true,false,"offer unavailable",nobu),1230);
        check(trace.observe(new PageOutcomePolicy.Reading(1,1,1350,1360,true,false,"offer unavailable",nobu),1360).equals("offer unavailable"), "real fresh loss binds after zone-normalized clear");
        System.out.println(checks + " General-first and enriched Accept ownership cases passed");
    }
}
