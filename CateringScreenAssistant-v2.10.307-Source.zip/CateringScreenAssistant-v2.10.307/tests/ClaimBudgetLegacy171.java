package com.local.cateringscreenassistant;

final class ClaimBudgetLegacy171 {
    private static final long RETRY_WINDOW_MS = 60_000L;
    private static final class Entry { int attempts; long lastAttemptAt; long retryNotBefore; String text=""; }
    private final java.util.LinkedHashMap<String,Entry> attempts = new java.util.LinkedHashMap<>();

    private Entry liveEntry(String id, long now, boolean create) {
        Entry e = attempts.get(id);
        if (e != null && now >= e.lastAttemptAt && now - e.lastAttemptAt >= RETRY_WINDOW_MS) {
            attempts.remove(id);
            e = null;
        }
        if (e == null && create) {
            if (attempts.size() >= 256) attempts.remove(attempts.keySet().iterator().next());
            e = new Entry();
            attempts.put(id, e);
        }
        return e;
    }

    /** Bind missing-field aliases to one budget; never bridges conflicting time/id/address. */
    synchronized int reserve(String id, String text, long now) {
        Entry existing = liveEntry(id, now, false);
        if (existing == null) {
            Entry matched = null;
            for (Entry candidate : attempts.values()) {
                if (now < candidate.lastAttemptAt || now-candidate.lastAttemptAt >= RETRY_WINDOW_MS
                        || candidate.text.isEmpty()) continue;
                if (OfferEnrichmentPolicy.sameBudgetOwner(candidate.text, text)) {
                    if (matched != null && matched != candidate) return 0; // ambiguous ownership
                    matched = candidate;
                }
            }
            if (matched != null) {
                if (attempts.size() >= 256) attempts.remove(attempts.keySet().iterator().next());
                attempts.put(id, matched);
                existing = matched;
            }
        }
        int attempt = reserve(id, now);
        Entry entry = attempts.get(id);
        if (entry != null && (entry.text.isEmpty()
                || (OfferEnrichmentPolicy.sameBudgetOwner(entry.text, text)
                    && (OfferEnrichmentPolicy.endpointKey(entry.text).isEmpty()
                        || !OfferEnrichmentPolicy.endpointKey(text).isEmpty())
                    && (text.length() > entry.text.length()
                        || (OfferEnrichmentPolicy.endpointKey(entry.text).isEmpty()
                            && !OfferEnrichmentPolicy.endpointKey(text).isEmpty()))))) entry.text = text;
        return attempt;
    }

    /** Called only after the active transaction has two fresh full-identity proofs.
     * Aliases share the exact Entry; no reserve, attempt reset or cooldown reset occurs. */
    synchronized boolean bindVerifiedAlias(String ownerId,String aliasId,long now) {
        Entry owner=liveEntry(ownerId,now,false), alias=liveEntry(aliasId,now,false);
        if(owner==null || owner.attempts<1 || (alias!=null && alias!=owner)) return false;
        if(alias==null && attempts.size()>=256) return false;
        attempts.put(aliasId,owner); return true;
    }

    /** Cancelling an unsent retry must not erase previously sent attempts (including aliases). */
    synchronized void cancelUndispatched(String id) {
        Entry entry = attempts.get(id);
        if (entry == null) return;
        if (entry.attempts > 1) entry.attempts--;
        else forget(id);
    }

    synchronized boolean exhausted(String id, long now) {
        Entry entry=liveEntry(id, now, false);
        return entry!=null && entry.attempts>=3;
    }

    synchronized boolean available(String id, long now) {
        Entry e = liveEntry(id, now, false);
        return e == null || (e.attempts < 3 && now >= e.retryNotBefore);
    }

    synchronized int reserve(String id, long now) {
        Entry e = liveEntry(id, now, true);
        if (e.attempts >= 3 || now < e.retryNotBefore) return 0;
        e.attempts++;
        e.lastAttemptAt = now;
        return e.attempts;
    }

    /**
     * Release only a retry reservation whose Android gesture was never dispatched.
     * Attempt #1 is deliberately excluded: callers use the full transaction-cancel path for a
     * first-shot dispatch failure. A failed pre-dispatch recheck must not erase attempt #1.
     */
    synchronized boolean releaseUndispatchedRetry(String id, int reservedAttempt) {
        Entry e = attempts.get(id);
        if (e == null || reservedAttempt <= 1 || e.attempts != reservedAttempt) return false;
        e.attempts--;
        return true;
    }

    /** Failed live proof gets a shared-alias cooldown; no first-shot or other-offer delay. */
    synchronized boolean releaseUndispatchedRetry(String id, int reservedAttempt, long now) {
        if (!releaseUndispatchedRetry(id, reservedAttempt)) return false;
        attempts.get(id).retryNotBefore = now + 200L;
        return true;
    }

    synchronized void forget(String id) {
        Entry entry = attempts.get(id);
        if (entry != null) attempts.entrySet().removeIf(item -> item.getValue() == entry);
    }

    // Pure-Java regression helpers.
    synchronized boolean available(String id) { return available(id, System.currentTimeMillis()); }
    synchronized int reserve(String id) { return reserve(id, System.currentTimeMillis()); }
}
