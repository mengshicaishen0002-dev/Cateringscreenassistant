package com.local.cateringscreenassistant;
public class ClaimSuccessSignalsTest {
    static int n;
    static void check(boolean v){n++; if(!v) throw new AssertionError("case "+n);}
    public static void main(String[] args){
        check(!ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("No scheduling conflicts with this job")));
        check(ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("Route conflict")));
        check(ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("Unable to accept: this route conflicts with your existing route")));
        check(ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("Your route overlaps another delivery")));
        check(!ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("No route conflicts")));
        check(!ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("Route instructions: turn left")));
        String conflict=ClaimSuccessSignals.extractOutcomeHint("Offer unavailable: This delivery conflicts with an existing job at 11:05 AM.");
        check(ClaimSuccessSignals.isTimeConflict(conflict));
        check(conflict.contains("11:05 AM"));
        check(ClaimSuccessSignals.isTerminalNegative(conflict));
        check(!ClaimSuccessSignals.isPositive(conflict));
        check(ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("You already accepted a job with overlapping delivery time")));
        check(ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("Scheduling conflict: unable to accept this order")));
        check(!ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("Offer unavailable")));
        check(!ClaimSuccessSignals.isTimeConflict(ClaimSuccessSignals.extractOutcomeHint("Tomorrow at 11:05 AM pickup instructions")));
        check(ClaimSuccessSignals.extractOutcomeHint("Network error").equals("error"));

        check(ClaimSuccessSignals.hasAcceptedJobDetail("Dropoff Instructions: call when arrive Delivery Timeline"));
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Pickup Instructions: Approver Name: Julie Rivera NUID: K100435 GL String: 0806811874910"));
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Pickup Instructions NUID: K100435 GL String: 0806811874910"));
        check(!ClaimSuccessSignals.hasAcceptedJobDetail("Pickup Instructions: ask restaurant for order"));
        check(!ClaimSuccessSignals.hasAcceptedJobDetail("Pickup Instructions Approver Name: Julie Rivera"));
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Begin Delivery Delivery Timeline MENDO_46474511540436997"));
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Begin to Delivery Delivery Timeline MENDO_46474511540436997"));
        check(ClaimSuccessSignals.hasBeginDeliveryControl("Begin Delivery"));
        check(ClaimSuccessSignals.hasBeginDeliveryControl("BEGIN   TO   DELIVERY"));
        check(ClaimSuccessSignals.isExactBeginDeliveryControl("Begin Delivery"));
        check(ClaimSuccessSignals.isExactBeginDeliveryControl("BEGIN TO DELIVERY"));
        check(!ClaimSuccessSignals.isExactBeginDeliveryControl("Tap Begin Delivery now"));
        check(!ClaimSuccessSignals.hasBeginDeliveryControl("Begin tomorrow's delivery route"));
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Delivery Timeline MENDO_46498930040553475"));
        check(!ClaimSuccessSignals.hasAcceptedJobDetail("Est. $61.31 7.6 mi MENDO_46498930040553475"));
        check(!ClaimSuccessSignals.hasAcceptedJobDetail("Begin Delivery tomorrow at 10:30 AM"));
        check(ClaimSuccessSignals.isPositive(ClaimSuccessSignals.extractOutcomeHint("Delivery Timeline Dropoff Instructions")));
        check(ClaimSuccessSignals.isPositive(ClaimSuccessSignals.extractOutcomeHint("Delivery Timeline MENDO_46498930040553475")));
        check(ClaimSuccessSignals.isPositive(ClaimSuccessSignals.extractOutcomeHint("Begin Delivery Delivery Timeline MENDO_46474511540436997")));
        String offer = "$30.32 Est. 5.8 mi Tomorrow at 11:10 AM Rubio's Coastal Grill • Norco, CA";
        String job = "$30.32 Est. 5.8 mi Tomorrow at 11:10 AM olo_46593764798644225 Delivery Timeline Pickup Rubio's Coastal Grill";
        check(ClaimSuccessSignals.acceptedJobMatchesOffer(offer, job));
        String screenshotJob = "$30.32 Est. 5.8 mi Tomorrow at 11:10 AM POR_g8ympk "
                + "Dropoff Instructions Begin Delivery Deliveries History Settings";
        check(ClaimSuccessSignals.acceptedJobMatchesOffer(offer, screenshotJob));
        check(!ClaimSuccessSignals.acceptedJobMatchesOffer("$31.00 Est. 5.8 mi Tomorrow at 11:10 AM Other", job));
        check(ClaimSuccessSignals.jobsBadgeCount("Deliveries Jobs 1 Offers") == 1);
        check(ClaimSuccessSignals.jobsBadgeCount("Deliveries Jobs Offers No offers available") == 0);
        check(ClaimSuccessSignals.jobsBadgeCount("Offers No offers available") == -1);
        check(ClaimSuccessSignals.jobsBadgeIncreased(0,1));
        check(ClaimSuccessSignals.jobsBadgeIncreased(1,2));
        check(ClaimSuccessSignals.jobsBadgeIncreased(2,3));
        check(!ClaimSuccessSignals.jobsBadgeIncreased(1,1));
        check(!ClaimSuccessSignals.jobsBadgeIncreased(2,1));
        check(!ClaimSuccessSignals.jobsBadgeIncreased(-1,1));
        System.out.println(n+" claim-success-signal cases passed");
    }
}
