package com.local.cateringscreenassistant;
import java.util.*;
public class OfferFlowTest {
    static int cases;
    static void check(boolean condition) { cases++; if (!condition) throw new AssertionError("case " + cases); }
    static class Offer {
        String id; boolean qualified, accept, reject;
        Offer(String id, boolean qualified, boolean accept, boolean reject) {
            this.id=id; this.qualified=qualified; this.accept=accept; this.reject=reject;
        }
    }
    static Offer choose(List<Offer> offers, ClaimBudget budget) {
        return OfferPriority.choose(offers, o->o.qualified, o->o.accept && budget.available(o.id), o->o.reject);
    }
    public static void main(String[] args) throws Exception {
        String sparse="$86.47 5.6 mi Mendocino Farms • 13790 Jamboree Rd Ste 4, Irvine, CA 92602";
        String rich="$86.47 Est. 5.6 mi Tomorrow at 11:00 AM Mendocino Farms • 13790 Jamboree Rd Ste 4, Irvine, CA 92602";
        ClaimBudget alias=new ClaimBudget();
        check(alias.reserve(CardText.identity(sparse), sparse,1000)==1);
        check(alias.reserve(CardText.identity(rich), rich,1100)==2);
        alias.cancelUndispatched(CardText.identity(rich));
        check(alias.reserve(CardText.identity(sparse), sparse,1200)==2);
        check(alias.reserve(CardText.identity(rich), rich,1300)==3);
        check(alias.reserve(CardText.identity(sparse), sparse,1400)==0);
        check(alias.reserve("other-time",rich.replace("11:00","12:00"),1500)==1);
        check(alias.reserve("other-store",rich.replace("13790","13791"),1500)==1);
        alias.forget(CardText.identity(sparse));
        check(alias.reserve(CardText.identity(rich),rich,1600)==1);
        ClaimBudget backoff=new ClaimBudget();
        check(backoff.reserve("s",sparse,1000)==1);
        check(backoff.reserve("r",rich,1100)==2);
        check(backoff.releaseUndispatchedRetry("r",2,1150));
        check(!backoff.available("s",1169));
        check(backoff.reserve("s",sparse,1169)==0);
        check(backoff.reserve("different",rich.replace("13790","13791"),1200)==1);
        check(backoff.reserve("s",sparse,1170)==2);
        check(!backoff.releaseUndispatchedRetry("s",1,1360));
        backoff.forget("r");
        check(backoff.reserve("s",sparse,1361)==1);
        String porto="$27–37 4.8 mi (~15 mins) Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040, United States";
        String detail="$27–37 4.8 mi (~15 mins) 6100 S Malt Ave, Commerce, CA 90040, United States";
        ClaimBudget manualDetail=new ClaimBudget();
        for(int i=1;i<=3;i++) check(manualDetail.reserve(CardText.identity(porto),porto,1000+i*100)==i);
        check(manualDetail.reserve(CardText.identity(detail),detail,9000)==0);
        check(manualDetail.exhausted(CardText.identity(detail),9000));
        check(manualDetail.exhausted(CardText.identity(porto),9000));
        check(!OfferEnrichmentPolicy.sameTransaction(porto,detail)); // suppression is not live click proof
        check(!OfferEnrichmentPolicy.sameBudgetOwner(porto,detail.replace("6100","6101")));
        check(!OfferEnrichmentPolicy.sameBudgetOwner(porto,detail.replace("4.8","4.9")));
        check(!OfferEnrichmentPolicy.sameBudgetOwner(porto,porto.replace("Porto's Bakery","Other Store")));
        check(!OfferEnrichmentPolicy.sameBudgetOwner(porto,"$27–37 4.8 mi (~15 mins)"));
        check(!OfferEnrichmentPolicy.sameBudgetOwner(porto+" Today at 11:00 AM",detail+" Today at 12:00 PM"));
        check(!OfferEnrichmentPolicy.sameBudgetOwner(porto+" burq_3744670",detail+" burq_3744671"));
        ClaimBudget inverse=new ClaimBudget();
        check(inverse.reserve("thin",detail,1000)==1);
        check(inverse.reserve("full",porto,2000)==2);
        check(inverse.reserve("full",porto,3000)==3);
        check(inverse.reserve("thin",detail,4000)==0);
        check(inverse.reserve("other",porto.replace("Porto's Bakery","Other Store"),5000)==1);
        check(inverse.reserve("ambiguous",detail,6000)==0);
        check(ActionDispatchPolicy.previousGestureFinished(1000,1000));
        check(!ActionDispatchPolicy.previousGestureFinished(0,1000));
        check(!ActionDispatchPolicy.previousGestureFinished(1000,0));
        check(!ActionDispatchPolicy.previousGestureFinished(999,1000));
        ClaimBudget renewed=new ClaimBudget();
        for(int i=1;i<=3;i++) check(renewed.reserve("luna",porto,1000+i*100)==i);
        check(renewed.reserve("luna",porto,1500)==0);
        renewed.forget("luna"); // proven departure + current enabled Accept owns normal rearm
        check(renewed.reserve("luna",porto,3000)==1);
        check(renewed.reserve("detail",detail,3100)==2);
        ClaimBudget budget = new ClaimBudget();
        Offer low=new Offer("low",false,true,true), high=new Offer("high",true,true,true);
        // v2.10.3: strict serial queue — always finish the first visible card before lower cards.
        check(choose(Arrays.asList(low,high),budget)==low);
        check(choose(Arrays.asList(high,low),budget)==high);
        check(choose(Arrays.asList(low),budget)==low);
        check(choose(Collections.emptyList(),budget)==null);
        check(budget.reserve("high")==1);
        check(budget.reserve("high")==2);
        check(budget.reserve("high")==3);
        check(budget.reserve("high")==0);
        // v2.10.87: a retry whose final live-card recheck fails never dispatched. Roll back
        // only that retry so the existing first attempt stays recorded and the next fresh
        // same-card proof can still send attempt #2.
        ClaimBudget retryRollback = new ClaimBudget();
        check(retryRollback.reserve("same-card", 1000)==1);
        check(retryRollback.reserve("same-card", 1100)==2);
        check(retryRollback.releaseUndispatchedRetry("same-card", 2));
        check(retryRollback.reserve("same-card", 1170)==2);
        check(!retryRollback.releaseUndispatchedRetry("same-card", 1));
        check(retryRollback.reserve("same-card", 1200)==3);
        check(!retryRollback.releaseUndispatchedRetry("same-card", 2));
        check(choose(Arrays.asList(high,low),budget)==null);
        Offer newOrder=new Offer("samePayDifferentMerchant",true,true,true);
        check(choose(Arrays.asList(high,newOrder),budget)==null);
        check(choose(Arrays.asList(high),budget)==null);
        check(choose(Arrays.asList(new Offer("partial",true,false,false),low),budget)==null);
        check(choose(Arrays.asList(newOrder),budget)==newOrder);
        String base="$80 3 mi Tomorrow at 11:00 AM Store A, Pasadena CA 91101 Expires: 09:42 Accept Decline";
        check(CardText.identity(base).equals(CardText.identity(base.replace("09:42","09:41"))));
        check(!CardText.identity(base).equals(CardText.identity(base.replace("Store A","Store B"))));
        check(!CardText.identity(base).equals(CardText.identity(base.replace("11:00","11:30"))));
        List<CardText.Piece> pieces=Arrays.asList(
            new CardText.Piece("Est. $23–33",400,100,120),new CardText.Piece("13 mi",20,100,120),
            new CardText.Piece("Tomorrow at 10:35 AM Urbane Cafe Burbank CA",20,130,170),
            new CardText.Piece("Decline Accept",20,200,230),
            new CardText.Piece("Est. $90",400,300,320),new CardText.Piece("2 mi",20,300,320),
            new CardText.Piece("Tomorrow at 11:35 AM Store B Pasadena CA",20,330,370),
            new CardText.Piece("Decline Accept",20,400,430));
        String upper=CardText.aboveButton(pieces,200,230),lower=CardText.aboveButton(pieces,400,430);
        check(upper.contains("$23") && !upper.contains("$90"));
        check(lower.contains("$90") && !lower.contains("Burbank"));
        ClaimBudget concurrent=new ClaimBudget();
        List<Thread> threads=new ArrayList<>(); java.util.concurrent.atomic.AtomicInteger reserved=new java.util.concurrent.atomic.AtomicInteger();
        for(int i=0;i<12;i++) {Thread t=new Thread(()->{if(concurrent.reserve("one")>0)reserved.incrementAndGet();});threads.add(t);t.start();}
        for(Thread t:threads)t.join();
        check(reserved.get()==3);
        // Expired attempt budget becomes usable again for a genuinely resurfaced offer.
        ClaimBudget resurfaced = new ClaimBudget();
        check(resurfaced.reserve("same", rich, 1000)==1);
        check(resurfaced.reserve("alias", sparse, 10999)==2);
        check(resurfaced.reserve("same", rich, 11000)==3);
        check(resurfaced.reserve("alias", sparse, 20999)==0);
        ClaimBudget expiring = new ClaimBudget();
        check(expiring.reserve("again", 1000)==1);
        check(expiring.reserve("again", 1100)==2);
        check(expiring.reserve("again", 1200)==3);
        check(!expiring.available("again", 1300));
        check(!expiring.available("again", 9500));
        check(!expiring.available("again", 11199));
        check(expiring.available("again", 11200));
        check(expiring.reserve("again", 11200)==1);
        System.out.println(cases+" multi-offer/claim-budget regression cases passed");
    }
}
