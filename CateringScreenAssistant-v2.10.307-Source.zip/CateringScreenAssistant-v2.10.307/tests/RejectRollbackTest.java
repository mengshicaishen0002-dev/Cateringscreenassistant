package com.local.cateringscreenassistant;
public final class RejectRollbackTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[]args){
  RejectSequence s=new RejectSequence();check(s.reserveFirstIfReady("A",1000)==1);
  s.markProcessing("A",1200);check(s.reserveFinalIfFresh("A",1400)==0);
  s.markEnabledAfterProcessing("A",1500);check(s.reserveFinalIfFresh("A",1500)==2);
  s.markEnabledAfterProcessing("A",1600);check(s.reserveFinalIfFresh("A",1600)==0);
  RejectSequence t=new RejectSequence();t.reserveFirstIfReady("A",1000);t.markTerminal("A",1100);
  t.markEnabledAfterProcessing("A",1200);check(t.observe("A",1200)==RejectSequence.State.TOMBSTONE);
  check(t.reserveFinalIfFresh("A",1200)==0);
  RejectSequence d=new RejectSequence();d.reserveFirstIfReady("A",1000);d.markDisappeared("A",1100);
  d.markEnabledAfterProcessing("A",1200);check(d.reserveFinalIfFresh("A",1200)==0);
  System.out.println("Reject processing rollback, exhausted and terminal protection passed");
 }
}
