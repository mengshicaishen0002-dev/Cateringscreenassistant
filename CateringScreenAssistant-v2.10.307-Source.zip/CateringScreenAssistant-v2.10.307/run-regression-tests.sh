#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${TMPDIR:-/tmp}/csa-v29-tests"
rm -rf "$OUT" && mkdir -p "$OUT"
if command -v javac >/dev/null 2>&1; then
  JAVAC=(javac)
else
  JAVAC=(java com.sun.tools.javac.Main)
fi
"${JAVAC[@]}" -d "$OUT" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/UiMutationPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AcceptAttemptAudit.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PageOutcomePolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/BoundedReadBatch.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionGeometry.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionRowPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AcceptObservationPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AccessibilityFallbackPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionDispatchPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionStallPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AlertDedupe.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ButtonLabels.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AnchorlessOfferGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimBudget.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimConfirmation.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimSuccessSignals.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/NumericGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OfferPriority.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PageGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PasadenaRuleGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/QuickEvidencePolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/QuickTreeBudgetPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/IdleFallbackPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSequence.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectConfirmation.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectConfirmPriorityPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AcceptPreemptionPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ScanPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/VisualRetryPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/FastSnapshotPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/LargeOrderPopupGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/HotOfferScanPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OutcomeEventFence.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectTerminalGate.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/UniversalNumericFastPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/VisualAcceptFadePolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/VisualGenerationReboundPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectWorkPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OfferEnrichmentPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectDemandPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AcceptSpinnerPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSpinnerPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectReadProgress.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PipelineTiming.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/LiveScanHealth.java" \
  "$ROOT/tests"/*.java
for cls in AcceptPreemptionPolicyTest RejectSpinnerPolicyTest LiveScanHealthTest IdleFallbackPolicyTest PipelineTimingTest RejectReadProgressTest ContinuousClaimTest RejectRollbackTest AcceptSpinnerPolicyTest TextParseCacheTest HotpathEquivalenceTest RetryIdentityPolicyTest VisualRetryPolicyTest AcceptAttemptAuditTest PageOutcomePolicyTest BoundedReadBatchTest RejectDemandPolicyTest OfferEnrichmentPolicyTest RejectWorkPolicyTest AcceptObservationPolicyTest AnchorlessOfferGuardTest LargeOrderPopupGuardTest HotOfferScanPolicyTest OutcomeEventFenceTest ActionRowPolicyTest AccessibilityFallbackPolicyTest FastSnapshotPolicyTest ActionDispatchPolicyTest ActionStallPolicyTest ActionGeometryTest AlertDedupeTest ButtonLabelsTest CardTextTest ClaimConfirmationTest ClaimSuccessSignalsTest NumericGuardTest OfferFlowTest PageGuardTest PasadenaRuleGuardTest QuickEvidencePolicyTest QuickTreeBudgetPolicyTest RejectSequenceTest RejectTerminalGateTest RejectConfirmationTest RejectConfirmPriorityPolicyTest ScanPolicyTest UniversalNumericFastPolicyTest VisualAcceptFadePolicyTest VisualGenerationReboundPolicyTest; do
  java -cp "$OUT" "com.local.cateringscreenassistant.$cls"
done

# v228: historical suppression/rebroadcast assertions are superseded by current-publication tests.
python3 "$ROOT/tools/check_reject_read.py"
python3 "$ROOT/tools/check_reject_demand.py"
python3 "$ROOT/tools/check_visual_dispatch.py"
python3 "$ROOT/tools/check_accept_handoff.py"
# v300 migrates the formerly skipped v295/v296 index assertions to the user-
# authorized speed-first behavior (same-owner RN churn keeps dispatching while
# foreign-app, terminal, paused and cross-owner fences stay active).
# Both the migrated legacy cases AND new first-shot event-bridge cases must pass.
python3 "$ROOT/tools/check_index_pipeline.py"
python3 "$ROOT/tools/check_speed_first_index.py"
python3 "$ROOT/tools/check_structural_wake_fastlane.py"
python3 "$ROOT/tools/check_accept_outcome_fence.py"
python3 "$ROOT/tools/check_retry_dispatch.py"
python3 "$ROOT/tools/check_claim_visual.py"
python3 "$ROOT/tools/check_page_recovery.py"
python3 "$ROOT/tools/check_jobs_auto_return.py"
python3 "$ROOT/tools/check_visual_pixels.py"
python3 "$ROOT/tools/check_processing_wait.py"
python3 "$ROOT/tools/check_visual_retry.py"
python3 "$ROOT/tools/check_visual_retry_frame.py"
python3 "$ROOT/tools/check_accept_commit.py"
python3 "$ROOT/tools/check_unavailable_retirement.py"
python3 "$ROOT/tools/check_post_terminal_lane.py"
python3 "$ROOT/tools/check_ocr_dispatch.py"
python3 "$ROOT/tools/check_ocr_admission.py"
python3 "$ROOT/tools/check_navigation_foreground.py"
python3 "$ROOT/tools/check_sparse_retry.py"
python3 "$ROOT/tools/check_outcome_parser_equivalence.py"
python3 "$ROOT/tools/check_ui_event_routing.py"
python3 "$ROOT/tools/check_pasadena_fastlane.py"
python3 "$ROOT/tools/check_accept_card_safety.py"
python3 "$ROOT/tools/check_fast_gesture.py"
python3 "$ROOT/tools/check_reject_stall.py"
python3 "$ROOT/tools/check_reject_rescue.py"
python3 "$ROOT/tools/check_inspection_queue.py"
python3 "$ROOT/tools/check_control_wake.py"
python3 "$ROOT/tools/check_enabled_proof_lane.py"
python3 "$ROOT/tools/check_accept_pressure.py"
python3 "$ROOT/tools/check_read_deadlines.py"
python3 "$ROOT/tools/check_reject_pixels.py"
python3 "$ROOT/tools/check_reject_ocr_coalescing.py"
python3 "$ROOT/tools/check_accept_ocr_coalescing.py"
python3 "$ROOT/tools/check_navigation_targets.py"
python3 "$ROOT/tools/check_current_publication.py"
python3 "$ROOT/tools/check_bounded_fallback.py"
python3 "$ROOT/tools/check_reject_readiness.py"
python3 "$ROOT/tools/check_owned_success.py"
python3 "$ROOT/tools/check_replay_lifecycle.py"
python3 "$ROOT/tools/check_terminal_banner.py"
python3 "$ROOT/tools/check_result_alerts.py"
python3 "$ROOT/tools/check_transaction_reporting.py"
python3 "$ROOT/tools/check_capture_lifecycle.py"
python3 "$ROOT/tools/check_live_scan_continuity.py"
python3 "$ROOT/tools/check_latency_v297.py"
python3 "$ROOT/tools/check_accept_priority_handoff.py"
python3 "$ROOT/tools/check_accept_aliases.py"
python3 "$ROOT/tools/check_terminal_guards.py"
python3 "$ROOT/tools/check_v305_integration.py"
python3 "$ROOT/tools/check_v306_integration.py"
echo "All active v2.10.306 regression suites passed"

python3 "$ROOT/tools/check_v307_integration.py"
