# v2.10.299 — 合格单首击提速 / 自适应 OCR / Reject 让路

- 新合格事件立即绕过旧 Reject 的 36ms 探测门槛；同一事件重复探测保留 36ms 去重，避免每 12ms 打满 Binder。
- 一般规则已合格、当前事件有新鲜数值时，首次索引按 a/$/mi 三组并行；其它路径保留 a/e/$/mi。
- 同一窗口内 RN UI generation 变化不在读取中途作废已有的顶端 Accept；服务/窗口更换仍让路。
- 一般规则已经合格时，不再额外以商家“•”查询作为首击前必经步骤；不合格 Reject 逻辑不动。
- 无 indexedRead 的 Accept 首击取消旧快照 TTL 与二次 quickRefresh 树读；同 App 前台/终态/按钮几何仍保护。
- 同一接单事务的 RETRY_CURRENT_INDEX_PAGE 不再因 80ms 年龄或 UI 代际变化拒绝缓存坐标；丢失回调占用缩短为 320ms。
- OCR 默认配置仍为 20ms；新单数值/可见 Accept 的热窗口自动 12ms，空闲维持 20ms，12ms 主心跳保持不变。
- 重新发布订单按原版本重新处理；规则与 Reject 优先级之外不变。
- 版本 2.10.299 / versionCode 325；本地回归和语法验证不代表 APK 实际编译。

测试结果详情见根目录 README-v299.txt；完整说明在交付目录。
