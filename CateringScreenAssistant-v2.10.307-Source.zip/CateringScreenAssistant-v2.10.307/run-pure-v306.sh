#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${TMPDIR:-/tmp}/csa-v29-tests"
rm -rf "$OUT" && mkdir -p "$OUT"
if command -v javac >/dev/null 2>&1; then
  JAVAC=(javac)
else
  JAVAC=(java com.sun.tools.javac.Main)
fi
"${JAVAC[@]}" -d "$OUT" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/UiMutationPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AcceptAttemptAudit.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PageOutcomePolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/BoundedReadBatch.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionGeometry.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionRowPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AcceptObservationPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AccessibilityFallbackPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionDispatchPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionStallPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AlertDedupe.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ButtonLabels.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AnchorlessOfferGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimBudget.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimConfirmation.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimSuccessSignals.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/NumericGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OfferPriority.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PageGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PasadenaRuleGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/QuickEvidencePolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/QuickTreeBudgetPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/IdleFallbackPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSequence.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectConfirmation.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectConfirmPriorityPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AcceptPreemptionPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ScanPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/VisualRetryPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/FastSnapshotPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/LargeOrderPopupGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/HotOfferScanPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OutcomeEventFence.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectTerminalGate.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/UniversalNumericFastPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/VisualAcceptFadePolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/VisualGenerationReboundPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectWorkPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OfferEnrichmentPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectDemandPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AcceptSpinnerPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSpinnerPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectReadProgress.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PipelineTiming.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/LiveScanHealth.java" \
  "$ROOT/tests"/*.java
for cls in AcceptPreemptionPolicyTest RejectSpinnerPolicyTest LiveScanHealthTest IdleFallbackPolicyTest PipelineTimingTest RejectReadProgressTest ContinuousClaimTest RejectRollbackTest AcceptSpinnerPolicyTest TextParseCacheTest HotpathEquivalenceTest RetryIdentityPolicyTest VisualRetryPolicyTest AcceptAttemptAuditTest PageOutcomePolicyTest BoundedReadBatchTest RejectDemandPolicyTest OfferEnrichmentPolicyTest RejectWorkPolicyTest AcceptObservationPolicyTest AnchorlessOfferGuardTest LargeOrderPopupGuardTest HotOfferScanPolicyTest OutcomeEventFenceTest ActionRowPolicyTest AccessibilityFallbackPolicyTest FastSnapshotPolicyTest ActionDispatchPolicyTest ActionStallPolicyTest ActionGeometryTest AlertDedupeTest ButtonLabelsTest CardTextTest ClaimConfirmationTest ClaimSuccessSignalsTest NumericGuardTest OfferFlowTest PageGuardTest PasadenaRuleGuardTest QuickEvidencePolicyTest QuickTreeBudgetPolicyTest RejectSequenceTest RejectTerminalGateTest RejectConfirmationTest RejectConfirmPriorityPolicyTest ScanPolicyTest UniversalNumericFastPolicyTest VisualAcceptFadePolicyTest VisualGenerationReboundPolicyTest; do
  java -cp "$OUT" "com.local.cateringscreenassistant.$cls"
done

