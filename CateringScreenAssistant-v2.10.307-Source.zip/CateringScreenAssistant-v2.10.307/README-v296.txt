v2.10.296 source; created from 2.10.295. See CHANGELOG-v2.10.296.md. Android APK not built here.
