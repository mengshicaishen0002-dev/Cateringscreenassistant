# 最新版本：v2.10.304（结构唤醒、首击索引及回执资源竞争专项）

版本：2.10.304 / versionCode 330。详见 CHANGELOG-v2.10.304.md 与 TEST_REPORT-v2.10.304.txt。

## 历史版本

# 最新版本：v2.10.303（扫描、事务、回放联合修复）

版本：2.10.303 / versionCode 329。详见 CHANGELOG-v2.10.303.md 与 TEST_REPORT-v2.10.303.txt。

## 历史版本

# 最新版本：v2.10.302（双模式）

**版本：2.10.302 / versionCode 328。** 详见 [CHANGELOG-v2.10.302.md](CHANGELOG-v2.10.302.md) 与 [TEST_REPORT-v2.10.302.txt](TEST_REPORT-v2.10.302.txt)。

## 历史版本

# 最新版本：v2.10.301（手势对照与响应确认）

**版本：2.10.301 / versionCode 327。** 详见 [CHANGELOG-v2.10.301.md](CHANGELOG-v2.10.301.md) 与 [TEST_REPORT-v2.10.301.txt](TEST_REPORT-v2.10.301.txt)。未构建 APK。

## 历史版本说明

# 最新版本：v2.10.300（首击 Binder 加速／顶单抢占／回调前补击）

**版本号以 `app/build.gradle` 为准：`versionName 2.10.300` / `versionCode 326`。**

**v2.10.300（承接 v299）接单优先级：**已经开始 Accept 的合格订单继续完成；旧 Reject 尚在等回调时，如果新顶单符合规则，抢先索引并发送 Accept；Reject 回调晚到也不覆盖新的接单事务。若只是同一被拒订单重新发布，保留原版逐次判断 / Reject 流程，不视为不同新顶单。详见 [CHANGELOG-v2.10.300.md](CHANGELOG-v2.10.300.md)。


本版针对 v2.10.296 实机日志的 `SERIAL_BUSY`、`presence_unknown` 与部分扫描长尾：
首次并行索引繁忙时，主扫描不再串行补查 `a/e`（仍无法取到同批金额证据），而是尽早让出给下一轮快速扫描；独立空页探测改为 `Jobs/e/$` 三项并行、34ms 预算并区分 `BUSY`/`BUDGET`。详见 [CHANGELOG-v2.10.297.md](CHANGELOG-v2.10.297.md)。

**保持**：同一订单重新发布按当前规则重新拒/接，不永久封单；Accept 首击与持续补击优先、Reject Spinner、Jobs 列表有单/空单→Offers、接单成功后返回 Offers。源码测试已运行，仍需 Android APK 实际编译和手机实测。

---

# v2.10.291 — 连续快速扫描与历史失效逻辑清理

- **保留 12ms 实时监控心跳及首击快速索引**，不引入新等待；UI 新事件始终立即可触发快路径。
- **降低空闲慢扫描**：快树/完整树兜底预算 40ms/28ms；同代空页面不重复完整深扫，同代失败树读取 48ms 内合并。活跃订单绕过空闲抑制。
- **删除历史失效墓碑机制**：所有旧订单拦截、无效调用、已停用的别名/恢复逻辑和不再使用的历史类移除；每次当前订单重新出现均重新读取判断。
- **不移除当前保护**：当前失效提示、Spinner、相同交易占用、金额/里程实时一致性与 Reject 并发校验保留。
- **验证**：静态解析 107 个 Java 文件 0 语法错误；快速索引 996 项、连续扫描、慢树预算和当前订单准入等回归通过。尚未完成 Android SDK 编译/实机时延验证。
- **生成 APK**：见 `GITHUB_BUILD_README_CN.md` 和 `.github/workflows/build-apk.yml`。需要保留原升级签名密钥并放在 GitHub Actions Secret 中。

---

# v2.10.290 — 连续快速扫描稳态优化（v2.10.289 最小补丁）

- **每 12ms 监控心跳、首击 Action/数值索引、规则、点击/Spinner/续击判断全部不改。** 新订单结构事件和当前可读订单永远绕过下述空闲限制。
- **仅在没有新订单信号、没有有效索引和没有正在处理的订单时**，把快速树兜底等待读取上限从 80ms 缩到 40ms；完整树兜底从 60ms 缩到 28ms。无障碍慢根节点不再拖长空闲轮次；OCR 继续独立兜底。
- 对同代、证据完整的 Offers 空页：快速树已确认空页时直接进入下一轮，省去重复完整树。
- 对同一代、空闲页面的完整树读取失败：48ms 内合并冗余重读，快速按钮/金额/里程索引仍每轮运行；任意新事件/金额证据/世代变更立即允许完整树读取。
- 相同状态信息不反复排入日志/通知线程；不跳过任何变化状态。
- 加入 `IdleFallbackPolicyTest` 验证冷/热预算、事件绕过、世代更新与恢复边界。

> 这是**源码**改进。不能把 Android Accessibility Binder/OEM 的响应时延当作可保证的硬实时，因此设备上的最坏延迟需通过下一份 replay 实测；不会声称绝对 0 慢扫描。成功接单仍以 DeliverThat 页面或服务端证据为准。

---

# v2.10.289

版本号 315。并行按钮查询的首份结果到达即可开始筛选，两份结果齐全才建立顶部订单及失效提示证据。移除多余的末层父节点读取。常规兜底根据本轮已用时间分配动作索引、拒单索引、快速树、完整树的共享预算（125ms 调度目标），给快速树留出 25ms，剩余不足时进入 OCR 路径。

---

# v2.10.288

版本号 314。先完成 Accept 热区排序，再核验唯一的顶部按钮；跳过已经被更靠上按钮取代的候选控件的可点击性读取。同轮数字字段绑定省去重复数字筛查。

---

# v2.10.287

版本号 313。首卡发现索引最多等待慢根节点 20 ms，当前根节点就绪时立即唤醒并复用。界面世代或窗口切换时，旧根节点等待和并行索引查询可尽早让路。同代、同一窗口内短时有效的根节点凭据可供前台 Reject 索引复查复用。共享 Accept/Reject 索引日志区分根节点 Binder、线程排队和查询耗时。

---

# v2.10.286

版本号 312。共用首卡索引先区分按钮、数字字段和普通文字，仅对按钮和字段读取位置及启用状态。复用按钮解析的临时坐标，只留最终选中的 Accept 控件。首击提交后记录索引结果收集、节点筛选与 Reject 边界、Accept 解析、字段匹配、清理及顶部核验、数字结果等待和绑定。

设置中的间隔控制 OCR 兜底，默认 20 ms。可选 12–19 ms 只在已有新单信号且无动作占用时使用，空闲至少 20 ms。独立的无障碍事件、巡检和首击发送流程保留原调度。

---

# v2.10.285

版本号 311。完整树兜底共用一次读取的页面、卡片和顶部文本，移除扫描末尾用于页面辨认和诊断的重复树读取。快速树和完整树兜底在有界读取线程执行，页面变化或新订单结构事件可让扫描提前结束。无可读结果与明确空页分别记录。同卡 Reject 证据变化后合并复查，Reject 索引读取有时限并在新订单到来时让路。Accept 首击索引、规则与手势沿用 v2.10.284。

---

# v2.10.278

版本号 304。扫描诊断在线程后台汇总，首击线程只提供扫描状态和已有快速读取结果。触摸期间的只读探测独立运行，保护窗口结束前停止启动新的只读查询。

---

# v2.10.277

版本号 303。触摸保护期间继续读取前台卡片和采样画面，动作继续受触摸保护约束。持续界面事件最多推迟短暂的快速树兜底窗口，避免数值尚未出现时反复跳过。

新增「查看实时扫描诊断」，记录近期扫描及快速树读取结果，包括读到的金额、里程及 Accept 状态。没有发出 Accept 时也可查看本次监控的诊断。

---

# v2.10.276

版本号 302。Reject 从首次提交起单独计时，到期写明未确认。复核和补拒共用原尝试 ID。确认不同顶部或前台两次明确空页后释放旧卡，真实重现的同一张卡可立即从新事务开始。

共享 Reject 按钮解析复用已经读取的文案和父按钮坐标，避免重复读取。收尾日志保留尝试 ID，监控运行期间暂时暂停点击也能记录旧卡结果。

---

# v2.10.275

版本号 301。Reject 处理中与卡片离开顶部使用不同的日志状态，旧卡让位及串行确认日志保留尝试 ID。

共享 Reject 索引记录同卡金额与里程的读取时间，区分事件与索引来源。日志新增根节点、查询、按钮解析、数值、字段与证明分段耗时。去重两个标签查询返回的相同节点，数值已明确不通过时省去多余的完整规则检查。

---

# v2.10.274

版本号 300。系统停止屏幕捕获后，无障碍扫描和监控服务继续运行。重新授权屏幕捕获后恢复 OCR。保留原有人工介入和恢复流程。

离开 DeliverThat 时保留原 Reject 尝试，等待返回前台触发复核。旧卡复核到期只结束该次观察，扫描继续。分别记录窗口不可读、离开 DeliverThat、人工暂停和服务停止。确认超时保留结果未知。

共享索引尝试从 Reject 文案解析同窗可点击控件，保留禁用状态及发送前的顶部卡片校验。增加同卡数值首见到首次唤醒的耗时，方便定位提交前延迟。

---

# v2.10.273

版本号 299。拒单确认保留已取得的同代空页证据，界面读取不完整时继续等待。证据长期不完整时逐步退避，直至确认或到期。日志分别记录处理中等待、预算退出、界面变化和缺少证据，并为每次尝试记录编号。

前台 Reject 索引会复用仍新鲜的同窗同代根节点，日志记录复用失败原因。首击日志增加扫描队列、最近结构唤醒及当前 Reject 快照时间。筛选规则和 Accept 续击条件沿用 v272。

---

# v2.10.272

版本号 298。新的 Offers 结构事件会把尚未开始的扫描提前到队列前端。如果扫描已开始并遇到新的界面代次，会在昂贵的后续索引前让路给新事件。

同次索引已经验证顶部 Reject 和金额、里程，且两套数值规则都不通过时，复用该索引的按钮证据。日志将来自事件或索引的数值首见统一标为「数值首见」。

---

# v2.10.271

版本号 297。Accept 续击使用最终按钮刷新的时间校验加载状态。跨过转圈结束的同一轮页面读取可以提供按钮证据，前提是按钮在最后一张转圈帧之后刷新，当前界面和同卡验证都通过。发送前仍等待连续两张无转圈帧。

回放记录页面读取和按钮刷新的时间，以及续击在入队或发送阶段被拦截的原因。页面已失效时继续走原有的 Offers 返回流程。

---

# v2.10.270

版本号 296。

- 转圈后连续两帧清晰即唤醒同单续击取证。优先复用当前页面证据。原控件无法刷新时，将已排队的页面读取提前执行，前台窗口和同卡验证仍在发送前生效。
- 首击复用当前节点的 Ignore 热区与同代金额、里程索引。完整的金额和里程查询结果不再触发一轮重复查询。
- 回放保留最近一次 Accept 视觉边沿两侧的截图，并在时间线列出边沿采集时间。只采到一侧时，时间线标明缺失的帧。
- 首击三触点与订单筛选沿用 v2.10.269。

---

# v2.10.246

当前版本versionCode272。保留UI_CHANGED中的同一补击预约，完整取餐时间身份改用现有线程分波读取，成功长警报与待核对短提示分开，补齐冻结TX诊断。规则和首击手势不变。详见 [CHANGELOG-246.md](CHANGELOG-246.md)，运行 `./run-regression-tests.sh` 执行基础回归及全部44项脚本。

---

# v2.10.245

当前版本 versionCode271。连续补击改为每批3触点、复用已发布的当前布局证明、修复恢复启用统计，并分开记录发送与回调时刻。规则与首击触点保持不变。详见 [CHANGELOG-245.md](CHANGELOG-245.md)。运行 `./run-regression-tests.sh` 执行基础回归和全部42项脚本。

---

# v2.10.244

当前版本 versionCode270。补齐分配给其他司机的失败文案、页面预筛选及顶部终态OCR，接入已有结果核验和UNKNOWN迟到结果观察。首击与正常补击方法保持v243一致。详见 [CHANGELOG-244.md](CHANGELOG-244.md)；运行 `./run-regression-tests.sh` 可执行基础回归和全部42项脚本。

---

# v2.10.237

当前版本 versionCode263。针对 v236 的 Long Beach $100.40 日志，隔离原单启用证明的调度线程和读取槽位，减少普通OCR的同卡重复工作，修正失效页面的拦截说明。详见 CHANGES-v2.10.237.md、ANALYSIS-v2.10.237.md、VALIDATION-v2.10.237.md。

---

# v2.10.236

当前版本 versionCode262。根据 Porto's $135.05 与 Mendocino $194.28 的 v235 日志，压缩视觉首击的上方订单检查、处理中按钮的重复整页读取，并细化节点回退原因。详见 CHANGES-v2.10.236.md 与 VALIDATION-v2.10.236.md。

---

# v2.10.235

当前版本 versionCode261。根据最新goop Kitchen回放优化加载后的原单节点刷新；失败时保持整页定位回退。详见 CHANGES-v2.10.235.md、REPLAY-v2.10.235.md 和 VALIDATION-v2.10.235.md。

---

# v2.10.234

当前版本 versionCode260。压缩首卡读取后的重复字段获取与诊断格式化、按钮恢复启用后的核验排队及重复点击入队。详见 CHANGES-v2.10.234.md 与 VALIDATION-v2.10.234.md。

---

# v2.10.233

当前版本 versionCode259。修复当前失效提示页面重复建立 Accept 事务；详见 CHANGES-v2.10.233.md 与 VALIDATION-v2.10.233.md。

---

# v2.10.232

当前版本：versionCode 258。改动见 CHANGES-v2.10.232.md，测试与构建记录见 VALIDATION-v2.10.232.md。

构建需要 JDK 17、Android SDK 35 / Build Tools 35.0.0；运行 `bash run-regression-tests.sh` 验证业务回归，运行 Gradle `:app:assembleRelease` 构建。沿用内置升级签名。

---

# v2.10.201

基于v200优化当前同卡快速第二击、共享精确按钮识别、字段去重及结果查询分组。用户规则保持不变。详细说明见 RELEASE-v2.10.201.md。

---

# v2.10.200

已修复启用凭据排队过期与重复核验入队，增加结构事件根预取。详细核对见 RELEASE-v2.10.200.md。

---

# v2.10.199 更新说明

针对 v2.10.198 Cafe Rio 日志：数值首见至首击为18ms，但索引读取开始至发送仍为77ms，其中根读取31ms、动作读取26ms。按钮曾禁用，直到失效提示出现后才再次读到启用，日志不能证明更早重试一定可用。

本版改动：
- 合格金额事件提前启动单路根节点读取；并发请求共享在途任务，避免重复冷读。保留窗口、代次、前台与节点生命周期检查。增加 ROOT_READ 与 leadMs 诊断。
- 合并动作端点读取与文本去重，复用已完成的数值解析，减少快照到发送入口的重复计算。
- 独立轻量观察当前按钮，禁用、未导出时自适应降频；启用恢复立即唤醒原订单核验，避免旧页面快照再延迟100ms。节点脱离时最多两次定向查找。观察只负责唤醒，不能授权点击。
- 保留20ms动作冷却及未发送重试退避。保留订单身份、规则、事务次数、最终当前启用按钮和终态检查；不放宽 UI_CHANGED 校验，不进行无条件连点。
- 增加按钮未导出的具体原因和读取前后页面代次诊断。

验证：完整回归通过，其中774项索引/首击/凭据案例、30项稀疏首卡检查案例、10项预取/按钮唤醒准入案例。Release编译通过，versionCode225，沿用原签名。

尚未进行本机实测；40ms以内总流程和平台接单成功率需新日志验证。预取无提前事件时可能没有提前收益，不能把数值首见至发送视为完整发现延迟。

---

# v2.10.198 — 根信息复用、文本解析提速与页面重试交接

对应11月4日15:59与16:04两份v197日志。

## 已实现

- 初始Accept索引允许复用40ms内同服务、同UI代次、同窗口代次且前台仍为DeliverThat的已验证根节点副本。超过时限、代次变化或前台改变即重新读取。复用不会刷新原时间戳；首次冷读取仍需要Android响应。
- 金额、里程、订单身份、订单ID、取餐时间键、地址键使用每线程最多32条的不可变文本解析缓存。改变文本重新解析，过长文本不保留。按钮状态、窗口和页面新鲜度不进入该缓存。
- 同一Accept事务的待执行核验合并；更早的页面证明可替代延迟任务。过期任务票据不再读取页面，旧事务不能替换新事务的核验任务。已在执行的Android读取不能被抢占。
- 取得页面按钮证明后，把身份绑定与诊断日志的规则解析移出发送关键路径；页面证明复用日志移到最终发送校验调用之后，避免写日志期间证明过期。
- 页面证明保留有界的可刷新按钮/字段节点。取到证明后同窗口UI代次改变时，优先刷新当前按钮及完整身份字段；必须重新证明同卡、启用、同几何范围与稳定代次。40/80ms窗口证明仍受原有前台、窗口与终态约束。该路径不再叠加完整索引读取。
- 无法重新证明的页面证明返回RETRY_PAGE_REPROBE_REQUIRED，等待新证明，不用旧坐标点击。
- 未实际发送的重试回退后，预算退避由200ms降为20ms，后续核验延迟也由200ms降为20ms。已发送次数不回退；禁用按钮与新鲜失效提示仍禁止点击。
- 修正“第3次未执行”后固定写“复核第2次”的日志；按语义身份去重身份补全日志。
- 独立索引发现同卡按钮禁用时补齐诊断台账，避免处理日志已发现禁用却仍显示firstDisabled=UNOBSERVED。该补齐不改变成功、失效或重试授权状态。

## 验证

- 完整run-regression-tests.sh通过；原有规则、跨卡拦截、结果绑定、Reject与导航测试通过。
- 759项实际索引/首击/证明用例，包括根复用的40ms边界、UI/窗口/前台失效和页面证明节点重绑；地址改变、禁用和终态提示均禁止重试。
- 204项文本解析/淘汰/多线程检查，以及2796项原有热路径解析和预算差分检查通过。
- 新增实际调度方法测试：1000个重复延迟唤醒合并、即时唤醒替换、旧任务不读页面、旧事务不能覆盖新事务、停止监控取消待执行任务。
- APK版本2.10.198，versionCode224，沿用既有升级签名。

## 实机限制

尚未在用户手机测量本版耗时。76ms完整流程和40ms目标必须用新日志验证；首次冷根读取、Android调度及应用页面导出仍可能超过目标。不会通过移动计时起点、删去前台/身份核验或把未发送动作计为已发送来制造提速数字。Android手势发送成功不等于应用请求或平台接单成功。


---

# v2.10.197 — 并行首击索引、20ms动作冷却与重试交接修复

## 改动

- 首击的 a/e 动作查询和 $/mi 数值查询由前后两批改为同一批四路并行；待顶部动作确定后再按几何范围绑定数值。若动作查询已经包含完整数值，直接复用这些字段，释放预取结果，不重复处理字段或追加数值查询。
- 保留当前窗口、UI代次、顶部动作、金额/里程、特殊城市和预约时间规则校验。不能用查询未完成或跨代次的结果点击。
- Accept的索引、视觉、OCR三条发送路径，以及Reject发送路径的固定动作冷却改为20ms；Accept固定动作占用标记也改为20ms。事务锁、实际发送次数与成功/失效确认仍独立约束点击。
- 下一轮页面探测开始时不再清空上一轮未消费的启用按钮证明。完整的新读若未证明可点击则清除旧证明；新鲜度80ms、UI代次、窗口、事务和终态校验仍会否决旧证明。
- 首次终态探测进行期间，重复的前台索引任务以20ms异步让路，最多覆盖首击后250ms的重叠时段；探测取得启用按钮证明后立即唤醒，不必等满此时段。
- 独立慢索引结束时再检查是否已有更新的页面按钮证明，避免丢掉期间新到的证明。
- 增加 ACCEPT_RETRY_WAKE 队列耗时与 ACCEPT_PAGE_RETRY_REUSED 消费日志；INDEX_PHASE显示PARALLEL_4、批读取及排队耗时。

## 验证与限制

- 回归覆盖四路查询同时启动、同卡绑定、跨卡/跨代次拒绝、证据单次消费、下一轮让路不擦除证据、负面新读清除旧证明、慢索引期间新证据到达、首次索引让路上限、原事务与次数预算。
- 40ms是实机优化目标，不是保证。root读取、Android Binder调度和页面导出延迟仍可能超过40ms；日志同时保留索引开始到dispatch与本机数值首见到dispatch，不能混用两个口径。
- Android接受手势只证明发送动作被接受，不能证明应用已发网络请求或平台已接单。订单消失不直接判为成功；20ms动作冷却也不把服务器/UI结果核验截断为20ms。
- 本版本未在用户设备或DeliverThat平台上验证抢单成功率。


---

## v2.10.77 Pasadena ancestor-evidence immediate wake

- Accessibility 事件先以当前节点唤醒快速线程；父节点随后补齐金额、里程、城市或地址时，再立即触发一次快速检查。Pasadena 单不再无故等待下一次 React-Native 事件或 40ms 心跳。
- 新卡字段短等待窗由 96ms/16ms 轮询压缩为 64ms/8ms；若字段仍不完整，会更早进入当前树/OCR兜底。
- 蓝色 Accept 的视觉热探测从 32ms 压至 24ms，并继续使用独立时钟：失败不会启动 OCR，也不会延后正常 OCR。
- General、Pasadena 城市证据、按钮几何、订单墓碑、点击次数和接单成功确认门槛全部保持不变。

## v2.10.76 Hot visual probe + staged latency telemetry

- 新订单金额/里程进入 Accessibility 后的前 900ms，增加 32ms 独立节流的蓝色 Accept 轻量探测；上一张卡留下的 500ms “已可读”抑制不再挡住当前视觉首击。
- 热探测只读取当前 ROI 的蓝色按钮并使用同代、同金额/里程的缓存证据；失败即返回，不同步扫树、不启动 ML Kit OCR，也不更新时间戳饿死正常 OCR。
- General 合格单继续允许金额＋里程＋当前 Accept 锚点直达；Pasadena-only 单仍必须取得 Pasadena 城市证据，城市/时间筛选规则完全不放宽。
- Accept 日志拆分为 `FIRST_SEEN_NUMERIC`、`RULE_READY`、`ACCEPT_ANCHOR` 到 dispatch 的耗时，下一份真机日志可直接判断延迟来自 App 导出、规则字段还是按钮锚点。
- v2.10.75 的长效不可用墓碑、严格成功判定、Reject 消失完成和成功警报均保持不变。

## v2.10.75 Sparse internal-id tombstone promotion

- 服务器先对完整卡返回 `offer unavailable`、React Native 数秒后才在残缺帧暴露 `UBC_` / `GOP_` / `d_` 等内部订单ID时，使用金额＋里程＋预约时间建立15秒只读绑定桥梁。
- 匹配的内部ID立即升级成持久化6小时订单墓碑；之后残缺OCR帧直接静默跳过，不再启动三次动作行复核、规则判断或点击。
- 绑定桥梁缺少预约时间即不成立；金额、里程或时间任一不同均视为不同订单。桥梁只拦截不可用订单，绝不授权Accept/Reject。
- v2.10.74 的dispatch即追踪、严格成功证据、Pasadena规则、拒绝流程和成功警报保持不变。

## v2.10.74 Accept dispatch/callback race fix

- `dispatchGesture()` 返回成功后立即进入服务器/UI终态追踪，不再额外等待部分 Samsung/OEM 可能延迟或丢失的 `onCompleted` 回调。
- Gesture 完成回调现在仅作为诊断证据；缺失时保持同一事务和尝试次数，不再等 1.8 秒后清空状态并把同一订单重新标成“第1次”点击。
- 只有 Android 没有接受 Gesture dispatch 才会取消事务。服务器 `offer unavailable`、Jobs徽标、绑定订单详情等终态证据仍使用原有严格门槛。
- dispatch 成功会立即唤醒快速检查，缩短服务器终态捕获延迟；规则阈值、Pasadena逻辑、墓碑与成功警报均未改变。

## v2.10.73 Hawk architecture audit + local liveness hardening

- APK inspection confirms Hawk's competitive edge is architectural: its phone app is a WebView/control panel backed by a remote bot service and Firebase notifications. It does not expose an Accessibility or screen-capture service, so its acceptance latency is not produced by faster on-device OCR.
- This project remains local-only and does not reuse Hawk credentials, endpoints, session tokens, or proprietary acceptance code.
- While monitoring, the dedicated Samsung now holds both CPU and screen wake locks so screen timeout cannot freeze DeliverThat's React-Native Accessibility surface.
- Added a user-controlled battery-optimization exemption entry for Samsung background reliability.
- The recurring fast lane now reschedules in a `finally` block after an OEM runtime exception; Accessibility-only fallback also switches to a 40 ms heartbeat during a detected numeric-offer burst.
- The existing 8 ms-class cached-evidence Accept path, strict success gate, unavailable tombstones, Reject event fence, and 60-second success alarm are unchanged.

## v2.10.72 Reject terminal event binding

- Reject 只接受动作基线之后新产生的 Accessibility 服务器终态事件；完整树重复读到的旧 `offer unavailable` 不再刷新终态。
- Android 点击完成回调到达前不消费 Reject 终态，防止事务先结束、迟到回调又创建第二个后台确认。
- 若事务已由换顶/终态结束，迟到回调只记录 `REJECT_DISPATCH_COMPLETION_LATE`，不启动后台任务、不补点。
- v2.10.71 的 40ms 热订单扫描、140ms 防饥饿与全部规则保持不变。

## v2.10.71 fastest safe Accept hot path

- 金额/里程首次出现后，临时从空闲 600ms 心跳切换为 40ms 热订单竞速心跳。
- React-Native 连续输出不完整事件时只允许抢占 140ms；达到上限后必须读取当前顶部，防止完整树被持续饿死到 1–2 秒。
- 每次补读仍重新确认当前顶部、金额、里程、Pasadena 城市证据、Accept 状态与按钮坐标；没有降低接单规则。
- 扫描任务不重叠：下一次热心跳在当前任务结束后安排，避免慢手机堆积队列。

## v2.10.70 Reject disappearance completion + bounded final rescue

- Reject 后没有服务器终态，但同一订单已从顶部消失时，记录为 `REJECT_DISAPPEARED`，按拒绝完成处理。
- 后台收尾超时前只做一次受限实时复核；只有同一顶部订单仍在、Reject 仍启用且重新取得新鲜按钮坐标，才允许第 2 次动作。
- 新订单事件优先于旧 Reject 收尾；不同订单、按钮禁用、页面离开或证据不完整时绝不沿用旧坐标点击。
- `RejectSequence` 继续执行最多两次逻辑动作的硬上限。

## v2.10.69 Hawk-style latency and confirmed-success alarm

- Keeps the existing event-first Accessibility/visual/OCR race, but shortens the first verified
  Accept stroke from 24 ms to Android's enforced 18 ms floor.
- Compresses the React-Native event-burst wait from 180/32 ms to 96/16 ms so incomplete early
  events fall through to current-button verification sooner.
- Holds a partial CPU wake lock only while the foreground monitor is active, reducing replacement-
  phone power-management scheduling stalls; the lock is released when monitoring stops.
- A confirmed claim now starts a looping alarm ringtone and repeating vibration for up to 60 seconds.
  The high-priority ongoing notification includes a **Stop alarm** action and the main screen has a
  safe test button.
- Alarm entry is still behind v2.10.68's strict success gate. Offer disappearance, Timeline/Job
  candidates, gesture dispatch, and `offer unavailable` never trigger it.

## v2.10.37 Accept same-card callback observer fence

- Once Android accepts the first Accept dispatchGesture() request, late OCR callbacks for that same semantic card become observation-only and return before action-anchor parsing, rule evaluation, popup actions, or a second action path.
- Accessibility fast-lane callbacks for an active Accept remain owned by the existing pending-transaction observer and cannot re-enter normal offer discovery.
- ACCEPT_LOST behavior is intentionally unchanged: loss still ends the current transaction exactly as v2.10.36 did, and a later reappearance may be handled by the existing logic.
- Reject confirmation priority, Large Order popup handling before Accept, Pasadena rules, thresholds, scan cadence, and gesture durations are unchanged.

## v2.10.36 Reject-confirm foreground priority

- Any coherent new top offer immediately cancels background confirmation for a different old Reject.
- Reject confirmation now uses an active-window-only 90 ms / 72-node budget; it never runs the multi-window full-tree `findOffer()` path.
- Background Reject confirmation is capped at 2 probes / 950 ms. Budget exits do not count as card disappearance and do not alter same-card RejectSequence retry state.
- A genuinely different new top card keeps only a short Reject tombstone to prevent the old card animation from restarting Reject #1.
- Gesture fallback logs now split preparation, `dispatchGesture()` call, and callback latency, so a slow `ACTION_CLICK unavailable -> Gesture` case can be diagnosed precisely.
- Accept state machine, Reject click/retry semantics, Large Order popup guard, Pasadena rules, and all user thresholds are unchanged.

# v2.10.30

## v2.10.35 Quick-tree tail latency guard

- Foreground bounded quick-tree now has a 150 ms / 128-node soft budget.
- A budget miss yields to OCR rather than stacking an expensive full-tree scan on the same slow frame.
- Semantic action indexing stays live during the short OCR-yield window.
- Async Reject confirmation timing is transaction-local and cannot inherit a later card's scan timing.
- No rule thresholds, Pasadena semantics, Accept/Reject transaction rules, popup handling, or gesture durations changed.


- Action chain only: reuse already-validated fresh snapshot/root evidence before the first action; no threshold changes.
- Reject confirmation moved off the fast action lane to a dedicated background confirmer; next top offer can be evaluated immediately while the old Reject is confirmed.
- Pasadena protection: the special rule requires a parsed pickup address/city of Pasadena, not a bare text match. Decision logs show `RULE=PASADENA` or `RULE=GENERAL` with a reason.

## v2.10.29

Reject Fast-Exit release. Rule values and rule semantics are unchanged. When the indexed Accept path has already identified a complete ineligible top card, the monitor now searches only the same card's local action-row ancestors for the left Reject control before any 180-node quick-tree/full-tree fallback. Reject ACTION_CLICK also first follows only nodes intersecting the already-verified fresh Reject rectangle, avoiding a second ~140-node semantic walk when React-Native exposes a blank-label action node. Existing same-offer numeric verification, side-specific geometry, top-card serial lock, continuous monitoring, post-claim isolation and Jobs badge 1→2→3 success tracking remain intact.

## v2.10.28

Continuous-claim hardening + blank-label first-shot optimization. A confirmed or manual claim now invalidates every older OCR frame and quarantines only the assigned-job detail surface; monitoring remains alive and automatically resumes on the next verified Offers card. Jobs badge increases are tracked cumulatively (0→1→2→3...) as strong success evidence. Accepted-job details containing Pickup/Dropoff Instructions plus job-only approval metadata can no longer become synthetic offers. For blank-label Accept buttons, a fresh screen blue-button rectangle may be fused with same-generation Accessibility pay/miles/city/time evidence so the first Gesture55ms can be sent before ML Kit finishes; all configured rule values and rule semantics remain unchanged. OCR mileage drift such as 0.7→7 is corrected only when an independent same-offer Accessibility representation matches pay/time/merchant.

## v2.10.26

Latency Pipeline release. Keeps the 80 ms scan profile and the Galaxy A15-proven 55 ms first Accept gesture. Accessibility snapshots now cache pay, miles and stable identity once; a complete rule decision plus the correct side-specific action anchor owns the frame so OCR only runs for missing evidence. After Accept is observed disabled/processing, confirmation becomes event-first and full-tree rechecks are throttled to one per 520 ms quiet window instead of rebuilding the React-Native hierarchy every ~95 ms. The action log also reports snapshot-to-dispatch latency. Existing top-card serial locking, live numeric matching, page guards, Reject transaction separation and terminal ACCEPT_LOST behavior remain intact.

## v2.10.25
September 10 field hardening: the previous APK labeled v2.10.24 was discovered to be byte-for-byte identical to v2.10.23 because the temporary short-name ZIP did not replace the workflow's hard-coded `CateringScreenAssistant-v2.8.0-project.zip`. This release carries forward the v2.10.24 Reject/Accept split and adds an explicit pending-transaction fast-lane gate, in-flight Accessibility race rechecks, action-specific `offer unavailable` handling (`ACCEPT_LOST` vs `REJECT_SUCCESS/REJECT_UNKNOWN`), and a visible v2.10.25 banner.

## v2.10.22

## v2.10.24

- Split Accept and Reject post-action state machines.
- Reject disappearance is confirmed independently and never checks Jobs/claim-success evidence.
- Two consecutive missing reads prevent transient blank frames from falsely confirming a reject.
- `REJECT_SUCCESS` requires prior disabled/processing acknowledgement; otherwise the result is `REJECT_UNKNOWN`.

- Latency-first semantic Accept/Claim index path: qualified offers can bypass the ~130-node quick-tree walk.
- Indexed Ignore/Decline/Reject fallback for the same physical top card.
- Qualified-offer notification is queued after the claim action, never before it.
- Fresh Accessibility Accept snapshots skip redundant page-chrome rewalks; stale snapshots still revalidate.
- OCR Accept uses front-of-main-queue dispatch and recent OFFERS hints to avoid needless pre-tap work.
- Regex-heavy per-node button/page normalization replaced with allocation-light character scanning.
- Keeps the proven 55 ms Samsung-safe press duration.

## v2.10.21

- Fixes the real-device 11:26:33 double-Reject race where OCR and Accessibility treated one calendar-date offer as different card IDs.
- Canonicalizes `September 11 at 10:45 AM`-style pickup times and merchant identity across OCR/tree spacing differences.
- Makes Reject READY-check + attempt reservation atomic across worker threads.
- Immediately requests a coalesced rescue scan when OCR has amount+miles but no reliable action-row anchor.

## v2.10.20
- Fix duplicate Reject: once a live post-click read proves Reject is disabled/processing, the shared OCR + Accessibility arbiter enters a 7-second PROCESSING gate instead of firing attempt #2 about one second later.
- If that processing state really rolls back and the same card remains, the gate reopens after the bounded hold so recovery is still possible.
- Reject retries may no longer reuse an inferred/mirrored left coordinate; a retry must regain an explicit Accessibility/OCR Reject target.
- Faster first-card tree path: page evidence is collected in the same bounded walk, duplicate per-piece regex normalization is removed, and the walk stops once money + miles + California address + a safe action node are all present.
- Card text now suppresses repeated parent/child Accessibility phrases, reducing duplicated merchant/address logs and identity work.

## v2.10.19
- Fix silent-miss path: a stale Jobs/Ignored Accessibility tab hint no longer suppresses MediaProjection OCR while DeliverThat is foreground.
- Strong current offer evidence (money + miles + Accept/Reject/blue Accept) can override a conflicting stale tab hint.
- Quick page scan no longer stops at the first stale forbidden-tab bit; final action still requires numeric + safe button geometry.
- Blue Accept + raw OCR numeric miss now triggers enhanced OCR instead of silently skipping the frame.

## v2.10.18
- Galaxy A15 first-card low-latency path: bounded active-window scan before full tree; avoids duplicate active-window traversal.
- Rule-sensitive completeness guard: Pasadena/city/time decisions fall back when quick text is incomplete.
- Timing diagnostics show quick-tree vs full-tree latency.


## v2.10.17

- Galaxy A15 field fix for Ignore gestures that Android reported as completed while DeliverThat left the card unchanged.
- Reject now prefers a live verified Accessibility `ACTION_CLICK`; if the same offer remains with Reject enabled after 160 ms, it falls back to a 90 ms gesture inside freshly re-read button bounds.
- `ACTION_CLICK` + gesture fallback is one logical Reject attempt and shares the existing two-attempt/1100 ms budget.
- Blank-label React-Native action nodes are allowed only near the already verified left button and must pass amount+miles plus anti-card-container geometry checks.
- Reject logs now distinguish semantic click, semantic-no-change fallback, and gesture-only fallback.
- Accept path remains unchanged to preserve the current low-latency claim path.

## v2.10.16

- Fixes Galaxy A15 recordings where a clearly ineligible DeliverThat offer remained visible and Ignore never took effect.
- Reject/Ignore now uses a 55 ms full press on every dispatch path (Accessibility fast, OCR coordinate, and verified fallback), matching the duration already proven necessary for DeliverThat Accept.
- Accessibility-only mode no longer rejects a structurally valid offer merely because the React-Native Offers page classifier is UNKNOWN; explicit Jobs/Ignored still block actions.
- Reject logs now include source, rect, tap coordinates, and gesture duration so a failed real-device action can be distinguished from a correct server-side transition.
- Keeps the shared two-attempt Reject arbiter, first-card serial lock, anti-card-container geometry, and v2.10.14 Accept fast path.

## v2.10.14

- Optimizes the real-device `$113.73 / 7.2 mi` `offer unavailable` trace: the claim reached DeliverThat, but a stale serial transition delayed the first submit.
- A different top card can now be confirmed in the same frame by OCR + bounded Accessibility amount/mileage consensus; otherwise an urgent next-frame probe bypasses normal cooldown/scan cadence.
- Removes the second full Accessibility hierarchy traversal when the first WindowScan already produced `cards.get(0)`.
- Server-terminal outcomes such as `offer unavailable` / `already claimed` immediately terminate local retries for that offer and stop consuming the fast worker with repeated full-tree polls.
- Reject retry is throttled to at most two attempts with 1100 ms spacing; Accept remains the latency-priority path.
- Retains strict first-card isolation, action-geometry guards and positive success confirmation.

## v2.10.13

- Fixes the field stall where a visible first offer could remain on screen indefinitely after a previous Accept/Ignore transaction.
- Cooldown/action-hold no longer starves capture completely: a bounded rescue OCR probe may run every 320 ms after the old action has aged at least 420 ms.
- A stale serial lock is retired only after two stable first-card OCR observations; one mixed transition frame cannot unlock the queue.
- Retiring a stale lock now also invalidates pending `inspectClaim()` callbacks via an atomic claim epoch and clears old cooldown/action-hold gates, preventing an old callback from re-locking a new top offer.
- If the same top offer remains visible beyond the hard wait, only transient timing gates are released; offer identity and retry budgets stay intact to avoid repeat-click spam.
- Adds explicit `ACTION_STALL_RECOVERY` diagnostics so future field logs show when stale serial/cooldown/hold state was repaired.

## v2.10.12

- First qualified Accept no longer spends time on semantic `ACTION_CLICK`; it goes straight to the already verified 55 ms button gesture.
- Fixes wasted retry budget: while Accept is disabled/processing, the monitor waits without consuming attempts #2/#3; a retry is reserved only after the same button becomes enabled again.
- Fixes one-frame serial-lock lag: because OCR is restricted to the first-card action ROI, a newly anchored different top card retires the stale serial lock and is evaluated in the same frame instead of waiting for another scan.
- Captures recent DeliverThat accessibility event/root outcome text such as accepted/assigned, unavailable/already claimed, or retry/error hints and includes it in claim diagnostics.
- Preserves strict top-card isolation, left/right action geometry guards, stable offer identity, and positive-success confirmation.

## v2.10.11

- Accept now prefers a real safe Accessibility `ACTION_CLICK` on the verified top-card Accept node.
- If that semantic click returns true but the same enabled Accept is still visible 85 ms later, the app falls back to a 55 ms verified button press.
- Retry #2 reacquires the top button and uses a 55 ms center press; retry #3 uses a 65 ms alternate interior point.
- OCR/visual Accept fallback also uses a 55 ms press and logs button rect/tap coordinates.
- Offer identity is stabilized to pay + miles + pickup time + merchant key, reducing duplicate processing when DeliverThat duplicates accessibility text.
- Gesture completion still does not count as a successful claim; positive Jobs/accepted-assigned evidence remains required.

## v2.10.9

- Qualified first taps are no longer cancelled just because the original Accessibility button snapshot exceeded 380/420 ms. Snapshots up to 2200 ms get a bounded active-window revalidation of exact pay + mileage + current button geometry, then dispatch immediately if still the same top card.
- Fast Ignore no longer performs a second full `findOffer()` tree walk before its first click.
- Accessibility action work is prioritized over OCR; new OCR frames pause briefly while an action is in flight.
- Reuses ROI bitmaps to reduce allocation/GC spikes and warms ML Kit at monitor startup.
- Retains v2.10.8 anti-card-container guards and v2.10.5 positive acceptance confirmation.

## v2.10.8
- Fixes the field failure where an ineligible offer opened its detail page instead of pressing Ignore.
- Never replaces a semantic Ignore/Accept label with a larger clickable card ancestor.
- Adds hard left/right button-geometry guards to Accessibility, OCR, fast-tap, retry and semantic-fallback paths.
- Whole-card/full-row/detail-arrow targets are rejected; fallback parent climbing may not escape into the card container.
- Keeps strict first-card serial processing and the v2.10.6 ~80 ms low-latency scan profile.

## v2.10.6
- Galaxy A15 low-latency profile: 80 ms default scan interval (70–100 ms recommended).
- Direct first-card ImageReader-row copy; no full-screen bitmap allocation before OCR.
- First-card OCR ROI tightened to 20–58% screen height.
- Smaller pre-tap Accessibility page probes and 14 ms first-tap gesture.
- ML Kit starts before the visual Accept scan; blue-button pixels are bulk-read into a reusable buffer.
- Split ROI-copy/OCR/total timing diagnostics for real-device tuning.

## v2.10.4
Real-device DeliverThat action fix: gesture-first button execution, strict first-card lock, structural button bounds, no timeout unlock during Ignore/Decline transition.

## v2.10.3
Strict top-card serial queue: process first card → wait for disappearance/countdown → rescan next card.

## v2.10.2 qualified-order alert

Qualifying offers now trigger a high-priority notification, sound and vibration as soon as all active rules pass, before any Accept click is attempted. The alert shows pay, miles and $/mi and is de-duplicated per offer for 10 minutes. This keeps the human driver informed even if DeliverThat ignores an automated tap.

# Catering Screen Assistant v2.10.2


## v2.10.2

- Fixes the two field failures observed on Galaxy A15: `OCR/视觉证据已超过1秒` and `屏幕坐标在点击前已过期`.
- OCR/visual coordinate actions now use a dedicated 2.2 s action-evidence window; the normal OCR-result freshness guard remains tighter.
- Removes the expensive second full multi-window Accessibility traversal immediately before a coordinate gesture.
- Adds a bounded 90-node active-root page probe plus a short-lived page hint; positive JOBS/IGNORED still blocks the action.
- Reduces the background full-tree heartbeat from 90 ms to 900 ms because real device traces showed one tree walk taking 394-785 ms. Accessibility content-change events remain immediate.
- Adds action-age diagnostics to inferred Reject logs.

## v2.10.0
- Accessibility scans all DeliverThat interactive windows and no longer prunes descendants under invisible WebView/Compose containers.
- Reject OCR/visual coordinates can dispatch a fresh verified gesture when DeliverThat does not expose a Reject Accessibility node.
- Accept/Reject can be paired from the two-button row geometry when one label is missing.
- Enhanced OCR is skipped when a usable action-row anchor already exists, reducing avoidable latency.


Primary path: Android Accessibility control-tree parsing and action. Button text is optional; blank clickable nodes can be paired structurally with the offer card. OCR remains fallback only.

Android / Samsung local offer-screen assistant for DeliverThat.

Core architecture:
- Dedicated 90 ms Accessibility fast path (event-driven + heartbeat)
- ML Kit OCR on a separate worker as a true fallback
- Fresh-screen verification before every action
- Strict serial queue: only the first visible offer card may be accepted/rejected; lower cards wait until they move to the top
- Ordinary + Pasadena rule sets
- Persistent decision history
- Fixed local signing key for v2.9+ in-place upgrades

See `AUDIT-v2.9.md` for the v2.8 miss analysis and all v2.9 fixes.

Galaxy A15 suggested OCR interval: 70–100 ms. Accessibility fast path does not wait for this interval.
## v2.10.5
- First Accept uses a fresh top-card hot-zone snapshot to cut pre-tap tree-walk latency.
- A vanished Offers card is no longer reported as a successful claim.
- Positive claim confirmation requires Jobs/accepted-assigned UI evidence.
- OCR is restricted to the first-card screen region to reduce latency and preserve strict serial processing.


## v2.10.7
- Fast Ignore/Reject now uses the already-isolated first-card Accessibility rectangle instead of immediately rescanning the full tree.
- Action revalidation tolerates DeliverThat React-Native duplicate/missing descriptive nodes, while still requiring exact amount and miles.
- General verified gesture duration reduced to 18 ms; fast top-card gestures remain 14 ms.


## v2.10.15
Reject/Ignore now uses one process-wide two-attempt arbiter across OCR and Accessibility. Same-card retry state survives transient serial-lock recovery, disabled buttons are not re-clicked, and two unconfirmed attempts end in `REJECT_NOT_CONFIRMED` instead of repeated taps.

## v2.10.23
First real Accept field trace showed that v2.10.22 could successfully claim a job but fail to recognize the resulting assigned-job UI, causing expensive post-claim rescans and stale retries. v2.10.23 adds Delivery Timeline/Dropoff Instructions success evidence, Jobs badge increase confirmation, and a single-owner pending Accept state so only inspectClaim can retry.


## v2.10.31
Accept state-machine hardening: global task epoch invalidation after success, semantic card fingerprint regression coverage, completed-offer stale callback guard, indexed-action/event-evidence direct Accept lane, duplicate OCR suppression, and clearer Reject/Pasadena audit labels. Rule thresholds are unchanged.



## v2.10.33

- Reject OCR / Accessibility now share one process-wide transaction through `RejectSequence`; duplicate frames cannot create a new first attempt.
- Retry #2 requires a fresh continuous-visible streak of the same semantic card after retry grace; one late duplicate frame is insufficient.
- `REJECT_DISAPPEARED` creates a 5s tombstone; `REJECT_CONFIRMED` / `REJECT_LOST` create an 8s tombstone. Same-card RN reappearance is suppressed and logged once as `REJECT_REAPPEARED`.
- Background Reject confirmation records visible/missing observations into the same transaction, so transient blank frames break retry continuity instead of racing a second source.
- Keeps v2.10.31 Accept epoch/fingerprint and v2.10.32 Reject direct-dispatch behavior unchanged. Rule thresholds are unchanged.

## v2.10.32
- Reject dispatch reuses the already-proven action rectangle and first asks Android's semantic text index for the matching live Ignore/Decline/Reject node.
- A same-physical-button match is required before ACTION_CLICK; no rule threshold or card identity semantics changed.
- If the label is blank or the index is transiently unavailable, the existing rectangle-pruned lookup and bounded semantic probe remain fallbacks.
- v2.10.31 Accept epoch/fingerprint protections, async Reject confirmation and Pasadena pickup-city protection are unchanged.


## v2.10.34
- Added Large Order informational-tooltip guard. When the multi-driver explanation covers the offer, the monitor closes X before any Accept/Reject action.
- Tooltip obstruction no longer counts as Reject disappearance; reject confirmation waits for the original card to become readable again.
- Same Chicken Maison Large Order OCR variants now keep one semantic offer identity even when tooltip text changes reading order.
- Existing Accept state machine, Reject transaction logic, Pasadena guard and user rule thresholds are unchanged.

## v2.10.267 恢复版

本版基于可恢复的 v2.10.259 Java 工程，并通过 v2.10.266 APK 核对、恢复首击三触点选项、取消 90 秒历史订单拦截，以及把事件祖先读取移出辅助功能主线程。原始 v2.10.266 工程不可用，未验证其余改动全部等价。

回放在首击前按约 40 ms 保留采样，并记录画面按钮线索、唤醒、索引和本机首次读取数值。采样时间只能限定上屏时间区间。新顶部得到连续两次清晰完整证明后，旧单进入后台观察。出现已接单证据或新的失效提示时，仍按原事务处理其归属。

发布 APK 时同时保存对应版本的源码 ZIP 和 APK，并记录签名摘要。源码 ZIP 保留构建配置、应用源码、资源和测试。升级签名密钥与源码归档分开保管。

## v2.10.268

基于保存的 v2.10.267 恢复工程。无正文的结构变更事件先唤醒扫描，再尝试预读根节点。首次寻找屏幕按钮时，视觉探测的最小间隔为 16 毫秒。当前窗口与按钮的最终核验完成后先发首击，随后保存补击用的同单节点副本。

回放按约 32 毫秒的目标间隔保留首击前和首击后 420 毫秒内的可用画面。记录系统事件时间、应用收到事件的时间、扫描唤醒和启动，以及画面生产时间戳、回调和获取时间。画面生产时间戳单独记录。手势记录包含提交、计划触点间隔、总长和批次回调。每个触点的实际落下时间与服务器收到请求的时间无法从这些记录直接获取。

## v2.10.269

同单已确认转圈后，连续两帧未检测到转圈才开放重新读取。补击必须使用最后一帧转圈之后启动、能证明同一张卡当前 Accept 可用的读取。实际发送前仍会校验窗口、事务、卡片和终态。重试沿用原事务和累计次数。回放用 ACCEPT_SPINNER_CLEARED_SAME_CARD_ENABLED 记录恢复。

空结构变化事件先提交异步根节点预读，再唤醒扫描，让根节点读取可以与扫描入队重叠。共享索引略过重复失效解析和空字段，同卡和按钮校验保留。

### v2.10.279

- 新订单实时扫描队列与旧 Reject 补查队列分离。前台出现新的订单证据或正在响应结构变化时，旧卡补查让路。
- 顶部直接换单时，在 450ms 内抑制旧卡同一指纹及已匹配的缺字段重绘重复 Reject。此保护只作用于 Reject。确认空页时释放原事务，明确的新卡立即按独立事务处理。

### v2.10.280

- 换顶单独记录为 `REJECT_TOP_CHANGED` 并让路当前订单。旧卡回到顶部时保留拒单记录，前台连续两次明确空页后释放。不同订单 ID 或明确不同的配送信息按新卡处理。
- 现有 Reject 快照记录数值证据到首个可用按钮快照、首个到本次按钮快照，以及首个按钮快照到提交的时间。首次点击前证据已失效时立即请求刷新当前顶部，同卡复查间隔缩短至 20 毫秒。首击失败记录也包含这些时间。

### v2.10.281

- Reject 按钮已确认禁用后，后台优先检查 Offers 空页。首次读到空页后的第二次复核直接优先查空页，避免先定位已消失的 Reject 按钮。
- 两次后台空页验证需要来自同一界面代际及窗口。换窗或界面变化时，扫描继续处理活跃顶部卡。

### v2.10.282

- 快速扫描日志记录实际读取的开始、结束、耗时和结果年龄；诊断线程只输出尚未记录的新样本。
- 扫描心跳区分最新扫描与上一次快速读取；读取期间界面变更单独标注。
- 视觉首击回调拆分窗口读取、顶部订单核验和整个首击验证的时间，使用既有读取结果。

### v2.10.283

- 本帧刚确认可用的视觉 Accept 时，先处理首击，再复制同一帧用于回放。回放继续用原始采集时间保留首击前画面。复用本帧已有的转圈检测结果。

### v2.10.284

- 扫描记录包含触发来源、入队等待、阶段耗时和主要退出原因。后台诊断保留最近一次慢扫描，用于定位偶发延迟。
- 视觉 Accept 回调记录画面探测、前台检查、视觉定位、字段准备和规则判断。点击使用同一单调时钟串起规则就绪、派发前核验、Android 接收和回调。格式化使用既有记录流程。
