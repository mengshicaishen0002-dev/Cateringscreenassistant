CateringScreenAssistant v2.10.297 full source ZIP. Based on v2.10.296.
Fixes: no synchronous binder fallback on first-shot index BUSY; three-query parallel idle presence probe; BUSY-specific presence diagnostic.
Does not include keystore; build using existing private GitHub secret and workflow. Android release APK not yet compiled by this package.
