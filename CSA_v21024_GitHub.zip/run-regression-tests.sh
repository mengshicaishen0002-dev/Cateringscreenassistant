#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${TMPDIR:-/tmp}/csa-v29-tests"
rm -rf "$OUT" && mkdir -p "$OUT"
javac -d "$OUT" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionGeometry.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionDispatchPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionStallPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AlertDedupe.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ButtonLabels.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimBudget.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimConfirmation.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimSuccessSignals.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/NumericGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OfferPriority.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PageGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/QuickEvidencePolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSequence.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectConfirmation.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ScanPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/FastSnapshotPolicy.java" \
  "$ROOT/tests"/*.java
for cls in FastSnapshotPolicyTest ActionDispatchPolicyTest ActionStallPolicyTest ActionGeometryTest AlertDedupeTest ButtonLabelsTest CardTextTest ClaimConfirmationTest ClaimSuccessSignalsTest NumericGuardTest OfferFlowTest PageGuardTest QuickEvidencePolicyTest RejectSequenceTest RejectConfirmationTest ScanPolicyTest; do
  java -cp "$OUT" "com.local.cateringscreenassistant.$cls"
done
# v2.10.12 integration invariants from real-device traces.
grep -q '来源=Gesture首击' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q '!current.acceptBounds.isEmpty() && current.acceptEnabled' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'OCR+Accessibility双源确认换顶' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '紧急下一帧确认' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '服务器已明确返回' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '!cards.isEmpty() ? cards.get(0).text' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'recentCachedClaimOutcomeSince' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'ACTION_STALL_RECOVERY' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'claimEpoch.incrementAndGet()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'rescueProbe' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'RejectSequence.shared()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'RejectSequence.shared()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'REJECT_NOT_CONFIRMED' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'card.rejectEnabled' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'rejectTransitionSuppressUntil' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
! grep -q 'rejectSequence.forget(oldId)' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'ActionDispatchPolicy.rejectFallbackGestureDurationMs()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'dispatchRejectHybrid' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'trySemanticActionClick' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'ACTION_CLICK无界面变化' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q '顶部拒绝第%d次动作已发送' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'getQuickTopOfferSnapshot' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'window.getId() == activeWindowId' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'quickDecisionTextComplete' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '快速树' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'stale Accessibility tab hint suppress screen capture' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'ocrProvesOffer' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'visualAccept != null && !visualAccept.isEmpty()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'conflictingOfferEvidence' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'hasMoney && hasMiles && hasLiveAction' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'markProcessing' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'RejectSequence.State.PROCESSING' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'QuickEvidencePolicy.canStop' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'compactWhitespace' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'reserveIfReady' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSequence.java"
grep -q 'rejectSequence.reserveIfReady' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'september|october|november|december' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java"
grep -q 'recentCachedClaimOutcomeSince' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'Jobs徽标' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'Delivery Timeline/Dropoff Instructions' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimSuccessSignals.java"
grep -q 'serialTopActionAt > 0' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'serialTopAction == SerialAction.ACCEPT' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'serialTopAction = SerialAction.REJECT' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'inspectReject' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'REJECT_SUCCESS' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'REJECT_UNKNOWN' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'RejectConfirmation.classify' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
echo "48 v2.10.24 real-device integration invariants passed"
