# v2.10.22 audit — latency-first action dispatch

Field evidence on Galaxy A15 showed a correct Reject path still spending about 328 ms in the bounded Accessibility tree before action. For the user’s main goal (winning qualified offers), the first Accept must not wait behind work that is useful only for diagnostics or rejection.

Changes:

1. Added a semantic Accessibility text-index path for Accept/Claim. It jumps to the visible action label and climbs only a few ancestors to recover the card pay, miles and pickup text. A qualified card can therefore queue the verified 55 ms gesture without walking ~130 React-Native nodes.
2. Added the same indexed path for Ignore/Decline/Reject. It is used only when the indexed Accept card already proves the same physical offer and the RejectSequence arbiter says the card is READY. This accelerates common rejected offers without reintroducing coordinate guessing.
3. High-priority notification/sound work is moved after the claim gesture has been queued. Alerts remain available when no reliable Accept anchor exists, but they no longer sit on the critical pre-tap path.
4. A just-captured Accessibility Accept snapshot no longer repeats a 16-node page-chrome probe before the first gesture. Older snapshots still revalidate. Root package, fresh evidence and strict right-side button geometry remain mandatory.
5. OCR Accept actions use `postAtFrontOfQueue`, and a recent OFFERS page hint skips a redundant page probe. Unknown/stale page states still fall back to bounded verification.
6. Hot page/button label normalization no longer allocates regex machinery per Accessibility node.
7. Existing 55 ms press duration is retained because prior real-device traces showed shorter 12–14 ms gestures were less reliable. This release removes avoidable pre-dispatch latency instead of weakening the physical click.

Regression suite remains green; new FastSnapshotPolicy cases cover the fresh-snapshot page-recheck threshold.
