package com.local.cateringscreenassistant;

public class RejectSequenceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        RejectSequence lease = new RejectSequence();
        String oldLease=lease.bindObservation("$37.00 19.4 mi Porto Bakery",1000L);
        check(lease.reserveFirstIfReady(oldLease,1000L)==1);
        lease.markTransientDeparture(oldLease,1298L);
        String another=lease.bindObservation("$33.00 17.1 mi Porto Bakery",1320L);
        check(lease.reserveFirstIfReady(another,1320L)==1);
        check(lease.reserveFirstIfReady(oldLease,1730L)==0);
        check(!lease.blocksAccept(oldLease,1730L));
        check(lease.reserveFirstIfReady(oldLease,2499L)==0);
        check(lease.reserveFirstIfReady(oldLease,2500L)==1);
        RejectSequence emptyLease = new RejectSequence();
        String emptyId=emptyLease.bindObservation("$37.00 19.4 mi Porto Bakery",1000L);
        check(emptyLease.reserveFirstIfReady(emptyId,1000L)==1);
        emptyLease.markTransientDeparture(emptyId,1298L);
        emptyLease.observeReorderedEmpty(true,8L,1520L,1530L,120L);
        check(emptyLease.reserveFirstIfReady(emptyId,1531L)==0);
        emptyLease.observeReorderedEmpty(true,8L,1650L,1660L,120L);
        check(emptyLease.reserveFirstIfReady(emptyId,1661L)==1);
        RejectSequence reorder = new RejectSequence();
        String sparseA = "$20–30 1.2 mi";
        String a = sparseA + " (~6 mins) Urbane Cafe • 1750 E Gonzales Rd, Oxnard, CA 93030";
        String timedA = sparseA + " (~6 mins) Tomorrow at 11:10 AM, Urbane Cafe • 1750 E Gonzales Rd, Oxnard, CA 93030";
        String first = reorder.bindObservation(timedA, 1000L);
        check(reorder.reserveFirstIfReady(first, 1000L) == 1);
        reorder.markReorderedDeparture(first, 1160L);
        String b = reorder.bindObservation("$28–38 9.2 mi Cafe Rio • 27510 W Lugonia Ave, Redlands, CA 92374", 1161L);
        check(reorder.reserveFirstIfReady(b, 1161L) == 1);
        String redraw = reorder.bindObservation(a, 1325L);
        check(first.equals(redraw));
        reorder.noteVisible(redraw, 1325L);
        check(reorder.reserveFirstIfReady(redraw, 1325L) == 0);
        check(reorder.observe(redraw, 1325L) == RejectSequence.State.TOMBSTONE);
        check(!reorder.blocksAccept(CardText.identity(a), 1325L));
        check(!reorder.blocksAccept(CardText.identity(sparseA), 1325L));
        check(!reorder.bindObservation(timedA.replace("11:10", "11:20"), 1400L).equals(first));
        reorder.noteVisible(redraw, 1765L);
        check(reorder.reserveFirstIfReady(redraw, 1765L) == 0);
        check(reorder.observe(redraw, 1765L) == RejectSequence.State.TOMBSTONE);
        check(reorder.reserveFinalIfFresh(redraw, 1765L) == 0);
        check(reorder.bindObservation(a, 14000L).equals(first));
        check(reorder.reserveFirstIfReady(redraw, 14000L) == 0);
        check(!reorder.blocksAccept(CardText.identity(sparseA), 14000L));
        reorder.observeReorderedEmpty(true, 8L, 14010L, 14025L, 120L);
        check(reorder.reserveFirstIfReady(redraw, 14030L) == 0);
        reorder.invalidateReorderedEmpty();
        reorder.observeReorderedEmpty(true, 8L, 14145L, 14160L, 120L);
        check(reorder.reserveFirstIfReady(redraw, 14161L) == 0);
        reorder.observeReorderedEmpty(true, 9L, 14290L, 14305L, 120L);
        check(reorder.reserveFirstIfReady(redraw, 14306L) == 0);
        reorder.observeReorderedEmpty(true, 9L, 14425L, 14432L, 120L);
        check(!reorder.hasReorderedDepartures());
        check(reorder.reserveFirstIfReady(reorder.bindObservation(a, 14433L), 14433L) == 1);

        RejectSequence orders = new RejectSequence();
        first = orders.bindObservation(timedA + " Order ID: GOP_DT_LSRQ302", 1000L);
        check(orders.reserveFirstIfReady(first, 1000L) == 1);
        orders.markReorderedDeparture(first, 1284L);
        String replacement = orders.bindObservation(timedA + " Order ID: GOP_DT_LSRQ303", 1765L);
        check(!replacement.equals(first));
        check(orders.reserveFirstIfReady(replacement, 1765L) == 1);

        RejectSequence timing = new RejectSequence();
        String timingId = timing.bindObservation(a, 1000L);
        check(timing.noteEnabledSnapshot(timingId, 1000L, 0L) == 0L);
        check(timing.noteEnabledSnapshot(timingId, 1000L, 1430L) == 1430L);
        check(timing.reserveFirstIfReady(timingId, 1432L) == 1);
        timing.failed(timingId, 1433L);
        check(timing.noteEnabledSnapshot(timingId, 1000L, 1680L) == 1430L);
        check(timing.noteEnabledSnapshot(timingId, 2500L, 2540L) == 2540L);

        RejectSequence refresh = new RejectSequence();
        String refreshId = refresh.bindObservation(timedA, 2000L);
        check(refresh.reserveFirstIfReady(refreshId, 2000L) == 1);
        long refreshAt = refresh.failed(refreshId, 2001L, true);
        check(refreshAt == 2021L);
        check(refresh.proofRefreshPending(refreshId, timedA, 2020L));
        check(!refresh.proofRefreshPending(refreshId, timedA.replace("11:10", "11:20"), 2020L));
        check(!refresh.proofRefreshPending(refreshId, timedA.replace("1750", "1752"), 2020L));
        check(!refresh.proofRefreshPending(refreshId, timedA, refreshAt));
        check(refresh.reserveFirstIfReady(refreshId, refreshAt) == 1);

        RejectSequence exclusion = new RejectSequence();
        check(!exclusion.blocksAccept("old", 1000));
        check(exclusion.reserveFirstIfReady("old", 1000) == 1);
        check(exclusion.blocksAccept("old", 1100));
        check(!exclusion.blocksAccept("new", 1100));
        exclusion.markDisappeared("old", 1200);
        check(exclusion.blocksAccept("old", 1300));
        check(!exclusion.blocksAccept("new", 1300));
        check(!exclusion.blocksAccept("old", 20000));
        RejectSequence sequence = new RejectSequence();
        check(sequence.observe("A", 0) == RejectSequence.State.READY);
        check(sequence.reserveIfReady("A", 0) == 1);
        check(sequence.observe("A", 100) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 359) == RejectSequence.State.WAIT);
        // v2.10.61: time alone still never authorizes retry #2, even though the unresolved
        // retry window is shortened to 360ms. Continuous current-card visibility is required.
        check(sequence.observe("A", 360) == RejectSequence.State.WAIT);
        check(sequence.observeVisible("A", 370) == RejectSequence.State.WAIT);
        check(sequence.observeVisible("A", 500) == RejectSequence.State.READY);
        check(sequence.reserveIfReady("A", 500) == 2);
        check(sequence.observe("A", 501) == RejectSequence.State.HOLD);
        check(sequence.markHoldReported("A", 501));
        check(!sequence.markHoldReported("A", 502));

        RejectSequence atomic = new RejectSequence();
        check(atomic.reserveIfReady("RACE", 7000) == 1);
        check(atomic.reserveIfReady("RACE", 7000) == 0);
        atomic.noteVisible("RACE", 7200);
        check(atomic.reserveIfReady("RACE", 7200) == 0); // retry time not reached yet
        atomic.noteVisible("RACE", 7360);
        check(atomic.reserveIfReady("RACE", 7360) == 2);
        check(atomic.reserveIfReady("RACE", 7361) == 0);

        RejectSequence missingBreaksStreak = new RejectSequence();
        check(missingBreaksStreak.reserveIfReady("M", 1000) == 1);
        missingBreaksStreak.noteVisible("M", 2200);
        missingBreaksStreak.noteVisible("M", 2340);
        missingBreaksStreak.noteMissing("M", 2350);
        check(missingBreaksStreak.observe("M", 2351) == RejectSequence.State.WAIT);
        missingBreaksStreak.noteVisible("M", 2400);
        check(missingBreaksStreak.observe("M", 2400) == RejectSequence.State.WAIT);
        missingBreaksStreak.noteVisible("M", 2530);
        check(missingBreaksStreak.observe("M", 2530) == RejectSequence.State.READY);

        RejectSequence processing = new RejectSequence();
        check(processing.reserveIfReady("P", 4000) == 1);
        processing.markProcessing("P", 4200);
        check(processing.observe("P", 5000) == RejectSequence.State.PROCESSING);
        check(processing.observe("P", 11199) == RejectSequence.State.PROCESSING);
        // Once processing hold expires, retry still requires fresh continuous visibility.
        check(processing.observe("P", 11200) == RejectSequence.State.WAIT);
        processing.noteVisible("P", 11210);
        processing.noteVisible("P", 11340);
        check(processing.observe("P", 11340) == RejectSequence.State.READY);
        check(processing.reserveIfReady("P", 11340) == 2);

        RejectSequence disappeared = new RejectSequence();
        check(disappeared.reserveIfReady("D", 10000) == 1);
        disappeared.markDisappeared("D", 10100);
        check(disappeared.observe("D", 10101) == RejectSequence.State.TOMBSTONE);
        check(disappeared.markReappearedReported("D", 10102));
        check(!disappeared.markReappearedReported("D", 10103));
        disappeared.noteVisible("D", 12000);
        check(disappeared.observe("D", 12000) == RejectSequence.State.TOMBSTONE);
        check(disappeared.reserveIfReady("D", 12000) == 0);
        // v2.10.60: departure was independently proven. After tombstone expiry, a real
        // re-publication starts a fresh Reject transaction rather than consuming retry #2.
        disappeared.noteVisible("D", 15110);
        check(disappeared.consumeRearmed("D", 15110));
        check(disappeared.observe("D", 15110) == RejectSequence.State.READY);
        check(disappeared.reserveIfReady("D", 15110) == 1);

        RejectSequence terminal = new RejectSequence();
        check(terminal.reserveIfReady("T", 20000) == 1);
        terminal.markTerminal("T", 20100);
        check(terminal.observe("T", 20101) == RejectSequence.State.TOMBSTONE);
        check(terminal.markReappearedReported("T", 20102));
        check(!terminal.markReappearedReported("T", 20103));
        check(terminal.reserveIfReady("T", 27000) == 0);
        terminal.noteVisible("T", 28110);
        terminal.noteVisible("T", 28240);
        check(terminal.observe("T", 28240) == RejectSequence.State.HOLD);
        check(terminal.reserveIfReady("T", 28240) == 0);

        RejectSequence failed = new RejectSequence();
        check(failed.reserveIfReady("F", 30000) == 1);
        failed.markProcessing("F", 30050);
        failed.failed("F", 30100);
        check(failed.attempts("F", 30100) == 0);
        check(failed.observe("F", 30749) == RejectSequence.State.WAIT);
        check(failed.observe("F", 30750) == RejectSequence.State.READY);
        check(failed.reserveFirstIfReady("F", 30800) == 1);
        failed.failed("F", 30801, true);
        check(failed.attempts("F", 30801) == 0);
        check(failed.reserveFirstIfReady("F", 30820) == 0);
        check(failed.reserveFirstIfReady("F", 30821) == 1);

        RejectSequence sent = new RejectSequence();
        check(sent.sent("S", 40000) == 1);
        check(sent.sent("S", 41100) == 0); // no continuous visible proof
        sent.noteVisible("S", 40370);
        sent.noteVisible("S", 40500);
        check(sent.sent("S", 40500) == 2);

        RejectSequence finalRescue = new RejectSequence();
        check(finalRescue.reserveIfReady("FINAL", 60000) == 1);
        check(finalRescue.reserveFinalIfFresh("FINAL", 60359) == 0);
        check(finalRescue.reserveFinalIfFresh("FINAL", 60360) == 2);
        check(finalRescue.reserveFinalIfFresh("FINAL", 60720) == 0);

        RejectSequence foregroundOnly = new RejectSequence();
        check(foregroundOnly.reserveFirstIfReady("FOREGROUND", 61000) == 1);
        foregroundOnly.noteVisible("FOREGROUND", 61360);
        foregroundOnly.noteVisible("FOREGROUND", 61490);
        check(foregroundOnly.reserveFirstIfReady("FOREGROUND", 61490) == 0);
        check(foregroundOnly.reserveFinalIfFresh("FOREGROUND", 61490) == 2);

        RejectSequence shared1 = RejectSequence.shared();
        RejectSequence shared2 = RejectSequence.shared();
        shared1.forget("SHARED");
        check(shared1.reserveIfReady("SHARED", 50000) == 1);
        check(shared2.observe("SHARED", 50001) == RejectSequence.State.WAIT);
        check(shared2.reserveIfReady("SHARED", 50001) == 0);
        shared2.forget("SHARED");


        RejectSequence rearm = new RejectSequence();
        check(rearm.reserveIfReady("REARM", 70000) == 1);
        rearm.markDisappeared("REARM", 70100); // different coherent top proved departure
        rearm.noteVisible("REARM", 75200);     // tombstone expired; genuine republish
        check(rearm.consumeRearmed("REARM", 75200));
        check(rearm.observe("REARM", 75200) == RejectSequence.State.READY);
        check(rearm.reserveIfReady("REARM", 75200) == 1); // new transaction, not retry #2

        RejectSequence dispatchLease = new RejectSequence();
        check(dispatchLease.reserveFirstIfReady("LEASE", 80000) == 1);
        check(!dispatchLease.forgetIfNoDispatchOwnership("LEASE", 80050));
        check(dispatchLease.attempts("LEASE", 80051) == 1);
        check(dispatchLease.reserveFirstIfReady("LEASE", 80051) == 0);
        check(dispatchLease.observe("LEASE", 80052) == RejectSequence.State.TOMBSTONE);
        check(dispatchLease.forgetIfNoDispatchOwnership("LEASE", 81500));
        check(dispatchLease.observe("LEASE", 81501) == RejectSequence.State.READY);

        // v2.10.110: a post-Reject numeric-only redraw must inherit the recent full offer's
        // transaction. A complete next offer with the same numbers must remain immediately free.
        RejectSequence sparseAlias = new RejectSequence();
        String full = "pay=30.00|mi=4.6|time=tomorrow-9:30am|merchant=mendocino farms";
        String sparse = "pay=30.00|mi=4.6|time=|merchant=";
        String completeNext = "pay=30.00|mi=4.6|time=tomorrow-9:35am|merchant=urbane cafe";
        check(sparseAlias.reserveFirstIfReady(full, 90000) == 1);
        sparseAlias.markDisappeared(full, 90100);
        check(full.equals(sparseAlias.sparseAliasOwner(sparse, 92000)));
        check(sparseAlias.reserveFirstIfReady(sparse, 92000) == 0);
        check(sparseAlias.markSparseAliasReported(sparse, 92001));
        check(!sparseAlias.markSparseAliasReported(sparse, 92002));
        check(sparseAlias.reserveFirstIfReady(completeNext, 92003) == 1);
        check(sparseAlias.sparseAliasOwner(sparse, 100004).isEmpty());
        check(sparseAlias.reserveFirstIfReady(sparse, 100004) == 1);

        sequence.forget("A");
        check(sequence.observe("A", 60000) == RejectSequence.State.READY);
        RejectSequence expired = new RejectSequence();
        check(expired.reserveFirstIfReady("EXPIRED", 1000) == 1);
        expired.noteVisible("EXPIRED", 10999);
        check(expired.reserveFirstIfReady("EXPIRED", 11000) == 1);

        RejectSequence stalled = new RejectSequence();
        check(stalled.reserveFirstIfReady("STALLED", 1000) == 1);
        check(stalled.reserveFinalIfFresh("STALLED", 1400) == 2);
        check(!stalled.recoverStalledVisible("STALLED", 10000)); // time alone is insufficient
        stalled.noteVisible("STALLED", 10010);
        check(!stalled.recoverStalledVisible("STALLED", 10010));
        stalled.noteVisible("STALLED", 10140);
        check(stalled.recoverStalledVisible("STALLED", 10140));
        check(!stalled.recoverStalledVisible("STALLED", 10140));
        check(stalled.reserveFirstIfReady("STALLED", 10140) == 1);
        check(stalled.reserveFirstIfReady("STALLED", 10140) == 0);

        RejectSequence terminalStall = new RejectSequence();
        terminalStall.reserveFirstIfReady("TERMINAL", 1000);
        terminalStall.markTerminal("TERMINAL", 1200);
        terminalStall.noteVisible("TERMINAL", 9000);
        terminalStall.noteVisible("TERMINAL", 9130);
        check(!terminalStall.recoverStalledVisible("TERMINAL", 9199));
        check(terminalStall.recoverStalledVisible("TERMINAL", 9200));
        check(terminalStall.reserveFirstIfReady("TERMINAL", 9200) == 1);

        RejectSequence processingStall = new RejectSequence();
        processingStall.reserveFirstIfReady("PROCESSING", 1000);
        processingStall.noteVisible("PROCESSING", 9000);
        processingStall.noteVisible("PROCESSING", 9130);
        processingStall.markProcessing("PROCESSING", 9140);
        check(!processingStall.recoverStalledVisible("PROCESSING", 10000));
        check(!processingStall.recoverStalledVisible("PROCESSING", 500));

        String bare = "$52–62 Est. 19.4 mi (~29 mins) Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040, United States Large Order";
        String rich = bare.replace("Porto's Bakery", "Tomorrow at 9:25 AM, Porto's Bakery");
        RejectSequence aliases = new RejectSequence();
        String owner = aliases.bindObservation(bare, 1000);
        check(aliases.reserveFirstIfReady(owner, 1000) == 1);
        String alias = aliases.bindObservation(rich, 1001);
        check(owner.equals(alias));
        check(aliases.reserveFirstIfReady(alias, 1001) == 0);
        check(aliases.attempts(CardText.identity(rich), 1001) == 1);
        check(aliases.blocksAccept(CardText.identity(rich), 1001));
        check(!aliases.bindObservation(rich.replace("9:25", "10:25"), 1002).equals(owner));
        check(!aliases.bindObservation(rich.replace("6100", "6101"), 1002).equals(owner));
        check(!RejectConfirmPriorityPolicy.shouldDeferForNewTop(bare, rich));
        check(RejectConfirmPriorityPolicy.shouldDeferForNewTop(rich, rich.replace("9:25", "10:25")));
        aliases.markDisappeared(owner, 1100);
        check(aliases.observe(CardText.identity(rich), 1101) == RejectSequence.State.TOMBSTONE);
        aliases.forget(owner);
        check(aliases.attempts(CardText.identity(rich), 1102) == 0);
        RejectSequence reverse = new RejectSequence();
        owner = reverse.bindObservation(rich, 1000);
        check(reverse.reserveFirstIfReady(owner, 1000) == 1);
        check(reverse.bindObservation(bare, 1001).equals(owner));
        check(reverse.reserveFirstIfReady(CardText.identity(bare), 1001) == 0);
        // v305: OCR formatting and added pickup text must not create a second budget.
        String indexed = "$30–40 3 mi (~10 mins) Mendocino Farms • 23870 Aliso Creek Rd Suite C, Laguna Niguel, CA 92677, United States";
        String ocr = "Est. $30.00-40 O 3.0 mi (~10 mins) Tomorrow at 11:20 AM Mendocino Farms • 23870 Aliso Creek Rd Suite C, Laguna Niguel, CA 92677, United States";
        RejectSequence crossFormat = new RejectSequence();
        String indexedOwner = crossFormat.bindObservation(indexed, 1000L);
        check(crossFormat.reserveFirstIfReady(indexedOwner, 1000L) == 1);
        check(crossFormat.bindObservation(ocr, 1001L).equals(indexedOwner));
        check(crossFormat.reserveFirstIfReady(crossFormat.bindObservation(ocr, 1002L), 1002L) == 0);
        check(!crossFormat.bindObservation(ocr.replace("11:20", "11:30"), 1003L).equals(indexedOwner));
        check(!crossFormat.bindObservation(ocr.replace("23870", "23871"), 1004L).equals(indexedOwner));
        check(!crossFormat.bindObservation(ocr.replace("30.00", "31.00"), 1005L).equals(indexedOwner));
        // v306: replay the actual cross-source Chicken Maison pair and lease timing.
        String chicken="$59.12 3.2 mi (~13 mins) Chicken Maison • 4025 W El Segundo Blvd, Hawthorne, CA 90250, United States";
        String chickenOcr="Est. $59.12 O 3.2 mi (-13 mins) Tomorrow at 11:00 AM Chicken Maison • 4025 WEI Segundo Blvd, Hawthorne, CA 90250, United States";
        RejectSequence spinnerRedraw=new RejectSequence();
        String chickenOwner=spinnerRedraw.bindObservation(chicken,10000);
        check(spinnerRedraw.reserveFirstIfReady(chickenOwner,10000)==1);
        spinnerRedraw.markSpinnerAcknowledged(chickenOwner,10314);
        check(spinnerRedraw.acknowledgedRedraw(chickenOcr,11634));
        check(spinnerRedraw.bindObservation(chickenOcr,11634).equals(chickenOwner));
        check(spinnerRedraw.reserveFirstIfReady(chickenOwner,11634)==0);
        check(!spinnerRedraw.acknowledgedRedraw(chickenOcr.replace("4025","4026"),11635));
        check(!spinnerRedraw.acknowledgedRedraw(chickenOcr.replace("90250","90251"),11635));
        check(!spinnerRedraw.acknowledgedRedraw(chickenOcr.replace("11:00","11:05"),11635));
        check(!spinnerRedraw.acknowledgedRedraw(chickenOcr.replace("59.12","59.13"),11635));
        check(!spinnerRedraw.acknowledgedRedraw(chickenOcr.replace("Chicken Maison","Luna Grill"),11635));
        check(!OfferEnrichmentPolicy.sameTransaction(chicken,chickenOcr)); // strict live proof unchanged
        check(!spinnerRedraw.acknowledgedRedraw(chickenOcr,12500));
        check(spinnerRedraw.reserveFirstIfReady(spinnerRedraw.bindObservation(chickenOcr,12500),12500)==1);
        RejectSequence earlyEmpty=new RejectSequence();
        String earlyOwner=earlyEmpty.bindObservation(chicken,10000);
        check(earlyEmpty.reserveFirstIfReady(earlyOwner,10000)==1);
        earlyEmpty.markSpinnerAcknowledged(earlyOwner,10314);
        earlyEmpty.observeReorderedEmpty(true,1,10600,10610,120);
        earlyEmpty.observeReorderedEmpty(true,1,10740,10750,120);
        check(!earlyEmpty.acknowledgedRedraw(chickenOcr,10751));
        // v308: same displayed card reorders without a spinner, then returns just
        // after the old 1500ms dispatch window. Never create a duplicate first action.
        String porto="$26–36 2.4 mi (~9 mins) Porto's Bakery • 6100 S Malt Ave, Commerce, CA 90040, United States";
        RejectSequence topReorder = new RejectSequence();
        String portoId = topReorder.bindObservation(porto, 10000);
        check(topReorder.reserveFirstIfReady(portoId, 10000)==1);
        topReorder.markTransientDeparture(portoId, 10242);
        check(topReorder.reserveFirstIfReady(topReorder.bindObservation(porto,11513),11513)==0);
        check(topReorder.reserveFirstIfReady(topReorder.bindObservation(porto,11617),11617)==0);
        check(!topReorder.blocksAccept(portoId,11617));
        check(topReorder.reserveFinalIfFresh(portoId,11617)==0);
        String distinct = topReorder.bindObservation(porto.replace("2.4 mi", "2.5 mi"),11618);
        check(!distinct.equals(portoId) && topReorder.reserveFirstIfReady(distinct,11618)==1);
        String distinctStreet = topReorder.bindObservation(porto.replace("6100", "6101"),11619);
        check(!distinctStreet.equals(portoId) && topReorder.reserveFirstIfReady(distinctStreet,11619)==1);
        check(topReorder.reserveFirstIfReady(topReorder.bindObservation(porto,12499),12499)==0);
        check(topReorder.reserveFirstIfReady(topReorder.bindObservation(porto,12500),12500)==1);
        RejectSequence emptyReorder = new RejectSequence();
        String emptyReorderId = emptyReorder.bindObservation(porto,10000);
        check(emptyReorder.reserveFirstIfReady(emptyReorderId,10000)==1);
        emptyReorder.markTransientDeparture(emptyReorderId,10242);
        emptyReorder.observeReorderedEmpty(true,4,10500,10510,120);
        check(emptyReorder.reserveFirstIfReady(emptyReorderId,10511)==0);
        emptyReorder.observeReorderedEmpty(true,4,10640,10650,120);
        check(!emptyReorder.hasReorderedDepartures());
        check(emptyReorder.reserveFirstIfReady(emptyReorder.bindObservation(porto,10651),10651)==1);
        RejectSequence expiredReorder = new RejectSequence();
        String expiringId = expiredReorder.bindObservation(porto,10000);
        check(expiredReorder.reserveFirstIfReady(expiringId,10000)==1);
        expiredReorder.markTransientDeparture(expiringId,10242);
        check(expiredReorder.hasReorderedDepartures(12499));
        check(!expiredReorder.hasReorderedDepartures(12500));
        check(!expiredReorder.hasReorderedDepartures());
        // Two lanes bind and reserve independently; synchronization must still yield one action.
        RejectSequence raced = new RejectSequence();
        java.util.concurrent.atomic.AtomicInteger sends = new java.util.concurrent.atomic.AtomicInteger();
        Thread[] lanes = new Thread[20];
        for (int k = 0; k < lanes.length; k++) {
            final String text = k % 2 == 0 ? bare : rich;
            lanes[k] = new Thread(() -> {
                String id = raced.bindObservation(text, 1000);
                if (raced.reserveFirstIfReady(id, 1000) == 1) sends.incrementAndGet();
            });
            lanes[k].start();
        }
        for (Thread lane : lanes) try { lane.join(); } catch (InterruptedException e) { throw new AssertionError(e); }
        check(sends.get() == 1);
        System.out.println("Reject sequence and 15 enrichment/concurrency checks passed");
    }
}
