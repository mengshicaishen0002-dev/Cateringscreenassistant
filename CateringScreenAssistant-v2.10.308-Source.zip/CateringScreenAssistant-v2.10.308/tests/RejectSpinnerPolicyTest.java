package com.local.cateringscreenassistant;

public final class RejectSpinnerPolicyTest {
    private static void check(boolean v,String why) {if(!v) throw new AssertionError(why);}
    private static int[][] frame(int radius, int start) {
        int[][] pixels=new int[64][180];
        for(int y=0;y<64;y++)for(int x=0;x<180;x++) pixels[y][x]=0xeeeeee;
        for(int i=0;i<5;i++) {
            double theta=(start+i)*Math.PI/8;
            int x=90+(int)Math.round(radius*Math.cos(theta));
            int y=32+(int)Math.round(radius*Math.sin(theta));
            pixels[y][x]=0x222222;
        }
        return pixels;
    }
    private static int mask(int[][] pixels) {
        return RejectSpinnerPolicy.arcMask(4,2,176,62,(x,y)->pixels[y][x]);
    }
    public static void main(String[] args) {
        int[][] solid=frame(0,0);
        for(int y=0;y<64;y++)for(int x=0;x<180;x++)solid[y][x]=0xeeeeee;
        check(mask(solid)==0,"unmodified Reject surface is not a spinner");
        AcceptSpinnerPolicy.Tracker t=new AcceptSpinnerPolicy.Tracker();
        int first=mask(frame(15,0)),second=mask(frame(15,4));
        check(first!=0 && second!=0 && first!=second,"neutral background rotating arc detected");
        check(!t.observe(77,100,first),"first frame is only a candidate");
        check(t.observe(77,120,second),"second rotated frame confirms Reject spinner");
        check(t.firstObservationAt()==100,"first candidate timestamp retained");
        check(!t.observe(78,140,first),"new transaction cannot reuse older frame");
        check(t.firstObservationAt()==140,"new action has a fresh candidate timestamp");
        t.reset();check(!t.observe(77,100,first),"reset clears old spinner");
        System.out.println("Reject Spinner rotating-frame tests passed");
    }
}
