package com.local.cateringscreenassistant;

/** Detect a centered loading arc, rather than treating a missing/disabled node as a spinner. */
final class AcceptSpinnerPolicy {
    interface Pixels { int color(int x,int y); }
    private static int difference(int a,int b) {
        return Math.max(Math.abs((a>>16&255)-(b>>16&255)),
                Math.max(Math.abs((a>>8&255)-(b>>8&255)),Math.abs((a&255)-(b&255))));
    }
    private static final int[] RADII_PERCENT = {16,23,30,37,44};
    private static final double[] COS = new double[16], SIN = new double[16];
    static {
        for (int sector=0;sector<16;sector++) {
            double angle=sector*Math.PI/8;
            COS[sector]=Math.cos(angle);
            SIN[sector]=Math.sin(angle);
        }
    }

    static int arcMask(int left,int top,int right,int bottom,Pixels p) {
        int w=right-left,h=bottom-top,cx=(left+right)/2,cy=(top+bottom)/2;
        if(w<40 || h<20) return 0;
        int bg=p.color(cx,cy);
        int red=bg>>16&255, green=bg>>8&255, blue=bg&255;
        if(blue-red<55 || blue<75 || green<45) return 0;
        // A spinner leaves the hollow center and the sides of the button clear.
        for(int dx=-2;dx<=2;dx+=2) for(int dy=-2;dy<=2;dy+=2)
            if(difference(bg,p.color(cx+dx,cy+dy))>40) return 0;
        int outside=0;
        for(int y=-2;y<=2;y++) for(int side=-1;side<=1;side+=2)
            if(difference(bg,p.color(cx+side*w/3,cy+y*Math.max(1,h/10)))>60 && ++outside>1)
                return 0;
        int strongest=0, strongestCount=0;
        for(int percent:RADII_PERCENT) {
            int radius=Math.max(3,h*percent/100);int mask=0;
            for(int i=0;i<16;i++) {
                for(int dr=-1;dr<=1;dr++) {
                    int x=cx+(int)Math.round((radius+dr)*COS[i]);
                    int y=cy+(int)Math.round((radius+dr)*SIN[i]);
                    int color=p.color(x,y);
                    if((color>>16&255)-red>55 && difference(bg,color)>65) {mask|=1<<i;break;}
                }
            }
            int count=Integer.bitCount(mask);
            // A single sector is provisional. Rotation across distinct frames confirms loading.
            if(count>strongestCount && count<=14) {
                strongestCount=count;
                strongest=mask;
            }
        }
        return strongest;
    }
    static boolean ring(int left,int top,int right,int bottom,Pixels p) {
        return arcMask(left,top,right,bottom,p)!=0;
    }
    static final class Tracker {
        private long owner,first,last;
        private int count,previousMask;
        synchronized void reset(){owner=first=last=0;count=previousMask=0;}
        synchronized long firstObservationAt(){return first;}
        synchronized boolean observe(long tx,long now,int mask) {
            if(tx<=0 || now<last || tx!=owner || now-last>150 || (count>0 && now-first>150)) {reset();owner=tx;}
            if(mask==0) {first=0;count=0;previousMask=0;last=now;return false;}
            if(count==0) first=now;
            if(now>last || count==0) count++;
            boolean rotated=previousMask!=0 && previousMask!=mask
                    && Integer.bitCount(previousMask|mask)>=3;
            previousMask=mask;last=now;
            return rotated && count>=2 && now-first>=12 && now-first<=150;
        }
    }
    private AcceptSpinnerPolicy(){}
}
