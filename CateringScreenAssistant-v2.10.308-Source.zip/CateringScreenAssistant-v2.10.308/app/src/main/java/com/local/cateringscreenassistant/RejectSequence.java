package com.local.cateringscreenassistant;

/**
 * Process-wide per-offer Reject/Ignore arbiter. OCR and Accessibility must share the
 * same transaction; otherwise the same first card can be clicked once by each path.
 *
 * v2.10.33 adds two safety properties from real-device traces:
 *  1) a short terminal tombstone after a card disappears/finishes, so a transient RN
 *     reappearance cannot start a brand-new "attempt #1";
 *  2) retry #2 is allowed only after the same logical card has been observed visibly
 *     and continuously after attempt #1. A single late frame is not enough.
 */
final class RejectSequence {
    enum State { READY, WAIT, PROCESSING, TOMBSTONE, HOLD }

    private static final long RETRY_MS = 360L;
    private static final long FAILED_RETRY_MS = 650L;
    private static final long STALE_PROOF_REFRESH_MS = 20L;
    // A reservation owns the physical dispatch until Android's async callback has had ample
    // time to return.  Top-card retirement must not erase attempt #1 inside this window or a
    // concurrent OCR/Accessibility lane can recreate and dispatch another "first" attempt.
    private static final long DISPATCH_OWNERSHIP_MS = 1500L;
    // Bounded post-ack redraw ownership: spinner is not server departure. Only
    // a strongly identified card qualifies; coherent empty reads release earlier.
    private static final long SPINNER_REDRAW_MS = 2500L;
    private static final long TOP_REORDER_REDRAW_MS = 2500L;
    private static final long PROCESSING_HOLD_MS = 7000L;
    private static final long DISAPPEARED_TOMBSTONE_MS = 5000L;
    private static final long TERMINAL_TOMBSTONE_MS = 8000L;
    private static final long VISIBLE_GAP_RESET_MS = 650L;
    private static final long MIN_RETRY_VISIBLE_STREAK_MS = 120L;
    private static final long RECENT_VISIBLE_MS = 500L;
    // After Reject, React Native can briefly redraw the same card with only pay+miles.
    // The semantic fingerprint then changes even though the physical offer did not. Block only
    // that sparse alias for a short period; a complete new card is never delayed by this guard.
    private static final long SPARSE_ALIAS_BLOCK_MS = 8000L;
    private static final long EMPTY_AFTER_REORDER_MS = 220L;
    private static final long ENTRY_TTL_MS = 10_000L;
    private static final RejectSequence SHARED = new RejectSequence();

    static RejectSequence shared() { return SHARED; }

    private final java.util.LinkedHashMap<String, Entry> entries = new java.util.LinkedHashMap<>();
    private volatile boolean hasReorderedDepartures;
    private volatile long emptyObservedAt;
    private long emptyReadStartedAt;
    private long emptyGeneration;

    private static final class Entry {
        String canonicalId = "", observedText = "", endpoint = "", pickup = "", orderId = "";
        int attempts;
        long retryAfter;
        long proofRefreshUntil;
        long processingUntil;
        long tombstoneUntil;
        long lastTouched;
        long lastDispatchAt;
        long dispatchOwnershipUntil;
        long visibleSince;
        long lastVisibleAt;
        int visibleSamples;
        boolean holdReported;
        boolean reappearedReported;
        boolean departureProven;
        long reorderedAt;
        long transientReorderExpiresAt;
        long firstEnabledSnapshotAt;
        long lastEnabledSnapshotAt;
        boolean rearmedPending;
        boolean sparseAliasReported;
        boolean spinnerAcknowledged;
    }

    private void purgeExpired(long now) {
        java.util.Iterator<java.util.Map.Entry<String, Entry>> it = entries.entrySet().iterator();
        boolean reordered = false;
        while (it.hasNext()) {
            Entry e = it.next().getValue();
            long anchor = e.lastDispatchAt > 0L ? e.lastDispatchAt : e.lastTouched;
            if ((e.transientReorderExpiresAt > 0L && now >= e.transientReorderExpiresAt)
                    || (e.reorderedAt == 0L && anchor > 0L && now >= anchor && now - anchor >= ENTRY_TTL_MS)) {
                it.remove();
            } else if (e.reorderedAt > 0L) {
                reordered = true;
            }
        }
        // Update the fast-path flag in the same pass instead of traversing the map twice.
        hasReorderedDepartures = reordered;
        if (!reordered) emptyObservedAt = 0L;
    }

    /** Top replacement is not proof of departure. Retain a bounded, full-identity
     * redraw lease anchored to the original dispatch; do not extend on every observation. */
    synchronized void markTransientDeparture(String current, long now) {
        Entry value = entries.get(current);
        if (value == null || value.attempts == 0) return;
        if (value.dispatchOwnershipUntil <= now) { forget(current); return; }
        if (value.lastDispatchAt > 0L && now >= value.lastDispatchAt
                && strongRedrawIdentity(value)) {
            value.dispatchOwnershipUntil = Math.max(value.dispatchOwnershipUntil,
                    value.lastDispatchAt + TOP_REORDER_REDRAW_MS);
        }
        markReorderedDeparture(current, now);
        if (value.reorderedAt > 0L) value.transientReorderExpiresAt = value.dispatchOwnershipUntil;
    }

    private static boolean strongRedrawIdentity(Entry value) {
        return !value.endpoint.isEmpty() && !value.observedText.isEmpty()
                && CardText.amount(value.observedText) >= 0f && CardText.miles(value.observedText) >= 0f
                && !CardText.containsConflictingOfferNumbers(value.observedText)
                && !CardText.containsConflictingPickupEvidence(value.observedText)
                && !OfferEnrichmentPolicy.containsConflictingAddresses(value.observedText);
    }

    synchronized void markSpinnerAcknowledged(String current, long now) {
        Entry value=entries.get(current);
        if (value==null || value.attempts==0) return;
        if (value.lastDispatchAt<=0L || now<value.lastDispatchAt || now>=value.dispatchOwnershipUntil) {
            markTransientDeparture(current,now);
            return;
        }
        if (strongRedrawIdentity(value)) {
            value.spinnerAcknowledged=true;
            value.dispatchOwnershipUntil=Math.max(value.dispatchOwnershipUntil,
                    value.lastDispatchAt+SPINNER_REDRAW_MS);
        }
        markTransientDeparture(current,now);
    }

    /** Read-only coalescing, not authority to tap. A new endpoint/time/ID bypasses it. */
    synchronized boolean acknowledgedRedraw(String text,long now) {
        if (!hasReorderedDepartures) return false;
        purgeExpired(now);
        String endpoint=OfferEnrichmentPolicy.rejectEndpointKey(text);
        if (endpoint.isEmpty() || CardText.containsConflictingOfferNumbers(text)
                || CardText.containsConflictingPickupEvidence(text)
                || OfferEnrichmentPolicy.containsConflictingAddresses(text)) return false;
        String pickup=OfferEnrichmentPolicy.pickupKey(text), order=CardText.orderId(text);
        Entry owner=null;
        for (Entry value:entries.values()) {
            if (!value.spinnerAcknowledged || now>=value.dispatchOwnershipUntil
                    || !endpoint.equals(value.endpoint) || !sameAliasNumbers(text,value.observedText)
                    || (!pickup.isEmpty() && !value.pickup.isEmpty() && !pickup.equals(value.pickup))
                    || (!order.isEmpty() && !value.orderId.isEmpty() && !order.equals(value.orderId))) continue;
            if (owner!=null && owner!=value) return false;
            owner=value;
        }
        return owner!=null;
    }

    private Entry entry(String identity, long now) {
        purgeExpired(now);
        Entry value = entries.get(identity);
        if (value == null) {
            makeRoomForIdentity();
            value = new Entry();
            entries.put(identity, value);
        }
        value.lastTouched = now;
        return value;
    }

    /** Suppression only: bind missing-field redraws before any foreground reservation. */
    synchronized String bindObservation(String text, long now) {
        purgeExpired(now);
        String id = CardText.identity(text);
        String endpoint = OfferEnrichmentPolicy.rejectEndpointKey(text);
        String pickup = OfferEnrichmentPolicy.pickupKey(text);
        String order = CardText.orderId(text);
        Entry exact = entries.get(id);
        // CardText's display fingerprint omits street/order id. Do not merge such collisions.
        if (exact != null && ((!endpoint.isEmpty() && !exact.endpoint.isEmpty() && !endpoint.equals(exact.endpoint))
                || (!order.isEmpty() && !exact.orderId.isEmpty() && !order.equals(exact.orderId))
                || (!pickup.isEmpty() && !exact.pickup.isEmpty() && !pickup.equals(exact.pickup)))) {
            id += "|endpoint=" + endpoint + "|order=" + order + "|pickup=" + pickup;
            exact = entries.get(id);
        }
        if (exact != null) { enrich(exact, id, text); return exact.canonicalId; }
        Entry owner = null;
        if (!endpoint.isEmpty() && !CardText.containsConflictingOfferNumbers(text)
                && !CardText.containsConflictingPickupEvidence(text)
                && !OfferEnrichmentPolicy.containsConflictingAddresses(text)) {
            for (Entry value : entries.values()) {
                if (value.observedText.isEmpty() || !endpoint.equals(value.endpoint)
                        || !sameAliasNumbers(text, value.observedText)
                        || (!pickup.isEmpty() && !value.pickup.isEmpty() && !pickup.equals(value.pickup))
                        || (!order.isEmpty() && !value.orderId.isEmpty() && !order.equals(value.orderId))) continue;
                // Ambiguous partial observations must not join two distinct complete orders.
                if (owner != null && owner != value) return id;
                owner = value;
            }
        }
        if (owner == null) owner = entry(id, now);
        else {
            makeRoomForIdentity();
            entries.put(id, owner);
        }
        enrich(owner, id, text);
        owner.lastTouched = now;
        return owner.canonicalId;
    }

    private static boolean sameAliasNumbers(String left, String right) {
        float a = CardText.amount(left), b = CardText.amount(right);
        float x = CardText.miles(left), y = CardText.miles(right);
        return a >= 0f && b >= 0f && x >= 0f && y >= 0f
                && !CardText.containsConflictingOfferNumbers(right)
                && Math.round(a*100f) == Math.round(b*100f)
                && Math.abs(x-y) < 0.0001f;
    }

    private void makeRoomForIdentity() {
        if (entries.size() < 100) return;
        java.util.Iterator<java.util.Map.Entry<String,Entry>> it = entries.entrySet().iterator();
        while (it.hasNext()) {
            if (it.next().getValue().attempts == 0) {
                it.remove();
                return;
            }
        }
        entries.remove(entries.keySet().iterator().next());
    }

    private void enrich(Entry value, String id, String text) {
        if (value.canonicalId.isEmpty()) value.canonicalId = id;
        if (value.observedText.isEmpty()) value.observedText = text;
        String endpoint = OfferEnrichmentPolicy.rejectEndpointKey(text);
        String pickup = OfferEnrichmentPolicy.pickupKey(text);
        String order = CardText.orderId(text);
        if (!endpoint.isEmpty()) value.endpoint = endpoint;
        if (!pickup.isEmpty()) value.pickup = pickup;
        if (!order.isEmpty()) value.orderId = order;
    }

    private static boolean sparseIdentity(String identity) {
        return identity != null && identity.startsWith("pay=")
                && identity.endsWith("|time=|merchant=");
    }

    private static String numericPrefix(String identity) {
        if (identity == null || !identity.startsWith("pay=")) return "";
        int time = identity.indexOf("|time=");
        if (time <= 0) return "";
        String prefix = identity.substring(0, time);
        return prefix.contains("|mi=") ? prefix : "";
    }

    /**
     * Return the recent full Reject identity that owns this sparse pay+miles redraw.
     * Complete cards are deliberately excluded so a genuine next offer is never coalesced.
     */
    synchronized String sparseAliasOwner(String current, long now) {
        return sparseAliasOwner(current, now, false);
    }

    private String sparseAliasOwner(String current, long now, boolean acceptCheck) {
        if (!sparseIdentity(current)) return "";
        String numeric = numericPrefix(current);
        if (numeric.isEmpty()) return "";
        for (java.util.Map.Entry<String, Entry> item : entries.entrySet()) {
            String candidate = item.getKey();
            Entry value = item.getValue();
            if (candidate.equals(current) || sparseIdentity(candidate)
                    || value.attempts <= 0 || value.lastDispatchAt <= 0
                    || now < value.lastDispatchAt) continue;
            if (value.reorderedAt > 0L ? acceptCheck : now - value.lastDispatchAt > SPARSE_ALIAS_BLOCK_MS)
                continue;
            if (numeric.equals(numericPrefix(candidate))) return candidate;
        }
        return "";
    }

    synchronized boolean markSparseAliasReported(String current, long now) {
        if (sparseAliasOwner(current, now).isEmpty()) return false;
        Entry value = entry(current, now);
        if (value.sparseAliasReported) return false;
        value.sparseAliasReported = true;
        return true;
    }

    /** Record that this exact logical offer is currently readable/visible. */
    synchronized void noteVisible(String current, long now) {
        Entry value = entry(current, now);
        if (value.reorderedAt > 0L) return;
        // For ordinary disappearance tombstones, preserve the existing re-publication path.
        if (value.attempts > 0 && value.departureProven && now >= value.tombstoneUntil) {
            value.attempts = 0;
            value.retryAfter = 0;
            value.processingUntil = 0;
            value.tombstoneUntil = 0;
            value.visibleSince = 0;
            value.lastVisibleAt = 0;
            value.visibleSamples = 0;
            value.holdReported = false;
            value.reappearedReported = false;
            value.departureProven = false;
            value.rearmedPending = true;
            return;
        }
        if (value.attempts <= 0) return;
        if (value.lastVisibleAt <= 0 || now < value.lastVisibleAt
                || now - value.lastVisibleAt > VISIBLE_GAP_RESET_MS) {
            value.visibleSince = now;
            value.visibleSamples = 1;
        } else {
            value.visibleSamples++;
        }
        value.lastVisibleAt = now;
    }

    /** A confirmation probe failed to find the old card: break the continuous-visible streak. */
    synchronized void noteMissing(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts <= 0) return;
        value.visibleSince = 0;
        value.lastVisibleAt = 0;
        value.visibleSamples = 0;
    }

    private static boolean tombstoned(Entry entry, long now) {
        return entry.reorderedAt > 0L || now < entry.tombstoneUntil;
    }

    synchronized State observe(String current, long now) {
        Entry value = entry(current, now);
        if (tombstoned(value, now)) return State.TOMBSTONE;
        if (value.attempts >= 2) return State.HOLD;
        if (now < value.processingUntil) return State.PROCESSING;
        if (now < value.retryAfter) return State.WAIT;
        if (value.attempts == 1 && !retryVisibilityReady(value, now)) return State.WAIT;
        return State.READY;
    }

    /**
     * v2.10.61: a coherent CURRENT top-card snapshot is itself visibility evidence.
     * Fast Accessibility paths use this atomic helper before gating retry #2; otherwise
     * they could keep returning WAIT forever while simultaneously suppressing OCR.
     */
    synchronized State observeVisible(String current, long now) {
        noteVisible(current, now);
        return observe(current, now);
    }

    private boolean retryVisibilityReady(Entry value, long now) {
        if (value.visibleSamples < 2 || value.visibleSince <= 0 || value.lastVisibleAt <= 0) return false;
        if (now < value.visibleSince || now - value.visibleSince < MIN_RETRY_VISIBLE_STREAK_MS) return false;
        return now >= value.lastVisibleAt && now - value.lastVisibleAt <= RECENT_VISIBLE_MS;
    }

    /**
     * Atomically reserve a Reject attempt only when the same logical offer is actually READY.
     * OCR and Accessibility both call this shared gate, so only one source can own a dispatch.
     */
    synchronized int reserveIfReady(String current, long now) {
        if (!sparseAliasOwner(current, now).isEmpty()) return 0;
        Entry value = entry(current, now);
        if (tombstoned(value, now) || value.attempts >= 2
                || now < value.processingUntil || now < value.retryAfter) return 0;
        if (value.attempts == 1 && !retryVisibilityReady(value, now)) return 0;
        value.attempts++;
        value.lastDispatchAt = now;
        value.spinnerAcknowledged = false;
        value.dispatchOwnershipUntil = now + DISPATCH_OWNERSHIP_MS;
        value.retryAfter = now + RETRY_MS;
        value.processingUntil = 0;
        value.tombstoneUntil = 0;
        value.visibleSince = now;
        value.lastVisibleAt = now;
        value.visibleSamples = 1;
        value.holdReported = false;
        value.reappearedReported = false;
        value.departureProven = false;
        value.reorderedAt = 0L;
        value.rearmedPending = false;
        return value.attempts;
    }

    /**
     * Foreground lanes may start a Reject transaction, but may never consume retry #2.
     * The sole second attempt is reserved by reserveFinalIfFresh() after a fresh live recheck.
     */
    synchronized int reserveFirstIfReady(String current, long now) {
        if (!sparseAliasOwner(current, now).isEmpty()) return 0;
        Entry value = entry(current, now);
        if (value.attempts != 0 || tombstoned(value, now)
                || now < value.processingUntil || now < value.retryAfter) return 0;
        value.attempts = 1;
        value.lastDispatchAt = now;
        value.spinnerAcknowledged = false;
        value.dispatchOwnershipUntil = now + DISPATCH_OWNERSHIP_MS;
        value.retryAfter = now + RETRY_MS;
        value.processingUntil = 0;
        value.tombstoneUntil = 0;
        value.visibleSince = now;
        value.lastVisibleAt = now;
        value.visibleSamples = 1;
        value.holdReported = false;
        value.reappearedReported = false;
        value.departureProven = false;
        value.reorderedAt = 0L;
        value.rearmedPending = false;
        return 1;
    }

    /**
     * Reserve the one and only final rescue attempt after the caller has just re-read the live
     * top card and proved that it is the same offer with an enabled Reject control.  This is
     * intentionally stricter than a timer retry: it can only turn attempt #1 into attempt #2.
     */
    synchronized int reserveFinalIfFresh(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts != 1 || tombstoned(value, now)
                || now < value.processingUntil || now < value.retryAfter) return 0;
        value.attempts = 2;
        value.lastDispatchAt = now;
        value.spinnerAcknowledged = false;
        value.dispatchOwnershipUntil = now + DISPATCH_OWNERSHIP_MS;
        value.retryAfter = now + RETRY_MS;
        value.processingUntil = 0;
        value.visibleSince = now;
        value.lastVisibleAt = now;
        value.visibleSamples = 1;
        value.holdReported = false;
        value.reappearedReported = false;
        value.departureProven = false;
        value.reorderedAt = 0L;
        value.rearmedPending = false;
        return 2;
    }

    /** Reserve one actual Reject dispatch and return its 1-based attempt number. */
    synchronized int sent(String current, long now) {
        if (!sparseAliasOwner(current, now).isEmpty()) return 0;
        Entry value = entry(current, now);
        if (tombstoned(value, now)) return 0;
        if (value.attempts >= 2) return value.attempts;
        if (value.attempts == 1 && !retryVisibilityReady(value, now)) return 0;
        value.attempts++;
        value.lastDispatchAt = now;
        value.spinnerAcknowledged = false;
        value.dispatchOwnershipUntil = now + DISPATCH_OWNERSHIP_MS;
        value.retryAfter = now + RETRY_MS;
        value.processingUntil = 0;
        value.visibleSince = now;
        value.lastVisibleAt = now;
        value.visibleSamples = 1;
        value.holdReported = false;
        value.reappearedReported = false;
        value.departureProven = false;
        value.reorderedAt = 0L;
        value.rearmedPending = false;
        return value.attempts;
    }

    /** Positive UI acknowledgement: Reject became disabled/processing. */
    synchronized void markProcessing(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts <= 0 || tombstoned(value, now)) return;
        value.processingUntil = Math.max(value.processingUntil, now + PROCESSING_HOLD_MS);
        value.retryAfter = Math.max(value.retryAfter, value.processingUntil);
        value.holdReported = false;
    }

    /** A live same-card enabled button may roll back a processing observation, not a terminal. */
    synchronized void markEnabledAfterProcessing(String current,long now) {
        Entry value=entry(current,now);
        if(value.attempts!=1 || tombstoned(value, now) || value.processingUntil<=0L) return;
        value.processingUntil=0L;value.retryAfter=Math.min(value.retryAfter,now);
    }

    /** Card vanished without strong server confirmation. Keep a short anti-reappearance tombstone. */
    synchronized void markDisappeared(String current, long now) {
        Entry value = entry(current, now);
        value.tombstoneUntil = Math.max(value.tombstoneUntil, now + DISAPPEARED_TOMBSTONE_MS);
        value.processingUntil = 0;
        value.retryAfter = Math.max(value.retryAfter, value.tombstoneUntil);
        value.visibleSince = 0;
        value.lastVisibleAt = 0;
        value.visibleSamples = 0;
        value.reappearedReported = false;
        value.departureProven = true;
    }

    /** Strong completion/loss evidence: suppress stale reappearance longer. */
    synchronized void markTerminal(String current, long now) {
        Entry value = entry(current, now);
        // Strong terminal evidence means this logical offer must never be clicked again during
        // its retained lifetime. Saturate the attempt budget after the short UI tombstone.
        value.attempts = Math.max(value.attempts, 2);
        value.tombstoneUntil = Math.max(value.tombstoneUntil, now + TERMINAL_TOMBSTONE_MS);
        value.processingUntil = 0;
        value.retryAfter = Math.max(value.retryAfter, value.tombstoneUntil);
        value.visibleSince = 0;
        value.lastVisibleAt = 0;
        value.visibleSamples = 0;
        value.reappearedReported = false;
        value.departureProven = false;
        value.reorderedAt = 0L;
        value.rearmedPending = false;
        value.dispatchOwnershipUntil = 0;
    }

    /**
     * An exhausted/terminal card can remain enabled after a failed Ignore. The caller must
     * re-prove the live same-card enabled Reject and current rule failure before entering.
     * Time alone never resets ownership; two current visibility samples are required.
     */
    synchronized boolean recoverStalledVisible(String current, long now) {
        Entry value = entries.get(current);
        if (value == null || value.attempts <= 0 || value.lastDispatchAt <= 0
                || now < value.lastDispatchAt || now - value.lastDispatchAt < TERMINAL_TOMBSTONE_MS
                || tombstoned(value, now) || now < value.processingUntil
                || now < value.dispatchOwnershipUntil || !retryVisibilityReady(value, now)) return false;
        value.attempts = 0;
        value.retryAfter = 0;
        value.processingUntil = 0;
        value.tombstoneUntil = 0;
        value.lastDispatchAt = 0;
        value.dispatchOwnershipUntil = 0;
        value.holdReported = false;
        value.reappearedReported = false;
        value.departureProven = false;
        value.reorderedAt = 0L;
        value.rearmedPending = false;
        value.lastTouched = now;
        return true;
    }

    /** Undo a reservation when Android never dispatched the gesture/click. */
    synchronized void failed(String current, long now) {
        failed(current, now, false);
    }

    synchronized long failed(String current, long now, boolean proofChangedBeforeClick) {
        Entry value = entry(current, now);
        if (value.attempts > 0) value.attempts--;
        value.retryAfter = now + (proofChangedBeforeClick ? STALE_PROOF_REFRESH_MS : FAILED_RETRY_MS);
        value.proofRefreshUntil = proofChangedBeforeClick ? value.retryAfter : 0L;
        value.processingUntil = 0;
        value.tombstoneUntil = 0;
        value.visibleSince = 0;
        value.lastVisibleAt = 0;
        value.visibleSamples = 0;
        value.holdReported = false;
        value.reappearedReported = false;
        value.departureProven = false;
        value.reorderedAt = 0L;
        value.rearmedPending = false;
        value.dispatchOwnershipUntil = 0;
        return value.retryAfter;
    }

    /** Suppresses repeated reads only during a failed pre-dispatch proof's short refresh window. */
    synchronized boolean proofRefreshPending(String identity, String text, long now) {
        Entry value = entries.get(identity);
        return value != null && now < value.proofRefreshUntil
                && OfferEnrichmentPolicy.sameTransaction(value.observedText, text);
    }

    /** Returns true only once when the two-attempt ceiling is reached. */
    synchronized boolean markHoldReported(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts < 2 || value.holdReported) return false;
        value.holdReported = true;
        return true;
    }

    /** Returns true once while an existing dispatch/processing transaction suppresses a frame. */


    /** Returns true once if a tombstoned card becomes visible again. */
    synchronized boolean markReappearedReported(String current, long now) {
        Entry value = entry(current, now);
        if (!tombstoned(value, now) || value.reappearedReported) return false;
        value.reappearedReported = true;
        return true;
    }

    synchronized boolean consumeRearmed(String current, long now) {
        Entry value = entry(current, now);
        if (!value.rearmedPending) return false;
        value.rearmedPending = false;
        return true;
    }

    /** Read-only Accept exclusion; never consumes/reset Reject attempts or delays a new id. */
    synchronized boolean blocksAccept(String identity, long now) {
        Entry value = entries.get(identity);
        if (value != null && value.reorderedAt == 0L && value.attempts > 0 && value.lastDispatchAt > 0L
                && now >= value.lastDispatchAt && now - value.lastDispatchAt < ENTRY_TTL_MS
                && (now < value.dispatchOwnershipUntil || now < value.processingUntil
                    || now < value.tombstoneUntil || now - value.lastDispatchAt <= SPARSE_ALIAS_BLOCK_MS))
            return true;
        return !sparseAliasOwner(identity, now, true).isEmpty();
    }

    synchronized int attempts(String current, long now) { return entry(current, now).attempts; }

    /**
     * Production cleanup may forget an old logical card only when no Android dispatch callback
     * can still own it.  During the lease, retain a departure tombstone instead.  A different
     * top card remains free to run, while the old card cannot manufacture another attempt #1.
     */
    synchronized boolean forgetIfNoDispatchOwnership(String current, long now) {
        Entry value = entries.get(current);
        if (value == null) return true;
        if (now < value.dispatchOwnershipUntil) {
            value.lastTouched = now;
            value.tombstoneUntil = Math.max(value.tombstoneUntil,
                    now + DISAPPEARED_TOMBSTONE_MS);
            value.retryAfter = Math.max(value.retryAfter, value.tombstoneUntil);
            value.processingUntil = 0;
            value.visibleSince = 0;
            value.lastVisibleAt = 0;
            value.visibleSamples = 0;
            value.departureProven = true;
            return false;
        }
        entries.values().removeIf(item -> item == value);
        return true;
    }

    /** A new top lets the scan proceed but does not prove the previous publication left Offers. */
    synchronized void markReorderedDeparture(String current, long now) {
        Entry value = entries.get(current);
        if (value == null || value.attempts == 0 || tombstoned(value, now)) return;
        value.reorderedAt = now;
        value.processingUntil = 0L;
        hasReorderedDepartures = true;
        noteMissing(current, now);
    }

    synchronized boolean hasReorderedDepartures(long now) {
        if (!hasReorderedDepartures) return false;
        purgeExpired(now);
        return hasReorderedDepartures;
    }

    boolean hasReorderedDepartures() { return hasReorderedDepartures; }

    void invalidateReorderedEmpty() {
        if (emptyObservedAt != 0L) observeReorderedEmpty(false, 0L, 0L, 0L, 0L);
    }

    synchronized void observeReorderedEmpty(boolean empty, long generation, long readStartedAt, long now, long minGapMs) {
        if (empty) purgeExpired(now);
        if (!empty) {
            emptyObservedAt = 0L;
            return;
        }
        if (emptyObservedAt == 0L || generation != emptyGeneration) {
            emptyObservedAt = now;
            emptyReadStartedAt = readStartedAt;
            emptyGeneration = generation;
            return;
        }
        if (readStartedAt - emptyObservedAt < minGapMs) return;
        // Only release entries whose transition had settled before the first empty read.
        long cutoff = emptyReadStartedAt - EMPTY_AFTER_REORDER_MS;
        entries.values().removeIf(value -> value.reorderedAt > 0L && value.reorderedAt <= cutoff);
        hasReorderedDepartures = entries.values().stream().anyMatch(value -> value.reorderedAt > 0L);
        emptyReadStartedAt = readStartedAt;
        emptyObservedAt = hasReorderedDepartures ? now : 0L;
    }

    /** Records only an enabled same-card Reject snapshot already obtained by the scan. */
    synchronized long noteEnabledSnapshot(String current, long numericSeenAt, long snapshotAt) {
        Entry value = entries.get(current);
        if (value == null || snapshotAt <= 0L) return 0L;
        if (value.firstEnabledSnapshotAt == 0L || numericSeenAt > value.lastEnabledSnapshotAt
                || value.firstEnabledSnapshotAt < numericSeenAt)
            value.firstEnabledSnapshotAt = snapshotAt;
        else value.firstEnabledSnapshotAt = Math.min(value.firstEnabledSnapshotAt, snapshotAt);
        value.lastEnabledSnapshotAt = Math.max(value.lastEnabledSnapshotAt, snapshotAt);
        return value.firstEnabledSnapshotAt;
    }

    synchronized void forget(String current) {
        Entry value = entries.get(current);
        if (value != null) {
            entries.values().removeIf(item -> item == value);
            if (value.reorderedAt > 0L) {
                hasReorderedDepartures = entries.values().stream().anyMatch(item -> item.reorderedAt > 0L);
                if (!hasReorderedDepartures) emptyObservedAt = 0L;
            }
        }
    }
}
