package com.local.cateringscreenassistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.hardware.display.VirtualDisplay;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.DisplayMetrics;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.text.DateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OcrMonitorService extends Service {
    private static final String CHANNEL = "ocr_monitor";
    private static final int NOTIFICATION_ID = 41;
    static final String ACTION_RESUME_MANUAL =
            "com.local.cateringscreenassistant.action.RESUME_AFTER_MANUAL_INTERVENTION";
    private static final Pattern MONEY_RANGE = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)\\s*[-–—]\\s*\\$?(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MILES = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern OFFER_TIME = Pattern.compile("(?:today|tomorrow)\\s*(?:at)?\\s*(\\d{1,2}:\\d{2})\\s*(am|pm)", Pattern.CASE_INSENSITIVE);
    private static final String[] ACCEPT_WORDS = {"accept", "claim"};
    private static final String[] IGNORE_WORDS = {"ignore", "decline", "reject"};
    private static volatile OcrMonitorService activeInstance;
    private static final AtomicBoolean MANUAL_INTERVENTION_PAUSED = new AtomicBoolean(false);
    private static final AtomicLong MANUAL_PAUSE_EPOCH = new AtomicLong();
    private static final Handler MANUAL_PAUSE_HANDLER = new Handler(Looper.getMainLooper());
    private static final long MANUAL_AUTO_RESUME_MS = 15_000L;
    private static volatile boolean manualInterventionConfirmed;
    // v2.10.59: timestamp the newest DeliverThat Accessibility demand before any deep event
    // ancestry work. Background Reject confirmation must yield to this foreground lane.
    private static final AtomicLong foregroundOfferDemandAt = new AtomicLong();
    // v2.10.6 Galaxy A15 speed profile: the first DeliverThat card lives roughly in
    // the middle third of the screen. Keep a little safety margin but stop copying/OCRing
    // the navigation bar and lower cards.
    private static final float TOP_ROI_START = 0.20f;
    private static final float TOP_ROI_END = 0.58f;
    private static final int DEFAULT_SCAN_INTERVAL_MS = ScanPolicy.DEFAULT_OCR_INTERVAL_MS;
    private volatile int lastEffectiveOcrIntervalMs = DEFAULT_SCAN_INTERVAL_MS;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private volatile ImageReader reader;
    private AcceptReplay acceptReplay;
    private HandlerThread workerThread;
    private Handler worker;
    // Keep Accessibility decisions on their own high-priority queue so a heavy OCR frame
    // cannot delay an offer click. This is the primary low-latency path.
    private HandlerThread fastThread;
    private HandlerThread acceptClickThread;
    private Handler acceptClickWorker;
    private final AtomicBoolean pressureAdmissionWaiting=new AtomicBoolean();
    private volatile TapAccessibilityService.FastOfferSnapshot pressureSnapshot,spinnerSnapshot;
    private volatile long pressureOwner, pressureEpoch, spinnerObservedAt, lastSpinnerFrameAt;
    private volatile long spinnerCandidateAt, spinnerWindowEpoch;
    private final AtomicLong queuedPressureOwner = new AtomicLong();
    private static final long SPINNER_CANDIDATE_TIMEOUT_MS = 150L;
    private static final long SPINNER_CLEAR_MIN_MS = 112L;
    private int spinnerClearFrames;
    private long spinnerFirstClearAt, spinnerClearedAt;
    private final AcceptSpinnerPolicy.Tracker spinnerTracker = new AcceptSpinnerPolicy.Tracker();

    private void armAcceptPressure(TapAccessibilityService.FastOfferSnapshot snapshot,long epoch) {
        pressureSnapshot=snapshot;spinnerSnapshot=snapshot;
        pressureOwner=serialTopActionAt;pressureEpoch=epoch;
        spinnerWindowEpoch=TapAccessibilityService.outcomeWindowEpoch();
        pressureAdmissionWaiting.set(false);
        synchronized (spinnerTracker) {
            spinnerObservedAt=lastSpinnerFrameAt=spinnerCandidateAt=0L;
            spinnerClearFrames=0;
            spinnerFirstClearAt=spinnerClearedAt=0L;
            spinnerTracker.reset();
        }
        claimBudget.enableContinuous(snapshot.identity,SystemClock.elapsedRealtime());
    }
    public static TapAccessibilityService.FastOfferSnapshot acceptPressureSnapshotForBinding() {
        OcrMonitorService s=activeInstance;
        return s!=null && acceptPressureActive(s.serialTopActionAt)?s.pressureSnapshot:null;
    }
    public static void bindAcceptPressureSnapshot(TapAccessibilityService.FastOfferSnapshot snapshot) {
        OcrMonitorService s=activeInstance;
        if(s!=null && snapshot!=null && acceptPressureActive(s.serialTopActionAt)) {
            s.pressureSnapshot=snapshot;s.spinnerSnapshot=snapshot;
        }
    }
    public static Handler acceptRenewalHandler() {
        OcrMonitorService s=activeInstance;
        return s==null?null:s.acceptProofWorker;
    }
    public static void noteAcceptCallbackEntry(long owner,long callAt,long ackAt,long enteredAt,boolean cancelled) {
        OcrMonitorService s=activeInstance;
        if(s!=null && s.serialTopActionAt==owner)
            s.acceptReplay.event(enteredAt,"GESTURE_CALLBACK_ENTRY tx="+owner+" call="+callAt
                    +" ack="+ackAt+" callback="+enteredAt+" cancelled="+cancelled);
    }
    public static Handler acceptCallbackHandler() {
        OcrMonitorService s=activeInstance;
        return s==null?null:s.acceptClickWorker;
    }
    public static boolean acceptPressureActive(long owner) {
        OcrMonitorService s=activeInstance;
        return s!=null && s.pressureSnapshot!=null && s.pressureOwner==owner
                && s.serialTopAction==SerialAction.ACCEPT && s.serialTopActionAt==owner
                && s.pressureEpoch==s.claimEpoch.get() && s.spinnerObservedAt==0L;
    }
    private boolean hasSpinnerCandidate(long owner) {
        return pressureOwner == owner && spinnerCandidateAt > 0L && spinnerObservedAt == 0L;
    }

    private boolean preserveVisibleAcceptLoading(long owner,PageOutcomePolicy.Tracker tracker,long now) {
        long frameAt=lastSpinnerFrameAt;
        return tracker!=null && owner==pressureOwner && owner==serialTopActionAt
                && pressureEpoch==claimEpoch.get() && frameAt>0L
                && (spinnerObservedAt>0L || spinnerCandidateAt>0L)
                && spinnerWindowEpoch==TapAccessibilityService.outcomeWindowEpoch()
                && tracker.noteLoadingFrame(frameAt,now);
    }

    public static String acceptLoadingRetryBlock(long owner) {
        OcrMonitorService service = activeInstance;
        if (service == null || owner <= 0L || service.pressureOwner != owner
                || service.serialTopActionAt != owner) return "";
        if (service.spinnerObservedAt > 0L) return "RETRY_SPINNER_CONFIRMED";
        return service.spinnerCandidateAt > 0L ? "RETRY_SPINNER_CANDIDATE" : "";
    }
    public static boolean canReadAcceptRecoveryProof(long owner) {
        OcrMonitorService service=activeInstance;
        if (service==null) return false;
        synchronized (service.spinnerTracker) {
            if (owner<=0L || service.serialTopActionAt!=owner) return false;
            if (service.pressureOwner!=owner) return true;
            return service.spinnerCandidateAt==0L && (service.spinnerObservedAt==0L
                    || (service.spinnerClearFrames>=2
                        && service.spinnerWindowEpoch==TapAccessibilityService.outcomeWindowEpoch()));
        }
    }

    public static String acceptPressureGuard(long owner) {
        String terminal=acceptRetryGuard(owner);
        if(!terminal.isEmpty()) return terminal;
        String loading = acceptLoadingRetryBlock(owner);
        if (!loading.isEmpty()) return loading;
        OcrMonitorService service=activeInstance;
        PageOutcomePolicy.Tracker tracker=service==null?null:service.pageTracker(owner);
        return tracker==null?"":tracker.pressureBlockReason();
    }
    private void pauseAcceptPressureForContext(long owner,String reason,long at) {
        if(owner<=0L || serialTopAction!=SerialAction.ACCEPT || owner!=serialTopActionAt) return;
        if(PageOutcomePolicy.transientControlGap(reason)) return;
        PageOutcomePolicy.Tracker tracker=pageTracker(owner);
        if(tracker!=null) tracker.pausePressure(reason,at);
        // A delayed observer cannot revoke a newer current-button proof.
        if(pressureSnapshot!=null && pressureSnapshot.capturedAt>at) return;
        // Revoke queued gesture authority synchronously, before any logging or worker wake.
        boolean active=pressureSnapshot!=null && pressureOwner==owner;
        pressureSnapshot=null;pressureAdmissionWaiting.set(false);
        acceptReplay.event(SystemClock.elapsedRealtime(),"PRESSURE_PAUSE_APPLIED tx="+owner+" reason="+reason+" evidenceEnd="+at);
        if(active) {
            acceptReporter(serialTopText).accept("ACCEPT_PRESSURE_PAUSED："+reason
                    +"；已撤销缓存坐标补击；等待当前同卡Accept启用证明；非接单终态");
            scheduleAcceptPageProbe(owner);
            TapAccessibilityService.startAcceptControlWatch(serialTopText,owner);
            scheduleClaimInspection(serialTopText,claimEpoch.get(),0,0,0L);
        }
    }
    private void finishAcceptPressure(long owner) {
        if(pressureOwner!=owner || pressureSnapshot==null) return;
        pressureSnapshot=null;
        if(serialTopActionAt==owner && serialTopAction==SerialAction.ACCEPT) {
            scheduleAcceptPageProbe(owner);
            TapAccessibilityService.startAcceptControlWatch(serialTopText,owner);
            scheduleClaimInspection(serialTopText,claimEpoch.get(),0,0,0L);
        }
    }
    private void releaseAcceptAdmission() {
        acceptAdmissionBusy.set(false);
        if(pressureAdmissionWaiting.getAndSet(false) && acceptPressureActive(pressureOwner))
            scheduleAcceptPressure(pressureOwner,pressureEpoch);
    }

    private void scheduleAcceptPressure(long owner,long epoch) {
        Handler clicks=acceptClickWorker;
        if (clicks==null || owner<=0L || owner!=pressureOwner || epoch!=pressureEpoch
                || owner!=serialTopActionAt || hasSpinnerCandidate(owner)) return;
        long queuedOwner=queuedPressureOwner.get();
        do {
            if (queuedOwner>=owner) return;
        } while (!queuedPressureOwner.compareAndSet(queuedOwner,owner)
                && (queuedOwner=queuedPressureOwner.get())<owner);
        if (queuedOwner>=owner) return;
        final long queuedAt=SystemClock.elapsedRealtime();
        clicks.postAtFrontOfQueue(() -> {
            if (queuedPressureOwner.compareAndSet(owner,0L)) runAcceptPressure(owner,epoch,queuedAt);
        });
    }

    /** Already on the click worker: preserve all final fences without another queue hop. */
    private void runAcceptPressure(long owner,long epoch,long queuedAt) {
            TapAccessibilityService.FastOfferSnapshot snapshot=pressureSnapshot;
            if(snapshot==null || owner!=pressureOwner || epoch!=claimEpoch.get()
                    || serialTopActionAt!=owner || serialTopAction!=SerialAction.ACCEPT) return;
            if (hasSpinnerCandidate(owner)
                    || ActionDispatchPolicy.retryInFlight(SystemClock.elapsedRealtime(),acceptRetryDispatchPendingAt)) return;
            if(!monitorReady || isManualInterventionPaused() || spinnerObservedAt>0L
                    || !TapAccessibilityService.hasDeliverThatReplayForegroundHint()
                    || !acceptPressureGuard(owner).isEmpty()) {
                finishAcceptPressure(owner);return;
            }
            if(!acceptAdmissionBusy.compareAndSet(false,true)) {
                pressureAdmissionWaiting.set(true);
                if(!acceptAdmissionBusy.get() && pressureAdmissionWaiting.getAndSet(false))
                    scheduleAcceptPressure(owner,epoch);
                return;
            }
            try {
                long enteredAt=SystemClock.elapsedRealtime();
                acceptReplay.event(enteredAt,"PRESSURE_ENTRY tx="+owner+" queueMs="+(enteredAt-queuedAt));
                if(!dispatchClaim(snapshot,epoch,0L,0L,true) && !hasSpinnerCandidate(owner))
                    finishAcceptPressure(owner);
            } finally {releaseAcceptAdmission();}
    }

    /** Read just the CTA pixels directly from the frame. */
    private static int acceptSpinnerMask(Image image, Rect r) {
        int width=image.getWidth(), height=image.getHeight();
        if(r.isEmpty() || r.left<0 || r.top<0 || r.right>width || r.bottom>height) return 0;
        Image.Plane plane=image.getPlanes()[0];
        ByteBuffer buf=plane.getBuffer().duplicate();
        int pixel=plane.getPixelStride(), row=plane.getRowStride();
        if(pixel!=4 || (long)(height-1)*row+(long)(width-1)*pixel+3>=buf.limit()) return 0;
        return AcceptSpinnerPolicy.arcMask(r.left,r.top,r.right,r.bottom,(x,y) -> {
            int i=y*row+x*pixel;
            return ((buf.get(i)&255)<<16)|((buf.get(i+1)&255)<<8)|(buf.get(i+2)&255);
        });
    }

    /** A real rotating Reject CTA spinner acknowledges the click; disabled alone does NOT. */
    private static int rejectSpinnerMask(Image image,Rect r) {
        int w=image.getWidth(),h=image.getHeight();
        if(r.isEmpty()||r.left<0||r.top<0||r.right>w||r.bottom>h) return 0;
        Image.Plane plane=image.getPlanes()[0];
        ByteBuffer buf=plane.getBuffer().duplicate();
        int stride=plane.getPixelStride(),row=plane.getRowStride();
        if(stride!=4 || (long)(h-1)*row+(long)(w-1)*stride+3>=buf.limit()) return 0;
        return RejectSpinnerPolicy.arcMask(r.left,r.top,r.right,r.bottom,(x,y)->{
            int i=y*row+x*stride;
            return ((buf.get(i)&255)<<16)|((buf.get(i+1)&255)<<8)|(buf.get(i+2)&255);
        });
    }

    private void observeRejectSpinner(Image image,long now) {
        // A newer Accept transaction must not pay for old Reject diagnostics on the frame lane.
        if(serialTopAction==SerialAction.ACCEPT || rejectConfirmStates.isEmpty()
                || !TapAccessibilityService.hasDeliverThatReplayForegroundHint()) return;
        for(RejectConfirmState state:rejectConfirmStates.values()) {
            Rect bounds=state.spinnerBounds;
            final long actionAt=state.lastActionAt;
            if(bounds==null || bounds.isEmpty() || state.spinnerConfirmed.get()
                    || !rejectTerminalGate.isCurrent(state.id,state.token)
                    || now<actionAt || now-actionAt>600L) continue;
            int mask=rejectSpinnerMask(image,bounds);
            // A rescue action is a separate physical input. Never combine masks captured
            // before and after it or attribute an old frame to the newer input.
            if(state.spinnerTracker.observe(actionAt,now,mask)
                    && actionAt==state.lastActionAt
                    && state.spinnerConfirmed.compareAndSet(false,true)) {
                final long firstFrameAt=state.spinnerTracker.firstObservationAt();
                Handler confirm=rejectConfirmWorker;
                // Failed scheduling is not a completed acknowledgement. Leave the detector
                // eligible for another rotating frame instead of silently losing the result.
                if(confirm==null || !confirm.postAtFrontOfQueue(() -> finishRejectSpinnerAck(state,actionAt,firstFrameAt,now)))
                    state.spinnerConfirmed.set(false);
            }
        }
    }

    private void finishRejectSpinnerAck(RejectConfirmState state,long actionAt,long firstFrameAt,long frameAt) {
        if(actionAt!=state.lastActionAt) {
            state.spinnerConfirmed.set(false);
            return;
        }
        if(!state.spinnerConfirmed.get()
                || !closeRejectConfirmation(state,"REJECT_SPINNER_CONFIRMED",false,true)) return;
        final long elapsed=Math.max(0L,frameAt-actionAt);
        final long firstSeenMs=Math.max(0L,firstFrameAt-actionAt);
        final long handoffMs=Math.max(0L,SystemClock.elapsedRealtime()-frameAt);
        logWriter.execute(() -> offerReporterWithTiming(state.text,"Reject尝试ID="+state.actionAt
                +"；Reject旋转加载视觉确认；动作→转圈="+elapsed+"ms；动作→转圈首帧="+firstSeenMs
                +"ms；首帧→旋转确认="+Math.max(0L,frameAt-firstFrameAt)+"ms；转圈确认交接="+handoffMs+"ms").accept(
                "REJECT_SPINNER_CONFIRMED：Reject按钮旋转加载已确认；视为拒单动作已接收，"
                +"不再后台深树复核；非服务器最终结果；继续实时监控新卡"));
    }

    private void observeAcceptSpinner(Image image,long now) {
        TapAccessibilityService.FastOfferSnapshot snapshot=spinnerSnapshot;
        long owner=pressureOwner, epoch=pressureEpoch;
        long sentAt=acceptDispatchObservationAt;
        if (snapshot==null || serialTopAction!=SerialAction.ACCEPT || serialTopActionAt!=owner
                || epoch!=claimEpoch.get() || sentAt<owner || now<sentAt
                || spinnerWindowEpoch!=TapAccessibilityService.outcomeWindowEpoch()
                || image.getWidth()!=width || image.getHeight()!=height
                || !TapAccessibilityService.hasDeliverThatReplayForegroundHint()) return;
        try {
            int mask=acceptSpinnerMask(image,snapshot.acceptBounds);
            if (snapshot==spinnerSnapshot && spinnerWindowEpoch==TapAccessibilityService.outcomeWindowEpoch()) {
                long detectedAt = SystemClock.elapsedRealtime();
                boolean firstMask = mask!=0 && spinnerObservedAt==0L && spinnerCandidateAt==0L;
                applyAcceptSpinnerMask(snapshot.text,owner,epoch,now,mask);
                if (firstMask)
                    acceptReplay.event(detectedAt,"SPINNER_MASK_READ tx="+owner
                            +" frame_acquired="+now+" mask_read_ms="+(detectedAt-now));
            }
        } catch (RuntimeException ignored) { }
    }

    private void applyAcceptSpinnerMask(String text,long owner,long epoch,long now,int mask) {
        boolean candidate=false, confirmed=false, resume=false, loadingCleared=false;
        long firstSeen=0L;
        synchronized (spinnerTracker) {
            if (owner!=pressureOwner || owner!=serialTopActionAt || epoch!=claimEpoch.get()) return;
            if (spinnerObservedAt>0L) {
                if (mask!=0) {
                    lastSpinnerFrameAt=now;
                    spinnerClearFrames=0;
                    spinnerFirstClearAt=spinnerClearedAt=0L;
                } else if (spinnerClearFrames<2) {
                    if (spinnerClearFrames==0) { spinnerClearFrames=1; spinnerFirstClearAt=now; }
                    else if (now>spinnerFirstClearAt && now-lastSpinnerFrameAt>=SPINNER_CLEAR_MIN_MS) {
                        spinnerClearFrames=2;
                        spinnerClearedAt=now;
                        loadingCleared=true;
                    }
                }
            } else if (mask!=0) {
                confirmed=spinnerTracker.observe(owner,now,mask);
                lastSpinnerFrameAt=now;
                spinnerClearFrames=0;
                if (spinnerCandidateAt==0L) {
                    spinnerCandidateAt=now;
                    candidate=true;
                }
                if (confirmed) {
                    firstSeen=spinnerCandidateAt;
                    spinnerObservedAt=now;
                    spinnerCandidateAt=0L;
                }
            } else {
                spinnerTracker.observe(owner,now,0);
                if (spinnerCandidateAt > 0L && ++spinnerClearFrames >= 2
                        && now - lastSpinnerFrameAt >= SPINNER_CLEAR_MIN_MS) {
                    spinnerCandidateAt=0L;
                    spinnerClearFrames=0;
                    resume=true;
                }
            }
        }
        if (loadingCleared) {
            acceptReplay.event(now,"ACCEPT_SPINNER_CLEAR_FRAMES tx="+owner);
            acceptReplay.pinFrameAt(now);
            Handler proof=acceptProofWorker;
            if (proof!=null) proof.postAtFrontOfQueue(() -> {
                if (epoch==claimEpoch.get() && owner==serialTopActionAt && canReadAcceptRecoveryProof(owner))
                    scheduleEnabledClaimInspection(text,epoch,now);
            });
        }
        if (candidate) {
            acceptReplay.event(now,"ACCEPT_SPINNER_FIRST_SEEN tx="+owner+" mask="+mask);
            acceptReplay.pinFrameAt(now);
            Handler clicks=acceptClickWorker;
            if (clicks!=null) clicks.postDelayed(() -> expireSpinnerCandidate(owner,epoch,now),
                    SPINNER_CANDIDATE_TIMEOUT_MS);
        }
        if (resume) {
            acceptReplay.event(now, "ACCEPT_SPINNER_CANDIDATE_CLEARED tx=" + owner + " reason=CLEAR_FRAMES");
            scheduleAcceptPressure(owner,epoch);
        }
        if (confirmed) {
            acceptReplay.event(now,"ACCEPT_SPINNER_CONFIRMED tx="+owner+" firstSeen="+firstSeen);
            acceptReplay.pinFrameAt(now);
            final long seenAt=firstSeen;
            Handler clicks=acceptClickWorker;
            if (clicks!=null) clicks.postAtFrontOfQueue(() -> {
                if (owner!=serialTopActionAt || epoch!=claimEpoch.get() || spinnerObservedAt!=now) return;
                preserveVisibleAcceptLoading(owner,pageTracker(owner),SystemClock.elapsedRealtime());
                finishAcceptPressure(owner);
                scheduleAcceptPageProbe(owner);
                acceptReporter(text).accept("ACCEPT_SPINNER_CONFIRMED：同单加载已确认；停止该次Accept补击；"
                        + acceptResultTiming(text,"SPINNER_FIRST_SEEN",seenAt)
                        + "；首见到确认="+(now-seenAt)+"ms；继续观察接单结果");
            });
        }
    }

    /** A single ambiguous frame cannot indefinitely suppress a still-enabled button. */
    private void expireSpinnerCandidate(long owner,long epoch,long candidateAt) {
        long remaining;
        synchronized (spinnerTracker) {
            if (owner!=serialTopActionAt || owner!=pressureOwner || epoch!=claimEpoch.get()
                    || spinnerObservedAt>0L || spinnerCandidateAt!=candidateAt) return;
            remaining=SPINNER_CANDIDATE_TIMEOUT_MS-(SystemClock.elapsedRealtime()-lastSpinnerFrameAt);
            if (remaining<=0L) {
                spinnerCandidateAt=0L;
                spinnerClearFrames=0;
                spinnerTracker.reset();
            }
        }
        if (remaining <= 0L) {
            acceptReplay.event(SystemClock.elapsedRealtime(),
                    "ACCEPT_SPINNER_CANDIDATE_CLEARED tx=" + owner + " reason=FRAME_TIMEOUT");
            scheduleAcceptPressure(owner,epoch);
        } else {
            Handler clicks=acceptClickWorker;
            if (clicks!=null) clicks.postDelayed(() -> expireSpinnerCandidate(owner,epoch,candidateAt),remaining);
        }
    }

    private Handler fastWorker;
    // v2.10.293: idle existence checks never execute on the offer-fast decision worker.
    // There is at most one in-flight low-priority probe, and a new offer wake always
    // bypasses it. The probe only wakes the live CURRENT-index path; it cannot click.
    private HandlerThread idlePresenceThread;
    private Handler idlePresenceWorker;
    private final AtomicBoolean idlePresenceQueued = new AtomicBoolean();
    private volatile long nextIdlePresenceProbeAt;
    private volatile long lastIdlePresenceProbeAt;
    private volatile long idlePresenceUnreadableSince;
    private boolean idlePresenceDegraded;
    private final AtomicLong idlePresenceProbes = new AtomicLong();
    private final AtomicLong idlePresencePresent = new AtomicLong();
    private final AtomicLong idlePresenceEmpty = new AtomicLong();
    private final AtomicLong idlePresenceUnknown = new AtomicLong();
    private volatile String idlePresenceLastStatus = "UNOBSERVED";
    private final AtomicLong idleHeartbeatScans = new AtomicLong();
    private HandlerThread acceptOutcomeThread;
    private Handler acceptOutcomeWorker;
    // Current enabled proof must not queue behind a running 150ms page/navigation read.
    private HandlerThread acceptProofThread;
    private Handler acceptProofWorker;
    // v2.10.30: Reject confirmation must never occupy the latency-critical offer/action lane.
    // Heavy post-Reject tree probes run on a separate thread while fastWorker immediately
    // resumes top-card discovery.
    private HandlerThread rejectConfirmThread;
    private Handler rejectConfirmWorker;
    private static final class RejectConfirmState {
        final String id;
        final String text;
        final long actionAt;
        final long token;
        volatile long outcomeBaselineEpoch;
        volatile long lastActionAt;
        volatile int missingChecks;
        volatile boolean processingReported;
        long foregroundEmptyAt;
        long foregroundEmptyGeneration;
        volatile long lastProbeMs;
        volatile long totalProbeMs;
        volatile int probeCount;
        volatile boolean lastProbeBudgetExceeded;
        volatile boolean finalRescueQueued;
        volatile String lastDeferReason = "NONE";
        volatile int priorityDeferrals;
        volatile int budgetDeferrals;
        volatile int evidenceDeferrals;
        volatile int processingDeferrals;
        volatile int changedDeferrals;
        volatile int foregroundUnavailable;
        final AtomicBoolean awaitingForeground = new AtomicBoolean();
        volatile Runnable foregroundExpiry;
        volatile String lastReadFailure = "NONE";
        volatile int lastProbeNodes;
        volatile int totalProbeNodes;
        volatile String lastProbeLimit = "NONE";
        volatile Rect spinnerBounds;
        final AcceptSpinnerPolicy.Tracker spinnerTracker = new AcceptSpinnerPolicy.Tracker();
        final AtomicBoolean spinnerConfirmed = new AtomicBoolean();
        RejectConfirmState(String id, String text, long actionAt, long token,
                           long outcomeBaselineEpoch) {
            this.id = id;
            this.text = text;
            this.actionAt = actionAt;
            this.lastActionAt = actionAt;
            this.token = token;
            this.outcomeBaselineEpoch = outcomeBaselineEpoch;
        }
    }
    private volatile Rect pendingRejectSpinnerBounds;
    private volatile long pendingRejectSpinnerActionAt;
    private final Object rejectedRoiLock = new Object();
    private int rejectedRoiWidth,rejectedRoiHeight;
    private RejectConfirmState rejectedRoiOwner;
    private long rejectedRoiAt;
    private int[] rejectedRoiPixels;

    private final java.util.concurrent.ConcurrentHashMap<String, RejectConfirmState> rejectConfirmStates =
            new java.util.concurrent.ConcurrentHashMap<>();
    // v2.10.41: a real per-card Reject generation/token gate. Old queued callbacks from an
    // earlier Reject action are stale by definition, and only the first terminal outcome for
    // the live token may be recorded.
    private final RejectTerminalGate rejectTerminalGate = new RejectTerminalGate();
    private static final long REJECT_RESULT_DEADLINE_MS = 5_000L;
    private final java.util.concurrent.atomic.AtomicReference<RejectConfirmState> expiredReject =
            new java.util.concurrent.atomic.AtomicReference<>();
    private final java.util.concurrent.ThreadPoolExecutor logWriter = new java.util.concurrent.ThreadPoolExecutor(
            1, 1, 0L, java.util.concurrent.TimeUnit.MILLISECONDS,
            new java.util.concurrent.ArrayBlockingQueue<Runnable>(256),
            task -> new Thread(() -> {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
                task.run();
            }, "offer-log"),
            new java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy());
    private TextRecognizer recognizer;
    private final AtomicBoolean ocrBusy = new AtomicBoolean(false);
    private final ThreadLocal<Long> decisionPipelineStartedAt = new ThreadLocal<>();
    private final ThreadLocal<Long> decisionQueueAt = new ThreadLocal<>();
    private final ThreadLocal<Long> decisionWakeAt = new ThreadLocal<>();
    private volatile long lastStructuralWakeAt;
    private static final class NumericWake {
        final String identity;
        final long firstSeen, wakeAt;
        NumericWake(String identity,long firstSeen,long wakeAt) {
            this.identity=identity;this.firstSeen=firstSeen;this.wakeAt=wakeAt;
        }
    }
    private final java.util.concurrent.atomic.AtomicReference<NumericWake> lastNumericWake =
            new java.util.concurrent.atomic.AtomicReference<>();
    private final ThreadLocal<PipelineTiming> decisionStageTiming = new ThreadLocal<>();
    private void noteDecisionStage(String stage) {
        PipelineTiming timing = decisionStageTiming.get();
        if (timing != null) timing.mark(stage, SystemClock.elapsedRealtime());
    }
    // Non-blocking admission gate for the two initial Accept lanes. Never hold a Java monitor
    // across dispatchGesture()/Binder callbacks: Samsung may deliver related callbacks inline.
    private final AtomicBoolean acceptAdmissionBusy = new AtomicBoolean(false);
    private long lastScan;
    // Independent from lastScan so 24ms visual-only probes cannot postpone/starve normal OCR.
    private long lastHotVisualProbeAt;
    private long lastScreenOfferProbeAt;
    private boolean screenAcceptVisible;
    private volatile long lastReadableFastScan;
    private volatile String scanTiming = "";
    // v2.10.35: when the bounded quick tree exceeds its latency budget, briefly yield only
    // that fallback lane to OCR. Semantic action indexing remains active during this window.
    private volatile long quickTreeBackoffUntil;
    // A failed full-tree read on an unchanged, signal-free Offers scene must not monopolize
    // the 12ms heartbeat. This only coalesces the expensive last fallback; every heartbeat
    // still performs the existing indexed Accept/number/Reject checks. Any new Accessibility
    // wake, numeric evidence, current action or generation change bypasses it immediately.
    private volatile long idleFullReadFailedAt;
    private volatile long idleFullReadFailedGeneration = -1L;

    private volatile long cooldownUntil;
    private long pendingIgnoreSince;
    private String pendingIgnoreFingerprint = "";
    private String pendingAcceptFingerprint = "";
    private String lastLoggedIneligibleFingerprint = "";
    private int pendingAcceptConfirmations;
    private int width;
    private int height;
    private int density;
    private SharedPreferences prefs;
    private volatile boolean monitorReady;
    private int[] visualScanPixels;
    private final Object ruleReadyLock = new Object();
    private long ruleReadyNumericKey;
    private long ruleReadyFirstAt;
    private long ruleReadyLastAt;
    // v2.10.9: reuse ROI bitmaps across frames. ML Kit allows only one OCR task here
    // (ocrBusy gate), so pooled buffers are safe and avoid repeated 720x600 allocations/GC.
    private Bitmap roiPaddedBuffer;
    private Bitmap roiExactBuffer;
    private final Paint roiCopyPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    // While an Accessibility decision/gesture is in flight, do not start a competing ML Kit
    // frame. This protects the time-critical first tap from CPU/Binder contention.
    private volatile long accessibilityActionHoldUntil;
    private final AtomicBoolean fastCheckQueued = new AtomicBoolean(false);
    private final java.util.concurrent.atomic.AtomicReference<Runnable> pendingFastCheck =
            new java.util.concurrent.atomic.AtomicReference<>();
    private final AtomicBoolean fastCheckDirty = new AtomicBoolean(false);
    private final AtomicBoolean fastStructuralWake = new AtomicBoolean(false);
    private final LiveScanHealth liveScanHealth = new LiveScanHealth();
    // v2.10.57: let a fresh React-Native Accessibility event burst finish exporting the
    // current card before falling into the 100-800ms quick/full-tree lane. This is a bounded
    // scheduling optimization only; it never relaxes decision or geometry guards.
    private static final long EVENT_BURST_FAST_WINDOW_MS = 48L;
    private static final long EVENT_BURST_RETRY_MS = 8L;
    private PowerManager.WakeLock monitorWakeLock;
    private PowerManager.WakeLock monitorScreenWakeLock;
    public static boolean isMonitoring() {
        OcrMonitorService current = activeInstance;
        return current != null && current.monitorReady && !isManualInterventionPaused();
    }

    /** True while the user owns DeliverThat and every automatic Accept/Reject path is frozen. */
    public static boolean isManualInterventionPaused() {
        OcrMonitorService current = activeInstance;
        return MANUAL_INTERVENTION_PAUSED.get() || (current != null
                && SystemClock.elapsedRealtime() < current.unownedInteractionUntil);
    }

    public static void pauseForManualIntervention(Context context) {
        MANUAL_INTERVENTION_PAUSED.set(true);
        manualInterventionConfirmed = false;
        long deadlineWallClock = System.currentTimeMillis() + MANUAL_AUTO_RESUME_MS;
        if (context != null) context.getSharedPreferences("rules", MODE_PRIVATE).edit()
                .putBoolean("manualInterventionPaused", true)
                .putBoolean("manualInterventionConfirmed", false)
                .putLong("manualInterventionDeadline", deadlineWallClock).apply();
        long epoch = MANUAL_PAUSE_EPOCH.incrementAndGet();
        OcrMonitorService current = activeInstance;
        if (current != null) {
            current.scanGeneration.incrementAndGet();
            current.claimEpoch.incrementAndGet();
            current.fastCheckDirty.set(false);
            current.fastStructuralWake.set(false);
            current.updateStatus("等待人工介入｜自动点击暂停15秒；未进入Jobs/详情将自动恢复");
        }
        scheduleManualAutoResume(context, epoch, MANUAL_AUTO_RESUME_MS);
    }

    /** Notification/open action is explicit proof that the user took ownership. */
    public static void confirmManualIntervention(Context context) {
        if (!MANUAL_INTERVENTION_PAUSED.get()) return;
        manualInterventionConfirmed = true;
        MANUAL_PAUSE_EPOCH.incrementAndGet();
        if (context != null) context.getSharedPreferences("rules", MODE_PRIVATE).edit()
                .putBoolean("manualInterventionConfirmed", true)
                .remove("manualInterventionDeadline").apply();
        OcrMonitorService current = activeInstance;
        if (current != null) current.updateStatus(
                "人工已介入｜自动Accept/Reject保持暂停；处理完成后点“恢复自动监控”");
    }

    public static void resumeAfterManualIntervention(Context context) {
        resumeAfterManualIntervention(context, false);
    }

    private static void resumeAfterManualIntervention(Context context, boolean automatic) {
        MANUAL_INTERVENTION_PAUSED.set(false);
        manualInterventionConfirmed = false;
        MANUAL_PAUSE_EPOCH.incrementAndGet();
        if (context != null) context.getSharedPreferences("rules", MODE_PRIVATE).edit()
                .putBoolean("manualInterventionPaused", false)
                .putBoolean("manualInterventionConfirmed", false)
                .remove("manualInterventionDeadline").apply();
        OcrMonitorService current = activeInstance;
        if (current == null || !current.monitorReady) return;
        current.unownedInteractionUntil=0L;
        current.scanGeneration.incrementAndGet();
        current.cooldownUntil = 0L;
        current.accessibilityActionHoldUntil = 0L;
        current.lastScan = 0L;
        current.lastReadableFastScan = 0L;
        current.updateStatus(automatic
                ? "15秒内未检测到人工介入｜自动监控已恢复"
                : "人工介入结束｜自动监控已恢复，请返回Offers页面");
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    private static void scheduleManualAutoResume(Context context, long epoch, long delayMs) {
        Context app = context == null ? null : context.getApplicationContext();
        MANUAL_PAUSE_HANDLER.postDelayed(() -> {
            if (epoch != MANUAL_PAUSE_EPOCH.get() || !MANUAL_INTERVENTION_PAUSED.get()
                    || manualInterventionConfirmed) return;
            PageGuard.Page page = TapAccessibilityService.activePage();
            // Entering Jobs/Ignored is current on-device evidence that manual/job handling owns
            // the UI. Keep the freeze. Remaining on Offers (or leaving DT) means nobody took the
            // handoff, so the monitor must not remain dead indefinitely.
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) {
                confirmManualIntervention(app);
                return;
            }
            resumeAfterManualIntervention(app, true);
        }, Math.max(0L, delayMs));
    }

    private void restoreManualPauseTimer() {
        if (!MANUAL_INTERVENTION_PAUSED.get()) return;
        manualInterventionConfirmed = prefs.getBoolean("manualInterventionConfirmed", false);
        if (manualInterventionConfirmed) return;
        long deadline = prefs.getLong("manualInterventionDeadline", 0L);
        long remaining = deadline <= 0L ? 0L : deadline - System.currentTimeMillis();
        long epoch = MANUAL_PAUSE_EPOCH.incrementAndGet();
        scheduleManualAutoResume(this, epoch, Math.max(0L, remaining));
    }
    /** Start time of the currently unresolved Accept transaction; 0 when none. */
    /** Scheduling hint only; missing mileage/city does not authorize an Accept. */
    public static boolean shouldPrefetchOfferRoot(String text) {
        OcrMonitorService service=activeInstance;
        if(service==null || !isMonitoring() || service.serialTopAction!=SerialAction.NONE) return false;
        float pay=CardText.amount(text);
        if(pay<0f) return false;
        if(pay>=service.prefs.getFloat("minPay",60f)) return true;
        // Avoid cold-root work for low ordinary offers; a special-only amount needs city evidence.
        return service.prefs.getBoolean("pasadenaRuleEnabled",false)
                && pay>=service.prefs.getFloat("pasadenaMinPay",25f)
                && PasadenaRuleGuard.isPasadenaOffer(text);
    }
    /** Control-only observer may wake a full inspection; it never reserves or sends a click. */
    public static void onAcceptControlObserved(long at,String state,long elapsed) {
        OcrMonitorService service=activeInstance;
        if(service==null || !isMonitoring() || service.serialTopAction!=SerialAction.ACCEPT
                || service.serialTopActionAt!=at || !acceptRetryGuard(at).isEmpty()) return;
        service.acceptAudit.observedControl(at,state,SystemClock.elapsedRealtime());
        if("ENABLED_RECOVERED".equals(state)) {
            service.acceptControlEnabledActionAt=at;service.acceptControlEnabledAt=SystemClock.elapsedRealtime();
        } else if(!"ENABLED".equals(state)) {
            service.acceptControlEnabledActionAt=0L;service.acceptControlEnabledAt=0L;
        }
        if("ENABLED".equals(state) || "ENABLED_RECOVERED".equals(state))
            service.scheduleEnabledClaimInspection(service.serialTopText,service.claimEpoch.get(),SystemClock.elapsedRealtime());
        service.acceptReporter(service.serialTopText).accept("ACCEPT_CONTROL_WATCH："+state
                +"；本次观察会话="+elapsed+"ms；仅唤醒，同卡身份和最终发送校验独立执行");
    }
    public static long pendingClaimSince() {
        OcrMonitorService current = activeInstance;
        return current == null || current.serialTopAction != SerialAction.ACCEPT
                ? 0L : current.serialTopActionAt;
    }
    /** Current transaction identity only; never consults historical offer suppression. */
    public static String pendingClaimText(long owner) {
        OcrMonitorService current=activeInstance;
        if(current==null || owner<=0L || current.serialTopAction!=SerialAction.ACCEPT
                || current.serialTopActionAt!=owner) return "";
        String rich=current.acceptRetryEnrichedText;
        return !rich.isEmpty() && current.verifiedAcceptRetryMatches(rich)?rich:current.serialTopText;
    }
    /** Accessibility reports every observed Jobs badge value, including manual claims. */
    public static void onJobsBadgeObserved(int count) {
        OcrMonitorService current = activeInstance;
        if (current == null || count < 0) return;
        int before = current.observedJobsBadgeCount;
        current.observedJobsBadgeCount = count;
        if (before < 0 || count <= before) return;

        // Kill any OCR work that started before the badge transition immediately. The actual
        // transaction cleanup runs on the fast thread to keep all state mutation serialized.
        current.scanGeneration.incrementAndGet();
        Handler fast = current.fastWorker;
        if (fast != null) {
            fast.postAtFrontOfQueue(() -> {
                if (!current.monitorReady) return;
                if (current.postClaimIsolationActive && current.postClaimIsolationBadge >= count) return;
                if (current.serialTopAction == SerialAction.ACCEPT) {
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                    return;
                }
                current.enterPostClaimIsolation("Jobs徽标 " + before + "→" + count
                        + "（手动/外部接单）", count);
            });
        }
    }

    private enum SerialAction { NONE, ACCEPT, REJECT }
    private final AtomicLong claimEpoch = new AtomicLong();
    // v2.10.28: every OCR frame belongs to a scan generation. A confirmed/manual claim or
    // newly dispatched action invalidates older callbacks so they cannot create fake cards or
    // duplicate gestures after the UI has already moved on.
    private final AtomicLong scanGeneration = new AtomicLong();
    // v2.10.31: scanGeneration is the global task epoch. Every queued Accessibility scan,
    // OCR callback and Gesture callback must belong to the same epoch that created it.
    // ACCEPT_SUCCESS/manual Jobs increment invalidates the whole previous generation at once.
    private final AtomicLong staleTaskDrops = new AtomicLong();
    private volatile String activeAcceptFingerprint = "";
    private volatile int suppressedAcceptFrames;
    // v2.10.37: once Android has accepted an Accept dispatchGesture() request, callbacks for the
    // same semantic card become observation-only. They may contribute success/terminal
    // evidence through the existing claim observers, but must not re-enter offer parsing,
    // rule evaluation, anchor discovery or another action path while that Accept transaction lives.
    private volatile long acceptDispatchObservationAt;
    private final AcceptAttemptAudit acceptAudit = new AcceptAttemptAudit();
    private volatile AcceptOutcomeFence acceptOutcomeFence;
    private volatile PageOutcomePolicy.Baseline preparedPageBaseline, dispatchedPageBaseline;
    private volatile boolean dispatchedPageBaselineClean;
    private volatile PageOutcomePolicy.Tracker acceptPageTracker;
    private final java.util.concurrent.atomic.AtomicBoolean acceptPageProbeQueued = new java.util.concurrent.atomic.AtomicBoolean();
    private final Object acceptPageProbeScheduleLock = new Object();
    // Access under acceptPageProbeScheduleLock. A running read has no pending callback.
    private Runnable pendingAcceptPageProbe;
    private long pendingAcceptPageProbeOwner;
    private volatile int acceptPageProbeCount, acceptPageValidProbeCount;
    private volatile long acceptPageProbeStartedAt;
    private volatile long cancelledAcceptPriorityUntil;

    private volatile AcceptOutcomeFence acceptAdmissionGuardFence;
    private volatile long ignoredAcceptOutcomeActionAt;
    private String engineVersion = "unknown";
    private long engineVersionCode = -1L;
    private final long engineSessionAt = SystemClock.elapsedRealtime();
    // Set only by Android's optional gesture completion callback. Some Samsung/OEM builds can
    // delay or omit this callback even though dispatchGesture() returned true. It is diagnostic
    // evidence only; acceptDispatchObservationAt is the transaction/terminal-tracking gate.
    private volatile long acceptGestureCompletedAt;
    private volatile long acceptCallbackDelayReportedForActionAt;
    // v2.10.89: dispatchGesture() acceptance is authoritative evidence that Android queued
    // the gesture. Persist that fact before the immediate server/UI observer can terminate and
    // clear the transaction; the optional OEM completion callback may arrive afterwards.
    private volatile long acceptDispatchAckReportedForActionAt;
    private volatile int observedJobsBadgeCount = -1;
    private volatile boolean postClaimIsolationActive;
    private volatile long postClaimIsolationAt;
    private volatile int postClaimIsolationBadge = -1;
    // v2.10.131: every confirmed-claim navigation owns one token.  A newer success, a proven
    // Offers surface, timeout, foreground loss or isolation release invalidates all delayed
    // callbacks from the older navigation transaction.
    private final AtomicLong postClaimNavigationEpoch = new AtomicLong();
    // Serial first-card transaction. Accept and Reject must never share post-action
    // confirmation semantics: Jobs/detail signals belong only to Accept.
    private volatile String serialTopText = "";
    private volatile long serialTopActionAt;
    private volatile SerialAction serialTopAction = SerialAction.NONE;
    private volatile long rejectProcessingConfirmedAt;
    private volatile long rejectDispatchCompletedAt;
    private volatile long rejectOutcomeBaselineEpoch;
    // v2.10.26: after the first coherent scan proves Accept is disabled/processing,
    // cached Accessibility outcome events own the short wait. This avoids repeated 400-800ms
    // tree walks while DeliverThat is already processing the same claim.
    private volatile long acceptProcessingConfirmedAt;
    private int acceptProcessingQuietChecks;
    private volatile long acceptRetryDispatchPendingAt;
    private volatile String acceptRetryEnrichedText="";
    private volatile boolean visualRetryNeeded;
    private volatile int visualRetryOcrProbes;
    private volatile long lastVisualRetryProbeAt;
    private int visualRetryDiagnosticMask;
    private VisualRetryPolicy.Proof visualRetryProof=new VisualRetryPolicy.Proof();
    // v2.10.23: capture the pre-claim Jobs badge without putting another tree walk in front
    // of the tap. Existing page scans keep this cache warm.
    private volatile int pendingAcceptJobsBaseline = -1;
    // v2.10.68: Job/Timeline is only a provisional UI transition, never final success.
    // A generic/old assigned-job page can contain the same pay, miles and time as the Offer.
    private volatile String pendingJobDetailCandidateIdentity = "";
    private volatile long pendingJobDetailCandidateAt;
    private static final long JOB_DETAIL_CANDIDATE_WINDOW_MS = 1_800L;
    // v2.10.50: once the claimed card disappears, keep a short observation-only window
    // for delayed Jobs/detail/unavailable signals. No Accept retry is authorized while this
    // timer is active; it only prevents a premature ACCEPT_UNKNOWN classification.
    private volatile long pendingAcceptMissingSince;
    private volatile long pendingAcceptTerminalProbeAt;
    // v2.10.13 action-stall watchdog. A transaction-level cooldown must never starve
    // screen capture long enough to hide a newly arrived top offer. We therefore allow
    // sparse rescue OCR probes and require two stable first-card observations before
    // retiring an old serial lock.
    private volatile long lastActionDispatchAt;
    private volatile long lastWatchdogProbeAt;
    private volatile long lastStallRecoveryAt;
    private volatile String observedTopIdentity = "";
    private volatile long observedTopSince;
    private volatile int observedTopFrames;
    // v2.10.66: an offer-looking OCR frame can temporarily lose both semantic action labels.
    // Coalesce those frames by stable numeric/time evidence instead of the noisy full-screen
    // map OCR.  This state controls only retry scheduling and logging; it never authorizes taps.
    private volatile String anchorlessOfferKey = "";
    private volatile long anchorlessFirstSeenAt;
    private volatile long anchorlessLastSeenAt;
    private volatile long anchorlessLastRetryAt;
    private volatile int anchorlessRetryCount;
    private volatile int anchorlessSuppressedFrames;
    // The Large Order explanation temporarily replaces the card tree. Preserve recent numeric
    // evidence, but require a fresh current Accept rectangle after closing X.
    private volatile TapAccessibilityService.DecisionEvidence largeOrderResumeEvidence;
    private volatile long largeOrderResumeUntil;
    // v2.10.14: when OCR sees a different first card while an old serial transaction is
    // still present, force the very next available frame instead of waiting for the normal
    // scan/cooldown cadence. Accessibility consensus can confirm the switch immediately.
    private volatile String urgentTransitionIdentity = "";
    private volatile long urgentTransitionUntil;
    // A fresh qualifying top can interrupt a pending Reject without waiting for its
    // Android callback; do not poll the indexed first-shot reader on every 12ms tick.
    private volatile long lastRejectPriorityProbeAt;
    private volatile long lastQualifiedRejectProbeEventAt;
    // A server-terminal loss such as "offer unavailable" must never trigger local retries.
    // Keep the top card locked until it disappears, but suppress new Accept attempts briefly.
    private volatile String terminalLossIdentity = "";
    private volatile long terminalLossUntil;
    // v2.10.109: DeliverThat sometimes emits "offer unavailable" before replacing the offer
    // with this device's assigned-job detail. Keep a short observation-only bridge so the
    // matching Job page can correct that ambiguous terminal result and start Back -> Offers.
    // It never authorizes another Accept and is cancelled by any newer action transaction.
    private volatile String postTerminalVerifyOfferText = "";
    private volatile long postTerminalVerifyActionAt;
    private volatile long postTerminalVerifyUntil;
    private volatile int postTerminalVerifyJobsBaseline = -1;
    private static final long POST_TERMINAL_JOB_VERIFY_MS = 10_000L;
    private static final long POST_TERMINAL_JOB_VERIFY_POLL_MS = 160L;
    // v2.10.129: Begin Delivery can be painted briefly while DeliverThat is still reconciling
    // an offer-unavailable race. Treat the first sighting as a candidate, freeze every
    // unavailable clear/return action, and require a stable live CTA before announcing success.
    // A Jobs badge rise lets the candidate commit sooner; builds without an exported badge can
    // still commit after a longer continuously-visible Begin Delivery interval.
    private volatile String postTerminalSuccessCandidateText = "";
    private volatile String postTerminalSuccessCandidateEvidence = "";
    private volatile long postTerminalSuccessCandidateFirstAt;
    private volatile long postTerminalSuccessCandidateLastVisibleAt;
    private volatile int postTerminalSuccessCandidateVisiblePolls;
    private static final long POST_TERMINAL_SUCCESS_POLL_MS = 260L;
    private static final long POST_TERMINAL_SUCCESS_BADGE_STABLE_MS = 3_000L;
    private static final long POST_TERMINAL_SUCCESS_NO_BADGE_STABLE_MS = 4_200L;
    private static final long POST_TERMINAL_SUCCESS_MISSING_GRACE_MS = 900L;
    // v2.10.120: explicit server-unavailable is already terminal. Give the assigned-job
    // surface one short render window, then leave the dead card in about one second instead of
    // holding the scanner for roughly four seconds. The independent 12s success verifier stays
    // armed and every poll still checks a matching Begin Delivery before any navigation.
    private static final long UNAVAILABLE_RETIRE_DELAY_MS = 160L;
    private static final long UNAVAILABLE_RETIRE_POLL_MS = 90L;
    private static final int UNAVAILABLE_RETIRE_MAX_POLLS = 3;
    // Stay on Jobs long enough for a just-assigned Begin Delivery surface to publish.  Returning
    // after 280 ms raced the React-Native page and hid successful claims behind unavailable.
    // v2.10.130: an ACTION_CLICK acknowledgement is not navigation completion.  Treat stale-card
    // recovery as one bounded transaction: current Offers evidence completes it, four clicks is
    // the action ceiling, ten seconds is the observation ceiling, and a newer transaction (or
    // leaving DeliverThat) invalidates every queued callback from the older one.
    private static final int UNAVAILABLE_RETURN_MAX_CLICKS = 4;
    private static final long UNAVAILABLE_RETURN_DEADLINE_MS = 1_000L;
    private static final long UNAVAILABLE_RETURN_OBSERVE_MS = 350L;
    private final AtomicLong unavailableReturnEpoch = new AtomicLong();
    private volatile long unavailableNavigationUntil;
    // A React-Native navigation ACTION_CLICK may return true while its stale node does nothing.
    // Keep re-verifying Back -> Offers for a bounded period instead of abandoning the user on
    // the accepted-job page after the first discovery burst.
    private static final long POST_CLAIM_NAVIGATION_WATCHDOG_MS = 10_000L;
    private static final int POST_CLAIM_NAVIGATION_MAX_CLICKS = 3;
    private static final long POST_CLAIM_NAVIGATION_OBSERVE_MS = 300L;
    private static final long ACCEPT_TERMINAL_TRACK_WINDOW_MS = 1100L;
    private static final long ACCEPT_TERMINAL_TRACK_POLL_MS = ActionDispatchPolicy.RETRY_RECHECK_MS;
    private static final long ACCEPT_PAGE_READ_HEAD_START_MS = 12L;
    private static final long ACCEPT_TERMINAL_DEEP_PROBE_AFTER_MS = 320L;
    private static final long ACCEPT_TERMINAL_DEEP_PROBE_GAP_MS = 360L;
    // v2.10.53: foreground UNKNOWN must release immediately so the next Offer can be scanned,
    // but keep a cheap observation-only tail for late server evidence. This tail never OCRs
    // and never authorizes another Accept.
    private static final long ACCEPT_LATE_TAIL_WINDOW_MS = 6000L;
    private static final long ACCEPT_LATE_TAIL_POLL_MS = 240L;
    // v2.10.15: short post-Reject transition window. DeliverThat briefly emits partial/blank
    // OCR frames while the first card is animating/entering countdown; suppress those noisy
    // card#0 records without weakening the top-card lock or Accept path.
    private volatile long rejectTransitionSuppressUntil;
    private final ClaimBudget claimBudget = new ClaimBudget();
    private final RejectSequence rejectSequence = RejectSequence.shared();
    private final ScanTrace scanTrace=new ScanTrace();
    private HandlerThread scanDiagnosticThread;
    private Handler scanDiagnosticWorker;
    private volatile long lastFastScanAt;
    private volatile PipelineTiming lastCompletedFastScan;
    private volatile PipelineTiming lastSlowFastScan;
    private long lastScanSummaryAt;
    private volatile Class<?> lastScanError;
    private volatile QuickReadTrace lastQuickTrace;
    private final FallbackGrace fallbackGrace=new FallbackGrace();

    private static final class FallbackGrace {
        private long firstDeferredAt=-1L;

        boolean defer(boolean requested,long now) {
            if (!requested) return false;
            if (firstDeferredAt<0L || now<firstDeferredAt) firstDeferredAt=now;
            return now-firstDeferredAt<HotOfferScanPolicy.eventYieldMaxMs();
        }

        void attempted() { firstDeferredAt=-1L; }
    }

    private static final class QuickReadTrace {
        final TapAccessibilityService.QuickTopResult result;
        final long startedAt, finishedAt;
        final boolean sameGeneration;

        QuickReadTrace(TapAccessibilityService.QuickTopResult result, long startedAt, long finishedAt,
                       boolean sameGeneration) {
            this.result = result;
            this.startedAt = startedAt;
            this.finishedAt = finishedAt;
            this.sameGeneration = sameGeneration;
        }

        String outcome() {
            if (!sameGeneration) return "UI_CHANGED";
            TapAccessibilityService.FastOfferSnapshot card = result.snapshot;
            if (card != null) return "amount="+card.amount+" miles="+card.miles+" accept="+card.acceptEnabled;
            if (result.emptyContradicted) return "EMPTY_CONTRADICTED";
            return result.emptyOffers && !result.budgetExceeded ? "EMPTY" : "UNREADABLE";
        }

        String timing(long now) {
            return " read_start_ms="+startedAt+" read_end_ms="+finishedAt
                    +" read_duration_ms="+(finishedAt-startedAt)+" result_age_ms="+Math.max(0L,now-finishedAt);
        }

        String summary(long now, long latestScanAt) {
            long age=Math.max(0L,now-finishedAt);
            return " latest_quick_read_elapsed_ms="+finishedAt+" latest_quick_read_age_ms="
                    +age+" quick_in_latest_scan="+(startedAt>=latestScanAt)
                    +" quick_fresh="+(age<=120L && sameGeneration);
        }
    }

    private static final class ScanTrace {
        private static final int LIMIT=180;
        private final java.util.ArrayDeque<String> recent=new java.util.ArrayDeque<>();
        private final java.text.SimpleDateFormat clock=new java.text.SimpleDateFormat(
                "HH:mm:ss.SSS",java.util.Locale.US);
        private final java.util.Map<String,String> lastDescription=new java.util.HashMap<>();
        private final java.util.Map<String,Long> lastTime=new java.util.HashMap<>();

        private QuickReadTrace lastLoggedQuick;
        private PipelineTiming lastLoggedSlowScan;

        synchronized void note(long now,String description) {
            note(now,description,"");
        }

        synchronized void noteQuick(long now, QuickReadTrace reading) {
            if (reading == null || reading == lastLoggedQuick) return;
            // An old cached quick result is NOT evidence of a new quick scan.
            String stage = now-reading.finishedAt>120L ? "QUICK_STALE_DIAGNOSTIC" : "QUICK_RESULT";
            if (noteRead(now,stage,reading)) lastLoggedQuick=reading;
        }

        synchronized void noteSlowScan(long now, long latestScanAt, PipelineTiming timing) {
            if (timing == null || timing == lastLoggedSlowScan) return;
            lastLoggedSlowScan=timing;
            note(now,"SCAN_SLOW"+timing.scanSummary(latestScanAt),"");
        }

        synchronized boolean noteRead(long now, String stage, QuickReadTrace reading) {
            return note(now,stage+" "+reading.outcome()+" limit="+reading.result.limitReason,reading.timing(now));
        }

        private boolean note(long now,String description,String details) {
            int split=description.indexOf(' ');
            String stage=split<0 ? description : description.substring(0,split);
            if (description.equals(lastDescription.get(stage))
                    && now-lastTime.getOrDefault(stage,0L)<1000L) return false;
            lastDescription.put(stage,description);
            lastTime.put(stage,now);
            if (recent.size()==LIMIT) recent.removeFirst();
            recent.addLast(clock.format(new java.util.Date())+" | "+now+" | "+description+details);
            return true;
        }

        synchronized String snapshot() { return String.join("\n",recent); }
    }

    public static String recentLiveScanTrace() {
        OcrMonitorService service=activeInstance;
        return service==null ? "" : service.scanTrace.snapshot();
    }

    private long lastScanHealthAt;
    private final Runnable scanDiagnosticCheck = new Runnable() {
        @Override public void run() {
            if (!monitorReady) return;
            long nextDelay=200L;
            try {
                long latestScanAt=lastFastScanAt;
                PipelineTiming completedScan=lastCompletedFastScan;
                QuickReadTrace reading=lastQuickTrace;
                long now=SystemClock.elapsedRealtime();
                if (TapAccessibilityService.hasDeliverThatReplayForegroundHint()) {
                    if (touchScanAllowed(now,unownedInteractionUntil,MANUAL_INTERVENTION_PAUSED.get())) {
                        nextDelay=48L;
                        observeOfferDuringTouch(now);
                    } else if (!isManualInterventionPaused() && latestScanAt>0L
                            && now-lastScanSummaryAt>=1000L) {
                        lastScanSummaryAt=now;
                        scanTrace.note(now,"SCAN_ACTIVE owner="+serialTopAction
                                +" latest_scan_elapsed_ms="+latestScanAt
                                +" latest_scan_age_ms="+Math.max(0L,now-latestScanAt)
                                +(reading==null ? " latest_quick_read_elapsed_ms=UNOBSERVED" : reading.summary(now,latestScanAt))
                                +(completedScan==null ? "" : completedScan.scanSummary(latestScanAt)));
                    }
                }
                if (now-lastScanHealthAt>=1000L) {
                    lastScanHealthAt=now;
                    scanTrace.note(now,"SCAN_HEALTH version="+engineVersion+" code="+engineVersionCode
                            +" session="+engineSessionAt+" "+liveScanHealth.snapshotAndReset(now)
                            +" idle_heartbeats="+idleHeartbeatScans.getAndSet(0L)
                            +" presence_probes="+idlePresenceProbes.getAndSet(0L)
                            +" presence_found="+idlePresencePresent.getAndSet(0L)
                            +" presence_empty="+idlePresenceEmpty.getAndSet(0L)
                            +" presence_unknown="+idlePresenceUnknown.getAndSet(0L)
                            +" presence_last="+idlePresenceLastStatus
                            +" presence_unreadable_ms="+(idlePresenceUnreadableSince>0L
                                ? Math.max(0L,now-idlePresenceUnreadableSince):0L)
                            +" presence_probe_age_ms="+(lastIdlePresenceProbeAt>0L
                                ? Math.max(0L,now-lastIdlePresenceProbeAt) : "UNOBSERVED"));
                }
                scanTrace.noteSlowScan(now,latestScanAt,lastSlowFastScan);
                scanTrace.noteQuick(SystemClock.elapsedRealtime(),reading);
                Class<?> failure=lastScanError;
                if (failure!=null) {
                    lastScanError=null;
                    scanTrace.note(now,"SCAN_ERROR "+failure.getSimpleName());
                }
            } catch (RuntimeException failure) {
                scanTrace.note(SystemClock.elapsedRealtime(),"DIAGNOSTIC_ERROR "+failure.getClass().getSimpleName());
            } finally {
                if (monitorReady && scanDiagnosticWorker!=null)
                    scanDiagnosticWorker.postDelayed(this,nextDelay);
            }
        }
    };

    private static boolean touchScanAllowed(long now,long touchUntil,boolean explicitlyPaused) {
        return !explicitlyPaused && touchUntil-now>=80L;
    }

    private final Runnable continuousCheck = new Runnable() {
        @Override public void run() {
            if (!monitorReady || fastWorker == null) return;
            long delay = HotOfferScanPolicy.heartbeatDelay(false);
            try {
                if (!isManualInterventionPaused())
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
            } catch (RuntimeException failure) {
                // Hawk-inspired liveness fence: one OEM Accessibility exception must not silently
                // kill the only recurring fast check. The next iteration re-enters cleanly.
                delay = 80L;
            } finally {
                Handler lane = fastWorker;
                if (monitorReady && lane != null) lane.postDelayed(this, delay);
            }
        }
    };

    private boolean shouldYieldFallbackToNewEvent() {
        return HotOfferScanPolicy.shouldYieldToNewEvent(fastCheckDirty.get(),
                TapAccessibilityService.recentNumericOfferBurstAge(2500L));
    }

    private boolean shouldDeferBoundedTopRead() {
        return fallbackGrace.defer(shouldYieldFallbackToNewEvent(),SystemClock.elapsedRealtime());
    }

    public static long acceptDispatchObservedAt() {
        OcrMonitorService service = activeInstance;
        return service == null ? 0L : service.acceptDispatchObservationAt;
    }

    /** Cheap atomic/clock work immediately before the actual Android dispatch call. */
    public static void noteAcceptGestureDispatchStarted() {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady || service.serialTopAction != SerialAction.ACCEPT
                || service.serialTopActionAt <= 0L) return;
        service.acceptRetryDispatchPendingAt=SystemClock.elapsedRealtime();
        long epoch = service.claimEpoch.get();
        AcceptOutcomeFence old = service.acceptOutcomeFence;
        // Retries remain part of the first actually dispatched transaction.
        if (old != null && old.actionEpoch == epoch && old.actionAt == service.serialTopActionAt) return;
        PageOutcomePolicy.Baseline baseline = service.preparedPageBaseline;
        long actualDispatch = SystemClock.elapsedRealtime();
        service.dispatchedPageBaseline = baseline;
        service.dispatchedPageBaselineClean = baseline != null && baseline.cleanAt(actualDispatch,
                TapAccessibilityService.outcomeUiGeneration(), TapAccessibilityService.outcomeWindowEpoch());
        service.acceptOutcomeFence = new AcceptOutcomeFence(epoch, service.serialTopActionAt,
                TapAccessibilityService.claimOutcomeEventEpoch(),
                actualDispatch, SystemClock.uptimeMillis());
    }

    /** Cache-only final dispatch guard. A first fresh negative is enough to pause retry,
     * but never enough to declare loss; a clear read or qualified terminal evidence owns that. */
    public static String acceptRetryGuard(long expectedActionAt) {
        OcrMonitorService service=activeInstance;
        if (service==null || !isMonitoring()) return "RETRY_CANCELLED：监控暂停/停止";
        if (service.serialTopAction!=SerialAction.ACCEPT || service.serialTopActionAt<=0L
                || (expectedActionAt>0L && expectedActionAt!=service.serialTopActionAt))
            return "RETRY_TRANSACTION_CHANGED：旧重试任务已失效";
        if (hasBoundAcceptSuccess()) return "RETRY_SUCCESS_OBSERVED：已出现成功证据";
        if (TapAccessibilityService.currentNegativeSurfaceBlocksAccept()) return "RETRY_CURRENT_NEGATIVE_SURFACE";
        String terminal=service.acceptScopedTerminalOutcomeSince(service.serialTopActionAt);
        if (!terminal.isEmpty()) return "RETRY_TERMINAL_OBSERVED："+terminal;
        PageOutcomePolicy.Tracker tracker=service.pageTracker(service.serialTopActionAt);
        if (tracker!=null && tracker.hasFreshDifferentTop(SystemClock.elapsedRealtime()))
            return "RETRY_DIFFERENT_TOP：当前顶部已换单";
        if (tracker!=null && tracker.retryContextBlocked())
            return "RETRY_PAGE_CONTEXT_CHANGED：当前页面已离开原Offer";
        if (tracker!=null && (tracker.hasPendingNegative() || tracker.hasVisibleNegative()))
            return "RETRY_NEGATIVE_PENDING：新鲜失效提示等待复核；暂不发送重试；"+tracker.diagnostic();
        return "";
    }

    public static boolean hasBoundAcceptSuccess() {
        OcrMonitorService service = activeInstance;
        if (service == null || service.serialTopAction != SerialAction.ACCEPT) return false;
        if (TapAccessibilityService.jobsBadgeIncreasedSince(service.pendingAcceptJobsBaseline)) return true;
        AcceptOutcomeFence fence = service.acceptFenceFor(service.serialTopActionAt);
        if (fence == null) fence = service.acceptAdmissionGuardFence;
        String hint = TapAccessibilityService.recentAcceptOutcomeAfter(fence);
        return TapAccessibilityService.isPositiveClaimOutcome(hint)
                && !ClaimSuccessSignals.isJobDetailHint(hint);
    }

    private AcceptOutcomeFence acceptFenceFor(long actionAt) {
        AcceptOutcomeFence fence = acceptOutcomeFence;
        return fence != null && fence.actionAt == actionAt ? fence : null;
    }

    public static void prepareAcceptPageBaseline(PageOutcomePolicy.Baseline baseline) {
        OcrMonitorService service=activeInstance;
        if (service!=null) service.preparedPageBaseline=baseline;
    }

    private synchronized PageOutcomePolicy.Tracker pageTracker(long actionAt) {
        AcceptOutcomeFence fence=acceptFenceFor(actionAt);
        if (fence==null) return null;
        PageOutcomePolicy.Tracker tracker=acceptPageTracker;
        if (tracker==null || tracker.dispatch!=fence.dispatchElapsed) {
            tracker=new PageOutcomePolicy.Tracker(fence.dispatchElapsed,serialTopText,
                    dispatchedPageBaseline,dispatchedPageBaselineClean);
            acceptPageTracker=tracker;
        }
        return tracker;
    }

    private String pageBoundOutcome(long actionAt) {
        PageOutcomePolicy.Tracker tracker=pageTracker(actionAt);
        return tracker==null?"":tracker.bound;
    }

    private String acceptOutcomeDiagnostic(long actionAt) {
        PageOutcomePolicy.Tracker tracker=pageTracker(actionAt);
        return TapAccessibilityService.acceptOutcomeEventDiagnostic(acceptFenceFor(actionAt))
                +(tracker==null?"":"；"+tracker.diagnostic()+"；probe="+acceptPageProbeCount
                        +",valid="+acceptPageValidProbeCount);
    }

    private boolean verifiedAcceptRetryMatches(String text) {
        long actionAt=serialTopActionAt;
        PageOutcomePolicy.Tracker tracker=pageTracker(actionAt);
        return serialTopAction==SerialAction.ACCEPT && actionAt>0 && actionAt==serialTopActionAt
                && tracker!=null && tracker.retryMatches(text);
    }

    private String acceptRetryDecisionText(String original) {
        if(serialTopAction!=SerialAction.ACCEPT || serialTopActionAt<=0
                || !(CardText.sameOffer(serialTopText,original)
                    || OfferEnrichmentPolicy.sameTransaction(serialTopText,original)
                    || verifiedAcceptRetryMatches(original))) return original;
        long actionAt=serialTopActionAt, epoch=claimEpoch.get();
        String ownerText=serialTopText;
        PageOutcomePolicy.Tracker tracker=pageTracker(actionAt);
        String rich=tracker==null?"":tracker.retryDecision(SystemClock.elapsedRealtime());
        if(rich.isEmpty() || !PageOutcomePolicy.compatible(ownerText,rich)
                || serialTopAction!=SerialAction.ACCEPT || serialTopActionAt!=actionAt
                || claimEpoch.get()!=epoch || !serialTopText.equals(ownerText)
                || !claimBudget.bindVerifiedAlias(CardText.identity(ownerText),CardText.identity(rich),
                        SystemClock.elapsedRealtime())) return original;
        if(serialTopAction!=SerialAction.ACCEPT || serialTopActionAt!=actionAt
                || claimEpoch.get()!=epoch || !serialTopText.equals(ownerText)) return original;
        if(!OfferEnrichmentPolicy.sameTransaction(rich,acceptRetryEnrichedText)) {
            acceptRetryEnrichedText=rich;
            acceptReporter(serialTopText).accept("ACCEPT_RETRY_IDENTITY_BOUND：当前完整同卡证据已补全重试身份；沿用原事务和次数；最终点击仍需当前索引复核");
        }
        return rich;
    }

    private void scheduleAcceptPageProbe(long actionAt) {
        scheduleAcceptPageProbe(actionAt, false);
    }

    private void scheduleAcceptPageProbe(long actionAt, boolean offerWake) {
        Handler probeWorker=acceptOutcomeWorker!=null?acceptOutcomeWorker:fastWorker;
        AcceptOutcomeFence fence=acceptFenceFor(actionAt);
        long now=SystemClock.elapsedRealtime();
        PageOutcomePolicy.Tracker scheduledTracker=pageTracker(actionAt);
        if (fence==null || probeWorker==null || scheduledTracker==null
                || !scheduledTracker.mayProbeContinuous(now)) return;
        final String probeText=serialTopText;
        Runnable probe = new Runnable() {
          @Override public void run() {
            synchronized (acceptPageProbeScheduleLock) {
                if (pendingAcceptPageProbe!=this) return;
                pendingAcceptPageProbe=null;
                pendingAcceptPageProbeOwner=0L;
            }
            try {
                if (!monitorReady || acceptOutcomeFence!=fence || serialTopAction!=SerialAction.ACCEPT
                        || serialTopActionAt!=actionAt) return;
                if (!scheduledTracker.mayProbeContinuous(SystemClock.elapsedRealtime())) return;
                acceptPageProbeCount++;
                PageOutcomePolicy.Reading reading;
                acceptPageReadOwner=actionAt;
                acceptPageReadActiveAt=SystemClock.elapsedRealtime();
                try {
                    reading=TapAccessibilityService.sampleAcceptPageOutcome(() ->
                        monitorReady && acceptOutcomeFence==fence && serialTopAction==SerialAction.ACCEPT
                                && serialTopActionAt==actionAt);
                } finally {acceptPageReadActiveAt=0L;acceptPageReadOwner=0L;}
                PageOutcomePolicy.Tracker tracker=scheduledTracker;
                // Publish page evidence under the same short commit lock as foreground release.
                // Sampling stays outside this lock; UNKNOWN cannot overtake a completed proof.
                synchronized (OcrMonitorService.this) {
                    if (!monitorReady || acceptOutcomeFence!=fence || serialTopAction!=SerialAction.ACCEPT
                            || serialTopActionAt!=actionAt) return;
                    if (tracker!=null) {
                        long observedAt=SystemClock.elapsedRealtime();
                        preserveVisibleAcceptLoading(actionAt,tracker,observedAt);
                        tracker.observe(reading,observedAt);
                        acceptPageValidProbeCount=tracker.validReads;
                    }
                }
                if(tracker!=null && tracker.hasConfirmedOwnedSuccess()) {
                    synchronized(OcrMonitorService.this) {
                        if(!monitorReady || acceptOutcomeFence!=fence || serialTopAction!=SerialAction.ACCEPT
                                || serialTopActionAt!=actionAt) return;
                        confirmPendingClaimSuccess(probeText,"OWNED_DETAIL_CONFIRMED:本单金额/里程/取餐时间连续读取匹配");
                    }
                    return;
                }
                if(tracker!=null && reading!=null && !tracker.pressureBlockReason().isEmpty())
                    pauseAcceptPressureForContext(actionAt,tracker.pressureBlockReason(),reading.end);
                if(tracker!=null && tracker.hasFreshUnboundPrompt(SystemClock.elapsedRealtime()) && fastWorker!=null) {
                    final long promptEpoch=claimEpoch.get();
                    fastWorker.postAtFrontOfQueue(() -> expireUnboundAcceptOutcome(probeText,promptEpoch,actionAt));
                }
                if (tracker!=null && (!tracker.bound.isEmpty()
                        || tracker.hasFreshDifferentTop(SystemClock.elapsedRealtime())))
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                else if(tracker!=null && tracker.shouldWakeEnabledRecheck(SystemClock.elapsedRealtime())
                        && fastWorker!=null) {
                    final long wakeEpoch=claimEpoch.get();
                    if(reading!=null && "ENABLED".equals(reading.actionState))
                        scheduleEnabledClaimInspection(probeText,wakeEpoch,reading.end);
                    else scheduleClaimInspection(probeText,wakeEpoch,0,0,0L);
                }
                String detail=tracker==null?"NO_TRACKER":tracker.diagnostic();
                acceptReporter(probeText).accept("ACCEPT_PAGE_OUTCOME_PROBE：读取="+acceptPageProbeCount
                        +"；持续观察，无总次数/时长上限；有效="+acceptPageValidProbeCount+"；"+detail
                        +(reading==null?"；read=NONE":"；read="+reading.reason+"；读取耗时="
                                +(reading.end-reading.start)+"ms；queries="+reading.queries+"；nodes="+reading.nodes
                                +"；ACCEPT_NODE="+reading.actionState
                                +(reading.evidenceDetail.isEmpty()?"":"；READ_DETAIL="+reading.evidenceDetail)
                                +"；RETRY_GATE="+tracker.retryDiagnostic(SystemClock.elapsedRealtime())
                                +("UI_CHANGED".equals(reading.reason)?"；UI_EVENT="+TapAccessibilityService.uiMutationDiagnostic():"")));
            } finally {
                acceptPageProbeQueued.set(false);
                if (monitorReady && serialTopAction==SerialAction.ACCEPT) {
                    long activeOwner = serialTopActionAt;
                    if (activeOwner != actionAt || (acceptOutcomeFence == fence && pageBoundOutcome(actionAt).isEmpty()))
                        scheduleAcceptPageProbe(activeOwner);
                }
            }
          }
        };
        synchronized (acceptPageProbeScheduleLock) {
            long pressureHeadStart=ActionDispatchPolicy.initialOutcomeReadDelayMs(
                    acceptPressureActive(actionAt),fence.dispatchElapsed,now);
            if (!acceptPageProbeQueued.compareAndSet(false,true)) {
                Runnable pending=pendingAcceptPageProbe;
                if (offerWake && pressureHeadStart==0L && pending!=null && pendingAcceptPageProbeOwner==actionAt) {
                    probeWorker.removeCallbacks(pending);
                    if (!probeWorker.postAtFrontOfQueue(pending)) {
                        pendingAcceptPageProbe=null;
                        pendingAcceptPageProbeOwner=0L;
                        acceptPageProbeQueued.set(false);
                    }
                }
                return;
            }
            if (acceptPageProbeStartedAt<=0) acceptPageProbeStartedAt=now;
            pendingAcceptPageProbe=probe;
            pendingAcceptPageProbeOwner=actionAt;
            boolean posted=offerWake && pressureHeadStart==0L ? probeWorker.postAtFrontOfQueue(probe)
                    : probeWorker.postDelayed(probe,Math.max(pressureHeadStart,
                            scheduledTracker.nextContinuousProbeDelayMs(acceptPageProbeCount,now)));
            if (!posted) {
                pendingAcceptPageProbe=null;
                pendingAcceptPageProbeOwner=0L;
                acceptPageProbeQueued.set(false);
            }
        }
    }

    private void noteUnboundAcceptOutcome(long actionAt, String evidence) {
        if (serialTopAction != SerialAction.ACCEPT || serialTopActionAt != actionAt) return;
        PageOutcomePolicy.Tracker tracker=pageTracker(actionAt);
        if(tracker!=null) tracker.requestDepartureOutcomeProbe(SystemClock.elapsedRealtime());
        scheduleAcceptPageProbe(actionAt);
        if (ignoredAcceptOutcomeActionAt == actionAt) return;
        ignoredAcceptOutcomeActionAt = actionAt;
        offerReporter(serialTopText).accept("ACCEPT_OUTCOME_UNBOUND_PENDING：失效提示暂无本次新事件；正在核验新鲜页面变化；"
                + "保留当前事务，不写入失效标记、不返回Offers；提示=" + evidence + "；"
                + TapAccessibilityService.acceptOutcomeEventDiagnostic(acceptFenceFor(actionAt)));
        long epoch = claimEpoch.get();
        String text = serialTopText;
        if (fastWorker != null)
            fastWorker.postDelayed(() -> expireUnboundAcceptOutcome(text, epoch, actionAt), 1_800L);
    }

    private void expireUnboundAcceptOutcome(String text, long epoch, long actionAt) {
        if (!monitorReady || claimEpoch.get() != epoch || serialTopAction != SerialAction.ACCEPT
                || serialTopActionAt != actionAt) return;
        String terminal = acceptScopedTerminalOutcomeSince(actionAt);
        if (!terminal.isEmpty()) { finishPendingClaimLoss(text, terminal, true); return; }
        String positive = acceptScopedOutcomeSince(actionAt);
        if (isBoundPositiveClaimOutcome(text, positive, actionAt)
                || TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
            confirmPendingClaimSuccess(text, positive.isEmpty() ? "Jobs徽标已增加" : positive);
            return;
        }
        if (!pendingJobDetailCandidateIdentity.isEmpty()) return; // existing candidate watchdog owns it
        // Missing event ownership is UNKNOWN, never a server loss. Release the lane without
        // tombstoning, clearing the card or forcing navigation away from a possibly claimed job.
        finishPendingClaimLoss(text, "失效提示缺少新事件或新鲜页面变化证据；归属未确认，保留后台观察", false);
    }

    private String acceptScopedTerminalOutcomeSince(long actionAt) {
        String bound = TapAccessibilityService.recentAcceptTerminalOutcomeAfter(acceptFenceFor(actionAt));
        if (bound.isEmpty()) bound = pageBoundOutcome(actionAt);
        if (bound.isEmpty()) bound = visualBoundOutcome(actionAt);
        if (bound.isEmpty()) {
            String unbound = TapAccessibilityService.recentTerminalNegativeClaimOutcomeSince(actionAt);
            if (!unbound.isEmpty()) noteUnboundAcceptOutcome(actionAt, unbound);
        }
        return bound;
    }

    private String acceptScopedOutcomeSince(long actionAt) {
        String bound = TapAccessibilityService.recentAcceptOutcomeAfter(acceptFenceFor(actionAt));
        if (bound.isEmpty()) bound = pageBoundOutcome(actionAt);
        if (bound.isEmpty()) bound = visualBoundOutcome(actionAt);
        if (!bound.isEmpty()) return bound;
        String cached = TapAccessibilityService.recentCachedClaimOutcomeSince(actionAt);
        if (TapAccessibilityService.isTerminalNegativeClaimOutcome(cached))
            noteUnboundAcceptOutcome(actionAt, cached);
        // Generic Job-detail surfaces have their separate identity/stability proof. A cached
        // success/failure sentence alone cannot be assigned to the current click.
        return "";
    }

    private boolean canCommitAcceptTerminalLoss(String originalText, String evidence) {
        if (hasBoundAcceptSuccess() || TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline))
            return false;
        if (!acceptScopedTerminalOutcomeSince(serialTopActionAt).isEmpty()) return true;
        noteUnboundAcceptOutcome(serialTopActionAt, evidence);
        long epoch = claimEpoch.get();
        if (fastWorker != null) scheduleClaimInspection(originalText, epoch, 0, 0, 120L);
        return false;
    }

    /** Called only after Android accepted an Accept dispatchGesture() request. */
    public static void noteAcceptGestureDispatched() {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady
                || service.serialTopAction != SerialAction.ACCEPT
                || service.serialTopActionAt <= 0 || service.serialTopText.isEmpty()) return;
        long dispatchedAt = SystemClock.elapsedRealtime();
        if (service.acceptDispatchObservationAt <= 0L) service.acceptDispatchObservationAt = dispatchedAt;
        final long actionAt = service.serialTopActionAt;
        service.acceptAudit.dispatched(actionAt,dispatchedAt);
        service.acceptControlEnabledActionAt=0L;service.acceptControlEnabledAt=0L;
        final String observedText = service.serialTopText;
        final String observedTiming = service.scanTiming;
        final boolean emitAck = service.acceptDispatchAckReportedForActionAt != actionAt;
        if (emitAck) {service.acceptDispatchAckReportedForActionAt = actionAt;
            service.acceptTimingText=observedText;service.acceptTransactionTiming=observedTiming;}
        // The first accepted send starts outcome tracking. Repeated ACKs during
        // active pressure do not restart the existing continuous observation lane.
        // Real structural, Spinner and terminal events still wake independently.
        if (emitAck || !service.acceptPressureActive(actionAt)) {
            service.requestImmediateFastCheck(dispatchedAt);
            service.scheduleAcceptPageProbe(actionAt);
            TapAccessibilityService.startAcceptControlWatch(observedText,actionAt);
        }
        service.acceptReplay.dispatched(service.worker, actionAt, dispatchedAt,
                emitAck ? TapAccessibilityService.recentFirstSeenAt(CardText.identity(observedText), 8_000L) : 0L);
        if (emitAck) {
            service.logWriter.execute(() -> service.offerReporterWithTiming(observedText, observedTiming).accept(
                    "ACCEPT_DISPATCH_ACCEPTED：Android已接受Accept手势发送；已立即进入服务器终态追踪；非接单确认"
                    + service.acceptStageTiming(observedText, CardText.identity(observedText), dispatchedAt)
                    + "；DISPATCH_ELAPSED="+dispatchedAt+"；首见口径=本机可读数值"));
        }
        // Completion is the normal next-send handoff, including the first multi-stroke batch.
        // A watchdog is only for a genuinely missing callback after the existing 160ms lease.
        // Old watchdogs cannot wake a newer send; terminal and spinner fences still apply.
        if (service.acceptPressureActive(actionAt)) {
            final long pressureEpoch = service.pressureEpoch;
            final int sentCount = service.acceptAudit.sendsFor(actionAt);
            Handler clicks = service.acceptClickWorker;
            if (clicks != null) clicks.postDelayed(() -> {
                if (service.serialTopActionAt != actionAt
                        || service.claimEpoch.get() != pressureEpoch
                        || !service.acceptPressureActive(actionAt)
                        || service.acceptAudit.sendsFor(actionAt)!=sentCount
                        || service.hasSpinnerCandidate(actionAt)
                        || ActionDispatchPolicy.retryInFlight(
                                SystemClock.elapsedRealtime(), service.acceptRetryDispatchPendingAt)) return;
                service.scheduleAcceptPressure(actionAt, pressureEpoch);
            }, 172L);
        }
        // dispatchGesture()==true starts outcome tracking immediately, independently
        // of the OEM completion callback.
    }

    private void noteAcceptGestureCompleted() {
        if (serialTopAction == SerialAction.ACCEPT && serialTopActionAt > 0L) {
            acceptRetryDispatchPendingAt=0L;
            acceptGestureCompletedAt = SystemClock.elapsedRealtime();
            acceptReplay.event(acceptGestureCompletedAt, "GESTURE_COMPLETED tx=" + serialTopActionAt);
        }
    }

    private boolean acceptGestureCompletedForCurrentTransaction() {
        return serialTopAction == SerialAction.ACCEPT && serialTopActionAt > 0L
                && acceptGestureCompletedAt >= serialTopActionAt;
    }

    private boolean acceptGestureDispatchedForCurrentTransaction() {
        return serialTopAction == SerialAction.ACCEPT && serialTopActionAt > 0L
                && acceptDispatchObservationAt >= serialTopActionAt;
    }

    public static void noteForegroundOfferDemand(String text) {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady || !RejectDemandPolicy.coherent(text)) return;
        for (RejectConfirmState state : service.rejectConfirmStates.values()) {
            if (service.rejectTerminalGate.isCurrent(state.id, state.token)
                    && RejectDemandPolicy.sameOrUnprovenOwned(state.text, text)) return;
        }
        long now=SystemClock.elapsedRealtime();
        foregroundOfferDemandAt.set(now);
        String identity=CardText.identity(text);
        long seen=TapAccessibilityService.recentFirstSeenAt(identity, 8_000L);
        if (seen>0L && seen<=now) {
            service.lastNumericWake.updateAndGet(old -> old!=null && (old.wakeAt>now
                    || old.identity.equals(identity) && old.firstSeen==seen)
                    ? old : new NumericWake(identity,seen,now));
        }
    }

    /**
     * v2.10.107 main-thread bypass. Used only to decide whether an Accessibility event needs
     * synchronous ancestor enrichment; it never authorizes a gesture. The worker still proves
     * a CURRENT enabled Accept and the exact same amount+mileage before dispatch.
     */
    public static boolean eventNumbersUniversallyQualified(String eventText) {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady || eventText == null) return false;
        float amount = CardText.amount(eventText);
        float miles = CardText.miles(eventText);
        return amount >= 0f && miles >= 0f
                && service.universallyQualifiedByNumbers(amount, miles);
    }

    /**
     * v2.10.118 main-thread bypass for Pasadena-group numeric candidates. This only decides
     * whether the Accessibility callback may skip its synchronous parent climb. It never
     * authorizes an action: FIRST_PUBLISH_PASADENA_INDEXED still has to bind the exact current
     * amount+mileage to a current Pasadena-group endpoint and enabled Accept before dispatch.
     */
    public static boolean eventNumbersPasadenaIndexCandidate(String eventText) {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady || eventText == null
                || !service.prefs.getBoolean("pasadenaRuleEnabled", false)) return false;
        float amount = CardText.amount(eventText);
        float miles = CardText.miles(eventText);
        if (amount < 0f || miles < 0f) return false;
        boolean generalQualified = amount >= service.prefs.getFloat("minPay", 60f)
                && miles <= service.prefs.getFloat("maxMiles", 10f);
        boolean pasadenaNumbersQualified = amount
                        >= service.prefs.getFloat("pasadenaMinPay", 25f)
                && miles <= service.prefs.getFloat("pasadenaMaxMiles", 5f);
        return !generalQualified && pasadenaNumbersQualified;
    }

    public static boolean eventNumbersUniversallyRejected(String eventText) {
        return eventText != null && eventNumbersUniversallyRejected(
                CardText.amount(eventText), CardText.miles(eventText));
    }

    static boolean eventNumbersUniversallyRejected(float amount, float miles) {
        OcrMonitorService service = activeInstance;
        return service != null && service.monitorReady && service.universallyRejectedByNumbers(amount, miles);
    }

    private static boolean foregroundOfferDemandRecent(long maxAgeMs) {
        long seen = foregroundOfferDemandAt.get();
        long now = SystemClock.elapsedRealtime();
        return seen > 0L && now >= seen && now - seen <= Math.max(1L, maxAgeMs);
    }

    /** Cheap cache/event-only screen presence gate. There are NO Binder reads here. */
    private boolean liveOfferSignal(long now) {
        return screenAcceptVisible || foregroundOfferDemandRecent(900L)
                || TapAccessibilityService.recentDecisionEvidence(400L)!=null
                || TapAccessibilityService.recentEventBurstDecisionEvidence(900L)!=null
                || TapAccessibilityService.recentNumericOfferBurstAge(2500L)>=0L;
    }

    /**
     * A regular idle heartbeat monitors *presence*, not amount/miles/action/city.
     * Delayed/budgeted Android reads run off-lane. No new-card/event/visual wake is gated.
     */
    private boolean monitorOnly(long now, boolean structural, boolean priorityOffer) {
        if(structural || priorityOffer || fastStructuralWake.get()
                || serialTopAction!=SerialAction.NONE || fastCheckDirty.get()
                || liveOfferSignal(now)) return false;
        // One cached page-hint read; Jobs/Ignored must never be treated as idle Offers.
        PageGuard.Page page=TapAccessibilityService.recentPageHint();
        return page!=PageGuard.Page.JOBS && page!=PageGuard.Page.IGNORED
                && TapAccessibilityService.hasDeliverThatReplayForegroundHint();
    }

    private void scheduleIdlePresenceProbe() {
        final Handler lane=idlePresenceWorker;
        final long now=SystemClock.elapsedRealtime();
        if(lane==null || now<nextIdlePresenceProbeAt || !idlePresenceQueued.compareAndSet(false,true)) return;
        final long generation=TapAccessibilityService.currentUiGeneration();
        final long epoch=scanGeneration.get();
        final long wakeAt=lastStructuralWakeAt;
        if(!lane.post(() -> {
            try {
                if(!taskEpochCurrent(epoch) || serialTopAction!=SerialAction.NONE
                        || fastStructuralWake.get() || lastStructuralWakeAt!=wakeAt
                        || liveOfferSignal(SystemClock.elapsedRealtime())) return;
                lastIdlePresenceProbeAt=SystemClock.elapsedRealtime();
                idlePresenceProbes.incrementAndGet();
                TapAccessibilityService.OfferPresence presence=
                        TapAccessibilityService.probeCurrentOffersPresence(34L,
                          () -> taskEpochCurrent(epoch) && serialTopAction==SerialAction.NONE
                             && lastStructuralWakeAt==wakeAt && !fastStructuralWake.get()
                             && !liveOfferSignal(SystemClock.elapsedRealtime()));
                idlePresenceLastStatus = TapAccessibilityService.lastPresenceProbeDetail();
                if(!taskEpochCurrent(epoch) || generation!=TapAccessibilityService.currentUiGeneration()
                        || lastStructuralWakeAt!=wakeAt || liveOfferSignal(SystemClock.elapsedRealtime()))
                    return; // Stale probe never starts a click.
                if (rejectSequence.hasReorderedDepartures(SystemClock.elapsedRealtime()))
                    rejectSequence.observeReorderedEmpty(presence==TapAccessibilityService.OfferPresence.EMPTY,
                            generation,lastIdlePresenceProbeAt,SystemClock.elapsedRealtime(),120L);
                // A live heartbeat is not proof of a readable screen. Make sustained failure visible,
                // but never guess an empty page or tap through an unknown/foreign root.
                long observedAt=SystemClock.elapsedRealtime();
                if (presence==TapAccessibilityService.OfferPresence.UNKNOWN) {
                    if (idlePresenceUnreadableSince==0L) idlePresenceUnreadableSince=observedAt;
                    if (!idlePresenceDegraded && observedAt-idlePresenceUnreadableSince>=2000L) {
                        idlePresenceDegraded=true;
                        updateStatus("监控心跳运行；当前页面持续不可读："+idlePresenceLastStatus+"；请检查DeliverThat前台及无障碍服务");
                    }
                } else {
                    idlePresenceUnreadableSince=0L;
                    if (idlePresenceDegraded) {
                        idlePresenceDegraded=false;
                        updateStatus("当前页面读取已恢复："+presence);
                    }
                }
                switch(presence) {
                    case PRESENT:
                        idlePresencePresent.incrementAndGet();
                        // Re-enter live numeric+button proof with a structural priority wake.
                        requestImmediateFastCheck(SystemClock.uptimeMillis(),true);
                        break;
                    case JOBS_EMPTY:
                    case IGNORED_EMPTY:
                    case JOBS_LIST:
                    case IGNORED_LIST:
                        // Same-generation evidence only. The foreground fast lane validates the
                        // live hub + selected other tab again before its one Offers click.
                        TapAccessibilityService.recordIdleOtherTabHint(presence);
                        requestImmediateFastCheck(SystemClock.uptimeMillis(),true);
                        break;
                    case EMPTY:
                        idlePresenceEmpty.incrementAndGet();break;
                    default:
                        idlePresenceUnknown.incrementAndGet();break;
                }
            } finally {
                // The 12ms heartbeat never blocks on this budget or the OEM Binder call.
                nextIdlePresenceProbeAt=SystemClock.elapsedRealtime()+48L;
                idlePresenceQueued.set(false);
            }
        })) idlePresenceQueued.set(false);
    }

    public static void requestImmediateFastCheck(long eventTime) {
        requestImmediateFastCheck(eventTime,false);
    }

    static int acceptFirstGestureMode() {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady) return ActionDispatchPolicy.SINGLE;
        return ActionDispatchPolicy.gestureMode(service.prefs.getInt("acceptGestureMode",
                service.prefs.getBoolean("threeTapFirstGesture", false) ? 2 : 0));
    }

    static void noteAcceptGesturePlan(long owner, long callAt, long ackAt, String plan) {
        OcrMonitorService service = activeInstance;
        if (service != null && service.serialTopActionAt == owner)
            service.acceptReplay.event(ackAt, "GESTURE_PLAN tx="+owner+" call="+callAt+" ack="+ackAt+" "+plan);
    }

    public static void noteReplayDiscovery(long at, String stage) {
        OcrMonitorService service = activeInstance;
        if (service != null && service.monitorReady) service.acceptReplay.markDiscovery(at, stage);
    }

    public static void requestImmediateFastCheck(long eventTime,boolean structuralOfferWake) {
        requestImmediateFastCheck(eventTime, structuralOfferWake, 0L);
    }

    static void requestImmediateFastCheck(long eventTime, boolean structuralOfferWake, long eventReceivedAt) {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady || isManualInterventionPaused()
                || service.fastWorker == null) return;
        boolean firstWake = false;
        if (structuralOfferWake) {
            firstWake = !service.fastStructuralWake.getAndSet(true);
            if (firstWake) {
                long signalAt = SystemClock.elapsedRealtime();
                service.lastStructuralWakeAt = signalAt;
                long eventAge = Math.max(0L, SystemClock.uptimeMillis() - eventTime);
                if (eventAge <= 1_200L) service.acceptReplay.markDiscovery(signalAt - eventAge,
                        eventReceivedAt > 0L ? "A11Y_EVENT_TIMESTAMP" : "OFFER_WAKE_SIGNAL");
                if (eventReceivedAt > 0L)
                    service.acceptReplay.markDiscovery(eventReceivedAt, "A11Y_CALLBACK_ENTRY");
                service.acceptReplay.markDiscovery(signalAt, "OFFER_WAKE_REQUEST");
            }
            if (service.serialTopAction == SerialAction.ACCEPT)
                service.scheduleAcceptPageProbe(service.serialTopActionAt, true);
        }
        if (!service.fastCheckQueued.compareAndSet(false, true)) {
            service.fastCheckDirty.set(true);
            // Promote a heartbeat scan that is queued but has not entered the worker.
            // The callback must still claim its slot when it runs; a racing copy is inert.
            Handler lane=service.fastWorker;
            Runnable waiting=service.pendingFastCheck.get();
            boolean freshOfferEvent = eventReceivedAt > 0L && foregroundOfferDemandRecent(32L);
            if ((structuralOfferWake || freshOfferEvent) && lane!=null && waiting!=null) {
                lane.removeCallbacks(waiting);
                if (!lane.postAtFrontOfQueue(waiting) && service.pendingFastCheck.compareAndSet(waiting,null))
                    service.fastCheckQueued.set(false);
            }
            return;
        }
        final long queuedAt = SystemClock.elapsedRealtime();
        final long taskEpoch = service.scanGeneration.get();
        boolean structuralWakePending = service.fastStructuralWake.getAndSet(false);
        TapAccessibilityService.DecisionEvidence priorityEvidence = structuralWakePending ? null
                : TapAccessibilityService.recentEventBurstDecisionEvidence(650L);
        if (structuralWakePending) service.acceptReplay.markDiscovery(queuedAt, "FAST_SCAN_QUEUED");
        // A newly published qualifying offer also outranks an old in-flight Reject.
        // Keep the Accept owner exclusive; only a Reject may be preempted.
        boolean priorityOffer = (service.serialTopAction == SerialAction.NONE
                    || service.serialTopAction == SerialAction.REJECT)
                && (structuralWakePending || foregroundOfferDemandRecent(32L)
                || SystemClock.elapsedRealtime() < service.cancelledAcceptPriorityUntil
                || (priorityEvidence != null && service.universallyQualifiedByNumbers(
                        priorityEvidence.amount, priorityEvidence.miles))
                || service.pasadenaNumericCandidate(priorityEvidence));
        Runnable fastAction = new Runnable() {
          @Override public void run() {
            if (!service.pendingFastCheck.compareAndSet(this,null)) return;
            boolean structural = structuralWakePending | service.fastStructuralWake.getAndSet(false);
            long enteredAt=SystemClock.elapsedRealtime();
            long precedingScanAt=service.lastFastScanAt;
            service.lastFastScanAt=enteredAt;
            service.liveScanHealth.enter(enteredAt,queuedAt,
                    structural ? service.lastStructuralWakeAt : 0L,precedingScanAt);
            service.decisionPipelineStartedAt.set(enteredAt);
            service.decisionQueueAt.set(queuedAt);
            service.decisionWakeAt.set(structural ? service.lastStructuralWakeAt : 0L);
            if (structural)
                service.acceptReplay.markDiscovery(enteredAt, "FAST_SCAN_STARTED queueMs="+(enteredAt-queuedAt));
            PipelineTiming timing = new PipelineTiming(enteredAt);
            service.decisionStageTiming.set(timing);
            String scanExit = "PATH_RETURNED";
            try {
            if (!service.taskEpochCurrent(taskEpoch)) {
                service.noteStaleTaskDrop();
                scanExit = "STALE_AT_ENTRY";
                // Preserve the structural wake across a transaction generation change.
                if (structural && service.monitorReady && !isManualInterventionPaused()) {
                    service.fastStructuralWake.set(true);
                    service.fastCheckDirty.set(true);
                }
                return;
            }
            long now = SystemClock.elapsedRealtime();

            // A post-unavailable Begin Delivery candidate owns the screen until its dedicated
            // stability poll either commits or records a server rollback. Keep the ordinary
            // offer lane completely passive so no concurrent scan/navigation can hide the CTA.
            if (!service.postTerminalSuccessCandidateText.isEmpty()) {
                scanExit = "OUTCOME_OWNS_PAGE";
                return;
            }

            // v2.10.34: a Large Order info tooltip can cover the action row. While a recent
            // Accessibility/OCR event says it is visible, never send Accept/Reject. A bounded
            // tree confirmation prevents a stale hint from pausing the lane after the X closes.
            if (TapAccessibilityService.largeOrderPopupRecentlyVisible(1200L)
                    && TapAccessibilityService.isLargeOrderInfoPopupVisible()) {
                service.rejectTransitionSuppressUntil = Math.max(
                        service.rejectTransitionSuppressUntil, now + 700L);
                return;
            }

            // v2.10.298 ACCEPT_FIRST: the old Reject may still be awaiting an Android
            // callback when a qualified new top appears. Check the CURRENT indexed Accept
            // row first on a fresh offer wake, preempt Reject and dispatch in this scan.
            // A pending ACCEPT remains exclusive so an unqualified card cannot interrupt it.
            if (service.preemptRejectForQualifiedTop(now, structural, priorityOffer)) {
                scanExit = "QUALIFIED_ACCEPT_PREEMPTED_REJECT";
                return;
            }
            if (service.handlePendingSerialFast(now)) { scanExit = "IN_FLIGHT_ACTION"; return; }
            if (service.handlePostClaimIsolationFast(now)) { scanExit = "POST_CLAIM_ISOLATION"; return; }
            if (service.recoverOffersPage(now)) { scanExit = "RETURNING_TO_OFFERS"; return; }
            if (now < service.cooldownUntil) { scanExit = "COOLDOWN"; return; }

            // v2.10.293 PRESENCE_FIRST: do not walk 4 numeric/action indexes plus
            // Quick/Full trees when regular monitoring has no actual offer signal.
            // New structural events, numeric evidence, and visible CTA skip this gate.
            if(service.monitorOnly(now,structural,priorityOffer)) {
                service.idleHeartbeatScans.incrementAndGet();
                service.scheduleIdlePresenceProbe();
                scanExit="IDLE_PRESENCE_MONITOR";
                return;
            }
            long scanUiGeneration=TapAccessibilityService.currentUiGeneration();
            service.noteDecisionStage("preflight");
            TapAccessibilityService.DecisionEvidence ownedFrame =
                    TapAccessibilityService.recentDecisionEvidence(120L);
            if (!structural && ownedFrame != null && ownedFrame.capturedAt <= now
                    && !foregroundOfferDemandRecent(240L)) {
                RejectConfirmState owner = service.rejectConfirmStates.get(ownedFrame.identity);
                // Coalesce only the initial redraw of a fully identified, active Reject.
                // A structural wake or new-card demand must always reach the live read.
                if (owner != null && now >= owner.actionAt && now - owner.actionAt < 120L
                        && ownedFrame.uiGeneration == TapAccessibilityService.currentUiGeneration()
                        && service.rejectTerminalGate.isCurrent(owner.id, owner.token)
                        && !OfferEnrichmentPolicy.endpointKey(ownedFrame.text).isEmpty()
                        && (!OfferEnrichmentPolicy.pickupKey(ownedFrame.text).isEmpty()
                            || !CardText.orderId(ownedFrame.text).isEmpty())
                        && OfferEnrichmentPolicy.sameTransaction(owner.text, ownedFrame.text)) return;
            }
            // Fresh same-generation evidence for a Spinner-acknowledged redraw may
            // skip redundant exactReject/index/Quick work on a regular heartbeat only.
            // Structural/priority events and new numeric demand always bypass this gate.
            if (!structural && !priorityOffer && !service.fastCheckDirty.get()
                    && !service.fastStructuralWake.get() && !foregroundOfferDemandRecent(240L)
                    && ownedFrame!=null && ownedFrame.capturedAt<=now
                    && now-ownedFrame.capturedAt<=48L && ownedFrame.uiGeneration==scanUiGeneration
                    && service.rejectSequence.acknowledgedRedraw(ownedFrame.text,now)
                    && (service.universallyRejectedByNumbers(ownedFrame.amount,ownedFrame.miles)
                        || (service.quickDecisionTextComplete(ownedFrame.text,ownedFrame.amount,ownedFrame.miles)
                            && !service.fastRuleFailure(ownedFrame.text,ownedFrame.amount,ownedFrame.miles).isEmpty()))) {
                service.scheduleIdlePresenceProbe();
                scanExit="REJECT_ACK_REDRAW_COALESCED";
                return;
            }
            service.noteDecisionStage("ownerGate");
            StringBuilder rejectRoute = new StringBuilder();

            // v2.10.65 UNIVERSAL_NUMERIC_FAST: when the live numeric pair already passes
            // the General base rule, location cannot change the Accept result. Pasadena is an
            // additional lower-threshold branch; it never invalidates a General-qualified offer. If city filtering and time filtering are disabled, use a
            // cheap semantic Accept lookup that re-proves the CURRENT amount+mileage and
            // current enabled Accept rectangle. This is especially for $60+ short-mile offers
            // such as the real $140.40/3mi trace, where waiting for address/full-tree evidence
            // cost ~260ms before the first gesture. Reject behavior is never handled here.
            TapAccessibilityService.DecisionEvidence universalEvidence =
                    TapAccessibilityService.recentEventBurstDecisionEvidence(650L);
            if ((universalEvidence == null || universalEvidence.amount < 0 || universalEvidence.miles < 0)
                    && now <= service.largeOrderResumeUntil
                    && service.largeOrderResumeEvidence != null) {
                universalEvidence = service.largeOrderResumeEvidence;
            }

            long exactRejectReadGeneration=-1L;
            // v2.10.122 CURRENT_REJECT_EXACT_FIRST: low offers were still paying for the
            // generic Accept index plus a 50-150ms quick tree (and occasionally a full tree)
            // before Reject. Query the CURRENT top Reject and exact numeric pair directly.
            // If every numeric branch fails, city cannot rescue the offer. Otherwise a fresh,
            // complete event may supply the unchanged city/time rule fields only after this
            // live Reject row independently re-proves the exact pair.
            if (universalEvidence != null && universalEvidence.uiGeneration == scanUiGeneration
                    && service.prefs.getBoolean("autoIgnore", true)) {
                boolean finalNumericReject = service.universallyRejectedByNumbers(
                        universalEvidence.amount, universalEvidence.miles);
                boolean completeEventReject = !finalNumericReject
                        && service.quickDecisionTextComplete(universalEvidence.text,
                        universalEvidence.amount, universalEvidence.miles)
                        && !service.fastRuleFailure(universalEvidence.text,
                        universalEvidence.amount, universalEvidence.miles).isEmpty();
                if ((finalNumericReject || completeEventReject)
                        && !service.rejectSequence.proofRefreshPending(CardText.identity(universalEvidence.text),
                                universalEvidence.text, now)
                        && scanUiGeneration == TapAccessibilityService.currentUiGeneration()) {
                    long rejectExactStarted = SystemClock.elapsedRealtime();
                    long rejectExactGeneration=TapAccessibilityService.currentUiGeneration();
                    TapAccessibilityService.FastOfferSnapshot currentReject =
                            TapAccessibilityService.getBoundedNumericRejectSnapshot(
                                    universalEvidence.amount, universalEvidence.miles,finalNumericReject,
                                    service.decisionNeedsOfferTimeEvidence(),
                                    () -> service.taskEpochCurrent(taskEpoch) && !service.fastStructuralWake.get());
                    long rejectExactMs = SystemClock.elapsedRealtime() - rejectExactStarted;
                    service.noteDecisionStage("exactReject");
                    rejectRoute.append("；ExactReject=").append(TapAccessibilityService.routingReadTrace());
                    if ((currentReject != null
                            || "NUMERIC_NO_REJECT_ACTION".equals(TapAccessibilityService.routingReadTrace()))
                            && rejectExactGeneration == TapAccessibilityService.currentUiGeneration())
                        exactRejectReadGeneration=rejectExactGeneration;
                    if (!service.taskEpochCurrent(taskEpoch)) {
                        service.noteStaleTaskDrop();
                        return;
                    }
                    if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                    TapAccessibilityService.FastOfferSnapshot fusedReject =
                            service.fuseCurrentNumericRejectEvidence(
                                    currentReject, universalEvidence, completeEventReject);
                    if (fusedReject != null) {
                        service.scanTiming = "排队" + (now - queuedAt)
                                + "ms；CURRENT_REJECT_EXACT_FIRST " + rejectExactMs
                                + "ms；当前Reject+精确数值"
                                + (completeEventReject ? "+新鲜完整规则字段" : "+数值必拒")
                                + "；跳过Accept索引/快速树/完整树";
                        boolean handled = finalNumericReject
                                ? service.tryUniversalNumericReject(fusedReject)
                                : service.tryFastAccept(fusedReject);
                        service.lastReadableFastScan = handled
                                ? SystemClock.elapsedRealtime() : 0;
                        if (handled) return;
                    }
                }
            }
            if (universalEvidence != null && service.universallyQualifiedByNumbers(
                    universalEvidence.amount, universalEvidence.miles)) {
                // v2.10.107: prove the exact numeric pair first. v2.10.106 queried the generic
                // Accept index (~18ms in the field) and then the exact numeric index (~24ms).
                // General-qualified events already provide the expected pair, so the generic
                // lookup is redundant on the success path.
                long exactStarted = SystemClock.elapsedRealtime();
                TapAccessibilityService.FastOfferSnapshot universalCurrent =
                        TapAccessibilityService.getIndexedNumericTopAcceptSnapshot(
                                universalEvidence.amount, universalEvidence.miles);
                long exactIndexMs = SystemClock.elapsedRealtime() - exactStarted;
                if (!service.taskEpochCurrent(taskEpoch)) {
                    service.noteStaleTaskDrop();
                    return;
                }
                if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                TapAccessibilityService.FastOfferSnapshot universal =
                        service.fuseUniversalNumericEvidence(universalCurrent, universalEvidence);
                // v2.10.100: React Native often publishes the amount+mileage event before the
                // semantic Accept ancestor inherits the same card text.  The old universal lane
                // therefore fell through to quick + full-tree work even though General was
                // already decided.  If the cheap index cannot bind the pair, immediately run a
                // bounded CURRENT-window proof targeted at that exact amount+mileage.  It must
                // independently rediscover the pair above a safe, enabled Accept control, so this
                // is not a stale-event/old-coordinate click and no city or rule is weakened.
                long genericIndexMs = 0L;
                long targetedVerifyMs = 0L;
                // A newer numeric event supersedes this failed exact probe. Do not make that
                // new event wait behind a generic index and short-tree reconstruction.
                if (universal == null && service.shouldYieldFallbackToNewEvent()) return;
                if (universal == null) {
                    long genericStarted = SystemClock.elapsedRealtime();
                    TapAccessibilityService.FastOfferSnapshot verified =
                            TapAccessibilityService.getIndexedTopAcceptSnapshot(false, false);
                    genericIndexMs = SystemClock.elapsedRealtime() - genericStarted;
                    verified = service.fuseUniversalNumericEvidence(verified, universalEvidence);
                    if (verified == null && service.shouldYieldFallbackToNewEvent()) return;
                    if (verified == null) {
                        long shortTreeStarted = SystemClock.elapsedRealtime();
                        verified = TapAccessibilityService.quickVerifyTopAction(
                                universalEvidence.amount, universalEvidence.miles, true);
                        targetedVerifyMs = SystemClock.elapsedRealtime() - shortTreeStarted;
                    }
                    if (!service.taskEpochCurrent(taskEpoch)) {
                        service.noteStaleTaskDrop();
                        return;
                    }
                    if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                    if (verified != null && verified.acceptEnabled
                            && !verified.acceptBounds.isEmpty()
                            && service.universallyQualifiedByNumbers(
                                    verified.amount, verified.miles)) {
                        universal = verified;
                    }
                }
                if (universal != null && service.universallyQualifiedByNumbers(
                        universal.amount, universal.miles)) {
                    String universalId = universal.identity;
                    boolean actionable = !universal.acceptBounds.isEmpty()
                            && universal.acceptEnabled
                            && service.claimBudget.available(
                                    universalId, SystemClock.elapsedRealtime());
                    if (actionable) {
                        service.scanTiming = "排队" + (now - queuedAt)
                                + "ms；UNIVERSAL_EXACT_INDEX_FIRST " + exactIndexMs
                                + "ms；通用索引兜底" + genericIndexMs
                                + "ms；短树兜底" + targetedVerifyMs
                                + "ms；金额/里程已满足General；跳过城市与完整树；当前Accept直达";
                        boolean actionDispatched = service.tryUniversalNumericAccept(universal);
                        service.lastReadableFastScan = actionDispatched
                                ? SystemClock.elapsedRealtime() : 0;
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, universal.text,
                                universal.amount, universal.miles);
                        if (actionDispatched) return;
                    }
                }
            }

            service.noteDecisionStage("numericRoutes");
            // v2.10.123 FILTERED_GENERAL_INDEX_FIRST: an explicit city allow-list and active
            // time window intentionally disable the numeric-universal lane. The first card used
            // to fall through to quick + full-tree reconstruction even when Android's live text
            // index already exposed every required field. Re-prove the CURRENT enabled Accept,
            // exact pair, configured city and offer time inside one top-card band, then evaluate
            // the unchanged rule before dispatch. No cached city/time field can authorize this.
            if (universalEvidence != null
                    && service.generalNumbersQualified(
                    universalEvidence.amount, universalEvidence.miles)
                    && (service.decisionNeedsLocationEvidence()
                    || service.decisionNeedsOfferTimeEvidence())) {
                long filteredStarted = SystemClock.elapsedRealtime();
                TapAccessibilityService.FastOfferSnapshot filteredCurrent =
                        TapAccessibilityService.getIndexedFilteredGeneralTopAcceptSnapshot(
                                universalEvidence.amount, universalEvidence.miles,
                                service.configuredCityQueries(),
                                service.decisionNeedsOfferTimeEvidence());
                long filteredMs = SystemClock.elapsedRealtime() - filteredStarted;
                if (!service.taskEpochCurrent(taskEpoch)) {
                    service.noteStaleTaskDrop();
                    return;
                }
                if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                if (filteredCurrent != null
                        && service.quickDecisionTextComplete(filteredCurrent)
                        && service.fastRuleFailure(filteredCurrent).isEmpty()) {
                    String filteredId = filteredCurrent.identity;
                    long filteredNow = SystemClock.elapsedRealtime();
                    boolean actionable = service.claimBudget.available(filteredId, filteredNow);
                    if (actionable) {
                        service.scanTiming = "排队" + (now - queuedAt)
                                + "ms；FILTERED_GENERAL_INDEX_FIRST " + filteredMs
                                + "ms；当前允许城市+订单时间+精确数值+当前Accept；"
                                + "跳过快速树/完整树";
                        boolean actionDispatched = service.tryFastAccept(filteredCurrent);
                        service.lastReadableFastScan = actionDispatched
                                ? SystemClock.elapsedRealtime() : 0;
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs,
                                filteredCurrent.text, filteredCurrent.amount,
                                filteredCurrent.miles);
                        if (actionDispatched) return;
                    }
                }
            }

            // v182: one exact live read for a Pasadena candidate. Complete cached city
            // evidence needs only the current numeric/action proof; otherwise the same read
            // also obtains the live city. Do not repeat the entire numeric/action index first.
            if (service.pasadenaNumericCandidate(universalEvidence)) {
                boolean completeCityEvidence = service.pasadenaOnlyEvidenceQualified(universalEvidence);
                long pasadenaStarted = SystemClock.elapsedRealtime();
                TapAccessibilityService.FastOfferSnapshot pasadenaCurrent = completeCityEvidence
                        ? TapAccessibilityService.getIndexedNumericTopAcceptSnapshot(
                                universalEvidence.amount, universalEvidence.miles)
                        : TapAccessibilityService.getIndexedPasadenaTopAcceptSnapshot(
                                universalEvidence.amount, universalEvidence.miles);
                long pasadenaMs = SystemClock.elapsedRealtime() - pasadenaStarted;
                if (!service.taskEpochCurrent(taskEpoch)) {
                    service.noteStaleTaskDrop();
                    return;
                }
                if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                TapAccessibilityService.FastOfferSnapshot pasadenaFast =
                        service.fusePasadenaCityEvidence(pasadenaCurrent, universalEvidence);
                if (pasadenaFast != null) {
                    String pasadenaId = pasadenaFast.identity;
                    long pasadenaNow = SystemClock.elapsedRealtime();
                    boolean actionable = service.claimBudget.available(pasadenaId, pasadenaNow);
                    if (actionable) {
                        service.scanTiming = "排队" + (now - queuedAt)
                                + "ms；" + (completeCityEvidence ? "PASADENA_CITY_FAST "
                                        : "FIRST_PUBLISH_PASADENA_INDEXED ") + pasadenaMs
                                + "ms；单次当前数值/Accept索引；城市同卡复核；跳过快速树/完整树";
                        boolean actionDispatched = service.tryFastAccept(pasadenaFast);
                        service.lastReadableFastScan = actionDispatched
                                ? SystemClock.elapsedRealtime() : 0;
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs,
                                pasadenaFast.text, pasadenaFast.amount, pasadenaFast.miles);
                        if (actionDispatched) return;
                    }
                }
            }

            service.noteDecisionStage("filteredRoutes");
            long rejectedRoutingGeneration = -1L;
            long noAcceptGeneration=-1L;
            boolean rejectedCurrentObservation = false;
            boolean selfIndexOfferObserved = false;
            // v2.10.126 PASADENA_SELF_INDEX_FIRST: some RN publications expose the current
            // Accept, amount, mileage and Commerce/Pasadena address as separate indexed nodes
            // without ever putting the numeric pair into one Accessibility event. The older
            // first-publish lane therefore had no expected pair and fell through to a 100-400ms
            // full-tree walk. Bind all CURRENT fields to the same top action band directly.
            if (service.prefs.getBoolean("pasadenaRuleEnabled", false)
                    || (!service.cityFilterEnabled() && !service.decisionNeedsOfferTimeEvidence())) {
                long selfIndexedStarted = SystemClock.elapsedRealtime();
                TapAccessibilityService.FastOfferSnapshot selfIndexed =
                        TapAccessibilityService.getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(
                                service.prefs.getFloat("minPay", 60f), service.prefs.getFloat("maxMiles", 10f),
                                service.prefs.getBoolean("pasadenaRuleEnabled", false),
                                !service.cityFilterEnabled() && !service.decisionNeedsOfferTimeEvidence(),
                                service.decisionNeedsOfferTimeEvidence());
                long selfIndexedMs = SystemClock.elapsedRealtime() - selfIndexedStarted;
                service.noteDecisionStage("selfIndex");
                if (!service.taskEpochCurrent(taskEpoch)) {
                    service.noteStaleTaskDrop();
                    return;
                }
                if (selfIndexed != null && service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                if (selfIndexed != null) {
                    selfIndexOfferObserved = true;
                    service.deferRejectConfirmationsForNewTop(selfIndexed.text);
                }
                boolean generalSelf = selfIndexed != null && service.universallyQualifiedByNumbers(
                        selfIndexed.amount, selfIndexed.miles);
                if (selfIndexed != null && (generalSelf
                        || (service.quickDecisionTextComplete(selfIndexed)
                        && service.fastRuleFailure(selfIndexed).isEmpty()))) {
                    if (service.claimBudget.available(selfIndexed.identity, SystemClock.elapsedRealtime())) {
                        service.scanTiming = "排队" + (now - queuedAt)
                                + "ms；" + (generalSelf ? "GENERAL_SELF_INDEX_FIRST " : "PASADENA_SELF_INDEX_FIRST ") + selfIndexedMs
                                + (generalSelf ? "ms；当前Accept+数值已满足General；跳过特殊组城市查询；"
                                : "ms；当前Accept+金额+里程+城市+时间同卡自证；")
                                + "跳过快速树/完整树";
                        boolean actionDispatched = generalSelf ? service.dispatchUniversalNumericAccept(selfIndexed)
                                : service.tryFastAccept(selfIndexed);
                        service.lastReadableFastScan = actionDispatched
                                ? SystemClock.elapsedRealtime() : 0;
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs,
                                selfIndexed.text, selfIndexed.amount, selfIndexed.miles);
                        if (actionDispatched) return;
                    }
                }
                TapAccessibilityService.FastOfferSnapshot rejectedObservation =
                        TapAccessibilityService.takeRejectedSelfIndexObservation();
                if (rejectedObservation != null) selfIndexOfferObserved = true;
                if (rejectedObservation != null && rejectedObservation.rejectEnabled)
                    service.deferRejectConfirmationsForNewTop(rejectedObservation.text);
                String selfFailure = TapAccessibilityService.currentAcceptObservationReason();
                // v2.10.297: a saturated first-shot read batch is not evidence that the
                // offer is gone. Do NOT append Reject/Quick/Full fallback reads to the
                // same heartbeat: those compete with the overdue first-shot Binder calls.
                // The regular 12ms heartbeat (or independent idle-presence lane when
                // no event remains) retries without tombstoning re-published offers.
                if(selfIndexed==null && "ACTION_INDEX_BUSY_YIELD".equals(selfFailure)) {
                    scanExit="FIRST_SHOT_INDEX_BUSY_YIELD";
                    service.scheduleIdlePresenceProbe();
                    return;
                }
                if(selfIndexed==null && "NO_ACCEPT".equals(selfFailure))
                    noAcceptGeneration=TapAccessibilityService.currentUiGeneration();
                rejectRoute.append("；SelfIndex=").append(selfFailure);
                if (rejectedObservation!=null && !rejectedObservation.rejectReuseReason.isEmpty())
                    rejectRoute.append("；Reject复用=").append(rejectedObservation.rejectReuseReason);
                if (selfIndexed == null && rejectedObservation != null
                        && service.taskEpochCurrent(taskEpoch)
                        && service.prefs.getBoolean("autoIgnore", true)) {
                    boolean numericReject=service.universallyRejectedByNumbers(rejectedObservation.amount,rejectedObservation.miles);
                    String sharedRuleFailure=!numericReject && service.quickDecisionTextComplete(rejectedObservation)
                            ? service.fastRuleFailure(rejectedObservation) : "";
                    if(numericReject || !sharedRuleFailure.isEmpty()) {
                        rejectedCurrentObservation=true;
                        rejectedRoutingGeneration=TapAccessibilityService.currentUiGeneration();
                        if (service.rejectSequence.proofRefreshPending(rejectedObservation.identity,
                                rejectedObservation.text, SystemClock.elapsedRealtime())) {
                            scanExit = "REJECT_PROOF_REFRESH_WAIT";
                            return;
                        }
                        if (rejectedObservation.rejectEnabled) {
                            service.scanTiming = "SHARED_REJECT_ROW " + selfIndexedMs
                                    + "ms；同次索引已核对数值与Reject按钮；SelfIndex=" + selfFailure
                                    + "；" + rejectedObservation.rejectIndexTiming();
                            if (numericReject ? service.tryUniversalNumericReject(rejectedObservation)
                                    : service.handleFastRejection(rejectedObservation,
                                            rejectedObservation.amount, rejectedObservation.miles,
                                            sharedRuleFailure)) return;
                        }
                        // A current disabled control on an already-owned, conclusively
                        // ineligible row is not authority to click or declare completion.
                        // Avoid a second Reject/Quick/Full read of that same observation.
                        // Each later heartbeat/structural publication still runs live index.
                        if (!rejectedObservation.rejectEnabled
                                && "REJECT_DISABLED".equals(rejectedObservation.rejectReuseReason)
                                && rejectedRoutingGeneration==TapAccessibilityService.currentUiGeneration()
                                && service.currentDisabledOwnedReject(rejectedObservation)
                                && rejectedRoutingGeneration==TapAccessibilityService.currentUiGeneration()) {
                            service.noteDecisionStage("rejectDisabledReadOnly");
                            scanExit="REJECT_CURRENT_DISABLED_OWNED";
                            return;
                        }
                        long rejectStarted=SystemClock.elapsedRealtime();
                        long rejectWindowEpoch=TapAccessibilityService.outcomeWindowEpoch();
                        StringBuilder rejectPhases=new StringBuilder();
                        TapAccessibilityService.FastOfferSnapshot currentReject =
                                TapAccessibilityService.getBoundedCurrentRejectSnapshot(false, false,
                                        (pay, mi) -> true, rejectPhases, 60L,
                                        () -> service.taskEpochCurrent(taskEpoch) && !service.fastStructuralWake.get());
                        service.noteDecisionStage("selfReject");
                        rejectRoute.append("；SelfReject").append(rejectPhases);
                        if(currentReject!=null && service.taskEpochCurrent(taskEpoch)
                                && rejectedRoutingGeneration==TapAccessibilityService.currentUiGeneration()
                                && rejectWindowEpoch==TapAccessibilityService.outcomeWindowEpoch()
                                && ActionRowPolicy.pairedReject(currentReject.rejectBounds.left,
                                        currentReject.rejectBounds.top,currentReject.rejectBounds.right,
                                        currentReject.rejectBounds.bottom,rejectedObservation.acceptBounds.left,
                                        rejectedObservation.acceptBounds.top,rejectedObservation.acceptBounds.right,
                                        rejectedObservation.acceptBounds.bottom)
                                && Math.abs(currentReject.amount-rejectedObservation.amount)<0.011f
                                && Math.abs(currentReject.miles-rejectedObservation.miles)<0.001f
                                && SystemClock.elapsedRealtime()-rejectedObservation.capturedAt<=180L) {
                            TapAccessibilityService.FastOfferSnapshot boundReject =
                                    currentReject.withDecisionText(rejectedObservation.text);
                            service.scanTiming="SELF_INDEX_REJECT_REUSED " + selfIndexedMs
                                    + "ms；当前Reject复核"+(SystemClock.elapsedRealtime()-rejectStarted)
                                    + "ms；SelfIndex="+selfFailure+"；Reject复用="
                                    +rejectedObservation.rejectReuseReason+rejectPhases+"；跳过重复Accept索引";
                            if(numericReject ? service.tryUniversalNumericReject(boundReject)
                                    : service.handleFastRejection(boundReject,boundReject.amount,boundReject.miles,
                                            service.fastRuleFailure(boundReject))) return;
                        }
                        if(rejectedRoutingGeneration!=TapAccessibilityService.currentUiGeneration()
                                || rejectWindowEpoch!=TapAccessibilityService.outcomeWindowEpoch()) {
                            requestImmediateFastCheck(SystemClock.uptimeMillis());
                            return;
                        }
                    }
                }
                service.noteDecisionStage("selfRoute");

                if (selfIndexed == null && "ROOT_READ_PENDING".equals(selfFailure)) {
                    // The in-flight root read wakes this lane as soon as it publishes.
                    return;
                }
                if (selfIndexed == null && ("ACTION_INDEX_YIELD".equals(selfFailure)
                        || "UI_CHANGED_ACTION".equals(selfFailure)
                        || "ROOT_READ_SUPERSEDED".equals(selfFailure))
                        && scanUiGeneration != TapAccessibilityService.currentUiGeneration()) {
                    scanExit = "YIELD_FRESH_EVENT";
                    return;
                }
                if(selfIndexed==null && selfFailure.startsWith("ROOT_READ_")) {
                    service.fastWorker.postDelayed(() -> requestImmediateFastCheck(SystemClock.uptimeMillis()),20L);
                    return;
                }
                if (selfIndexed == null && (!service.taskEpochCurrent(taskEpoch)
                        || service.handlePendingSerialFast(SystemClock.elapsedRealtime()))) return;
            }

            // v2.10.56 SAME_GEN_FAST: if the CURRENT Accessibility generation already
            // contains complete rule fields, query only the current Accept/Claim action and
            // prove the same numeric pair locally. This avoids rebuilding address/time from
            // card ancestors and never changes Reject behavior or any threshold.
            TapAccessibilityService.DecisionEvidence sameGenEvidence =
                    TapAccessibilityService.recentDecisionEvidence(360L);
            if (!rejectedCurrentObservation && sameGenEvidence != null
                    && !service.universallyRejectedByNumbers(sameGenEvidence.amount, sameGenEvidence.miles)
                    && service.quickDecisionTextComplete(
                    sameGenEvidence.text, sameGenEvidence.amount, sameGenEvidence.miles)
                    && service.fastRuleFailure(sameGenEvidence.text,sameGenEvidence.amount,sameGenEvidence.miles).isEmpty()) {
                long sameGenStarted = SystemClock.elapsedRealtime();
                TapAccessibilityService.FastOfferSnapshot sameGen =
                        TapAccessibilityService.getSameGenerationQualifiedAcceptSnapshot(
                                sameGenEvidence);
                long sameGenMs = SystemClock.elapsedRealtime() - sameGenStarted;
                if (!service.taskEpochCurrent(taskEpoch)) {
                    service.noteStaleTaskDrop();
                    return;
                }
                if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                if (sameGen != null && service.quickDecisionTextComplete(sameGen)) {
                    String sameGenFailure = service.fastRuleFailure(sameGen);
                    float sameGenAmount = sameGen.amount;
                    float sameGenMiles = sameGen.miles;
                    if (sameGenFailure.isEmpty()) {
                        String sameGenId = sameGen.identity;
                        boolean sameGenActionable = !sameGen.acceptBounds.isEmpty()
                                && sameGen.acceptEnabled
                                && service.claimBudget.available(
                                        sameGenId, SystemClock.elapsedRealtime());
                        if (sameGenActionable) {
                            service.scanTiming = "排队" + (now - queuedAt)
                                    + "ms；SAME_GEN_FAST " + sameGenMs
                                    + "ms；同代字段+当前Accept直达";
                            boolean actionDispatched = service.tryFastAccept(sameGen);
                            service.lastReadableFastScan = actionDispatched
                                    ? SystemClock.elapsedRealtime() : 0;
                            QualifiedOfferAlert.notifyIfNeeded(
                                    service, service.prefs, sameGen.text,
                                    sameGenAmount, sameGenMiles);
                            if (actionDispatched) return;
                        } else {
                            QualifiedOfferAlert.notifyIfNeeded(
                                    service, service.prefs, sameGen.text,
                                    sameGenAmount, sameGenMiles);
                            if (service.accessibilityOwnsDecision(sameGen, sameGenFailure)) {
                                service.holdAccessibilityDecision(
                                        sameGen, sameGenFailure, "SAME_GEN_FAST");
                                return;
                            }
                        }
                    }
                    // Ineligible offers deliberately fall through to the existing indexed/
                    // paired Reject path. v2.10.56 does not optimize or alter Reject.
                }
            }

            // A structural notification with no exported amount/miles or action is not
            // proof an offer is present. Avoid chaining Reject+Quick+Full on this lane;
            // the independent presence worker will wake us when the UI exports a card.
            // An already observed live offer never enters this branch.
            // v2.10.296: a failed live/current offer index is not permission to run a
            // 125ms Action→Reject→Quick→Full chain merely because a *stale* screenshot
            // or previous React-Native event still suggests Accept. The regular heartbeat
            // must be available for the next publication. The independent presence lane
            // keeps looking, while a new indexed card/numeric event enters the fast lane.
            // In particular, an unproven STRUCTURAL wake is a hint to probe existence,
            // not a reason to block 10-12 upcoming heartbeats with Binder reads.
            if (!selfIndexOfferObserved && service.serialTopAction==SerialAction.NONE
                    && (universalEvidence==null || universalEvidence.amount<0f
                        || universalEvidence.miles<0f)) {
                service.scheduleIdlePresenceProbe();
                scanExit="PRESENCE_UNPROVEN_OFF_LANE";
                return;
            }
            // A fresh numeric rejection can recover a missed exact lookup using the
            // current Reject row, before paying for an unrelated Accept index.
            long earlyRejectGeneration = rejectedRoutingGeneration>=0L?rejectedRoutingGeneration:exactRejectReadGeneration;
            service.noteDecisionStage("sameGen");
            TapAccessibilityService.DecisionEvidence currentRoutingEvidence = TapAccessibilityService.recentDecisionEvidence(120L);
            TapAccessibilityService.DecisionEvidence rejectRoutingEvidence = currentRoutingEvidence != null
                    && currentRoutingEvidence.uiGeneration == TapAccessibilityService.currentUiGeneration()
                    ? currentRoutingEvidence : universalEvidence;
            long earlyRejectBudget = QuickTreeBudgetPolicy.remainingScanMs(
                    enteredAt, SystemClock.elapsedRealtime(), 60L, QuickTreeBudgetPolicy.QUICK_RESERVE_MS);
            if (earlyRejectBudget >= QuickTreeBudgetPolicy.MIN_TREE_SLICE_MS && !rejectedCurrentObservation && earlyRejectGeneration!=TapAccessibilityService.currentUiGeneration()
                    && rejectRoutingEvidence != null && service.prefs.getBoolean("autoIgnore", true)
                    && !service.rejectSequence.proofRefreshPending(CardText.identity(rejectRoutingEvidence.text),
                            rejectRoutingEvidence.text, SystemClock.elapsedRealtime())
                    && service.universallyRejectedByNumbers(rejectRoutingEvidence.amount, rejectRoutingEvidence.miles)
                    && !service.shouldYieldFallbackToNewEvent()) {
                earlyRejectGeneration = TapAccessibilityService.currentUiGeneration();
                long earlyRejectAt = SystemClock.elapsedRealtime();
                StringBuilder phases = new StringBuilder();
                TapAccessibilityService.FastOfferSnapshot earlyReject =
                        TapAccessibilityService.getBoundedCurrentRejectSnapshot(
                                service.decisionNeedsLocationEvidence(),
                                service.decisionNeedsOfferTimeEvidence(),
                                service::universallyRejectedByNumbers, phases, earlyRejectBudget,
                                () -> service.taskEpochCurrent(taskEpoch) && !service.fastStructuralWake.get());
                if (!service.taskEpochCurrent(taskEpoch)) { service.noteStaleTaskDrop(); return; }
                if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                service.noteDecisionStage("rejectSelf");
                if (earlyReject == null) rejectRoute.append("；早期Reject").append(phases);
                if (earlyReject != null && service.universallyRejectedByNumbers(earlyReject.amount, earlyReject.miles)) {
                    service.scanTiming = "排队" + (now - queuedAt)
                            + "ms；CURRENT_REJECT_SELF_INDEX "
                            + (SystemClock.elapsedRealtime() - earlyRejectAt) + "ms" + phases;
                    if (service.tryUniversalNumericReject(earlyReject)) {
                        service.lastReadableFastScan = SystemClock.elapsedRealtime();
                        return;
                    }
                }
            }

            // v2.10.22: qualified offers get an even cheaper Accept-index path first.
            // Android can jump directly to the semantic Accept/Claim label; if a card-level
            // ancestor already exposes pay+miles+address, do not walk ~130 React-Native nodes
            // before sending the first claim gesture. Any ambiguity falls through unchanged.
            if (service.fastStructuralWake.get() && scanUiGeneration!=TapAccessibilityService.currentUiGeneration()
                    && service.shouldDeferBoundedTopRead()) return;
            long indexedStarted = SystemClock.elapsedRealtime();
            long actionBudget = QuickTreeBudgetPolicy.remainingScanMs(
                    enteredAt, indexedStarted, 45L, QuickTreeBudgetPolicy.QUICK_RESERVE_MS);
            TapAccessibilityService.FastOfferSnapshot indexed = rejectedCurrentObservation
                    || noAcceptGeneration == TapAccessibilityService.currentUiGeneration() ? null :
                    TapAccessibilityService.getBoundedIndexedTopActionSnapshot(true,
                            service.decisionNeedsLocationEvidence(), service.decisionNeedsOfferTimeEvidence(),
                            actionBudget, () -> service.taskEpochCurrent(taskEpoch) && !service.fastStructuralWake.get());
            long indexedMs = SystemClock.elapsedRealtime() - indexedStarted;
            service.noteDecisionStage("actionIndex");
            // OCR / Jobs-success may have advanced the global epoch while the indexed lookup ran.
            if (!service.taskEpochCurrent(taskEpoch)) {
                service.noteStaleTaskDrop();
                return;
            }
            // OCR may have dispatched Accept/Reject while the indexed lookup was running.
            if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;

            // v2.10.31 direct Accept fusion: when the semantic Accept index already owns the
            // current action rectangle but its ancestor omitted address/time, fuse only the
            // fresh same-card Accessibility event fields before paying for quick/full-tree walks.
            indexed = service.fuseIndexedActionWithEventEvidence(indexed);
            TapAccessibilityService.FastOfferSnapshot beforeBurstFusion = indexed;
            indexed = service.fuseIndexedActionWithEventBurstEvidence(indexed);
            boolean eventBurstFused = indexed != beforeBurstFusion;

            // v2.10.86 INDEXED_NUMERIC_FAST: the first UNIVERSAL_NUMERIC_FAST probe can run
            // a few milliseconds before React-Native exports the Accept anchor. The ordinary
            // Action index immediately below may then obtain the CURRENT enabled Accept plus
            // the exact current amount/mileage, but still omit city/address text. When those
            // live numbers already pass General, city is mathematically irrelevant (Pasadena
            // is additive), so do not pay for quick/full-tree reconstruction. Explicit city
            // allow-lists and active time filters remain hard blockers inside the universal
            // policy. The symmetric universal-Reject lane below is allowed only when every
            // enabled numeric branch fails and a CURRENT same-row Reject is independently
            // re-proved.
            if (indexed != null
                    && service.prefs.getBoolean("autoIgnore", true)
                    && service.universallyRejectedByNumbers(indexed.amount, indexed.miles)) {
                long universalRejectStarted = SystemClock.elapsedRealtime();
                TapAccessibilityService.FastOfferSnapshot universalReject =
                        TapAccessibilityService.getPairedRejectSnapshotFromIndexedAccept(indexed);
                long universalRejectMs = SystemClock.elapsedRealtime() - universalRejectStarted;
                if (!service.taskEpochCurrent(taskEpoch)) {
                    service.noteStaleTaskDrop();
                    return;
                }
                if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                if (service.sameCurrentUniversalReject(indexed, universalReject)) {
                    service.scanTiming = "排队" + (now - queuedAt)
                            + "ms；Action索引" + indexedMs + "ms；"
                            + "配对Reject" + universalRejectMs
                            + "ms；UNIVERSAL_REJECT_FAST；跳过快速树/完整树";
                    boolean actionHandled = service.tryUniversalNumericReject(universalReject);
                    service.lastReadableFastScan = actionHandled
                            ? SystemClock.elapsedRealtime() : 0;
                    if (actionHandled) return;
                }
            }
            if (indexed != null && service.universallyQualifiedByNumbers(
                    indexed.amount, indexed.miles)) {
                String indexedNumericId = indexed.identity;
                boolean indexedNumericActionable = !indexed.acceptBounds.isEmpty()
                        && indexed.acceptEnabled
                        && service.claimBudget.available(
                                indexedNumericId, SystemClock.elapsedRealtime());
                if (indexedNumericActionable) {
                    service.scanTiming = "排队" + (now - queuedAt)
                            + "ms；Action索引" + indexedMs
                            + "ms；INDEXED_NUMERIC_FAST；当前金额/里程已满足General；跳过快速树/完整树";
                    boolean actionDispatched = service.tryUniversalNumericAccept(indexed);
                    service.lastReadableFastScan = actionDispatched
                            ? SystemClock.elapsedRealtime() : 0;
                    QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, indexed.text,
                            indexed.amount, indexed.miles);
                    if (actionDispatched) return;
                }
            }
            if (indexed != null && service.quickDecisionTextComplete(indexed)) {
                String indexedTop = indexed.text;
                service.deferRejectConfirmationsForNewTop(indexedTop);
                if (!service.serialTopText.isEmpty()
                        && !(CardText.sameOffer(service.serialTopText, indexedTop) || (service.serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(service.serialTopText, indexedTop))))
                    service.retireStaleSerialLock(indexedTop, "Accept索引确认换顶", null);
                String indexedFailure = service.fastRuleFailure(indexed);
                float indexedAmount = indexed.amount;
                float indexedMiles = indexed.miles;
                if (indexedFailure.isEmpty()) {
                    String indexedId = indexed.identity;
                    boolean indexedActionable = !indexed.acceptBounds.isEmpty()
                            && indexed.acceptEnabled
                            && service.claimBudget.available(indexedId, SystemClock.elapsedRealtime());
                    if (indexedActionable) {
                        service.scanTiming = "排队" + (now - queuedAt) + "ms；Action索引"
                                + indexedMs + "ms；"
                                + (eventBurstFused ? "EVENT_BURST_FAST；跨代字段+当前Accept直达"
                                : "合格首卡直达");
                        boolean actionDispatched = service.tryFastAccept(indexed);
                        service.lastReadableFastScan = actionDispatched
                                ? SystemClock.elapsedRealtime() : 0;
                        // Do not construct/post a high-priority notification before the claim
                        // gesture is queued. The user wants the button action to win the race.
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, indexed.text,
                                indexedAmount, indexedMiles);
                        if (actionDispatched) return;
                    } else {
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, indexed.text,
                                indexedAmount, indexedMiles);
                        if (service.accessibilityOwnsDecision(indexed, indexedFailure)) {
                            service.holdAccessibilityDecision(indexed, indexedFailure, "Accept索引");
                            return;
                        }
                    }
                } else if (service.prefs.getBoolean("autoIgnore", true)) {
                    // v2.10.29 Reject Fast-Exit: the Accept index already proved this exact
                    // top card. First inspect only its local action-row ancestors for the
                    // left-side Reject control. This removes the 400ms quick-tree + 479ms
                    // full-tree detour seen on the Galaxy A15 trace. Rule evaluation above is
                    // unchanged; this only shortens action-anchor discovery.
                    long pairedStarted = SystemClock.elapsedRealtime();
                    TapAccessibilityService.FastOfferSnapshot pairedReject =
                            TapAccessibilityService.getPairedRejectSnapshotFromIndexedAccept(indexed);
                    long pairedMs = SystemClock.elapsedRealtime() - pairedStarted;
                    if (!service.taskEpochCurrent(taskEpoch)) {
                        service.noteStaleTaskDrop();
                        return;
                    }
                    if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                    if (pairedReject != null
                            && service.quickDecisionTextComplete(pairedReject)
                            && CardText.sameOffer(indexed.text, pairedReject.text)) {
                        RejectSequence.State pairedState = service.rejectSequence.observeVisible(
                                pairedReject.identity, SystemClock.elapsedRealtime());
                        if (!pairedReject.rejectBounds.isEmpty()
                                && pairedReject.rejectEnabled
                                && pairedState == RejectSequence.State.READY) {
                            service.scanTiming = "排队" + (now - queuedAt) + "ms；Action索引"
                                    + indexedMs + "ms；配对Reject" + pairedMs + "ms；首卡直达";
                            boolean actionDispatched = service.tryFastAccept(pairedReject);
                            service.lastReadableFastScan = actionDispatched
                                    ? SystemClock.elapsedRealtime() : 0;
                            if (actionDispatched) return;
                        }
                        if (service.accessibilityOwnsDecision(pairedReject, indexedFailure)) {
                            service.holdAccessibilityDecision(pairedReject, indexedFailure, "配对Reject");
                            return;
                        }
                    }

                    // Semantic Reject index remains the first fallback when the local paired
                    // control is not exported by this React-Native frame.
                    long rejectIndexedStarted = SystemClock.elapsedRealtime();
                    long pairedRejectBudget = QuickTreeBudgetPolicy.remainingScanMs(
                            enteredAt, rejectIndexedStarted, 45L, QuickTreeBudgetPolicy.QUICK_RESERVE_MS);
                    TapAccessibilityService.FastOfferSnapshot indexedReject =
                            TapAccessibilityService.getBoundedIndexedTopActionSnapshot(false,
                                    service.decisionNeedsLocationEvidence(), service.decisionNeedsOfferTimeEvidence(),
                                    pairedRejectBudget, () -> service.taskEpochCurrent(taskEpoch) && !service.fastStructuralWake.get());
                    long rejectIndexedMs = SystemClock.elapsedRealtime() - rejectIndexedStarted;
                    if (!service.taskEpochCurrent(taskEpoch)) {
                        service.noteStaleTaskDrop();
                        return;
                    }
                    if (indexedReject != null
                            && service.quickDecisionTextComplete(indexedReject)
                            && CardText.sameOffer(indexed.text, indexedReject.text)) {
                        RejectSequence.State indexedRejectState = service.rejectSequence.observeVisible(
                                indexedReject.identity, SystemClock.elapsedRealtime());
                        if (!indexedReject.rejectBounds.isEmpty()
                                && indexedReject.rejectEnabled
                                && indexedRejectState == RejectSequence.State.READY) {
                            service.scanTiming = "排队" + (now - queuedAt) + "ms；Action索引"
                                    + indexedMs + "ms；配对Reject" + pairedMs + "ms；Reject索引"
                                    + rejectIndexedMs + "ms；首卡直达";
                            boolean actionDispatched = service.tryFastAccept(indexedReject);
                            service.lastReadableFastScan = actionDispatched
                                    ? SystemClock.elapsedRealtime() : 0;
                            if (actionDispatched) return;
                        }
                        if (service.accessibilityOwnsDecision(indexedReject, indexedFailure)) {
                            service.holdAccessibilityDecision(indexedReject, indexedFailure, "Reject索引");
                            return;
                        }
                    }
                }
            }

            // v2.10.57: if a brand-new offer is still inside React-Native's tiny event burst,
            // do not let an incomplete first event immediately enter the expensive quick/full
            // tree. Give current-card fields/Accept up to 64ms total to settle, then fall back
            // unchanged. This is especially important because fastCheckDirty can otherwise wait
            // behind the first slow traversal even though newer events already arrived.
            if (!rejectedCurrentObservation && service.deferForEventBurstFastPath(indexed)) {
                scanExit = "EVENT_BURST_WAIT";
                return;
            }

            // Qualified Accept lanes above keep priority. Before a slow tree, discover the
            // CURRENT Reject row and its own numeric/address/time nodes without cached fields.
            long directRejectBudget = QuickTreeBudgetPolicy.remainingScanMs(
                    enteredAt, SystemClock.elapsedRealtime(), 60L, QuickTreeBudgetPolicy.QUICK_RESERVE_MS);
            if (directRejectBudget >= QuickTreeBudgetPolicy.MIN_TREE_SLICE_MS && service.prefs.getBoolean("autoIgnore", true)
                    && (indexed == null || !service.universallyQualifiedByNumbers(indexed.amount, indexed.miles))
                    && (universalEvidence == null || !service.universallyQualifiedByNumbers(
                            universalEvidence.amount, universalEvidence.miles))
                    && earlyRejectGeneration != TapAccessibilityService.currentUiGeneration()
                    && (rejectRoutingEvidence == null || !service.rejectSequence.proofRefreshPending(
                            CardText.identity(rejectRoutingEvidence.text), rejectRoutingEvidence.text,
                            SystemClock.elapsedRealtime()))
                    && !service.shouldYieldFallbackToNewEvent()) {
                long directRejectAt = SystemClock.elapsedRealtime();
                StringBuilder phases = new StringBuilder();
                TapAccessibilityService.FastOfferSnapshot directReject =
                        TapAccessibilityService.getBoundedCurrentRejectSnapshot(
                                service.decisionNeedsLocationEvidence(),
                                service.decisionNeedsOfferTimeEvidence(),
                                service::universallyRejectedByNumbers, phases, directRejectBudget,
                                () -> service.taskEpochCurrent(taskEpoch) && !service.fastStructuralWake.get());
                if (!service.taskEpochCurrent(taskEpoch)) { service.noteStaleTaskDrop(); return; }
                if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                service.noteDecisionStage("rejectIndex");
                if (directReject == null) rejectRoute.append("；Reject直读").append(phases);
                if (directReject != null) {
                    boolean numericReject = service.universallyRejectedByNumbers(
                            directReject.amount, directReject.miles);
                    boolean completeReject = service.quickDecisionTextComplete(directReject)
                            && !service.fastRuleFailure(directReject).isEmpty();
                    if (numericReject || completeReject) {
                        service.scanTiming = "排队" + (now - queuedAt)
                                + "ms；Action索引" + indexedMs + "ms；FIRST_PUBLISH_REJECT_INDEXED "
                                + (SystemClock.elapsedRealtime() - directRejectAt)
                                + "ms" + phases + "；当前Reject+当前数值/规则字段；跳过快速树/完整树";
                        boolean handled = numericReject ? service.tryUniversalNumericReject(directReject)
                                : service.tryFastAccept(directReject);
                        service.lastReadableFastScan = handled ? SystemClock.elapsedRealtime() : 0;
                        if (handled) return;
                    }
                }
            }

            if(service.yieldDeepScanDuringUnavailableReturn(indexed,SystemClock.elapsedRealtime())) return;

            // Existing bounded active-window path remains the fallback for Reject, blank-label
            // controls, or any indexed Accept whose ancestor text was incomplete. A recent
            // v2.10.35 budget exit yields this fallback briefly to OCR while still allowing the
            // semantic index above to win immediately on a new actionable frame.
            if (SystemClock.elapsedRealtime() < service.quickTreeBackoffUntil) {
                scanExit = "QUICK_TREE_BACKOFF";
                service.lastReadableFastScan = 0;
                service.lastScan = 0;
                return;
            }
            // v2.10.59: never enter a 100ms+ fallback walk when a newer Accessibility event
            // already arrived. Finish this runnable immediately so the coalesced fresh event can
            // restart from UNIVERSAL/SAME_GEN/indexed fast paths.
            if (service.shouldDeferBoundedTopRead()) { scanExit = "YIELD_FRESH_EVENT"; return; }
            service.fallbackGrace.attempted();
            // Idle scans must remain short and continuous. Fresh/new order evidence retains
            // the original (larger) fallback budgets, and all first-shot indexed lanes above
            // run unchanged before this policy is consulted.
            boolean idleFallback = !structural && !priorityOffer
                    && indexed == null && universalEvidence == null
                    && service.serialTopAction == SerialAction.NONE
                    && service.rejectConfirmStates.isEmpty()
                    && !service.fastCheckDirty.get()
                    && !foregroundOfferDemandRecent(1200L)
                    && TapAccessibilityService.recentNumericOfferBurstAge(2500L) < 0L
                    && TapAccessibilityService.recentDecisionEvidence(220L) == null;
            long quickStarted = SystemClock.elapsedRealtime();
            long quickBudget = QuickTreeBudgetPolicy.remainingFallbackMs(
                    enteredAt, quickStarted,
                    IdleFallbackPolicy.quickBudget(QuickTreeBudgetPolicy.softBudgetMs(),idleFallback), 0L);
            if (quickBudget < QuickTreeBudgetPolicy.MIN_TREE_SLICE_MS) {
                scanExit = "SCAN_BUDGET_BEFORE_QUICK_OCR";
                service.lastReadableFastScan = 0L;
                service.lastScan = 0L;
                return;
            }
            long quickGeneration = TapAccessibilityService.currentUiGeneration();
            TapAccessibilityService.QuickTopResult quickResult =
                    TapAccessibilityService.getBoundedQuickTopOfferSnapshot(quickBudget,
                            () -> service.taskEpochCurrent(taskEpoch) && !service.fastStructuralWake.get());
            TapAccessibilityService.FastOfferSnapshot quick = quickResult.snapshot;
            long quickFinished = SystemClock.elapsedRealtime();
            long quickMs = quickFinished - quickStarted;
            service.lastQuickTrace = new QuickReadTrace(quickResult,quickStarted,quickFinished,
                    quickGeneration==TapAccessibilityService.currentUiGeneration());
            service.noteDecisionStage("quickTree");
            // Same in-flight race guard after the bounded tree read.
            if (!service.taskEpochCurrent(taskEpoch)) {
                service.noteStaleTaskDrop();
                return;
            }
            if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
            if ("QUICK_YIELD".equals(quickResult.limitReason)) {
                scanExit = "YIELD_FRESH_EVENT";
                return;
            }

            if ((!service.rejectConfirmStates.isEmpty() || service.expiredReject.get()!=null
                    || service.rejectSequence.hasReorderedDepartures(SystemClock.elapsedRealtime()))
                    && quickGeneration == TapAccessibilityService.currentUiGeneration()) {
                // An incomplete scan is neither proof of an empty list nor evidence of a card.
                if ((quickResult.emptyOffers && !quickResult.budgetExceeded)
                        || quickResult.emptyContradicted || quick!=null)
                    service.observeRejectEmptyOffers(quickResult.emptyOffers && !quickResult.budgetExceeded,
                            quickGeneration,
                            quickStarted, SystemClock.elapsedRealtime());
            }

            if (quick != null && !quickResult.budgetExceeded && quick.rejectEnabled
                    && quickGeneration == TapAccessibilityService.currentUiGeneration()
                    && !CardText.containsMultipleMileageRows(quick.text)
                    && !CardText.containsConflictingOfferNumbers(quick.text)
                    && service.prefs.getBoolean("autoIgnore", true)
                    && service.universallyRejectedByNumbers(quick.amount, quick.miles)
                    && !service.shouldYieldFallbackToNewEvent()) {
                service.scanTiming = "排队" + (now - queuedAt) + "ms；Action索引" + indexedMs
                        + "ms；快速树" + quickMs + "ms；QUICK_CURRENT_NUMERIC_REJECT" + rejectRoute;
                if (service.tryUniversalNumericReject(quick)) {
                    service.lastReadableFastScan = SystemClock.elapsedRealtime();
                    return;
                }
            }

            // v2.10.102 QUICK_CURRENT_NUMERIC_FAST: the bounded quick walk has just rebuilt a
            // CURRENT top-row snapshot and independently paired its exact amount+mileage with
            // a safe, enabled right-side Accept rectangle.  If that pair already passes the
            // General rule, location cannot reverse the decision (the Pasadena branch is only
            // additive), so the subsequent full city/address reconstruction is pure latency.
            // This is deliberately narrower than the old removed locationless shortcut: it
            // accepts only the newly captured same-row snapshot and still runs every universal
            // policy, page, geometry, freshness, current surface and claim-budget guard.
            if (quick != null && service.universallyQualifiedByNumbers(
                    quick.amount, quick.miles)) {
                String quickNumericId = quick.identity;
                boolean quickNumericActionable = !quick.acceptBounds.isEmpty()
                        && quick.acceptEnabled
                        && service.claimBudget.available(
                                quickNumericId, SystemClock.elapsedRealtime());
                if (quickNumericActionable) {
                    service.scanTiming = "排队" + (now - queuedAt)
                            + "ms；Action索引" + indexedMs
                            + "ms；快速树" + quickMs
                            + "ms；QUICK_CURRENT_NUMERIC_FAST；当前同卡金额/里程已满足General；跳过完整树";
                    boolean actionDispatched = service.tryUniversalNumericAccept(quick);
                    service.lastReadableFastScan = actionDispatched
                            ? SystemClock.elapsedRealtime() : 0;
                    QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, quick.text,
                            quick.amount, quick.miles);
                    if (actionDispatched) return;
                }
            }

            // v2.10.103 POST_QUICK_NUMERIC_FAST: the bounded walk can discover and cache the
            // CURRENT top amount+mileage even when it cannot itself assemble an actionable
            // snapshot.  This was the exact $89.76/2.9mi failure shape: the first Action index
            // ran before React-Native attached the numeric row, the quick walk then learned the
            // pair, but the old flow ignored that newly fresh evidence and paid for a full city
            // tree. Re-query only the current semantic Accept against the same-generation pair;
            // if RN still exposes split ancestry, use the existing exact-pair current-row verifier.
            // Neither evidence source may authorize a tap by itself.
            TapAccessibilityService.DecisionEvidence postQuickEvidence =
                    TapAccessibilityService.recentDecisionEvidence(260L);
            if (postQuickEvidence != null && service.universallyQualifiedByNumbers(
                    postQuickEvidence.amount, postQuickEvidence.miles)) {
                long postQuickStarted = SystemClock.elapsedRealtime();
                TapAccessibilityService.FastOfferSnapshot postQuickCurrent =
                        TapAccessibilityService.getSameGenerationQualifiedAcceptSnapshot(
                                postQuickEvidence);
                String postQuickSource = "同代Accept复核";
                if (postQuickCurrent == null) {
                    postQuickCurrent = TapAccessibilityService.quickVerifyTopAction(
                            postQuickEvidence.amount, postQuickEvidence.miles, true);
                    postQuickSource = "定向当前行复核";
                }
                long postQuickMs = SystemClock.elapsedRealtime() - postQuickStarted;
                if (!service.taskEpochCurrent(taskEpoch)) {
                    service.noteStaleTaskDrop();
                    return;
                }
                if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                if (postQuickCurrent != null && service.universallyQualifiedByNumbers(
                        postQuickCurrent.amount, postQuickCurrent.miles)) {
                    String postQuickId = postQuickCurrent.identity;
                    boolean postQuickActionable = !postQuickCurrent.acceptBounds.isEmpty()
                            && postQuickCurrent.acceptEnabled
                            && service.claimBudget.available(
                                    postQuickId, SystemClock.elapsedRealtime());
                    if (postQuickActionable) {
                        service.scanTiming = "排队" + (now - queuedAt)
                                + "ms；Action索引" + indexedMs
                                + "ms；快速树" + quickMs
                                + "ms；POST_QUICK_NUMERIC_FAST " + postQuickMs
                                + "ms；" + postQuickSource
                                + "；快速树后新鲜数值+当前Accept；跳过完整树";
                        boolean actionDispatched =
                                service.tryUniversalNumericAccept(postQuickCurrent);
                        service.lastReadableFastScan = actionDispatched
                                ? SystemClock.elapsedRealtime() : 0;
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs,
                                postQuickCurrent.text, postQuickCurrent.amount,
                                postQuickCurrent.miles);
                        if (actionDispatched) return;
                    }
                }
            }

            // If the first probe raced the React-Native Accept export, reuse the newly current
            // quick-row action with the still-fresh exact Pasadena evidence and skip full tree.
            TapAccessibilityService.DecisionEvidence postQuickPasadenaEvidence =
                    TapAccessibilityService.recentEventBurstDecisionEvidence(420L);
            if (postQuickPasadenaEvidence != null
                    && service.pasadenaOnlyEvidenceQualified(postQuickPasadenaEvidence)) {
                long postQuickPasadenaStarted = SystemClock.elapsedRealtime();
                TapAccessibilityService.FastOfferSnapshot postQuickPasadenaCurrent = quick;
                if (postQuickPasadenaCurrent == null
                        || postQuickPasadenaCurrent.acceptBounds.isEmpty()
                        || !postQuickPasadenaCurrent.acceptEnabled
                        || Math.abs(postQuickPasadenaCurrent.amount
                                - postQuickPasadenaEvidence.amount) > 0.011f
                        || Math.abs(postQuickPasadenaCurrent.miles
                                - postQuickPasadenaEvidence.miles) > 0.051f) {
                    postQuickPasadenaCurrent =
                            TapAccessibilityService.getIndexedNumericTopAcceptSnapshot(
                                    postQuickPasadenaEvidence.amount,
                                    postQuickPasadenaEvidence.miles);
                }
                long postQuickPasadenaMs =
                        SystemClock.elapsedRealtime() - postQuickPasadenaStarted;
                if (!service.taskEpochCurrent(taskEpoch)) {
                    service.noteStaleTaskDrop();
                    return;
                }
                if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
                TapAccessibilityService.FastOfferSnapshot postQuickPasadena =
                        service.fusePasadenaCityEvidence(
                                postQuickPasadenaCurrent, postQuickPasadenaEvidence);
                if (postQuickPasadena != null) {
                    String pasadenaId = postQuickPasadena.identity;
                    boolean actionable = service.claimBudget.available(
                                    pasadenaId, SystemClock.elapsedRealtime());
                    if (actionable) {
                        service.scanTiming = "排队" + (now - queuedAt)
                                + "ms；Action索引" + indexedMs
                                + "ms；快速树" + quickMs
                                + "ms；POST_QUICK_PASADENA_FAST "
                                + postQuickPasadenaMs
                                + "ms；新鲜城市证据+当前精确数值+当前Accept；跳过完整树";
                        boolean actionDispatched = service.tryFastAccept(postQuickPasadena);
                        service.lastReadableFastScan = actionDispatched
                                ? SystemClock.elapsedRealtime() : 0;
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs,
                                postQuickPasadena.text, postQuickPasadena.amount,
                                postQuickPasadena.miles);
                        if (actionDispatched) return;
                    }
                }
            }
            boolean quickDecisionReady = quick != null && service.quickDecisionTextComplete(quick);
            // v2.10.45 Fast Accept fusion: the semantic Action index can own the exact,
            // fresh Accept rectangle while its ancestor text is incomplete; the bounded quick
            // tree can simultaneously own the complete pay/miles/location decision but expose
            // no clickable Accept node. When both snapshots are fresh and provably the SAME
            // offer, combine only those complementary facts and dispatch immediately. This
            // skips the expensive full-tree reconstruction without weakening any rule, page,
            // geometry, identity, enabled-state, claim-budget, or terminal-state guard.
            boolean quickAcceptFused = false;
            boolean complementaryFused = false;
            if (quickDecisionReady) {
                TapAccessibilityService.FastOfferSnapshot fused =
                        service.fuseQuickDecisionWithIndexedAccept(quick, indexed);
                quickAcceptFused = fused != quick;
                quick = fused;
            } else {
                TapAccessibilityService.FastOfferSnapshot fused =
                        service.fuseComplementaryDecisionEvidence(quick, indexed);
                complementaryFused = fused != quick;
                quick = fused;
                quickDecisionReady = quick != null && service.quickDecisionTextComplete(quick);
            }

            if (quickDecisionReady) {
                String quickTop = quick.text;
                service.deferRejectConfirmationsForNewTop(quickTop);
                if (!service.serialTopText.isEmpty()) {
                    if (!(CardText.sameOffer(service.serialTopText, quickTop) || (service.serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(service.serialTopText, quickTop))))
                        service.retireStaleSerialLock(quickTop, "快速树确认换顶", null);
                }
                String quickFailure = service.fastRuleFailure(quick);
                float quickAlertAmount = quick.amount;
                float quickAlertMiles = quick.miles;
                boolean quickActionable = quickFailure.isEmpty()
                        ? (!quick.acceptBounds.isEmpty() && quick.acceptEnabled
                        && service.claimBudget.available(quick.identity, SystemClock.elapsedRealtime()))
                        : (service.prefs.getBoolean("autoIgnore", true) && !quick.rejectBounds.isEmpty()
                        && quick.rejectEnabled
                        && service.rejectSequence.observeVisible(quick.identity,
                        SystemClock.elapsedRealtime()) == RejectSequence.State.READY);
                if (quickActionable) {
                    service.scanTiming = "排队" + (now - queuedAt) + "ms；Action索引" + indexedMs
                            + "ms；快速树" + quickMs + "ms"
                            + (complementaryFused ? "；互补证据融合"
                            : (quickAcceptFused ? "；FastAccept融合" : "；首卡直达"));
                    boolean actionDispatched = service.tryFastAccept(quick);
                    service.lastReadableFastScan = actionDispatched ? SystemClock.elapsedRealtime() : 0;
                    if (quickFailure.isEmpty())
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, quick.text,
                                quickAlertAmount, quickAlertMiles);
                    if (actionDispatched) return;
                } else {
                    if (quickFailure.isEmpty())
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, quick.text,
                                quickAlertAmount, quickAlertMiles);
                    if (service.accessibilityOwnsDecision(quick, quickFailure)) {
                        service.holdAccessibilityDecision(quick, quickFailure, "快速树");
                        return;
                    }
                }
            }

            // If the bounded pass hit its time/node budget without producing a coherent card,
            // do not immediately stack a full-tree traversal on top of an already slow frame.
            // Force the next screen frame through OCR; this is a routing optimization only and
            // does not alter any pay/miles/city/time rule or action geometry requirement.
            // v2.10.51: before paying ML Kit latency, allow a very recent COMPLETE decision
            // cache to pair with the CURRENT indexed Accept rectangle.
            TapAccessibilityService.FastOfferSnapshot quorumFused =
                    service.fuseQualifiedPartialQuorum(indexed, quick);
            if (quorumFused != null) {
                String quorumFailure = service.fastRuleFailure(quorumFused);
                if (quorumFailure.isEmpty()
                        && service.claimBudget.available(quorumFused.identity, SystemClock.elapsedRealtime())) {
                    service.scanTiming = "排队" + (now - queuedAt) + "ms；Action索引" + indexedMs
                            + "ms；快速树" + quickMs + "ms；PARTIAL_QUORUM；OCR/完整树跳过";
                    boolean actionDispatched = service.tryFastAccept(quorumFused);
                    service.lastReadableFastScan = actionDispatched ? SystemClock.elapsedRealtime() : 0;
                    QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, quorumFused.text,
                            quorumFused.amount, quorumFused.miles);
                    if (actionDispatched) return;
                }
            }

            TapAccessibilityService.FastOfferSnapshot cacheFused =
                    service.fuseRecentCachedDecisionWithCurrentAction(indexed);
            if (cacheFused != null) {
                String cacheFailure = service.fastRuleFailure(cacheFused);
                if (cacheFailure.isEmpty()
                        && service.claimBudget.available(cacheFused.identity, SystemClock.elapsedRealtime())) {
                    service.scanTiming = "排队" + (now - queuedAt) + "ms；Action索引" + indexedMs
                            + "ms；快速树" + quickMs + "ms；跨代缓存融合；OCR跳过";
                    boolean actionDispatched = service.tryFastAccept(cacheFused);
                    service.lastReadableFastScan = actionDispatched ? SystemClock.elapsedRealtime() : 0;
                    QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, cacheFused.text,
                            cacheFused.amount, cacheFused.miles);
                    if (actionDispatched) return;
                }
            }

            if (QuickTreeBudgetPolicy.shouldYieldToOcr(quickResult.budgetExceeded, false)) {
                scanExit = "QUICK_TREE_BUDGET_OCR";
                long backoffBase = SystemClock.elapsedRealtime();
                service.quickTreeBackoffUntil = backoffBase + QuickTreeBudgetPolicy.ocrBackoffMs();
                service.scanTiming = "排队" + (now - queuedAt) + "ms；Action索引" + indexedMs
                        + "ms；快速树" + quickMs + "ms(v" + quickResult.visited
                        + ",预算退出)；OCR兜底";
                service.lastReadableFastScan = 0;
                service.lastScan = 0;
                service.updateStatus("快速树达到延迟预算；本轮跳过完整树，已转OCR兜底");
                return;
            }

            // An explicit, complete same-generation empty Offers snapshot is already the
            // strongest no-card evidence. Rewalking the entire window cannot improve the
            // decision; it only delays the next offer scan.
            if (quickResult.emptyOffers && !quickResult.budgetExceeded
                    && quickGeneration == TapAccessibilityService.currentUiGeneration()
                    && !service.fastCheckDirty.get() && !service.fastStructuralWake.get()) {
                service.lastReadableFastScan = 0L;
                service.lastScan = 0L; // OCR remains eligible on the next screen frame.
                scanExit = "QUICK_EXPLICIT_EMPTY";
                service.updateStatus("页面：OFFERS｜监控中；当前无可读订单");
                return;
            }

            // v2.10.71: newer events may preempt only during the first 140ms burst. After that,
            // continue with a fresh CURRENT tree once, otherwise a stream of incomplete RN
            // events can starve the actionable card for 1-2 seconds.
            if (service.shouldYieldFallbackToNewEvent()) return;
            // Navigation can start while the quick read is in flight. Recheck here too.
            if(service.yieldDeepScanDuringUnavailableReturn(quick,SystemClock.elapsedRealtime())) return;
            long fullStarted = SystemClock.elapsedRealtime();
            boolean idleFullFallback = idleFallback && quick == null && !quickResult.emptyContradicted
                    && !service.fastCheckDirty.get() && !service.fastStructuralWake.get();
            if (IdleFallbackPolicy.coalesceFailedFull(fullStarted,
                    service.idleFullReadFailedAt, quickGeneration,
                    service.idleFullReadFailedGeneration, idleFullFallback)) {
                // No sleep and no loss of liveness: the next 12ms scan still checks the
                // CURRENT Accept and amount/mileage; structural wakes bypass the coalescer.
                scanExit = "IDLE_FULL_RETRY_COALESCED";
                service.lastReadableFastScan = 0L;
                service.lastScan = 0L;
                return;
            }
            long fullBudget = QuickTreeBudgetPolicy.remainingFallbackMs(enteredAt, fullStarted,
                    IdleFallbackPolicy.fullBudget(60L,idleFullFallback), 0L);
            if (fullBudget < QuickTreeBudgetPolicy.MIN_TREE_SLICE_MS) {
                scanExit = "SCAN_BUDGET_BEFORE_FULL_OCR";
                service.lastReadableFastScan = 0L;
                service.lastScan = 0L;
                return;
            }
            TapAccessibilityService.FullScanResult full = TapAccessibilityService.getBoundedFastOfferSnapshots(
                    fullBudget, !service.serialTopText.isEmpty(),
                    () -> service.taskEpochCurrent(taskEpoch) && !service.fastStructuralWake.get());
            service.noteDecisionStage("fullTree");
            if (!service.taskEpochCurrent(taskEpoch)) {
                service.noteStaleTaskDrop();
                return;
            }
            if (full == null) {
                if (idleFullFallback && quickGeneration == TapAccessibilityService.currentUiGeneration()) {
                    service.idleFullReadFailedAt = SystemClock.elapsedRealtime();
                    service.idleFullReadFailedGeneration = quickGeneration;
                }
                scanExit = TapAccessibilityService.routingReadTrace();
                service.lastReadableFastScan = 0;
                service.lastScan = 0L;
                return;
            }
            service.idleFullReadFailedAt = 0L;
            TapAccessibilityService.publishFullScanPage(full);
            List<TapAccessibilityService.FastOfferSnapshot> cards = full.cards;
            service.scanTiming = "排队" + (now - queuedAt) + "ms；Action索引" + indexedMs
                    + "ms；快速树" + quickMs + "ms；完整树" + (SystemClock.elapsedRealtime() - fullStarted)
                    + "ms；可读卡片" + cards.size() + rejectRoute
                    + "；快速树结果=" + quickResult.limitReason
                    + "；完整树读取=" + TapAccessibilityService.routingReadTrace();
            service.noteDecisionStage("fullReport");
            String visibleTop = full.visibleTop;
            if (!visibleTop.isEmpty()) {
                service.deferRejectConfirmationsForNewTop(visibleTop);
            }
            if (!service.serialTopText.isEmpty()) {
                if (!visibleTop.isEmpty() && (CardText.sameOffer(service.serialTopText, visibleTop) || (service.serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(service.serialTopText, visibleTop)))) {
                    // Keep processing/waiting only for the same top card. Lower cards must not
                    // steal its button coordinates during Ignore countdown/transition states.
                } else if (!visibleTop.isEmpty()) {
                    service.retireStaleSerialLock(visibleTop, "Accessibility确认换顶", null);
                } else {
                    // Do not unlock from an empty Accessibility read alone, but also do not let
                    // that blind spot starve OCR forever. Once the original action is old enough,
                    // release only transient blockers so the rescue OCR probe can identify the
                    // actual first card and safely reconcile the serial lock.
                    long actionAge = service.serialTopActionAt > 0 ? now - service.serialTopActionAt : Long.MAX_VALUE;
                    if (actionAge >= ActionStallPolicy.rescueArmMs()) {
                        service.lastReadableFastScan = 0;
                        if (actionAge >= ActionStallPolicy.hardHoldMs()) {
                            service.cooldownUntil = 0;
                            service.accessibilityActionHoldUntil = 0;
                        }
                        service.updateStatus("顶部锁定订单Accessibility暂不可读；已启用OCR恢复探测，不会处理下面订单");
                    } else {
                        service.updateStatus("顶部订单处理中/倒计时；未确认原卡消失，继续锁定第一张");
                    }
                    return;
                }
            }
            TapAccessibilityService.FastOfferSnapshot selected = OfferPriority.choose(cards,
                    card -> service.fastRuleFailure(card).isEmpty(),
                    card -> !card.acceptBounds.isEmpty()
                            && card.acceptEnabled
                            && service.claimBudget.available(card.identity, SystemClock.elapsedRealtime()),
                    card -> service.prefs.getBoolean("autoIgnore", true) && !card.rejectBounds.isEmpty()
                            && card.rejectEnabled
                            && service.rejectSequence.observeVisible(card.identity,
                            SystemClock.elapsedRealtime()) == RejectSequence.State.READY);
            if (selected != null) {
                boolean qualified = service.fastRuleFailure(selected).isEmpty();
                float alertAmount = qualified ? selected.amount : -1f;
                float alertMiles = qualified ? selected.miles : -1f;
                boolean actionDispatched = service.tryFastAccept(selected);
                service.lastReadableFastScan = actionDispatched ? SystemClock.elapsedRealtime() : 0;
                if (qualified)
                    QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, selected.text,
                            alertAmount, alertMiles);
            } else if (!cards.isEmpty()) {
                // If a qualified card is visible but its action node is temporarily unavailable,
                // still alert the driver; there is no automated dispatch to delay in this branch.
                TapAccessibilityService.FastOfferSnapshot top = cards.get(0);
                String topFailure = service.fastRuleFailure(top);
                if (topFailure.isEmpty())
                    QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, top.text,
                            top.amount, top.miles);
                // v2.10.26: if Accessibility already has all decision fields AND the exact
                // side-specific action rectangle, OCR cannot improve a disabled/processing or
                // retry-gated state. Keep OCR as fallback only for genuinely missing evidence.
                if (service.accessibilityOwnsDecision(top, topFailure)) {
                    service.holdAccessibilityDecision(top, topFailure, "完整树");
                } else {
                    service.lastReadableFastScan = 0;
                    service.updateStatus("页面：OFFERS｜发现" + cards.size()
                            + "张卡片但辅助功能动作证据不完整；OCR兜底已激活");
                }
            } else {
                service.lastReadableFastScan = 0;
                if (service.fastCheckDirty.get()) return;
                if (full.page == PageGuard.Page.JOBS || full.page == PageGuard.Page.IGNORED) {
                    boolean recovering = service.recoverOffersPage(full.page, SystemClock.elapsedRealtime());
                    service.noteDecisionStage("pageRecovery");
                    if (recovering) { scanExit = "RETURNING_TO_OFFERS"; return; }
                }
                if (service.fastCheckDirty.get()) return;
                if (full.explicitEmpty)
                service.updateStatus(full.page == PageGuard.Page.OFFERS
                        ? "页面：OFFERS｜监控中；当前无可读订单"
                        : "页面：" + full.page + "｜仅监控Offers；未点击");
                scanExit = full.explicitEmpty ? "EMPTY_OFFERS" : "NO_READABLE_CARD";
                service.noteDecisionStage("noCardStatus");
            }
            } catch (RuntimeException failure) {
                scanExit = "READ_ERROR";
                service.lastScanError=failure.getClass();
            } finally {
                long finishedAt=SystemClock.elapsedRealtime();
                timing.completeScan(queuedAt,finishedAt,structural,priorityOffer,scanExit);
                service.liveScanHealth.finish(Math.max(0L,finishedAt-enteredAt));
                service.lastCompletedFastScan=timing;
                if (timing.isSlowScan()) service.lastSlowFastScan=timing;
                service.decisionPipelineStartedAt.remove();
                service.decisionQueueAt.remove();
                service.decisionWakeAt.remove();
                service.decisionStageTiming.remove();
                service.fastCheckQueued.set(false);
                boolean dirty=service.fastCheckDirty.getAndSet(false);
                if ((dirty || service.fastStructuralWake.get()) && service.monitorReady)
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
            }
          }
        };
        service.pendingFastCheck.set(fastAction);
        Handler lane=service.fastWorker;
        boolean urgent=priorityOffer || service.fastStructuralWake.get();
        boolean posted=lane!=null && (urgent ? lane.postAtFrontOfQueue(fastAction) : lane.post(fastAction));
        if (!posted && service.pendingFastCheck.compareAndSet(fastAction,null)) {
            if (structuralWakePending) service.fastStructuralWake.set(true);
            service.fastCheckDirty.set(true);
            service.fastCheckQueued.set(false);
        }
    }

    private void observeOfferDuringTouch(long startedAt) {
        long generation=TapAccessibilityService.currentUiGeneration();
        TapAccessibilityService.QuickTopResult result=TapAccessibilityService.getQuickTopOfferSnapshotResult(20L,64);
        long finishedAt=SystemClock.elapsedRealtime();
        scanTrace.noteRead(finishedAt,"TOUCH_READ_ONLY",new QuickReadTrace(result,startedAt,finishedAt,
                generation==TapAccessibilityService.currentUiGeneration()));
    }

    private boolean taskEpochCurrent(long expected) {
        return monitorReady && !isManualInterventionPaused()
                && expected == scanGeneration.get();
    }

    private void noteStaleTaskDrop() {
        // Intentionally no per-frame log: stale callbacks can arrive in bursts after a claim.
        // Count them for the single ACCEPT_SUCCESS summary instead of adding I/O to the hot lane.
        staleTaskDrops.incrementAndGet();
    }

    private volatile String acceptTimingText="",acceptTransactionTiming="";
    private String acceptTiming(String text,String fallback) {
        return text!=null && !acceptTransactionTiming.isEmpty() && !acceptTimingText.isEmpty()
                && (text.equals(acceptTimingText) || OfferEnrichmentPolicy.sameTransaction(text,acceptTimingText))
                ?acceptTransactionTiming:(fallback==null?"":fallback);
    }
    private void beginAcceptFrameSuppression(String text) {
        acceptTimingText=text;acceptTransactionTiming="";
        synchronized (unavailableReturnEpoch) {
            unavailableReturnEpoch.incrementAndGet();
            unavailableNavigationUntil=0L;
        }
        acceptAudit.begin(serialTopActionAt,text);
        acceptRetryEnrichedText="";
        acceptProcessingQuietChecks=0;
        acceptRetryDispatchPendingAt=0;
        visualRetryNeeded=false;visualRetryOcrProbes=0;lastVisualRetryProbeAt=0;
        visualRetryDiagnosticMask=0;
        visualRetryProof=new VisualRetryPolicy.Proof();
        activeAcceptFingerprint = CardText.identity(text);
        acceptOutcomeFence = null;
        preparedPageBaseline = null; dispatchedPageBaseline = null;
        dispatchedPageBaselineClean = false; acceptPageTracker = null;
        acceptPageProbeCount = 0; acceptPageValidProbeCount=0; acceptPageProbeStartedAt=0;

        // Pre-dispatch cancellation only: an intervening manual success may cancel a tap,
        // but this admission guard never declares success/loss for the automatic transaction.
        acceptAdmissionGuardFence = new AcceptOutcomeFence(claimEpoch.get(), serialTopActionAt,
                TapAccessibilityService.claimOutcomeEventEpoch(),
                SystemClock.elapsedRealtime(), SystemClock.uptimeMillis());
        ignoredAcceptOutcomeActionAt = 0L;
        suppressedAcceptFrames = 0;
        acceptDispatchObservationAt = 0;
        acceptGestureCompletedAt = 0;
        acceptCallbackDelayReportedForActionAt = 0;
        staleTaskDrops.set(0L);
    }

    private void suppressDuplicateAcceptFrame(String text) {
        String id = CardText.identity(text);
        if (!activeAcceptFingerprint.isEmpty() && activeAcceptFingerprint.equals(id))
            suppressedAcceptFrames = Math.min(10_000, suppressedAcceptFrames + 1);
    }

    private String consumeAcceptSuppressionSummary() {
        int count = suppressedAcceptFrames;
        suppressedAcceptFrames = 0;
        activeAcceptFingerprint = "";
        acceptDispatchObservationAt = 0;
        acceptGestureCompletedAt = 0;
        acceptCallbackDelayReportedForActionAt = 0;
        long stale = staleTaskDrops.getAndSet(0L);
        StringBuilder out = new StringBuilder();
        if (count > 0) out.append("；重复OCR帧已静默抑制×").append(count);
        if (stale > 0) out.append("；STALE_TASK_DROP×").append(stale);
        return out.toString();
    }

    private boolean sameCardAcceptObservationOnly(String incomingText) {
        return AcceptObservationPolicy.shouldObserveOnly(
                serialTopAction == SerialAction.ACCEPT,
                serialTopActionAt, acceptDispatchObservationAt, serialTopText, incomingText);
    }

    private boolean acceptCallbackCurrent(long claim, long actionEpoch, String text) {
        if (!monitorReady || claim != claimEpoch.get() || actionEpoch != scanGeneration.get()) return false;
        if (serialTopAction != SerialAction.ACCEPT || serialTopActionAt <= 0) return false;
        if (text == null || text.isEmpty() || !((CardText.sameOffer(serialTopText, text) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, text))) || verifiedAcceptRetryMatches(text))) return false;
        return true; // The live transaction/epoch owns callbacks; completed history is never a veto.
    }

    private TapAccessibilityService.FastOfferSnapshot fuseIndexedActionWithEventEvidence(
            TapAccessibilityService.FastOfferSnapshot indexed) {
        if (indexed == null || quickDecisionTextComplete(indexed)) return indexed;
        if (indexed.acceptBounds.isEmpty()) return indexed;
        TapAccessibilityService.DecisionEvidence evidence =
                TapAccessibilityService.recentDecisionEvidence(420L);
        if (evidence == null) return indexed;
        long delta = Math.abs(evidence.capturedAt - indexed.capturedAt);
        if (delta > 220L || !CardText.sameOfferForAction(indexed.text, evidence.text)) return indexed;
        return new TapAccessibilityService.FastOfferSnapshot(evidence.text,
                indexed.acceptBounds, indexed.rejectBounds,
                indexed.acceptEnabled, indexed.rejectEnabled,
                Math.max(indexed.capturedAt, evidence.capturedAt));
    }

    /**
     * v2.10.65 numeric-universal gate. General is the base acceptance branch and Pasadena is
     * additive. It is legal to skip location when no explicit city allow-list/time filter is
     * active and the exact amount/mileage already pass General. Pasadena evidence remains
     * mandatory only for Pasadena-only offers that fail General.
     */
    private boolean universallyQualifiedByNumbers(float amount, float miles) {
        return UniversalNumericFastPolicy.qualifies(amount, miles,
                prefs.getFloat("minPay", 60f), prefs.getFloat("maxMiles", 10f),
                prefs.getBoolean("pasadenaRuleEnabled", false),
                prefs.getFloat("pasadenaMinPay", 25f), prefs.getFloat("pasadenaMaxMiles", 5f),
                !prefs.getString("cities", "").trim().isEmpty(),
                decisionNeedsOfferTimeEvidence());
    }

    private boolean universallyRejectedByNumbers(float amount, float miles) {
        return UniversalNumericFastPolicy.rejects(amount, miles,
                prefs.getFloat("minPay", 60f), prefs.getFloat("maxMiles", 10f),
                prefs.getBoolean("pasadenaRuleEnabled", false),
                prefs.getFloat("pasadenaMinPay", 25f), prefs.getFloat("pasadenaMaxMiles", 5f));
    }

    private boolean generalNumbersQualified(float amount, float miles) {
        return amount >= 0f && miles >= 0f
                && amount >= prefs.getFloat("minPay", 60f)
                && miles <= prefs.getFloat("maxMiles", 10f);
    }

    private String[] configuredCityQueries() {
        String configured = prefs.getString("cities", "").trim();
        if (configured.isEmpty()) return new String[0];
        String[] split = configured.split(",");
        List<String> cleaned = new ArrayList<>();
        for (String value : split) {
            String city = value == null ? "" : value.trim();
            if (!city.isEmpty()) cleaned.add(cityIndexQuery(city));
        }
        return cleaned.toArray(new String[0]);
    }

    /** DeliverThat address labels use normal title casing. Canonicalize user input such as
     * "Los angeles" before Android's text-index query; final rule matching remains
     * case-insensitive and still validates the returned text. */
    private static String cityIndexQuery(String value) {
        String lower = value.trim().toLowerCase(Locale.US);
        StringBuilder out = new StringBuilder(lower.length());
        boolean upper = true;
        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            out.append(upper && Character.isLetter(c) ? Character.toUpperCase(c) : c);
            upper = Character.isWhitespace(c) || c == '-';
        }
        return out.toString();
    }

    /**
     * The Accept index and Reject index are separate live lookups. Require the exact numeric
     * pair plus a physically paired row before combining them, so a card swap can never reuse
     * the previous left-side action.
     */
    private boolean sameCurrentUniversalReject(
            TapAccessibilityService.FastOfferSnapshot accept,
            TapAccessibilityService.FastOfferSnapshot reject) {
        if (accept == null || reject == null || accept.acceptBounds.isEmpty()
                || reject.rejectBounds.isEmpty() || !reject.rejectEnabled
                || !universallyRejectedByNumbers(reject.amount, reject.miles)
                || Math.abs(accept.amount - reject.amount) > 0.011f
                || Math.abs(accept.miles - reject.miles) > 0.051f) return false;
        long now = SystemClock.elapsedRealtime();
        if (now < accept.capturedAt || now < reject.capturedAt
                || now - accept.capturedAt > 500L || now - reject.capturedAt > 500L) return false;
        Rect a = accept.acceptBounds, r = reject.rejectBounds;
        if (r.centerX() >= a.centerX()) return false;
        int overlap = Math.min(a.bottom, r.bottom) - Math.max(a.top, r.top);
        int centerDelta = Math.abs(a.centerY() - r.centerY());
        boolean sameRow = overlap > 0
                || centerDelta <= Math.max(18, Math.max(a.height(), r.height()) / 2);
        return sameRow && CardText.compatiblePartialActionEvidence(accept.text, reject.text);
    }

    /** Diagnostic stage only: first instant the configured rule had enough passing evidence. */
    private void noteRuleReady(float amount, float miles, long observedAt) {
        if (amount < 0 || miles < 0) return;
        long now = observedAt > 0L ? observedAt : SystemClock.elapsedRealtime();
        long key = CardText.numericTimingKey(amount, miles);
        synchronized (ruleReadyLock) {
            boolean sameBurst = key == ruleReadyNumericKey && ruleReadyFirstAt > 0L
                    && now >= ruleReadyLastAt && now - ruleReadyLastAt <= 8_000L;
            if (!sameBurst) {
                ruleReadyNumericKey = key;
                ruleReadyFirstAt = now;
            }
            ruleReadyLastAt = now;
        }
    }

    private long recentRuleReadyAt(String text, long maxAgeMs) {
        float amount = CardText.amount(text), miles = CardText.miles(text);
        if (amount < 0 || miles < 0) return 0L;
        long key = CardText.numericTimingKey(amount, miles);
        long now = SystemClock.elapsedRealtime();
        synchronized (ruleReadyLock) {
            if (key != ruleReadyNumericKey || ruleReadyFirstAt <= 0L
                    || now < ruleReadyFirstAt || now - ruleReadyFirstAt > Math.max(1L, maxAgeMs))
                return 0L;
            return ruleReadyFirstAt;
        }
    }

    private String acceptResultTiming(String text, String phase, long observedAt) {
        AcceptOutcomeFence resultFence = acceptFenceFor(serialTopActionAt);
        long dispatchedAt = acceptDispatchObservationAt;
        long callAt = resultFence == null ? 0L : resultFence.dispatchElapsed;
        StringBuilder timing = new StringBuilder();
        if (dispatchedAt > 0L && observedAt >= dispatchedAt)
            timing.append("；FIRST_DISPATCH_ACK→").append(phase).append('=')
                    .append(observedAt - dispatchedAt).append("ms");
        if (callAt > 0L && observedAt >= callAt)
            timing.append("；FIRST_DISPATCH_CALL→").append(phase).append('=')
                    .append(observedAt - callAt).append("ms");
        long numericAt = TapAccessibilityService.recentFirstSeenAt(CardText.identity(text), 8_000L);
        if (numericAt > 0L && observedAt >= numericAt)
            timing.append("；LOCAL_NUMERIC_OBSERVED→").append(phase).append('=')
                    .append(observedAt - numericAt).append("ms");
        return timing.toString();
    }

    private String acceptStageTiming(String text, String identity, long dispatchAt) {
        StringBuilder timing = new StringBuilder();
        long numericAt = TapAccessibilityService.recentFirstSeenAt(identity, 8_000L);
        if (numericAt > 0L) timing.append("；FIRST_SEEN_NUMERIC首见→dispatch=")
                .append(Math.max(0L, dispatchAt - numericAt)).append("ms；NUMERIC_SEEN_ELAPSED=").append(numericAt);
        long ruleAt = recentRuleReadyAt(text, 8_000L);
        if (ruleAt > 0L) timing.append("；RULE_READY→dispatch=")
                .append(Math.max(0L, dispatchAt - ruleAt)).append("ms；RULE_READY_ELAPSED=").append(ruleAt);
        long anchorAt = TapAccessibilityService.recentAcceptAnchorFirstSeenAt(text, 8_000L);
        if (anchorAt > 0L) timing.append("；ACCEPT_ANCHOR首见→dispatch=")
                .append(Math.max(0L, dispatchAt - anchorAt)).append("ms；ACCEPT_ANCHOR_ELAPSED=").append(anchorAt);
        return timing.toString();
    }

    /**
     * The current semantic Accept ancestry is authoritative for action geometry and MUST
     * independently expose the same numeric pair. Event evidence may only enrich identity/text
     * so FIRST_SEEN and transaction de-dupe remain stable across React-Native event generations.
     */
    private TapAccessibilityService.FastOfferSnapshot fuseUniversalNumericEvidence(
            TapAccessibilityService.FastOfferSnapshot current,
            TapAccessibilityService.DecisionEvidence evidence) {
        if (current == null || evidence == null || current.acceptBounds.isEmpty()
                || !current.acceptEnabled || current.amount < 0 || current.miles < 0) return null;
        long now = SystemClock.elapsedRealtime();
        if (now < current.capturedAt || now - current.capturedAt > 360L) return null;
        if (Math.abs(current.amount - evidence.amount) > 0.011f
                || Math.abs(current.miles - evidence.miles) > 0.051f) return null;
        if (!CardText.compatiblePartialActionEvidence(evidence.text, current.text)) return null;
        String merged = (evidence.text + " " + current.text).replaceAll("\\s+", " ").trim();
        return current.withDecisionText(merged);
    }

    /** Bind fresh decision text only to a CURRENT enabled Reject that re-proved both numbers. */
    private TapAccessibilityService.FastOfferSnapshot fuseCurrentNumericRejectEvidence(
            TapAccessibilityService.FastOfferSnapshot current,
            TapAccessibilityService.DecisionEvidence evidence,
            boolean requireCompleteFailure) {
        if (current == null || evidence == null || current.rejectBounds.isEmpty()
                || !current.rejectEnabled || current.amount < 0 || current.miles < 0) return null;
        long now = SystemClock.elapsedRealtime();
        if (now < current.capturedAt || now - current.capturedAt > 360L
                || now < evidence.capturedAt || now - evidence.capturedAt > 650L) return null;
        if (Math.abs(current.amount - evidence.amount) > 0.011f
                || Math.abs(current.miles - evidence.miles) > 0.051f
                || !CardText.compatiblePartialActionEvidence(evidence.text, current.text))
            return null;
        String merged = (evidence.text + " " + current.text).replaceAll("\\s+", " ").trim();
        if (CardText.containsConflictingOfferNumbers(merged)) return null;
        if (requireCompleteFailure
                && (!quickDecisionTextComplete(merged, current.amount, current.miles)
                || fastRuleFailure(merged, current.amount, current.miles).isEmpty())) return null;
        return current.withDecisionText(merged);
    }

    private boolean pasadenaOnlyEvidenceQualified(
            TapAccessibilityService.DecisionEvidence evidence) {
        if (evidence == null || !prefs.getBoolean("pasadenaRuleEnabled", false)
                || evidence.amount < 0f || evidence.miles < 0f
                || !quickDecisionTextComplete(evidence.text, evidence.amount, evidence.miles)
                || !PasadenaRuleGuard.isPasadenaOffer(evidence.text)) return false;
        boolean generalQualified = evidence.amount >= prefs.getFloat("minPay", 60f)
                && evidence.miles <= prefs.getFloat("maxMiles", 10f);
        boolean pasadenaQualified = evidence.amount
                        >= prefs.getFloat("pasadenaMinPay", 25f)
                && evidence.miles <= prefs.getFloat("pasadenaMaxMiles", 5f);
        return !generalQualified && pasadenaQualified
                && fastRuleFailure(evidence.text, evidence.amount, evidence.miles).isEmpty();
    }

    /** Numeric pre-gate for the indexed first-publish city proof; never authorizes a tap. */
    private boolean pasadenaNumericCandidate(
            TapAccessibilityService.DecisionEvidence evidence) {
        if (evidence == null || !prefs.getBoolean("pasadenaRuleEnabled", false)
                || evidence.amount < 0f || evidence.miles < 0f) return false;
        boolean generalQualified = evidence.amount >= prefs.getFloat("minPay", 60f)
                && evidence.miles <= prefs.getFloat("maxMiles", 10f);
        boolean pasadenaNumbersQualified = evidence.amount
                        >= prefs.getFloat("pasadenaMinPay", 25f)
                && evidence.miles <= prefs.getFloat("pasadenaMaxMiles", 5f);
        return !generalQualified && pasadenaNumbersQualified;
    }

    private TapAccessibilityService.FastOfferSnapshot fusePasadenaCityEvidence(
            TapAccessibilityService.FastOfferSnapshot current,
            TapAccessibilityService.DecisionEvidence evidence) {
        if (current == null || evidence == null || current.acceptBounds.isEmpty()
                || !current.acceptEnabled || current.amount < 0f || current.miles < 0f)
            return null;
        long now = SystemClock.elapsedRealtime();
        if (now < current.capturedAt || now < evidence.capturedAt
                || now - current.capturedAt > 360L || now - evidence.capturedAt > 420L
                || Math.abs(current.capturedAt - evidence.capturedAt) > 420L) return null;
        if (Math.abs(current.amount - evidence.amount) > 0.011f
                || Math.abs(current.miles - evidence.miles) > 0.051f
                || !CardText.compatiblePartialActionEvidence(evidence.text, current.text))
            return null;
        String currentPickup = OfferEnrichmentPolicy.pickupKey(current.text);
        String cachedPickup = OfferEnrichmentPolicy.pickupKey(evidence.text);
        String currentOrder = CardText.orderId(current.text), cachedOrder = CardText.orderId(evidence.text);
        String currentEndpoint = OfferEnrichmentPolicy.endpointKey(current.text);
        String cachedEndpoint = OfferEnrichmentPolicy.endpointKey(evidence.text);
        if ((!currentPickup.isEmpty() && !cachedPickup.isEmpty() && !currentPickup.equals(cachedPickup))
                || (!currentOrder.isEmpty() && !cachedOrder.isEmpty() && !currentOrder.equals(cachedOrder))
                || (!currentEndpoint.isEmpty() && !cachedEndpoint.isEmpty()
                        && !currentEndpoint.equals(cachedEndpoint))) return null;
        String merged = (evidence.text + " " + current.text)
                .replaceAll("\\s+", " ").trim();
        float mergedAmount = offerLowAmount(merged);
        float mergedMiles = offerMiles(merged);
        if (!quickDecisionTextComplete(merged, mergedAmount, mergedMiles)
                || !PasadenaRuleGuard.isPasadenaOffer(merged)
                || !fastRuleFailure(merged, mergedAmount, mergedMiles).isEmpty()) return null;
        // Keep the originating live read receipt, baseline and refreshable witness.
        // Cached enrichment must not make that receipt newer than the current index.
        return current.withDecisionText(merged);
    }

    /**
     * Accept-only sibling of tryFastAccept for the universal numeric proof above. It deliberately
     * does not call fastRuleFailure(), because that function requires location whenever Pasadena
     * is enabled. The universal gate has already proven that either city classification produces
     * the same Accept result. All claim-budget, geometry, page and terminal guards remain in
     * dispatchClaim().
     */
    private boolean tryUniversalNumericAccept(TapAccessibilityService.FastOfferSnapshot snapshot) {
        return snapshot != null && universallyQualifiedByNumbers(snapshot.amount, snapshot.miles)
                && dispatchUniversalNumericAccept(snapshot);
    }

    private boolean dispatchUniversalNumericAccept(TapAccessibilityService.FastOfferSnapshot snapshot) {
        // Every currently published offer uses the live numeric decision immediately.
        // Past unavailable attempts cannot suppress a newly visible Accept.
        noteRuleReady(snapshot.amount, snapshot.miles, SystemClock.elapsedRealtime());
        scanTiming = scanTiming + "；通用数值规则0ms";
        if (prefs.getBoolean("dryRun", false)) {
            cooldownUntil = SystemClock.elapsedRealtime() + 5_000L;
            offerReporter(snapshot.text).accept(String.format(Locale.US,
                    "通用数值快速通道测试通过：$%.2f / %.1f mi；未点击",
                    snapshot.amount, snapshot.miles));
            playAlert();
            return true;
        }
        clearPendingIgnore();
        return dispatchClaim(snapshot);
    }

    /** Read-only suppresses only redundant fallback for a freshly indexed disabled row. */
    private boolean currentDisabledOwnedReject(TapAccessibilityService.FastOfferSnapshot observed) {
        long now=SystemClock.elapsedRealtime();
        if (observed==null || observed.capturedAt>now || now-observed.capturedAt>48L
                || observed.rejectEnabled || !"REJECT_DISABLED".equals(observed.rejectReuseReason)
                || OfferEnrichmentPolicy.endpointKey(observed.text).isEmpty()
                || CardText.containsConflictingOfferNumbers(observed.text)
                || CardText.containsConflictingPickupEvidence(observed.text)
                || OfferEnrichmentPolicy.containsConflictingAddresses(observed.text)) return false;
        if (rejectSequence.acknowledgedRedraw(observed.text,now)) return true;
        RejectConfirmState owner=rejectConfirmStates.get(observed.identity);
        return owner!=null && rejectTerminalGate.isCurrent(owner.id,owner.token)
                && now>=owner.lastActionAt && now-owner.lastActionAt<=600L
                && OfferEnrichmentPolicy.sameTransaction(owner.text,observed.text);
    }

    /** Universal numeric Reject sibling; action geometry and transaction gates stay unchanged. */
    private boolean tryUniversalNumericReject(TapAccessibilityService.FastOfferSnapshot snapshot) {
        if (snapshot == null || !universallyRejectedByNumbers(snapshot.amount, snapshot.miles))
            return false;
        // Reject also evaluates each currently published card without old-loss aliases.
        scanTiming = scanTiming + "；通用必拒规则0ms";
        String reason;
        if (prefs.getBoolean("pasadenaRuleEnabled", false)) {
            reason = "金额/里程无法通过普通或Pasadena组任一数值规则";
            if (MONEY_RANGE.matcher(snapshot.text).find())
                reason += "（区间按下限$" + String.format(Locale.US, "%.2f", snapshot.amount)
                        + "判断）";
        } else {
            reason = numericFailureDetail(snapshot.text, snapshot.amount, snapshot.miles, false,
                    prefs.getFloat("minPay", 60f), prefs.getFloat("maxMiles", 10f),
                    prefs.getFloat("pasadenaMinPay", 25f), prefs.getFloat("pasadenaMaxMiles", 5f));
        }
        return handleFastRejection(snapshot, snapshot.amount, snapshot.miles, reason);
    }

    /**
     * v2.10.57 EVENT_BURST_FAST fusion. The current semantic Accept index owns the only action
     * rectangle we may use. A very recent cross-generation event fragment may contribute fields
     * only after the CURRENT Accept ancestry independently re-proves the exact amount+mileage.
     * The merged text must still satisfy the unchanged city/time completeness gate.
     */
    private TapAccessibilityService.FastOfferSnapshot fuseIndexedActionWithEventBurstEvidence(
            TapAccessibilityService.FastOfferSnapshot indexed) {
        if (indexed == null || quickDecisionTextComplete(indexed)
                || indexed.acceptBounds.isEmpty() || !indexed.acceptEnabled) return indexed;
        TapAccessibilityService.DecisionEvidence evidence =
                TapAccessibilityService.recentEventBurstDecisionEvidence(650L);
        if (evidence == null) return indexed;
        long now = SystemClock.elapsedRealtime();
        if (now < indexed.capturedAt || now - indexed.capturedAt > 360L) return indexed;
        float currentAmount = offerLowAmount(indexed.text);
        float currentMiles = offerMiles(indexed.text);
        if (currentAmount < 0 || currentMiles < 0
                || Math.abs(currentAmount - evidence.amount) > 0.011f
                || Math.abs(currentMiles - evidence.miles) > 0.051f) return indexed;
        if (!CardText.compatiblePartialActionEvidence(evidence.text, indexed.text)) return indexed;
        String merged = (evidence.text + " " + indexed.text).replaceAll("\\s+", " ").trim();
        float mergedAmount = offerLowAmount(merged);
        float mergedMiles = offerMiles(merged);
        if (!quickDecisionTextComplete(merged, mergedAmount, mergedMiles)) return indexed;
        return new TapAccessibilityService.FastOfferSnapshot(merged,
                indexed.acceptBounds, indexed.rejectBounds, true, indexed.rejectEnabled,
                Math.max(indexed.capturedAt, evidence.capturedAt));
    }

    /**
     * Hold only the expensive fallback lane for at most 48ms from first numeric sighting.
     * New Accessibility events mark fastCheckDirty and rerun immediately; the 8ms timer is
     * merely a backstop when React-Native does not emit another event. Reject/action semantics
     * are untouched and the normal path resumes automatically when the tiny window expires.
     */
    private boolean deferForEventBurstFastPath(
            TapAccessibilityService.FastOfferSnapshot indexed) {
        TapAccessibilityService.DecisionEvidence evidence =
                TapAccessibilityService.recentEventBurstDecisionEvidence(EVENT_BURST_FAST_WINDOW_MS);
        // Numeric rejects already have a decision. Let the current Reject row prove the
        // action instead of waiting for Accept fields that cannot change the outcome.
        if (evidence == null || universallyRejectedByNumbers(evidence.amount, evidence.miles))
            return false;
        long firstSeen = TapAccessibilityService.recentFirstSeenAt(
                evidence.identity, EVENT_BURST_FAST_WINDOW_MS + 40L);
        long now = SystemClock.elapsedRealtime();
        if (firstSeen <= 0L || now < firstSeen || now - firstSeen >= EVENT_BURST_FAST_WINDOW_MS)
            return false;
        // If the current Accept ancestry already exposes numeric fields, they must match the
        // burst evidence. An isolated/partial Accept is allowed to WAIT, but never to ACT.
        if (indexed != null && indexed.text != null && !indexed.text.trim().isEmpty()) {
            float currentAmount = offerLowAmount(indexed.text);
            float currentMiles = offerMiles(indexed.text);
            if ((currentAmount >= 0 && Math.abs(currentAmount - evidence.amount) > 0.011f)
                    || (currentMiles >= 0 && Math.abs(currentMiles - evidence.miles) > 0.051f))
                return false;
        }
        long remaining = EVENT_BURST_FAST_WINDOW_MS - (now - firstSeen);
        long delay = Math.max(1L, Math.min(EVENT_BURST_RETRY_MS, remaining));
        scanTiming = "EVENT_BURST_WAIT " + (now - firstSeen)
                + "ms；等待当前卡字段/Accept完成导出；不进快速树/完整树";
        Handler worker = fastWorker;
        if (worker != null) worker.postDelayed(
                () -> requestImmediateFastCheck(SystemClock.uptimeMillis()), delay);
        return true;
    }

    /**
     * v2.10.45: fuse a complete bounded-quick-tree decision with the exact Accept rectangle
     * already discovered by the semantic Action index. This is intentionally Accept-only.
     * Reject geometry/state is left untouched. Both snapshots must be adjacent in time and
     * remain adjacent in time. The quick tree is authoritative for decision fields; the
     * Action index may omit ancestry fields, but any indexed field that is present must agree.
     */
    private TapAccessibilityService.FastOfferSnapshot fuseQuickDecisionWithIndexedAccept(
            TapAccessibilityService.FastOfferSnapshot quick,
            TapAccessibilityService.FastOfferSnapshot indexed) {
        if (quick == null || indexed == null || !quickDecisionTextComplete(quick)) return quick;
        if (indexed.acceptBounds.isEmpty() || !indexed.acceptEnabled) return quick;
        long now = SystemClock.elapsedRealtime();
        if (now - quick.capturedAt > 420L || now - indexed.capturedAt > 420L) return quick;
        long delta = Math.abs(quick.capturedAt - indexed.capturedAt);
        if (delta > 260L || !CardText.compatiblePartialActionEvidence(quick.text, indexed.text)) return quick;
        return new TapAccessibilityService.FastOfferSnapshot(quick.text,
                indexed.acceptBounds, quick.rejectBounds,
                true, quick.rejectEnabled,
                Math.max(quick.capturedAt, indexed.capturedAt));
    }

    /**
     * v2.10.49: merge complementary partial Accessibility evidence before paying for a full-tree
     * reconstruction. The semantic Accept index owns the exact action rectangle; the bounded
     * quick tree may own missing mileage/location ancestry (or vice versa). Existing fields may
     * be missing but may never conflict. The merged text must itself satisfy the unchanged rule
     * completeness gate before it can act.
     */
    private TapAccessibilityService.FastOfferSnapshot fuseComplementaryDecisionEvidence(
            TapAccessibilityService.FastOfferSnapshot quick,
            TapAccessibilityService.FastOfferSnapshot indexed) {
        if (quick == null || indexed == null || indexed.acceptBounds.isEmpty()
                || !indexed.acceptEnabled) return quick;
        long now = SystemClock.elapsedRealtime();
        if (now - quick.capturedAt > 420L || now - indexed.capturedAt > 420L) return quick;
        if (Math.abs(quick.capturedAt - indexed.capturedAt) > 260L) return quick;
        if (!CardText.compatibleComplementaryEvidence(indexed.text, quick.text)) return quick;

        String mergedText = (indexed.text + " " + quick.text).replaceAll("\\s+", " ").trim();
        float amount = offerLowAmount(mergedText);
        float miles = offerMiles(mergedText);
        if (!quickDecisionTextComplete(mergedText, amount, miles)) return quick;
        return new TapAccessibilityService.FastOfferSnapshot(mergedText,
                indexed.acceptBounds, quick.rejectBounds, true, quick.rejectEnabled,
                Math.max(quick.capturedAt, indexed.capturedAt));
    }


    /**
     * v2.10.51: tolerate harmless React-Native uiGeneration churn immediately before OCR.
     * The action rectangle must come from the CURRENT semantic Accept index; only the decision
     * fields may come from a very recent cache, and every field present in the current partial
     * card must agree. This never reuses old button geometry and never acts on a bare Accept.
     */
    private TapAccessibilityService.FastOfferSnapshot fuseRecentCachedDecisionWithCurrentAction(
            TapAccessibilityService.FastOfferSnapshot indexed) {
        if (indexed == null || indexed.acceptBounds.isEmpty() || !indexed.acceptEnabled) return null;
        TapAccessibilityService.DecisionEvidence cached =
                TapAccessibilityService.recentDecisionEvidence(300L);
        if (cached == null || ClaimSuccessSignals.hasAcceptedJobDetail(cached.text)
                || !quickDecisionTextComplete(cached.text, cached.amount, cached.miles)) return null;
        long now = SystemClock.elapsedRealtime();
        if (now - indexed.capturedAt > 320L || now - cached.capturedAt > 300L) return null;
        if (!CardText.compatiblePartialActionEvidence(cached.text, indexed.text)) return null;
        return new TapAccessibilityService.FastOfferSnapshot(cached.text, indexed.acceptBounds,
                indexed.rejectBounds, true, indexed.rejectEnabled,
                Math.max(cached.capturedAt, indexed.capturedAt));
    }

    /**
     * v2.10.52 qualified partial quorum. The CURRENT semantic Accept index owns geometry.
     * A bounded quick-tree fragment plus a <=260ms cross-generation cache may jointly prove
     * the same card even when neither current snapshot alone contains every location/time node.
     * Existing numeric fields may never conflict; final merged evidence must pass the unchanged
     * decision-completeness gate.
     */
    private TapAccessibilityService.FastOfferSnapshot fuseQualifiedPartialQuorum(
            TapAccessibilityService.FastOfferSnapshot indexed,
            TapAccessibilityService.FastOfferSnapshot quick) {
        if (indexed == null || indexed.acceptBounds.isEmpty() || !indexed.acceptEnabled) return null;
        TapAccessibilityService.DecisionEvidence cached =
                TapAccessibilityService.recentCrossGenerationDecisionEvidence(260L);
        if (cached == null || !quickDecisionTextComplete(cached.text, cached.amount, cached.miles)) return null;
        long now = SystemClock.elapsedRealtime();
        if (now - indexed.capturedAt > 340L || now - cached.capturedAt > 260L) return null;
        String current = indexed.text == null ? "" : indexed.text;
        if (quick != null && now - quick.capturedAt <= 340L) {
            if (!current.isEmpty() && quick.text != null && !quick.text.trim().isEmpty()
                    && !CardText.compatibleComplementaryEvidence(current, quick.text)) return null;
            current = (current + " " + quick.text).trim();
        }
        if (current.isEmpty() || !CardText.compatiblePartialActionEvidence(cached.text, current)) return null;
        // Require two current evidence sources unless the current fragment itself carries both
        // money and mileage. This prevents a stale cache + isolated Accept label from acting.
        float currentAmount = offerLowAmount(current), currentMiles = offerMiles(current);
        if ((quick == null || quick.text == null || quick.text.trim().isEmpty())
                && (currentAmount < 0 || currentMiles < 0)) return null;
        return new TapAccessibilityService.FastOfferSnapshot(cached.text, indexed.acceptBounds,
                quick == null ? indexed.rejectBounds : quick.rejectBounds, true,
                quick == null ? indexed.rejectEnabled : quick.rejectEnabled,
                Math.max(indexed.capturedAt, cached.capturedAt));
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        acceptReplay = new AcceptReplay(this);
        try {
            android.content.pm.PackageInfo installed = getPackageManager().getPackageInfo(getPackageName(), 0);
            engineVersion = installed.versionName;
            engineVersionCode = installed.getLongVersionCode();
        }
        catch (Exception ignored) { }
        activeInstance = this;
        prefs = getSharedPreferences("rules", MODE_PRIVATE);
        MANUAL_INTERVENTION_PAUSED.set(
                prefs.getBoolean("manualInterventionPaused", false));
        loadUnavailableTombstones();
        // One-time upgrade from the old 140 ms default. Preserve any non-default value the
        // user chose manually, but move untouched installs to the lower-latency profile.
        if (!prefs.getBoolean("v2106SpeedProfileApplied", false)) {
            SharedPreferences.Editor migration = prefs.edit().putBoolean("v2106SpeedProfileApplied", true);
            if (prefs.getInt("interval", 140) == 140) migration.putInt("interval", DEFAULT_SCAN_INTERVAL_MS);
            migration.apply();
        }
        // v2.10.99: move the two previously recommended presets to the requested 40 ms race
        // profile on upgrade. Preserve every other explicit user value. The Accessibility hot
        // lane was already bounded at 40 ms; this aligns the frame/OCR scheduler with it.
        if (!prefs.getBoolean("v21099Speed40Applied", false)) {
            int oldInterval = prefs.getInt("interval", 80);
            SharedPreferences.Editor migration = prefs.edit()
                    .putBoolean("v21099Speed40Applied", true);
            if (oldInterval == 80 || oldInterval == 60)
                migration.putInt("interval", DEFAULT_SCAN_INTERVAL_MS);
            migration.apply();
        }
        // v2.10.125: the settings screen previously clamped a user-entered 20ms value to
        // 40ms before saving. Migrate that indistinguishable stored 40ms value once so the
        // requested Galaxy A15 race profile finally becomes real end-to-end.
        if (!prefs.getBoolean("v210125Speed20Applied", false)) {
            int oldInterval = prefs.getInt("interval", 40);
            SharedPreferences.Editor migration = prefs.edit()
                    .putBoolean("v210125Speed20Applied", true);
            if (oldInterval == 40) migration.putInt("interval", DEFAULT_SCAN_INTERVAL_MS);
            migration.apply();
        }
        createChannel();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        workerThread = new HandlerThread("screen-ocr", android.os.Process.THREAD_PRIORITY_DISPLAY);
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        fastThread = new HandlerThread("offer-fast", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        fastThread.start();
        fastWorker = new Handler(fastThread.getLooper());
        idlePresenceThread=new HandlerThread("offer-idle-presence",android.os.Process.THREAD_PRIORITY_BACKGROUND);
        idlePresenceThread.start();
        idlePresenceWorker=new Handler(idlePresenceThread.getLooper());
        acceptClickThread=new HandlerThread("accept-click",android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        acceptClickThread.start();acceptClickWorker=new Handler(acceptClickThread.getLooper());
        // Post-dispatch probes must not wait behind repeated top-card scans/inspectors.
        // Ownership fences, 150ms read budget and 3s total deadline still gate every read.
        acceptOutcomeThread = new HandlerThread("accept-outcome", android.os.Process.THREAD_PRIORITY_DEFAULT);
        acceptOutcomeThread.start();
        acceptOutcomeWorker = new Handler(acceptOutcomeThread.getLooper());
        acceptProofThread = new HandlerThread("accept-enabled-proof",android.os.Process.THREAD_PRIORITY_DISPLAY);
        acceptProofThread.start();acceptProofWorker=new Handler(acceptProofThread.getLooper());
        rejectConfirmThread = new HandlerThread("reject-confirm", android.os.Process.THREAD_PRIORITY_BACKGROUND);
        rejectConfirmThread.start();
        rejectConfirmWorker = new Handler(rejectConfirmThread.getLooper());
        scanDiagnosticThread=new HandlerThread("scan-diagnostics",android.os.Process.THREAD_PRIORITY_BACKGROUND);
        scanDiagnosticThread.start();
        scanDiagnosticWorker=new Handler(scanDiagnosticThread.getLooper());
        restoreManualPauseTimer();
        warmRecognizer();
    }

    @Override
    public synchronized int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !intent.hasExtra("resultData")) return START_NOT_STICKY;
        // A fresh, explicit screen-capture start is also an explicit request to resume.
        MANUAL_INTERVENTION_PAUSED.set(false);
        manualInterventionConfirmed = false;
        MANUAL_PAUSE_EPOCH.incrementAndGet();
        prefs.edit().putBoolean("manualInterventionPaused", false)
                .putBoolean("manualInterventionConfirmed", false)
                .remove("manualInterventionDeadline").apply();
        unownedInteractionUntil=0L;
        if (monitorReady && projection!=null) {
            acquirePerformanceWakeLock();
            updateStatus("监控已运行；规则已更新，自动检查Offers页面");
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, statusNotification(String.format(Locale.US,
                "等待画面｜生效规则：最低$%.2f / 最高%.1f mi",
                prefs.getFloat("minPay", 60f), prefs.getFloat("maxMiles", 10f))));

        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent resultData = intent.getParcelableExtra("resultData");
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        try {
            final MediaProjection startedProjection=manager.getMediaProjection(resultCode,resultData);
            if (startedProjection==null) throw new IllegalStateException("Screen capture permission expired");
            projection=startedProjection;
            startedProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    onScreenCaptureEnded(startedProjection);
                }
            },worker);

            DisplayMetrics dm=Resources.getSystem().getDisplayMetrics();
            width=dm.widthPixels;
            height=dm.heightPixels;
            density=dm.densityDpi;
            reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);
            virtualDisplay=startedProjection.createVirtualDisplay("ocr-capture",width,height,density,
                    0,reader.getSurface(),null,worker);
            if (virtualDisplay==null) throw new IllegalStateException("Capture display unavailable");
            reader.setOnImageAvailableListener(this::onFrame,worker);
        } catch (RuntimeException failure) {
            android.util.Log.w("CSA","Screen capture unavailable",failure);
            MediaProjection failed=projection;
            projection=null;
            releaseScreenCapture();
            if (failed!=null) failed.stop();
            updateStatus("屏幕捕获不可用；无障碍扫描继续运行");
        }
        monitorReady = true;
        scanTrace.note(SystemClock.elapsedRealtime(),"MONITOR_STARTED version="+engineVersion
                +" code="+engineVersionCode+" session="+engineSessionAt);
        acquirePerformanceWakeLock();
        fastWorker.removeCallbacks(continuousCheck);
        fastWorker.post(continuousCheck);
        scanDiagnosticWorker.removeCallbacks(scanDiagnosticCheck);
        scanDiagnosticWorker.post(scanDiagnosticCheck);
        return START_NOT_STICKY;
    }

    private synchronized void onScreenCaptureEnded(MediaProjection stopped) {
        if (projection!=stopped) return;
        projection=null;
        releaseScreenCapture();
        if (monitorReady) {
            updateStatus("屏幕捕获已结束；无障碍扫描继续运行");
            requestImmediateFastCheck(SystemClock.uptimeMillis(),true);
        }
    }

    private void releaseScreenCapture() {
        if (virtualDisplay!=null) {
            virtualDisplay.release();
            virtualDisplay=null;
        }
        ImageReader previous=reader;
        reader=null;
        if (previous!=null) {
            previous.setOnImageAvailableListener(null,null);
            previous.close();
        }
    }

    /** Keep both the CPU and the display active for the monitoring session. */
    @SuppressWarnings("deprecation")
    private void acquirePerformanceWakeLock() {
        PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
        if (power == null) return;
        try {
            if (monitorWakeLock == null) {
                monitorWakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        "CateringScreenAssistant:OfferMonitor");
                monitorWakeLock.setReferenceCounted(false);
            }
            if (!monitorWakeLock.isHeld()) monitorWakeLock.acquire();
        } catch (RuntimeException failure) {
            android.util.Log.w("CSA", "Could not keep monitoring CPU awake", failure);
        }
        try {
            if (monitorScreenWakeLock == null) {
                monitorScreenWakeLock = power.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK,
                        "CateringScreenAssistant:OfferScreen");
                monitorScreenWakeLock.setReferenceCounted(false);
            }
            if (!monitorScreenWakeLock.isHeld()) monitorScreenWakeLock.acquire();
        } catch (RuntimeException failure) {
            android.util.Log.w("CSA", "Could not keep monitoring screen on", failure);
        }
    }

    private void releasePerformanceWakeLock() {
        try {
            if (monitorWakeLock != null && monitorWakeLock.isHeld()) monitorWakeLock.release();
        } catch (RuntimeException ignored) { }
        try {
            if (monitorScreenWakeLock != null && monitorScreenWakeLock.isHeld())
                monitorScreenWakeLock.release();
        } catch (RuntimeException ignored) { }
        monitorWakeLock = null;
        monitorScreenWakeLock = null;
    }

    private RejectConfirmState ownedRejectForText(String text) {
        if (text == null || CardText.containsConflictingOfferNumbers(text)
                || OfferEnrichmentPolicy.containsConflictingAddresses(text)
                || CardText.containsConflictingPickupEvidence(text)
                || LargeOrderPopupGuard.isPopupText(text)
                || ClaimSuccessSignals.hasAcceptedJobDetail(text)
                || ClaimSuccessSignals.hasBeginDeliveryControl(text)) return null;
        for (RejectConfirmState state : rejectConfirmStates.values()) {
            if (rejectTerminalGate.isCurrent(state.id, state.token)
                    && (RejectWorkPolicy.sameOwnedOffer(state.text, text)
                        || OfferEnrichmentPolicy.sameTransaction(state.text, text))) return state;
        }
        return null;
    }

    /** Coalesce only the initial fresh semantic redraw; unknown/new frames retain OCR fallback. */
    private boolean skipFreshOwnedRejectOcr(long now) {
        TapAccessibilityService.DecisionEvidence evidence = TapAccessibilityService.recentDecisionEvidence(100L);
        if (evidence == null || evidence.uiGeneration != TapAccessibilityService.currentUiGeneration()
                || evidence.capturedAt > now || foregroundOfferDemandRecent(100L)) return false;
        RejectConfirmState owner = ownedRejectForText(evidence.text);
        long actionAt=owner!=null ? owner.actionAt : serialTopAction==SerialAction.REJECT
                && RejectWorkPolicy.sameOwnedOffer(serialTopText,evidence.text) ? serialTopActionAt : 0L;
        return actionAt>0L && now>=actionAt && now-actionAt<180L;
    }

    /** Coalesce only ordinary OCR of a freshly re-proven current owned offer.
     * Terminal/visual-retry probes bypass this helper; unknown/new cards keep normal OCR. */
    private boolean skipFreshOwnedAcceptOcr(long now) {
        if(serialTopAction!=SerialAction.ACCEPT || serialTopActionAt<=0L
                || !acceptGestureDispatchedForCurrentTransaction()
                || foregroundOfferDemandRecent(100L)
                || !pageBoundOutcome(serialTopActionAt).isEmpty()) return false;
        TapAccessibilityService.DecisionEvidence evidence=TapAccessibilityService.recentDecisionEvidence(100L);
        return evidence!=null && evidence.capturedAt<=now && now-evidence.capturedAt<=100L
                && evidence.uiGeneration==TapAccessibilityService.currentUiGeneration()
                && !OfferEnrichmentPolicy.containsConflictingAddresses(evidence.text)
                && !CardText.containsConflictingPickupEvidence(evidence.text)
                && IndexedWitnessPolicy.sameIdentity(serialTopText,evidence.text);
    }

    private void rememberOwnedRejectFrame(Bitmap roi, RejectConfirmState owner, long at) {
        if(owner==null || roi==null) return;
        int w=roi.getWidth(),h=roi.getHeight();
        int[] rgba=new int[w*h];
        roi.getPixels(rgba,0,w,0,0,w,h);
        for(int i=0;i<rgba.length;i++) {
            int c=rgba[i];rgba[i]=(c&0xff00ff00)|((c>>16)&255)|((c&255)<<16);
        }
        synchronized(rejectedRoiLock) {
            rejectedRoiPixels=rgba;rejectedRoiWidth=w;rejectedRoiHeight=h;
            rejectedRoiOwner=owner;rejectedRoiAt=at;
        }
    }

    private volatile long unownedInteractionUntil;
    private long pageRecoveryRetryAt;

    public static void noteUnownedUiInteraction() {
        OcrMonitorService service = activeInstance;
        if (service == null || SystemClock.elapsedRealtime() - service.lastActionDispatchAt < 1000L)
            return;
        noteManualTouch();
    }

    public static void noteManualTouch() {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady) return;
        service.unownedInteractionUntil = SystemClock.elapsedRealtime() + 3000L;
        service.scanGeneration.incrementAndGet();
    }

    private boolean recoverOffersPage(long now) {
        return recoverOffersPage(TapAccessibilityService.recentPageHint(), now);
    }

    private boolean recoverOffersPage(PageGuard.Page page, long now) {
        if (page != PageGuard.Page.JOBS && page != PageGuard.Page.IGNORED) return false;
        if (isManualInterventionPaused() || prefs.getBoolean("dryRun", false)
                || !TapAccessibilityService.isDeliverThatForeground()
                || serialTopAction != SerialAction.NONE || postClaimIsolationActive
                || acceptAdmissionBusy.get() || isPostTerminalSuccessCandidate(postTerminalVerifyOfferText)
                || now < unavailableNavigationUntil || now < pageRecoveryRetryAt) return false;
        // Retry only after allowing the current tab transition to settle.
        pageRecoveryRetryAt = now + 300L;
        return TapAccessibilityService.clickOffersNavigationFromOtherTab(
                detail -> updateStatus("AUTO_RETURN_OFFERS：" + detail));
    }

    /** Exact RGBA comparison before allocating/copying an OCR bitmap. A changed pixel reopens OCR. */
    private boolean skipIdenticalOwnedRejectImage(Image image,int top,int bottom,long now) {
        synchronized(rejectedRoiLock) {
            RejectConfirmState owner=rejectedRoiOwner;
            boolean owned=owner!=null && rejectConfirmStates.get(owner.id)==owner
                    && rejectTerminalGate.isCurrent(owner.id,owner.token);
            if(!RejectWorkPolicy.mayReusePixels(owned,now-rejectedRoiAt)
                    || rejectedRoiPixels==null || image.getWidth()!=rejectedRoiWidth
                    || bottom-top!=rejectedRoiHeight) return false;
            try {
                Image.Plane p=image.getPlanes()[0];ByteBuffer bytes=p.getBuffer().duplicate().order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int row=p.getRowStride(),pixel=p.getPixelStride(),w=image.getWidth();
                if(pixel!=4 || top<0 || bottom>image.getHeight()
                        || (long)(bottom-1)*row+(long)(w-1)*pixel+3>=bytes.limit()) return false;
                for(int y=0;y<bottom-top;y++) for(int x=0;x<w;x++) {
                    int i=(top+y)*row+x*4;
                    if(bytes.getInt(i)!=rejectedRoiPixels[y*w+x]) return false;
                }
                return true;
            } catch(RuntimeException stale) {return false;}
        }
    }

    private VisualAcceptDetection wakeIndexFromScreen(Image image, long now) {
        if (!monitorReady || serialTopAction != SerialAction.NONE
                || now < cooldownUntil || now < accessibilityActionHoldUntil
                || !TapAccessibilityService.hasDeliverThatReplayForegroundHint()) {
            screenAcceptVisible = false;
            return null;
        }
        // Use the existing hot visual cadence rather than skipping 12–16ms frames.
        if (now - lastScreenOfferProbeAt < 12L) return null;
        lastScreenOfferProbeAt = now;
        int cropTop = topCropTop();
        VisualAcceptDetection detection = findCompleteVisualAcceptInImage(
                image, cropTop, topCropBottom(), false);
        boolean visible = false;
        if (detection != null) {
            Rect button = new Rect(detection.bounds);
            button.offset(0, cropTop);
            visible = acceptSpinnerMask(image, button) == 0;
        }
        // The current screen can queue a read, even while OCR is processing an older frame.
        // Only the normal decision pipeline can authorize a tap.
        if (visible && (!screenAcceptVisible || !fastCheckQueued.get())) {
            if (!screenAcceptVisible) acceptReplay.markDiscovery(now, "SCREEN_ACCEPT_EDGE_HINT visualOnly=true");
            requestImmediateFastCheck(SystemClock.uptimeMillis(), true);
        }
        screenAcceptVisible = visible;
        return detection;
    }

    private void sampleOfferReplayFrame(Image image, long capturedAt, String screenProbe, long callbackAt) {
        if (monitorReady && TapAccessibilityService.hasDeliverThatReplayForegroundHint())
            acceptReplay.sample(image,capturedAt,screenProbe,callbackAt);
        else acceptReplay.clearPreRoll();
    }

    private void onFrame(ImageReader imageReader) {
        long frameCallbackAt = SystemClock.elapsedRealtime();
        if (imageReader!=reader) return;
        Image image;
        try { image=imageReader.acquireLatestImage(); }
        catch (IllegalStateException closed) { return; }
        if (image==null) return;
        if (imageReader!=reader) { image.close(); return; }
        long now = SystemClock.elapsedRealtime();
        if (isManualInterventionPaused()) {
            try {
                if (MANUAL_INTERVENTION_PAUSED.get()) acceptReplay.clearPreRoll();
            } finally { image.close(); }
            return;
        }
        int interval = configuredScanIntervalMs();
        observeAcceptSpinner(image,now);
        observeRejectSpinner(image,now);
        final long spinnerReadAt = SystemClock.elapsedRealtime();
        final long screenProbeBefore = lastScreenOfferProbeAt;
        final VisualAcceptDetection screenAccept = wakeIndexFromScreen(image, now);
        final String replayScreenProbe = lastScreenOfferProbeAt == screenProbeBefore ? "UNPROBED"
                : screenAcceptVisible ? "CTA_CANDIDATE" : "NO_CTA_CANDIDATE";
        // The current CTA frame belongs in pre-roll by capture time. The same screen worker
        // copies the pre-roll after this callback, so a first gesture can go out before this copy.
        final boolean replayAfterVisual = screenAccept != null && screenAcceptVisible;
        final long replayStartedAt=SystemClock.elapsedRealtime();
        final long replayReadyAt;
        final long frameStarted=now;
        final long frameGeneration, frameUiGeneration, terminalEpoch, visualRetryActionAt;
        final long foregroundCheckStartedAt, foregroundCheckFinishedAt, directVisualStartedAt;
        final long directVisualFinishedAt, copyStartedAt, copyFinishedAt;
        final boolean terminalHeaderProbe, terminalProbe, visualRetryProbe, runOcrAfterVisual, directFirstProbe;
        final Bitmap roi;
        VisualAcceptDetection reusableDirectDetection = null;
        boolean hotVisualProbe;
        try {
            if (!replayAfterVisual) sampleOfferReplayFrame(image,now,replayScreenProbe,frameCallbackAt);
            replayReadyAt=SystemClock.elapsedRealtime();
            // Frame callbacks can arrive at display refresh rate. Normally cooldown/action-hold
            // suppress OCR, but v2.10.13 permits a sparse rescue probe while a transaction is
            // blocking. Without this, an old serial lock plus an unreadable Accessibility top row
            // could suppress every new frame and leave a visible offer untouched indefinitely.
            boolean actionBlocked = now < cooldownUntil || now < accessibilityActionHoldUntil;
            long actionAge = serialTopActionAt <= 0 ? Long.MAX_VALUE : Math.max(0L, now - serialTopActionAt);
            boolean rescueProbe = ActionStallPolicy.shouldProbe(
                    actionBlocked, prefs.getBoolean("dryRun", false), ocrBusy.get(),
                    now - lastWatchdogProbeAt, actionAge);
            // v2.10.52: once Accept owns the transaction, its Accessibility confirmation state
            // machine is authoritative. Do not launch 200-450ms rescue OCR while the card is
            // processing/missing; that work cannot authorize a retry and can steal CPU from the
            // next offer. Long-stall recovery remains available after the bounded confirmation lane.
            if (serialTopAction == SerialAction.ACCEPT
                    && (pendingAcceptMissingSince > 0L || actionAge < 4_500L)) rescueProbe = false;
            if (!urgentTransitionIdentity.isEmpty() && now > urgentTransitionUntil) {
                urgentTransitionIdentity = "";
                urgentTransitionUntil = 0;
            }
            boolean urgentTransitionProbe = !urgentTransitionIdentity.isEmpty()
                    && now <= urgentTransitionUntil && !ocrBusy.get();
            long numericBurstAge = TapAccessibilityService.recentNumericOfferBurstAge(
                    HotOfferScanPolicy.visualProbeWindowMs());
            boolean freshFirstOffer = serialTopAction == SerialAction.NONE && !actionBlocked
                    && (numericBurstAge >= 0L || (screenAccept != null && screenAcceptVisible));
            int ocrInterval = ScanPolicy.ocrIntervalForFrame(interval, freshFirstOffer);
            lastEffectiveOcrIntervalMs = ocrInterval;
            boolean normalOcrDue = ScanPolicy.needsOcr(
                    now, lastScan, lastReadableFastScan, ocrInterval, ocrBusy.get());
            hotVisualProbe = HotOfferScanPolicy.shouldProbeVisual(numericBurstAge,
                    lastHotVisualProbeAt <= 0L ? Long.MAX_VALUE : now - lastHotVisualProbeAt,
                    ocrBusy.get(), actionBlocked);
            // Page samples already cover terminal text. Let missing/invalid samples reopen OCR;
            // blue-button visual retry retains its independent fallback below.
            PageOutcomePolicy.Tracker frameTracker=serialTopAction==SerialAction.ACCEPT
                    ?pageTracker(serialTopActionAt):null;
            boolean pageReadOwnsFrame=frameTracker!=null && frameTracker.deferVisualRead(now);
            if(pageReadOwnsFrame) {
                normalOcrDue=false;rescueProbe=false;urgentTransitionProbe=false;hotVisualProbe=false;
            }
            terminalHeaderProbe = pageReadOwnsFrame && ClaimVisualProbePolicy.headerDue(
                    terminalVisualContext(now), acceptGestureDispatchedForCurrentTransaction(),
                    spinnerObservedAt>0L, ocrBusy.get(), now, lastTerminalVisualProbeAt);
            terminalProbe = terminalHeaderProbe || (!pageReadOwnsFrame
                    && ClaimVisualProbePolicy.due(terminalVisualContext(now),
                            ocrBusy.get(), now, lastTerminalVisualProbeAt));
            visualRetryActionAt=serialTopActionAt;
            visualRetryProbe=!terminalProbe && spinnerObservedAt==0L && serialTopAction==SerialAction.ACCEPT
                    && acceptGestureCompletedAt>0L
                    && !ActionDispatchPolicy.retryInFlight(now,acceptRetryDispatchPendingAt)
                    && acceptGestureDispatchedForCurrentTransaction()
                    && acceptRetryGuard(visualRetryActionAt).isEmpty()
                    && VisualRetryPolicy.due(now-acceptGestureCompletedAt,
                            lastVisualRetryProbeAt<=0?Long.MAX_VALUE:now-lastVisualRetryProbeAt,
                            visualRetryOcrProbes,visualRetryNeeded,ocrBusy.get());
            runOcrAfterVisual = terminalProbe || normalOcrDue || rescueProbe || urgentTransitionProbe || visualRetryProbe;
            if (!monitorReady || (!terminalProbe && !rescueProbe && !urgentTransitionProbe && !visualRetryProbe
                    && (actionBlocked || (!normalOcrDue && !hotVisualProbe)))) {
                return;
            }
            if (visualRetryProbe) lastVisualRetryProbeAt=now;
            if (rescueProbe) lastWatchdogProbeAt = now;
            if (hotVisualProbe) lastHotVisualProbeAt = now;
            PageGuard.Page active = TapAccessibilityService.recentPageHint();
            // v2.10.19: do not let a stale Accessibility tab hint suppress screen capture.
            // The field miss at 10:30 showed a complete visible offer with no decision record.
            // Capture whenever DeliverThat is actually the active root; evaluate() will require
            // independent OCR/visual offer evidence before overriding a Jobs/Ignored hint.
            foregroundCheckStartedAt = SystemClock.elapsedRealtime();
            if (!TapAccessibilityService.isDeliverThatForeground()) {
                if (runOcrAfterVisual) lastScan = now;
                return;
            }
            foregroundCheckFinishedAt = SystemClock.elapsedRealtime();
            if (runOcrAfterVisual) lastScan = now;

            frameGeneration = scanGeneration.get();
            frameUiGeneration = TapAccessibilityService.currentUiGeneration();
            int cropTop = terminalProbe ? ClaimVisualProbePolicy.top() : topCropTop();
            terminalEpoch = claimEpoch.get();
            if (terminalProbe) lastTerminalVisualProbeAt = now;
            int cropBottom = terminalHeaderProbe ? ClaimVisualProbePolicy.headerBottom(height)
                    : terminalProbe ? ClaimVisualProbePolicy.bottom(height) : topCropBottom();
            directFirstProbe=!terminalProbe && !visualRetryProbe && serialTopAction==SerialAction.NONE;
            if (!terminalProbe && !visualRetryProbe
                    && (skipFreshOwnedAcceptOcr(SystemClock.elapsedRealtime())
                        || skipFreshOwnedRejectOcr(SystemClock.elapsedRealtime())
                        || skipIdenticalOwnedRejectImage(image,cropTop,cropBottom,now))) {
                return;
            }
            directVisualStartedAt = SystemClock.elapsedRealtime();
            if (directFirstProbe || !runOcrAfterVisual) {
                VisualAcceptDetection hotDetection = directFirstProbe && screenAccept != null
                        ? screenAccept : findCompleteVisualAcceptInImage(image,cropTop,cropBottom,hotVisualProbe);
                if (directFirstProbe && hotDetection!=null) {
                    Rect button=new Rect(hotDetection.bounds);
                    button.offset(0,cropTop);
                    if (hotDetection==screenAccept ? !screenAcceptVisible : acceptSpinnerMask(image,button)!=0) {
                        return;
                    }
                }
                if (directFirstProbe && hotDetection != null && !hotDetection.earlyFade
                        && hotDetection.bounds.bottom < Math.round((cropBottom-cropTop)*.94f)-4)
                    reusableDirectDetection = hotDetection;
                long visualReadyAt=SystemClock.elapsedRealtime();
                if(tryVisualAccessibilityFastLane(hotDetection==null?null:hotDetection.bounds,
                        frameStarted,visualReadyAt,frameGeneration,frameUiGeneration,!runOcrAfterVisual,
                        hotDetection!=null && hotDetection.earlyFade,
                        frameCallbackAt,replayStartedAt-spinnerReadAt,replayReadyAt-replayStartedAt,
                        foregroundCheckFinishedAt-foregroundCheckStartedAt,visualReadyAt-directVisualStartedAt,
                        hotDetection!=null && hotDetection==screenAccept) || !runOcrAfterVisual) {
                    return;
                }
            }
            directVisualFinishedAt = SystemClock.elapsedRealtime();
            // v2.10.6: copy only the first-card rows directly from the ImageReader plane.
            // v2.10.5 first allocated/copied a full 720x1600 bitmap and then cropped it, which
            // wasted memory bandwidth before ML Kit even started.
            if (!terminalProbe && !visualRetryProbe && terminalEpoch != claimEpoch.get()) {
                return;
            }
            if(!terminalProbe && !visualRetryProbe
                    && (skipFreshOwnedAcceptOcr(SystemClock.elapsedRealtime())
                        || skipFreshOwnedRejectOcr(SystemClock.elapsedRealtime()))) {
                return;
            }
            copyStartedAt = SystemClock.elapsedRealtime();
            roi = imageToTopRoiBitmap(image, cropTop, cropBottom);
            copyFinishedAt = SystemClock.elapsedRealtime();
        } finally {
            try {
                if (replayAfterVisual) sampleOfferReplayFrame(image,now,replayScreenProbe,frameCallbackAt);
            } finally { image.close(); }
        }
        if (roi == null) return;
        final long roiReadyAt = SystemClock.elapsedRealtime();
        // DeliverThat's filled blue Accept button is visually stable even when its label is
        // absent from Accessibility. Before paying the 150-300ms ML Kit cost, combine that
        // just-captured rectangle with same-generation Accessibility decision fields. This is
        // the v2.10.28 blank-label first-shot lane; all configured rules still run unchanged.
        final VisualAcceptDetection visualDetection =
                terminalProbe ? null : reusableDirectDetection != null ? reusableDirectDetection
                : findVisualAcceptButton(roi, !visualRetryProbe && hotVisualProbe);
        final boolean reusedDirectPixels = reusableDirectDetection != null;
        final Rect visualAccept = visualDetection == null ? null : visualDetection.bounds;
        if (visualRetryProbe && visualAccept==null) {
            if (fastWorker!=null) fastWorker.post(() -> {
                if (terminalEpoch==claimEpoch.get() && visualRetryActionAt==serialTopActionAt)
                    noteVisualRetrySkip(1,"当前画面未检测到实心蓝色Accept按钮；未启动重试OCR");
            });
            return;
        }
        if (!directFirstProbe && !visualRetryProbe && tryVisualAccessibilityFastLane(visualAccept, frameStarted, roiReadyAt,
                frameGeneration, frameUiGeneration, !runOcrAfterVisual,
                visualDetection != null && visualDetection.earlyFade,
                frameCallbackAt,replayStartedAt-spinnerReadAt,replayReadyAt-replayStartedAt,
                foregroundCheckFinishedAt-foregroundCheckStartedAt,-1L,false)) return;

        // The hot probe exists only to find the current visual action rectangle. If cached
        // same-generation numeric evidence was not enough, leave normal OCR scheduling intact.
        if (!runOcrAfterVisual) return;

        if (visualRetryProbe) {
            if(terminalEpoch!=claimEpoch.get() || visualRetryActionAt!=serialTopActionAt
                    || serialTopAction!=SerialAction.ACCEPT) return;
            visualRetryOcrProbes++;
        }
        if (frameGeneration != scanGeneration.get()
                || frameUiGeneration != TapAccessibilityService.currentUiGeneration()) return;
        if (!terminalProbe && !visualRetryProbe && terminalEpoch != claimEpoch.get()) return;
        if(!terminalProbe && !visualRetryProbe
                && (skipFreshOwnedAcceptOcr(SystemClock.elapsedRealtime())
                    || skipFreshOwnedRejectOcr(SystemClock.elapsedRealtime()))) {
            return; // pooled ROI: reuse on the next eligible frame
        }
        ocrBusy.set(true);
        final long ocrSubmittedAt = SystemClock.elapsedRealtime();
        final Task<Text> task;
        try {
            task = recognizer.process(InputImage.fromBitmap(roi, 0));
        } catch (RuntimeException submissionFailure) {
            ocrBusy.set(false);
            scanTrace.note(SystemClock.elapsedRealtime(), "OCR_SUBMIT_FAILED "
                    + submissionFailure.getClass().getSimpleName());
            return;
        }
        final AtomicBoolean enhancedStarted = new AtomicBoolean(false);
        task.addOnSuccessListener(result -> {
                    final long ocrCallbackAt = SystemClock.elapsedRealtime();
                    if (frameGeneration != scanGeneration.get()
                            || frameUiGeneration != TapAccessibilityService.currentUiGeneration()
                            || !ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) return;
                    RejectConfirmState owner = ownedRejectForText(result.getText());
                    if (frameGeneration == scanGeneration.get()
                            && frameUiGeneration == TapAccessibilityService.currentUiGeneration())
                        rememberOwnedRejectFrame(roi, owner, SystemClock.elapsedRealtime());
                    // A frame captured before an action cannot re-enter ordinary offer evaluation.
                    if (!terminalProbe && !visualRetryProbe
                            && (owner != null || terminalEpoch != claimEpoch.get())) return;
                    if (worker != null) worker.post(() -> {
                        if (!monitorReady || frameGeneration != scanGeneration.get()
                                || frameUiGeneration != TapAccessibilityService.currentUiGeneration()
                                || !ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) return;
                        long decidedAt = SystemClock.elapsedRealtime();
                        scanTiming = "首卡帧阶段 spinner=" + (spinnerReadAt-frameStarted)
                                + "ms screenProbe=" + (replayStartedAt-spinnerReadAt)
                                + "ms replayBeforeVisual=" + (replayReadyAt-replayStartedAt)
                                + "ms policy=" + (foregroundCheckStartedAt-replayReadyAt)
                                + "ms foreground=" + (foregroundCheckFinishedAt-foregroundCheckStartedAt)
                                + "ms frameBind=" + (directVisualStartedAt-foregroundCheckFinishedAt)
                                + "ms visualBeforeCopy=" + (directVisualFinishedAt-directVisualStartedAt)
                                + "ms copyGate=" + (copyStartedAt-directVisualFinishedAt)
                                + "ms；ROI复制" + (copyFinishedAt-copyStartedAt)
                                + "ms；close=" + (roiReadyAt-copyFinishedAt)
                                + "ms；复制后→OCR提交=" + (ocrSubmittedAt-roiReadyAt)
                                + "ms；直接视觉结果复用=" + reusedDirectPixels
                                + "；OCR提交→回调=" + (ocrCallbackAt-ocrSubmittedAt)
                                + "ms；回调→评估=" + (decidedAt-ocrCallbackAt)
                                + "ms；总" + (decidedAt-frameStarted) + "ms";
                        if (terminalProbe) {
                            if (terminalEpoch == claimEpoch.get() && terminalVisualContext(decidedAt))
                                observeTerminalVisual(result.getText(), frameStarted, frameUiGeneration, terminalHeaderProbe);
                            return; // A full detail crop must never authorize Accept/Reject.
                        }
                        if (visualRetryProbe) {
                            if (fastWorker!=null) fastWorker.post(() -> tryVisualRetry(result,visualAccept,
                                    frameStarted,frameUiGeneration,terminalEpoch,visualRetryActionAt));
                            return;
                        }
                        if (terminalEpoch != claimEpoch.get()) return;
                        evaluate(result, frameStarted, visualAccept);
                    });
                    // Borrow the useful idea from high-contrast OCR pipelines, but only as a
                    // fallback. The normal path stays raw/fast; we pay this cost only when an
                    // offer-looking frame has money+miles but the action labels were missed.
                    if (frameGeneration == scanGeneration.get()
                            && frameUiGeneration == TapAccessibilityService.currentUiGeneration()
                            && owner == null && terminalEpoch == claimEpoch.get() && !terminalProbe && !visualRetryProbe
                            && needsEnhancedOcr(result, visualAccept)
                            && ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) {
                        Bitmap enhanced = enhanceForOcr(roi);
                        if (enhanced != null) {
                            try {
                                enhancedStarted.set(true);
                                recognizer.process(InputImage.fromBitmap(enhanced, 0))
                                        .addOnSuccessListener(second -> {
                                            if (worker != null) worker.post(() -> {
                                                if (!monitorReady || frameGeneration != scanGeneration.get()
                                                        || frameUiGeneration != TapAccessibilityService.currentUiGeneration()
                                                        || !ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) return;
                                                if (terminalEpoch != claimEpoch.get()) return;
                                                scanTiming = "增强OCR帧至判断"
                                                        + (SystemClock.elapsedRealtime() - frameStarted) + "ms";
                                                evaluate(second, frameStarted, visualAccept);
                                            });
                                        })
                                        .addOnCompleteListener(done2 -> {
                                            enhanced.recycle();
                                            ocrBusy.set(false);
                                        });
                            } catch (RuntimeException startFailure) {
                                enhancedStarted.set(false);
                                enhanced.recycle();
                                scanTrace.note(SystemClock.elapsedRealtime(), "OCR_ENHANCED_SUBMIT_FAILED "
                                        + startFailure.getClass().getSimpleName());
                            }
                        }
                    }
                })
                .addOnCompleteListener(done -> {
                    // roi is a pooled reusable buffer in v2.10.9; do not recycle per frame.
                    if (!enhancedStarted.get()) ocrBusy.set(false);
                });
    }

    /**
     * v2.10.28 hybrid first shot for DeliverThat builds whose blue Accept has no accessible
     * label. Money/miles/city/time are taken only from a same-generation Accessibility card;
     * the screen contributes only the current blue action rectangle. No rule threshold is
     * inferred or changed here.
     */
    private boolean tryVisualAccessibilityFastLane(Rect visualAccept, long frameStarted,
                                                    long roiReadyAt, long frameGeneration,
                                                    long frameUiGeneration,
                                                    boolean cachedOnly,
                                                    boolean earlyFadeVisual, long frameCallbackAt,
                                                    long screenProbeMs, long replayBeforeVisualMs,
                                                    long foregroundCheckMs, long visualReadMs,
                                                    boolean reusedScreenProbe) {
        if (visualAccept == null || visualAccept.isEmpty() || !monitorReady
                || serialTopAction != SerialAction.NONE || SystemClock.elapsedRealtime() < cooldownUntil)
            return false;
        if (frameGeneration != scanGeneration.get()
                || frameUiGeneration != TapAccessibilityService.currentUiGeneration()) return false;

        int cropTop = topCropTop();
        Rect fullAccept = new Rect(visualAccept);
        fullAccept.offset(0, cropTop);
        if (!ActionGeometry.plausibleActionRect(width, height,
                fullAccept.left, fullAccept.top, fullAccept.right, fullAccept.bottom, true))
            return false;

        // v2.10.48: do not make a hot qualified offer wait for ML Kit merely because the
        // event-cached DecisionEvidence missed the exact current UI generation. The screen has
        // already proved a fresh blue Accept rectangle. Refresh decision fields synchronously,
        // in increasing-cost order: cached evidence -> semantic Accept index -> bounded quick
        // tree. Only complete, same-generation Accessibility evidence may bypass OCR.
        String evidenceText = "";
        float evidenceAmount = -1f;
        float evidenceMiles = -1f;
        String evidenceIdentity = "";
        long evidenceCapturedAt = 0L;
        String evidenceSource = "缓存证据";
        long evidenceRefreshMs = 0L;

        TapAccessibilityService.DecisionEvidence cached =
                TapAccessibilityService.recentDecisionEvidence(520L);
        if (cached != null && cached.uiGeneration == frameUiGeneration
                && universallyRejectedByNumbers(cached.amount, cached.miles)
                && !CardText.containsConflictingOfferNumbers(cached.text)) return false;
        boolean nearbyGenerationEvidence = false;
        // v2.10.117: React Native commonly emits a complete numeric event and then immediately
        // advances the UI generation with an Accept-only event. recentDecisionEvidence() rejects
        // the still-current numeric event solely because it is no longer the last generation,
        // which forced the visual lane to pay a 20-50ms quick-tree refresh. The current screen
        // frame already proves a fresh right-side blue Accept rectangle; recover only a <=160ms,
        // <=3-generation numeric event and let recentVisualNumericEvidence() enforce those hard
        // bounds. Pasadena-only offers still require their complete city proof and do not use
        // this shortcut.
        if (cached == null) {
            cached = TapAccessibilityService.recentCrossGenerationDecisionEvidence(160L);
            nearbyGenerationEvidence = cached != null;
        }
        if (cached == null) {
            cached = TapAccessibilityService.recentEventBurstDecisionEvidence(240L);
            nearbyGenerationEvidence = cached != null;
        }
        // v2.10.65 VISUAL_NUMERIC_FAST: a current screen frame already proves the filled-blue
        // Accept rectangle. If the SAME Accessibility generation also exposes amount+miles and
        // those numbers pass General, location cannot change the decision. Pasadena is additive.
        // Do not wait for merchant/address/Accept text or ML Kit in that exact case. This is
        // intentionally stricter than the normal visual lane: no city allow-list/time filter,
        // current generation only, current visual geometry, and the universal numeric gate.
        long cachedAge = cached == null ? Long.MAX_VALUE
                : Math.max(0L, SystemClock.elapsedRealtime() - cached.capturedAt);
        long generationDelta = cached == null ? Long.MAX_VALUE
                : Math.abs(cached.uiGeneration - frameUiGeneration);
        boolean sameGenUniversalVisual = cached != null
                && universallyQualifiedByNumbers(cached.amount, cached.miles)
                && HotOfferScanPolicy.recentVisualNumericEvidence(
                        cachedAge, generationDelta, true,
                        ClaimSuccessSignals.hasAcceptedJobDetail(cached.text));
        if (sameGenUniversalVisual || (cached != null && cached.uiGeneration == frameUiGeneration
                && !ClaimSuccessSignals.hasAcceptedJobDetail(cached.text)
                && quickDecisionTextComplete(cached.text, cached.amount, cached.miles))) {
            evidenceText = cached.text;
            evidenceAmount = cached.amount;
            evidenceMiles = cached.miles;
            evidenceIdentity = cached.identity;
            evidenceCapturedAt = cached.capturedAt;
            if (sameGenUniversalVisual) evidenceSource = nearbyGenerationEvidence
                    ? "近代突发数值+当前视觉Accept"
                    : "同代数值+当前视觉Accept";
        } else {
            // v2.10.127 VISUAL_EXACT_NUMERIC_FIRST: the blue CTA may be on screen while RN has
            // not exported its semantic Accept node yet. Re-prove the exact numeric pair from
            // the CURRENT live text index and spatially bind it above this CURRENT visual CTA.
            // This remains General-only and is disabled whenever city/time filtering matters.
            // A bounded recent event supplies identity only after the current index independently
            // matches both values; no cached coordinate or cached-only gesture is allowed.
            long visualExactStarted = SystemClock.elapsedRealtime();
            long cachedAgeForExact = cached == null ? Long.MAX_VALUE
                    : Math.max(0L, visualExactStarted - cached.capturedAt);
            long cachedGenerationDelta = cached == null ? Long.MAX_VALUE
                    : Math.abs(cached.uiGeneration - frameUiGeneration);
            TapAccessibilityService.FastOfferSnapshot visualExact = null;
            if (cached != null && !cityFilterEnabled() && !decisionNeedsOfferTimeEvidence()
                    && universallyQualifiedByNumbers(cached.amount, cached.miles)
                    && !ClaimSuccessSignals.hasAcceptedJobDetail(cached.text)
                    && cachedAgeForExact <= 240L && cachedGenerationDelta <= 16L) {
                visualExact = TapAccessibilityService.getIndexedNumericVisualAcceptSnapshot(
                        cached.amount, cached.miles, fullAccept);
            }
            evidenceRefreshMs += SystemClock.elapsedRealtime() - visualExactStarted;
            if (frameGeneration != scanGeneration.get()
                    || frameUiGeneration != TapAccessibilityService.currentUiGeneration()) return false;
            boolean visualExactBound = visualExact != null
                    && Math.abs(visualExact.amount - cached.amount) <= 0.011f
                    && Math.abs(visualExact.miles - cached.miles) <= 0.051f
                    && CardText.compatiblePartialActionEvidence(cached.text, visualExact.text);
            if (visualExactBound) {
                evidenceText = (cached.text + " " + visualExact.text)
                        .replaceAll("\\s+", " ").trim();
                evidenceAmount = visualExact.amount;
                evidenceMiles = visualExact.miles;
                evidenceIdentity = CardText.identity(evidenceText);
                evidenceCapturedAt = visualExact.capturedAt;
                evidenceSource = "当前精确数值+当前视觉Accept；VISUAL_EXACT_NUMERIC_FIRST";
            }

            if (visualExactBound) {
                // Evidence has already been filled by the current visual/numeric bridge.
            } else {
                // A 24ms hot visual-only probe must remain cheap. It never starts a synchronous
                // tree walk or OCR; the normal fast heartbeat/next due OCR frame owns that work.
                if (cachedOnly || fastCheckQueued.get()) return false;
                long refreshStarted = SystemClock.elapsedRealtime();
                TapAccessibilityService.FastOfferSnapshot indexed =
                        TapAccessibilityService.getIndexedTopAcceptSnapshot(
                                decisionNeedsLocationEvidence(), decisionNeedsOfferTimeEvidence());
                evidenceRefreshMs += SystemClock.elapsedRealtime() - refreshStarted;
                if (frameGeneration != scanGeneration.get()
                        || frameUiGeneration != TapAccessibilityService.currentUiGeneration()) return false;

                TapAccessibilityService.FastOfferSnapshot fresh = indexed;
                if (fresh != null && quickDecisionTextComplete(fresh)
                        && !ClaimSuccessSignals.hasAcceptedJobDetail(fresh.text)) {
                    evidenceSource = "新鲜Action索引";
                } else {
                    long quickStarted = SystemClock.elapsedRealtime();
                    TapAccessibilityService.QuickTopResult quickResult =
                            TapAccessibilityService.getQuickTopOfferSnapshotResult(45L,96);
                    evidenceRefreshMs += SystemClock.elapsedRealtime() - quickStarted;
                    if (frameGeneration != scanGeneration.get()
                            || frameUiGeneration != TapAccessibilityService.currentUiGeneration()) return false;
                    TapAccessibilityService.FastOfferSnapshot quickFresh =
                            quickResult == null ? null : quickResult.snapshot;
                    fresh = fuseComplementaryDecisionEvidence(quickFresh, indexed);
                    if (fresh == quickFresh && (fresh == null || !quickDecisionTextComplete(fresh)))
                        fresh = quickFresh;
                    if (fresh == null || !quickDecisionTextComplete(fresh)
                            || ClaimSuccessSignals.hasAcceptedJobDetail(fresh.text)) return false;
                    evidenceSource = fresh != quickFresh ? "新鲜互补融合" : "新鲜快速树";
                }
                evidenceText = fresh.text;
                evidenceAmount = fresh.amount;
                evidenceMiles = fresh.miles;
                evidenceIdentity = fresh.identity;
                evidenceCapturedAt = fresh.capturedAt;
            }
        }

        PageGuard.Page page = TapAccessibilityService.recentPageHint();
        if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) return false;
        final long visualFieldsReadyAt = SystemClock.elapsedRealtime();
        // A new live visual card is independent of previous unavailable attempts.
        String failure = sameGenUniversalVisual
                ? "" : fastRuleFailure(evidenceText, evidenceAmount, evidenceMiles);
        if (!failure.isEmpty()) return false; // Reject remains on the normal verified path.
        final long ruleReadyAt=SystemClock.elapsedRealtime();
        noteRuleReady(evidenceAmount, evidenceMiles, ruleReadyAt);
        TapAccessibilityService.noteVisualAcceptAnchor(
                evidenceAmount, evidenceMiles, frameStarted);

        String id = evidenceIdentity;
        final long now;
        final int attempt;
        final long epoch;
        final long actionEpoch;
        final String acceptedText = evidenceText;
        final float acceptedAmount = evidenceAmount;
        final float acceptedMiles = evidenceMiles;
        final long acceptedCapturedAt = evidenceCapturedAt;
        final String acceptedSource = evidenceSource
                + (earlyFadeVisual ? "；EARLY_FADE_ACCEPT" : "");
        final long acceptedRefreshMs = evidenceRefreshMs;
        final String acceptedIdentity = evidenceIdentity;
        // Atomic single-flight admission. Accessibility, quick-tree and screen-frame callbacks
        // can arrive on different threads in the same 10-30ms window. Only one may reserve the
        // first attempt and establish the transaction; all others observe ACCEPT immediately.
        if (!acceptAdmissionBusy.compareAndSet(false, true)) return false;
        try {
            now = SystemClock.elapsedRealtime();
            if (!acceptCardSafetyReason(acceptedText, now).isEmpty()) return false;
            if (serialTopAction != SerialAction.NONE || serialTopActionAt > 0L
                    || id.isEmpty()
                    || !claimBudget.available(id, now)) return false;
            claimBudget.forget(id); // Single-flight initial visual admission only.
            attempt = claimBudget.reserve(id, acceptedText, now);
            if (attempt == 0) return false;
            if (postClaimIsolationActive) releasePostClaimIsolation("视觉+Accessibility确认新卡");
            pendingAcceptJobsBaseline = TapAccessibilityService.recentJobsBadgeCount();
            pendingAcceptMissingSince = 0L;
            pendingAcceptTerminalProbeAt = 0L;
            epoch = claimEpoch.incrementAndGet();
            serialTopText = acceptedText;
            serialTopActionAt = now;
            serialTopAction = SerialAction.ACCEPT;
            armAcceptPressure(new TapAccessibilityService.FastOfferSnapshot(acceptedText,fullAccept,new Rect(),true,false),epoch);
            rejectProcessingConfirmedAt = 0;
            rejectDispatchCompletedAt = 0;
            rejectOutcomeBaselineEpoch = 0;
            acceptProcessingConfirmedAt = 0;
            lastActionDispatchAt = now;
            cooldownUntil = now + 20L;
            accessibilityActionHoldUntil = now + 20L;
            // Immediately retire raw/enhanced OCR callbacks that began before this claim.
            actionEpoch = scanGeneration.incrementAndGet();
            beginAcceptFrameSuppression(acceptedText);
        } finally {
            releaseAcceptAdmission();
        }

        scanTiming = "首卡视觉定位" + Math.max(0L, roiReadyAt - frameStarted) + "ms；视觉Accept；"
                + acceptedSource + (acceptedRefreshMs > 0 ? acceptedRefreshMs + "ms" : "")
                + "；OCR跳过";
        java.util.function.Consumer<String> report = acceptReporter(acceptedText);
        TapAccessibilityService.tapVisualAccessibilityOffer(fullAccept, acceptedAmount, acceptedMiles,
                acceptedText, frameStarted, frameUiGeneration, detail -> {
                    if (!acceptCallbackCurrent(epoch, actionEpoch, acceptedText)) {
                        noteStaleTaskDrop();
                        return;
                    }
                    noteAcceptGestureCompleted();
                    if(acceptPressureActive(serialTopActionAt)) scheduleAcceptPressure(serialTopActionAt,epoch);
                    accessibilityActionHoldUntil = 0;
                    long callbackAt = SystemClock.elapsedRealtime();
                    long actualDispatchAt = acceptDispatchObservationAt > 0L
                            ? acceptDispatchObservationAt : callbackAt;
                    long evidenceAgeAtDispatch = Math.max(0L, actualDispatchAt - acceptedCapturedAt);
                    String stageTiming = acceptStageTiming(
                            acceptedText, acceptedIdentity, actualDispatchAt);
                    report.accept("Accept预算第" + attempt + "次动作已发送；本轮实际发送="
                    +acceptAudit.sendsFor(serialTopActionAt)+"：" + detail
                            + "；证据来源=" + acceptedSource
                            + "；缓存年龄=" + evidenceAgeAtDispatch + "ms"
                            + "；画面→dispatch=" + Math.max(0L, actualDispatchAt - frameStarted) + "ms"
                            + stageTiming
                            + "；ROI=" + Math.max(0L, roiReadyAt - frameStarted) + "ms"
                            + "；FRAME_SCAN acquire=" + Math.max(0L,frameStarted-frameCallbackAt)
                            + "ms,screenProbe=" + screenProbeMs + "ms,replayBeforeVisual=" + replayBeforeVisualMs
                            + "ms,foreground=" + foregroundCheckMs + "ms,visual="
                            + (visualReadMs<0L ? "UNOBSERVED" : visualReadMs+"ms")
                            + ",screenProbeReused=" + reusedScreenProbe
                            + "；VISUAL_DECISION fields=" + (visualFieldsReadyAt-roiReadyAt)
                            + "ms,eligibilityAndRule=" + (ruleReadyAt-visualFieldsReadyAt)
                            + "ms；VISUAL_RULE_READY_ELAPSED=" + ruleReadyAt
                            + (acceptedRefreshMs > 0 ? "；证据刷新=" + acceptedRefreshMs + "ms" : "")
                            + "；OCR跳过；非接单确认");
                    if (fastWorker != null)
                        scheduleClaimInspection(acceptedText, epoch, 0, 0, 0L);
                }, reason -> {
                    if (!acceptCallbackCurrent(epoch, actionEpoch, acceptedText)) {
                        noteStaleTaskDrop();
                        return;
                    }
                    accessibilityActionHoldUntil = 0;
                    cancelUndispatchedAccept(acceptedText,
                            "Accept第" + attempt + "次未执行：视觉融合首击 " + reason);
                });
        QualifiedOfferAlert.notifyIfNeeded(this, prefs, acceptedText, acceptedAmount, acceptedMiles);
        return true;
    }

    private boolean needsEnhancedOcr(Text result, Rect visualAccept) {
        String text = result == null ? "" : result.getText().toLowerCase(Locale.US);
        boolean hasMoney = text.contains("$") || MONEY.matcher(text).find();
        boolean hasMiles = MILES.matcher(text).find();
        // v2.10.19: a visible blue Accept is itself strong offer evidence. If raw ML Kit
        // misses BOTH numeric fields, retry enhanced OCR instead of silently giving up.
        if (!hasMoney && !hasMiles) return visualAccept != null && !visualAccept.isEmpty();
        // One missing numeric field is worth a high-contrast retry.
        if (!hasMoney || !hasMiles) return true;
        // v2.9.3: do not spend another ~300-700 ms merely because one button word
        // was missed. A visual Accept anchor or either action label is enough to infer
        // the paired action row safely on a fresh frame.
        if (visualAccept != null && !visualAccept.isEmpty()) return false;
        if (findButtonBounds(result, ACCEPT_WORDS) != null) return false;
        if (findButtonBounds(result, IGNORE_WORDS) != null) return false;
        return true;
    }

    /**
     * Conservative visual fallback for DeliverThat's filled blue Accept button.
     * We intentionally look only in the lower/right part of the Offers ROI and require
     * a wide, short, dense cyan/blue rectangle. This avoids the selected Offers tab and
     * small navigation/status icons. Coordinates are ROI-local, matching ML Kit boxes.
     */
    /** Screen proof is transaction-bound and never reuses the first shot's coordinates. */
    private void tryVisualRetry(Text result,Rect visual,long frameAt,long generation,long epoch,long actionAt) {
        long now=SystemClock.elapsedRealtime();
        if(result==null || visual==null || visual.isEmpty() || !monitorReady
                || epoch!=claimEpoch.get() || serialTopAction!=SerialAction.ACCEPT
                || actionAt!=serialTopActionAt || !visualRetryNeeded
                || ActionDispatchPolicy.retryInFlight(now,acceptRetryDispatchPendingAt)
                || !VisualRetryPolicy.fresh(frameAt,now)
                || generation!=TapAccessibilityService.currentUiGeneration()
                || !acceptRetryGuard(actionAt).isEmpty()
                || !ActionDispatchPolicy.previousGestureFinished(now,acceptGestureCompletedAt)) return;
        String card=textNearButton(result,visual);
        if(!VisualRetryPolicy.card(acceptRetryDecisionText(serialTopText),card,result.getText())
                || !fastRuleFailure(card).isEmpty()) {
            noteVisualRetrySkip(2,"OCR订单身份/时间/规则或页面终态证据未通过");return;
        }
        boolean label=false;
        for(Text.TextBlock block:result.getTextBlocks()) for(Text.Line line:block.getLines())
            for(Text.Element element:line.getElements()) {
                Rect b=element.getBoundingBox();
                if(b!=null && !b.isEmpty() && VisualRetryPolicy.label(element.getText())
                        && b.left>=visual.left-2 && b.right<=visual.right+2
                        && b.top>=visual.top-2 && b.bottom<=visual.bottom+2) label=true;
            }
        if(!label) {noteVisualRetrySkip(4,"蓝色按钮内未读到精确Accept/Claim文字");return;}
        Rect full=new Rect(visual);full.offset(0,topCropTop());
        if(!ActionGeometry.plausibleActionRect(width,height,full.left,full.top,full.right,full.bottom,true)) return;
        if(!visualRetryProof.observe(card,frameAt,full.left,full.top,full.right,full.bottom)) {
            noteVisualRetrySkip(8,"已取得当前订单及按钮证据；等待第二帧一致复核");return;
        }
        if(!acceptAdmissionBusy.compareAndSet(false,true)) return;
        try {
            if(epoch!=claimEpoch.get() || serialTopAction!=SerialAction.ACCEPT
                    || actionAt!=serialTopActionAt || !acceptRetryGuard(actionAt).isEmpty()
                    || !claimBudget.available(CardText.identity(card),SystemClock.elapsedRealtime())) return;
            TapAccessibilityService.FastOfferSnapshot current=new TapAccessibilityService.FastOfferSnapshot(
                    card,full,new Rect(),true,false,frameAt);
            dispatchClaim(current,epoch,frameAt,generation);
            visualRetryProof=new VisualRetryPolicy.Proof();
        } finally {releaseAcceptAdmission();}
    }

    /** At most one entry per reason per Accept transaction; no frame-by-frame log flood. */
    private void noteVisualRetrySkip(int reason,String detail) {
        if(serialTopAction!=SerialAction.ACCEPT || (visualRetryDiagnosticMask&reason)!=0) return;
        visualRetryDiagnosticMask|=reason;
        offerReporter(serialTopText).accept("VISUAL_RETRY_PROBE："+detail+"；未发送点击");
    }

    private static final class VisualAcceptDetection {
        final Rect bounds;
        final boolean earlyFade;

        VisualAcceptDetection(Rect bounds, boolean earlyFade) {
            this.bounds = new Rect(bounds);
            this.earlyFade = earlyFade;
        }
    }

    private interface VisualPixels { int color(int x,int y); }

    private VisualAcceptDetection findVisualAcceptButton(Bitmap source, boolean allowEarlyFade) {
        if (source==null) return null;
        final int w=source.getWidth(),h=source.getHeight();
        if(w<240 || h<400) return null;
        final int left=Math.round(w*.51f),top=Math.round(h*.55f),bottom=Math.round(h*.94f);
        final int stride=w-left,needed=stride*Math.max(1,bottom-top);
        try {
            if(visualScanPixels==null || visualScanPixels.length<needed) visualScanPixels=new int[needed];
            source.getPixels(visualScanPixels,0,stride,left,top,stride,bottom-top);
            return detectVisualAccept(w,h,allowEarlyFade,(x,y)->visualScanPixels[(y-top)*stride+x-left]);
        } catch(RuntimeException | OutOfMemoryError failure) { return null; }
    }

    /** Extend only a CTA cut by the normal ROI; never substitute a different lower row. */
    private VisualAcceptDetection findCompleteVisualAcceptInImage(Image image,int top,int bottom,boolean early) {
        VisualAcceptDetection first=findVisualAcceptInImage(image,top,bottom,early);
        if(first==null || first.bounds.bottom<Math.round((bottom-top)*.94f)-4) return first;
        int extended=Math.min(image.getHeight(),bottom+Math.round(image.getHeight()*.08f));
        if(extended<=bottom) return null;
        VisualAcceptDetection full=findVisualAcceptInImage(image,top,extended,early);
        if(full==null || Math.abs(full.bounds.top-first.bounds.top)>6
                || Math.abs(full.bounds.left-first.bounds.left)>16
                || Math.abs(full.bounds.right-first.bounds.right)>16
                || full.bounds.bottom>=Math.round((extended-top)*.94f)-4) return null;
        return full;
    }

    /** Hot visual-only frames read sampled CTA pixels in place; no Bitmap/Canvas copy. */
    private VisualAcceptDetection findVisualAcceptInImage(Image image,int cropTop,int cropBottom,boolean early) {
        if(image==null || image.getWidth()!=width || width<240 || cropBottom-cropTop<400) return null;
        try {
            Image.Plane plane=image.getPlanes()[0];
            final ByteBuffer buffer=plane.getBuffer().duplicate();
            final int pixel=plane.getPixelStride(),row=plane.getRowStride();
            if(pixel!=4 || row<(long)width*pixel || cropTop<0 || cropBottom>image.getHeight()
                    || (long)(cropBottom-1)*row+(long)(width-1)*pixel+3>=buffer.limit()) return null;
            return detectVisualAccept(width,cropBottom-cropTop,early,(x,y)->{
                int at=(cropTop+y)*row+x*pixel;
                return 0xff000000 | ((buffer.get(at)&255)<<16)
                        | ((buffer.get(at+1)&255)<<8) | (buffer.get(at+2)&255);
            });
        } catch(RuntimeException failure) { return null; }
    }

    private VisualAcceptDetection detectVisualAccept(int w,int h,boolean early,VisualPixels pixels) {
        VisualAcceptScan strong=new VisualAcceptScan(w,h,false);
        VisualAcceptScan fade=early?new VisualAcceptScan(w,h,true):null;
        for(int y=Math.round(h*.55f);y<Math.round(h*.94f);y+=2) {
            for(int x=Math.round(w*.51f);x<w-4;x+=2) {
                int color=pixels.color(x,y);
                strong.pixel(x,looksLikeAcceptBlue(color));
                if(fade!=null) fade.pixel(x,looksLikeEarlyAcceptBlue(color));
            }
            strong.row(y);
            if(fade!=null) fade.row(y);
        }
        Rect best=strong.finish();
        if(best!=null) return new VisualAcceptDetection(best,false);
        best=fade==null?null:fade.finish();
        return best==null?null:new VisualAcceptDetection(best,true);
    }

    private final class VisualAcceptScan {
        final int w,h;final boolean earlyFade;final int stepY=2;
        Rect current,best;int bestArea,gapRows;
        int runStart=-1,runEnd=-1,bestRunStart=-1,bestRunEnd=-1,toleratedGap;
        VisualAcceptScan(int w,int h,boolean earlyFade){this.w=w;this.h=h;this.earlyFade=earlyFade;}
        void pixel(int x,boolean blue) {
            if(blue){if(runStart<0)runStart=x;runEnd=x;toleratedGap=0;}
            else if(runStart>=0 && toleratedGap<3)toleratedGap++;
            else if(runStart>=0){saveRun();runStart=runEnd=-1;toleratedGap=0;}
        }
        void saveRun(){if(runStart>=0 && runEnd-runStart>bestRunEnd-bestRunStart){bestRunStart=runStart;bestRunEnd=runEnd;}}
        void row(int y) {
            saveRun();
            int minRun = earlyFade
                    ? Math.max(120, Math.round(w * 0.28f))
                    : Math.max(56, Math.round(w * 0.105f));
            if (bestRunStart >= 0 && bestRunEnd - bestRunStart >= minRun) {
                Rect row = new Rect(bestRunStart, y, bestRunEnd + 2, y + stepY);
                if (current == null) {
                    current = row;
                } else if (row.left <= current.right + 18 && row.right >= current.left - 18
                        && y - current.bottom <= 6) {
                    current.union(row);
                } else {
                    if (isAcceptShape(current, w, h, earlyFade)
                            && current.width() * current.height() > bestArea) {
                        best = new Rect(current);
                        bestArea = current.width() * current.height();
                    }
                    current = row;
                }
                gapRows = 0;
            } else if (current != null && ++gapRows > 3) {
                if (isAcceptShape(current, w, h, earlyFade)
                        && current.width() * current.height() > bestArea) {
                    best = new Rect(current);
                    bestArea = current.width() * current.height();
                }
                current = null;
                gapRows = 0;
            }

            runStart=runEnd=bestRunStart=bestRunEnd=-1;toleratedGap=0;
        }
        Rect finish() {
        if (current != null && isAcceptShape(current, w, h, earlyFade)
                && current.width() * current.height() > bestArea)
            best = new Rect(current);
        return best;
        }
    }

    private boolean looksLikeAcceptBlue(int color) {
        int r = (color >> 16) & 0xff, g = (color >> 8) & 0xff, b = color & 0xff;
        // DeliverThat currently uses a saturated cyan/blue filled button. Keep the gate
        // broad enough for display color profiles but narrow enough to reject gray/white UI.
        return b >= 135 && g >= 95 && r <= 125
                && b - r >= 45 && g - r >= 25;
    }

    private boolean looksLikeEarlyAcceptBlue(int color) {
        // Alpha-composited DeliverThat blue during the first fade frames.  Neutral white/gray
        // controls cannot pass both chroma deltas.  Geometry is intentionally much stricter
        // than the normal saturated-blue detector.
        return VisualAcceptFadePolicy.isEarlyBlue(color);
    }

    private boolean isAcceptShape(Rect r, int w, int h, boolean earlyFade) {
        if (r == null || r.isEmpty()) return false;
        if (earlyFade) {
            return VisualAcceptFadePolicy.isStrictRightCta(
                    r.left, r.top, r.right, r.bottom, w, h);
        }
        int minW = Math.max(60, Math.round(w * 0.10f));
        int maxW = Math.round(w * 0.43f);
        int minH = Math.max(18, Math.round(h * 0.018f));
        int maxH = Math.round(h * 0.18f);
        float aspect = r.height() == 0 ? 0f : (float) r.width() / r.height();
        return r.width() >= minW && r.width() <= maxW
                && r.height() >= minH && r.height() <= maxH
                && aspect >= 1.7f && aspect <= 8.5f
                && r.centerX() > w * 0.58f && r.centerY() > h * 0.36f;
    }

    private Bitmap enhanceForOcr(Bitmap source) {
        try {
            Bitmap out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(out);
            Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
            ColorMatrix matrix = new ColorMatrix();
            matrix.setSaturation(0f);
            float contrast = 1.55f;
            float offset = 128f * (1f - contrast);
            ColorMatrix contrastMatrix = new ColorMatrix(new float[]{
                    contrast, 0, 0, 0, offset,
                    0, contrast, 0, 0, offset,
                    0, 0, contrast, 0, offset,
                    0, 0, 0, 1, 0
            });
            matrix.postConcat(contrastMatrix);
            paint.setColorFilter(new ColorMatrixColorFilter(matrix));
            canvas.drawBitmap(source, 0, 0, paint);
            return out;
        } catch (RuntimeException | OutOfMemoryError ignored) {
            return null;
        }
    }

    private String fastRuleFailure(String cardText) {
        return fastRuleFailure(cardText, offerLowAmount(cardText), offerMiles(cardText));
    }

    private String fastRuleFailure(TapAccessibilityService.FastOfferSnapshot snapshot) {
        if (snapshot == null) return "信息不完整";
        return fastRuleFailure(snapshot.text, snapshot.amount, snapshot.miles);
    }

    private String fastRuleFailure(String cardText, float amount, float miles) {
        if (cardText == null) return "信息不完整";
        if (amount < 0 || miles < 0) return "信息不完整";
        float generalMin = prefs.getFloat("minPay", 60f);
        float generalMaxMiles = prefs.getFloat("maxMiles", 10f);
        boolean generalQualified = amount >= generalMin && miles <= generalMaxMiles;
        boolean pasadenaOffer = prefs.getBoolean("pasadenaRuleEnabled", false)
                && PasadenaRuleGuard.isPasadenaOffer(cardText);
        boolean pasadenaQualified = pasadenaOffer
                && amount >= prefs.getFloat("pasadenaMinPay", 25f)
                && miles <= prefs.getFloat("pasadenaMaxMiles", 5f);
        // v2.10.65: Pasadena is an additive exception branch. It may qualify an offer that
        // misses General, but it must never disqualify an offer that already passes General.
        if (!generalQualified && !pasadenaQualified)
            return numericFailureDetail(cardText, amount, miles, pasadenaOffer,
                    generalMin, generalMaxMiles,
                    prefs.getFloat("pasadenaMinPay", 25f),
                    prefs.getFloat("pasadenaMaxMiles", 5f));
        if (cityFilterEnabled() && !pasadenaQualified
                && !containsAllowedCity(cardText)) return "城市不符合";
        if (!offerTimeAllowed(cardText)) return "订单时间不符合";
        return "";
    }

    /** Diagnostic-only detail. Range offers always use the guaranteed/lower displayed amount. */
    private String numericFailureDetail(String cardText, float amount, float miles,
                                        boolean pasadenaOffer, float generalMin,
                                        float generalMaxMiles, float specialMin,
                                        float specialMaxMiles) {
        float min = pasadenaOffer ? specialMin : generalMin;
        float maxMiles = pasadenaOffer ? specialMaxMiles : generalMaxMiles;
        boolean payFailed = amount < min;
        boolean milesFailed = miles > maxMiles;
        String branch = pasadenaOffer ? "Pasadena组" : "普通";
        String detail;
        if (payFailed && milesFailed) {
            detail = branch + "金额低于$" + String.format(Locale.US, "%.0f", min)
                    + "且里程超过" + String.format(Locale.US, "%.1f", maxMiles) + "mi";
        } else if (payFailed) {
            detail = branch + "金额低于$" + String.format(Locale.US, "%.0f", min);
        } else {
            detail = branch + "里程超过" + String.format(Locale.US, "%.1f", maxMiles) + "mi";
        }
        if (cardText != null && MONEY_RANGE.matcher(cardText).find())
            detail += "（区间按下限$" + String.format(Locale.US, "%.2f", amount) + "判断）";
        if (pasadenaOffer && !payFailed && !milesFailed)
            detail = "普通与Pasadena金额/里程均不符合";
        return detail;
    }

    /**
     * The bounded quick tree is allowed to ACT only when it contains the fields that can
     * change the rule result. Missing address/time evidence falls through to the complete
     * Accessibility scan or OCR instead of being misread as a non-Pasadena/non-city order.
     */
    private boolean quickDecisionTextComplete(String cardText) {
        return quickDecisionTextComplete(cardText, offerLowAmount(cardText), offerMiles(cardText));
    }

    private boolean quickDecisionTextComplete(TapAccessibilityService.FastOfferSnapshot snapshot) {
        return snapshot != null && quickDecisionTextComplete(snapshot.text, snapshot.amount, snapshot.miles);
    }

    private boolean decisionNeedsLocationEvidence() {
        if (prefs.getBoolean("pasadenaRuleEnabled", false)) return true;
        return cityFilterEnabled();
    }

    private boolean decisionNeedsOfferTimeEvidence() {
        String startValue = prefs.getString("startTime", "").trim();
        String endValue = prefs.getString("endTime", "").trim();
        return !startValue.isEmpty() && !endValue.isEmpty();
    }

    private boolean quickDecisionTextComplete(String cardText, float amount, float miles) {
        if (cardText == null || cardText.isEmpty()
                || CardText.containsConflictingPickupEvidence(cardText)) return false;
        String lower = cardText.toLowerCase(Locale.US);
        if (decisionNeedsLocationEvidence()) {
            // Completeness only. Pay/mileage/city/time rule values remain exactly unchanged.
            boolean hasLocationEvidence = lower.contains(", ca")
                    || lower.contains(" california")
                    || lower.matches("(?s).*\\bca\\s+\\d{5}(?:-\\d{4})?\\b.*");
            if (!hasLocationEvidence) return false;
        }
        if (decisionNeedsOfferTimeEvidence() && !OFFER_TIME.matcher(cardText).find()) return false;
        return amount >= 0 && miles >= 0;
    }

    private boolean accessibilityOwnsDecision(TapAccessibilityService.FastOfferSnapshot snapshot,
                                               String failure) {
        if (!quickDecisionTextComplete(snapshot)) return false;
        boolean expectedActionAnchored = failure == null || failure.isEmpty()
                ? snapshot != null && !snapshot.acceptBounds.isEmpty()
                : prefs.getBoolean("autoIgnore", true)
                && snapshot != null && !snapshot.rejectBounds.isEmpty();
        return AccessibilityFallbackPolicy.accessibilityOwnsFrame(true, expectedActionAnchored);
    }

    /** Hold OCR only when Accessibility already owns a complete top-card decision. */
    private void holdAccessibilityDecision(TapAccessibilityService.FastOfferSnapshot snapshot,
                                           String failure, String source) {
        lastReadableFastScan = SystemClock.elapsedRealtime();
        String action = failure == null || failure.isEmpty() ? "Accept" : "Reject";
        boolean enabled = failure == null || failure.isEmpty()
                ? snapshot.acceptEnabled : snapshot.rejectEnabled;
        updateStatus("页面：OFFERS｜" + source + "已完整锁定第一张；" + action
                + (enabled ? "受事务/重试门控" : "已禁用/处理中")
                + "；暂不启动OCR重复识别");
    }

    private boolean tryFastAccept(TapAccessibilityService.FastOfferSnapshot snapshot) {
        final long decisionStarted = SystemClock.elapsedRealtime();
        String cardText = snapshot.text;
        java.util.function.Consumer<String> report = acceptReporter(cardText);
        if (CardText.containsConflictingPickupEvidence(cardText)) {
            report.accept("ACCEPT_CARD_CONFLICT：多个取餐商家/时间；本帧不发送Accept或Reject");
            return false;
        }
        float amount = snapshot.amount;
        float miles = snapshot.miles;
        if (amount < 0 || miles < 0) return false;
        // Historical unavailable evidence is never an admission gate for a live card.
        String failure = fastRuleFailure(snapshot);
        scanTiming = scanTiming + "；规则" + (SystemClock.elapsedRealtime() - decisionStarted) + "ms";
        if (!failure.isEmpty()) return handleFastRejection(snapshot, amount, miles, failure);
        noteRuleReady(amount, miles, SystemClock.elapsedRealtime());

        if (prefs.getBoolean("dryRun", false)) {
            cooldownUntil = SystemClock.elapsedRealtime() + 5_000;
            report.accept(String.format(Locale.US,
                    "快速通道测试通过：$%.2f / %.1f mi；未点击", amount, miles));
            playAlert();
            return true;
        }
        clearPendingIgnore();
        return dispatchClaim(snapshot);
    }

    /**
     * After any confirmed claim (software or manual), quarantine only the old job/detail UI.
     * Monitoring remains alive. A fresh Accessibility decision card or OCR-proven offer releases
     * this state immediately; there is deliberately no fixed sleep/cooldown between jobs.
     */
    private void enterPostClaimIsolation(String reason, int jobsBadge) {
        String old = serialTopText;
        if (serialTopAction == SerialAction.REJECT && old != null && !old.isEmpty())
            rejectSequence.forgetIfNoDispatchOwnership(
                    CardText.identity(old), SystemClock.elapsedRealtime());
        claimEpoch.incrementAndGet();
        scanGeneration.incrementAndGet();
        serialTopText = "";
        serialTopActionAt = 0;
        serialTopAction = SerialAction.NONE;
        rejectProcessingConfirmedAt = 0;
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        clearPendingAccept();
        clearPendingIgnore();
        observedTopIdentity = "";
        observedTopSince = 0;
        observedTopFrames = 0;
        urgentTransitionIdentity = "";
        urgentTransitionUntil = 0;
        rejectTransitionSuppressUntil = 0;
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        postClaimIsolationActive = true;
        postClaimIsolationAt = SystemClock.elapsedRealtime();
        postClaimIsolationBadge = jobsBadge;
        postClaimNavigationEpoch.incrementAndGet();
        if (jobsBadge >= 0) observedJobsBadgeCount = jobsBadge;
        TapAccessibilityService.invalidateDecisionEvidenceAfterClaim();
        updateStatus("接单成功隔离旧Job页面；继续监控下一张"
                + (reason == null || reason.isEmpty() ? "" : "｜" + reason));
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    private void releasePostClaimIsolation(String source) {
        if (!postClaimIsolationActive) return;
        postClaimIsolationActive = false;
        postClaimIsolationAt = 0;
        postClaimIsolationBadge = -1;
        postClaimNavigationEpoch.incrementAndGet();
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        updateStatus("接单成功隔离已解除；连续监控恢复"
                + (source == null || source.isEmpty() ? "" : "｜" + source));
    }

    /** Returns true while the old accepted-job surface still owns the screen. */
    private boolean handlePostClaimIsolationFast(long now) {
        if (!postClaimIsolationActive) return false;

        TapAccessibilityService.DecisionEvidence evidence =
                TapAccessibilityService.recentDecisionEvidence(520L);
        if (evidence != null && quickDecisionTextComplete(
                evidence.text, evidence.amount, evidence.miles)) {
            PageGuard.Page page = TapAccessibilityService.recentPageHint();
            if (page == PageGuard.Page.OFFERS
                    || TapAccessibilityService.hasCurrentOffersSurfaceEvidence()) {
                releasePostClaimIsolation("Accessibility新卡+Offers页证据");
                return false;
            }
        }

        // Semantic Accept/Claim indexing is cheap and can release the guard without waiting OCR.
        TapAccessibilityService.FastOfferSnapshot indexed =
                TapAccessibilityService.getIndexedTopAcceptSnapshot(
                        decisionNeedsLocationEvidence(), decisionNeedsOfferTimeEvidence());
        if (indexed != null && quickDecisionTextComplete(indexed)
                && !ClaimSuccessSignals.hasAcceptedJobDetail(indexed.text)) {
            releasePostClaimIsolation("Accept索引发现新卡");
            return false;
        }

        // Do not stop capture: a blank-label new offer may only be provable by the visual/OCR
        // fallback. evaluate() will release this guard as soon as that new offer is coherent.
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        return true;
    }

    /**
     * Explicit positive text needs a new event after the actual dispatch too. Job-detail
     * surfaces may belong to an older assigned Job, so v2.10.60 requires the cached raw
     * Job/Timeline page to match the amount + miles + pickup time of this exact Accept.
     */
    private boolean isBoundPositiveClaimOutcome(String originalText, String hint, long actionAt) {
        if (!TapAccessibilityService.isPositiveClaimOutcome(hint)) return false;
        // Generic Job/Timeline UI is provisional only. It previously caused false success when
        // DeliverThat opened an old/placeholder assigned-job page after a failed Accept.
        return !ClaimSuccessSignals.isJobDetailHint(hint)
                && hint.equals(TapAccessibilityService.recentAcceptOutcomeAfter(acceptFenceFor(actionAt)));
    }

    private static boolean isJobDetailEvidence(String evidence) {
        String lower = evidence == null ? "" : evidence.toLowerCase(java.util.Locale.US);
        return ClaimSuccessSignals.isJobDetailHint(evidence)
                || lower.contains("assigned job") || lower.contains("job详情")
                || lower.contains("delivery timeline") || lower.contains("已接单job");
    }

    /**
     * Hold generic Job/detail UI as a candidate only. It may be committed by an independent
     * Jobs badge rise or explicit server-positive text. Otherwise it becomes UNKNOWN and never
     * triggers success notification/navigation.
     */
    private boolean holdJobDetailCandidate(String originalText, String evidence) {
        if (!isJobDetailEvidence(evidence)) return false;
        if (serialTopAction != SerialAction.ACCEPT || serialTopActionAt <= 0L
                || !((CardText.sameOffer(serialTopText, originalText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, originalText))) || verifiedAcceptRetryMatches(originalText))) return true;

        String terminal = acceptScopedTerminalOutcomeSince(
                serialTopActionAt);
        if (!terminal.isEmpty()) {
            finishPendingClaimLoss(originalText, "服务器返回" + terminal, true);
            return true;
        }
        if (TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) return false;

        long now = SystemClock.elapsedRealtime();
        String identity = CardText.identity(originalText);
        if (!identity.equals(pendingJobDetailCandidateIdentity)) {
            pendingJobDetailCandidateIdentity = identity;
            pendingJobDetailCandidateAt = now;
            offerReporter(originalText).accept("ACCEPT_SUCCESS_CANDIDATE：检测到Job/Delivery Timeline，"
                    + "仅作为候选；等待Jobs新增或服务器明确成功，暂不返回Offers");
        }
        long age = Math.max(0L, now - pendingJobDetailCandidateAt);
        if (age >= JOB_DETAIL_CANDIDATE_WINDOW_MS) {
            finishPendingClaimLoss(originalText,
                    "Job/Delivery Timeline未获得Jobs新增或服务器成功确认；不误报接单成功", false);
            return true;
        }
        if (fastWorker != null) {
            long wait = Math.max(120L, JOB_DETAIL_CANDIDATE_WINDOW_MS - age);
            long epoch = claimEpoch.get();
            scheduleClaimInspection(originalText, epoch, 0, 0, wait);
        }
        return true;
    }

    /**
     * v2.10.298: Accept > Reject > background confirmation. A CURRENT enabled top
     * Accept and qualified numeric/city evidence can retire an earlier REJECT even if
     * its Android callback has not returned. Do not interrupt an in-flight Accept.
     *
     * A fresh event triggers one bounded indexed read, not a full-tree fallback;
     * ordinary 12ms heartbeats keep their original cost. The current top's action
     * rectangle is read before clearing the reject transaction (no blind tap).
     */
    private boolean preemptRejectForQualifiedTop(long now, boolean structural,
                                                 boolean priorityOffer) {
        if (serialTopAction != SerialAction.REJECT || serialTopActionAt <= 0L
                || serialTopText.isEmpty() || !monitorReady
                || isManualInterventionPaused() || postClaimIsolationActive) return false;
        // This check runs on every 12ms heartbeat during a Reject. Do not invoke
        // isDeliverThatForeground(): it calls getRootInActiveWindow() synchronously.
        // The indexed CURRENT top Accept read below verifies the live app/window;
        // the actual gesture path independently verifies the foreground again.

        TapAccessibilityService.DecisionEvidence event =
                TapAccessibilityService.recentEventBurstDecisionEvidence(400L);
        // A qualifying numeric-change event may precede the merchant/address fragment.
        // Probe its CURRENT top immediately; never retire the old Reject using event
        // fragments alone. Different coherent tops retain the original fast path.
        boolean qualifiedNewEvent = event != null
                && event.capturedAt >= serialTopActionAt
                && (universallyQualifiedByNumbers(event.amount, event.miles)
                        || pasadenaNumericCandidate(event))
                && (AcceptPreemptionPolicy.isDifferentCoherentTop(serialTopText, event.text)
                        || AcceptPreemptionPolicy.distinctQualifiedNumericWake(serialTopText, event.text));
        boolean currentOfferWake = (structural || priorityOffer)
                && foregroundOfferDemandRecent(220L);
        if (!qualifiedNewEvent && !currentOfferWake) return false;
        // A new eligible event outranks both the old Reject and the 36ms throttle.
        // Coalesce retries of the SAME event so stalled Binder jobs do not flood
        // the hot index workers on each 12ms heartbeat. A genuinely newer event
        // is admitted immediately, including when priorityOffer is already false.
        long eventAt = qualifiedNewEvent ? event.capturedAt : 0L;
        if (!AcceptPreemptionPolicy.shouldProbeNow(qualifiedNewEvent, eventAt,
                lastQualifiedRejectProbeEventAt, now, lastRejectPriorityProbeAt)) return false;
        lastRejectPriorityProbeAt = now;
        if (qualifiedNewEvent) lastQualifiedRejectProbeEventAt = eventAt;

        TapAccessibilityService.FastOfferSnapshot current =
                TapAccessibilityService.getIndexedGeneralOrPasadenaCurrentTopAcceptSnapshot(
                        prefs.getFloat("minPay", 60f), prefs.getFloat("maxMiles", 10f),
                        prefs.getBoolean("pasadenaRuleEnabled", false),
                        !cityFilterEnabled() && !decisionNeedsOfferTimeEvidence(),
                        decisionNeedsOfferTimeEvidence());
        if (current == null || current.acceptBounds.isEmpty() || !current.acceptEnabled
                || !AcceptPreemptionPolicy.isDifferentCoherentTop(serialTopText, current.text, true))
            return false;
        boolean universal = universallyQualifiedByNumbers(current.amount, current.miles);
        boolean qualified = universal || (quickDecisionTextComplete(current)
                && fastRuleFailure(current).isEmpty());
        if (!qualified) return false;

        // This is an actual DIFFERENT eligible top, not the re-posted old Reject.
        // Retire first: stale Reject callbacks are fenced by claimEpoch and cannot
        // finish/erase the new Accept transaction. No permanent offer tombstone.
        String previous = serialTopText;
        retireStaleSerialLock(current.text, "QUALIFIED_ACCEPT_PREEMPT_REJECT", null);
        if (serialTopAction != SerialAction.NONE) return false;
        scanTiming = "QUALIFIED_ACCEPT_PREEMPT_REJECT；旧Reject="
                + CardText.identity(previous) + "；当前第一张直接Accept";
        boolean sent = universal ? dispatchUniversalNumericAccept(current)
                : tryFastAccept(current);
        QualifiedOfferAlert.notifyIfNeeded(this, prefs,
                current.text, current.amount, current.miles);
        if (!sent) {
            // Never re-enter the retired Reject branch. Retry the qualified current
            // card immediately if a transient admission race prevented dispatch.
            requestImmediateFastCheck(SystemClock.uptimeMillis(), true);
        }
        return true;
    }

    /**
     * Own the fast lane while a first-card transaction is unresolved.
     * Returns true when normal offer discovery must stop for this runnable.
     */
    private boolean handlePendingSerialFast(long now) {
        if (serialTopText.isEmpty() || serialTopActionAt <= 0 || serialTopAction == SerialAction.NONE)
            return false;

        final long epoch = claimEpoch.get();
        final long age = Math.max(0L, now - serialTopActionAt);
        if (serialTopAction == SerialAction.ACCEPT) {
            if (!acceptGestureDispatchedForCurrentTransaction()) {
                if (age >= 1_800L)
                    cancelUndispatchedAccept(serialTopText,
                            "Android未接受Gesture dispatch；已取消本次事务，不进入终态追踪");
                return true;
            }
            if (!acceptGestureCompletedForCurrentTransaction()
                    && now - acceptDispatchObservationAt >= 1_800L
                    && acceptCallbackDelayReportedForActionAt != serialTopActionAt) {
                acceptCallbackDelayReportedForActionAt = serialTopActionAt;
                offerReporter(serialTopText).accept(
                        "ACCEPT_GESTURE_CALLBACK_DELAYED：Android已接受Gesture dispatch，"
                                + "但完成回调延迟/缺失；保持同一事务并继续观察服务器终态；不重置次数、不重复点击");
            }
            String cached = acceptScopedOutcomeSince(serialTopActionAt);
            String terminal = acceptScopedTerminalOutcomeSince(
                    serialTopActionAt);
            if (!terminal.isEmpty()) {
                finishPendingClaimLoss(serialTopText, "服务器返回" + terminal, true);
                return true;
            }
            if (TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
                confirmPendingClaimSuccess(serialTopText, "Jobs徽标已增加");
                return true;
            }
            if (TapAccessibilityService.recentAcceptedJobDetailMatches(serialTopText, serialTopActionAt)) {
                holdJobDetailCandidate(serialTopText,
                        "Assigned Job ID/Delivery Timeline（仅候选，已绑定当前Accept）");
                return true;
            }
            if (isBoundPositiveClaimOutcome(serialTopText, cached, serialTopActionAt)) {
                confirmPendingClaimSuccess(serialTopText, cached);
                return true;
            }
            PageOutcomePolicy.Tracker tracker = pageTracker(serialTopActionAt);
            if (tracker != null && !preserveVisibleAcceptLoading(serialTopActionAt,tracker,now)
                    && tracker.hasFreshDifferentTop(now)
                    && !ActionDispatchPolicy.retryInFlight(now, acceptRetryDispatchPendingAt)
                    && (tracker.hasFreshCleanReplacement(now) || !tracker.departureOutcomePending(now))) {
                finishPendingClaimLoss(serialTopText, "连续两次核对当前可见订单均无原单；原单终态转后台", false);
                return true; // Release invalidates this scan generation; restart immediately.
            }
            // A terminal server answer owns the transaction too. Do not let an already-running
            // Accessibility scan fall through and prepare an independent Accept attempt.
            if (TapAccessibilityService.isTerminalNegativeClaimOutcome(cached)) {
                // The dispatch callback already owns the short confirmation loop. Do not start
                // another tree walk from every Accessibility event; keep only the long-stop probe.
                if (age >= 1800L) inspectClaim(serialTopText, epoch);
                return true;
            }
            if (age >= 1800L) inspectClaim(serialTopText, epoch);
            return true;
        }

        // Reject has completely separate semantics. Jobs/detail evidence is intentionally
        // ignored. "offer unavailable" after a Reject only closes the Reject transaction.
        if (serialTopAction == SerialAction.REJECT) {
            // Wait until Android confirms the action callback, then accept only an outcome
            // Accessibility event newer than this Reject's captured baseline. Tree scans may
            // repeatedly rediscover a stale toast and are intentionally excluded here.
            if (rejectDispatchCompletedAt <= 0L) {
                if (age >= 3_200L) {
                    String pendingText = serialTopText;
                    long pendingAt = serialTopActionAt;
                    long baseline = rejectOutcomeBaselineEpoch;
                    startAsyncRejectConfirmation(pendingText, baseline, pendingAt);
                    offerReporter(pendingText).accept("REJECT_CALLBACK_TIMEOUT：等待动作回调超过3.2秒；"
                            + "已释放前台锁并转当前卡后台复核，未判定Reject成功");
                }
                return true;
            }
            String cached = TapAccessibilityService.recentEventClaimOutcomeAfter(
                    rejectOutcomeBaselineEpoch, serialTopActionAt);
            boolean processingAck = rejectProcessingConfirmedAt > 0
                    || rejectSequence.observe(CardText.identity(serialTopText), now)
                    == RejectSequence.State.PROCESSING;
            if (TapAccessibilityService.isTerminalNegativeClaimOutcome(cached)) {
                finishRejectTransaction(serialTopText, processingAck, true,
                        processingAck
                                ? "服务器返回" + cached + "，且此前Reject已禁用/处理中"
                                : "服务器返回" + cached + "，但未捕获Reject处理中证据");
                return true;
            }
            // Normal short confirmation is already scheduled by the Reject completion callback.
            // Only a long-held transaction gets an extra watchdog probe here.
            if (age >= 3200L) inspectReject(serialTopText, epoch, 0);
            return true;
        }
        return false;
    }

    /** All first-shot lanes share this cache-only card/Reject admission fence. */
    private String acceptCardSafetyReason(String text, long now) {
        if(TapAccessibilityService.currentNegativeSurfaceBlocksAccept()) return "ACCEPT_CURRENT_NEGATIVE_SURFACE";
        if (CardText.containsConflictingPickupEvidence(text)
                || CardText.containsConflictingOfferNumbers(text)) return "ACCEPT_CARD_CONFLICT";
        if (rejectSequence.blocksAccept(CardText.identity(text), now)) return "ACCEPT_REJECT_OWNED";
        for (RejectConfirmState state : rejectConfirmStates.values()) {
            if (rejectTerminalGate.isCurrent(state.id, state.token)
                    && RejectDemandPolicy.sameOrUnprovenOwned(state.text, text))
                return "ACCEPT_REJECT_OWNED";
        }
        return "";
    }

    private boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot) {
        // Initial claims are single-flight. Bounded retries enter the epoch overload directly
        // from inspectClaim after the current button has been freshly re-proved enabled.
        if (!acceptAdmissionBusy.compareAndSet(false, true)) return false;
        try {
            if (serialTopAction != SerialAction.NONE || serialTopActionAt > 0L) return false;
            // No stale-order tombstone/quiet window: begin a fresh transaction immediately.
            pendingAcceptJobsBaseline = TapAccessibilityService.recentJobsBadgeCount();
            pendingJobDetailCandidateIdentity = "";
            pendingJobDetailCandidateAt = 0L;
            pendingAcceptMissingSince = 0L;
            pendingAcceptTerminalProbeAt = 0L;
            return dispatchClaim(snapshot, claimEpoch.incrementAndGet());
        } finally {
            releaseAcceptAdmission();
        }
    }

    private boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot, long epoch) {
        return dispatchClaim(snapshot,epoch,0L,0L);
    }

    private boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot,long epoch,
                                  long visualFrameAt,long visualGeneration) {
        return dispatchClaim(snapshot,epoch,visualFrameAt,visualGeneration,false);
    }
    private boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot,long epoch,
                                  long visualFrameAt,long visualGeneration,boolean pressure) {
        if(ActionDispatchPolicy.retryInFlight(SystemClock.elapsedRealtime(),acceptRetryDispatchPendingAt)) return false;
        if (epoch != claimEpoch.get()) return false;
        if (!monitorReady || prefs.getBoolean("dryRun", false)) { cooldownUntil = 0; return false; }
        String id = snapshot.identity;
        long reserveNow = SystemClock.elapsedRealtime();
        String safetyReason = acceptCardSafetyReason(snapshot.text, reserveNow);
        if (!safetyReason.isEmpty()) {
            offerReporter(snapshot.text).accept(safetyReason + ("ACCEPT_CURRENT_NEGATIVE_SURFACE".equals(safetyReason)
                    ? "：当前页面仍有失效提示；未发送Accept"
                    : "：卡片身份冲突或同单Reject尚未结束；未发送Accept"));
            return false;
        }
        boolean retryTransaction = serialTopAction == SerialAction.ACCEPT
                && serialTopActionAt > 0L && !serialTopText.isEmpty()
                && ((CardText.sameOffer(serialTopText, snapshot.text) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, snapshot.text))) || verifiedAcceptRetryMatches(snapshot.text));
        if(serialTopAction==SerialAction.ACCEPT && serialTopActionAt>0 && !retryTransaction) return false;
        if (retryTransaction && !acceptLoadingRetryBlock(serialTopActionAt).isEmpty()) return false;
        // Reject stopped transactions BEFORE reserving another numbered attempt.
        if(retryTransaction && !acceptRetryGuard(serialTopActionAt).isEmpty()) {
            finishAcceptPressure(serialTopActionAt);
            scheduleAcceptPageProbe(serialTopActionAt);
            return false;
        }
        // v2.10.296: an old visual frame timestamp is not a reason to cancel a
        // previously admitted SAME-TRANSACTION retry. Foreground and terminal
        // guards still run at the actual gesture dispatch, not via frame TTL.
        if (visualFrameAt>0 && (!retryTransaction
                || !acceptRetryGuard(serialTopActionAt).isEmpty())) return false;
        // Only the current page, active transaction and live button bounds gate this tap.
        if (snapshot.acceptBounds.isEmpty() || !ActionGeometry.plausibleActionRect(
                width, height, snapshot.acceptBounds.left, snapshot.acceptBounds.top,
                snapshot.acceptBounds.right, snapshot.acceptBounds.bottom, true)) {
            acceptReporter(snapshot.text).accept("Accept热区几何异常（疑似整卡/容器）；已禁止点击并交给OCR重新定位");
            cooldownUntil = 0;
            lastReadableFastScan = 0;
            return false;
        }
        if (!retryTransaction) claimBudget.forget(id); // New admitted publication, never a pressure retry.
        int attempt = claimBudget.reserve(id, snapshot.text, reserveNow);
        if (attempt == 0) return false;
        // v2.10.87: a real retry remains part of the ORIGINAL Accept transaction. Keep the
        // first dispatch time/text and its server-observation fence. Replacing them here made a
        // failed pre-dispatch retry erase attempt #1 and allowed the same card to start over as
        // another "Accept第1次".
        if (!retryTransaction) {
            serialTopText = snapshot.text;
            serialTopActionAt = SystemClock.elapsedRealtime();
            serialTopAction = SerialAction.ACCEPT;
            armAcceptPressure(snapshot,epoch);
        }
        final long actionEpoch = scanGeneration.incrementAndGet();
        if (!retryTransaction) {
            beginAcceptFrameSuppression(snapshot.text);
            rejectProcessingConfirmedAt = 0;
            rejectDispatchCompletedAt = 0;
            rejectOutcomeBaselineEpoch = 0;
            acceptProcessingConfirmedAt = 0;
            lastActionDispatchAt = serialTopActionAt;
        }
        float amount = snapshot.amount, miles = snapshot.miles;
        final int dispatchesBefore=acceptAudit.sendsFor(serialTopActionAt);
        java.util.function.Consumer<String> report = acceptReporter(snapshot.text);
        // Short transaction window only; a different card is not suppressed for 15 seconds.
        cooldownUntil = SystemClock.elapsedRealtime() + 20L;
        accessibilityActionHoldUntil = SystemClock.elapsedRealtime() + 20L;
        java.util.function.Consumer<String> sent = detail -> {
            if (!acceptCallbackCurrent(epoch, actionEpoch, snapshot.text)) {
                noteStaleTaskDrop();
                return;
            }
            noteAcceptGestureCompleted();
            acceptRetryDispatchPendingAt=0L;
            accessibilityActionHoldUntil = 0;
            // Queue the next tap before formatting diagnostic text. This queue never reads trees.
            if(acceptPressureActive(serialTopActionAt)) scheduleAcceptPressure(serialTopActionAt,epoch);
            long callbackAt = SystemClock.elapsedRealtime();
            long actualDispatchAt = attempt >= 2 ? callbackAt : acceptDispatchObservationAt > 0L
                    ? acceptDispatchObservationAt : callbackAt;
            long pipelineMs = Math.max(0L, actualDispatchAt - snapshot.capturedAt);
            String stageTiming = attempt >= 2 ? (pressure?"；连续补击，与首击同事务，无总次数上限":"；重试回调口径，首击锚点不复用") : acceptStageTiming(
                    snapshot.text, snapshot.identity, actualDispatchAt);
            report.accept("Accept第" + attempt + "次动作已发送：" + detail
                    + (pressure?"；热区绑定→callback=":attempt >= 2 ? "；snapshot→callback=" : "；snapshot→dispatch=") + pipelineMs + "ms"
                    + stageTiming + "；非接单确认");
            if (fastWorker != null && !acceptPressureActive(serialTopActionAt))
                scheduleClaimInspection(snapshot.text, epoch, 0, 0, 0L);
        };
        java.util.function.Consumer<String> failed = reason -> {
            if (!acceptCallbackCurrent(epoch, actionEpoch, snapshot.text)) {
                noteStaleTaskDrop();
                return;
            }
            acceptRetryDispatchPendingAt=0L;
            accessibilityActionHoldUntil = 0;
            if(acceptAudit.sendsFor(serialTopActionAt)>dispatchesBefore) {
                // A cancelled gesture may have delivered a DOWN/UP already. Never refund a sent attempt.
                noteAcceptGestureCompleted();
                if(acceptPressureActive(serialTopActionAt)) scheduleAcceptPressure(serialTopActionAt,epoch);
                report.accept("ACCEPT_GESTURE_CANCELLED_AFTER_DISPATCH：保留实际发送次数；"+reason);
                if(fastWorker!=null) scheduleClaimInspection(snapshot.text,epoch,0,0,0L);
                return;
            }
            if (retryTransaction && reason.contains("RETRY_SPINNER_CANDIDATE")) {
                claimBudget.releaseUndispatchedRetry(id,attempt);
                if (!hasSpinnerCandidate(serialTopActionAt) && acceptPressureActive(serialTopActionAt))
                    scheduleAcceptPressure(serialTopActionAt,epoch);
                return;
            }
            boolean layoutRebind=pressure && reason.startsWith("PRESSURE_STOPPED:LAYOUT_CHANGED");
            boolean layoutYield=pressure && reason.startsWith("PRESSURE_STOPPED:LAYOUT_RENEWAL_YIELD");
            if(layoutRebind || layoutYield) {
                pressureSnapshot=null;pressureAdmissionWaiting.set(false);
                if(!layoutYield) scheduleEnabledProofRebind(snapshot.text,epoch,SystemClock.elapsedRealtime());
                scheduleAcceptPageProbe(serialTopActionAt);
                TapAccessibilityService.startAcceptControlWatch(serialTopText,serialTopActionAt);
            } else if(pressure || attempt==1) finishAcceptPressure(serialTopActionAt);
            if (attempt >= 2 && retryTransaction) {
                retainFirstAcceptAfterUndispatchedRetry(
                        snapshot.text, id, attempt, epoch, reason + "；预约→核验结束="
                                + (SystemClock.elapsedRealtime() - reserveNow) + "ms");
            } else {
                cancelUndispatchedAccept(
                        snapshot.text, "Accept第" + attempt + "次未执行：" + reason);
            }
        };
        // v2.10.12: first attempt goes straight to the verified 55ms Gesture. Real-device
        // evidence showed ACTION_CLICK added latency but did not move DeliverThat, while the
        // gesture reliably changed Accept into disabled/processing. Retry attempts refresh the
        // top-card action first and never spend an attempt while the button is disabled.
        acceptRetryDispatchPendingAt=SystemClock.elapsedRealtime();
        if(pressure && attempt>=2)
            TapAccessibilityService.tapPressureRetry(snapshot,serialTopActionAt,attempt,sent,failed);
        else if (visualFrameAt>0 && attempt>=2)
            TapAccessibilityService.tapVisualSnapshotRetryDetailed(snapshot,visualFrameAt,visualGeneration,
                    serialTopActionAt,attempt,sent,failed);
        else if (attempt >= 2)
            TapAccessibilityService.tapSnapshotRetryDetailed(snapshot, amount, miles, attempt, sent, failed);
        else
            TapAccessibilityService.tapSnapshotFastDetailed(snapshot, amount, miles, sent, failed);
        return true;
    }

    /**
     * A retry that failed its final live-card recheck never reached Android dispatchGesture().
     * Roll back only that retry reservation, preserve the already-dispatched first attempt and
     * re-read the same top card shortly. If it is still present/enabled, inspectClaim may reserve
     * and send the real attempt #2; terminal server evidence always wins first.
     */
    private void retainFirstAcceptAfterUndispatchedRetry(
            String originalText, String id, int attempt, long epoch, String reason) {
        if (serialTopAction != SerialAction.ACCEPT || serialTopActionAt <= 0L
                || !((CardText.sameOffer(serialTopText, originalText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, originalText))) || verifiedAcceptRetryMatches(originalText))) return;
        String retryBlock=acceptRetryGuard(serialTopActionAt);
        boolean canExpedite = reason.startsWith("RETRY_PAGE_REPROBE_REQUIRED")
                && expeditedReprobeActionAt != serialTopActionAt
                && acceptRetryGuard(serialTopActionAt).isEmpty();
        boolean released = canExpedite ? claimBudget.releaseUndispatchedRetry(id, attempt)
                : claimBudget.releaseUndispatchedRetry(id, attempt, SystemClock.elapsedRealtime());
        cooldownUntil = 0L;
        lastReadableFastScan = 0L;
        lastScan = 0L;
        boolean expedite = released && canExpedite;
        if (expedite) {
            expeditedReprobeActionAt = serialTopActionAt;
            scheduleClaimInspection(originalText, epoch, 0, 0, 0L);
        }
        acceptReporter(originalText).accept("Accept第" + attempt + "次未执行：" + reason
                + "；保留原事务及已发送次数；仅撤销本次未发送预约；同卡启用后重新核验本次重试"
                + (expedite ? "；新鲜同卡复核已优先入队" : "")
                + (released ? "" : "；重试预算已被更新，未重复回退"));
        if(!retryBlock.isEmpty()) {
            scheduleAcceptPageProbe(serialTopActionAt);
            requestImmediateFastCheck(SystemClock.uptimeMillis());
        } else if (!expedite && fastWorker != null
                && !reason.startsWith("PRESSURE_STOPPED:LAYOUT_RENEWAL_YIELD"))
            scheduleClaimInspection(originalText, epoch, 0, 0, 0L);
    }

    private void inspectClaim(String originalText, long epoch) {
        scheduleClaimInspection(originalText, epoch, 0, 0, 0L);
    }
    private volatile long acceptControlEnabledAt,acceptControlEnabledActionAt;
    private long expeditedReprobeActionAt;
    private volatile long acceptPageReadActiveAt,acceptPageReadOwner;
    private final ClaimInspectionQueue claimInspectionQueue=new ClaimInspectionQueue();
    private final AtomicLong enabledProofRebindOwner=new AtomicLong();
    private final AtomicLong enabledProofDemand=new AtomicLong();
    /** Promote an enabled-control wake even when an older due message is behind Binder work.
     * One queue ticket owns the inspection. The control is a wake hint, never click authority. */
    private boolean recordResumeBlock(long owner,String phase,String reason,
            TapAccessibilityService.FastOfferSnapshot current) {
        acceptReplay.event(SystemClock.elapsedRealtime(),"ACCEPT_RESUME_BLOCK tx="+owner
                +" phase="+phase+" reason="+reason+(current==null?"":" proofAt="+current.capturedAt
                +" readStart="+current.acceptProofStartedAt()+" controlReadAt="+current.acceptControlReadAt()
                +" lastSpinnerAt="+lastSpinnerFrameAt));
        return false;
    }

    // Called with spinnerTracker held. A tap cannot use a refresh started during visible loading.
    private String spinnerResumeBlock(TapAccessibilityService.FastOfferSnapshot current) {
        if (spinnerCandidateAt>0L) return "SPINNER_CANDIDATE";
        if (spinnerObservedAt==0L) return "";
        if (spinnerWindowEpoch!=TapAccessibilityService.outcomeWindowEpoch()) return "SPINNER_WINDOW_CHANGED";
        if (spinnerClearFrames<2) return "WAIT_CLEAR_FRAMES";
        return current.acceptControlReadAt()<=Math.max(lastSpinnerFrameAt,spinnerClearedAt)
                ? "CONTROL_READ_BEFORE_SPINNER_CLEAR" : "";
    }

    private boolean resumeAcceptPressure(long owner,long epoch,long observedAt,
            TapAccessibilityService.FastOfferSnapshot current) {
        if(owner<=0L || owner!=pressureOwner || epoch!=pressureEpoch || epoch!=claimEpoch.get()
                || serialTopAction!=SerialAction.ACCEPT || serialTopActionAt!=owner)
            return recordResumeBlock(owner,"ADMIT","OWNER_CHANGED",current);
        final String expected=acceptRetryDecisionText(serialTopText);
        String block=TapAccessibilityService.pressureResumeProofBlock(current,expected,owner);
        if(!block.isEmpty()) return recordResumeBlock(owner,"ADMIT",block,current);
        Handler clicks=acceptClickWorker;
        if(clicks==null) return recordResumeBlock(owner,"ADMIT","CLICK_WORKER_UNAVAILABLE",current);
        synchronized (spinnerTracker) {
            block=spinnerResumeBlock(current);
        }
        if(!block.isEmpty()) return recordResumeBlock(owner,"ADMIT",block,current);
        boolean posted=clicks.postAtFrontOfQueue(() -> {
            if(!monitorReady || isManualInterventionPaused() || epoch!=claimEpoch.get()
                    || owner!=serialTopActionAt || owner!=pressureOwner || serialTopAction!=SerialAction.ACCEPT) {
                recordResumeBlock(owner,"SEND","OWNER_OR_MONITOR_CHANGED",current);return;
            }
            String veto=TapAccessibilityService.pressureResumeProofBlock(current,expected,owner);
            if(!veto.isEmpty()) {
                recordResumeBlock(owner,"SEND",veto,current);
                // A re-render between proof and click is not an order outcome. Refresh on
                // the coalesced proof lane instead of stranding the transaction or using stale coordinates.
                Handler proof=acceptProofWorker;
                if (proof!=null && ("UI_GENERATION_CHANGED".equals(veto) || "PROOF_EXPIRED".equals(veto))) {
                    proof.postDelayed(() -> {
                        if (monitorReady && owner==serialTopActionAt && epoch==claimEpoch.get()
                                && canReadAcceptRecoveryProof(owner) && acceptRetryGuard(owner).isEmpty())
                            scheduleEnabledClaimInspection(serialTopText,epoch,SystemClock.elapsedRealtime());
                    },16L);
                }
                return;
            }
            PageOutcomePolicy.Tracker tracker=pageTracker(owner);
            if(tracker!=null) {
                tracker.notePressureRevalidated(current.text,current.capturedAt);
                veto=tracker.pressureBlockReason();
                if(!veto.isEmpty()) {recordResumeBlock(owner,"SEND",veto,current);return;}
            }
            boolean loadingEnded;
            synchronized (spinnerTracker) {
                veto=owner!=serialTopActionAt || epoch!=claimEpoch.get() ? "OWNER_CHANGED"
                        : spinnerResumeBlock(current);
                loadingEnded=spinnerObservedAt>0L;
                if(veto.isEmpty() && loadingEnded) {
                    spinnerObservedAt=lastSpinnerFrameAt=0L;
                    spinnerClearFrames=0;
                    spinnerFirstClearAt=spinnerClearedAt=0L;
                    spinnerTracker.reset();
                }
            }
            if(!veto.isEmpty()) {recordResumeBlock(owner,"SEND",veto,current);return;}
            veto=acceptPressureGuard(owner);
            if(!veto.isEmpty()) {recordResumeBlock(owner,"SEND",veto,current);return;}
            if(loadingEnded) acceptReplay.event(SystemClock.elapsedRealtime(),
                    "ACCEPT_SPINNER_CLEARED_SAME_CARD_ENABLED tx="+owner+" proofAt="+current.capturedAt
                            +" proofStartedAt="+current.acceptProofStartedAt()+" controlReadAt="+current.acceptControlReadAt());
            if(acceptPressureActive(owner)) {
                pressureSnapshot=current;spinnerSnapshot=current;return;
            }
            pressureSnapshot=current;spinnerSnapshot=current;
            claimBudget.enableContinuous(pressureSnapshot.identity,SystemClock.elapsedRealtime());
            long now=SystemClock.elapsedRealtime();
            acceptReplay.event(now,"PRESSURE_RESUMED tx="+owner+" enabledToQueueMs="+(now-observedAt));
            runAcceptPressure(owner,epoch,now);
            acceptReporter(serialTopText).accept("ACCEPT_PRESSURE_RESUMED：Accept恢复启用，直接续击；沿用原事务和累计次数；启用证据→续击入队="
                    +Math.max(0L,now-observedAt)+"ms");
        });
        return posted || recordResumeBlock(owner,"ADMIT","CLICK_QUEUE_STOPPED",current);
    }

    private boolean resumePressureFromPage(String text,long epoch,long observedAt) {
        long owner=serialTopActionAt;
        if(owner<=0L || serialTopAction!=SerialAction.ACCEPT || !canReadAcceptRecoveryProof(owner)) return false;
        TapAccessibilityService.FastOfferSnapshot current=
                TapAccessibilityService.takeAcceptPageRetrySnapshot(acceptRetryDecisionText(text),owner);
        return current!=null && resumeAcceptPressure(owner,epoch,current.capturedAt,current);
    }

    /** Caption enabled is a wake only. Re-prove the current owned row on the outcome lane. */
    private boolean scheduleEnabledProofRebind(String text,long epoch,long observedAt) {
        Handler proofWorker=acceptProofWorker;
        long owner=serialTopActionAt;
        if(proofWorker==null || !monitorReady || owner<=0L || owner!=pressureOwner
                || epoch!=pressureEpoch || epoch!=claimEpoch.get() || serialTopAction!=SerialAction.ACCEPT
                || !acceptRetryGuard(owner).isEmpty()) return false;
        enabledProofDemand.incrementAndGet();
        if(enabledProofRebindOwner.get()==owner) return true;
        if(!enabledProofRebindOwner.compareAndSet(0L,owner)) return false;
        final long queuedAt=SystemClock.elapsedRealtime();
        final long proofTicket=claimInspectionQueue.urgent(epoch,queuedAt);
        if(proofTicket==0L) {enabledProofRebindOwner.compareAndSet(owner,0L);return false;}
        proofWorker.postAtFrontOfQueue(() -> {
            boolean inspectFallback=false,resumeQueued=false;
            final long servedDemand=enabledProofDemand.get();
            try {
                if(!monitorReady || isManualInterventionPaused() || epoch!=claimEpoch.get()
                        || serialTopAction!=SerialAction.ACCEPT || owner!=serialTopActionAt
                        || owner!=pressureOwner || !canReadAcceptRecoveryProof(owner)
                        || !acceptRetryGuard(owner).isEmpty()) return;
                if(resumePressureFromPage(text,epoch,observedAt) || acceptPressureActive(owner)) {
                    resumeQueued=true;return;
                }
                long enteredAt=SystemClock.elapsedRealtime();
                String expected=acceptRetryDecisionText(text);
                TapAccessibilityService.FastOfferSnapshot current=
                        TapAccessibilityService.refreshCurrentOwnedAcceptNodes(expected,owner);
                boolean nodeProof=current!=null;
                boolean processing=TapAccessibilityService.ownedAcceptNodeProcessingObserved();
                String nodeDetail=TapAccessibilityService.ownedAcceptNodeRefreshDetail();
                if(!monitorReady || isManualInterventionPaused() || epoch!=claimEpoch.get()
                        || owner!=serialTopActionAt || owner!=pressureOwner
                        || serialTopAction!=SerialAction.ACCEPT || !acceptRetryGuard(owner).isEmpty()) return;
                if(current==null && !processing) {
                    // Another result reader may have completed while these live nodes were
                    // refreshing. Consume that proof, or let its in-flight read finish; never
                    // start a duplicate seven-query scan behind the same active transaction.
                    if(resumePressureFromPage(text,epoch,observedAt) || acceptPressureActive(owner)) {
                        resumeQueued=true;return;
                    }
                    long pageAt=acceptPageReadActiveAt,now=SystemClock.elapsedRealtime();
                    if(acceptPageReadOwner==owner && pageAt>0L && now>=pageAt && now-pageAt<150L) {
                        acceptReplay.event(now,"ACCEPT_RESUME_WAIT tx="+owner+" reason=PAGE_READ_IN_FLIGHT pageStartedAt="+pageAt);
                        scheduleAcceptPageProbe(owner);resumeQueued=true;return;
                    }
                    current=TapAccessibilityService.observeCurrentOwnedAcceptSnapshot(expected,owner);
                    if (current==null) {
                        acceptReplay.event(SystemClock.elapsedRealtime(),
                                "ACCEPT_RESUME_WAIT tx="+owner+" reason=NO_CURRENT_PAGE_PROOF");
                        scheduleAcceptPageProbe(owner,true);
                    }
                }
                long finishedAt=SystemClock.elapsedRealtime();
                if(!monitorReady || epoch!=claimEpoch.get() || serialTopAction!=SerialAction.ACCEPT
                        || owner!=serialTopActionAt || !acceptRetryGuard(owner).isEmpty()) return;
                boolean resumed=current!=null && current.acceptEnabled
                        && resumeAcceptPressure(owner,epoch,current.capturedAt,current);
                resumeQueued=resumed;
                inspectFallback=!resumed && !processing;
                if(processing) scheduleAcceptPageProbe(owner);
                acceptReporter(text).accept("ACCEPT_ENABLED_PROOF：wake→entry="+Math.max(0L,enteredAt-observedAt)
                        +"ms,queue="+Math.max(0L,enteredAt-queuedAt)
                        +"ms,read="+Math.max(0L,finishedAt-enteredAt)+"ms；source="+(nodeProof?"LIVE_OWNED_NODES":processing?"LIVE_CONTROL_PROCESSING":"CURRENT_PAGE_CACHE")+"；nodes="+nodeDetail+"；currentEnabled="
                        +(current!=null && current.acceptEnabled)+"；resumeQueued="+resumed
                        +"；独立结果线程核验原单，最终发送仍需当前证明");
            } catch(RuntimeException stale) {
                inspectFallback=true;
            } finally {
                claimInspectionQueue.begin(proofTicket,epoch);
                enabledProofRebindOwner.compareAndSet(owner,0L);
                if(!resumeQueued && monitorReady && epoch==claimEpoch.get() && owner==serialTopActionAt
                        && !isManualInterventionPaused() && acceptRetryGuard(owner).isEmpty()) {
                    if(enabledProofDemand.get()!=servedDemand)
                        scheduleEnabledProofRebind(text,epoch,SystemClock.elapsedRealtime());
                    else if(inspectFallback) scheduleClaimInspection(text,epoch,0,0,0L);
                }
            }
        });
        return true;
    }

    private void scheduleEnabledClaimInspection(String text,long epoch,long observedAt) {
        if (!canReadAcceptRecoveryProof(serialTopActionAt)) return;
        if(resumePressureFromPage(text,epoch,observedAt)) return;
        if(acceptPressureActive(serialTopActionAt)) return;
        if(scheduleEnabledProofRebind(text,epoch,observedAt)) return;
        Handler fast=fastWorker;
        if(fast==null || !monitorReady || epoch!=claimEpoch.get()) return;
        long owner=serialTopActionAt;
        if(owner<=0L || serialTopAction!=SerialAction.ACCEPT || !acceptRetryGuard(owner).isEmpty()) return;
        long ticket=claimInspectionQueue.urgent(epoch,SystemClock.elapsedRealtime());
        if(ticket==0L) return;
        fast.postAtFrontOfQueue(() -> {
            if(!claimInspectionQueue.begin(ticket,epoch) || !monitorReady
                    || epoch!=claimEpoch.get() || serialTopActionAt!=owner) return;
            acceptReporter(text).accept("ACCEPT_RETRY_WAKE：启用证据→核验入口="
                    +Math.max(0L,SystemClock.elapsedRealtime()-observedAt)+"ms；单次入队；仍需当前同卡校验");
            inspectClaim(text,epoch,0,0);
        });
    }

    private void scheduleClaimInspection(String text,long epoch,int disabled,int missing,long delay) {
        Handler fast=fastWorker;
        if(fast==null || !monitorReady || epoch!=claimEpoch.get()) return;
        long ticket=claimInspectionQueue.request(epoch,SystemClock.elapsedRealtime(),delay);
        if(ticket==0L) return;
        Runnable run=() -> {
            if(claimInspectionQueue.begin(ticket,epoch) && monitorReady && epoch==claimEpoch.get())
                inspectClaim(text,epoch,disabled,missing);
        };
        if(delay<=0L) fast.postAtFrontOfQueue(run); else fast.postDelayed(run,delay);
    }

    private void confirmPendingClaimSuccess(String originalText, String evidence) {
        if (originalText == null || originalText.isEmpty()) return;
        if ((evidence==null || !evidence.startsWith("OWNED_DETAIL_CONFIRMED:"))
                && holdJobDetailCandidate(originalText, evidence)) return;
        String id = CardText.identity(originalText);
        java.util.function.Consumer<String> report = offerReporter(originalText);
        pendingAcceptMissingSince = 0L;
        pendingAcceptTerminalProbeAt = 0L;
        pendingJobDetailCandidateIdentity = "";
        pendingJobDetailCandidateAt = 0L;
        // Invalidate every already-queued inspector/retry before releasing the serial lock.
        claimBudget.forget(id);
        int jobsNow = TapAccessibilityService.recentJobsBadgeCount();
        if (jobsNow < 0 && pendingAcceptJobsBaseline >= 0) jobsNow = pendingAcceptJobsBaseline + 1;
        String successTiming = acceptResultTiming(originalText, "SUCCESS_CONFIRMED", SystemClock.elapsedRealtime());
        String suppressedSummary = consumeAcceptSuppressionSummary();
        report.accept("已确认接单成功：" + (evidence == null || evidence.isEmpty()
                ? "DeliverThat明确接单成功状态" : evidence) + suppressedSummary + successTiming);
        if (MANUAL_INTERVENTION_PAUSED.get() && !manualInterventionConfirmed)
            resumeAfterManualIntervention(this, true);
        ClaimSuccessAlert.notifyConfirmed(this, originalText, evidence, serialTopActionAt);
        enterPostClaimIsolation(evidence, jobsNow);
        // Confirmed claim: leave the assigned-job detail page and resume the Offers loop.
        // Some React-Native builds publish the Offer/Offers navigation node one or two frames
        // after Begin Delivery appears, so retry only navigation discovery (never Accept/Reject).
        long navigationToken = postClaimNavigationEpoch.get();
        scheduleReturnToOffersAfterClaim(report, 0,
                SystemClock.elapsedRealtime(), navigationToken);
    }

    private boolean stopPostClaimNavigationIfNeeded(
            java.util.function.Consumer<String> report, long startedAt, long token,Runnable resume) {
        if (token != postClaimNavigationEpoch.get() || !postClaimIsolationActive) return true;
        if (!monitorReady || manualInterventionConfirmed) {
            postClaimNavigationEpoch.compareAndSet(token, token + 1L);
            return true;
        }
        TapAccessibilityService.ForegroundState foreground=TapAccessibilityService.deliverThatForegroundState();
        if(foreground==TapAccessibilityService.ForegroundState.UNKNOWN
                && SystemClock.elapsedRealtime()-startedAt<POST_CLAIM_NAVIGATION_WATCHDOG_MS) {
            if(fastWorker!=null) fastWorker.postDelayed(resume,180L);
            return true;
        }
        if (foreground==TapAccessibilityService.ForegroundState.OTHER_APP) {
            report.accept("接单成功后导航取消：DeliverThat不在前台；已停止后台点击并解除隔离");
            releasePostClaimIsolation("应用离开前台；页面守卫继续保护Jobs详情");
            return true;
        }
        long age = Math.max(0L, SystemClock.elapsedRealtime() - startedAt);
        if (age >= POST_CLAIM_NAVIGATION_WATCHDOG_MS) {
            report.accept("接单成功后导航超时：10秒内未验证Offers；已停止导航并解除隔离，继续正常扫描");
            releasePostClaimIsolation("导航验证超时；已停止重复点击");
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            return true;
        }
        return false;
    }

    private boolean completePostClaimReturnIfVisible(
            java.util.function.Consumer<String> report, long token) {
        if (token != postClaimNavigationEpoch.get() || !postClaimIsolationActive) return true;
        if (TapAccessibilityService.hasFreshBeginDeliveryOcr(null)) return false;
        PageGuard.Page hint = TapAccessibilityService.recentPageHint();
        if (hint != PageGuard.Page.OFFERS
                && !TapAccessibilityService.hasCurrentOffersSurfaceEvidence()) return false;
        report.accept("接单成功后导航：已由当前Offers页面/订单动作行确认返回；隔离解除");
        releasePostClaimIsolation("已确认Offers页面");
        requestImmediateFastCheck(SystemClock.uptimeMillis());
        return true;
    }

    private void scheduleReturnToOffersAfterClaim(java.util.function.Consumer<String> report,
                                                   int attempt, long startedAt, long token) {
        if (stopPostClaimNavigationIfNeeded(report, startedAt, token,
                () -> scheduleReturnToOffersAfterClaim(report,attempt,startedAt,token))
                || completePostClaimReturnIfVisible(report, token)) {
            return;
        }
        if (attempt >= POST_CLAIM_NAVIGATION_MAX_CLICKS) {
            if (fastWorker != null) fastWorker.postDelayed(
                    () -> scheduleReturnToOffersAfterClaim(report, attempt,
                            startedAt, token), POST_CLAIM_NAVIGATION_OBSERVE_MS);
            return;
        }
        // v2.10.59: the confirmed-job screen (Begin Delivery / Delivery Timeline) must leave
        // through its top-left Back first. Searching Offers on the detail screen can hit stale or
        // unrelated navigation semantics. Only after Back do we look for Offers.
        boolean backed = TapAccessibilityService.clickPostClaimBack(
                detail -> {
                    if (token != postClaimNavigationEpoch.get()) return;
                    report.accept("接单成功后导航：" + detail);
                    if (fastWorker != null) fastWorker.postDelayed(
                            () -> scheduleFindOffersAfterClaim(report, 0,
                                    startedAt, token), 180L);
                },
                reason -> {
                    if (token != postClaimNavigationEpoch.get()) return;
                    if (attempt >= POST_CLAIM_NAVIGATION_MAX_CLICKS) {
                        if (fastWorker != null) fastWorker.postDelayed(
                                () -> scheduleReturnToOffersAfterClaim(report, attempt,
                                        startedAt, token), POST_CLAIM_NAVIGATION_OBSERVE_MS);
                        return;
                    }
                    long[] waits = {100L, 180L, 300L, 500L};
                    if (fastWorker != null) fastWorker.postDelayed(
                            () -> scheduleReturnToOffersAfterClaim(report, attempt + 1,
                                    startedAt, token),
                            waits[Math.min(attempt, waits.length - 1)]);
                });
        if (!backed && attempt == 0)
            report.accept("接单成功：先等待左上角返回可用，再寻找Offers");
    }

    private void scheduleFindOffersAfterClaim(java.util.function.Consumer<String> report,
                                               int attempt, long startedAt, long token) {
        if (stopPostClaimNavigationIfNeeded(report, startedAt, token,
                () -> scheduleFindOffersAfterClaim(report,attempt,startedAt,token))
                || completePostClaimReturnIfVisible(report, token)) {
            return;
        }
        if (attempt >= POST_CLAIM_NAVIGATION_MAX_CLICKS) {
            if (fastWorker != null) fastWorker.postDelayed(
                    () -> scheduleFindOffersAfterClaim(report, attempt,
                            startedAt, token), POST_CLAIM_NAVIGATION_OBSERVE_MS);
            return;
        }
        boolean clicked = TapAccessibilityService.clickOffersNavigation(
                detail -> {
                    if (token != postClaimNavigationEpoch.get()) return;
                    report.accept("接单成功后导航：" + detail);
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                    // ACTION_CLICK/dispatchGesture being accepted is not proof that React Native
                    // changed pages. Re-check and continue until Offers is independently proven.
                    if (fastWorker != null) fastWorker.postDelayed(
                            () -> scheduleFindOffersAfterClaim(report, attempt + 1,
                                    startedAt, token), 220L);
                },
                reason -> {
                    if (token != postClaimNavigationEpoch.get()) return;
                    // The prior Back may have targeted a stale RN node and done nothing. If the
                    // accepted-job surface is still visible, go back to step one instead of
                    // searching Offers until the retry budget is exhausted.
                    if (TapAccessibilityService.isPostClaimJobDetailVisible()) {
                        report.accept("接单成功后导航：返回动作后仍检测到Begin Delivery/订单详情；重新点击左上角返回");
                        if (fastWorker != null) fastWorker.postDelayed(
                                () -> scheduleReturnToOffersAfterClaim(report, 0,
                                        startedAt, token), 180L);
                        return;
                    }
                    long[] waits = {100L, 180L, 300L, 500L};
                    if (fastWorker != null) fastWorker.postDelayed(
                            () -> scheduleFindOffersAfterClaim(report, attempt + 1,
                                    startedAt, token),
                            waits[Math.min(attempt, waits.length - 1)]);
                });
        if (!clicked && attempt == 0)
            report.accept("接单成功后导航：已先返回；正在寻找Offers入口");
    }

    private synchronized void finishPendingClaimLoss(
            String originalText, String evidence, boolean terminal) {
        if (originalText == null || originalText.isEmpty()
                || serialTopAction != SerialAction.ACCEPT
                || !((CardText.sameOffer(serialTopText, originalText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, originalText))) || verifiedAcceptRetryMatches(originalText))) return;
        if (!terminal) {
            // Re-read at the commit boundary, rather than trusting an earlier inspector read.
            // The dedicated page worker can finish its second proof between those two points.
            String latest=acceptScopedTerminalOutcomeSince(serialTopActionAt);
            String positive=acceptScopedOutcomeSince(serialTopActionAt);
            if (TapAccessibilityService.recentAcceptedJobDetailMatches(originalText,serialTopActionAt)
                    || isBoundPositiveClaimOutcome(originalText,positive,serialTopActionAt)
                    || TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
                confirmPendingClaimSuccess(originalText,positive.isEmpty()?"提交前已核对接单成功证据":positive);
                return;
            }
            if (!latest.isEmpty()) { terminal=true; evidence="提交前捕获"+latest; }
        }
        if (!terminal) {
            long actionAt=serialTopActionAt;
            PageOutcomePolicy.Tracker tracker=pageTracker(actionAt);
            long nowProbe=SystemClock.elapsedRealtime();
            if (preserveVisibleAcceptLoading(actionAt,tracker,nowProbe)) {
                scheduleAcceptPageProbe(actionAt);
                return;
            }
            if(tracker!=null && tracker.departureOutcomePending(nowProbe)
                    && !tracker.hasFreshCleanReplacement(nowProbe) && fastWorker!=null) {
                scheduleAcceptPageProbe(actionAt);
                final long epoch=claimEpoch.get();
                fastWorker.postDelayed(() -> expireUnboundAcceptOutcome(originalText,epoch,actionAt),80L);
                return;
            }
            if (tracker!=null && !tracker.hasFreshDifferentTop(nowProbe)
                    && !tracker.hasFreshUnboundPrompt(nowProbe)
                    && tracker.mayProbe(acceptPageProbeCount,acceptPageProbeStartedAt,nowProbe)
                    && fastWorker!=null) {
                scheduleAcceptPageProbe(actionAt);
                final long epoch=claimEpoch.get();
                fastWorker.postDelayed(() -> expireUnboundAcceptOutcome(originalText,epoch,actionAt),160L);
                return;
            }
        }
        if (terminal && !canCommitAcceptTerminalLoss(originalText, evidence)) return;
        if (terminal && ClaimSuccessSignals.isTimeConflict(acceptScopedTerminalOutcomeSince(serialTopActionAt))) {
            offerReporter(originalText).accept("ACCEPT_TIME_CONFLICT_CONFIRMED：原因=TIME_CONFLICT（含route conflict）；速度归因=不适用（平台排期限制，非抢单速度证据）；结束本轮尝试；后续重新出现且Accept可用时允许新一轮受限尝试；原始提示摘录="
                    + acceptScopedTerminalOutcomeSince(serialTopActionAt).substring("TIME_CONFLICT: ".length()));
        }
        if (terminal) evidence = "当前Accept发送后失效证据="
                + acceptScopedTerminalOutcomeSince(serialTopActionAt) + "；"
                + acceptOutcomeDiagnostic(serialTopActionAt);
        String id = CardText.identity(originalText);
        java.util.function.Consumer<String> report = offerReporter(originalText);
        long now = SystemClock.elapsedRealtime();
        String resultTiming = acceptResultTiming(originalText,
                terminal ? "UNAVAILABLE_UI" : "UNKNOWN_UI", now);
        // Preserve immutable observation anchors before releasing the foreground transaction.
        // v2.10.53 uses these only for a cheap late tail; they never authorize another click.
        long finishedActionAt = serialTopActionAt;
        int finishedJobsBaseline = pendingAcceptJobsBaseline;
        final String finishedDiagnostic=acceptOutcomeDiagnostic(finishedActionAt);
        PageOutcomePolicy.Tracker finishedTracker=pageTracker(finishedActionAt);
        final boolean recoverUnboundPrompt=!terminal && finishedTracker!=null
                && !finishedTracker.hasFreshCleanReplacement(now)
                && finishedTracker.hasFreshUnboundPrompt(now);
        // Release the completed transaction; its queued callbacks still carry the old epoch.
        claimBudget.forget(CardText.identity(serialTopText));
        claimBudget.forget(id);
        TapAccessibilityService.invalidateDecisionEvidence();
        claimEpoch.incrementAndGet();
        scanGeneration.incrementAndGet();
        serialTopText = "";
        serialTopActionAt = 0;
        serialTopAction = SerialAction.NONE;
        rejectProcessingConfirmedAt = 0;
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        pendingAcceptMissingSince = 0L;
        pendingAcceptTerminalProbeAt = 0L;
        pendingJobDetailCandidateIdentity = "";
        pendingJobDetailCandidateAt = 0L;
        consumeAcceptSuppressionSummary();
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        if (terminal) {
            String terminalEvidence = evidence == null || evidence.isEmpty()
                    ? "服务器返回offer unavailable" : evidence;
            report.accept("ACCEPT_VERIFY_REQUIRED：" + terminalEvidence
                    + "；先核对Begin Delivery；若仍是原Offer则自动Reject清除并继续扫描" + resultTiming);
            ClaimSuccessAlert.notifyVerificationRequired(this, originalText, terminalEvidence, finishedActionAt);
            armPostTerminalJobVerification(
                    originalText, finishedActionAt, finishedJobsBaseline, now);
            String navigationAudit = acceptAudit.summary(finishedActionAt, originalText, acceptPageTracker);
            java.util.function.Consumer<String> navigationReport = message -> logWriter.execute(() ->
                    updateOfferStatus(message + navigationAudit + "\n本次处理：v" + engineVersion
                            + "；Accept失效恢复", originalText, ruleSummary(originalText)));
            scheduleUnavailableCardRetirement(originalText, finishedActionAt, 0, navigationReport);
        } else {
            // UNKNOWN is a soft terminal state: release the foreground immediately, retain only
            // complete decision evidence, and observe late server signals in the background.
            // v2.10.62 may re-arm only if the CURRENT same-card Accept becomes enabled again;
            // old geometry is never retained/reused.
            if (!id.isEmpty() && quickDecisionTextComplete(originalText)) {
                // No historical decision publication retained.
    
            }
            report.accept("ACCEPT_UNKNOWN：" + (evidence == null || evidence.isEmpty()
                    ? "原卡已消失但没有明确成功/失败证据" : evidence)
                    + "；前台已释放，继续扫描；后台观察迟到终态；当前出现的Offer按统一新卡流程判断"
                    + "；"+finishedDiagnostic);
            armPostTerminalJobVerification(originalText, finishedActionAt, finishedJobsBaseline, now);
            scheduleLateAcceptTail(originalText, finishedActionAt, finishedJobsBaseline,
                    now + ACCEPT_LATE_TAIL_WINDOW_MS, 0);
            if(recoverUnboundPrompt) {
                report.accept("ACCEPT_UNBOUND_PROMPT_RECOVERY：连续两次确认当前失效提示；归属保持UNKNOWN；先复核Begin Delivery和当前Offers，再恢复入口扫描");
                returnToOffersAfterUnavailable(originalText,report);
            }
        }
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    private void armPostTerminalJobVerification(
            String originalText, long actionAt, int jobsBaseline, long now) {
        if (originalText == null || originalText.isEmpty() || actionAt <= 0L) return;
        postTerminalVerifyOfferText = originalText;
        postTerminalVerifyActionAt = actionAt;
        postTerminalVerifyUntil = now + POST_TERMINAL_JOB_VERIFY_MS;
        postTerminalVerifyJobsBaseline = jobsBaseline;
        clearPostTerminalSuccessCandidate();
        Handler fast = acceptOutcomeWorker!=null?acceptOutcomeWorker:fastWorker;
        if (fast != null) fast.postDelayed(
                () -> pollPostTerminalJobVerification(originalText, actionAt),
                POST_TERMINAL_JOB_VERIFY_POLL_MS);
    }

    /**
     * v2.10.120: an unavailable result is ambiguous only until the assigned-job surface has had
     * a bounded chance to appear. It must not permanently pause monitoring or leave the dead
     * Offer pinned at the top. Re-prove the CURRENT same-card Reject control before dispatch;
     * never reuse the old Accept geometry and never Reject a visible Begin Delivery job.
     */
    private void scheduleUnavailableCardRetirement(String originalText, long actionAt, int poll,
            java.util.function.Consumer<String> report) {
        Handler maintenance = acceptOutcomeWorker!=null?acceptOutcomeWorker:fastWorker;
        if (maintenance == null || originalText == null || originalText.isEmpty()) return;
        long delay = poll == 0 ? UNAVAILABLE_RETIRE_DELAY_MS : UNAVAILABLE_RETIRE_POLL_MS;
        // Success/Accept/Reject/Offers reads belong to the result lane. They must not
        // occupy the fast queue while a newly pushed offer is waiting for its first shot.
        maintenance.postDelayed(() -> retireUnavailableCard(originalText, actionAt, poll, report), delay);
    }

    private void retireUnavailableCard(String originalText, long actionAt, int poll,
            java.util.function.Consumer<String> report) {
        if (!monitorReady || manualInterventionConfirmed || postClaimIsolationActive) return;
        if (postTerminalVerifyActionAt != actionAt || isPostTerminalSuccessCandidate(originalText)) return;
        // A newer Accept/Reject transaction owns the screen. The old unavailable tail must not
        // compete with it or reinterpret its action row.
        if (serialTopAction != SerialAction.NONE || serialTopActionAt > 0L) return;
        if (TapAccessibilityService.recentAcceptedJobDetailMatches(originalText, actionAt)
                || TapAccessibilityService.liveBeginDeliveryMatches(originalText)) {
            confirmPostTerminalClaimSuccess(originalText,
                    "自动清卡前检测到与本次Accept匹配的Begin Delivery详情页");
            return;
        }

        TapAccessibilityService.FastOfferSnapshot accept =
                TapAccessibilityService.getIndexedTopAcceptSnapshot(false, false);
        if (accept != null && ((accept.acceptEnabled && !TapAccessibilityService.hasCurrentNegativeBaseline(accept))
                || !CardText.sameOfferForAction(originalText, accept.text))) {
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            return;
        }
        TapAccessibilityService.FastOfferSnapshot current =
                TapAccessibilityService.getIndexedTopRejectSnapshot(false, false);
        if (current == null && accept != null)
            current = TapAccessibilityService.getPairedRejectSnapshotFromIndexedAccept(accept);

        if (current != null && CardText.sameOfferForAction(originalText, current.text)) {
            if (current.rejectEnabled && !current.rejectBounds.isEmpty()) {
                final TapAccessibilityService.FastOfferSnapshot cleanup=current;
                Handler fast=fastWorker;
                if(fast!=null) fast.post(() -> commitUnavailableCardRetirement(originalText,actionAt,cleanup,report));
                return;
            }
        } else if (current != null) {
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            return;
        }

        if (current == null && accept == null
                && TapAccessibilityService.hasCurrentOffersSurfaceEvidence(true)) {
            report.accept("UNAVAILABLE_AUTO_RETURN_CONFIRMED：当前已是可用Offers页；继续扫描");
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            return;
        }
        if (poll < UNAVAILABLE_RETIRE_MAX_POLLS) {
            scheduleUnavailableCardRetirement(originalText, actionAt, poll + 1, report);
            return;
        }

        // A missing Reject is not evidence that the screen needs a Jobs round trip.
        // The direct recovery lane rechecks the live Offers/Delivery surface before clicking.
        returnToOffersAfterUnavailable(originalText, report);
    }

    private void commitUnavailableCardRetirement(String originalText,long actionAt,
            TapAccessibilityService.FastOfferSnapshot current,java.util.function.Consumer<String> report) {
        // State mutation returns to the foreground lane only after read-only discovery.
        // Newer offers win; final Reject dispatch still refreshes the current action row.
        if(!monitorReady || manualInterventionConfirmed || postClaimIsolationActive
                || serialTopAction!=SerialAction.NONE || serialTopActionAt>0L
                || postTerminalVerifyActionAt!=actionAt || isPostTerminalSuccessCandidate(originalText)) return;
        report.accept("UNAVAILABLE_AUTO_REJECT：未发现Begin Delivery；当前同一卡片Reject已重新验证，自动清除失效卡并恢复扫描");
        handleFastRejection(current,current.amount,current.miles,"服务器已返回offer unavailable，自动清除失效卡片");
    }

    private boolean yieldDeepScanDuringUnavailableReturn(
            TapAccessibilityService.FastOfferSnapshot indexed,long now) {
        if(unavailableNavigationUntil<=0 || now>=unavailableNavigationUntil
                || serialTopAction!=SerialAction.NONE) return false;
        // A usable new card keeps priority. A partial card cannot
        // justify a full-window walk while navigation already owns its own fresh checks.
        if(indexed!=null
                && ((indexed.acceptEnabled && !indexed.acceptBounds.isEmpty())
                    || (indexed.rejectEnabled && !indexed.rejectBounds.isEmpty()))
) return false;
        lastReadableFastScan=0L; lastScan=0L; // OCR/visual and next current-index heartbeat remain live.
        return true;
    }

    private void returnToOffersAfterUnavailable(String originalText, java.util.function.Consumer<String> report) {
        startUnavailableReturn(originalText, 0, report);
    }

    private void startUnavailableReturn(String originalText, int attempt,
                                        java.util.function.Consumer<String> report) {
        Handler navigation = acceptOutcomeWorker;
        if (navigation == null || serialTopAction != SerialAction.NONE || postClaimIsolationActive) return;
        long startedAt = SystemClock.elapsedRealtime();
        long token;
        synchronized (unavailableReturnEpoch) {
            token = unavailableReturnEpoch.incrementAndGet();
            unavailableNavigationUntil = startedAt + UNAVAILABLE_RETURN_DEADLINE_MS;
        }
        MANUAL_PAUSE_HANDLER.postDelayed(() -> expireUnavailableReturn(token, report),
                UNAVAILABLE_RETURN_DEADLINE_MS);
        navigation.post(() -> returnToOffersAfterUnavailable(originalText, attempt, startedAt, token, report));
    }

    private boolean finishUnavailableReturn(long token) {
        synchronized (unavailableReturnEpoch) {
            if (!unavailableReturnEpoch.compareAndSet(token, token + 1L)) return false;
            unavailableNavigationUntil = 0L;
            return true;
        }
    }

    private void expireUnavailableReturn(long token, java.util.function.Consumer<String> report) {
        if (!finishUnavailableReturn(token)) return;
        requestImmediateFastCheck(SystemClock.uptimeMillis());
        report.accept("UNAVAILABLE_AUTO_RETURN_TIMEOUT：独立计时到期；已释放返回流程");
    }

    private void returnToOffersAfterUnavailable(String originalText, int attempt,
                                                 long startedAt, long token,
                                                 java.util.function.Consumer<String> report) {
        if (token != unavailableReturnEpoch.get()) return;
        if (SystemClock.elapsedRealtime() - startedAt >= UNAVAILABLE_RETURN_DEADLINE_MS) {
            expireUnavailableReturn(token, report);
            return;
        }
        if (!monitorReady || manualInterventionConfirmed || postClaimIsolationActive
                || serialTopAction!=SerialAction.NONE) {
            finishUnavailableReturn(token);
            return;
        }
        if (isPostTerminalSuccessCandidate(originalText)) {
            finishUnavailableReturn(token);
            return;
        }
        TapAccessibilityService.ForegroundState foreground=TapAccessibilityService.deliverThatForegroundState();
        if(foreground==TapAccessibilityService.ForegroundState.UNKNOWN) {
            long remaining = UNAVAILABLE_RETURN_DEADLINE_MS - (SystemClock.elapsedRealtime() - startedAt);
            if (remaining <= 0L) {
                if (!finishUnavailableReturn(token)) return;
                report.accept("UNAVAILABLE_AUTO_RETURN_TIMEOUT：窗口不可读取；本轮已停止；page=UNKNOWN");
                requestImmediateFastCheck(SystemClock.uptimeMillis());
            } else if(acceptOutcomeWorker!=null) acceptOutcomeWorker.postDelayed(
                    () -> returnToOffersAfterUnavailable(originalText,attempt,startedAt,token,report),Math.min(180L, remaining));
            return;
        }
        if (foreground==TapAccessibilityService.ForegroundState.OTHER_APP) {
            if (!finishUnavailableReturn(token)) return;
            report.accept(
                    "UNAVAILABLE_AUTO_RETURN_CANCELLED：DeliverThat不在前台；已终止本次返回任务，"
                            + "不再后台循环点击");
            return;
        }
        // Success can be published during the short Jobs transition. Recheck before returning;
        // never navigate away from any visible Begin Delivery success page.
        if (TapAccessibilityService.hasFreshBeginDeliveryOcr(originalText)) {
            if (!finishUnavailableReturn(token)) return;
            confirmPostTerminalClaimSuccess(originalText,
                    "失效卡离场期间检测到Begin Delivery成功页");
            return;
        }
        TapAccessibilityService.OffersNavigationSurface page =
                TapAccessibilityService.readOffersNavigationSurface(true);
        if (token != unavailableReturnEpoch.get()) return;
        if (page == TapAccessibilityService.OffersNavigationSurface.DELIVERY) {
            if (!finishUnavailableReturn(token)) return;
            if (TapAccessibilityService.liveBeginDeliveryMatches(originalText))
                confirmPostTerminalClaimSuccess(originalText, "失效卡离场期间检测到Begin Delivery成功页");
            else requestImmediateFastCheck(SystemClock.uptimeMillis());
            return;
        }
        if (page == TapAccessibilityService.OffersNavigationSurface.OFFERS) {
            if (!finishUnavailableReturn(token)) return;
            report.accept(
                    "UNAVAILABLE_AUTO_RETURN_CONFIRMED：已由当前页面/Offer动作行确认返回Offers；继续扫描");
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            return;
        }
        long age = Math.max(0L, SystemClock.elapsedRealtime() - startedAt);
        if (age >= UNAVAILABLE_RETURN_DEADLINE_MS) {
            if (!finishUnavailableReturn(token)) return;
            report.accept(
                    "UNAVAILABLE_AUTO_RETURN_TIMEOUT：未确认Offers；恢复扫描；page=" + page
                            + "；attempt=" + Math.max(0, attempt) + "；elapsed=" + age + "ms");
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            return;
        }
        if (attempt >= UNAVAILABLE_RETURN_MAX_CLICKS) {
            Handler navigation = acceptOutcomeWorker;
            if (navigation != null) navigation.postDelayed(
                    () -> returnToOffersAfterUnavailable(originalText, attempt,
                            startedAt, token, report), Math.min(UNAVAILABLE_RETURN_OBSERVE_MS,
                            UNAVAILABLE_RETURN_DEADLINE_MS - age));
            return;
        }
        final int nextAttempt = attempt + 1;
        final boolean preferGesture = nextAttempt % 2 == 0;
        String stage = "；attempt=" + nextAttempt + "；page=" + page;
        report.accept("UNAVAILABLE_AUTO_RETURN_TRY：核验后尝试返回" + stage);
        TapAccessibilityService.clickOffersRecoveryNavigation(preferGesture,
                () -> token == unavailableReturnEpoch.get()
                        && SystemClock.elapsedRealtime() - startedAt < UNAVAILABLE_RETURN_DEADLINE_MS
                        && serialTopAction == SerialAction.NONE && !postClaimIsolationActive,
                detail -> {
                    if (token != unavailableReturnEpoch.get()) return;
                    report.accept("UNAVAILABLE_AUTO_RETURN：" + detail + stage);
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                },
                reason -> {
                    if (token == unavailableReturnEpoch.get())
                        report.accept("UNAVAILABLE_AUTO_RETURN_PENDING：" + reason + stage);
                });
        // Android can accept the gesture without reporting its callback. Poll independently.
        if (acceptOutcomeWorker != null) acceptOutcomeWorker.postDelayed(
                () -> returnToOffersAfterUnavailable(originalText, nextAttempt, startedAt, token, report),
                Math.min(preferGesture ? 150L : 100L,
                        Math.max(0L, startedAt + UNAVAILABLE_RETURN_DEADLINE_MS - SystemClock.elapsedRealtime())));
    }

    private void pollPostTerminalJobVerification(String originalText, long actionAt) {
        long now = SystemClock.elapsedRealtime();
        if (!monitorReady || originalText == null
                || !CardText.sameOffer(postTerminalVerifyOfferText, originalText)
                || postTerminalVerifyActionAt != actionAt || now > postTerminalVerifyUntil) {
            if (now > postTerminalVerifyUntil && postTerminalVerifyActionAt == actionAt) {
                postTerminalVerifyOfferText = "";
                postTerminalVerifyActionAt = 0L;
                postTerminalVerifyUntil = 0L;
                postTerminalVerifyJobsBaseline = -1;
                clearPostTerminalSuccessCandidate();
            }
            return;
        }
        if (manualInterventionConfirmed) return;
        if (isPostTerminalSuccessCandidate(originalText)) return;
        // A sparse/full alias may briefly start another transaction while the original server
        // terminal is being verified. Keep polling instead of silently killing the 12 s verifier.
        // A live Begin Delivery below is authoritative and enterPostClaimIsolation() invalidates
        // every queued action before navigation starts.
        if (TapAccessibilityService.recentAcceptedJobDetailMatches(originalText, actionAt)
                || TapAccessibilityService.liveBeginDeliveryMatches(originalText)) {
            confirmPostTerminalClaimSuccess(originalText,
                    "Accept后检测到Begin Delivery成功页");
            return;
        }
        Handler fast = acceptOutcomeWorker!=null?acceptOutcomeWorker:fastWorker;
        if (fast != null) fast.postDelayed(
                () -> pollPostTerminalJobVerification(originalText, actionAt),
                POST_TERMINAL_JOB_VERIFY_POLL_MS);
    }

    private synchronized boolean confirmPostTerminalClaimSuccess(
            String originalText, String evidence) {
        long now = SystemClock.elapsedRealtime();
        if (originalText == null || originalText.isEmpty()
                || postTerminalVerifyOfferText.isEmpty()
                || !CardText.sameOffer(postTerminalVerifyOfferText, originalText)
                || now > postTerminalVerifyUntil
                || manualInterventionConfirmed) return false;

        if (!isPostTerminalSuccessCandidate(originalText)) {
            postTerminalSuccessCandidateText = originalText;
            postTerminalSuccessCandidateEvidence = evidence == null ? "" : evidence;
            postTerminalSuccessCandidateFirstAt = now;
            postTerminalSuccessCandidateLastVisibleAt = now;
            postTerminalSuccessCandidateVisiblePolls = 1;
            offerReporter(originalText).accept(
                    "ACCEPT_SUCCESS_CANDIDATE：检测到Begin Delivery；暂停清卡/返回，"
                            + "持续复核服务器稳定状态后再确认成功");
            Handler fast = acceptOutcomeWorker!=null?acceptOutcomeWorker:fastWorker;
            if (fast != null) fast.postDelayed(
                    () -> pollPostTerminalSuccessStability(originalText),
                    POST_TERMINAL_SUCCESS_POLL_MS);
        }
        return true;
    }

    private boolean isPostTerminalSuccessCandidate(String originalText) {
        return originalText != null && !originalText.isEmpty()
                && !postTerminalSuccessCandidateText.isEmpty()
                && CardText.sameOffer(postTerminalSuccessCandidateText, originalText);
    }

    private void clearPostTerminalSuccessCandidate() {
        postTerminalSuccessCandidateText = "";
        postTerminalSuccessCandidateEvidence = "";
        postTerminalSuccessCandidateFirstAt = 0L;
        postTerminalSuccessCandidateLastVisibleAt = 0L;
        postTerminalSuccessCandidateVisiblePolls = 0;
    }

    private void pollPostTerminalSuccessStability(String originalText) {
        long now = SystemClock.elapsedRealtime();
        if (!monitorReady || manualInterventionConfirmed
                || !isPostTerminalSuccessCandidate(originalText)) return;
        if (postTerminalVerifyOfferText.isEmpty()
                || !CardText.sameOffer(postTerminalVerifyOfferText, originalText)
                || now > postTerminalVerifyUntil) {
            rollbackPostTerminalSuccessCandidate(originalText,
                    "稳定复核窗口结束前未形成持久Jobs终态");
            return;
        }

        boolean beginVisible = TapAccessibilityService.liveBeginDeliveryMatches(originalText)
                || TapAccessibilityService.hasFreshBeginDeliveryOcr(originalText);
        int jobsNow = TapAccessibilityService.recentJobsBadgeCount();
        boolean jobsRaised = ClaimSuccessSignals.jobsBadgeIncreased(
                postTerminalVerifyJobsBaseline, jobsNow)
                || (postTerminalVerifyJobsBaseline < 0 && jobsNow > 0);
        if (beginVisible) {
            postTerminalSuccessCandidateLastVisibleAt = now;
            postTerminalSuccessCandidateVisiblePolls++;
            long stableMs = Math.max(0L, now - postTerminalSuccessCandidateFirstAt);
            long requiredMs = jobsRaised ? POST_TERMINAL_SUCCESS_BADGE_STABLE_MS
                    : POST_TERMINAL_SUCCESS_NO_BADGE_STABLE_MS;
            if (postTerminalSuccessCandidateVisiblePolls >= 5 && stableMs >= requiredMs) {
                commitPostTerminalClaimSuccess(originalText,
                        postTerminalSuccessCandidateEvidence
                                + (jobsRaised ? "；Jobs徽标持续存在" : "；Begin Delivery持续稳定"));
                return;
            }
        } else if (now - postTerminalSuccessCandidateLastVisibleAt
                > POST_TERMINAL_SUCCESS_MISSING_GRACE_MS) {
            rollbackPostTerminalSuccessCandidate(originalText,
                    "Begin Delivery短暂出现后消失，Jobs终态未稳定保留");
            return;
        }

        Handler fast = acceptOutcomeWorker!=null?acceptOutcomeWorker:fastWorker;
        if (fast != null) fast.postDelayed(
                () -> pollPostTerminalSuccessStability(originalText),
                POST_TERMINAL_SUCCESS_POLL_MS);
    }

    private synchronized void rollbackPostTerminalSuccessCandidate(
            String originalText, String reason) {
        if (!isPostTerminalSuccessCandidate(originalText)) return;
        clearPostTerminalSuccessCandidate();
        postTerminalVerifyOfferText = "";
        postTerminalVerifyActionAt = 0L;
        postTerminalVerifyUntil = 0L;
        postTerminalVerifyJobsBaseline = -1;
        offerReporter(originalText).accept("ACCEPT_SERVER_ROLLED_BACK：" + reason
                + "；此前仅为候选成功，未报警、未记录为已接单；继续返回Offers扫描");
        returnToOffersAfterUnavailable(originalText,
                offerReporterWithTiming(originalText, "Accept成功候选回退"));
    }

    private synchronized boolean commitPostTerminalClaimSuccess(
            String originalText, String evidence) {
        long now = SystemClock.elapsedRealtime();
        if (originalText == null || originalText.isEmpty()
                || !isPostTerminalSuccessCandidate(originalText)
                || postTerminalVerifyOfferText.isEmpty()
                || !CardText.sameOffer(postTerminalVerifyOfferText, originalText)
                || now > postTerminalVerifyUntil
                || manualInterventionConfirmed) return false;

        final long confirmedOwner=postTerminalVerifyActionAt;
        clearPostTerminalSuccessCandidate();
        postTerminalVerifyOfferText = "";
        postTerminalVerifyActionAt = 0L;
        postTerminalVerifyUntil = 0L;
        postTerminalVerifyJobsBaseline = -1;
        String id = CardText.identity(originalText);
        if (!id.isEmpty()) claimBudget.forget(id);
        if (id.equals(terminalLossIdentity)) {
            terminalLossIdentity = "";
            terminalLossUntil = 0L;
        }
        if (MANUAL_INTERVENTION_PAUSED.get() && !manualInterventionConfirmed)
            resumeAfterManualIntervention(this, true);
        java.util.function.Consumer<String> report = offerReporter(originalText);
        report.accept("ACCEPT_CONFIRMED_AFTER_RECHECK：" + evidence
                + "；已纠正终态并开始自动返回Offers");
        ClaimSuccessAlert.notifyConfirmed(this, originalText, evidence, confirmedOwner);
        enterPostClaimIsolation(evidence, TapAccessibilityService.recentJobsBadgeCount());
        long navigationToken = postClaimNavigationEpoch.get();
        scheduleReturnToOffersAfterClaim(report, 0,
                SystemClock.elapsedRealtime(), navigationToken);
        return true;
    }

    /**
     * v2.10.62 cheap post-UNKNOWN tail. No OCR/full-tree scan and no navigation. Cached terminal
     * evidence wins first. This tail records evidence only and never authorizes a retry.
     * Any newer action or manual intervention stops it to prevent cross-attribution.
     */
    private volatile long lateUnboundReportedActionAt;
    private void scheduleLateAcceptTail(String originalText, long actionAt, int jobsBaseline,
                                        long deadline, int poll) {
        if (!monitorReady || fastWorker == null || originalText == null || originalText.isEmpty()) return;
        long now = SystemClock.elapsedRealtime();
        if (now > deadline) return;
        // Later Accept OR Reject makes a generic event unsafe to attribute to this old claim.
        if(lastActionDispatchAt>actionAt || isManualInterventionPaused()
                || (serialTopAction==SerialAction.ACCEPT && serialTopActionAt>actionAt)) return;

        String outcome = acceptScopedOutcomeSince(actionAt);
        java.util.function.Consumer<String> report = offerReporter(originalText);
        if (isBoundPositiveClaimOutcome(originalText, outcome, actionAt)) {
            report.accept("ACCEPT_LATE_SUCCESS：UNKNOWN释放后捕获迟到成功证据=" + outcome
                    + "；仅修正日志，不触发任何点击");
            return;
        }
        if (TapAccessibilityService.isTerminalNegativeClaimOutcome(outcome)) {
            report.accept("ACCEPT_LATE_LOST：UNKNOWN释放后捕获迟到服务器结果=" + outcome
                    + "；仅修正日志，不触发任何点击");
            return;
        }
        if (jobsBaseline >= 0 && TapAccessibilityService.jobsBadgeIncreasedSince(jobsBaseline)) {
            report.accept("ACCEPT_LATE_SUCCESS：UNKNOWN释放后Jobs徽标增加；仅修正日志，不触发任何点击");
            return;
        }

        String unbound=TapAccessibilityService.recentTerminalNegativeClaimOutcomeSince(actionAt);
        if(!unbound.isEmpty() && lateUnboundReportedActionAt!=actionAt) {
            lateUnboundReportedActionAt=actionAt;
            report.accept("ACCEPT_LATE_UNBOUND_PROMPT：后台检测到迟到失效提示="+unbound
                    +"；缺少本次归属证明，结果保持UNKNOWN；仅记录，不点击、不清卡");
        }
        fastWorker.postDelayed(() -> scheduleLateAcceptTail(originalText, actionAt, jobsBaseline,
                deadline, poll + 1), ACCEPT_LATE_TAIL_POLL_MS);
    }

    private void inspectClaim(String originalText, long epoch, int disabledChecks, int missingChecks) {
        if (!monitorReady || epoch != claimEpoch.get() || serialTopAction != SerialAction.ACCEPT) return;
        if(acceptPressureActive(serialTopActionAt)) return;
        if (!acceptGestureDispatchedForCurrentTransaction()) {
            cancelUndispatchedAccept(originalText,
                    "Accept动作未成功dispatch；禁止进入成功/失败终态追踪");
            return;
        }
        String id = CardText.identity(originalText);
        java.util.function.Consumer<String> report = offerReporter(originalText);

        String terminalCache = acceptScopedTerminalOutcomeSince(
                serialTopActionAt);
        if (!terminalCache.isEmpty()) {
            finishPendingClaimLoss(originalText, "服务器返回" + terminalCache, true);
            return;
        }

        // Zero-tree fast exit. Accessibility events frequently expose the assigned-job screen
        // before this 70ms inspector runs. If so, do not spend 500-900ms rebuilding the old
        // offer tree and, more importantly, do not allow any stale retry gesture.
        String outcomeHint = acceptScopedOutcomeSince(serialTopActionAt);
        if (TapAccessibilityService.recentAcceptedJobDetailMatches(originalText, serialTopActionAt)) {
            confirmPendingClaimSuccess(originalText,
                    "Assigned Job ID/Delivery Timeline（金额/里程/时间已绑定当前Accept）");
            return;
        }
        if (isBoundPositiveClaimOutcome(originalText, outcomeHint, serialTopActionAt)) {
            confirmPendingClaimSuccess(originalText, outcomeHint);
            return;
        }
        if (TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
            confirmPendingClaimSuccess(originalText, "Jobs徽标已增加");
            return;
        }

        PageOutcomePolicy.Tracker departedTracker=pageTracker(serialTopActionAt);
        if(departedTracker!=null
                && !preserveVisibleAcceptLoading(serialTopActionAt,departedTracker,SystemClock.elapsedRealtime())
                && departedTracker.hasConfirmedDeparture()) {
            finishPendingClaimLoss(originalText,"当前可见行已连续确认原单离场；终态追踪转后台",false);
            return;
        }
        if ("RETRY_SPINNER_CONFIRMED".equals(acceptLoadingRetryBlock(serialTopActionAt))) {
            scheduleAcceptPageProbe(serialTopActionAt);
            return;
        }
        if(ActionDispatchPolicy.retryInFlight(SystemClock.elapsedRealtime(),acceptRetryDispatchPendingAt)) {
            if(fastWorker!=null) scheduleClaimInspection(originalText,epoch,
                    disabledChecks,missingChecks, 70L);
            return;
        }
        // A recent coherent page read already observed missing/disabled controls. Recheck
        // terminal events above immediately, and keep visual recovery for an unexported CTA.
        PageOutcomePolicy.Tracker recentPageRead=pageTracker(serialTopActionAt);
        // Do not occupy the fast queue with a duplicate Binder read during the first probe.
        // Terminal checks above remain immediate; this is a bounded asynchronous yield.
        long inspectNow=SystemClock.elapsedRealtime();
        // A recovered live control cancels scheduling-only suppression from an older disabled
        // page. It still supplies no identity/geometry authorization for the actual retry.
        boolean recoveredControl=acceptControlEnabledActionAt==serialTopActionAt && acceptControlEnabledAt>0L
                && inspectNow>=acceptControlEnabledAt && inspectNow-acceptControlEnabledAt<=250L;
        if(!recoveredControl && acceptPageProbeQueued.get() && acceptDispatchObservationAt>0L
                && inspectNow>=acceptDispatchObservationAt
                && inspectNow-acceptDispatchObservationAt<ACCEPT_PAGE_READ_HEAD_START_MS
                && recentPageRead!=null && recentPageRead.retryDecision(inspectNow).isEmpty()) {
            if(fastWorker!=null) scheduleClaimInspection(originalText,epoch,
                    disabledChecks,missingChecks,
                    ACCEPT_PAGE_READ_HEAD_START_MS - (inspectNow - acceptDispatchObservationAt));
            return;
        }
        if(!recoveredControl && recentPageRead!=null && recentPageRead.deferControlRead(SystemClock.elapsedRealtime())) {
            visualRetryNeeded="NOT_EXPORTED".equals(recentPageRead.lastActionState);
            if(fastWorker!=null) scheduleClaimInspection(originalText,epoch,
                    disabledChecks,missingChecks, ActionDispatchPolicy.RETRY_RECHECK_MS);
            return;
        }
        // Consume a matching completed page proof before starting another independent index.
        // It need not wait for text enrichment when the original identity was already complete.
        String retryExpected=acceptRetryDecisionText(originalText);
        TapAccessibilityService.FastOfferSnapshot current=recentPageRead==null?null
                :TapAccessibilityService.takeAcceptPageRetrySnapshot(retryExpected,serialTopActionAt);
        boolean reusedPageProof=current!=null;
        long activeReadAt=acceptPageReadActiveAt, readNow=SystemClock.elapsedRealtime();
        if (current == null && !recoveredControl && acceptPageReadOwner==serialTopActionAt && activeReadAt > 0L
                && readNow >= activeReadAt && readNow - activeReadAt < ACCEPT_PAGE_READ_HEAD_START_MS) {
            if(fastWorker!=null) scheduleClaimInspection(originalText,epoch,disabledChecks,missingChecks,
                    ACCEPT_PAGE_READ_HEAD_START_MS - (readNow - activeReadAt));
            return;
        }
        if(current==null) {
            current=TapAccessibilityService.observeCurrentTopAcceptSnapshot();
            retryExpected=acceptRetryDecisionText(originalText);
            TapAccessibilityService.FastOfferSnapshot newer=recentPageRead==null?null
                    :TapAccessibilityService.takeAcceptPageRetrySnapshot(retryExpected,serialTopActionAt);
            if(newer!=null) {current=newer;reusedPageProof=true;}
        }
        if (current != null && !OfferEnrichmentPolicy.sameTransaction(originalText, current.text)
                && !OfferEnrichmentPolicy.sameTransaction(retryExpected, current.text))
            current = null;
        // A new top card does not prove the active offer left the visible list.
        // Locate the owned row before missing-card tracking or retiring the transaction.
        if(current==null) {
            current=TapAccessibilityService.observeCurrentOwnedAcceptSnapshot(retryExpected,serialTopActionAt);
            if(current!=null) reusedPageProof=true;
        }
        visualRetryNeeded=current==null;
        if(current!=null && !current.acceptEnabled && recentPageRead!=null)
            recentPageRead.noteInspectorDisabled(current.text,SystemClock.elapsedRealtime());
        outcomeHint = acceptScopedOutcomeSince(serialTopActionAt);
        if (TapAccessibilityService.recentAcceptedJobDetailMatches(originalText, serialTopActionAt)) {
            confirmPendingClaimSuccess(originalText,
                    "Assigned Job ID/Delivery Timeline（金额/里程/时间已绑定当前Accept）");
            return;
        }
        if (isBoundPositiveClaimOutcome(originalText, outcomeHint, serialTopActionAt)) {
            confirmPendingClaimSuccess(originalText, outcomeHint);
            return;
        }
        if (TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
            confirmPendingClaimSuccess(originalText, "Jobs徽标已增加");
            return;
        }

        if (TapAccessibilityService.isTerminalNegativeClaimOutcome(outcomeHint)) {
            cooldownUntil = 0;
            accessibilityActionHoldUntil = 0;
            lastReadableFastScan = 0;
            // Keep the dead first card locked only until it actually leaves the top. The explicit
            // server answer suppresses every Accept retry; no second/third claim is authorized.
            if (current != null) {
                if (fastWorker != null)
                    scheduleClaimInspection(originalText, epoch,
                            Math.max(1, disabledChecks), missingChecks, 90);
                return;
            }
        }
        if (current != null && fastRuleFailure(current.text).isEmpty()
                && claimBudget.available(id, SystemClock.elapsedRealtime())) {
            if (!current.acceptBounds.isEmpty() && current.acceptEnabled) {
                if (!ActionDispatchPolicy.previousGestureFinished(
                        SystemClock.elapsedRealtime(), acceptGestureCompletedAt)) return;
                if(resumeAcceptPressure(serialTopActionAt,epoch,current.capturedAt,current)) return;
                // Non-pressure recovery still verifies a current action before dispatch. Normal OCR/fast scans are gated
                // while serialTopActionAt is non-zero, preventing competing attempts.
                if(!acceptAdmissionBusy.compareAndSet(false,true)) {
                    if(fastWorker!=null) scheduleClaimInspection(originalText,epoch,
                            disabledChecks,missingChecks, 8L);
                    return;
                }
                try {
                    dispatchClaim(current, epoch);
                    if(reusedPageProof) acceptReporter(originalText).accept(
                            "ACCEPT_PAGE_RETRY_REUSED：页面启用证明已提交最终发送校验；实际发送以动作回调/dispatchCount为准");
                }
                finally { releaseAcceptAdmission(); }
                return;
            }
            if (!current.acceptEnabled) {
                pauseAcceptPressureForContext(serialTopActionAt,"INSPECTOR_DISABLED",SystemClock.elapsedRealtime());
                long processingNow = SystemClock.elapsedRealtime();
                final boolean firstProcessing=ActionDispatchPolicy.useFastProcessingWindow(
                        ++acceptProcessingQuietChecks);
                boolean firstProcessingObservation=acceptProcessingConfirmedAt<=0L;
                acceptProcessingConfirmedAt = processingNow;
                if (disabledChecks == 0 && firstProcessingObservation)
                    report.accept("ACCEPT_CONTROL_DISABLED：按钮禁用，仅作状态观察；不等同画面转圈或接单成功"
                            + (outcomeHint.isEmpty() ? "" : "；状态=" + outcomeHint)
                            + acceptResultTiming(originalText, "PROCESSING_UI", processingNow));
                if (fastWorker != null)
                    fastWorker.postDelayed(() -> awaitClaimProcessingOutcome(originalText, epoch,
                                    missingChecks, processingNow,firstProcessing),
                            ActionDispatchPolicy.processingPollMs());
                return;
            }
        }
        if (current != null) {
            serialTopText = originalText;
            if (serialTopActionAt <= 0) serialTopActionAt = SystemClock.elapsedRealtime();
            report.accept("顶部原订单仍可见；未确认接单，继续锁定第一张，不处理下面订单"
                    + (outcomeHint.isEmpty() ? "" : "；服务器状态=" + outcomeHint));
            cooldownUntil = 0;
            lastScan = 0;
            return;
        }

        pauseAcceptPressureForContext(serialTopActionAt,"INSPECTOR_NO_CURRENT_ACCEPT",SystemClock.elapsedRealtime());
        // Index absence is not success. Consume cached page hints; outcome probes and lower-screen
        // OCR independently own terminal evidence without a second full-window walk.
        PageGuard.Page page = TapAccessibilityService.recentPageHint();
        outcomeHint = acceptScopedOutcomeSince(serialTopActionAt);
        boolean jobsIncreased = TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline);
        boolean successEvidence = TapAccessibilityService.recentAcceptedJobDetailMatches(
                originalText, serialTopActionAt)
                || isBoundPositiveClaimOutcome(originalText, outcomeHint, serialTopActionAt)
                || jobsIncreased;
        long confirmNow = SystemClock.elapsedRealtime();
        boolean terminalKnown = TapAccessibilityService.isTerminalNegativeClaimOutcome(outcomeHint)
                || (id.equals(terminalLossIdentity) && confirmNow <= terminalLossUntil);
        ClaimConfirmation.Result confirmation =
                ClaimConfirmation.classify(false, page, successEvidence, terminalKnown);
        if (confirmation == ClaimConfirmation.Result.CONFIRMED) {
            confirmPendingClaimSuccess(originalText, !outcomeHint.isEmpty() ? outcomeHint
                    : (jobsIncreased ? "Jobs徽标已增加" : "DeliverThat显示Jobs"));
            return;
        }
        if (confirmation == ClaimConfirmation.Result.TERMINAL_LOST) {
            finishPendingClaimLoss(originalText,
                    "服务器返回" + (outcomeHint.isEmpty() ? "offer unavailable" : outcomeHint), true);
            return;
        }
        // v2.10.50: disappearance is not itself a terminal result. DeliverThat can remove the
        // offer card one frame before the assigned-job screen, Jobs badge, or unavailable text
        // becomes visible. Keep a short observation-only window; never re-Accept while missing.
        if (pendingAcceptMissingSince <= 0L) {
            pendingAcceptMissingSince = confirmNow;
            report.accept("Accept后当前索引未确认原卡；进入短时终态追踪，不盲目重试；INDEX="
                    +TapAccessibilityService.currentAcceptObservationReason());
        }
        long missingElapsed = Math.max(0L, confirmNow - pendingAcceptMissingSince);
        // v2.10.51: sparse bounded deep probes catch short-lived Jobs/detail/unavailable text
        // that page classification alone can miss. They never authorize another Accept.
        if (missingElapsed >= ACCEPT_TERMINAL_DEEP_PROBE_AFTER_MS
                && (pendingAcceptTerminalProbeAt <= 0L
                || confirmNow - pendingAcceptTerminalProbeAt >= ACCEPT_TERMINAL_DEEP_PROBE_GAP_MS)) {
            pendingAcceptTerminalProbeAt = confirmNow;
            String deepOutcome = TapAccessibilityService.recentClaimOutcomeSince(serialTopActionAt);
            if (TapAccessibilityService.recentAcceptedJobDetailMatches(originalText, serialTopActionAt)
                    || isBoundPositiveClaimOutcome(originalText, deepOutcome, serialTopActionAt)) {
                confirmPendingClaimSuccess(originalText, deepOutcome.isEmpty()
                        ? "终态追踪深探测发现Jobs/已接单详情" : deepOutcome);
                return;
            }
            if (TapAccessibilityService.isTerminalNegativeClaimOutcome(deepOutcome)) {
                finishPendingClaimLoss(originalText, "终态追踪捕获" + deepOutcome, true);
                return;
            }
        }
        if (missingElapsed < ACCEPT_TERMINAL_TRACK_WINDOW_MS) {
            if (fastWorker != null)
                scheduleClaimInspection(originalText, epoch,
                                disabledChecks, missingChecks + 1, ACCEPT_TERMINAL_TRACK_POLL_MS);
            return;
        }
        if (acceptPageProbeQueued.get() && acceptPageProbeStartedAt>0
                && confirmNow-acceptPageProbeStartedAt<1200L) {
            if (fastWorker!=null) scheduleClaimInspection(originalText,epoch,
                    disabledChecks,missingChecks+1, 90L);
            return;
        }
        finishPendingClaimLoss(originalText,
                page == PageGuard.Page.OFFERS
                        ? "原卡已从Offers消失，终态追踪窗口内仍未检测到Jobs/已接单详情/服务器失败"
                        : "原卡已消失，终态追踪窗口内仍无明确成功/失败证据",
                false);
        return;
    }

    /**
     * v2.10.26 processing quiet lane. A prior coherent tree read already proved that the same
     * top offer's Accept control is disabled/processing. During this short window we consume
     * cached Accessibility success/failure signals only, so the confirmation phase does not
     * contend with OCR or the next UI event by rebuilding the full React-Native tree every 95ms.
     */
    private void awaitClaimProcessingOutcome(String originalText, long epoch, int missingChecks,
                                             long processingWindowStarted, boolean firstProcessing) {
        if (!monitorReady || epoch != claimEpoch.get() || serialTopAction != SerialAction.ACCEPT)
            return;
        if (originalText == null || originalText.isEmpty()
                || !((CardText.sameOffer(serialTopText, originalText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, originalText))) || verifiedAcceptRetryMatches(originalText))) return;

        String terminalCache = acceptScopedTerminalOutcomeSince(
                serialTopActionAt);
        if (!terminalCache.isEmpty()) {
            finishPendingClaimLoss(originalText, "服务器返回" + terminalCache, true);
            return;
        }
        String outcomeHint = acceptScopedOutcomeSince(serialTopActionAt);
        if (isBoundPositiveClaimOutcome(originalText, outcomeHint, serialTopActionAt)) {
            confirmPendingClaimSuccess(originalText, outcomeHint);
            return;
        }
        if (TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
            confirmPendingClaimSuccess(originalText, "Jobs徽标已增加");
            return;
        }
        if (TapAccessibilityService.isTerminalNegativeClaimOutcome(outcomeHint)) {
            // A terminal answer is authoritative, but one coherent tree recheck still owns
            // top-card retirement so a lower card can never inherit the old action rectangle.
            scheduleClaimInspection(originalText, epoch, 1, missingChecks, 0L);
            return;
        }

        long now = SystemClock.elapsedRealtime();
        long elapsed = Math.max(0L, now - processingWindowStarted);
        if (elapsed < (firstProcessing ? ActionDispatchPolicy.firstProcessingRecheckMs()
                : ActionDispatchPolicy.processingTreeRecheckMs())) {
            if (fastWorker != null)
                fastWorker.postDelayed(() -> awaitClaimProcessingOutcome(originalText, epoch,
                                missingChecks, processingWindowStarted,firstProcessing),
                        ActionDispatchPolicy.processingRecheckDelayMs(elapsed,firstProcessing));
            return;
        }

        // Recheck once after the quiet window. If Accept is still disabled, inspectClaim will
        // start a new quiet window. If it rolled back to enabled, the normal bounded retry
        // budget can act immediately; if the card disappeared, normal success/loss semantics run.
        scheduleClaimInspection(originalText, epoch, 1, missingChecks, 0L);
    }

    /**
     * v2.10.30 asynchronous Reject confirmation. The physical action has already been accepted
     * by Android, so release the serial/action lane immediately. RejectSequence keeps the same
     * card gated during its retry window; a genuinely new top card can be processed at once.
     */
    private void startAsyncRejectConfirmation(String originalText, long outcomeBaselineEpoch,
                                              long actionStartedAt) {
        if (originalText == null || originalText.isEmpty()) return;
        long now = SystemClock.elapsedRealtime();
        String id = rejectSequence.bindObservation(originalText, now);
        if (actionStartedAt <= 0L) actionStartedAt = now;
        // Confirmation owns its own timing state; never borrow scanTiming from a later card.
        long rejectToken = rejectTerminalGate.begin(id);
        RejectConfirmState state = new RejectConfirmState(id, originalText, actionStartedAt, rejectToken,
                outcomeBaselineEpoch);
        if(pendingRejectSpinnerActionAt==actionStartedAt && pendingRejectSpinnerBounds!=null)
            state.spinnerBounds=new Rect(pendingRejectSpinnerBounds);
        rejectConfirmStates.put(id, state);

        if (serialTopAction == SerialAction.REJECT && (CardText.sameOffer(serialTopText, originalText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, originalText)))) {
            claimEpoch.incrementAndGet(); // invalidate any old serial Reject inspector only
            serialTopText = "";
            serialTopActionAt = 0;
            serialTopAction = SerialAction.NONE;
            rejectProcessingConfirmedAt = 0;
            rejectDispatchCompletedAt = 0;
            rejectOutcomeBaselineEpoch = 0;
        }
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        rejectTransitionSuppressUntil = Math.max(rejectTransitionSuppressUntil, now + 220L);
        armRejectResultDeadline(state);
        requestImmediateFastCheck(SystemClock.uptimeMillis(), true);
        scheduleRejectFinalTail(state, now, 0);
    }

    private void armRejectResultDeadline(RejectConfirmState state) {
        // The confirmation scheduler is independent of the window-reading and action queues.
        Handler lane=rejectConfirmWorker;
        long wait=Math.max(0L,REJECT_RESULT_DEADLINE_MS-(SystemClock.elapsedRealtime()-state.actionAt));
        if (lane==null || !lane.postDelayed(() -> {
            if (monitorReady)
                expireRejectTail(state,"独立确认窗口到期；原因="+state.lastDeferReason);
        },wait)) expireRejectTail(state,"确认计时队列不可用");
    }

    /** A different top permits handoff; only coherent empty reads prove list departure. */
    private void deferRejectConfirmationsForNewTop(String topText) {
        if (topText == null || topText.isEmpty()) return;
        rejectSequence.invalidateReorderedEmpty();
        RejectConfirmState expired=expiredReject.get();
        if (expired!=null && rejectDepartureProven(expired.text,topText)) releaseExpiredReject(expired,true);
        for (RejectConfirmState state : rejectConfirmStates.values()) {
            if (rejectDepartureProven(state.text,topText))
                finishAsyncRejectConfirmation(state,"检测到新的顶部订单；旧Reject后台确认已让路",true);
        }
    }

    private static boolean rejectDepartureProven(String oldTop,String newTop) {
        return !RejectDemandPolicy.sameOrUnprovenOwned(oldTop,newTop)
                && RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldTop,newTop);
    }

    private void releaseExpiredReject(RejectConfirmState state, boolean changedTop) {
        synchronized (state) {
            if (expiredReject.compareAndSet(state,null)) recordRejectDeparture(state.id,changedTop);
        }
    }

    private void recordRejectDeparture(String id, boolean changedTop) {
        // A top change / spinner ack can be a temporary React Native redraw, not departure.
        // Retain a bounded same-identity lease. Coherent empty reads or lease expiry release it.
        if (changedTop) rejectSequence.markTransientDeparture(id,SystemClock.elapsedRealtime());
        else rejectSequence.forget(id);
    }

    private void observeRejectEmptyOffers(boolean empty, long generation, long readStartedAt, long now) {
        if (rejectSequence.hasReorderedDepartures(now))
            rejectSequence.observeReorderedEmpty(empty,generation,readStartedAt,now,120L);
        RejectConfirmState expired=expiredReject.get();
        if (expired!=null && rejectEmptyDeparture(expired,empty,generation,readStartedAt,now))
            releaseExpiredReject(expired,false);
        for (RejectConfirmState state : rejectConfirmStates.values()) {
            if (rejectTerminalGate.isCurrent(state.id,state.token)
                    && rejectEmptyDeparture(state,empty,generation,readStartedAt,now))
                finishAsyncRejectConfirmation(state,"前台连续两次确认Offers明确空页；原拒绝卡已消失",false);
        }
    }

    private static boolean rejectEmptyDeparture(RejectConfirmState state,boolean empty,
            long generation,long readStartedAt,long now) {
        if (!empty) {state.foregroundEmptyAt=0L;return false;}
        if (readStartedAt-state.actionAt<220L) return false;
        if (state.foregroundEmptyAt<=0L || state.foregroundEmptyGeneration!=generation) {
            state.foregroundEmptyAt=now;
            state.foregroundEmptyGeneration=generation;
            return false;
        }
        return readStartedAt-state.foregroundEmptyAt>=RejectConfirmPriorityPolicy.finalEmptyRecheckMs();
    }

    private void scheduleRejectFinalTail(RejectConfirmState state, long deferredAt, int poll) {
        Handler confirm = rejectConfirmWorker;
        if (confirm == null || state == null) return;
        confirm.postDelayed(() -> {
            if (!monitorReady || !rejectTerminalGate.isCurrent(state.id, state.token)) return;
            if (finishRejectFromCachedOutcome(state)) return;
            long age = Math.max(0L, SystemClock.elapsedRealtime() - deferredAt);
            if (age >= RejectConfirmPriorityPolicy.finalTailMs()) {
                queueFinalRejectRescue(state);
                return;
            }
            scheduleRejectFinalTail(state, deferredAt, poll + 1);
        }, RejectConfirmPriorityPolicy.finalTailPollMs());
    }

    private boolean finishRejectFromCachedOutcome(RejectConfirmState state) {
        String cached=TapAccessibilityService.recentEventClaimOutcomeAfter(
                state.outcomeBaselineEpoch,state.lastActionAt);
        if (!TapAccessibilityService.isTerminalNegativeClaimOutcome(cached)) return false;
        if (closeRejectConfirmation(state,"REJECT_BACKGROUND_FINALIZED",true))
            offerReporterWithTiming(state.text,"Reject尝试ID="+state.actionAt+"；Reject后台最终收尾；无树扫描").accept(
                    "REJECT_BACKGROUND_FINALIZED：服务器返回"+cached+"；旧Reject已最终收尾；未阻塞新卡");
        return true;
    }

    /** One bounded live recheck at tail expiry; a foreground new-card event always has priority. */
    private void queueFinalRejectRescue(RejectConfirmState state) {
        if (state == null || state.finalRescueQueued) return;
        state.finalRescueQueued = true;
        Handler confirm = rejectConfirmWorker;
        if (confirm == null || !confirm.post(() -> runFinalRejectRescue(state)))
            expireRejectTail(state, "最终复核队列不可用");
    }

    private String rejectRescuePriority(RejectConfirmState state) {
        if (isManualInterventionPaused()) return "MANUAL_PAUSE";
        long wakeAge = SystemClock.elapsedRealtime() - lastStructuralWakeAt;
        boolean wakingForegroundScan = fastCheckQueued.get() && lastStructuralWakeAt > 0L
                && wakeAge >= 0L && wakeAge <= 120L;
        return RejectDemandPolicy.deferReason(serialTopAction == SerialAction.ACCEPT,
                foregroundOfferDemandRecent(240L) || wakingForegroundScan);
    }

    private boolean rejectRescueMayRun(RejectConfirmState state) {
        return monitorReady && rejectTerminalGate.isCurrent(state.id, state.token)
                && "NONE".equals(rejectRescuePriority(state));
    }

    private void deferFinalRejectRescue(RejectConfirmState state, String reason) {
        if (!monitorReady || !rejectTerminalGate.isCurrent(state.id, state.token)) return;
        state.lastDeferReason = reason;
        if ("MANUAL_PAUSE".equals(reason)) {
            expireRejectTail(state,"人工介入；结束旧卡后台复核");
            return;
        }
        if (reason.endsWith("PRIORITY")) state.priorityDeferrals++;
        else if ("SCAN_BUDGET".equals(reason)) state.budgetDeferrals++;
        else if ("CONTROL_DISABLED".equals(reason) || "RETRY_NOT_READY".equals(reason)) state.processingDeferrals++;
        else if ("UI_CHANGED".equals(reason)) state.changedDeferrals++;
        else if ("WINDOW_UNREADABLE".equals(reason)) state.foregroundUnavailable++;
        else state.evidenceDeferrals++;
        Handler confirm = rejectConfirmWorker;
        if (SystemClock.elapsedRealtime() - state.actionAt >= REJECT_RESULT_DEADLINE_MS || confirm == null
                || state.probeCount >= RejectProbePolicy.maxReads()) {
            expireRejectTail(state, (state.probeCount >= RejectProbePolicy.maxReads()
                    ? "最终复核读取次数已达上限" : "最终复核到期") + "；原因=" + reason);
            return;
        }
        int retryCount = reason.endsWith("PRIORITY") ? state.probeCount
                : Math.max(state.probeCount,state.evidenceDeferrals+state.changedDeferrals+state.foregroundUnavailable);
        if (!confirm.postDelayed(() -> runFinalRejectRescue(state), RejectProbePolicy.retryMs(retryCount)))
            expireRejectTail(state,"最终复核队列不可用");
    }

    private void waitForRejectForeground(RejectConfirmState state) {
        if (!rejectTerminalGate.isCurrent(state.id,state.token)) return;
        Handler lane=rejectConfirmWorker;
        state.lastDeferReason="OUTSIDE_DELIVERTHAT";
        if (lane==null) {expireRejectTail(state,"前台观察队列不可用");return;}
        if (!state.awaitingForeground.compareAndSet(false,true)) return;
        Runnable expiry=() -> {
            if (state.awaitingForeground.compareAndSet(true,false))
                expireRejectTail(state,"复核窗口到期；期间离开DeliverThat");
        };
        state.foregroundExpiry=expiry;
        lane.postDelayed(expiry,Math.max(0L,REJECT_RESULT_DEADLINE_MS-(SystemClock.elapsedRealtime()-state.actionAt)));
        // A return event may have arrived while the read's result was being delivered.
        if (TapAccessibilityService.hasDeliverThatReplayForegroundHint()) onDeliverThatForeground();
    }

    static void onDeliverThatForeground() {
        OcrMonitorService service=activeInstance;
        if (service==null || !service.monitorReady || isManualInterventionPaused()) return;
        Handler confirm=service.rejectConfirmWorker;
        if (confirm==null) return;
        for (RejectConfirmState state:service.rejectConfirmStates.values()) {
            if (!state.awaitingForeground.compareAndSet(true,false)) continue;
            Runnable expiry=state.foregroundExpiry;
            if (expiry!=null) confirm.removeCallbacks(expiry);
            if (!confirm.post(() -> service.runFinalRejectRescue(state)))
                service.expireRejectTail(state,"最终复核队列不可用");
        }
    }

    private void runFinalRejectRescue(RejectConfirmState state) {
        if (state == null || !monitorReady || !rejectTerminalGate.isCurrent(state.id, state.token)) return;
        if (finishRejectFromCachedOutcome(state)) return;
        if (state.probeCount >= RejectProbePolicy.maxReads()
                || SystemClock.elapsedRealtime() - state.actionAt >= REJECT_RESULT_DEADLINE_MS) {
            expireRejectTail(state, "最终复核读取窗口已结束；原因=" + state.lastDeferReason);
            return;
        }
        if (!rejectRescueMayRun(state)) { deferFinalRejectRescue(state, rejectRescuePriority(state)); return; }
        TapAccessibilityService.recheckRejectedTop(state.text, state.processingReported, current -> {
            if (!rejectTerminalGate.isCurrent(state.id, state.token)) return;
            if(current.rejectBounds.isEmpty()) {
                deferFinalRejectRescue(state,"CONTROL_GEOMETRY_MISSING");return;
            }
            long now = SystemClock.elapsedRealtime();
            if(!current.rejectEnabled) {
                if(!state.processingReported) {
                    state.processingReported=true;
                    rejectSequence.markProcessing(state.id,now);
                    offerReporterWithTiming(state.text,"Reject尝试ID="+state.actionAt+"；Reject处理中观察；无终态封存").accept(
                            "REJECT_PROCESSING_OBSERVED：同卡Reject明确禁用；保留原事务和补拒次数，继续观察");
                }
                // Disabled/processing is an acknowledgement, NOT proof of a spinner.
                // Do not re-enter a deep polling loop while the UI is processing.
                expireRejectTail(state,"Reject控制进入处理中；未观察到明确旋转图案；"
                        +"结束旧卡后台复核，保留本次dispatch事实");
                return;
            }
            rejectSequence.markEnabledAfterProcessing(state.id,now);
            state.processingReported=false;
            int attempt = rejectSequence.reserveFinalIfFresh(state.id, now);
            if (attempt != 2) {
                deferFinalRejectRescue(state,rejectSequence.attempts(state.id,now)>=2
                        ? "RESCUE_ALREADY_SENT" : "RETRY_NOT_READY");
                return;
            }
            final long rescueOutcomeBaseline = TapAccessibilityService.claimOutcomeEventEpoch();
            final long rescueActionAt = now;
            TapAccessibilityService.tapSnapshotRejectRescue(current, CardText.amount(state.text),
                    CardText.miles(state.text), detail -> {
                        if (!rejectTerminalGate.isCurrent(state.id, state.token)) return;
                        state.lastActionAt=rescueActionAt;
                        state.outcomeBaselineEpoch=rescueOutcomeBaseline;
                        offerReporterWithTiming(state.text, "Reject尝试ID="+state.actionAt+"；Reject最终复核；新鲜顶部坐标").accept(
                                "REJECT_FINAL_RESCUE_SENT：同一顶部订单仍在且Reject仍启用；"
                                        + "第2次动作已发送；" + detail);
                        requestImmediateFastCheck(SystemClock.uptimeMillis(),true);
                        deferFinalRejectRescue(state,"RESCUE_SENT");
                    }, reason -> {
                        if (!rejectTerminalGate.isCurrent(state.id,state.token)) return;
                        rejectSequence.failed(state.id, SystemClock.elapsedRealtime());
                        expireRejectTail(state, "最终补击未dispatch：" + reason);
                    }, () -> rejectRescueMayRun(state));
        }, evidence -> finishAsyncRejectConfirmation(state, evidence,
                TapAccessibilityService.REJECT_RECHECK_TOP_CHANGED.equals(evidence)),
                reason -> {
                    state.lastReadFailure=reason;
                    if ("OUTSIDE_DELIVERTHAT".equals(reason)) waitForRejectForeground(state);
                    else if (!"MONITOR_STOPPED".equals(reason))
                        deferFinalRejectRescue(state,reason.contains("预算") ? "SCAN_BUDGET"
                                : reason.contains("UI_CHANGED") ? "UI_CHANGED"
                                : "WINDOW_UNREADABLE".equals(reason) || "MANUAL_PAUSE".equals(reason)
                                        ? reason : "EVIDENCE_INCOMPLETE");
                },
                () -> rejectRescueMayRun(state),
                () -> deferFinalRejectRescue(state, rejectRescuePriority(state)),
                (probeMs, budgetExit) -> {
                    state.lastProbeMs = probeMs;
                    state.totalProbeMs += probeMs;
                    state.lastProbeBudgetExceeded = budgetExit;
                    state.probeCount++;
                }, tree -> {
                    state.lastProbeNodes = tree.visited;
                    state.totalProbeNodes += tree.visited;
                    state.lastProbeLimit = tree.limitReason;
                });
    }

    private boolean closeRejectConfirmation(RejectConfirmState state,String outcome,boolean awaitDeparture) {
        return closeRejectConfirmation(state,outcome,awaitDeparture,false);
    }

    private boolean closeRejectConfirmation(RejectConfirmState state,String outcome,boolean awaitDeparture,
            boolean changedTop) {
        if (state==null) return false;
        synchronized (state) {
            if (rejectConfirmStates.get(state.id)!=state
                    || !rejectTerminalGate.tryTerminal(state.id,state.token,outcome)) return false;
            if (awaitDeparture) expiredReject.set(state);
            else if ("REJECT_SPINNER_CONFIRMED".equals(outcome))
                rejectSequence.markSpinnerAcknowledged(state.id,SystemClock.elapsedRealtime());
            else recordRejectDeparture(state.id,changedTop);
            rejectTerminalGate.invalidate(state.id,state.token);
            rejectConfirmStates.remove(state.id,state);
            return true;
        }
    }

    private void expireRejectTail(RejectConfirmState state, String reason) {
        if (!closeRejectConfirmation(state,"REJECT_BACKGROUND_FINAL_EXPIRED",true)) return;
        offerReporterWithTiming(state.text, "Reject尝试ID="+state.actionAt+"；Reject后台最终收尾；探测=" + state.probeCount
                + "；累计复核=" + state.totalProbeMs + "ms；优先让路=" + state.priorityDeferrals
                + "；预算退出=" + state.budgetDeferrals + "；证据不完整=" + state.evidenceDeferrals
                + "；处理中等待=" + state.processingDeferrals + "；界面更新=" + state.changedDeferrals
                + "；窗口不可读=" + state.foregroundUnavailable
                + "；末次读取问题=" + state.lastReadFailure
                + "；末次节点=" + state.lastProbeNodes + "；累计节点=" + state.totalProbeNodes
                + "；扫描限制=" + state.lastProbeLimit).accept(
                "REJECT_BACKGROUND_FINAL_EXPIRED：" + reason
                        + "；未收到服务器终态；停止后台观察；前台新卡不受影响");
    }

    private void finishAsyncRejectConfirmation(RejectConfirmState state, String evidence, boolean changedTop) {
        String outcome = changedTop ? "REJECT_TOP_CHANGED" : "REJECT_DISAPPEARED";
        if (!closeRejectConfirmation(state,outcome,false,changedTop)) {
            releaseExpiredReject(state,changedTop);
            return;
        }
        long finishedAt = SystemClock.elapsedRealtime();
        requestImmediateFastCheck(SystemClock.uptimeMillis(), true);
        logWriter.execute(() -> {
            String confirmTiming = "Reject尝试ID="+state.actionAt+"；Reject确认树" + state.lastProbeMs + "ms"
                    + (state.lastProbeBudgetExceeded ? "(预算退出)" : "") + "；探测"
                    + state.probeCount + "次；确认总" + Math.max(0L, finishedAt - state.actionAt) + "ms";
            offerReporterWithTiming(state.text,confirmTiming).accept(
                    outcome+"："+evidence+(changedTop
                            ? "；保留旧卡记录，继续扫描当前顶部"
                            : "；空页已确认，按产品规则视为Reject完成，可继续下一张"));
        });
    }

    private void finishAsyncRejectLost(RejectConfirmState state, String evidence) {
        if (state == null || !rejectTerminalGate.isCurrent(state.id, state.token)
                || !rejectConfirmStates.remove(state.id, state)) return;
        if (!rejectTerminalGate.tryTerminal(state.id, state.token, "REJECT_LOST")) {
            rejectTerminalGate.invalidate(state.id, state.token);
            return;
        }
        rejectTerminalGate.invalidate(state.id, state.token);
        long finishedAt = SystemClock.elapsedRealtime();
        rejectSequence.forget(state.id);
        String confirmTiming = "Reject尝试ID="+state.actionAt+"；Reject确认树" + state.lastProbeMs + "ms"
                + (state.lastProbeBudgetExceeded ? "(预算退出)" : "") + "；探测"
                + state.probeCount + "次；确认总" + Math.max(0L, finishedAt - state.actionAt) + "ms";
        offerReporterWithTiming(state.text, confirmTiming).accept("REJECT_LOST：" + evidence
                + "；不统计为Reject确认成功，立即继续下一张");
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    /**
     * Reject post-action confirmation is intentionally separate from Accept. Jobs badge and
     * assigned-job detail are NEVER consulted here. Two consecutive misses are required before
     * calling a rejected card gone, preventing a transient blank Accessibility frame from
     * producing a false success.
     */
    private void inspectReject(String originalText, long epoch, int missingChecks) {
        if (!monitorReady || epoch != claimEpoch.get() || serialTopAction != SerialAction.REJECT) return;
        if (originalText == null || originalText.isEmpty()
                || !(CardText.sameOffer(serialTopText, originalText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, originalText)))) return;
        final long now = SystemClock.elapsedRealtime();
        final String id = rejectSequence.bindObservation(originalText, now);
        TapAccessibilityService.FastOfferSnapshot current = TapAccessibilityService.findOffer(originalText);
        if (current != null) {
            rejectSequence.noteVisible(id, now);
            // Same card remains: do not reinterpret it as Accept and do not burn a Reject retry
            // while the control is disabled/processing. Normal shared RejectSequence timing
            // still owns any later real retry if DeliverThat rolls the state back.
            if ((!current.rejectEnabled
                    || rejectSequence.observe(id, now) == RejectSequence.State.PROCESSING)
                    && rejectProcessingConfirmedAt == 0) {
                rejectProcessingConfirmedAt = now;
            }
            if (fastWorker != null && now - serialTopActionAt < 3200L)
                fastWorker.postDelayed(() -> inspectReject(originalText, epoch, 0), 240);
            return;
        }

        rejectSequence.noteMissing(id, now);
        boolean processingAck = rejectProcessingConfirmedAt > 0
                || rejectSequence.observe(id, now) == RejectSequence.State.PROCESSING;
        int missingReads = missingChecks + 1;
        RejectConfirmation.Result result = RejectConfirmation.classify(false, processingAck, missingReads);
        if (result == RejectConfirmation.Result.PENDING) {
            if (fastWorker != null)
                fastWorker.postDelayed(() -> inspectReject(originalText, epoch, missingChecks + 1), 100);
            return;
        }
        boolean confirmed = result == RejectConfirmation.Result.CONFIRMED;
        finishRejectTransaction(originalText, confirmed, false, confirmed
                ? "原卡连续两次不可见，且此前Reject已禁用/处理中"
                : "原卡连续两次不可见，但未捕获明确Reject处理中证据");
    }

    private void finishRejectTransaction(String originalText, boolean confirmed, boolean serverNegative, String evidence) {
        if (serialTopAction != SerialAction.REJECT || originalText == null
                || !(CardText.sameOffer(serialTopText, originalText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, originalText)))) return;
        String id = rejectSequence.bindObservation(originalText, SystemClock.elapsedRealtime());
        long attemptId=serialTopActionAt;
        java.util.function.Consumer<String> report = offerReporterWithTiming(originalText,"Reject尝试ID="+attemptId);
        // v2.10.40: serial Reject resolution is authoritative. Remove any background
        // confirmation state first so an already-queued probe cannot later emit a conflicting
        // REJECT_CONFIRM_DEFERRED after REJECT_DISAPPEARED/CONFIRMED.
        RejectConfirmState bgState = rejectConfirmStates.remove(id);
        String priorRejectTerminal = rejectTerminalGate.terminalOutcome(id);
        long rejectToken = bgState != null ? bgState.token
                : (priorRejectTerminal.isEmpty() ? rejectTerminalGate.currentOrBegin(id) : 0L);
        String terminalOutcome = serverNegative ? "REJECT_BACKGROUND_FINALIZED" : "REJECT_DISAPPEARED";
        boolean terminalOwner = rejectToken > 0L
                && rejectTerminalGate.tryTerminal(id, rejectToken, terminalOutcome);
        if (rejectToken > 0L) rejectTerminalGate.invalidate(id, rejectToken);
        claimEpoch.incrementAndGet();
        serialTopText = "";
        serialTopActionAt = 0;
        serialTopAction = SerialAction.NONE;
        rejectProcessingConfirmedAt = 0;
        rejectDispatchCompletedAt = 0;
        rejectOutcomeBaselineEpoch = 0;
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        rejectSequence.forget(id);
        rejectTransitionSuppressUntil = 0;
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        if (terminalOwner) {
            report.accept(terminalOutcome+"："+evidence+"；继续扫描下一张");
        }
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    // One-time upgrade migration: erase old suppression state. It is never read to block a card.
    private static final String UNAVAILABLE_TOMBSTONES_PREF = "unavailableOfferTombstonesV21068";
    private void loadUnavailableTombstones() {
        if (prefs.contains(UNAVAILABLE_TOMBSTONES_PREF))
            prefs.edit().remove(UNAVAILABLE_TOMBSTONES_PREF).apply();
    }

    private boolean isFinalOcrAcceptBlocked(String text,long now) {
        return !acceptCardSafetyReason(text, now).isEmpty();
    }

    /** Final queued OCR action fence: live current page and transaction ownership only. */
    public static String firstAcceptCardGuard(String text) {
        OcrMonitorService service = activeInstance;
        return service == null ? "ACCEPT_NO_OWNER" :
                service.acceptCardSafetyReason(text, SystemClock.elapsedRealtime());
    }

    public static String ocrAcceptDispatchGuard(long actionAt,float amount,float miles) {
        String loading = acceptLoadingRetryBlock(actionAt);
        if (!loading.isEmpty()) return loading;
        OcrMonitorService service=activeInstance;
        if (service==null) return "OCR_ACCEPT_NO_OWNER";
        synchronized (service) {
            if (!service.monitorReady || MANUAL_INTERVENTION_PAUSED.get()
                    || service.serialTopAction!=SerialAction.ACCEPT || actionAt<=0L
                    || service.serialTopActionAt!=actionAt) return "OCR_ACCEPT_OWNER_CHANGED";
            if (Math.round(CardText.amount(service.serialTopText)*100)!=Math.round(amount*100)
                    || Math.abs(CardText.miles(service.serialTopText)-miles)>0.0001f)
                return "OCR_ACCEPT_NUMERIC_CHANGED";
            String cardGuard = service.acceptCardSafetyReason(service.serialTopText, SystemClock.elapsedRealtime());
            if (!cardGuard.isEmpty()) return cardGuard;
            if (hasBoundAcceptSuccess()) return "OCR_ACCEPT_SUCCESS_OBSERVED";
        }
        return "";
    }

    private void cancelUndispatchedAccept(String originalText, String reason) {
        if (serialTopAction != SerialAction.ACCEPT || serialTopActionAt <= 0L) return;
        if (acceptGestureDispatchedForCurrentTransaction()) {
            noteAcceptGestureCompleted();
            accessibilityActionHoldUntil = 0L;
            if(acceptPressureActive(serialTopActionAt)) scheduleAcceptPressure(serialTopActionAt,claimEpoch.get());
            scheduleClaimInspection(originalText, claimEpoch.get(), 0, 0, 0L);
            acceptReporter(originalText).accept("ACCEPT_BURST_INTERRUPTED：手势已派发，保留原事务并核验结果；原因="+reason);
            return;
        }
        String id = CardText.identity(originalText);
        java.util.function.Consumer<String> report = acceptReporter(originalText);
        claimEpoch.incrementAndGet();
        scanGeneration.incrementAndGet();
        serialTopText = "";
        serialTopActionAt = 0L;
        serialTopAction = SerialAction.NONE;
        claimBudget.cancelUndispatched(id);
        pendingAcceptJobsBaseline = -1;
        pendingAcceptMissingSince = 0L;
        pendingAcceptTerminalProbeAt = 0L;
        pendingJobDetailCandidateIdentity = "";
        pendingJobDetailCandidateAt = 0L;
        consumeAcceptSuppressionSummary();
        cooldownUntil = 0L;
        accessibilityActionHoldUntil = 0L;
        lastReadableFastScan = 0L;
        lastScan = 0L;
        cancelledAcceptPriorityUntil = SystemClock.elapsedRealtime() + 200L;
        requestImmediateFastCheck(SystemClock.uptimeMillis());
        logWriter.execute(() -> report.accept(reason == null || reason.isEmpty()
                ? "Accept未完成dispatch；已取消终态追踪" : reason));
    }

    /** Record only stable, first-card OCR evidence. Returns true after two consecutive frames. */
    private boolean observeOcrTop(String cardText, long now) {
        String id = CardText.identity(cardText);
        if (id.isEmpty()) return false;
        if (!id.equals(observedTopIdentity)) {
            observedTopIdentity = id;
            observedTopSince = now;
            observedTopFrames = 1;
            return false;
        }
        observedTopFrames = Math.min(1000, observedTopFrames + 1);
        return observedTopFrames >= ActionStallPolicy.stableFrames()
                && now - observedTopSince >= ActionStallPolicy.stableTopMs();
    }

    /**
     * Retire an old action transaction only after a different top offer is positively observed.
     * Invalidate pending claim inspectors as well as global timing gates; otherwise an old
     * inspectClaim callback can re-lock the service after the new card has already reached top.
     */
    private void retireStaleSerialLock(String newTopText, String source,
                                       java.util.function.Consumer<String> report) {
        String old = serialTopText;
        if (old.isEmpty() || CardText.sameOffer(old, newTopText)
                || OfferEnrichmentPolicy.sameTransaction(old, newTopText)) return;
        long now = SystemClock.elapsedRealtime();
        SerialAction oldAction = serialTopAction;
        long oldActionAt=serialTopActionAt;
        boolean rejectAck = oldAction == SerialAction.REJECT
                && (rejectProcessingConfirmedAt > 0
                || rejectSequence.observe(rejectSequence.bindObservation(old, now), now) == RejectSequence.State.PROCESSING);
        claimEpoch.incrementAndGet();
        serialTopText = "";
        serialTopActionAt = 0;
        serialTopAction = SerialAction.NONE;
        rejectProcessingConfirmedAt = 0;
        rejectDispatchCompletedAt = 0;
        rejectOutcomeBaselineEpoch = 0;
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        rejectTransitionSuppressUntil = 0;
        urgentTransitionIdentity = "";
        urgentTransitionUntil = 0;
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        lastStallRecoveryAt = now;
        String message;
        if (oldAction == SerialAction.REJECT) {
            String rejectId = rejectSequence.bindObservation(old, now);
            RejectConfirmState bgState = rejectConfirmStates.remove(rejectId);
            String priorRejectTerminal = rejectTerminalGate.terminalOutcome(rejectId);
            long rejectToken = bgState != null ? bgState.token
                    : (priorRejectTerminal.isEmpty() ? rejectTerminalGate.currentOrBegin(rejectId) : 0L);
            long attemptId=bgState==null ? oldActionAt : bgState.actionAt;
            String outcome = "REJECT_TOP_CHANGED";
            boolean terminalOwner = rejectToken > 0L
                    && rejectTerminalGate.tryTerminal(rejectId, rejectToken, outcome);
            if (rejectToken > 0L) rejectTerminalGate.invalidate(rejectId, rejectToken);
            recordRejectDeparture(rejectId,true);
            message = terminalOwner ? "REJECT_TOP_CHANGED：顶部已换单；保留旧卡记录；Reject尝试ID="+attemptId
                    + (rejectAck ? "；此前Reject已禁用/处理中" : "；未捕获明确处理中证据")
                    + "；立即处理下一张" : "";
        } else if (oldAction == SerialAction.ACCEPT
                && CardText.identity(old).equals(terminalLossIdentity)
                && now <= terminalLossUntil) {
            claimBudget.forget(CardText.identity(old));
            message = "ACCEPT_LOST：服务器已判定旧Offer不可用且顶部已换单；停止旧单全部重试，立即处理当前第一张";
        } else {
            message = "ACTION_STALL_RECOVERY：" + source
                    + "；旧顶部事务已失效，清除serial/cooldown/hold并继续处理当前第一张";
        }
        if (!message.isEmpty()) {
            if (report != null) report.accept(message); else updateStatus(message);
        }
    }

    private int topCropTop() {
        return Math.max(0, Math.min(height - 2, Math.round(height * TOP_ROI_START)));
    }

    private volatile long lastTerminalVisualProbeAt;
    private final ClaimVisualProbePolicy.NegativeProof terminalVisualNegative =
            new ClaimVisualProbePolicy.NegativeProof();

    private String visualBoundOutcome(long actionAt) {
        return terminalVisualNegative.read(actionAt, TapAccessibilityService.outcomeWindowEpoch(),
                SystemClock.elapsedRealtime());
    }

    private boolean terminalVisualContext(long now) {
        return (serialTopAction == SerialAction.ACCEPT && serialTopActionAt > 0L
                    && acceptGestureDispatchedForCurrentTransaction())
                || (!postTerminalVerifyOfferText.isEmpty() && now <= postTerminalVerifyUntil)
                || postClaimIsolationActive;
    }

    private int topCropBottom() {
        return Math.max(topCropTop() + 2, Math.min(height, Math.round(height * TOP_ROI_END)));
    }

    /**
     * Copy only [cropTop,cropBottom) rows from the RGBA ImageReader plane. This keeps the
     * source row stride/padding intact while avoiding a full-screen temporary bitmap.
     */
    private Bitmap imageToTopRoiBitmap(Image image, int cropTop, int cropBottom) {
        if (image == null || cropBottom <= cropTop) return null;
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer source = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        if (pixelStride <= 0 || rowStride <= 0) return null;
        int cropHeight = cropBottom - cropTop;
        int paddedWidth = rowStride / pixelStride;
        long startLong = (long) cropTop * rowStride;
        long bytesLong = (long) cropHeight * rowStride;
        if (startLong < 0 || bytesLong <= 0 || startLong + bytesLong > source.capacity()) return null;
        try {
            ByteBuffer rows = source.duplicate();
            rows.position((int) startLong);
            rows.limit((int) (startLong + bytesLong));
            rows = rows.slice();

            if (roiPaddedBuffer == null || roiPaddedBuffer.isRecycled()
                    || roiPaddedBuffer.getWidth() != paddedWidth
                    || roiPaddedBuffer.getHeight() != cropHeight) {
                if (roiPaddedBuffer != null && !roiPaddedBuffer.isRecycled()) roiPaddedBuffer.recycle();
                roiPaddedBuffer = Bitmap.createBitmap(paddedWidth, cropHeight, Bitmap.Config.ARGB_8888);
            }
            roiPaddedBuffer.copyPixelsFromBuffer(rows);
            if (paddedWidth == width) {
                roiExactBuffer = roiPaddedBuffer;
                return roiPaddedBuffer;
            }
            if (roiExactBuffer == null || roiExactBuffer == roiPaddedBuffer || roiExactBuffer.isRecycled()
                    || roiExactBuffer.getWidth() != width || roiExactBuffer.getHeight() != cropHeight) {
                if (roiExactBuffer != null && roiExactBuffer != roiPaddedBuffer && !roiExactBuffer.isRecycled())
                    roiExactBuffer.recycle();
                roiExactBuffer = Bitmap.createBitmap(width, cropHeight, Bitmap.Config.ARGB_8888);
            }
            Canvas canvas = new Canvas(roiExactBuffer);
            canvas.drawBitmap(roiPaddedBuffer,
                    new Rect(0, 0, width, cropHeight),
                    new Rect(0, 0, width, cropHeight), roiCopyPaint);
            return roiExactBuffer;
        } catch (RuntimeException | OutOfMemoryError failure) {
            return null;
        }
    }

    /** Warm ML Kit while the user is opening DeliverThat instead of on the first valuable offer. */
    private void warmRecognizer() {
        if (recognizer == null || worker == null) return;
        worker.post(() -> {
            Bitmap warm = null;
            try {
                warm = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888);
                warm.eraseColor(android.graphics.Color.WHITE);
                final Bitmap toRecycle = warm;
                recognizer.process(InputImage.fromBitmap(warm, 0))
                        .addOnCompleteListener(done -> toRecycle.recycle());
            } catch (RuntimeException | OutOfMemoryError ignored) {
                if (warm != null && !warm.isRecycled()) warm.recycle();
            }
        });
    }


    private void observeTerminalVisual(String raw, long frameAt, long uiGeneration, boolean headerOnly) {
        if (!monitorReady || !TapAccessibilityService.isDeliverThatForeground()) return;
        String owner = serialTopAction == SerialAction.ACCEPT ? serialTopText : postTerminalVerifyOfferText;
        boolean begin = ClaimSuccessSignals.hasBeginDeliveryControl(raw)
                && ClaimSuccessSignals.hasAcceptedJobDetail(raw);
        if (!headerOnly || begin)
            TapAccessibilityService.noteBeginDeliveryOcr(begin, owner, frameAt, uiGeneration);
        if (!begin) {
            // The callback already checks scan/claim epoch; require fresh UI and the actual
            // dispatch fence here too. OCR never fabricates an Accessibility outcome event.
            long now=SystemClock.elapsedRealtime();
            boolean pending=serialTopAction==SerialAction.ACCEPT && serialTopActionAt>0L;
            long actionAt=pending?serialTopActionAt:postTerminalVerifyActionAt;
            boolean late=serialTopAction==SerialAction.NONE && !postTerminalVerifyOfferText.isEmpty()
                    && now<=postTerminalVerifyUntil && lastActionDispatchAt<=actionAt
                    && !isManualInterventionPaused();
            if (postClaimIsolationActive || (!pending && !late)
                    || !ClaimVisualProbePolicy.fresh(now,frameAt,uiGeneration,
                            TapAccessibilityService.currentUiGeneration(),true)) return;
            AcceptOutcomeFence fence=acceptFenceFor(actionAt);
            if(fence==null || frameAt<fence.dispatchElapsed) return;
            String hint=ClaimSuccessSignals.extractOutcomeHint(raw);
            if(!ClaimSuccessSignals.isTerminalNegative(hint)) hint="";
            if(hint.isEmpty()) {
                String header=ClaimSuccessSignals.normalize(raw);
                if(!header.contains("deliveries") && !header.contains("offers")) return;
            }
            boolean confirmed=terminalVisualNegative.observe(actionAt,fence.dispatchElapsed,
                    TapAccessibilityService.outcomeWindowEpoch(),frameAt,now,hint);
            if(pending && !hint.isEmpty()) {
                pauseAcceptPressureForContext(actionAt,"NEGATIVE_VISIBLE",now);
                if(confirmed) finishPendingClaimLoss(owner,"当前顶部OCR连续确认="+hint,true);
            }
            // After UNKNOWN, the existing late tail reads this scoped proof and corrects
            // the log only. It cannot restart clicks, reject a card or navigate away.
            return;
        }
        if (postClaimIsolationActive) return;
        if (serialTopAction == SerialAction.ACCEPT && serialTopActionAt > 0L
                && frameAt >= serialTopActionAt) {
            confirmPendingClaimSuccess(serialTopText, "OCR下半屏检测到Begin Delivery成功页");
        } else if (!postTerminalVerifyOfferText.isEmpty() && frameAt >= postTerminalVerifyActionAt
                && SystemClock.elapsedRealtime() <= postTerminalVerifyUntil) {
            confirmPostTerminalClaimSuccess(postTerminalVerifyOfferText,
                    "OCR下半屏检测到Begin Delivery成功页");
        }
    }

    private void evaluate(Text result, long evidenceAt, Rect visualAccept) {
        PageGuard.Page active = TapAccessibilityService.recentPageHint();
        if (!monitorReady || !TapAccessibilityService.isDeliverThatForeground()) return;
        String rawScreenText = result == null ? "" : result.getText();
        long outcomeProbeNow = SystemClock.elapsedRealtime();
        // v2.10.128: after an Accept is in flight (or its unavailable verifier is armed), the
        // accepted-job CTA is self-authenticating.  Real success pages may omit the old Offer's
        // amount/mileage/time, so do not require completionKey equality before confirming.
        boolean beginDeliveryVisible = ClaimSuccessSignals.hasBeginDeliveryControl(rawScreenText);
        if (beginDeliveryVisible && serialTopAction == SerialAction.ACCEPT
                && serialTopActionAt > 0L) {
            confirmPendingClaimSuccess(serialTopText, "OCR检测到Begin Delivery成功页");
            return;
        }
        if (beginDeliveryVisible && !postTerminalVerifyOfferText.isEmpty()
                && outcomeProbeNow <= postTerminalVerifyUntil
                && confirmPostTerminalClaimSuccess(postTerminalVerifyOfferText,
                        "OCR检测到Begin Delivery成功页")) return;
        // An assigned-job screen is not a rebroadcast offer. Check the short ambiguous-terminal
        // bridge before checking the live current Offers publication.
        if (!postTerminalVerifyOfferText.isEmpty()
                && outcomeProbeNow <= postTerminalVerifyUntil
                && ClaimSuccessSignals.acceptedJobMatchesOffer(
                        postTerminalVerifyOfferText, rawScreenText)
                && confirmPostTerminalClaimSuccess(postTerminalVerifyOfferText,
                        "OCR检测到与刚才Accept匹配的Begin Delivery/Delivery Timeline")) return;

        // v2.10.37: after the first Accept gesture has been dispatched, a late OCR completion
        // for that SAME semantic card is an observer only. Check the one OCR success signal that
        // is safe without card/action parsing, then stop before popup handling, button discovery,
        // rule evaluation, logging such as "动作行仍无可靠锚点", or any second action path.
        if (serialTopAction == SerialAction.ACCEPT && serialTopActionAt > 0
                && ClaimSuccessSignals.hasAcceptedJobDetail(rawScreenText)) {
            if (ClaimSuccessSignals.acceptedJobMatchesOffer(serialTopText, rawScreenText)) {
                confirmPendingClaimSuccess(serialTopText, "已接单Job详情页（金额/里程/时间已绑定当前Accept）");
            } else {
                offerReporter(serialTopText).accept("ACCEPT_SUCCESS_CANDIDATE：检测到Job/Delivery Timeline，"
                        + "但尚未与当前Accept的金额/里程/时间一致绑定；停止Offer OCR误解析并等待下一事件");
            }
            return;
        }
        if (sameCardAcceptObservationOnly(rawScreenText)) {
            suppressDuplicateAcceptFrame(rawScreenText);
            return;
        }

        if (ownedRejectForText(rawScreenText) != null) return;

        // v2.10.34: DeliverThat can show a Large Order explanatory tooltip directly over the
        // action row. It is neither a new offer nor a Reject success. Freeze order actions,
        // dismiss the tooltip X first, then immediately rescan the same physical card.
        if (LargeOrderPopupGuard.isPopupText(rawScreenText)) {
            TapAccessibilityService.noteLargeOrderPopupOcr(rawScreenText);
            long now = SystemClock.elapsedRealtime();
            TapAccessibilityService.DecisionEvidence resume =
                    TapAccessibilityService.recentDecisionEvidence(1_400L);
            if (resume != null && resume.amount >= 0 && resume.miles >= 0) {
                largeOrderResumeEvidence = resume;
                largeOrderResumeUntil = now + 1_500L;
            }
            rejectTransitionSuppressUntil = Math.max(rejectTransitionSuppressUntil, now + 280L);
            Rect popupClose = findLargeOrderPopupClose(result);
            if (popupClose != null) popupClose.offset(0, topCropTop());
            final Rect close = popupClose == null ? null : new Rect(popupClose);
            final String popupCard = rawScreenText;
            if (close != null) {
                TapAccessibilityService.tapLargeOrderPopupClose(close, evidenceAt,
                        detail -> {
                            updateOfferStatus("LARGE_ORDER_INFO_CLOSE：检测到多人配送说明层；已先关闭X；"
                                    + "已将原卡证据送回前台快速队列；" + detail, popupCard);
                            rejectTransitionSuppressUntil = Math.min(rejectTransitionSuppressUntil,
                                    SystemClock.elapsedRealtime() + 80L);
                            lastReadableFastScan = 0;
                            lastScan = 0;
                            Handler fast = fastWorker;
                            if (fast != null) fast.postAtFrontOfQueue(() ->
                                    requestImmediateFastCheck(SystemClock.uptimeMillis()));
                        }, reason -> updateOfferStatus("LARGE_ORDER_INFO_HOLD：检测到多人配送说明层；"
                                + "未执行订单动作；" + reason, popupCard));
            } else {
                updateOfferStatus("LARGE_ORDER_INFO_HOLD：检测到多人配送说明层，但X锚点暂不可用；"
                        + "暂停Accept/Reject并等待下一帧", popupCard);
            }
            lastReadableFastScan = 0;
            lastScan = 0;
            return;
        }
        // Do not discard the OCR completion yet merely because Accessibility was readable.
        // A rescue frame may be the only source able to prove that an old serial transaction
        // no longer owns the top action row. The normal fast-path suppression is applied only
        // after stale-state reconciliation below.

        Rect semanticAccept = findButtonBounds(result, ACCEPT_WORDS);
        Rect semanticReject = findButtonBounds(result, IGNORE_WORDS);
        Rect acceptAnchor = semanticAccept == null ? null : new Rect(semanticAccept);
        boolean visualAcceptUsed = false;
        boolean acceptInferredFromReject = false;

        if (acceptAnchor == null && visualAccept != null && !visualAccept.isEmpty()) {
            acceptAnchor = new Rect(visualAccept);
            visualAcceptUsed = true;
        }
        if (acceptAnchor == null && semanticReject != null
                && ActionGeometry.plausibleLeftAction(width, semanticReject.exactCenterX())) {
            acceptAnchor = inferPairedAction(semanticReject, false);
            acceptInferredFromReject = acceptAnchor != null;
        }

        boolean acceptedJobDetail = ClaimSuccessSignals.hasAcceptedJobDetail(rawScreenText);
        if (acceptedJobDetail) {
            if (serialTopAction == SerialAction.ACCEPT && serialTopActionAt > 0) {
                if (ClaimSuccessSignals.acceptedJobMatchesOffer(serialTopText, rawScreenText))
                    confirmPendingClaimSuccess(serialTopText, "已接单Job详情页（金额/里程/时间已绑定当前Accept）");
                else
                    offerReporter(serialTopText).accept("ACCEPT_SUCCESS_CANDIDATE：Job详情存在但未绑定当前Accept；不判成功/失败，不再把Job页当Offer扫描");
            } else {
                clearPendingIgnore();
                clearPendingAccept();
                // Manual navigation/claim must never turn the assigned-job detail page into a
                // synthetic offer merely because the screen still contains pay, miles and blue UI.
                if (!postClaimIsolationActive)
                    enterPostClaimIsolation("检测到已接单Job详情页", TapAccessibilityService.recentJobsBadgeCount());
            }
            return;
        }
        boolean screenHasMoney = MONEY.matcher(rawScreenText).find();
        boolean screenHasMiles = MILES.matcher(rawScreenText).find();
        boolean screenHasOfferAction = semanticAccept != null || semanticReject != null
                || (visualAccept != null && !visualAccept.isEmpty());
        boolean ocrProvesOffer = screenHasMoney && screenHasMiles && screenHasOfferAction;
        if (postClaimIsolationActive) {
            // After a successful/manual claim, a visual-blue rectangle alone is not enough to
            // release the old Job surface. Require a fresh Offers-page classification or a real
            // semantic action label in addition to current numeric evidence.
            boolean freshNewOffer = ocrProvesOffer && (active == PageGuard.Page.OFFERS
                    || semanticAccept != null || semanticReject != null);
            if (!freshNewOffer) return;
            releasePostClaimIsolation("OCR/页面确认新Offer");
        }
        if ((active == PageGuard.Page.JOBS || active == PageGuard.Page.IGNORED) && !ocrProvesOffer) return;
        if ((active == PageGuard.Page.JOBS || active == PageGuard.Page.IGNORED) && ocrProvesOffer) {
            // A current screenshot with numbers + live Accept/Reject evidence overrides a stale
            // Accessibility selected-tab hint.  This is specifically to prevent silent misses.
            active = PageGuard.Page.OFFERS;
        }

        Rect cardAnchor = acceptAnchor != null ? acceptAnchor
                : (semanticReject == null ? null : new Rect(semanticReject));
        if (cardAnchor == null) {
            if (SystemClock.elapsedRealtime() < rejectTransitionSuppressUntil) return;
            clearPendingIgnore();
            clearPendingAccept();
            String screenText = rawScreenText.toLowerCase(Locale.US);
            if ((screenText.contains("$") || MONEY.matcher(screenText).find())
                    && MILES.matcher(screenText).find()
                    && AnchorlessOfferGuard.eligibleForRescue(rawScreenText)) {
                long now = SystemClock.elapsedRealtime();
                String key = CardText.anchorlessKey(rawScreenText);
                boolean newOffer = key.isEmpty() || !key.equals(anchorlessOfferKey)
                        || now - anchorlessLastSeenAt > 2_500L;
                if (newOffer) {
                    anchorlessOfferKey = key;
                    anchorlessFirstSeenAt = now;
                    anchorlessLastSeenAt = now;
                    anchorlessLastRetryAt = 0L;
                    anchorlessRetryCount = 0;
                    anchorlessSuppressedFrames = 0;
                    updateOfferStatusWithIdentity(
                            "OCR扫描：金额/里程已读到，但动作行仍无可靠锚点；未点击；"
                                    + "已启动最多3次限速Accessibility/下一帧复核",
                            result.getText(), ruleSummary(result.getText()), key);
                } else {
                    anchorlessLastSeenAt = now;
                    anchorlessSuppressedFrames = Math.min(10_000, anchorlessSuppressedFrames + 1);
                }

                // Single-flight bounded rescue: only the first three observations may force an
                // immediate retry, at least 90 ms apart. Afterwards the ordinary event/900 ms
                // heartbeat keeps watching, so one anchorless card cannot create an OCR storm.
                if (anchorlessRetryCount < 3 && now - anchorlessLastRetryAt >= 90L) {
                    anchorlessRetryCount++;
                    anchorlessLastRetryAt = now;
                    lastReadableFastScan = 0;
                    lastScan = 0;
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                }
            }
            return;
        }

        // A verified action row ends the anchorless retry transaction.  Do this before parsing
        // the card so a later appearance of a numerically identical offer starts fresh.
        anchorlessOfferKey = "";
        anchorlessFirstSeenAt = 0L;
        anchorlessLastSeenAt = 0L;
        anchorlessLastRetryAt = 0L;
        anchorlessRetryCount = 0;
        anchorlessSuppressedFrames = 0;

        String ocrCardText = CardText.normalizeOcrSplitDecimalMiles(
                textNearButton(result, cardAnchor));
        float ocrAmount = offerLowAmount(ocrCardText);
        TapAccessibilityService.DecisionEvidence accessibilityEvidence =
                TapAccessibilityService.recentDecisionEvidence(650L);
        boolean useAccessibilityCard = accessibilityEvidence != null
                && CardText.sameOfferIgnoringMiles(ocrCardText, accessibilityEvidence.text)
                && quickDecisionTextComplete(accessibilityEvidence.text,
                        accessibilityEvidence.amount, accessibilityEvidence.miles);
        // Cross-source correction only: if OCR loses the decimal in a value such as 0.7 mi,
        // use the fresh Accessibility representation of the SAME amount/time/merchant card.
        // No threshold or rule semantics are changed.
        String cardText = useAccessibilityCard ? accessibilityEvidence.text : ocrCardText;
        if (isFinalOcrAcceptBlocked(cardText,SystemClock.elapsedRealtime())) {
            // Current-transaction/card safety is still enforced; never treat it as old-order history.
            return;
        }
        // v2.10.36: any coherent OCR top card immediately cancels background confirmation for
        // a different old Reject. Foreground order discovery always has priority.
        deferRejectConfirmationsForNewTop(cardText);
        // v2.10.31: once an Accept transaction exists, duplicate OCR frames for the same
        // semantic card are internal noise. Suppress before rule/action logging so ML Kit cannot
        // flood the event history or create a second action path for the active transaction.
        if (serialTopAction == SerialAction.ACCEPT && serialTopActionAt > 0
                && (CardText.sameOffer(serialTopText, cardText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, cardText)))) {
            suppressDuplicateAcceptFrame(cardText);
            return;
        }
        java.util.function.Consumer<String> report = offerReporter(cardText);
        if (CardText.containsConflictingPickupEvidence(cardText)) {
            report.accept("ACCEPT_CARD_CONFLICT：OCR卡片混入多个取餐商家/时间；本帧不点击");
            return;
        }
        long actionNow = SystemClock.elapsedRealtime();
        float earlyAmount = useAccessibilityCard ? accessibilityEvidence.amount : ocrAmount;
        float earlyMiles = useAccessibilityCard ? accessibilityEvidence.miles : offerMiles(ocrCardText);
        boolean stableTop = observeOcrTop(cardText, actionNow);
        if (!serialTopText.isEmpty() && !(CardText.sameOffer(serialTopText, cardText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, cardText)))) {
            // v2.10.14: do not automatically donate one full scan cycle to a competitor.
            // If a bounded Accessibility re-read independently sees the same amount+miles on
            // the CURRENT top Accept row, OCR+Accessibility are two-source confirmation and
            // the old transaction can be retired in this same frame. Otherwise force the
            // next camera frame immediately; the old lock is preserved until that proof arrives.
            TapAccessibilityService.FastOfferSnapshot consensus = null;
            if (earlyAmount >= 0 && earlyMiles >= 0 && acceptAnchor != null)
                consensus = TapAccessibilityService.quickVerifyTopAction(earlyAmount, earlyMiles, true);
            boolean qualifiedNewOcrTop = serialTopAction == SerialAction.REJECT
                    && AcceptPreemptionPolicy.isDifferentCoherentTop(serialTopText, cardText)
                    && earlyAmount >= 0f && earlyMiles >= 0f
                    && quickDecisionTextComplete(cardText, earlyAmount, earlyMiles)
                    && fastRuleFailure(cardText, earlyAmount, earlyMiles).isEmpty()
                    && (semanticAccept != null || (visualAccept != null && !visualAccept.isEmpty()));
            if (qualifiedNewOcrTop) {
                // First fresh OCR card with an Accept anchor is already enough for a
                // qualifying replacement: no second-frame / old Reject callback wait.
                urgentTransitionIdentity = "";
                urgentTransitionUntil = 0;
                retireStaleSerialLock(cardText, "OCR合格订单抢占旧Reject", report);
            } else if (consensus != null) {
                urgentTransitionIdentity = "";
                urgentTransitionUntil = 0;
                retireStaleSerialLock(cardText, "OCR+Accessibility双源确认换顶", report);
            } else if (!stableTop) {
                urgentTransitionIdentity = CardText.identity(cardText);
                urgentTransitionUntil = actionNow + ActionStallPolicy.urgentTransitionWindowMs();
                lastScan = 0;
                report.accept("检测到疑似换顶；已启动紧急下一帧确认，不等待常规扫描周期");
                return;
            } else {
                urgentTransitionIdentity = "";
                urgentTransitionUntil = 0;
                retireStaleSerialLock(cardText, "OCR快速连续两帧确认换顶", report);
            }
        } else if (stableTop && !prefs.getBoolean("dryRun", false)) {
            if (CardText.identity(cardText).equals(urgentTransitionIdentity)) {
                urgentTransitionIdentity = "";
                urgentTransitionUntil = 0;
            }
            boolean transientBlocked = actionNow < cooldownUntil || actionNow < accessibilityActionHoldUntil;
            long sinceDispatch = lastActionDispatchAt > 0 ? actionNow - lastActionDispatchAt : Long.MAX_VALUE;
            if (transientBlocked && serialTopText.isEmpty()
                    && sinceDispatch >= ActionStallPolicy.softStallMs()
                    && actionNow - lastStallRecoveryAt >= ActionStallPolicy.recoveryDebounceMs()) {
                cooldownUntil = 0;
                accessibilityActionHoldUntil = 0;
                lastReadableFastScan = 0;
                lastStallRecoveryAt = actionNow;
                report.accept("ACTION_STALL_RECOVERY：第一张订单稳定可见但仍被旧cooldown/hold阻塞；已软复位并同帧继续");
            } else if (transientBlocked && !serialTopText.isEmpty()
                    && (CardText.sameOffer(serialTopText, cardText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, cardText)))
                    && serialTopActionAt > 0
                    && actionNow - serialTopActionAt >= ActionStallPolicy.hardHoldMs()
                    && actionNow - lastStallRecoveryAt >= ActionStallPolicy.recoveryDebounceMs()) {
                // Same-card hard stall: release only transient timing gates. Keep identity and
                // attempt budgets so we cannot spam a countdown/processing button.
                cooldownUntil = 0;
                accessibilityActionHoldUntil = 0;
                lastReadableFastScan = 0;
                lastStallRecoveryAt = actionNow;
                report.accept("ACTION_STALL_RECOVERY：同一顶部订单超过硬等待仍可见；仅释放临时阻塞，保留串行锁与重试预算");
            }
        }
        // After the watchdog had a chance to reconcile a stale transaction, ordinary cooldown
        // semantics still apply. A live claim/reject transaction is not bypassed.
        if (SystemClock.elapsedRealtime() < cooldownUntil
                || SystemClock.elapsedRealtime() < accessibilityActionHoldUntil) return;
        // An ordinary older OCR completion should still yield to a newer readable
        // Accessibility decision. A successful stall recovery clears lastReadableFastScan,
        // so this cannot suppress the same rescue frame that performed the recovery.
        if (AccessibilityFallbackPolicy.shouldYieldOcrFrame(evidenceAt,lastReadableFastScan,
                SystemClock.elapsedRealtime())) return;
        float amount = earlyAmount;
        float miles = earlyMiles;
        if (amount < 0 || miles < 0) {
            if (SystemClock.elapsedRealtime() < rejectTransitionSuppressUntil) return;
            clearPendingIgnore();
            clearPendingAccept();
            report.accept("OCR信息不完整：不会点击Accept或Ignore");
            return;
        }

        // If Accessibility cannot classify the page, only a strong right-side action
        // anchor (semantic Accept or visual blue Accept) may authorize coordinate actions.
        // An inferred Accept from a lone Reject label is not enough on UNKNOWN.
        boolean strongAcceptEvidence = semanticAccept != null
                || (visualAccept != null && !visualAccept.isEmpty());
        if (active == PageGuard.Page.UNKNOWN && !strongAcceptEvidence) {
            clearPendingIgnore();
            clearPendingAccept();
            report.accept("页面仍UNKNOWN且没有独立Accept证据；未点击");
            return;
        }

        float generalMin = prefs.getFloat("minPay", 60f);
        float generalMaxMiles = prefs.getFloat("maxMiles", 10f);
        boolean generalQualified = amount >= generalMin && miles <= generalMaxMiles;
        boolean pasadenaOffer = prefs.getBoolean("pasadenaRuleEnabled", false)
                && PasadenaRuleGuard.isPasadenaOffer(cardText);
        boolean pasadenaQualified = pasadenaOffer
                && amount >= prefs.getFloat("pasadenaMinPay", 25f)
                && miles <= prefs.getFloat("pasadenaMaxMiles", 5f);
        if (!generalQualified && !pasadenaQualified) {
            clearPendingAccept();
            handleIneligible(result, acceptAnchor, semanticReject, cardText, amount, miles,
                    numericFailureDetail(cardText, amount, miles, pasadenaOffer,
                            generalMin, generalMaxMiles,
                            prefs.getFloat("pasadenaMinPay", 25f),
                            prefs.getFloat("pasadenaMaxMiles", 5f)),
                    evidenceAt);
            return;
        }
        if (cityFilterEnabled() && !pasadenaQualified && !containsAllowedCity(cardText)) {
            clearPendingAccept();
            handleIneligible(result, acceptAnchor, semanticReject, cardText,
                    amount, miles, "城市不符合", evidenceAt);
            return;
        }
        if (!offerTimeAllowed(cardText)) {
            clearPendingAccept();
            handleIneligible(result, acceptAnchor, semanticReject, cardText,
                    amount, miles, "订单时间不符合", evidenceAt);
            return;
        }

        noteRuleReady(amount, miles, SystemClock.elapsedRealtime());

        clearPendingIgnore();

        if (acceptAnchor == null) {
            clearPendingAccept();
            QualifiedOfferAlert.notifyIfNeeded(this, prefs, cardText, amount, miles);
            report.accept("规则符合，但仍无法可靠定位Accept动作行；未接单");
            return;
        }

        if (visualAcceptUsed) {
            report.accept(String.format(Locale.US,
                    "规则符合；Accessibility/OCR按钮文字缺失，使用蓝色Accept视觉锚点：$%.2f / %.1f mi",
                    amount, miles));
        } else if (acceptInferredFromReject) {
            report.accept(String.format(Locale.US,
                    "规则符合；由同排Reject位置镜像推定Accept：$%.2f / %.1f mi", amount, miles));
        }

        int cropTop = topCropTop();
        Rect fullAccept = new Rect(acceptAnchor);
        fullAccept.offset(0, cropTop);
        if (!ActionGeometry.plausibleActionRect(width, height,
                fullAccept.left, fullAccept.top, fullAccept.right, fullAccept.bottom, true)) {
            clearPendingAccept();
            QualifiedOfferAlert.notifyIfNeeded(this, prefs, cardText, amount, miles);
            report.accept("规则符合，但Accept热区几何异常（疑似整卡/容器）；未点击，等待重新定位");
            lastReadableFastScan = 0;
            return;
        }
        float x = ActionGeometry.stableTapX(width, fullAccept.exactCenterX(), true);
        float y = fullAccept.exactCenterY();
        if (prefs.getBoolean("dryRun", false)) {
            cooldownUntil = SystemClock.elapsedRealtime() + 5_000;
            report.accept(String.format(Locale.US, "测试通过：$%.2f / %.1f mi；未点击", amount, miles));
            playAlert();
            return;
        }
        String claimId = CardText.identity(cardText);
        if (!serialTopText.isEmpty() && serialTopActionAt > 0
                && (CardText.sameOffer(serialTopText, cardText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, cardText)))) {
            // Accept duplicates were already suppressed before any rule/log work above.
            // Keep only the Reject guard because OCR must never reinterpret an in-flight Reject.
            if (serialTopAction == SerialAction.REJECT)
                report.accept("Reject事务处理中；OCR不把同一卡重新解释为Accept");
            return;
        }
        final long epoch;
        final long actionEpoch;
        if (!acceptAdmissionBusy.compareAndSet(false,true)) return;
        try {
            synchronized (this) {
                if (!monitorReady || serialTopAction!=SerialAction.NONE || serialTopActionAt>0L
                        || isManualInterventionPaused()) return;
                if (isFinalOcrAcceptBlocked(cardText,SystemClock.elapsedRealtime())) {
                    return;
                }
                claimBudget.forget(claimId); // Initial OCR admission owns the gate; no active retry is reset.
                if (claimBudget.reserve(claimId, cardText, SystemClock.elapsedRealtime()) == 0) return;
                pendingAcceptJobsBaseline = TapAccessibilityService.recentJobsBadgeCount();
                epoch = claimEpoch.incrementAndGet();
                serialTopText = cardText;
                serialTopActionAt = SystemClock.elapsedRealtime();
                serialTopAction = SerialAction.ACCEPT;
                armAcceptPressure(new TapAccessibilityService.FastOfferSnapshot(cardText,fullAccept,new Rect(),true,false),epoch);
                actionEpoch = scanGeneration.incrementAndGet();
                beginAcceptFrameSuppression(cardText);
                rejectProcessingConfirmedAt = 0;
                rejectDispatchCompletedAt = 0;
                rejectOutcomeBaselineEpoch = 0;
                acceptProcessingConfirmedAt = 0;
                lastActionDispatchAt = serialTopActionAt;
                cooldownUntil = SystemClock.elapsedRealtime() + 20L;
            }
        } finally { releaseAcceptAdmission(); }
        TapAccessibilityService.tapOcrOffer(x, y, amount, miles, evidenceAt, () -> {
                    if (!acceptCallbackCurrent(epoch, actionEpoch, cardText)) {
                        noteStaleTaskDrop();
                        return;
                    }
                    noteAcceptGestureCompleted();
                    if(acceptPressureActive(serialTopActionAt)) scheduleAcceptPressure(serialTopActionAt,epoch);
                    long callbackAt = SystemClock.elapsedRealtime();
                    long actualDispatchAt = acceptDispatchObservationAt > 0L
                            ? acceptDispatchObservationAt : callbackAt;
                    String stageTiming = acceptStageTiming(
                            cardText, CardText.identity(cardText), actualDispatchAt);
                    report.accept(String.format(Locale.US,
                            "Accept点击已发送：OCR顶部按钮热区 Gesture%dms；strokes=1 rect=[%d,%d,%d,%d] tap=(%d,%d) $%.2f / %.1f mi%s；非接单确认",
                            ActionDispatchPolicy.firstGestureDurationMs(true),
                            fullAccept.left, fullAccept.top, fullAccept.right, fullAccept.bottom,
                            Math.round(x), Math.round(y), amount, miles, stageTiming));
                    if (fastWorker != null)
                        scheduleClaimInspection(cardText, epoch, 0, 0, 0L);
                }, reason -> {
                    if (!acceptCallbackCurrent(epoch, actionEpoch, cardText)) {
                        noteStaleTaskDrop();
                        return;
                    }
                    cooldownUntil = 0;
                    cancelUndispatchedAccept(cardText, "Accept未执行：" + reason);
                });
        // Queue the claim first; notification/sound work must never sit ahead of the tap.
        QualifiedOfferAlert.notifyIfNeeded(this, prefs, cardText, amount, miles);
    }

    private Rect inferPairedAction(Rect anchor, boolean inferLeft) {
        if (anchor == null || anchor.isEmpty()) return null;
        float x;
        if (inferLeft) {
            if (!ActionGeometry.plausibleRightAction(width, anchor.exactCenterX())) return null;
            x = ActionGeometry.inferredLeftActionX(width, anchor.exactCenterX());
        } else {
            if (!ActionGeometry.plausibleLeftAction(width, anchor.exactCenterX())) return null;
            x = ActionGeometry.inferredRightActionX(width, anchor.exactCenterX());
        }
        int halfW = Math.max(18, Math.min(60, anchor.width() / 2));
        int halfH = Math.max(12, Math.min(36, anchor.height() / 2));
        int cx = Math.round(x), cy = Math.round(anchor.exactCenterY());
        return new Rect(cx - halfW, cy - halfH, cx + halfW, cy + halfH);
    }

    /** Locate the Large Order tooltip X from the same OCR frame that proved the popup. */
    private Rect findLargeOrderPopupClose(Text result) {
        if (result == null || !LargeOrderPopupGuard.isPopupText(result.getText())) return null;
        Rect signature = null;
        Rect bestX = null;
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String lineText = line.getText() == null ? "" : line.getText().trim();
                String lower = lineText.toLowerCase(Locale.US).replaceAll("\s+", " ");
                Rect lineBox = line.getBoundingBox();
                if (lineBox != null && !lineBox.isEmpty()
                        && (lower.contains("this order is eligible")
                        || lower.contains("eligible to have multiple")
                        || lower.contains("drivers assigned to complete"))) {
                    if (signature == null || lineBox.top < signature.top) signature = new Rect(lineBox);
                }
                for (Text.Element element : line.getElements()) {
                    String value = element.getText() == null ? "" : element.getText().trim()
                            .toLowerCase(Locale.US).replaceAll("[^a-z0-9×]", "");
                    Rect box = element.getBoundingBox();
                    if (box == null || box.isEmpty()) continue;
                    boolean closeLabel = value.equals("x") || value.equals("×")
                            || value.equals("close") || value.equals("dismiss");
                    if (closeLabel && box.exactCenterX() >= width * 0.70f) {
                        if (bestX == null || box.exactCenterX() > bestX.exactCenterX())
                            bestX = new Rect(box);
                    }
                }
            }
        }
        if (bestX != null) return bestX;
        if (signature == null) return null;
        // OCR occasionally recognizes the body but not the icon. The tooltip itself is exact
        // evidence, so infer only its top-right X—not any Accept/Reject coordinate.
        int cx = width - Math.max(18, Math.round(width * 0.03f));
        int dy = Math.max(10, Math.min(28, Math.max(1, signature.height() / 8)));
        int cy = signature.top + dy;
        int half = Math.max(12, Math.round(width * 0.018f));
        return new Rect(cx - half, cy - half, cx + half, cy + half);
    }

    private Rect findButtonBounds(Text result, String[] words) {
        return findButtonBounds(result, words, null);
    }

    private Rect findButtonBounds(Text result, String[] words, Rect sameRowAs) {
        if (result == null) return null;
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element element : line.getElements()) {
                    String value = element.getText().trim().toLowerCase(Locale.US)
                            .replaceAll("[^a-z0-9]", "");
                    for (String word : words) {
                        Rect box = element.getBoundingBox();
                        if (buttonWordMatches(value, word) && box != null && !box.isEmpty()
                                && (sameRowAs == null || ocrSameRow(box, sameRowAs))) return new Rect(box);
                    }
                }
                String lineText = line.getText().trim().toLowerCase(Locale.US);
                String lineValue = lineText.replaceAll("[^a-z0-9]", "");
                for (String word : words) {
                    boolean present = buttonWordMatches(lineValue, word)
                            || Pattern.compile("(^|[^a-z0-9])" + Pattern.quote(word)
                            + "([^a-z0-9]|$)").matcher(lineText).find();
                    if (present && line.getBoundingBox() != null) {
                        Rect box = new Rect(line.getBoundingBox());
                        int middle = (box.left + box.right) / 2;
                        if (words == ACCEPT_WORDS && (lineValue.contains("ignore")
                                || lineValue.contains("decline") || lineValue.contains("reject"))) box.left = middle;
                        if (words == IGNORE_WORDS && (lineValue.contains("accept")
                                || lineValue.contains("claim"))) box.right = middle;
                        if (!box.isEmpty() && (sameRowAs == null || ocrSameRow(box, sameRowAs))) return box;
                    }
                }
            }
        }
        return null;
    }

    private boolean ocrSameRow(Rect a, Rect b) {
        int tolerance = Math.max(14, Math.max(a.height(), b.height()));
        return Math.abs(a.centerY() - b.centerY()) <= tolerance;
    }

    private boolean buttonWordMatches(String value, String word) {
        if (value.equals(word)) return true;
        // Common Latin OCR substitutions on Android button labels.
        if (word.equals("ignore") && (value.equals("lgnore") || value.equals("ign0re"))) return true;
        if ((word.equals("accept") || word.equals("claim")
                || word.equals("decline") || word.equals("reject") || word.equals("ignore"))
                && value.length() >= 4 && oneEditOrLess(value, word)) return true;
        return false;
    }

    private boolean oneEditOrLess(String a, String b) {
        if (Math.abs(a.length() - b.length()) > 1) return false;
        int i = 0, j = 0, edits = 0;
        while (i < a.length() && j < b.length()) {
            if (a.charAt(i) == b.charAt(j)) {
                i++;
                j++;
                continue;
            }
            if (++edits > 1) return false;
            if (a.length() > b.length()) i++;
            else if (b.length() > a.length()) j++;
            else {
                i++;
                j++;
            }
        }
        if (i < a.length() || j < b.length()) edits++;
        return edits <= 1;
    }

    private void handleIneligible(Text result, Rect acceptAnchor, Rect semanticReject,
                                  String decisionCardText, float amount, float miles,
                                  String reason, long evidenceAt) {
        Rect reject = null;
        boolean inferredReject = false;

        if (semanticReject != null && !semanticReject.isEmpty()
                && (acceptAnchor == null || ocrSameRow(semanticReject, acceptAnchor))) {
            reject = new Rect(semanticReject);
        }
        if (reject == null && acceptAnchor != null) {
            Rect sameRow = findButtonBounds(result, IGNORE_WORDS, acceptAnchor);
            if (sameRow != null) reject = new Rect(sameRow);
        }
        if (reject == null && acceptAnchor != null) {
            reject = inferPairedAction(acceptAnchor, true);
            inferredReject = reject != null;
        }

        Rect cardAnchor = acceptAnchor != null ? acceptAnchor
                : (semanticReject == null ? reject : semanticReject);
        // Keep the exact authoritative text used for the amount/mileage decision. Rebuilding
        // raw OCR text here previously changed both mileage and transaction identity (4 -> 0.4).
        String cardText = decisionCardText == null || decisionCardText.trim().isEmpty()
                ? textNearButton(result, cardAnchor) : decisionCardText;

        if (reject != null) {
            reject = new Rect(reject);
            reject.offset(0, topCropTop());
        }
        handleRejectedCard(cardText, reject, amount, miles, reason,
                false, evidenceAt, inferredReject);
    }

    private boolean handleFastRejection(TapAccessibilityService.FastOfferSnapshot snapshot,
                                        float amount, float miles, String reason) {
        if (snapshot.rejectBounds.isEmpty()) return false;
        if (!snapshot.rejectEnabled) {
            offerReporter(snapshot.text).accept("Reject按钮当前禁用/处理中；保持第一卡锁定，不重复点击");
            lastReadableFastScan = 0;
            return false;
        }
        if (!ActionGeometry.plausibleActionRect(width, height,
                snapshot.rejectBounds.left, snapshot.rejectBounds.top,
                snapshot.rejectBounds.right, snapshot.rejectBounds.bottom, false)) {
            offerReporter(snapshot.text).accept(
                    "Reject热区几何异常（疑似整卡/容器）；快速路径不点击，交给OCR重定位");
            lastReadableFastScan = 0;
            return false;
        }
        if (expiredReject.get()!=null && SystemClock.elapsedRealtime()-snapshot.capturedAt<=250L)
            deferRejectConfirmationsForNewTop(snapshot.text);
        handleRejectedCard(snapshot.text, snapshot.rejectBounds, amount, miles, reason,
                true, 0L, false, snapshot);
        return true;
    }

    private static String rejectButtonTiming(long numericAt, long firstButtonAt, long currentButtonAt,
            long submitAt) {
        return "；数值证据→首个可用Reject快照=" + (numericAt>0L && firstButtonAt>=numericAt
                ? (firstButtonAt-numericAt)+"ms" : "UNOBSERVED")
                + "；首个可用Reject快照→本次快照=" + (firstButtonAt>0L && currentButtonAt>=firstButtonAt
                ? (currentButtonAt-firstButtonAt)+"ms" : "UNOBSERVED")
                + "；首个可用Reject快照→提交=" + (firstButtonAt>0L && submitAt>=firstButtonAt
                ? (submitAt-firstButtonAt)+"ms" : "UNOBSERVED");
    }

    private void handleRejectedCard(String cardText, Rect reject, float amount, float miles,
                                    String reason, boolean fastSource, long evidenceAt,
                                    boolean inferredReject) {
        handleRejectedCard(cardText, reject, amount, miles, reason, fastSource, evidenceAt,
                inferredReject, null);
    }

    private void handleRejectedCard(String cardText, Rect reject, float amount, float miles,
                                    String reason, boolean fastSource, long evidenceAt,
                                    boolean inferredReject,
                                    TapAccessibilityService.FastOfferSnapshot fastSnapshot) {
        long now = SystemClock.elapsedRealtime();
        RejectConfirmState expired=expiredReject.get();
        if (expired!=null && !rejectDepartureProven(expired.text,cardText)
                && (CardText.sameRejectObservation(expired.text,cardText)
                    || CardText.numericTimingKey(CardText.amount(expired.text),CardText.miles(expired.text))
                        == CardText.numericTimingKey(amount,miles))) return;
        String fingerprint = rejectSequence.bindObservation(cardText, now);
        long cachedNumericAt=TapAccessibilityService.recentFirstSeenAt(CardText.identity(cardText),8000L);
        // Preserve cached event time for diagnostics, but do not mislabel old publication data as current.
        long currentNumericAt=fastSnapshot==null ? 0L : fastSnapshot.rejectNumbersReadAt();
        long buttonSnapshotAt=fastSnapshot!=null && fastSnapshot.rejectEnabled
                && !fastSnapshot.rejectBounds.isEmpty() ? fastSnapshot.capturedAt : 0L;
        long firstEnabledSnapshotAt=rejectSequence.noteEnabledSnapshot(
                fingerprint,currentNumericAt>0L?currentNumericAt:cachedNumericAt,buttonSnapshotAt);
        // OCR drift must not acquire a fresh Reject budget or prove departure.
        for (RejectConfirmState state : rejectConfirmStates.values()) {
            if (rejectTerminalGate.isCurrent(state.id, state.token)
                    && !state.id.equals(fingerprint)
                    && CardText.sameRejectObservation(state.text, cardText)) {
                return;
            }
        }
        // v2.10.110: after a real Reject, DeliverThat may redraw that same card for ~2s with
        // only amount+mileage. Its semantic fingerprint is different, so the old sequence alone
        // cannot recognize it. Coalesce only this sparse alias; complete new offers stay fast.
        if (!rejectSequence.sparseAliasOwner(fingerprint, now).isEmpty()) {
            if (rejectSequence.markSparseAliasReported(fingerprint, now)) {
                offerReporter(cardText).accept("REJECT_SPARSE_ALIAS_BLOCKED：金额/里程相同的残缺重绘帧命中旧Reject保护；"
                        + "沿用原Reject事务，不重新点击；完整新订单不受影响");
            }
            return;
        }
        if (!fingerprint.equals(lastLoggedIneligibleFingerprint)) {
            lastLoggedIneligibleFingerprint = fingerprint;
            if (fastSource) logWriter.execute(() -> appendIgnoredRecord(amount, miles, reason, cardText));
            else appendIgnoredRecord(amount, miles, reason, cardText);
        }
        if (prefs.getBoolean("dryRun", false)) {
            clearPendingIgnore();
            offerReporter(cardText).accept(String.format(Locale.US, "测试未Ignore：$%.2f / %.1f mi，%s", amount, miles, reason));
            return;
        }
        if (!prefs.getBoolean("autoIgnore", true)) {
            clearPendingIgnore();
            offerReporter(cardText).accept(String.format(Locale.US, "未接：$%.2f / %.1f mi，%s", amount, miles, reason));
            return;
        }

        // v2.10.33: OCR and Accessibility are two observers of ONE Reject transaction.
        // Record current visibility before reading the shared state so retry #2 is allowed
        // only after a real continuous-visible streak, never from one late duplicate frame.
        rejectSequence.noteVisible(fingerprint, now);
        if (rejectSequence.consumeRearmed(fingerprint, now)) {
            offerReporter(cardText).accept("REJECT_REARMED：旧拒单保护已解除；当前卡进入新的Reject事务");
        }
        RejectSequence.State state = rejectSequence.observe(fingerprint, now);
        if (state == RejectSequence.State.TOMBSTONE) return; // Only a still-owned current transaction can gate here.
        if (state == RejectSequence.State.HOLD) {
            if (rejectSequence.markHoldReported(fingerprint, now)) {
                offerReporter(cardText).accept("REJECT_NOT_CONFIRMED：同一顶部订单仍可见且2次Reject预算已占用；等待已安排动作或卡片变化");
            }
            return;
        }
        // v2.10.20: ACTION_CLICK was followed by a positive UI acknowledgement that Reject
        // became disabled/processing. Do not let OCR or Accessibility fire a second logical
        // reject merely because the card remains visible during the server transition.
        if (state == RejectSequence.State.PROCESSING || state == RejectSequence.State.WAIT) return;

        final String rejectTiming = scanTiming;
        java.util.function.Consumer<String> report = message -> logWriter.execute(
                () -> offerReporterWithTiming(cardText, rejectTiming).accept(message));

        // A mirror-derived coordinate is acceptable only as a first-resort fallback. If a
        // previous real Reject dispatch already happened, a retry must regain an explicit
        // Accessibility/OCR Reject target instead of guessing the left-side coordinate again.
        if (inferredReject && rejectSequence.attempts(fingerprint, now) > 0) {
            report.accept("Reject重试未找到明确按钮；已禁止再次使用Accept镜像坐标，等待Accessibility/新OCR帧重新定位");
            return;
        }

        if (reject == null || reject.isEmpty()) {
            report.accept("订单不符合，但动作行也无法从Accessibility/OCR/视觉几何定位；未点击");
            return;
        }
        if (!ActionGeometry.plausibleActionRect(width, height,
                reject.left, reject.top, reject.right, reject.bottom, false)) {
            report.accept("订单不符合，但Reject热区几何异常（疑似卡片/详情容器）；为防误点已取消");
            lastReadableFastScan = 0;
            return;
        }
        float x = ActionGeometry.stableTapX(width, reject.exactCenterX(), false);
        float y = reject.exactCenterY();
        // v2.10.21: the final reservation must be atomic with READY validation. OCR and
        // Accessibility run on different handlers and can reach this point from the same
        // physical card within the same few milliseconds. A separate observe()+sent() pair
        // allowed both paths to dispatch once. Only the winner of this reservation may tap.
        // v2.10.85: foreground OCR/Accessibility paths may create only attempt #1. Attempt #2
        // belongs exclusively to runFinalRejectRescue(), after one fresh bounded re-read proves
        // that the same top card and enabled Reject control are still present. This prevents a
        // normal foreground rescan from racing the asynchronous Reject confirmation tail.
        int rejectAttempt = rejectSequence.reserveFirstIfReady(fingerprint, now);
        if (rejectAttempt == 0) return;
        cooldownUntil = now + 20L;
        clearPendingIgnore();
        final long rejectEpoch = claimEpoch.incrementAndGet();
        serialTopText = cardText;
        serialTopActionAt = now;
        serialTopAction = SerialAction.REJECT;
        pendingRejectSpinnerBounds=new Rect(reject);
        pendingRejectSpinnerActionAt=now;
        rejectProcessingConfirmedAt = 0;
        rejectDispatchCompletedAt = 0;
        rejectOutcomeBaselineEpoch = TapAccessibilityService.claimOutcomeEventEpoch();
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        lastActionDispatchAt = now;
        accessibilityActionHoldUntil = now + 700;
        rejectTransitionSuppressUntil = now + 1400;

        if (inferredReject) {
            report.accept(String.format(Locale.US,
                    "拒绝文字未识别；由同排Accept位置推定左侧Reject坐标：$%.2f / %.1f mi；帧龄%dms",
                    amount, miles, evidenceAt > 0 ? ScanPolicy.actionAge(SystemClock.elapsedRealtime(), evidenceAt) : -1));
        }

        String timingIdentity=CardText.identity(cardText);
        long indexedNumericAt=fastSnapshot==null ? 0L : fastSnapshot.rejectNumbersReadAt();
        NumericWake numericWake=lastNumericWake.get();
        boolean eventNumbers=numericWake!=null && numericWake.identity.equals(timingIdentity)
                && cachedNumericAt>0L && numericWake.firstSeen==cachedNumericAt
                && (indexedNumericAt==0L || numericWake.wakeAt<indexedNumericAt);
        final long numericFirstSeen=eventNumbers ? numericWake.wakeAt
                : indexedNumericAt>0L ? indexedNumericAt : cachedNumericAt;
        String numericSource=eventNumbers ? "ACCESSIBILITY_EVENT"
                : indexedNumericAt>0L ? "CURRENT_SHARED_INDEX"
                : numericFirstSeen>0L ? "CACHED_NUMERIC_EVIDENCE" : "UNOBSERVED";
        long readStart = fastSnapshot == null ? 0L : fastSnapshot.rejectReadStartedAt();
        long localObserved=fastSnapshot==null?evidenceAt:fastSnapshot.capturedAt;
        Long pipelineStart = decisionPipelineStartedAt.get();
        long processingStart = fastSource && pipelineStart != null ? pipelineStart
                : fastSnapshot == null ? evidenceAt : readStart;
        long earliest = processingStart > 0L ? processingStart : localObserved;
        if (numericFirstSeen > 0L && (earliest <= 0L || numericFirstSeen < earliest)) earliest = numericFirstSeen;
        if (readStart > 0L && (earliest <= 0L || readStart < earliest)) earliest = readStart;
        final long firstSeen = earliest;
        final String seenSource = earliest == numericFirstSeen ? "NUMERIC_FIRST_SEEN"
                : earliest == readStart ? "INDEX_READ_BEGIN" : processingStart > 0L ? "PIPELINE_BEGIN" : "LOCAL_SNAPSHOT";
        final long submitAt = SystemClock.elapsedRealtime();
        long buttonNumericAt = indexedNumericAt>0L ? indexedNumericAt : cachedNumericAt;
        PipelineTiming pipelineTiming = decisionStageTiming.get();
        final String pipelineDetail = pipelineTiming == null ? "NOT_FAST_PIPELINE" : pipelineTiming.finish(submitAt);
        if (pipelineTiming != null) pipelineTiming.mark("rejectAdmit",submitAt);
        Long queueAt=decisionQueueAt.get(), wakeAt=decisionWakeAt.get();
        final String wakeTiming=(eventNumbers && numericWake.wakeAt<=submitAt
                ? "；同卡缓存数值→事件唤醒="+(numericWake.wakeAt-cachedNumericAt)+"ms" : "")
                +(pipelineStart!=null && queueAt!=null
                ? "；扫描队列="+(pipelineStart-queueAt)+"ms" : "")
                +(pipelineStart!=null && wakeAt!=null && wakeAt>0L && pipelineStart>=wakeAt
                    && pipelineStart-wakeAt<=2_500L ? "；本轮结构唤醒→扫描="+(pipelineStart-wakeAt)+"ms" : "；本轮结构唤醒→扫描=UNOBSERVED")
                +(fastSnapshot!=null && !fastSnapshot.rejectBounds.isEmpty()
                    ? "；当前Reject快照→提交="+Math.max(0L,submitAt-fastSnapshot.capturedAt)+"ms" : "");
        java.util.function.Consumer<String> completed = actionDetail -> {
            if (pipelineTiming != null && decisionStageTiming.get() == pipelineTiming) noteDecisionStage("rejectDispatchCallback");
            String rejectSource = fastSource ? "Accessibility顶部热区"
                    : (inferredReject ? "OCR镜像热区" : "OCR语义热区");
            long callbackAt = SystemClock.elapsedRealtime();
            boolean ownsReject = rejectEpoch == claimEpoch.get() && serialTopAction == SerialAction.REJECT
                    && CardText.sameOffer(serialTopText, cardText);
            if (ownsReject) {
                rejectDispatchCompletedAt = callbackAt;
                startAsyncRejectConfirmation(cardText, rejectOutcomeBaselineEpoch, serialTopActionAt);
            }
            if (pipelineTiming != null && decisionStageTiming.get() == pipelineTiming) noteDecisionStage("rejectCallbackHandoff");
            String detail = (actionDetail == null ? "动作详情未知" : actionDetail)
                    + "；数值首见→提交=" + (numericFirstSeen > 0L ? (submitAt-numericFirstSeen)+"ms" : "UNOBSERVED")
                    + "；数值首见来源="+numericSource
                    + "；本轮处理→提交=" + (processingStart > 0L ? (submitAt-processingStart)+"ms" : "UNOBSERVED")
                    + "；Reject尝试ID="+now+wakeTiming
                    + "；REJECT_CANONICAL="+Integer.toHexString(fingerprint.hashCode())
                    + "；REJECT_OBSERVED="+Integer.toHexString(timingIdentity.hashCode())
                    + rejectButtonTiming(buttonNumericAt,firstEnabledSnapshotAt,buttonSnapshotAt,submitAt)
                    + "；Reject数值时钟="+(indexedNumericAt>0L?"CURRENT_INDEX":"HISTORICAL_OR_UNOBSERVED")
                    + "；历史数值年龄="+(cachedNumericAt>0L?Math.max(0L,submitAt-cachedNumericAt)+"ms":"UNOBSERVED")
                    + "；PIPELINE_PHASE=" + pipelineDetail
                    + "；首见→读开始=" + (firstSeen > 0L && readStart >= firstSeen
                            ? (readStart - firstSeen) + "ms" : readStart<=0L?"NOT_INDEXED":"NUMERIC_SEEN_AFTER_READ_BEGIN")
                    + "；首见来源="+seenSource+"；计时起点→提交="
                    +(firstSeen>0L?Math.max(0L,submitAt-firstSeen)+"ms":"UNOBSERVED")
                    + "；读开始→提交="+(readStart>0L?Math.max(0L,submitAt-readStart)+"ms":"NOT_INDEXED")
                    + "；判定入口→提交=" + (submitAt - now) + "ms"
                    + "；提交→回调=" + (callbackAt - submitAt) + "ms";
            report.accept(String.format(Locale.US,
                    "顶部拒绝第%d次动作已发送：来源=%s；%s；原始rect=[%d,%d,%d,%d] tap=(%d,%d) $%.2f / %.1f mi；Reject确认已转后台",
                    rejectAttempt, rejectSource, detail,
                    reject.left, reject.top, reject.right, reject.bottom, Math.round(x), Math.round(y),
                    amount, miles));
            if (!ownsReject) report.accept(
                    "REJECT_DISPATCH_COMPLETION_LATE：动作回调迟于事务终态；保留dispatch记录");
            if (pipelineTiming != null && decisionStageTiming.get() == pipelineTiming) noteDecisionStage("rejectCallbackLog");
        };
        java.util.function.Consumer<String> failed = failureReason -> {
            if (rejectEpoch != claimEpoch.get() || serialTopAction != SerialAction.REJECT
                    || !CardText.sameOffer(serialTopText, cardText)) {
                report.accept("REJECT_DISPATCH_FAILURE_LATE：旧动作失败回调已过期，保留当前事务");
                return;
            }
            accessibilityActionHoldUntil = 0;
            cooldownUntil = 0;
            boolean staleBeforeClick = TapAccessibilityService.REJECT_PROOF_CHANGED_BEFORE_CLICK.equals(failureReason);
            long failedAt = SystemClock.elapsedRealtime();
            long retryAt = rejectSequence.failed(fingerprint, failedAt, staleBeforeClick);
            rejectDispatchCompletedAt = 0;
            rejectOutcomeBaselineEpoch = 0;
            if (rejectEpoch == claimEpoch.get() && serialTopAction == SerialAction.REJECT
                    && (CardText.sameOffer(serialTopText, cardText) || (serialTopAction == SerialAction.ACCEPT && OfferEnrichmentPolicy.sameTransaction(serialTopText, cardText)))) {
                serialTopText = "";
                serialTopActionAt = 0;
                serialTopAction = SerialAction.NONE;
                rejectProcessingConfirmedAt = 0;
            }
            lastScan = 0;
            requestImmediateFastCheck(SystemClock.uptimeMillis(), true);
            Handler lane = fastWorker;
            if (staleBeforeClick && lane != null && monitorReady) {
                lane.removeCallbacks(rejectProofRefresh);
                lane.postDelayed(rejectProofRefresh, Math.max(0L, retryAt - SystemClock.elapsedRealtime()));
            }
            report.accept("拒绝未执行：" + failureReason + "；本次未计入Reject次数"
                    + rejectButtonTiming(buttonNumericAt,firstEnabledSnapshotAt,buttonSnapshotAt,submitAt)
                    + (staleBeforeClick ? "；同卡新证据复查保护=" + (retryAt - failedAt) + "ms" : ""));
        };

        if (fastSource) {
            // v2.10.9: use the SAME first-card snapshot that made the rule decision.
            // Do not perform findOffer() here: that is another full multi-window tree walk
            // and was adding hundreds of milliseconds before Ignore. tapSnapshotRejectFast
            // now performs its own bounded stale-snapshot refresh when necessary.
            if (fastSnapshot != null && !fastSnapshot.rejectBounds.isEmpty()) {
                TapAccessibilityService.tapSnapshotRejectFast(
                        fastSnapshot, amount, miles, completed, failed,
                        () -> rejectEpoch == claimEpoch.get()
                                && serialTopAction == SerialAction.REJECT
                                && serialTopActionAt == now
                                && CardText.sameOffer(serialTopText, cardText));
            } else {
                TapAccessibilityService.ignoreIfOfferStillMatches(
                        x, y, amount, miles, cardText,
                        () -> completed.accept("verified Gesture" + ActionDispatchPolicy.firstGestureDurationMs(false) + "ms"),
                        failed);
            }
        } else {
            // v2.9.3 critical fix: OCR already found the Reject coordinate in the failing
            // screenshot, but v2.9.2 then required the same Reject to exist as an
            // Accessibility node and refused to click. Use the same fresh-coordinate
            // verified fallback as Accept instead.
            TapAccessibilityService.tapOcrReject(
                    reject, amount, miles, evidenceAt, cardText, completed, failed,
                    () -> rejectEpoch == claimEpoch.get()
                            && serialTopAction == SerialAction.REJECT
                            && serialTopActionAt == now
                            && CardText.sameOffer(serialTopText, cardText));
        }
        // Separate synchronous dispatch/callback work from the opaque scan tail.
        if (pipelineTiming != null) pipelineTiming.mark("rejectDispatchReturn",SystemClock.elapsedRealtime());
    }

    private final Runnable rejectProofRefresh = () -> requestImmediateFastCheck(SystemClock.uptimeMillis());

    private void clearPendingIgnore() {
        pendingIgnoreFingerprint = "";
        pendingIgnoreSince = 0;
    }

    private void clearPendingAccept() {
        pendingAcceptFingerprint = "";
        pendingAcceptConfirmations = 0;
    }

    private void appendIgnoredRecord(float amount, float miles, String reason, String cardText) {
        String when = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date());
        String entry = String.format(Locale.US, "%s｜$%.2f / %.1f mi｜%s\n%s",
                when, amount, miles, reason, compactOfferText(cardText));
        String history = prefs.getString("ignoredHistory", "");
        history = history.isEmpty() ? entry : entry + "\n\n" + history;
        if (history.length() > 7000) history = history.substring(0, 7000);
        prefs.edit().putString("ignoredHistory", history).apply();
        updateOfferStatus("规则未通过：$" + String.format(Locale.US, "%.2f / %.1f mi，", amount, miles)
                + reason, cardText);
    }

    private String compactOfferText(String text) {
        if (text == null) return "";
        String clean = text.replaceAll("\\s+", " ").trim();
        return clean.length() > 360 ? clean.substring(0, 360) + "…" : clean;
    }

    private String textNearButton(Text result, Rect button) {
        if (button == null) return "";
        List<CardText.Piece> pieces = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                if (line.getBoundingBox() == null) continue;
                Rect box = line.getBoundingBox();
                pieces.add(new CardText.Piece(line.getText(), box.left, box.top, box.bottom));
            }
        }
        return CardText.aboveButton(pieces, button.top, button.bottom);
    }

    private float offerLowAmount(String text) {
        Matcher range = MONEY_RANGE.matcher(text.replace(',', '.'));
        if (range.find()) {
            try { return Float.parseFloat(range.group(1).replace(',', '.')); }
            catch (NumberFormatException ignored) { }
        }
        Matcher matcher = MONEY.matcher(text.replace(',', '.'));
        if (!matcher.find()) return -1f;
        try { return Float.parseFloat(matcher.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    private float offerMiles(String text) {
        Matcher matcher = MILES.matcher(text.replace(',', '.'));
        if (!matcher.find()) return -1f;
        try { return Float.parseFloat(matcher.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    private boolean containsAllowedCity(String text) {
        String lower = text.toLowerCase(Locale.US);
        String configuredValue = prefs.getString("cities", "").trim();
        // Blank means that city filtering is disabled.
        if (configuredValue.isEmpty()) return true;
        String[] configured = configuredValue.split(",");
        List<String> cities = new ArrayList<>();
        for (String city : configured) {
            String clean = city.trim().toLowerCase(Locale.US);
            if (!clean.isEmpty()) cities.add(clean);
        }
        if (cities.isEmpty()) return false;
        for (String city : cities) if (lower.contains(city)) return true;
        return false;
    }

    /** A non-empty allow-list is always authoritative. There is no second switch that can
     * silently disable it and let a slower fallback accept a disallowed city. */
    private boolean cityFilterEnabled() {
        return !prefs.getString("cities", "").trim().isEmpty();
    }

    private int configuredScanIntervalMs() {
        return ScanPolicy.clampOcrInterval(prefs.getInt("interval", DEFAULT_SCAN_INTERVAL_MS));
    }

    private boolean offerTimeAllowed(String text) {
        try {
            String configuredStart = prefs.getString("startTime", "").trim();
            String configuredEnd = prefs.getString("endTime", "").trim();
            // Blank/incomplete time fields mean that time filtering is disabled.
            if (configuredStart.isEmpty() || configuredEnd.isEmpty()) return true;
            Matcher matcher = OFFER_TIME.matcher(text);
            if (!matcher.find()) return false;
            DateTimeFormatter offerFormat = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
            LocalTime offer = LocalTime.parse(
                    matcher.group(1) + " " + matcher.group(2).toUpperCase(Locale.US), offerFormat);
            DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
            LocalTime start = LocalTime.parse(configuredStart, f);
            LocalTime end = LocalTime.parse(configuredEnd, f);
            if (end.isAfter(start) || end.equals(start)) return !offer.isBefore(start) && !offer.isAfter(end);
            return !offer.isBefore(start) || !offer.isAfter(end);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void playAlert() {
        try {
            AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION,
                    audio.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION), 0);
            Ringtone tone = RingtoneManager.getRingtone(this,
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            tone.play();
        } catch (Exception ignored) { }
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL,
                "OCR monitor", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private Notification statusNotification(String status) {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String expanded = status;
        if (expanded.length() > 3500) expanded = expanded.substring(0, 3500);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle(MANUAL_INTERVENTION_PAUSED.get()
                        ? "人工介入中｜自动点击已暂停" : "Catering Screen Assistant")
                .setContentText(status)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(expanded))
                .setOngoing(true)
                .setContentIntent(open);
        if (MANUAL_INTERVENTION_PAUSED.get()) {
            Intent resume = new Intent(this, ClaimAlertReceiver.class)
                    .setAction(ACTION_RESUME_MANUAL);
            PendingIntent resumePi = PendingIntent.getBroadcast(this, 26043, resume,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(android.R.drawable.ic_media_play,
                    "恢复自动监控", resumePi);
        }
        return builder.build();
    }

    private final java.util.concurrent.atomic.AtomicReference<String> lastQueuedStatus =
            new java.util.concurrent.atomic.AtomicReference<>();

    private void updateStatus(String status) {
        if (status == null || status.equals(lastQueuedStatus.getAndSet(status))) return;
        logWriter.execute(() -> writeStatus(status));
    }

    private void writeStatus(String status) {
        if (!monitorReady && activeInstance != this) return;
        if (status.equals(prefs.getString("lastStatus", ""))) return;
        prefs.edit()
                .putString("lastStatus", status)
                .putLong("lastStatusAt", System.currentTimeMillis())
                .apply();
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, statusNotification(status));
    }

    private String lastEventKey = "";
    /** No city/identity audit parsing between rule readiness and first dispatch. */
    private java.util.function.Consumer<String> acceptReporter(String cardText) {
        final long reportOwner=serialTopAction==SerialAction.ACCEPT?serialTopActionAt:0L;
        final String timing = acceptTiming(cardText,scanTiming);
        final long started = SystemClock.elapsedRealtime();
        return message -> {
            final long elapsed = SystemClock.elapsedRealtime() - started;
            logWriter.execute(() -> updateOfferStatus(message + (reportOwner>0L?"；TX="+reportOwner:"") + "\n本次处理：v" + engineVersion
                    + "；" + timing + "；判断至记录" + elapsed + "ms", cardText, ruleSummary(cardText)));
        };
    }

    private java.util.function.Consumer<String> offerReporter(String cardText) {
        return offerReporterWithTiming(cardText, scanTiming);
    }

    /** Freeze timing at transaction creation; async confirmation must not read global scanTiming. */
    private java.util.function.Consumer<String> offerReporterWithTiming(String cardText, String timingValue) {
        final String rules = ruleSummary(cardText);
        final long reportOwner=serialTopAction==SerialAction.ACCEPT?serialTopActionAt:postTerminalVerifyActionAt;
        final String timing = acceptTiming(cardText,timingValue);
        final long started = SystemClock.elapsedRealtime();
        return message -> updateOfferStatus(message
                + ((message.startsWith("UNAVAILABLE_") || message.startsWith("ACCEPT_VERIFY_REQUIRED")
                    || message.startsWith("ACCEPT_UNKNOWN")) ? acceptAudit.summary(reportOwner,cardText,acceptPageTracker) : "")
                + "\n本次处理：v" + engineVersion + "；" + timing + "；判断至记录"
                + (SystemClock.elapsedRealtime() - started) + "ms", cardText, rules);
    }

    private String ruleSummary() {
        return ruleSummary("");
    }

    private String ruleSummary(String cardText) {
        boolean pasadenaEnabled = prefs.getBoolean("pasadenaRuleEnabled", false);
        return "普通≥$" + prefs.getFloat("minPay",60f) + " / ≤" + prefs.getFloat("maxMiles",10f)
                + "mi；Pasadena启用=" + pasadenaEnabled
                + " ≥$" + prefs.getFloat("pasadenaMinPay",25f) + " / ≤" + prefs.getFloat("pasadenaMaxMiles",5f)
                + "mi；" + PasadenaRuleGuard.auditTag(cardText, pasadenaEnabled)
                + "；解析城市=" + PasadenaRuleGuard.parsedCitiesForLog(cardText)
                + "；城市过滤=" + (cityFilterEnabled() ? "强制" : "关闭")
                + "；允许城市=" + prefs.getString("cities", "") + "；时间=" + prefs.getString("startTime", "")
                + "–" + prefs.getString("endTime", "")
                + "；扫描=" + configuredScanIntervalMs() + "ms"
                + "；最近OCR调度=" + lastEffectiveOcrIntervalMs + "ms";
    }

    private void updateOfferStatus(String status, String cardText) {
        updateOfferStatus(status, cardText, ruleSummary(cardText));
    }

    private synchronized void updateOfferStatus(String status, String cardText, String rules) {
        updateOfferStatusWithIdentity(status, cardText, rules, CardText.identity(cardText));
    }

    private synchronized void updateOfferStatusWithIdentity(String status, String cardText,
                                                             String rules, String identityOverride) {
        boolean rejectTerminal=status.startsWith("REJECT_DISAPPEARED：")
                || status.startsWith("REJECT_TOP_CHANGED：")
                || status.startsWith("REJECT_BACKGROUND_FINAL_EXPIRED：")
                || status.startsWith("REJECT_BACKGROUND_FINALIZED：")
                || status.startsWith("REJECT_LOST：");
        if (!isMonitoring() && !(rejectTerminal && monitorReady && activeInstance==this)) return;
        String identity = identityOverride == null || identityOverride.isEmpty()
                ? CardText.identity(cardText) : identityOverride;
        String message=status.split("\\n本次处理：",2)[0];
        String eventKey=identity+"|"+message;
        String attemptLabel="Reject尝试ID=";
        int attempt=status.indexOf(attemptLabel);
        if (attempt>=0 && (message.startsWith("REJECT_") || message.startsWith("顶部拒绝"))) {
            int end=attempt+attemptLabel.length();
            while (end<status.length() && Character.isDigit(status.charAt(end))) end++;
            eventKey+="|"+status.substring(attempt,end);
        }
        if (eventKey.equals(lastEventKey)) return;
        lastEventKey = eventKey;
        String id = Integer.toHexString(identity.hashCode());
        String event = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(new Date())
                + "｜卡片#" + id + "\n" + status + "\n本次卡片：" + cardText
                + "\n本次规则：" + rules;
        final long recordAt = SystemClock.elapsedRealtime();
        logWriter.execute(() -> {
        if (!monitorReady) return;
        acceptReplay.event(recordAt, status);
        try {
            org.json.JSONArray history = new org.json.JSONArray(prefs.getString("decisionEvents", "[]"));
            org.json.JSONArray next = new org.json.JSONArray();
            next.put(event);
            for (int i = 0; i < Math.min(99, history.length()); i++) next.put(history.getString(i));
            prefs.edit().putString("decisionEvents", next.toString()).putString("lastDecision", event).apply();
        } catch (org.json.JSONException ignored) {
            prefs.edit().putString("lastDecision", event).apply();
        }
        // This direct event notification supersedes the last routine scan status.
        // Allow the next genuine Offers status to be queued even if its text was
        // identical to the value before this event.
        lastQueuedStatus.set(event);
        writeStatus(event);
        });
    }

    @Override
    public synchronized void onDestroy() {
        monitorReady = false;
        releasePerformanceWakeLock();
        if (worker != null) worker.removeCallbacksAndMessages(null);
        if (fastWorker != null) fastWorker.removeCallbacksAndMessages(null);
        if (idlePresenceWorker != null) idlePresenceWorker.removeCallbacksAndMessages(null);
        if (acceptOutcomeWorker != null) acceptOutcomeWorker.removeCallbacksAndMessages(null);
        if (acceptProofWorker != null) acceptProofWorker.removeCallbacksAndMessages(null);
        if (scanDiagnosticWorker != null) scanDiagnosticWorker.removeCallbacksAndMessages(null);
        if (activeInstance == this) activeInstance = null;
        releaseScreenCapture();
        MediaProjection stopped=projection;
        projection=null;
        if (stopped!=null) stopped.stop();
        if (recognizer != null) recognizer.close();
        synchronized (rejectedRoiLock) {
            rejectedRoiWidth=rejectedRoiHeight=0;
            rejectedRoiPixels = null;
            rejectedRoiOwner = null;
        }
        if (roiPaddedBuffer != null && !roiPaddedBuffer.isRecycled()) roiPaddedBuffer.recycle();
        if (roiExactBuffer != null && roiExactBuffer != roiPaddedBuffer && !roiExactBuffer.isRecycled()) roiExactBuffer.recycle();
        roiPaddedBuffer = null;
        roiExactBuffer = null;
        if (workerThread != null) workerThread.quitSafely();
        if (fastThread != null) fastThread.quitSafely();
        if (idlePresenceThread != null) idlePresenceThread.quitSafely();
        if (acceptClickThread != null) acceptClickThread.quitSafely();
        if (acceptOutcomeThread != null) acceptOutcomeThread.quitSafely();
        if (acceptProofThread != null) acceptProofThread.quitSafely();
        if (rejectConfirmThread != null) rejectConfirmThread.quitSafely();
        if (scanDiagnosticThread != null) scanDiagnosticThread.quitSafely();
        rejectConfirmStates.clear();
        expiredReject.set(null);
        logWriter.shutdownNow();
        super.onDestroy();
    }
}
