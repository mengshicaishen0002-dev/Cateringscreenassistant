# CateringScreenAssistant v2.10.56

Version: 2.10.56 (versionCode 80)
Base: v2.10.55 FastDispatch flat source.

## Changes

1. SAME_GEN_FAST qualified Accept lane
   - Requires complete decision evidence from the exact current Accessibility UI generation.
   - Queries the live Accept/Claim action only.
   - Re-proves the same pay + mileage from the current action's local ancestor before acting.
   - Uses only the current live Accept rectangle and requires it enabled/safe.
   - User thresholds, Pasadena semantics, claim budget, terminal-loss guards and page guards are unchanged.
   - Ineligible offers deliberately fall through to the existing Reject path; Reject behavior is unchanged.

2. FIRST_SEEN diagnostics
   - Records the first complete Accessibility evidence timestamp for an offer identity.
   - Diagnostic only; never participates in action eligibility.
   - Rolls over after an 8-second evidence gap so later re-broadcasts get a fresh baseline.
   - Accept logs now include `FIRST_SEEN首见→dispatch=...ms` when available.
   - Uses the actual accepted gesture-dispatch observation timestamp rather than callback completion time where available.

## Preserved

- General $60 / 10mi rule.
- Pasadena either endpoint semantics and saved Pasadena thresholds.
- Reject state machine and async confirmation behavior.
- Accept geometry guards, claim budget, terminal tracking, UNKNOWN soft terminal, late tail, reappearance handling.
- v2.10.55 Gesture24ms FastDispatch.

## Verification

`bash ./run-regression-tests.sh`

Result: 183 v2.10.56 integration invariants passed, plus all existing Java regression suites.
