# v2.10.54 Accept latency logging audit

- versionCode 78 / versionName 2.10.54
- No Accept/Reject decision, click, geometry, retry, terminal-tracking, Pasadena, or rule logic changed.
- Replaced misleading `<cached source>→dispatch` metric with two explicit fields:
  - `证据来源=<source>`
  - `缓存年龄=<ms>`
- Preserved `画面→dispatch=<ms>` as the current-frame-to-dispatch latency metric.
- Purpose: a cached DecisionEvidence may predate the current frame by hundreds of ms; that age is not local click latency.
