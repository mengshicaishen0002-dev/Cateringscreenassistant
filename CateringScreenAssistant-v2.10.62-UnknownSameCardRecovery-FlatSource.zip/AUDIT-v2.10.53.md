# v2.10.53 Accept UNKNOWN soft-terminal / late-tail audit

- versionCode 77 / versionName 2.10.53
- Foreground ACCEPT_UNKNOWN releases the serial transaction immediately so next offers can scan.
- Adds 3s cached-Accessibility-only late terminal tail; no OCR, no tree walk, no Accept retry.
- Tail stops if a newer Accept transaction begins to avoid cross-attribution.
- Adds ACCEPT_LATE_SUCCESS / ACCEPT_LATE_LOST diagnostic correction logs.
- UNKNOWN complete decision evidence retained for 90s only; current Accept bounds are always required and old geometry is never reused.
- UNKNOWN reappearance can enter existing REAPPEAR_FAST path after current-frame compatibility checks.
- Existing 1100ms foreground terminal tracking, first-click fast paths, Pasadena rule, Reject state machine and terminal-loss suppression preserved.
- Regression result: 171 integration invariants plus all existing Java regression suites passed.
