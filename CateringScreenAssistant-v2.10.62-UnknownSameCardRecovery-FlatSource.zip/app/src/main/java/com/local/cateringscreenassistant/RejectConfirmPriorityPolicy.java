package com.local.cateringscreenassistant;

/**
 * v2.10.60 Reject post-dispatch policy.
 *
 * Background confirmation is cache-only.  There is deliberately no Accessibility tree budget:
 * the safest way to guarantee a new offer never queues behind old Reject diagnostics is to never
 * start that tree call after dispatch.
 */
final class RejectConfirmPriorityPolicy {
    private static final long FINAL_TAIL_MS = 1600L;
    private static final long FINAL_TAIL_POLL_MS = 160L;

    static long finalTailMs() { return FINAL_TAIL_MS; }
    static long finalTailPollMs() { return FINAL_TAIL_POLL_MS; }

    static boolean shouldDeferForNewTop(String rejectedText, String newTopText) {
        return rejectedText != null && !rejectedText.isEmpty()
                && newTopText != null && !newTopText.isEmpty()
                && !CardText.sameOffer(rejectedText, newTopText);
    }

    private RejectConfirmPriorityPolicy() { }
}
