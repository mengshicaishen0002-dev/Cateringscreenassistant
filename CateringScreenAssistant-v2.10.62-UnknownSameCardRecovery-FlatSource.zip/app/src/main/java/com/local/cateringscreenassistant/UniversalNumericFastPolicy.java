package com.local.cateringscreenassistant;

/**
 * Accept-only policy for deciding whether location evidence is mathematically irrelevant.
 * It never authorizes an action by itself; the caller must still own a fresh current Accept
 * rectangle and independently re-prove the current amount/mileage pair.
 */
final class UniversalNumericFastPolicy {
    private UniversalNumericFastPolicy() { }

    static boolean qualifies(float amount, float miles,
                             float generalMinPay, float generalMaxMiles,
                             boolean pasadenaEnabled,
                             float pasadenaMinPay, float pasadenaMaxMiles,
                             boolean hasExplicitCityFilter,
                             boolean hasActiveTimeFilter) {
        if (amount < 0f || miles < 0f || hasExplicitCityFilter || hasActiveTimeFilter) return false;
        if (amount < generalMinPay || miles > generalMaxMiles) return false;
        return !pasadenaEnabled
                || (amount >= pasadenaMinPay && miles <= pasadenaMaxMiles);
    }
}
