# CateringScreenAssistant v2.10.58 — Event Burst + Universal Numeric Fast

## Triggering real-device trace
- $140.40 / 3.0 mi, Brea
- Action index: 15ms
- quick tree: 103ms
- full tree: 228ms
- snapshot→dispatch: 15ms
- FIRST_SEEN→dispatch: 275ms
- terminal: ACCEPT_LOST / server offer unavailable

The current Accept action itself was fast once a complete snapshot existed. The avoidable delay was waiting for location/full-tree evidence even though $140.40/3mi passes both configured ordinary ($60/10mi) and Pasadena ($20/5mi) numeric branches.

## v2.10.58 changes
1. Retains v2.10.57 EVENT_BURST_FAST (180ms event burst, 32ms backstop retry).
2. Adds UNIVERSAL_NUMERIC_FAST before SAME_GEN/quick/full-tree work.
3. The shortcut is Accept-only and can run only when:
   - current semantic Accept/Claim is live, enabled and fresh;
   - current Accept ancestry independently exposes the exact amount + mileage;
   - no explicit city allow-list is configured;
   - no active time filter is configured;
   - the numeric pair passes the ordinary rule; and
   - when Pasadena special is enabled, the same numeric pair ALSO passes Pasadena thresholds.
4. Current live Accept geometry remains authoritative; event evidence never supplies geometry.
5. Event evidence may enrich text/identity only after numeric equality and partial-evidence compatibility.
6. Reject path, Pasadena endpoint semantics, Gesture24ms, claim budget, page/package/generation/geometry guards and terminal tracking are unchanged.

## Expected behavior on the real traces
- $140.40 / 3mi: eligible for UNIVERSAL_NUMERIC_FAST.
- $73.47 / 1.2mi: eligible for UNIVERSAL_NUMERIC_FAST.
- $27 / 1mi Pasadena: NOT eligible for universal numeric shortcut; city evidence is still required, so EVENT_BURST_FAST / existing Pasadena path remains responsible.
- $65 / 8mi with Pasadena enabled: NOT eligible, because it would pass ordinary but fail Pasadena 5mi limit; location must be known.

## Regression
- Added UniversalNumericFastPolicyTest: 7 cases.
- Existing regression suites pass.
- 196 v2.10.58 integration invariants pass.
