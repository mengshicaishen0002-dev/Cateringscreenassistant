package com.local.cateringscreenassistant;

public final class UniversalNumericFastPolicyTest {
    private static void expect(boolean value, boolean expected, String name) {
        if (value != expected) throw new AssertionError(name + " expected=" + expected + " got=" + value);
    }

    public static void main(String[] args) {
        // Real traces: both should be eligible without waiting for city because they pass
        // ordinary $60/10 AND Pasadena $20/5 simultaneously.
        expect(UniversalNumericFastPolicy.qualifies(140.40f, 3f, 60f, 10f,
                true, 20f, 5f, false, false), true, "Brea 140/3");
        expect(UniversalNumericFastPolicy.qualifies(73.47f, 1.2f, 60f, 10f,
                true, 20f, 5f, false, false), true, "Irvine 73/1.2");

        // $65/8 passes ordinary but would fail if the endpoint turns out to be Pasadena.
        expect(UniversalNumericFastPolicy.qualifies(65f, 8f, 60f, 10f,
                true, 20f, 5f, false, false), false, "Pasadena ambiguity");
        // Low Pasadena-only offers still require location evidence.
        expect(UniversalNumericFastPolicy.qualifies(27f, 1f, 60f, 10f,
                true, 20f, 5f, false, false), false, "Pasadena-only amount");
        // Explicit city/time filters always require their evidence.
        expect(UniversalNumericFastPolicy.qualifies(140f, 3f, 60f, 10f,
                true, 20f, 5f, true, false), false, "city filter");
        expect(UniversalNumericFastPolicy.qualifies(140f, 3f, 60f, 10f,
                true, 20f, 5f, false, true), false, "time filter");
        // If Pasadena special is disabled, ordinary thresholds alone are sufficient.
        expect(UniversalNumericFastPolicy.qualifies(65f, 8f, 60f, 10f,
                false, 20f, 5f, false, false), true, "ordinary only");
        System.out.println("7 universal numeric fast policy cases passed");
    }
}
