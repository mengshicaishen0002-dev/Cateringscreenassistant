package com.local.cateringscreenassistant;

public class RejectSequenceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        RejectSequence sequence = new RejectSequence();
        check(sequence.observe("A", 0) == RejectSequence.State.READY);
        check(sequence.reserveIfReady("A", 0) == 1);
        check(sequence.observe("A", 100) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 359) == RejectSequence.State.WAIT);
        // v2.10.61: time alone still never authorizes retry #2, even though the unresolved
        // retry window is shortened to 360ms. Continuous current-card visibility is required.
        check(sequence.observe("A", 360) == RejectSequence.State.WAIT);
        check(sequence.observeVisible("A", 370) == RejectSequence.State.WAIT);
        check(sequence.observeVisible("A", 500) == RejectSequence.State.READY);
        check(sequence.reserveIfReady("A", 500) == 2);
        check(sequence.observe("A", 501) == RejectSequence.State.HOLD);
        check(sequence.markHoldReported("A", 501));
        check(!sequence.markHoldReported("A", 502));

        RejectSequence atomic = new RejectSequence();
        check(atomic.reserveIfReady("RACE", 7000) == 1);
        check(atomic.reserveIfReady("RACE", 7000) == 0);
        atomic.noteVisible("RACE", 7200);
        check(atomic.reserveIfReady("RACE", 7200) == 0); // retry time not reached yet
        atomic.noteVisible("RACE", 7360);
        check(atomic.reserveIfReady("RACE", 7360) == 2);
        check(atomic.reserveIfReady("RACE", 7361) == 0);

        RejectSequence missingBreaksStreak = new RejectSequence();
        check(missingBreaksStreak.reserveIfReady("M", 1000) == 1);
        missingBreaksStreak.noteVisible("M", 2200);
        missingBreaksStreak.noteVisible("M", 2340);
        missingBreaksStreak.noteMissing("M", 2350);
        check(missingBreaksStreak.observe("M", 2351) == RejectSequence.State.WAIT);
        missingBreaksStreak.noteVisible("M", 2400);
        check(missingBreaksStreak.observe("M", 2400) == RejectSequence.State.WAIT);
        missingBreaksStreak.noteVisible("M", 2530);
        check(missingBreaksStreak.observe("M", 2530) == RejectSequence.State.READY);

        RejectSequence processing = new RejectSequence();
        check(processing.reserveIfReady("P", 4000) == 1);
        processing.markProcessing("P", 4200);
        check(processing.observe("P", 5000) == RejectSequence.State.PROCESSING);
        check(processing.observe("P", 11199) == RejectSequence.State.PROCESSING);
        // Once processing hold expires, retry still requires fresh continuous visibility.
        check(processing.observe("P", 11200) == RejectSequence.State.WAIT);
        processing.noteVisible("P", 11210);
        processing.noteVisible("P", 11340);
        check(processing.observe("P", 11340) == RejectSequence.State.READY);
        check(processing.reserveIfReady("P", 11340) == 2);

        RejectSequence disappeared = new RejectSequence();
        check(disappeared.reserveIfReady("D", 10000) == 1);
        disappeared.markDisappeared("D", 10100);
        check(disappeared.observe("D", 10101) == RejectSequence.State.TOMBSTONE);
        check(disappeared.markReappearedReported("D", 10102));
        check(!disappeared.markReappearedReported("D", 10103));
        disappeared.noteVisible("D", 12000);
        check(disappeared.observe("D", 12000) == RejectSequence.State.TOMBSTONE);
        check(disappeared.reserveIfReady("D", 12000) == 0);
        // v2.10.60: departure was independently proven. After tombstone expiry, a real
        // re-publication starts a fresh Reject transaction rather than consuming retry #2.
        disappeared.noteVisible("D", 15110);
        check(disappeared.consumeRearmed("D", 15110));
        check(disappeared.observe("D", 15110) == RejectSequence.State.READY);
        check(disappeared.reserveIfReady("D", 15110) == 1);

        RejectSequence terminal = new RejectSequence();
        check(terminal.reserveIfReady("T", 20000) == 1);
        terminal.markTerminal("T", 20100);
        check(terminal.observe("T", 20101) == RejectSequence.State.TOMBSTONE);
        check(terminal.markReappearedReported("T", 20102));
        check(!terminal.markReappearedReported("T", 20103));
        check(terminal.reserveIfReady("T", 27000) == 0);
        terminal.noteVisible("T", 28110);
        terminal.noteVisible("T", 28240);
        check(terminal.observe("T", 28240) == RejectSequence.State.HOLD);
        check(terminal.reserveIfReady("T", 28240) == 0);

        RejectSequence failed = new RejectSequence();
        check(failed.reserveIfReady("F", 30000) == 1);
        failed.markProcessing("F", 30050);
        failed.failed("F", 30100);
        check(failed.attempts("F", 30100) == 0);
        check(failed.observe("F", 30749) == RejectSequence.State.WAIT);
        check(failed.observe("F", 30750) == RejectSequence.State.READY);

        RejectSequence sent = new RejectSequence();
        check(sent.sent("S", 40000) == 1);
        check(sent.sent("S", 41100) == 0); // no continuous visible proof
        sent.noteVisible("S", 40370);
        sent.noteVisible("S", 40500);
        check(sent.sent("S", 40500) == 2);

        RejectSequence shared1 = RejectSequence.shared();
        RejectSequence shared2 = RejectSequence.shared();
        shared1.forget("SHARED");
        check(shared1.reserveIfReady("SHARED", 50000) == 1);
        check(shared2.observe("SHARED", 50001) == RejectSequence.State.WAIT);
        check(shared2.reserveIfReady("SHARED", 50001) == 0);
        shared2.forget("SHARED");


        RejectSequence rearm = new RejectSequence();
        check(rearm.reserveIfReady("REARM", 70000) == 1);
        rearm.markDisappeared("REARM", 70100); // different coherent top proved departure
        rearm.noteVisible("REARM", 75200);     // tombstone expired; genuine republish
        check(rearm.consumeRearmed("REARM", 75200));
        check(rearm.observe("REARM", 75200) == RejectSequence.State.READY);
        check(rearm.reserveIfReady("REARM", 75200) == 1); // new transaction, not retry #2

        sequence.forget("A");
        check(sequence.observe("A", 60000) == RejectSequence.State.READY);
        System.out.println("59 rejection sequence cases passed");
    }
}
