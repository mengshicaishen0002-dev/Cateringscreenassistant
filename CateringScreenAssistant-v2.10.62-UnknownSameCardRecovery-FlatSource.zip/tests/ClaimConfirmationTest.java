package com.local.cateringscreenassistant;
public class ClaimConfirmationTest {
    static int n;
    static void check(boolean v){n++; if(!v) throw new AssertionError("case "+n);}
    public static void main(String[] args){
        check(ClaimConfirmation.classify(true, PageGuard.Page.OFFERS, false, false)==ClaimConfirmation.Result.PENDING);
        check(ClaimConfirmation.classify(false, PageGuard.Page.JOBS, false, false)==ClaimConfirmation.Result.DISAPPEARED_UNKNOWN);
        check(ClaimConfirmation.classify(false, PageGuard.Page.OFFERS, true, false)==ClaimConfirmation.Result.CONFIRMED);
        check(ClaimConfirmation.classify(false, PageGuard.Page.OFFERS, false, true)==ClaimConfirmation.Result.TERMINAL_LOST);
        check(ClaimConfirmation.classify(true, PageGuard.Page.OFFERS, false, true)==ClaimConfirmation.Result.PENDING);
        check(ClaimConfirmation.classify(false, PageGuard.Page.OFFERS, false, false)==ClaimConfirmation.Result.DISAPPEARED_UNKNOWN);
        check(ClaimConfirmation.classify(false, PageGuard.Page.UNKNOWN, false, false)==ClaimConfirmation.Result.DISAPPEARED_UNKNOWN);
        System.out.println(n+" claim-confirmation cases passed");
    }
}
