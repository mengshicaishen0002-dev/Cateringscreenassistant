package com.local.cateringscreenassistant;
public class ClaimSuccessSignalsTest {
    static int n;
    static void check(boolean v){n++; if(!v) throw new AssertionError("case "+n);}
    public static void main(String[] args){
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Dropoff Instructions: call when arrive Delivery Timeline"));
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Pickup Instructions: Approver Name: Julie Rivera NUID: K100435 GL String: 0806811874910"));
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Pickup Instructions NUID: K100435 GL String: 0806811874910"));
        check(!ClaimSuccessSignals.hasAcceptedJobDetail("Pickup Instructions: ask restaurant for order"));
        check(!ClaimSuccessSignals.hasAcceptedJobDetail("Pickup Instructions Approver Name: Julie Rivera"));
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Begin Delivery Delivery Timeline MENDO_46474511540436997"));
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Delivery Timeline MENDO_46498930040553475"));
        check(!ClaimSuccessSignals.hasAcceptedJobDetail("Est. $61.31 7.6 mi MENDO_46498930040553475"));
        check(!ClaimSuccessSignals.hasAcceptedJobDetail("Begin Delivery tomorrow at 10:30 AM"));
        check(ClaimSuccessSignals.isPositive(ClaimSuccessSignals.extractOutcomeHint("Delivery Timeline Dropoff Instructions")));
        check(ClaimSuccessSignals.isPositive(ClaimSuccessSignals.extractOutcomeHint("Delivery Timeline MENDO_46498930040553475")));
        check(ClaimSuccessSignals.isPositive(ClaimSuccessSignals.extractOutcomeHint("Begin Delivery Delivery Timeline MENDO_46474511540436997")));
        String offer = "$30.32 Est. 5.8 mi Tomorrow at 11:10 AM Rubio's Coastal Grill • Norco, CA";
        String job = "$30.32 Est. 5.8 mi Tomorrow at 11:10 AM olo_46593764798644225 Delivery Timeline Pickup Rubio's Coastal Grill";
        check(ClaimSuccessSignals.acceptedJobMatchesOffer(offer, job));
        check(!ClaimSuccessSignals.acceptedJobMatchesOffer("$31.00 Est. 5.8 mi Tomorrow at 11:10 AM Other", job));
        check(ClaimSuccessSignals.jobsBadgeCount("Deliveries Jobs 1 Offers") == 1);
        check(ClaimSuccessSignals.jobsBadgeCount("Deliveries Jobs Offers No offers available") == 0);
        check(ClaimSuccessSignals.jobsBadgeCount("Offers No offers available") == -1);
        check(ClaimSuccessSignals.jobsBadgeIncreased(0,1));
        check(ClaimSuccessSignals.jobsBadgeIncreased(1,2));
        check(ClaimSuccessSignals.jobsBadgeIncreased(2,3));
        check(!ClaimSuccessSignals.jobsBadgeIncreased(1,1));
        check(!ClaimSuccessSignals.jobsBadgeIncreased(2,1));
        check(!ClaimSuccessSignals.jobsBadgeIncreased(-1,1));
        System.out.println(n+" claim-success-signal cases passed");
    }
}
