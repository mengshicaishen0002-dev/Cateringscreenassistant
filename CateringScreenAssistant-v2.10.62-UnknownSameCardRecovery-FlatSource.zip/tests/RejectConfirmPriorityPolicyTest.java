package com.local.cateringscreenassistant;

public final class RejectConfirmPriorityPolicyTest {
    private static int tests;
    private static void check(boolean condition, String message) { tests++; if (!condition) throw new AssertionError(message); }
    public static void main(String[] args) {
        check(RejectConfirmPriorityPolicy.finalTailMs() == 1600L, "final tail");
        check(RejectConfirmPriorityPolicy.finalTailPollMs() == 160L, "tail poll");
        String oldOffer = "$29–39 Est. 2.1 mi Tomorrow at 10:15 AM Mendocino Farms • Huntington Beach, CA";
        String sameOffer = "$29-39 2.1 mi Tomorrow at 10:15 AM Mendocino Farms Huntington Beach CA";
        String newOffer = "$66.67 Est. 1.8 mi Tomorrow at 10:00 AM Mendocino Farms • El Segundo, CA";
        check(!RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldOffer, sameOffer), "same offer");
        check(RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldOffer, newOffer), "new offer");
        check(!RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldOffer, ""), "blank top");
        System.out.println(tests + " reject-confirm cache-only priority cases passed");
    }
}
