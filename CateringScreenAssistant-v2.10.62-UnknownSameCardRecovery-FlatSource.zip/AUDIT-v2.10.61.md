# v2.10.61 audit

Targeted fix for the 2026-09-15 live Reject trace where the same visible ineligible card waited about 30 seconds before attempt #2.

## Unresolved Reject retry
- Retry #2 eligibility window is 360ms instead of 1100ms, but time alone is still insufficient.
- The current card must remain continuously visible and the current explicit Reject target must be re-proven.
- Fast Accessibility decision paths now record coherent current-card visibility before reading RejectSequence state; previously WAIT could suppress OCR without ever accumulating the visibility samples needed to become READY.
- After a Reject dispatch, bounded fast-lane wakeups at 280/400/560ms prevent a quiet React-Native screen from waiting for a later content event.
- If a newer Accessibility event is already queued, the old Reject wakeup yields so a new card keeps priority.

## Background isolation preserved
- No Reject background Accessibility tree probe was restored.
- Background final tail remains cache-only.
- Two-attempt ceiling, explicit current Reject geometry, tombstones, terminal handling, and rearm semantics remain unchanged.

## ETA OCR noise
- The observed `(-9 mins)` is display OCR noise and is not used by the pay/mileage eligibility rule; core card identity parsing was intentionally not weakened to rewrite it.
