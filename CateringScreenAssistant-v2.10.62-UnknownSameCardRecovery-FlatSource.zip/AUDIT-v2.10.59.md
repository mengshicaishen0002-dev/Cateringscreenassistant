# CateringScreenAssistant v2.10.59 — BackFirst / StableFirstSeen / RejectFinalTail

## Field issues addressed
- Confirmed claim screen (Begin Delivery / Delivery Timeline): navigation now performs Back first, then searches for Offers.
- FIRST_SEEN false reset: React-Native identity enrichment (amount/miles -> time/merchant/address) no longer restarts the diagnostic baseline. The earliest numeric-pair sighting is preserved across the 8s enrichment burst.
- FIRST_SEEN→dispatch 4603ms: urgent fast check is queued before the synchronous event-source ancestor climb; stale queued work yields before quick/full-tree fallback when a newer Accessibility event is already waiting.
- Reject confirmation: background probe budget reduced to 45ms/48 nodes and yields for 220ms after foreground offer demand. REJECT_CONFIRM_DEFERRED now starts a server-signal-only final tail; it performs no further Accessibility tree scans and cannot own the foreground action lane.

## Preserved safety/decision behavior
- General/Pasadena thresholds and either-end Pasadena semantics unchanged.
- Accept current-card numeric proof, current live Accept geometry, package/page/generation gates, claim budget, terminal handling and Gesture24ms unchanged.
- Reject action semantics/retry gate unchanged; only post-action diagnostic priority/finalization changed.
- No blind Accept retry and no cached action geometry reuse.

## Regression
- Pure Java regression suites pass.
- 210 v2.10.59 integration invariants pass.
