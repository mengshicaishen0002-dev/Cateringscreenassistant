# v2.10.62 — UNKNOWN Same-Card Recovery

Real-device trigger: a qualified offer dispatched Accept, disappeared during the short terminal-tracking window, was classified ACCEPT_UNKNOWN, but the same offer later remained/reappeared on Offers. v2.10.61 intentionally made the post-UNKNOWN tail observation-only, so a transient React-Native disappearance could leave an actionable offer behind.

Changes:
- ACCEPT_UNKNOWN still releases the foreground immediately so a genuinely new top card is never blocked.
- The late tail is extended to 6s and now performs a cheap semantic Accept-index check; no OCR and no full-tree scan are added.
- A retry is authorized only when the CURRENT enabled Accept geometry belongs to evidence compatible with the same prior offer, the full old decision fields still pass the current rules, there is no terminal-loss suppression, and the bounded ClaimBudget has capacity.
- Old Accept geometry is never reused.
- UNKNOWN no longer clears ClaimBudget. Same unresolved offer therefore continues as attempt #2/#3 instead of resetting to attempt #1 indefinitely.
- Positive Jobs/detail evidence and explicit terminal-negative evidence still win before any recovery retry.
- Existing Pasadena semantics, Reject no-tree path, Gesture24ms first attempt, success arbitration, FIRST_SEEN instrumentation, and new-card foreground priority are unchanged.
