# CateringScreenAssistant v2.10.57 — Event-Burst Fast Path

## Trigger from live v2.10.56 logs
- Irvine $73.47/1.2mi: FIRST_SEEN→dispatch 606ms; current-frame→dispatch 103ms.
- Pasadena $27–37/1.0mi: FIRST_SEEN→dispatch 589ms; current-frame→dispatch 43ms.
- SAME_GEN_FAST did not hit either real offer because React-Native exported the card across multiple Accessibility generations.

## Changes
1. EVENT_BURST_FAST: current semantic Accept geometry remains mandatory. Cross-generation event evidence may contribute decision fields only when the current Accept ancestry independently re-proves the exact amount+mileage and compatibility. Final merged evidence must pass the existing location/time completeness and user-rule gates.
2. EVENT_BURST_WAIT: during the first 180ms after first numeric Accessibility sighting, an incomplete event no longer immediately enters the expensive quick/full-tree lane. New events rerun immediately; a 32ms delayed retry is only a backstop. After 180ms the old fallback path resumes unchanged.
3. No Reject behavior, thresholds, Pasadena semantics, Gesture24ms, claim budget, terminal tracking, page/package checks, or geometry guards were weakened.

## Expected live markers
- EVENT_BURST_FAST；跨代字段+当前Accept直达
- EVENT_BURST_WAIT ...
- FIRST_SEEN首见→dispatch=...ms

Target: reduce the ~500ms pre-frame/event-coalescing delay seen in v2.10.56 while preserving current-action proof.
