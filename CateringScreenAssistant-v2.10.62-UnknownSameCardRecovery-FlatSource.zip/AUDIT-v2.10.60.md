# v2.10.60 audit

Targeted fixes from 2026-09-15 live traces.

## Accept success arbitration
- `Assigned Job ID/Delivery Timeline` and `Begin Delivery/assigned Job` are now positive hints.
- Job-detail positives are transaction-bound using amount + miles + pickup time (`CardText.completionKey`).
- A matched accepted-job detail outranks a later `offer unavailable` hint for the same active Accept.
- Merely landing on the Jobs page is no longer sufficient to confirm success.
- OCR job-detail surfaces are never re-parsed as offer cards while an Accept is pending.
- Confirmed success keeps the v2.10.59 navigation order: Back first, then find Offers.

## Reject post-dispatch isolation
- Removed the active background Reject Accessibility tree-probe path entirely.
- After Reject dispatch, the background tail is cache-only for 1.6s.
- A different coherent foreground top proves departure and cancels the old tail, preventing cross-card terminal attribution.
- Therefore old Reject diagnostics cannot make a new card wait on a slow Accessibility tree call.

## Reject genuine reappearance
- A different coherent top marks departure as independently proven.
- After the tombstone expires, the same offer may rearm as a new Reject transaction (`REJECT_REARMED`) rather than consuming retry #2.
- Strong terminal Reject outcomes remain non-rearmable.

## Preserved
- General/Pasadena rule semantics and endpoint Pasadena matching.
- Gesture24ms first Accept.
- FIRST_SEEN stable earliest timestamp logic.
- Event-burst / universal numeric fast lanes.
- Current live button geometry and package/page guards.
- No blind Accept retries.

## Verification
- Pure Java regression suites pass.
- 216 v2.10.60 integration invariants pass.
