# v2.10.30

- Action chain only: reuse already-validated fresh snapshot/root evidence before the first action; no threshold changes.
- Reject confirmation moved off the fast action lane to a dedicated background confirmer; next top offer can be evaluated immediately while the old Reject is confirmed.
- Pasadena protection: the special rule requires a parsed pickup address/city of Pasadena, not a bare text match. Decision logs show `RULE=PASADENA` or `RULE=GENERAL` with a reason.

## v2.10.29

Reject Fast-Exit release. Rule values and rule semantics are unchanged. When the indexed Accept path has already identified a complete ineligible top card, the monitor now searches only the same card's local action-row ancestors for the left Reject control before any 180-node quick-tree/full-tree fallback. Reject ACTION_CLICK also first follows only nodes intersecting the already-verified fresh Reject rectangle, avoiding a second ~140-node semantic walk when React-Native exposes a blank-label action node. Existing same-offer numeric verification, side-specific geometry, top-card serial lock, continuous monitoring, post-claim isolation and Jobs badge 1→2→3 success tracking remain intact.

## v2.10.28

Continuous-claim hardening + blank-label first-shot optimization. A confirmed or manual claim now invalidates every older OCR frame and quarantines only the assigned-job detail surface; monitoring remains alive and automatically resumes on the next verified Offers card. Jobs badge increases are tracked cumulatively (0→1→2→3...) as strong success evidence. Accepted-job details containing Pickup/Dropoff Instructions plus job-only approval metadata can no longer become synthetic offers. For blank-label Accept buttons, a fresh screen blue-button rectangle may be fused with same-generation Accessibility pay/miles/city/time evidence so the first Gesture55ms can be sent before ML Kit finishes; all configured rule values and rule semantics remain unchanged. OCR mileage drift such as 0.7→7 is corrected only when an independent same-offer Accessibility representation matches pay/time/merchant.

## v2.10.26

Latency Pipeline release. Keeps the 80 ms scan profile and the Galaxy A15-proven 55 ms first Accept gesture. Accessibility snapshots now cache pay, miles and stable identity once; a complete rule decision plus the correct side-specific action anchor owns the frame so OCR only runs for missing evidence. After Accept is observed disabled/processing, confirmation becomes event-first and full-tree rechecks are throttled to one per 520 ms quiet window instead of rebuilding the React-Native hierarchy every ~95 ms. The action log also reports snapshot-to-dispatch latency. Existing top-card serial locking, live numeric matching, page guards, Reject transaction separation and terminal ACCEPT_LOST behavior remain intact.

## v2.10.25
September 10 field hardening: the previous APK labeled v2.10.24 was discovered to be byte-for-byte identical to v2.10.23 because the temporary short-name ZIP did not replace the workflow's hard-coded `CateringScreenAssistant-v2.8.0-project.zip`. This release carries forward the v2.10.24 Reject/Accept split and adds an explicit pending-transaction fast-lane gate, in-flight Accessibility race rechecks, action-specific `offer unavailable` handling (`ACCEPT_LOST` vs `REJECT_SUCCESS/REJECT_UNKNOWN`), and a visible v2.10.25 banner.

## v2.10.22

## v2.10.24

- Split Accept and Reject post-action state machines.
- Reject disappearance is confirmed independently and never checks Jobs/claim-success evidence.
- Two consecutive missing reads prevent transient blank frames from falsely confirming a reject.
- `REJECT_SUCCESS` requires prior disabled/processing acknowledgement; otherwise the result is `REJECT_UNKNOWN`.

- Latency-first semantic Accept/Claim index path: qualified offers can bypass the ~130-node quick-tree walk.
- Indexed Ignore/Decline/Reject fallback for the same physical top card.
- Qualified-offer notification is queued after the claim action, never before it.
- Fresh Accessibility Accept snapshots skip redundant page-chrome rewalks; stale snapshots still revalidate.
- OCR Accept uses front-of-main-queue dispatch and recent OFFERS hints to avoid needless pre-tap work.
- Regex-heavy per-node button/page normalization replaced with allocation-light character scanning.
- Keeps the proven 55 ms Samsung-safe press duration.

## v2.10.21

- Fixes the real-device 11:26:33 double-Reject race where OCR and Accessibility treated one calendar-date offer as different card IDs.
- Canonicalizes `September 11 at 10:45 AM`-style pickup times and merchant identity across OCR/tree spacing differences.
- Makes Reject READY-check + attempt reservation atomic across worker threads.
- Immediately requests a coalesced rescue scan when OCR has amount+miles but no reliable action-row anchor.

## v2.10.20
- Fix duplicate Reject: once a live post-click read proves Reject is disabled/processing, the shared OCR + Accessibility arbiter enters a 7-second PROCESSING gate instead of firing attempt #2 about one second later.
- If that processing state really rolls back and the same card remains, the gate reopens after the bounded hold so recovery is still possible.
- Reject retries may no longer reuse an inferred/mirrored left coordinate; a retry must regain an explicit Accessibility/OCR Reject target.
- Faster first-card tree path: page evidence is collected in the same bounded walk, duplicate per-piece regex normalization is removed, and the walk stops once money + miles + California address + a safe action node are all present.
- Card text now suppresses repeated parent/child Accessibility phrases, reducing duplicated merchant/address logs and identity work.

## v2.10.19
- Fix silent-miss path: a stale Jobs/Ignored Accessibility tab hint no longer suppresses MediaProjection OCR while DeliverThat is foreground.
- Strong current offer evidence (money + miles + Accept/Reject/blue Accept) can override a conflicting stale tab hint.
- Quick page scan no longer stops at the first stale forbidden-tab bit; final action still requires numeric + safe button geometry.
- Blue Accept + raw OCR numeric miss now triggers enhanced OCR instead of silently skipping the frame.

## v2.10.18
- Galaxy A15 first-card low-latency path: bounded active-window scan before full tree; avoids duplicate active-window traversal.
- Rule-sensitive completeness guard: Pasadena/city/time decisions fall back when quick text is incomplete.
- Timing diagnostics show quick-tree vs full-tree latency.


## v2.10.17

- Galaxy A15 field fix for Ignore gestures that Android reported as completed while DeliverThat left the card unchanged.
- Reject now prefers a live verified Accessibility `ACTION_CLICK`; if the same offer remains with Reject enabled after 160 ms, it falls back to a 90 ms gesture inside freshly re-read button bounds.
- `ACTION_CLICK` + gesture fallback is one logical Reject attempt and shares the existing two-attempt/1100 ms budget.
- Blank-label React-Native action nodes are allowed only near the already verified left button and must pass amount+miles plus anti-card-container geometry checks.
- Reject logs now distinguish semantic click, semantic-no-change fallback, and gesture-only fallback.
- Accept path remains unchanged to preserve the current low-latency claim path.

## v2.10.16

- Fixes Galaxy A15 recordings where a clearly ineligible DeliverThat offer remained visible and Ignore never took effect.
- Reject/Ignore now uses a 55 ms full press on every dispatch path (Accessibility fast, OCR coordinate, and verified fallback), matching the duration already proven necessary for DeliverThat Accept.
- Accessibility-only mode no longer rejects a structurally valid offer merely because the React-Native Offers page classifier is UNKNOWN; explicit Jobs/Ignored still block actions.
- Reject logs now include source, rect, tap coordinates, and gesture duration so a failed real-device action can be distinguished from a correct server-side transition.
- Keeps the shared two-attempt Reject arbiter, first-card serial lock, anti-card-container geometry, and v2.10.14 Accept fast path.

## v2.10.14

- Optimizes the real-device `$113.73 / 7.2 mi` `offer unavailable` trace: the claim reached DeliverThat, but a stale serial transition delayed the first submit.
- A different top card can now be confirmed in the same frame by OCR + bounded Accessibility amount/mileage consensus; otherwise an urgent next-frame probe bypasses normal cooldown/scan cadence.
- Removes the second full Accessibility hierarchy traversal when the first WindowScan already produced `cards.get(0)`.
- Server-terminal outcomes such as `offer unavailable` / `already claimed` immediately terminate local retries for that offer and stop consuming the fast worker with repeated full-tree polls.
- Reject retry is throttled to at most two attempts with 1100 ms spacing; Accept remains the latency-priority path.
- Retains strict first-card isolation, action-geometry guards and positive success confirmation.

## v2.10.13

- Fixes the field stall where a visible first offer could remain on screen indefinitely after a previous Accept/Ignore transaction.
- Cooldown/action-hold no longer starves capture completely: a bounded rescue OCR probe may run every 320 ms after the old action has aged at least 420 ms.
- A stale serial lock is retired only after two stable first-card OCR observations; one mixed transition frame cannot unlock the queue.
- Retiring a stale lock now also invalidates pending `inspectClaim()` callbacks via an atomic claim epoch and clears old cooldown/action-hold gates, preventing an old callback from re-locking a new top offer.
- If the same top offer remains visible beyond the hard wait, only transient timing gates are released; offer identity and retry budgets stay intact to avoid repeat-click spam.
- Adds explicit `ACTION_STALL_RECOVERY` diagnostics so future field logs show when stale serial/cooldown/hold state was repaired.

## v2.10.12

- First qualified Accept no longer spends time on semantic `ACTION_CLICK`; it goes straight to the already verified 55 ms button gesture.
- Fixes wasted retry budget: while Accept is disabled/processing, the monitor waits without consuming attempts #2/#3; a retry is reserved only after the same button becomes enabled again.
- Fixes one-frame serial-lock lag: because OCR is restricted to the first-card action ROI, a newly anchored different top card retires the stale serial lock and is evaluated in the same frame instead of waiting for another scan.
- Captures recent DeliverThat accessibility event/root outcome text such as accepted/assigned, unavailable/already claimed, or retry/error hints and includes it in claim diagnostics.
- Preserves strict top-card isolation, left/right action geometry guards, stable offer identity, and positive-success confirmation.

## v2.10.11

- Accept now prefers a real safe Accessibility `ACTION_CLICK` on the verified top-card Accept node.
- If that semantic click returns true but the same enabled Accept is still visible 85 ms later, the app falls back to a 55 ms verified button press.
- Retry #2 reacquires the top button and uses a 55 ms center press; retry #3 uses a 65 ms alternate interior point.
- OCR/visual Accept fallback also uses a 55 ms press and logs button rect/tap coordinates.
- Offer identity is stabilized to pay + miles + pickup time + merchant key, reducing duplicate processing when DeliverThat duplicates accessibility text.
- Gesture completion still does not count as a successful claim; positive Jobs/accepted-assigned evidence remains required.

## v2.10.9

- Qualified first taps are no longer cancelled just because the original Accessibility button snapshot exceeded 380/420 ms. Snapshots up to 2200 ms get a bounded active-window revalidation of exact pay + mileage + current button geometry, then dispatch immediately if still the same top card.
- Fast Ignore no longer performs a second full `findOffer()` tree walk before its first click.
- Accessibility action work is prioritized over OCR; new OCR frames pause briefly while an action is in flight.
- Reuses ROI bitmaps to reduce allocation/GC spikes and warms ML Kit at monitor startup.
- Retains v2.10.8 anti-card-container guards and v2.10.5 positive acceptance confirmation.

## v2.10.8
- Fixes the field failure where an ineligible offer opened its detail page instead of pressing Ignore.
- Never replaces a semantic Ignore/Accept label with a larger clickable card ancestor.
- Adds hard left/right button-geometry guards to Accessibility, OCR, fast-tap, retry and semantic-fallback paths.
- Whole-card/full-row/detail-arrow targets are rejected; fallback parent climbing may not escape into the card container.
- Keeps strict first-card serial processing and the v2.10.6 ~80 ms low-latency scan profile.

## v2.10.6
- Galaxy A15 low-latency profile: 80 ms default scan interval (70–100 ms recommended).
- Direct first-card ImageReader-row copy; no full-screen bitmap allocation before OCR.
- First-card OCR ROI tightened to 20–58% screen height.
- Smaller pre-tap Accessibility page probes and 14 ms first-tap gesture.
- ML Kit starts before the visual Accept scan; blue-button pixels are bulk-read into a reusable buffer.
- Split ROI-copy/OCR/total timing diagnostics for real-device tuning.

## v2.10.4
Real-device DeliverThat action fix: gesture-first button execution, strict first-card lock, structural button bounds, no timeout unlock during Ignore/Decline transition.

## v2.10.3
Strict top-card serial queue: process first card → wait for disappearance/countdown → rescan next card.

## v2.10.2 qualified-order alert

Qualifying offers now trigger a high-priority notification, sound and vibration as soon as all active rules pass, before any Accept click is attempted. The alert shows pay, miles and $/mi and is de-duplicated per offer for 10 minutes. This keeps the human driver informed even if DeliverThat ignores an automated tap.

# Catering Screen Assistant v2.10.2


## v2.10.2

- Fixes the two field failures observed on Galaxy A15: `OCR/视觉证据已超过1秒` and `屏幕坐标在点击前已过期`.
- OCR/visual coordinate actions now use a dedicated 2.2 s action-evidence window; the normal OCR-result freshness guard remains tighter.
- Removes the expensive second full multi-window Accessibility traversal immediately before a coordinate gesture.
- Adds a bounded 90-node active-root page probe plus a short-lived page hint; positive JOBS/IGNORED still blocks the action.
- Reduces the background full-tree heartbeat from 90 ms to 900 ms because real device traces showed one tree walk taking 394-785 ms. Accessibility content-change events remain immediate.
- Adds action-age diagnostics to inferred Reject logs.

## v2.10.0
- Accessibility scans all DeliverThat interactive windows and no longer prunes descendants under invisible WebView/Compose containers.
- Reject OCR/visual coordinates can dispatch a fresh verified gesture when DeliverThat does not expose a Reject Accessibility node.
- Accept/Reject can be paired from the two-button row geometry when one label is missing.
- Enhanced OCR is skipped when a usable action-row anchor already exists, reducing avoidable latency.


Primary path: Android Accessibility control-tree parsing and action. Button text is optional; blank clickable nodes can be paired structurally with the offer card. OCR remains fallback only.

Android / Samsung local offer-screen assistant for DeliverThat.

Core architecture:
- Dedicated 90 ms Accessibility fast path (event-driven + heartbeat)
- ML Kit OCR on a separate worker as a true fallback
- Fresh-screen verification before every action
- Strict serial queue: only the first visible offer card may be accepted/rejected; lower cards wait until they move to the top
- Ordinary + Pasadena rule sets
- Persistent decision history
- Fixed local signing key for v2.9+ in-place upgrades

See `AUDIT-v2.9.md` for the v2.8 miss analysis and all v2.9 fixes.

Galaxy A15 suggested OCR interval: 70–100 ms. Accessibility fast path does not wait for this interval.
## v2.10.5
- First Accept uses a fresh top-card hot-zone snapshot to cut pre-tap tree-walk latency.
- A vanished Offers card is no longer reported as a successful claim.
- Positive claim confirmation requires Jobs/accepted-assigned UI evidence.
- OCR is restricted to the first-card screen region to reduce latency and preserve strict serial processing.


## v2.10.7
- Fast Ignore/Reject now uses the already-isolated first-card Accessibility rectangle instead of immediately rescanning the full tree.
- Action revalidation tolerates DeliverThat React-Native duplicate/missing descriptive nodes, while still requiring exact amount and miles.
- General verified gesture duration reduced to 18 ms; fast top-card gestures remain 14 ms.


## v2.10.15
Reject/Ignore now uses one process-wide two-attempt arbiter across OCR and Accessibility. Same-card retry state survives transient serial-lock recovery, disabled buttons are not re-clicked, and two unconfirmed attempts end in `REJECT_NOT_CONFIRMED` instead of repeated taps.

## v2.10.23
First real Accept field trace showed that v2.10.22 could successfully claim a job but fail to recognize the resulting assigned-job UI, causing expensive post-claim rescans and stale retries. v2.10.23 adds Delivery Timeline/Dropoff Instructions success evidence, Jobs badge increase confirmation, and a single-owner pending Accept state so only inspectClaim can retry.


## v2.10.31
Accept state-machine hardening: global task epoch invalidation after success, semantic card fingerprint regression coverage, completed-offer stale callback guard, indexed-action/event-evidence direct Accept lane, duplicate OCR suppression, and clearer Reject/Pasadena audit labels. Rule thresholds are unchanged.



## v2.10.33

- Reject OCR / Accessibility now share one process-wide transaction through `RejectSequence`; duplicate frames cannot create a new first attempt.
- Retry #2 requires a fresh continuous-visible streak of the same semantic card after retry grace; one late duplicate frame is insufficient.
- `REJECT_DISAPPEARED` creates a 5s tombstone; `REJECT_CONFIRMED` / `REJECT_LOST` create an 8s tombstone. Same-card RN reappearance is suppressed and logged once as `REJECT_REAPPEARED`.
- Background Reject confirmation records visible/missing observations into the same transaction, so transient blank frames break retry continuity instead of racing a second source.
- Keeps v2.10.31 Accept epoch/fingerprint and v2.10.32 Reject direct-dispatch behavior unchanged. Rule thresholds are unchanged.

## v2.10.32
- Reject dispatch reuses the already-proven action rectangle and first asks Android's semantic text index for the matching live Ignore/Decline/Reject node.
- A same-physical-button match is required before ACTION_CLICK; no rule threshold or card identity semantics changed.
- If the label is blank or the index is transiently unavailable, the existing rectangle-pruned lookup and bounded semantic probe remain fallbacks.
- v2.10.31 Accept epoch/fingerprint protections, async Reject confirmation and Pasadena pickup-city protection are unchanged.
