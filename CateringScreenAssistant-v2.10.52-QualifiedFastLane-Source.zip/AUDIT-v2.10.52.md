# CateringScreenAssistant v2.10.52 audit

Targeted from v2.10.51 live traces on 2026-09-14. No threshold, Pasadena, Accept/Reject geometry, or terminal-loss semantics were relaxed.

## Changes

1. **Qualified partial quorum before full-tree/OCR**
   - Current semantic Accept index remains authoritative for the action rectangle.
   - Current bounded quick-tree evidence and a <=260 ms cross-generation decision cache may jointly supply missing card ancestry.
   - Current indexed/quick fragments must be mutually compatible; any present money/mileage conflict aborts fusion.
   - The cached authoritative text must still pass the unchanged amount+miles+location/time completeness gate and configured business rules.
   - New timing marker: `PARTIAL_QUORUM；OCR/完整树跳过`.

2. **Reappearance fast lane**
   - Complete decision text is retained for terminal-lost offers.
   - Reuse is allowed only after v2.10.47 departure proof exists and current indexed/quick evidence is compatible.
   - Current Accept geometry is always freshly acquired; old button geometry is never reused.
   - New timing marker: `REAPPEAR_FAST；OCR/完整树跳过`.

3. **No heavy rescue OCR during an owned Accept transaction**
   - While Accept is processing/missing, or during the first 4.5 s of the transaction, watchdog rescue OCR is suppressed.
   - The existing Accessibility confirmation/terminal tracking lane remains authoritative and never blindly re-Accepts.
   - Long-stall recovery remains available after the bounded confirmation period.

## Preserved invariants
- General rule and user preferences unchanged.
- Pasadena matches either endpoint city and thresholds unchanged.
- Reject action targeting/state machine unchanged.
- Accept action geometry/revalidation unchanged.
- Server `offer unavailable` remains `ACCEPT_LOST`.
- 90-second stale-loss guard and proven-reappearance rearm preserved.
- 1100 ms terminal tracking and deep terminal probes preserved.

## Regression
`run-regression-tests.sh`: all unit/regression suites passed; 164 v2.10.52 integration invariants passed.
