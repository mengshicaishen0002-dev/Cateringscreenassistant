package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pasadena special-rule guard.
 *
 * v2.10.44 semantics: an offer is Pasadena-special when EITHER endpoint is Pasadena.
 * We therefore inspect every city/state/ZIP segment exposed by the offer text instead of only
 * treating the first parsed city as pickup.  OCR may omit the address/state/ZIP entirely while
 * still exposing Pasadena as its own route/map line; an exact standalone Pasadena line is allowed
 * as a conservative fallback.  Merchant names such as "Pasadena Cafe" do not match that fallback.
 */
final class PasadenaRuleGuard {
    private PasadenaRuleGuard() { }

    private static final Pattern OFFER_TIME = Pattern.compile(
            "\\b(?:today|tomorrow|january|february|march|april|may|june|july|august|september|october|november|december)"
                    + "(?:\\s+\\d{1,2})?\\s*(?:at)?\\s*\\d{1,2}:\\d{2}\\s*(?:am|pm)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern CITY_CA_ZIP = Pattern.compile(
            "([^,\\n•]{2,48}),\\s*(?:CA|California)\\s+(\\d{5})(?:-\\d{4})?\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PASADENA_CA_ZIP_NO_COMMA = Pattern.compile(
            "\\bPasadena\\s+(?:CA|California)\\s+\\d{5}(?:-\\d{4})?\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern STANDALONE_PASADENA_LINE = Pattern.compile(
            "(?im)^\\s*Pasadena\\s*$");

    /** Backward-compatible first parsed endpoint city, used only for legacy logging. */
    static String pickupCity(String cardText) {
        List<String> cities = endpointCities(cardText);
        return cities.isEmpty() ? "" : cities.get(0);
    }

    /** All reliably parsed endpoint cities in display order. */
    static List<String> endpointCities(String cardText) {
        ArrayList<String> out = new ArrayList<>();
        if (cardText == null || cardText.trim().isEmpty()) return out;

        String normalized = cardText.replace('•', ' ').replaceAll("[\\r\\n]+", " ")
                .replaceAll("\\s+", " ").trim();
        int start = 0;
        Matcher tm = OFFER_TIME.matcher(normalized);
        if (tm.find()) start = tm.end();
        String tail = normalized.substring(Math.min(start, normalized.length()));

        Set<String> dedupe = new LinkedHashSet<>();
        Matcher city = CITY_CA_ZIP.matcher(tail);
        while (city.find()) {
            String clean = cleanCity(city.group(1));
            if (!clean.isEmpty()) dedupe.add(clean);
        }
        // OCR sometimes drops the comma before CA. Preserve the exact Pasadena+CA+ZIP shape.
        if (PASADENA_CA_ZIP_NO_COMMA.matcher(tail).find()) dedupe.add("Pasadena");
        out.addAll(dedupe);
        return out;
    }

    /**
     * True when pickup OR drop-off/route endpoint is Pasadena.
     * Exact standalone Pasadena OCR line is a fallback for sparse route/map OCR.
     */
    static boolean isPasadenaOffer(String cardText) {
        List<String> cities = endpointCities(cardText);
        for (String city : cities) {
            if ("pasadena".equals(city.toLowerCase(Locale.US))) return true;
        }
        // A standalone OCR/map line is only a fallback when no explicit endpoint city
        // could be parsed. If Encino/Rancho/etc. is already explicit, an unrelated map
        // label saying Pasadena must not override that stronger evidence.
        return cities.isEmpty() && cardText != null
                && STANDALONE_PASADENA_LINE.matcher(cardText).find();
    }

    /** Kept for source compatibility; semantics are now offer-wide rather than pickup-only. */
    static boolean isPasadenaPickup(String cardText) {
        return isPasadenaOffer(cardText);
    }

    static String parsedCitiesForLog(String cardText) {
        List<String> cities = endpointCities(cardText);
        if (!cities.isEmpty()) return String.join(" | ", cities);
        if (cardText != null && STANDALONE_PASADENA_LINE.matcher(cardText).find())
            return "Pasadena(OCR_ROUTE)";
        return "";
    }

    static String auditTag(String cardText, boolean specialEnabled) {
        if (!specialEnabled) return "RULE=GENERAL; PASADENA_DISABLED";
        List<String> cities = endpointCities(cardText);
        for (String city : cities) {
            if ("pasadena".equals(city.toLowerCase(Locale.US)))
                return "RULE=PASADENA; PASADENA_MATCH=ENDPOINT_CITY";
        }
        if (cities.isEmpty() && cardText != null && STANDALONE_PASADENA_LINE.matcher(cardText).find())
            return "RULE=PASADENA; PASADENA_MATCH=OCR_ROUTE";
        if (cities.isEmpty()) return "RULE=GENERAL; ROUTE_CITY_UNRESOLVED";
        return "RULE=GENERAL; CITY_NOT_PASADENA(" + String.join("|", cities) + ")";
    }

    private static String cleanCity(String raw) {
        if (raw == null) return "";
        String city = raw.trim().replaceAll("\\s+", " ");
        int semicolon = Math.max(city.lastIndexOf(';'), city.lastIndexOf('|'));
        if (semicolon >= 0 && semicolon + 1 < city.length()) city = city.substring(semicolon + 1).trim();
        return city;
    }
}
