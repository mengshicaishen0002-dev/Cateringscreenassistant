package com.local.cateringscreenassistant;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.util.LinkedHashMap;
import java.util.Map;

/** One-shot alarm emitted only after a claim has been positively confirmed. */
final class ClaimSuccessAlert {
    private static final String CHANNEL = "claim_success_alerts_v1";
    private static final String CHANNEL_NAME = "接单成功提醒";
    private static final long[] VIBRATION = {0, 260, 100, 260, 100, 650};
    private static final long KEEP_MS = 30L * 60L * 1000L;
    private static final Map<String, Long> SENT = new LinkedHashMap<>();

    private ClaimSuccessAlert() { }

    static synchronized boolean shouldSend(String identity, long now) {
        SENT.entrySet().removeIf(e -> now - e.getValue() > KEEP_MS);
        if (identity == null || identity.isEmpty()) identity = "claim-" + now;
        if (SENT.containsKey(identity)) return false;
        SENT.put(identity, now);
        while (SENT.size() > 64) SENT.remove(SENT.keySet().iterator().next());
        return true;
    }

    static void notifyConfirmed(Context context, String cardText, String evidence) {
        if (context == null) return;
        String identity = CardText.identity(cardText);
        long now = android.os.SystemClock.elapsedRealtime();
        if (!shouldSend(identity, now)) return;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel channel = nm.getNotificationChannel(CHANNEL);
            if (channel == null) {
                channel = new NotificationChannel(CHANNEL, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("DeliverThat 接单成功后立即提醒");
                channel.enableVibration(true);
                channel.setVibrationPattern(VIBRATION);
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                channel.setSound(sound, attrs);
                nm.createNotificationChannel(channel);
            }
        }

        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String text = "已确认抢到订单；正在返回 Offers 继续扫描";
        if (evidence != null && !evidence.isEmpty()) text += " · " + evidence;
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("DeliverThat 接单成功")
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setTimeoutAfter(20_000)
                .setVibrate(VIBRATION)
                .setSound(sound);

        boolean allowed = Build.VERSION.SDK_INT < 33
                || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
        if (allowed && nm != null) {
            nm.notify(26041 + (identity.hashCode() & 0x0fff), builder.build());
        } else {
            try {
                Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        v.vibrate(VibrationEffect.createWaveform(VIBRATION, -1));
                    else v.vibrate(VIBRATION, -1);
                }
            } catch (Exception ignored) { }
            try {
                Ringtone tone = RingtoneManager.getRingtone(context, sound);
                if (tone != null && !tone.isPlaying()) tone.play();
            } catch (Exception ignored) { }
        }
    }
}
