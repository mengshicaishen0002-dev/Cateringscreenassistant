package com.local.cateringscreenassistant;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure parser for post-Accept UI evidence. Kept Android-free for regression tests. */
final class ClaimSuccessSignals {
    private static final Pattern JOBS_BADGE = Pattern.compile("\\bjobs\\s*[:#-]?\\s*(\\d{1,3})\\b", Pattern.CASE_INSENSITIVE);
    // DeliverThat assigned-job ids look like MENDO_46474511540436997. They are not
    // shown on a normal offer card and are therefore strong post-claim evidence when
    // paired with an assigned-job control/section.
    private static final Pattern ASSIGNED_JOB_ID = Pattern.compile("\\b[a-z0-9]{2,20}_[0-9]{8,}\\b", Pattern.CASE_INSENSITIVE);

    private ClaimSuccessSignals() { }

    static String normalize(String raw) {
        if (raw == null) return "";
        return raw.toLowerCase(Locale.US).replaceAll("\\s+", " ").trim();
    }

    static boolean hasAcceptedJobDetail(String raw) {
        String lower = normalize(raw);
        if (lower.isEmpty()) return false;
        // Field evidence: after a successful claim DeliverThat replaces the offer card with
        // the assigned-job detail view containing these labels. Require a pair, not one lone
        // generic word, so an offer description cannot accidentally confirm a claim.
        boolean timeline = lower.contains("delivery timeline");
        boolean instructions = lower.contains("dropoff instructions")
                || lower.contains("pickup instructions")
                || lower.contains("delivery instructions");
        // DeliverThat's accepted-job detail view is not consistent across builds. Some
        // versions omit "Delivery Timeline" but expose accounting/approval metadata that never
        // belongs to an offer card. Requiring instructions plus two independent job-only fields
        // blocks the real-device false-positive seen after a successful claim without treating a
        // normal offer note containing the word "instructions" as a completed job.
        int jobMeta = 0;
        if (lower.contains("approver name")) jobMeta++;
        if (lower.contains("nuid")) jobMeta++;
        if (lower.contains("gl string")) jobMeta++;

        // v2.10.42: current DeliverThat builds may show the assigned-job page as
        // Begin Delivery + Delivery Timeline + a merchant order id, without any
        // pickup/dropoff-instructions label.  This exact layout was observed in the
        // field after a successful claim.  Require paired job-only evidence so a
        // normal offer card containing generic delivery wording cannot confirm itself.
        boolean beginDelivery = lower.contains("begin delivery");
        boolean assignedId = ASSIGNED_JOB_ID.matcher(lower).find();
        boolean assignedJobLayout = (beginDelivery && (timeline || assignedId))
                || (timeline && assignedId);

        return assignedJobLayout || (timeline && instructions)
                || (instructions && jobMeta >= 2);
    }

    static String extractOutcomeHint(String raw) {
        String lower = normalize(raw);
        if (lower.isEmpty()) return "";
        if (hasAcceptedJobDetail(lower)) {
            if (lower.contains("begin delivery")) return "Begin Delivery/assigned Job";
            if (ASSIGNED_JOB_ID.matcher(lower).find()) return "Assigned Job ID/Delivery Timeline";
            return "Delivery Timeline/Dropoff Instructions";
        }
        String[] phrases = new String[]{
                "successfully accepted", "job accepted", "delivery accepted", "offer accepted",
                "assigned to you", "you are assigned",
                "offer unavailable", "no longer available", "already claimed",
                "claimed by another", "someone else claimed", "unable to accept",
                "failed to accept", "something went wrong", "try again", "error"
        };
        for (String phrase : phrases) if (lower.contains(phrase)) return phrase;
        return "";
    }

    static boolean isPositive(String hint) {
        String lower = normalize(hint);
        return lower.contains("accepted") || lower.contains("assigned to you")
                || lower.contains("you are assigned")
                || lower.contains("delivery timeline/dropoff instructions");
    }

    static boolean isTerminalNegative(String hint) {
        String lower = normalize(hint);
        return lower.contains("offer unavailable") || lower.contains("no longer available")
                || lower.contains("already claimed") || lower.contains("claimed by another")
                || lower.contains("someone else claimed") || lower.contains("unable to accept")
                || lower.contains("failed to accept");
    }

    /** -1 = Jobs tab not observed, 0 = Jobs tab observed with no badge, >0 = badge value. */
    static int jobsBadgeCount(String raw) {
        String lower = normalize(raw).replace(',', ' ').replace('|', ' ');
        if (!lower.matches(".*\\bjobs\\b.*")) return -1;
        Matcher m = JOBS_BADGE.matcher(lower);
        if (!m.find()) return 0;
        try { return Integer.parseInt(m.group(1)); }
        catch (NumberFormatException ignored) { return -1; }
    }

    static boolean jobsBadgeIncreased(int before, int after) {
        return before >= 0 && after >= 0 && after > before;
    }
}
