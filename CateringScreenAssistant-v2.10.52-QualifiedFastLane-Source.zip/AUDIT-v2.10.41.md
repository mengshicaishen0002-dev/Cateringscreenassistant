# v2.10.41 audit

This patch closes the three state-machine items requested after the 2026-09-13 field logs.

1. **Reject generation/token**
   - Every physical Reject transaction receives a monotonically increasing token.
   - Background Reject probes must match both the live `RejectConfirmState` object and the current token.
   - When confirmation is deferred, terminal, superseded, or otherwise retired, that token is invalidated.
   - Queued callbacks from an older Reject generation therefore become no-ops and cannot append late `REJECT_CONFIRM_DEFERRED` records.

2. **Single terminal outcome per Reject transaction**
   - `RejectTerminalGate.tryTerminal(...)` is an atomic first-writer-wins gate.
   - For one card + Reject generation, only the first of `REJECT_CONFIRMED`, `REJECT_DISAPPEARED`, or `REJECT_LOST` can be emitted as terminal.
   - A conflicting later callback is silently discarded; cleanup still proceeds.
   - A later genuine Reject transaction for the same card id receives a new token and is not permanently blocked.

3. **Server-terminal Accept cooldown**
   - `ACCEPT_LOST` caused by authoritative `offer unavailable` now suppresses the same card id for a fixed 90 seconds.
   - The cooldown is intentionally fixed at 90 seconds and does not extend or back off exponentially after repeated losses.
   - Other card ids are unaffected and continue through the low-latency path immediately.

No business rules changed:
- General: amount >= $60 and miles <= 10.
- Pasadena special: Pickup city Pasadena only, amount >= $25 and miles <= 5.
