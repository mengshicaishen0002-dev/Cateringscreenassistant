# v2.10.47 — Terminal-loss Reappearance Rearm

Scope is intentionally narrow. Pasadena qualification, Reject state machine, button geometry, FastAcceptFusion2, claim-success logic, and the 90-second terminal-loss fallback remain unchanged.

## Change

A server-authoritative `ACCEPT_LOST / offer unavailable` still suppresses repeated taps on the same stale card for up to 90 seconds. The suppression can now end early only after the old card is proven to have left the top position:

- a coherent different top Offer is observed; or
- the app is positively on the Offers page and repeated full-tree observations show no readable top Offer for at least 180 ms.

After that departure proof, if the same Offer identity reappears, the cooldown is cleared and the app may immediately claim it again. One blank/failed OCR or Accessibility frame is not enough to rearm.

Expected audit status on a genuine repost:

`ACCEPT_REAPPEARED：旧Offer已确认离开后重新出现；已解除90秒ACCEPT_LOST锁，可立即重抢`
