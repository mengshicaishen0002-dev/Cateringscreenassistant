# v2.10.48 — Fresh Accessibility Before OCR

Field trigger: a qualified $116.67 / 1.7mi offer still used `首卡ROI复制9ms；OCR103ms；总112ms` before Accept.

Targeted change only:
- When the current screen already exposes a fresh visual blue Accept, do not fall straight to ML Kit just because cached Accessibility decision evidence is stale/missing.
- Evidence order is now: same-generation cached evidence -> fresh semantic Accept index -> bounded quick tree -> OCR fallback only if still incomplete.
- Every OCR bypass still requires complete amount, miles, location/time evidence required by the configured rules, current UI generation, valid page, plausible visual Accept geometry, claim budget, and no terminal-loss suppression.
- Reject remains on the existing verified path.
- Pasadena rules, terminal-loss/reappearance logic, reject state machine, claim confirmation, and server outcome handling are unchanged.

Expected hot-path timing:
`首卡ROI复制Xms；视觉Accept；新鲜Action索引Yms；OCR跳过`
or
`首卡ROI复制Xms；视觉Accept；新鲜快速树Yms；OCR跳过`
