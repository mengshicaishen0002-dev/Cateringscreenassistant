# v2.10.49 audit — complementary fast lane + Reject terminal ownership

## Scope
Targeted latency/reliability patch based on 2026-09-14 live logs. No business-rule changes.

## Accept hot-path changes
- Added complementary partial Accessibility evidence fusion before full-tree fallback.
- Semantic Accept index keeps ownership of the exact enabled Accept rectangle.
- Bounded quick tree may contribute missing pay/miles/location/time ancestry, or vice versa.
- Fusion is allowed only when snapshots are fresh (<=420 ms), close in time (<=260 ms), and existing evidence does not conflict.
- Shared amount/miles must match exactly when present on both sides.
- Descriptive overlap is required; bare Accept/Claim fragments cannot fuse.
- The merged result must still pass the existing quickDecisionTextComplete() gate before any action.
- v2.10.48 visual+Accessibility pre-OCR lane now also uses complementary fusion before falling back to OCR.

Expected new timing labels:
- 互补证据融合
- 新鲜互补融合

## Reject terminal changes
- Existing RejectTerminalGate first-terminal ownership remains authoritative.
- Serial cleanup no longer starts a fresh Reject token merely because an async terminal callback already invalidated its callback token.
- A prior REJECT_LOST / REJECT_DISAPPEARED / REJECT_CONFIRMED tombstone suppresses conflicting second terminal logging for that same physical Reject transaction.
- A genuinely new physical Reject action still calls begin(), which clears the old terminal tombstone and creates a new generation.

## Explicitly unchanged
- General rule thresholds.
- Pasadena either-end city semantics and thresholds.
- Reject button targeting / click geometry.
- Reject confirmation budget and REJECT_CONFIRM_DEFERRED behavior.
- ACCEPT_LOST semantics and 90-second fallback.
- v2.10.47 same-offer departure/reappearance rearm.
- Claim success detection and post-claim isolation.

## Verification
- 51 CardText isolation / identity / FastAccept fusion regression cases passed.
- RejectTerminalGate tests passed, including tombstone persistence after callback invalidation.
- Full existing regression suite passed.
- 149 v2.10.49 integration invariants passed.
