# v2.10.50 — Accept terminal tracking window

Field trigger: a $140.40 / 3 mi offer dispatched in 123 ms, then the offer card disappeared and the app immediately emitted `ACCEPT_UNKNOWN` before a delayed Jobs/detail/unavailable terminal state could be observed.

Changes:
- Card disappearance no longer immediately becomes `ACCEPT_UNKNOWN`.
- Starts a 900 ms observation-only terminal window, polling every 120 ms.
- During this window the app never sends another Accept; it only observes Jobs badge growth, assigned-job detail signals, or terminal server failure text.
- Positive evidence still routes to existing `ACCEPT_SUCCESS`; terminal negative evidence still routes to `ACCEPT_LOST`.
- Only after the full window expires without either terminal signal does the app emit `ACCEPT_UNKNOWN`.
- Existing Accept dispatch fast lanes, Pasadena qualification, Reject actions, terminal-loss reappearance behavior, and claim budget are unchanged.

Version: 2.10.50 (versionCode 74).
