# v2.10.40 audit

Focused reliability update based on live DeliverThat logs from 2026-09-13.

## Fixes

1. **Repeated ACCEPT_LOST suppression**
   - When DeliverThat explicitly returns a terminal negative state such as `offer unavailable`, the exact offer identity now enters a **90-second cooldown**.
   - During that window the same stale/re-broadcast card cannot launch another Accept gesture.
   - This directly addresses repeated attempts on the same card id (for example `9a4eb3fe`) seconds apart after the server has already rejected the claim.
   - A later genuine repost is still eligible after the bounded cooldown expires.

2. **Reject terminal-state race cleanup**
   - `finishRejectTransaction(...)` now removes any outstanding asynchronous Reject confirmation state *before* publishing the authoritative terminal result.
   - This prevents a queued background probe from emitting `REJECT_CONFIRM_DEFERRED` after the same Reject was already classified as `REJECT_DISAPPEARED` or `REJECT_CONFIRMED`.
   - Stale Reject confirmation state is also removed when a new top offer retires an old Reject transaction.

## Intentionally unchanged

- General rule: >= $60 and <= 10 mi.
- Pasadena pickup-city-only rule: >= $25 and <= 5 mi.
- Reject lightweight confirmation budget behavior remains protective; a standalone `REJECT_CONFIRM_DEFERRED` is not treated as success.
- Accept geometry, gesture duration, and success-page return-to-Offers behavior are unchanged.
