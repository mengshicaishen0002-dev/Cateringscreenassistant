# CateringScreenAssistant v2.10.51 audit

Field triggers from 2026-09-14 logs:
- Qualified $68.90 / 4.0 mi offer fell back to OCR (130 ms) before Accept.
- ACCEPT_UNKNOWN remained possible after the old card disappeared without a strong success/failure signal.
- Background Reject confirmation callbacks sometimes arrived 1.1-1.3 s after dispatch.

Changes:
1. Pre-OCR recent-cache fusion: a very recent complete decision cache may pair only with the CURRENT semantic Accept rectangle when current partial evidence is compatible. Existing numeric/descriptive fields may not conflict. Old button geometry is never reused.
2. Accept terminal tracking: window increased from 900 ms to 1100 ms and sparse bounded deep probes start after 320 ms, at least 360 ms apart, to catch short-lived Jobs/detail/unavailable evidence. These probes are observation-only and never authorize another Accept.
3. Reject background confirmation: callbacks already >=700 ms old skip the late hierarchy probe and defer back to foreground RejectSequence. Reject click/geometry/rules are unchanged.

Unchanged:
- General and Pasadena qualification rules.
- Pasadena endpoint-city matching.
- Accept/Reject geometry safeguards.
- Claim budget and terminal-loss/reappearance logic.
- Reject click path and retry ownership.

Regression: 158 v2.10.51 integration invariants passed, including all existing unit/regression suites.
