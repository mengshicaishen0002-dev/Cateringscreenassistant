# CateringScreenAssistant v2.10.45 — Fast Accept Fusion

Scope is intentionally narrow. No changes to Pasadena rules, Reject state machine, button geometry, terminal states, or ACCEPT_LOST behavior.

## Change
When the semantic Accept index already has a fresh exact Accept rectangle, while the bounded quick tree has complete decision text (pay, miles, location/time) for the same offer, fuse those complementary snapshots and dispatch Accept immediately instead of paying for a full Accessibility tree reconstruction.

Safety gates retained:
- exact pay+miles same-offer action matcher
- descriptive overlap when available
- both snapshots <=420 ms old
- capture delta <=260 ms
- Accept node must be enabled and have non-empty bounds
- dispatchClaim still rechecks action geometry, terminal suppression, claim budget, monitoring state, and page/action dispatch safety

Expected trace improvement:
`Action索引 + 快速树 + FastAccept融合` then Accept dispatch, without `完整树XXXms`, when complementary evidence is available.
