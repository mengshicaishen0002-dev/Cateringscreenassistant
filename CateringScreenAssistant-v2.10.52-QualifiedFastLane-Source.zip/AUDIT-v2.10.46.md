# CateringScreenAssistant v2.10.46 — FastAccept Fusion 2

## Scope
Targeted latency fix only. No changes to Pasadena qualification, Reject state machine, action geometry, ACCEPT_LOST cooldown, terminal-state handling, or claim-success logic.

## Field issue fixed
A qualifying $91.18 / 1.0 mi Culver City offer showed:
- Action index 43 ms
- Quick tree 41 ms
- Full tree 240 ms

v2.10.45 refused FastAccept fusion whenever the semantic Action-index snapshot omitted either pay or miles, even when the bounded quick tree had complete current-card decision evidence.

## v2.10.46 behavior
`CardText.compatiblePartialActionEvidence(authoritative, partial)` treats the bounded quick-tree snapshot as authoritative and permits the indexed Accept snapshot to omit ancestry fields.

Safety gates remain strict:
- any indexed amount present must exactly match the quick-tree amount;
- any indexed mileage present must exactly match the quick-tree mileage;
- descriptive overlap is required when numeric evidence is incomplete;
- a bare Accept/action label can never fuse;
- freshness and capture-delta gates remain unchanged;
- final action geometry/live revalidation remains unchanged in `tryFastAccept()`/dispatch.

Expected optimized timing tag:
`Action索引...；快速树...；FastAccept融合；规则...`
with no `完整树...` when complementary evidence is sufficient.

## Version
- versionCode 70
- versionName 2.10.46
