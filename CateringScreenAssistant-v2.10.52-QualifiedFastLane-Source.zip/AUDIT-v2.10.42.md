# v2.10.42 field fix

- Recognize current DeliverThat assigned-job success layout using `Begin Delivery`, `Delivery Timeline`, and merchant job IDs such as `MENDO_...`.
- Emit a distinct one-shot sound/vibration notification only after claim success is positively confirmed.
- After success, automatically click `Offer`/`Offers` (or safe back/up fallback) and retry navigation discovery for several short frames if React-Native has not exposed the navigation node yet.
- Keep post-claim isolation active until a fresh Offers card is confirmed, then resume normal scanning immediately.
- Does not change General or Pasadena thresholds.
