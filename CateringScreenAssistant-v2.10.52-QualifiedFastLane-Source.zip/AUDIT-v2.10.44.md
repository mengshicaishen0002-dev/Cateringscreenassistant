# v2.10.44 audit

Focused hardening after reviewing the full project history and v2.10.43.

1. Pasadena special rule remains: pickup OR drop-off endpoint Pasadena => special rule.
2. Sparse OCR fallback `Pasadena` is accepted only when no explicit endpoint city was parsed. This prevents an unrelated map label from overriding a clearly parsed Encino/Rancho/Los Angeles endpoint.
3. Fresh-install defaults now match the active operating rules: General >= $60 and <= 10 mi; Pasadena >= $25 and <= 5 mi. Existing saved user preferences are preserved.
4. Main screen copy/version text is updated.
5. Accept/Reject state machines, geometry, dedupe, claim-success recovery and server-terminal cooldown are unchanged.
