# v2.10.39 — stale IGNORED conflict fix

Field failure fixed: a qualifying offer could be OCR-verified while React-Native still exposed the Ignored tab as selected. The short pre-gesture page probe then returned IGNORED and blocked Accept even though the visible page was an offer card.

Change:
- Keep the normal 16-node Accept probe for speed.
- Only when that probe conflicts with a fresh OCR Accept decision by returning IGNORED, run one wider 96-node bounded probe.
- If current offer/action evidence is found, the stale Ignored selection is downgraded and the fresh OCR Accept path may proceed.
- Restore remains hard Ignored-page evidence, and JOBS remains blocked.
- No threshold or Pasadena-rule changes.

Target field signature:
`Accept未执行：页面为IGNORED；禁止屏幕坐标点击` on a visible qualifying Offers card.
