# v2.10.38 — post-claim return-to-Offers flow

- Treat the assigned-job detail page (`Begin Delivery`, `Delivery Timeline`, order number and pickup details) as claim-success evidence.
- After success confirmation, emit one success report, enter post-claim isolation, and invoke the dedicated Offer/Offers/back navigation path.
- Resume OCR only after a fresh Offers-page/offer-card observation; do not interpret the assigned-job page as a new offer.
- Navigation prefers explicit `Offer`/`Offers` accessibility labels and falls back to a back/up accessibility control.
- Pasadena eligibility remains based on Pickup city; Dropoff is retained for route/destination evaluation.
