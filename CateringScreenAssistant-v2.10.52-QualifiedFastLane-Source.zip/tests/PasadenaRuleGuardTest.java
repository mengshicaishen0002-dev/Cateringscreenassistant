package com.local.cateringscreenassistant;

public final class PasadenaRuleGuardTest {
    public static void main(String[] args) {
        check(PasadenaRuleGuard.isPasadenaOffer(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM Mendocino Farms • 238 S Lake Ave, Pasadena, CA 91101, United States"),
                "Pasadena pickup should use special rule");
        check(PasadenaRuleGuard.isPasadenaOffer(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM X • 175 S Fairfax Ave, Los Angeles, CA 90036 • 100 E Colorado Blvd, Pasadena, CA 91105"),
                "Pasadena dropoff/second endpoint should use special rule");
        check(PasadenaRuleGuard.isPasadenaOffer(
                "Fair Oaks Ave\nPasadena\n1 mi (~6 mins)\nEst. $30-40\nTomorrow at 3:35 PM\nMENDO_46474511540436997"),
                "standalone Pasadena OCR route line should use special rule");
        check(!PasadenaRuleGuard.isPasadenaOffer(
                "$28 Est. 6.7 mi Tomorrow at 10:50 AM Mendocino Farms • 7870 Monet Ave, Rancho Cucamonga, CA 91739, United States\nPasadena"),
                "standalone Pasadena map label must not override an explicit non-Pasadena endpoint");
        check(!PasadenaRuleGuard.isPasadenaOffer(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM Pasadena Cafe • 175 S Fairfax Ave, Los Angeles, CA 90036, United States"),
                "merchant word Pasadena must not trigger special rule");
        check(!PasadenaRuleGuard.isPasadenaOffer(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM Merchant Pasadena route note Los Angeles CA"),
                "inline bare Pasadena must stay general");
        check(PasadenaRuleGuard.auditTag(
                "Fair Oaks Ave\nPasadena\n1 mi (~6 mins)\nEst. $30-40\nTomorrow at 3:35 PM", true)
                .equals("RULE=PASADENA; PASADENA_MATCH=OCR_ROUTE"),
                "OCR route audit tag");
        check(PasadenaRuleGuard.auditTag(
                "$42 Est. 3.2 mi Tomorrow at 11:15 AM X • 175 S Fairfax Ave, Los Angeles, CA 90036", true)
                .startsWith("RULE=GENERAL; CITY_NOT_PASADENA"), "general audit tag");
        System.out.println("PasadenaRuleGuardTest passed");
    }

    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
