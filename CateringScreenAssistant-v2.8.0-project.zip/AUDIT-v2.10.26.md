# CateringScreenAssistant v2.10.26 — Latency Pipeline

## Scope
This release deliberately does **not** lower the 80 ms OCR interval or the 55 ms first Accept gesture. It removes avoidable work around the action path.

## Changes
- Decision-ready Accessibility snapshots cache `amount`, `miles`, and stable offer `identity` once at snapshot creation.
- Accessibility/OCR arbitration: when all rule-sensitive text is complete and the correct side-specific action rectangle exists, Accessibility owns the frame; OCR is reserved for genuinely incomplete/missing action evidence.
- Accept processing quiet lane: after one coherent scan proves the same top card's Accept is disabled/processing, cached Accessibility outcome and Jobs-badge events are checked every 95 ms without a full tree rebuild. A coherent tree recheck occurs at most once per 520 ms quiet window.
- Immediate success/terminal event handling remains unchanged and can close the transaction before the 520 ms tree recheck.
- `snapshot→dispatch` latency is included in Accept action diagnostics.
- Existing first-card serial lock, numeric live guards, page guards, Reject/Accept transaction separation, retry budget, terminal-loss suppression, and 55 ms first gesture are retained.

## Expected effect
The main gain is reduced Binder/tree contention after an Accept reaches processing state and fewer redundant OCR fallbacks on already-complete Accessibility decisions. This should improve readiness for the next meaningful UI event without making the initial gesture more aggressive.
