# v2.7.0 — sequential offer handling and bounded retries

User-selected behavior: process the first readable actionable offer from top to bottom, accept or reject under saved rules, re-read after dispatch and process the next card. Do not prioritize a lower qualifying card over an actionable first card.

Changes:
- One window scan now returns each readable visible card and its own buttons. Selection is top-to-bottom; unavailable/exhausted cards can be skipped so they do not permanently block other visible cards.
- Acceptance no longer sleeps for 15 seconds globally. After the callback, re-read in 180ms. Retry only the identical current card under current rules, up to three total attempts per identity during the session (256 identities retained).
- Retry 2 uses a freshly verified gesture when semantic click may not have affected the app. Attempts are callback-serialized, not parallel timers. All paths require Offers foreground, exact labelled target and fresh card/numeric verification.
- Claim generation cancels late retry processing from superseded transactions.
- Reject keeps the requested 1s eligibility countdown; after successful local click callback, release global cooldown and request a fresh read at 80ms instead of 1050ms. Same-card rejection retry budget still applies.
- Validation itself exceeding 1s cancels the stale click before dispatch.
- OCR fallback retains two readings, per-identity attempt budget and a 700ms post-callback wait. It does NOT have all fast-path retry features.

Validation:
- 94 pure-Java assertions: labels17, card text9, reject sequence7, page guards32, scan timing9, sequential/multi-card/budget20.
- Scenarios include first-low/second-high sequencing, removing first then selecting second, equal pay but different identity, countdown-only changes, card-local text isolation and concurrent claim reservation capped at3.
- Android release compilation, APK signature and alignment verified before delivery.

Evidence consulted 2026-09-08:
- https://developer.android.com/reference/android/accessibilityservice/AccessibilityService#dispatchGesture(android.accessibilityservice.GestureDescription,%20android.accessibilityservice.AccessibilityService.GestureResultCallback,%20android.os.Handler)
  Android documents gesture cancellation and direct tap fallback for apps that do not properly support ACTION_CLICK.
- https://developer.android.com/reference/android/view/accessibility/AccessibilityNodeInfo
  Node action APIs provide local action results, not delivery-platform assignment confirmation.
- https://developers.google.com/ml-kit/vision/text-recognition/v2/android
  Official on-device text-recognition integration and performance guidance.
- https://www.hawkbot.app/
  Advertises DeliverThat via push and <1s alert-to-accept, but page still presents waitlist/coming-soon and no independently verifiable implementation/benchmark. No Hawk code integrated.
- https://www.ideliverthat.com/driver-app
- https://apps.apple.com/us/app/deliverthat-drivers/id6479320370
  Official app description/release notes include Ignored offers and restoring offers. Restore remains excluded from decline actions.

Unverified / remaining limits:
- No real Samsung connected and no real DeliverThat order acquired during validation. 180ms/80ms are scheduled local delays, NOT measured total claim latency.
- Local click callback is not server acceptance. Missing card remains UNKNOWN; Jobs confirmation is not automated.
- Full read/OCR failure, invisible/off-screen cards, confirmation dialogs and platform/network responses can still prevent acquisition. No automatic scrolling or unverified dialog pressing was added.
- OCR final matching remains numeric + labelled location across sources, while fast path uses full card identity. Cross-source identity and fully automatic result confirmation need device evidence.
- Public material inspected does not supply a verified driver claim API implementation. This release uses screen/accessibility only and does not implement Hawk's advertised push/session integration.
