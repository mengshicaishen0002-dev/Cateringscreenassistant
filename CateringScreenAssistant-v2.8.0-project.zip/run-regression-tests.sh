#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${TMPDIR:-/tmp}/csa-v29-tests"
rm -rf "$OUT" && mkdir -p "$OUT"
javac -d "$OUT" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionGeometry.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionDispatchPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionStallPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AlertDedupe.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ButtonLabels.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimBudget.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimConfirmation.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/NumericGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OfferPriority.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PageGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSequence.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ScanPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/FastSnapshotPolicy.java" \
  "$ROOT/tests"/*.java
for cls in FastSnapshotPolicyTest ActionDispatchPolicyTest ActionStallPolicyTest ActionGeometryTest AlertDedupeTest ButtonLabelsTest CardTextTest ClaimConfirmationTest NumericGuardTest OfferFlowTest PageGuardTest RejectSequenceTest ScanPolicyTest; do
  java -cp "$OUT" "com.local.cateringscreenassistant.$cls"
done
# v2.10.12 integration invariants from real-device traces.
grep -q '来源=Gesture首击' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q '!current.acceptBounds.isEmpty() && current.acceptEnabled' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'OCR+Accessibility双源确认换顶' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '紧急下一帧确认' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '服务器已明确返回' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '!cards.isEmpty() ? cards.get(0).text' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'recentClaimOutcomeSince' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'ACTION_STALL_RECOVERY' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'claimEpoch.incrementAndGet()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'rescueProbe' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
echo "10 v2.10.14 real-device integration invariants passed"
