#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${TMPDIR:-/tmp}/csa-v29-tests"
rm -rf "$OUT" && mkdir -p "$OUT"
javac -d "$OUT" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionGeometry.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ButtonLabels.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimBudget.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/NumericGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OfferPriority.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PageGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSequence.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ScanPolicy.java" \
  "$ROOT/tests"/*.java
for cls in ActionGeometryTest ButtonLabelsTest CardTextTest NumericGuardTest OfferFlowTest PageGuardTest RejectSequenceTest ScanPolicyTest; do
  java -cp "$OUT" "com.local.cateringscreenassistant.$cls"
done
