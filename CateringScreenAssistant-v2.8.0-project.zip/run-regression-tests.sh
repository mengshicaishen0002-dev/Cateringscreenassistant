#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${TMPDIR:-/tmp}/csa-v29-tests"
rm -rf "$OUT" && mkdir -p "$OUT"
javac -d "$OUT" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionGeometry.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AccessibilityFallbackPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionDispatchPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionStallPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/AlertDedupe.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ButtonLabels.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimBudget.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimConfirmation.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimSuccessSignals.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/NumericGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OfferPriority.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PageGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PasadenaRuleGuard.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/QuickEvidencePolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSequence.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectConfirmation.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ScanPolicy.java" \
  "$ROOT/app/src/main/java/com/local/cateringscreenassistant/FastSnapshotPolicy.java" \
  "$ROOT/tests"/*.java
for cls in AccessibilityFallbackPolicyTest FastSnapshotPolicyTest ActionDispatchPolicyTest ActionStallPolicyTest ActionGeometryTest AlertDedupeTest ButtonLabelsTest CardTextTest ClaimConfirmationTest ClaimSuccessSignalsTest NumericGuardTest OfferFlowTest PageGuardTest PasadenaRuleGuardTest QuickEvidencePolicyTest RejectSequenceTest RejectConfirmationTest ScanPolicyTest; do
  java -cp "$OUT" "com.local.cateringscreenassistant.$cls"
done
# v2.10.12 integration invariants from real-device traces.
grep -q '来源=Gesture首击' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q '!current.acceptBounds.isEmpty() && current.acceptEnabled' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'OCR+Accessibility双源确认换顶' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '紧急下一帧确认' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'ACCEPT_LOST' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'handlePendingSerialFast' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '!cards.isEmpty() ? cards.get(0).text' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'recentCachedClaimOutcomeSince' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'ACTION_STALL_RECOVERY' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'claimEpoch.incrementAndGet()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'rescueProbe' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'RejectSequence.shared()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'RejectSequence.shared()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'REJECT_NOT_CONFIRMED' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'card.rejectEnabled' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'rejectTransitionSuppressUntil' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
! grep -q 'rejectSequence.forget(oldId)' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'ActionDispatchPolicy.rejectFallbackGestureDurationMs()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'dispatchRejectHybrid' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'trySemanticActionClick' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'Reject异步补手势' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q '顶部拒绝第%d次动作已发送' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'getQuickTopOfferSnapshot' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'window.getId() == activeWindowId' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'quickDecisionTextComplete' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '快速树' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'stale Accessibility tab hint suppress screen capture' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'ocrProvesOffer' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'visualAccept != null && !visualAccept.isEmpty()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'conflictingOfferEvidence' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'hasMoney && hasMiles && hasLiveAction' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'markProcessing' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'RejectSequence.State.PROCESSING' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'QuickEvidencePolicy.canStop' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'compactWhitespace' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'reserveIfReady' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/RejectSequence.java"
grep -q 'rejectSequence.reserveIfReady' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'september|october|november|december' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java"
grep -q 'recentCachedClaimOutcomeSince' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'Jobs徽标' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'Delivery Timeline/Dropoff Instructions' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ClaimSuccessSignals.java"
grep -q 'serialTopActionAt > 0' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'serialTopAction == SerialAction.ACCEPT' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'serialTopAction = SerialAction.REJECT' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'inspectReject' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'REJECT_CONFIRMED' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'REJECT_DISAPPEARED' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'REJECT_LOST' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'RejectConfirmation.classify' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'versionName "2.10.31"' "$ROOT/app/build.gradle"
grep -q 'processingTreeRecheckMs' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/ActionDispatchPolicy.java"
grep -q 'awaitClaimProcessingOutcome' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'AccessibilityFallbackPolicy.accessibilityOwnsFrame' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'snapshot→dispatch=' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'indexedCardTextFromLocalSubtree' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'plausibleIndexedCardRoot' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'decisionNeedsLocationEvidence' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'decisionNeedsOfferTimeEvidence' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
! grep -q 'canStopFirstShot' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/QuickEvidencePolicy.java"
grep -q 'postClaimIsolationActive' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'onJobsBadgeObserved' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'Accessibility字段+视觉Accept' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'frameGeneration != scanGeneration.get()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'sameOfferIgnoringMiles' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java"
grep -q 'ClaimSuccessSignals.hasAcceptedJobDetail(rawScreenText)' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'releasePostClaimIsolation' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'currentUiGeneration' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'invalidateDecisionEvidence' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'Jobs徽标 " + before + "→" + count' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"

grep -q 'getPairedRejectSnapshotFromIndexedAccept' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'getPairedRejectSnapshotFromIndexedAccept' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'findPairedRejectInLocalAncestors' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'findLiveActionAtExpectedBounds' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q '配对Reject' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'Action索引' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'dispatchVerifiedSnapshotGesture' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'Reject确认异步进行' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'reject-confirm' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'startAsyncRejectConfirmation' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'PICKUP_CITY_UNRESOLVED' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PasadenaRuleGuard.java"
grep -q 'RULE=PASADENA' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/PasadenaRuleGuard.java"
! grep -q 'contains("pasadena")' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
! grep -q 'contains("pasadena")' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/TapAccessibilityService.java"
grep -q 'final long taskEpoch = service.scanGeneration.get()' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'STALE_TASK_DROP' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'completedOfferSet' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q 'completionKey' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/CardText.java"
grep -q 'fuseIndexedActionWithEventEvidence' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
grep -q '重复OCR帧已静默抑制' "$ROOT/app/src/main/java/com/local/cateringscreenassistant/OcrMonitorService.java"
echo "91 v2.10.31 integration invariants passed"
