#!/usr/bin/env bash
set -euo pipefail
MANIFEST="app/src/main/AndroidManifest.xml"
SERVICE="app/src/main/java/com/ddoffermonitor/app/OfferAccessibilityService.java"
MAIN="app/src/main/java/com/ddoffermonitor/app/MainActivity.java"

# Core product guardrails / build preflight.
! grep -q 'android.permission.INTERNET' "$MANIFEST"
grep -q 'com.doordash.driverapp' "$SERVICE"
grep -q '<queries>' "$MANIFEST"
grep -q 'com.doordash.driverapp' "$MANIFEST"
grep -q 'manualPending = true' "$SERVICE"
grep -q 'BLOCKED_FINAL_ACTION' "$SERVICE"
grep -q 'Claim and schedule' "$MAIN"
grep -q 'D1–D7' "$MAIN"

# Java source sanity: MainActivity must contain exactly one onResume override.
[ "$(grep -c 'void onResume()' "$MAIN")" -eq 1 ]

# No legacy NovaFlow licensing/server code.
! grep -R -n -E 'verifyCard|/api/token|cjs_SDK|156\.254\.6\.38|Android ID' app/src/main || true


# v1.2.0 NovaFlow-style Accessibility date-row + control/timing guards
grep -q 'novaStyleSevenButtonRow' "$SERVICE"
grep -q 'android.widget.Button' "$SERVICE"
grep -q 'DATE_BUTTON_ROW_TAP' "$SERVICE"
! grep -q 'DATE_COORD_FALLBACK' "$SERVICE"
grep -q "versionName '1.2.0'" app/build.gradle
grep -q 'DATE_MIN_SETTLE_MS = 1500' "$SERVICE"
grep -q 'ROUND_PAUSE' "$SERVICE"
grep -q 'ensureControlOverlay' "$SERVICE"
grep -q 'USER_PAUSE' "$SERVICE"
grep -q 'USER_STOP' "$SERVICE"
! grep -q 'OPEN_OFFERS' "$SERVICE"
grep -q '等待 Schedule → Offers 页面' "$SERVICE"
grep -q '暂停监控' "$MAIN"
grep -q '停止监控' "$MAIN"

echo "DD Offer Monitor preflight PASS"

# v1.2.0 long-run reliability guards
grep -q 'soundAlert' "$MAIN"
grep -q 'vibrateAlert' "$MAIN"
grep -q 'keepAwake' "$MAIN"
grep -q '查看最近日志' "$MAIN"
grep -q 'MAX_LOG_BYTES' "$SERVICE"
grep -q 'FLAG_KEEP_SCREEN_ON' "$SERVICE"
grep -q 'overlayX' "$SERVICE"
grep -q 'PendingIntent' "$SERVICE"

# v1.2.0 reliability / observability guards
grep -q 'monitorMode' "$MAIN"
grep -q '观察模式' "$MAIN"
grep -q 'offerIdentity' "$SERVICE"
grep -q 'REJECT_CACHE_MS' "$SERVICE"
grep -q 'ROUND_WAKE_ON_CHANGE' "$SERVICE"
grep -q 'USER_INTERACTION_HOLD' "$SERVICE"
grep -q 'SAFETY_PAUSE' "$SERVICE"
grep -q 'hasSensitiveScreen' "$SERVICE"
grep -q 'offersUnique' "$SERVICE"
grep -q '查看统计' "$MAIN"
grep -q 'stableKeystorePath' app/build.gradle
