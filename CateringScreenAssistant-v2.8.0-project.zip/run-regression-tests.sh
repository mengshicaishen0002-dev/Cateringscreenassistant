#!/usr/bin/env bash
set -euo pipefail
MANIFEST="app/src/main/AndroidManifest.xml"
SERVICE="app/src/main/java/com/ddoffermonitor/app/OfferAccessibilityService.java"
MAIN="app/src/main/java/com/ddoffermonitor/app/MainActivity.java"

# Core product guardrails / build preflight.
! grep -q 'android.permission.INTERNET' "$MANIFEST"
grep -q 'com.doordash.driverapp' "$SERVICE"
grep -q '<queries>' "$MANIFEST"
grep -q 'com.doordash.driverapp' "$MANIFEST"
grep -q 'manualPending = true' "$SERVICE"
grep -q 'BLOCKED_FINAL_ACTION' "$SERVICE"
grep -q 'Claim and schedule' "$MAIN"
grep -q 'D1–D7' "$MAIN"

# Java source sanity: MainActivity must contain exactly one onResume override.
[ "$(grep -c 'void onResume()' "$MAIN")" -eq 1 ]

# No legacy NovaFlow licensing/server code.
! grep -R -n -E 'verifyCard|/api/token|cjs_SDK|156\.254\.6\.38|Android ID' app/src/main || true


# v1.1.4 date-coordinate fallback guard
grep -q 'DATE_COORD_FALLBACK' app/src/main/java/com/ddoffermonitor/app/OfferAccessibilityService.java
grep -q 's.hasAny("schedule", "offers")' app/src/main/java/com/ddoffermonitor/app/OfferAccessibilityService.java
grep -q "versionName '1.1.4'" app/build.gradle

echo "DD Offer Monitor preflight PASS"
