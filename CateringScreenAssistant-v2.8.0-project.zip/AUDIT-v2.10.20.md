# v2.10.20 audit — duplicate Reject + first-card latency

Field evidence from Galaxy A15 showed two remaining issues after v2.10.19:

1. A first Reject `ACTION_CLICK` was positively acknowledged by DeliverThat (`Reject disabled/processing`), but the same card was clicked again roughly one second later when the old retry timer reopened.
2. A first-card Accessibility pass still reached ~559 ms, and React-Native parent/child descriptions duplicated merchant/address text.

Changes:

- `RejectSequence` now has a `PROCESSING` state. A confirmed disabled/processing Reject holds cross-path retries for 7 seconds. If the same card genuinely returns to ready state after that bounded hold, one recovery retry remains available.
- OCR `handleRejectedCard` explicitly stops in `PROCESSING` and refuses mirror-inferred coordinates after any prior Reject dispatch.
- `dispatchRejectHybrid` marks the shared reject identity as processing only when a fresh post-click Accessibility read positively observes `rejectEnabled == false`; a mere gesture callback does not earn this stronger suppression.
- Quick top-card scan no longer runs a separate 32-node page pre-scan. Page flags are gathered in the same bounded evidence pass.
- Quick scan exits early only after money, miles, California location evidence, and a safe action node are all seen; otherwise it retains the 180-node fallback budget.
- `addUniquePiece` removes O(n^2) repeated regex normalization of already-normalized prior pieces.
- `CardText.aboveButton` avoids re-appending child phrases already present in a parent contentDescription.

Regression suite: 14 pure-Java suites plus 35 source integration invariants.
