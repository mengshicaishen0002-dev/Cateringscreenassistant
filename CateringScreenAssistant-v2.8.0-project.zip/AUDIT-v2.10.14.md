# v2.10.14 field audit

## Trigger trace
A qualifying `$113.73 / 7.2 mi` offer reached the verified 55 ms Accept gesture, then DeliverThat returned `offer unavailable`. The click path therefore reached the platform, but the first actionable submit arrived too late to win the offer.

The trace exposed two avoidable latency sources immediately before the claim:

1. A new top offer first entered `疑似换顶 / 等待第二帧` while an older serial transaction still owned the queue.
2. Accessibility fast checks traversed the hierarchy once to build cards and then traversed it again only to rediscover the top text.

## v2.10.14 changes

- Adds same-frame OCR + bounded Accessibility consensus for top-card replacement. If both sources independently report the same current amount + mileage on the top Accept row, the stale serial transaction is retired immediately and the current frame continues to rule evaluation/action.
- If Accessibility cannot provide consensus, the first mismatching OCR frame arms an urgent transition probe. The next available camera frame bypasses ordinary cooldown and scan cadence for confirmation; it no longer waits for the normal cycle.
- Stable two-frame timing is tightened from 70 ms to 35 ms because the urgent path is already first-card isolated.
- Reuses `cards.get(0).text` from the existing coherent Accessibility `WindowScan` instead of performing a second full hierarchy traversal just to obtain the visible top card.
- Treats server-terminal outcomes (`offer unavailable`, `already claimed`, `no longer available`, etc.) as terminal for that offer: no more Accept retry budget is spent after the server has already rejected the claim.
- Terminal-loss polling performs only one short follow-up hierarchy check; subsequent wakeups come from Accessibility content-change events / heartbeat so a dead offer cannot monopolize the fast worker.
- Reject retry behavior is deliberately calmer: at most two attempts with 1100 ms spacing. Accept remains the latency-priority path.

## Safety invariants retained

- First visible offer only; lower cards never borrow the top action coordinates.
- Exact amount + mileage verification before a claim action.
- Whole-card / wrong-side action rectangles remain prohibited.
- Jobs / Ignored pages remain non-actionable.
- Gesture dispatch is not counted as a successful job; positive accepted/assigned/Jobs evidence is still required.
- A disappeared card without positive evidence remains an unknown/lost result.
