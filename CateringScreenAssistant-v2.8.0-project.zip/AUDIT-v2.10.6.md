# v2.10.6 speed pass

Goal: reduce first-action latency on Galaxy A15 without relaxing the top-card/rule guards.

Changes:
- Default OCR interval moves from 140 ms to 80 ms. Existing installs that still have the old untouched 140 ms default are migrated once to 80 ms; custom values are preserved.
- UI now accepts 60 ms minimum and recommends 70–100 ms for Galaxy A15.
- First-card OCR ROI shrinks from 17–64% of screen height to 20–58%, still covering the observed top DeliverThat card/button row while excluding more navigation/lower-card pixels.
- Screen capture no longer allocates/copies a full 720x1600 bitmap before cropping. It copies only the first-card rows directly from the ImageReader RGBA plane, preserving row stride and cropping horizontal padding afterward.
- OCR worker thread runs at display priority.
- Visual Accept search starts lower in the first-card ROI and scans a smaller action band. Accept-shape height tolerance was widened to stay valid after the shorter ROI.
- Accessibility first-tap forbidden-page probe drops from 45 nodes to 20; OCR coordinate probe drops from 90 nodes to 24.
- Accessibility first-tap gesture duration drops from 35 ms to 14 ms. OCR coordinate gesture remains 12 ms for reliability.
- Timing diagnostics now split first-card ROI-copy time from ML Kit OCR time and total frame-to-decision latency.

Safety/serial invariants retained:
- Only the top offer can be acted on.
- Amount/miles and active city/time rules must still pass before Accept.
- JOBS/IGNORED still block actions.
- Card disappearance alone is not treated as a successful claim.
- Ignore/Decline countdown keeps the first-card lock.
- ML Kit recognition now starts before the visual Accept-band scan so both reads overlap rather than serializing visual detection ahead of OCR.
- Visual Accept detection uses one bulk Bitmap.getPixels() read into a reusable buffer instead of thousands of per-pixel getPixel() calls each frame.
