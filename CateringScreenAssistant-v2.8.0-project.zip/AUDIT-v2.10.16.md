# v2.10.16 audit — Samsung DeliverThat no-action / ineffective Ignore fix

## Field evidence
The supplied Galaxy A15 recording shows one visible DeliverThat offer (`Est. $37–47`, `22.1 mi`) remaining on the Offers page for the full recording even though it is clearly outside the configured max-mile rule. Earlier traces also showed repeated `Reject sent` logs while the same card remained visible.

## Root causes fixed
1. **Reject gestures were still much shorter than Accept.** Accept had already been raised to a 55 ms press after real-device evidence showed the old short gesture did not reliably trigger DeliverThat. Reject still used 14 ms in the Accessibility fast path, 20 ms in the OCR path, and 18 ms in the verified fallback. All Reject dispatch paths now use the same 55 ms Samsung-safe press.
2. **Accessibility-only fallback could discard a real offer before structural card building.** `processStandaloneAccessibility()` required `activePage()==OFFERS` before calling the robust card builder. DeliverThat's React-Native tree can expose the visible card and action row while the Offers tab itself remains `UNKNOWN`. The standalone path now blocks only explicit JOBS/IGNORED and lets `getFastOfferSnapshots()` prove an offer structurally from money+miles+action-row evidence.
3. **Reject diagnostics did not prove where the tap landed.** Reject completion logs now include source, gesture duration, full rect, and final tap coordinates.

## Samsung UI invariants retained
- First visible card only.
- Left action is Ignore/Reject; right action is Accept.
- Whole-card and detail containers are never accepted as action targets.
- OCR may mirror the verified right Accept rectangle only when the visible Ignore label is unavailable.
- Empty/no-offer, Jobs, and Ignored states never authorize a gesture.

## NovaFlow-derived architecture used
Only the interaction architecture is borrowed: event-driven Accessibility, one current UI snapshot per decision, live button bounds over fixed coordinates, and fresh state verification before action. DeliverThat's own Accept/Ignore workflow remains app-specific.
