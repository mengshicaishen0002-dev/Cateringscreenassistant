# v2.8.0 Audit / Upgrade Notes

## 目标

v2.8.0 不是单纯缩短扫描间隔，而是修复 v2.7.0 中会造成“正确订单仍不点击”或“卡片状态变化后停止重试”的逻辑问题，同时避免为追求速度引入跨卡误点。

## 已确认并修复的问题

### 1. 金额区间实时核验错误
v2.7 对卡片内每一个 `$` 数字逐一比较；`$70–80` 在先匹配 `$70` 后又看到 `$80` 时可被判失败。v2.8 改为：只要同一字段中存在与决策值一致的数值即可通过实时核验。

### 2. 动作按钮污染订单身份
Accept/Decline/Ignore 等节点在点击后可能消失、disabled 或改变 Accessibility 描述。v2.8 将动作标签和动态 Expires 倒计时从稳定身份中剥离。

### 3. 跨卡数字串联
当下面一张卡的金额或距离节点临时缺失时，简单“向上找最近金额/里程”可能取到上一张卡。v2.8 使用上一操作按钮行作为硬边界；当前卡字段缺失就返回不完整，不跨卡拼数据。

### 4. `Est` / `Offer` 被错误当成硬条件
部分 DeliverThat UI/Accessibility 树可能不暴露这两个词。v2.8 以金额、距离、动作按钮及规则字段为主，不再强制要求 `Est`/`Offer`。

### 5. OCR 二次确认造成不必要延迟
OCR 现在是 fallback。真正动作前 Accessibility 仍会重新核验卡片、数字和按钮，因此删除了符合条件后再等第二 OCR 帧的固定延迟。

### 6. Ignore 固定等待 1 秒
删除固定 1 秒等待。不符合订单在按钮和卡片实时核验后立即 Reject/Ignore，并在约 60 ms 发起下一轮读取；约 190 ms 再强制观察一次，以覆盖首次点击未生效的情况。

### 7. 点击节点结构变化
可见文字节点可能不可点击，而父节点才是真正按钮。v2.8 最多向上查找可点击父节点；语义点击失败时才使用已核验坐标手势。按钮坐标也允许有限的小幅布局移动，而不是要求旧坐标必须仍完全落在新节点矩形内。

### 8. 点击后 disabled 被误判成消失
窗口扫描保留 disabled 的动作节点作为卡片锚点，但不会把 disabled 节点当成可执行按钮。Accept 后短暂 disabled 会进行两次短复核，再决定重试或退出事务。

### 9. 扫描忙时事件丢失
新增 dirty-event 补扫机制：若 Accessibility 事件到达时已有扫描在排队/运行，事件不会永久丢掉；当前扫描完成后立即再扫一次。

### 10. OCR 按钮弱识别
正常 OCR 走原图快路径；只有金额/里程可见但动作按钮缺失时，才对 ROI 做灰度+对比度增强并进行第二次 OCR，避免每帧预处理带来的额外延迟。

## 当前动作时序

- Accessibility 轮询：约 180 ms，同时由真实窗口事件即时触发。
- OCR fallback：默认 200 ms；Accessibility 刚读到可靠卡片后的 500 ms 内不重复做 OCR。
- Accept：第一次优先语义 Accessibility click；后续重试使用实时核验后的 gesture fallback；每单最多 3 次。
- Accept 后：约 140 ms 检查页面；disabled 状态再以约 120 ms 间隔短观察。
- Reject：固定 1 秒等待已取消；retryAfter 约 180 ms；每单最多 3 次。

## 测试结果

纯 Java 回归：**110/110 assertions passed**

- ButtonLabels: 17
- CardText: 17
- NumericGuard: 6
- OfferFlow / ClaimBudget: 20
- PageGuard: 32
- RejectSequence: 9
- ScanPolicy: 9

此外对 Android Java 源码进行了无 Android classpath 的 javac 解析检查，用于发现语法/括号/声明级错误；完整 Android 编译仍需要 Android SDK + Gradle 环境。

## 外部参考

- Hawk public product site: https://www.hawkbots.com/
- User-provided CSDN Meituan OCR article: https://blog.csdn.net/2503_90251840/article/details/148590929
- Android AccessibilityService docs: https://developer.android.com/reference/android/accessibilityservice/AccessibilityService
- Google ML Kit text recognition on Android: https://developers.google.com/ml-kit/vision/text-recognition/v2/android

这些参考只用于公开可观察的架构/性能/OCR处理思路。本项目未实现随机伪装、反检测或绕过平台安全控制。
