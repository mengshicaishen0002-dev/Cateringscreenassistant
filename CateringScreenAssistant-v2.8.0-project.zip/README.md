## v2.10.10

- Replaces whole-card OCR/accessibility hashing with a stable order fingerprint based on low-end pay + miles + scheduled time + merchant/location core. Duplicate addresses, reordered `Est.` text and repeated accessibility descriptions no longer turn one order into a fake new card.
- Serial lock, claim budget, RejectSequence, alert de-dupe and decision-log card IDs now all share that stable fingerprint.
- Same-order comparison explicitly rejects changed scheduled time or merchant when both are available.
- Disabled Accept/Ignore nodes are treated as processing/countdown state: keep the first card locked and do not fall through to OCR coordinate clicking.
- Ignore retry spacing increased from 900 ms to 1400 ms to prevent needless double taps while DeliverThat is still processing the same card.
- Keeps v2.10.9 stale-snapshot refresh, v2.10.8 anti-card-container geometry and positive acceptance confirmation.

## v2.10.9

- Qualified first taps are no longer cancelled just because the original Accessibility button snapshot exceeded 380/420 ms. Snapshots up to 2200 ms get a bounded active-window revalidation of exact pay + mileage + current button geometry, then dispatch immediately if still the same top card.
- Fast Ignore no longer performs a second full `findOffer()` tree walk before its first click.
- Accessibility action work is prioritized over OCR; new OCR frames pause briefly while an action is in flight.
- Reuses ROI bitmaps to reduce allocation/GC spikes and warms ML Kit at monitor startup.
- Retains v2.10.8 anti-card-container guards and v2.10.5 positive acceptance confirmation.

## v2.10.8
- Fixes the field failure where an ineligible offer opened its detail page instead of pressing Ignore.
- Never replaces a semantic Ignore/Accept label with a larger clickable card ancestor.
- Adds hard left/right button-geometry guards to Accessibility, OCR, fast-tap, retry and semantic-fallback paths.
- Whole-card/full-row/detail-arrow targets are rejected; fallback parent climbing may not escape into the card container.
- Keeps strict first-card serial processing and the v2.10.6 ~80 ms low-latency scan profile.

## v2.10.6
- Galaxy A15 low-latency profile: 80 ms default scan interval (70–100 ms recommended).
- Direct first-card ImageReader-row copy; no full-screen bitmap allocation before OCR.
- First-card OCR ROI tightened to 20–58% screen height.
- Smaller pre-tap Accessibility page probes and 14 ms first-tap gesture.
- ML Kit starts before the visual Accept scan; blue-button pixels are bulk-read into a reusable buffer.
- Split ROI-copy/OCR/total timing diagnostics for real-device tuning.

## v2.10.4
Real-device DeliverThat action fix: gesture-first button execution, strict first-card lock, structural button bounds, no timeout unlock during Ignore/Decline transition.

## v2.10.3
Strict top-card serial queue: process first card → wait for disappearance/countdown → rescan next card.

## v2.10.2 qualified-order alert

Qualifying offers now trigger a high-priority notification, sound and vibration as soon as all active rules pass, before any Accept click is attempted. The alert shows pay, miles and $/mi and is de-duplicated per offer for 10 minutes. This keeps the human driver informed even if DeliverThat ignores an automated tap.

# Catering Screen Assistant v2.10.2


## v2.10.2

- Fixes the two field failures observed on Galaxy A15: `OCR/视觉证据已超过1秒` and `屏幕坐标在点击前已过期`.
- OCR/visual coordinate actions now use a dedicated 2.2 s action-evidence window; the normal OCR-result freshness guard remains tighter.
- Removes the expensive second full multi-window Accessibility traversal immediately before a coordinate gesture.
- Adds a bounded 90-node active-root page probe plus a short-lived page hint; positive JOBS/IGNORED still blocks the action.
- Reduces the background full-tree heartbeat from 90 ms to 900 ms because real device traces showed one tree walk taking 394-785 ms. Accessibility content-change events remain immediate.
- Adds action-age diagnostics to inferred Reject logs.

## v2.10.0
- Accessibility scans all DeliverThat interactive windows and no longer prunes descendants under invisible WebView/Compose containers.
- Reject OCR/visual coordinates can dispatch a fresh verified gesture when DeliverThat does not expose a Reject Accessibility node.
- Accept/Reject can be paired from the two-button row geometry when one label is missing.
- Enhanced OCR is skipped when a usable action-row anchor already exists, reducing avoidable latency.


Primary path: Android Accessibility control-tree parsing and action. Button text is optional; blank clickable nodes can be paired structurally with the offer card. OCR remains fallback only.

Android / Samsung local offer-screen assistant for DeliverThat.

Core architecture:
- Dedicated 90 ms Accessibility fast path (event-driven + heartbeat)
- ML Kit OCR on a separate worker as a true fallback
- Fresh-screen verification before every action
- Strict serial queue: only the first visible offer card may be accepted/rejected; lower cards wait until they move to the top
- Ordinary + Pasadena rule sets
- Persistent decision history
- Fixed local signing key for v2.9+ in-place upgrades

See `AUDIT-v2.9.md` for the v2.8 miss analysis and all v2.9 fixes.

Galaxy A15 suggested OCR interval: 70–100 ms. Accessibility fast path does not wait for this interval.
## v2.10.5
- First Accept uses a fresh top-card hot-zone snapshot to cut pre-tap tree-walk latency.
- A vanished Offers card is no longer reported as a successful claim.
- Positive claim confirmation requires Jobs/accepted-assigned UI evidence.
- OCR is restricted to the first-card screen region to reduce latency and preserve strict serial processing.


## v2.10.7
- Fast Ignore/Reject now uses the already-isolated first-card Accessibility rectangle instead of immediately rescanning the full tree.
- Action revalidation tolerates DeliverThat React-Native duplicate/missing descriptive nodes, while still requiring exact amount and miles.
- General verified gesture duration reduced to 18 ms; fast top-card gestures remain 14 ms.
