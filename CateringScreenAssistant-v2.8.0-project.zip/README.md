## v2.10.16

- Fixes Galaxy A15 recordings where a clearly ineligible DeliverThat offer remained visible and Ignore never took effect.
- Reject/Ignore now uses a 55 ms full press on every dispatch path (Accessibility fast, OCR coordinate, and verified fallback), matching the duration already proven necessary for DeliverThat Accept.
- Accessibility-only mode no longer rejects a structurally valid offer merely because the React-Native Offers page classifier is UNKNOWN; explicit Jobs/Ignored still block actions.
- Reject logs now include source, rect, tap coordinates, and gesture duration so a failed real-device action can be distinguished from a correct server-side transition.
- Keeps the shared two-attempt Reject arbiter, first-card serial lock, anti-card-container geometry, and v2.10.14 Accept fast path.

## v2.10.14

- Optimizes the real-device `$113.73 / 7.2 mi` `offer unavailable` trace: the claim reached DeliverThat, but a stale serial transition delayed the first submit.
- A different top card can now be confirmed in the same frame by OCR + bounded Accessibility amount/mileage consensus; otherwise an urgent next-frame probe bypasses normal cooldown/scan cadence.
- Removes the second full Accessibility hierarchy traversal when the first WindowScan already produced `cards.get(0)`.
- Server-terminal outcomes such as `offer unavailable` / `already claimed` immediately terminate local retries for that offer and stop consuming the fast worker with repeated full-tree polls.
- Reject retry is throttled to at most two attempts with 1100 ms spacing; Accept remains the latency-priority path.
- Retains strict first-card isolation, action-geometry guards and positive success confirmation.

## v2.10.13

- Fixes the field stall where a visible first offer could remain on screen indefinitely after a previous Accept/Ignore transaction.
- Cooldown/action-hold no longer starves capture completely: a bounded rescue OCR probe may run every 320 ms after the old action has aged at least 420 ms.
- A stale serial lock is retired only after two stable first-card OCR observations; one mixed transition frame cannot unlock the queue.
- Retiring a stale lock now also invalidates pending `inspectClaim()` callbacks via an atomic claim epoch and clears old cooldown/action-hold gates, preventing an old callback from re-locking a new top offer.
- If the same top offer remains visible beyond the hard wait, only transient timing gates are released; offer identity and retry budgets stay intact to avoid repeat-click spam.
- Adds explicit `ACTION_STALL_RECOVERY` diagnostics so future field logs show when stale serial/cooldown/hold state was repaired.

## v2.10.12

- First qualified Accept no longer spends time on semantic `ACTION_CLICK`; it goes straight to the already verified 55 ms button gesture.
- Fixes wasted retry budget: while Accept is disabled/processing, the monitor waits without consuming attempts #2/#3; a retry is reserved only after the same button becomes enabled again.
- Fixes one-frame serial-lock lag: because OCR is restricted to the first-card action ROI, a newly anchored different top card retires the stale serial lock and is evaluated in the same frame instead of waiting for another scan.
- Captures recent DeliverThat accessibility event/root outcome text such as accepted/assigned, unavailable/already claimed, or retry/error hints and includes it in claim diagnostics.
- Preserves strict top-card isolation, left/right action geometry guards, stable offer identity, and positive-success confirmation.

## v2.10.11

- Accept now prefers a real safe Accessibility `ACTION_CLICK` on the verified top-card Accept node.
- If that semantic click returns true but the same enabled Accept is still visible 85 ms later, the app falls back to a 55 ms verified button press.
- Retry #2 reacquires the top button and uses a 55 ms center press; retry #3 uses a 65 ms alternate interior point.
- OCR/visual Accept fallback also uses a 55 ms press and logs button rect/tap coordinates.
- Offer identity is stabilized to pay + miles + pickup time + merchant key, reducing duplicate processing when DeliverThat duplicates accessibility text.
- Gesture completion still does not count as a successful claim; positive Jobs/accepted-assigned evidence remains required.

## v2.10.9

- Qualified first taps are no longer cancelled just because the original Accessibility button snapshot exceeded 380/420 ms. Snapshots up to 2200 ms get a bounded active-window revalidation of exact pay + mileage + current button geometry, then dispatch immediately if still the same top card.
- Fast Ignore no longer performs a second full `findOffer()` tree walk before its first click.
- Accessibility action work is prioritized over OCR; new OCR frames pause briefly while an action is in flight.
- Reuses ROI bitmaps to reduce allocation/GC spikes and warms ML Kit at monitor startup.
- Retains v2.10.8 anti-card-container guards and v2.10.5 positive acceptance confirmation.

## v2.10.8
- Fixes the field failure where an ineligible offer opened its detail page instead of pressing Ignore.
- Never replaces a semantic Ignore/Accept label with a larger clickable card ancestor.
- Adds hard left/right button-geometry guards to Accessibility, OCR, fast-tap, retry and semantic-fallback paths.
- Whole-card/full-row/detail-arrow targets are rejected; fallback parent climbing may not escape into the card container.
- Keeps strict first-card serial processing and the v2.10.6 ~80 ms low-latency scan profile.

## v2.10.6
- Galaxy A15 low-latency profile: 80 ms default scan interval (70–100 ms recommended).
- Direct first-card ImageReader-row copy; no full-screen bitmap allocation before OCR.
- First-card OCR ROI tightened to 20–58% screen height.
- Smaller pre-tap Accessibility page probes and 14 ms first-tap gesture.
- ML Kit starts before the visual Accept scan; blue-button pixels are bulk-read into a reusable buffer.
- Split ROI-copy/OCR/total timing diagnostics for real-device tuning.

## v2.10.4
Real-device DeliverThat action fix: gesture-first button execution, strict first-card lock, structural button bounds, no timeout unlock during Ignore/Decline transition.

## v2.10.3
Strict top-card serial queue: process first card → wait for disappearance/countdown → rescan next card.

## v2.10.2 qualified-order alert

Qualifying offers now trigger a high-priority notification, sound and vibration as soon as all active rules pass, before any Accept click is attempted. The alert shows pay, miles and $/mi and is de-duplicated per offer for 10 minutes. This keeps the human driver informed even if DeliverThat ignores an automated tap.

# Catering Screen Assistant v2.10.2


## v2.10.2

- Fixes the two field failures observed on Galaxy A15: `OCR/视觉证据已超过1秒` and `屏幕坐标在点击前已过期`.
- OCR/visual coordinate actions now use a dedicated 2.2 s action-evidence window; the normal OCR-result freshness guard remains tighter.
- Removes the expensive second full multi-window Accessibility traversal immediately before a coordinate gesture.
- Adds a bounded 90-node active-root page probe plus a short-lived page hint; positive JOBS/IGNORED still blocks the action.
- Reduces the background full-tree heartbeat from 90 ms to 900 ms because real device traces showed one tree walk taking 394-785 ms. Accessibility content-change events remain immediate.
- Adds action-age diagnostics to inferred Reject logs.

## v2.10.0
- Accessibility scans all DeliverThat interactive windows and no longer prunes descendants under invisible WebView/Compose containers.
- Reject OCR/visual coordinates can dispatch a fresh verified gesture when DeliverThat does not expose a Reject Accessibility node.
- Accept/Reject can be paired from the two-button row geometry when one label is missing.
- Enhanced OCR is skipped when a usable action-row anchor already exists, reducing avoidable latency.


Primary path: Android Accessibility control-tree parsing and action. Button text is optional; blank clickable nodes can be paired structurally with the offer card. OCR remains fallback only.

Android / Samsung local offer-screen assistant for DeliverThat.

Core architecture:
- Dedicated 90 ms Accessibility fast path (event-driven + heartbeat)
- ML Kit OCR on a separate worker as a true fallback
- Fresh-screen verification before every action
- Strict serial queue: only the first visible offer card may be accepted/rejected; lower cards wait until they move to the top
- Ordinary + Pasadena rule sets
- Persistent decision history
- Fixed local signing key for v2.9+ in-place upgrades

See `AUDIT-v2.9.md` for the v2.8 miss analysis and all v2.9 fixes.

Galaxy A15 suggested OCR interval: 70–100 ms. Accessibility fast path does not wait for this interval.
## v2.10.5
- First Accept uses a fresh top-card hot-zone snapshot to cut pre-tap tree-walk latency.
- A vanished Offers card is no longer reported as a successful claim.
- Positive claim confirmation requires Jobs/accepted-assigned UI evidence.
- OCR is restricted to the first-card screen region to reduce latency and preserve strict serial processing.


## v2.10.7
- Fast Ignore/Reject now uses the already-isolated first-card Accessibility rectangle instead of immediately rescanning the full tree.
- Action revalidation tolerates DeliverThat React-Native duplicate/missing descriptive nodes, while still requiring exact amount and miles.
- General verified gesture duration reduced to 18 ms; fast top-card gestures remain 14 ms.


## v2.10.15
Reject/Ignore now uses one process-wide two-attempt arbiter across OCR and Accessibility. Same-card retry state survives transient serial-lock recovery, disabled buttons are not re-clicked, and two unconfirmed attempts end in `REJECT_NOT_CONFIRMED` instead of repeated taps.
