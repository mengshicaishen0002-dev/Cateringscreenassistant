## v2.10.4
Real-device DeliverThat action fix: gesture-first button execution, strict first-card lock, structural button bounds, no timeout unlock during Ignore/Decline transition.

## v2.10.3
Strict top-card serial queue: process first card → wait for disappearance/countdown → rescan next card.

## v2.10.2 qualified-order alert

Qualifying offers now trigger a high-priority notification, sound and vibration as soon as all active rules pass, before any Accept click is attempted. The alert shows pay, miles and $/mi and is de-duplicated per offer for 10 minutes. This keeps the human driver informed even if DeliverThat ignores an automated tap.

# Catering Screen Assistant v2.10.2


## v2.10.2

- Fixes the two field failures observed on Galaxy A15: `OCR/视觉证据已超过1秒` and `屏幕坐标在点击前已过期`.
- OCR/visual coordinate actions now use a dedicated 2.2 s action-evidence window; the normal OCR-result freshness guard remains tighter.
- Removes the expensive second full multi-window Accessibility traversal immediately before a coordinate gesture.
- Adds a bounded 90-node active-root page probe plus a short-lived page hint; positive JOBS/IGNORED still blocks the action.
- Reduces the background full-tree heartbeat from 90 ms to 900 ms because real device traces showed one tree walk taking 394-785 ms. Accessibility content-change events remain immediate.
- Adds action-age diagnostics to inferred Reject logs.

## v2.10.0
- Accessibility scans all DeliverThat interactive windows and no longer prunes descendants under invisible WebView/Compose containers.
- Reject OCR/visual coordinates can dispatch a fresh verified gesture when DeliverThat does not expose a Reject Accessibility node.
- Accept/Reject can be paired from the two-button row geometry when one label is missing.
- Enhanced OCR is skipped when a usable action-row anchor already exists, reducing avoidable latency.


Primary path: Android Accessibility control-tree parsing and action. Button text is optional; blank clickable nodes can be paired structurally with the offer card. OCR remains fallback only.

Android / Samsung local offer-screen assistant for DeliverThat.

Core architecture:
- Dedicated 90 ms Accessibility fast path (event-driven + heartbeat)
- ML Kit OCR on a separate worker as a true fallback
- Fresh-screen verification before every action
- Multi-card prioritization: qualifying visible offer first, then reject ineligible cards
- Ordinary + Pasadena rule sets
- Persistent decision history
- Fixed local signing key for v2.9+ in-place upgrades

See `AUDIT-v2.9.md` for the v2.8 miss analysis and all v2.9 fixes.

Galaxy A15 suggested OCR interval: 120–160 ms. Accessibility fast path does not wait for this interval.