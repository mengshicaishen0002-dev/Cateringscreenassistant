# Catering Screen Assistant v2.9.3

## v2.9.3
- Accessibility scans all DeliverThat interactive windows and no longer prunes descendants under invisible WebView/Compose containers.
- Reject OCR/visual coordinates can dispatch a fresh verified gesture when DeliverThat does not expose a Reject Accessibility node.
- Accept/Reject can be paired from the two-button row geometry when one label is missing.
- Enhanced OCR is skipped when a usable action-row anchor already exists, reducing avoidable latency.


Primary path: Android Accessibility control-tree parsing and action. Button text is optional; blank clickable nodes can be paired structurally with the offer card. OCR remains fallback only.

Android / Samsung local offer-screen assistant for DeliverThat.

Core architecture:
- Dedicated 90 ms Accessibility fast path (event-driven + heartbeat)
- ML Kit OCR on a separate worker as a true fallback
- Fresh-screen verification before every action
- Multi-card prioritization: qualifying visible offer first, then reject ineligible cards
- Ordinary + Pasadena rule sets
- Persistent decision history
- Fixed local signing key for v2.9+ in-place upgrades

See `AUDIT-v2.9.md` for the v2.8 miss analysis and all v2.9 fixes.

Galaxy A15 suggested OCR interval: 120–160 ms. Accessibility fast path does not wait for this interval.