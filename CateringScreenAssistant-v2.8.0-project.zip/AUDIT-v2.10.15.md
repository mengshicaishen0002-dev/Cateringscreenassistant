# v2.10.15 Reject/Ignore arbitration audit

Real Samsung DeliverThat traces showed the same ineligible first card (#9cedb734) receiving Reject dispatches at 18:14:30, :31, :32 and :35 even though the intended policy was two attempts maximum. The card identity remained stable, so the fault was action arbitration rather than OCR identity drift.

Changes:
- OCR and standalone Accessibility now share one process-wide `RejectSequence` budget.
- A transient serial-lock retirement no longer forgets the old Reject budget. This prevents mixed/transition frames from resetting the same card to attempt 0.
- Fast Accessibility Reject requires the actual reject action to be enabled; disabled/processing rows are held instead of clicked. OCR remains the bounded fallback when semantics are missing.
- Every Reject source (Accessibility fast path, OCR semantic path, inferred paired-button geometry, standalone Accessibility) is capped by the same two-attempt gate and 1100 ms retry spacing.
- Android dispatch failures roll back the reserved attempt and use a short retry delay; a failed gesture no longer burns the two-attempt budget.
- After two dispatched attempts the app emits `REJECT_NOT_CONFIRMED` once, then keeps the top-card serial lock without further clicks until the card changes/disappears.
- Log text now includes the Reject attempt number.

Samsung UI assumptions retained from supplied DeliverThat screenshots:
- Offers card action row has Ignore/Reject on the left and Accept on the right.
- Whole-card clickable ancestors are never accepted as action buttons.
- When the Ignore label is visually unreadable, left-side inference is allowed only from the same verified action row as a right-side Accept anchor and still passes normalized action geometry checks.
- The empty `No offers` state never authorizes an action.

- Partial OCR transition frames for about 1.4 s after a Reject dispatch are suppressed from ordinary card#0 logging; they do not clear the shared Reject budget or unlock lower cards.
