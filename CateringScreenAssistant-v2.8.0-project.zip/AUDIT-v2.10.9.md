# v2.10.9 audit — stale snapshot recovery + first-action latency hardening

## Problem reproduced from real log
A qualified `$91.25 / 2.7 mi` offer reached the fast Accessibility path, but the first Accept was never dispatched because its button snapshot was already 1091 ms old. The old code hard-rejected any Accept snapshot older than 380 ms, then performed another expensive read while the offer disappeared. The same log also showed ROI copy/OCR spikes of roughly 98 ms + 446 ms.

## v2.10.9 changes

1. **Soft-stale snapshots are revalidated instead of discarded.**
   - Accept soft age: 380 ms.
   - Reject soft age: 420 ms.
   - Hard safety limit: 2200 ms.
   - A snapshot between soft and hard age goes through a bounded active-window probe.

2. **Bounded top-card probe, no full-tree/OCR restart.**
   - Reads only the active DeliverThat Accessibility window.
   - Caps traversal at 180 nodes.
   - Revalidates exact low-end pay + mileage.
   - Requires a current button-sized action rectangle on the correct left/right side.
   - Whole-card clickable containers remain forbidden by ActionGeometry.

3. **Fast Reject no longer calls `findOffer()` before the first Ignore.**
   - It now uses the same first-card snapshot that made the rule decision.
   - If stale, `tapSnapshotRejectFast()` performs the bounded refresh itself.

4. **Accessibility action gets CPU/Binder priority over OCR.**
   - Fast decision thread raised to `THREAD_PRIORITY_URGENT_DISPLAY`.
   - New OCR frames are temporarily suppressed while an Accessibility action is in flight.

5. **ROI bitmap allocation removed from the steady-state loop.**
   - Padded/exact ROI bitmaps are pooled and reused while `ocrBusy` guarantees one OCR task at a time.
   - Avoids repeated large bitmap allocation/crop/GC spikes.

6. **ML Kit warm-up added.**
   - A tiny blank frame warms the recognizer after monitor startup so the first valuable offer is less likely to pay cold-start cost.

## Safety invariants retained
- Only DeliverThat package can authorize an action.
- Jobs and Ignored pages remain blocked.
- First-card serial lock remains in force.
- Pay/mileage must still match exactly during stale refresh.
- Accept/Ignore rectangles must pass v2.10.8 anti-card-container geometry.
- A card disappearing from Offers is not classified as successful acceptance without positive Jobs/accepted evidence.

## Regression status
- Fast snapshot freshness: 9 cases
- Action geometry: 25 cases
- Alert dedupe: 4 cases
- Button labels: 21 cases
- Card identity/isolation: 20 cases
- Claim confirmation: 5 cases
- Numeric guard: 6 cases
- Multi-offer/claim-budget: 25 cases
- Page guard: 128 combinations
- Reject sequence: 10 cases
- Scan timing: 13 cases
