# CateringScreenAssistant v2.10.23

Field-driven fixes from the first confirmed real Accept on DeliverThat.

## Confirmed failure in v2.10.22
- The job was actually accepted (Offers became empty and Jobs badge became 1), but the monitor classified the disappearance as unknown.
- During that uncertainty it continued expensive Accessibility scans and generated additional Accept retry attempts on the newly rendered assigned-job detail UI.

## v2.10.23 fixes
- Recognizes assigned-job detail evidence only when `Delivery Timeline` appears together with an instructions section such as `Dropoff Instructions`.
- Tracks the Jobs badge and treats an increase relative to the pre-claim cached baseline as strong success evidence.
- Makes Accessibility event success evidence a zero-tree fast exit before rebuilding the offer hierarchy.
- Removes the duplicate post-disappearance success tree walk; one coherent scan now refreshes page, Jobs badge and success text caches.
- While an Accept transaction is pending, normal fast scans and OCR cannot independently start attempt #2/#3. `inspectClaim` exclusively owns retries.
- OCR immediately terminates the pending claim when the assigned-job detail screen appears, preventing clicks on job-detail controls.
- Fast and retry gesture paths abort if a success state has already appeared.
- Clears pending claim epoch/serial/budgets immediately after confirmed success and wakes scanning for the next offer.
- Fixed an accidental duplicate stable-top frame increment in the OCR transition tracker.

## Regression
See `REGRESSION-RESULTS.txt`. Includes pure tests for assigned-job detail detection and Jobs badge increase semantics.
