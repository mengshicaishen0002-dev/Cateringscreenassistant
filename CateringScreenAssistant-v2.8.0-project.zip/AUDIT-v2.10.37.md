# v2.10.37 Accept Same-Card Callback Observer Fence Audit

Scope is intentionally narrow.

## Changed
- Arm an observer fence only immediately when Android returns true from the Accept dispatchGesture() call.
- Same-card late OCR frames are suppressed before button/action-row parsing. They can no longer emit the post-dispatch `OCR扫描：金额/里程已读到，但动作行仍无可靠锚点` path or re-enter rule/action logic.
- Accepted-job detail remains an allowed observation signal and can still confirm claim success.
- Existing Accessibility pending-Accept ownership remains the observer-only path for accessibility events.

## Explicitly unchanged
- `ACCEPT_LOST` / terminal-loss semantics and retry/reappearance behavior.
- Claim budget, thresholds, Pasadena rules, Reject state machine, Large Order popup guard before dispatch, scan interval, and gesture durations.
