# v2.10.21 audit — cross-source duplicate action arbitration

Galaxy A15 field logs exposed a remaining race in v2.10.20. At 11:26:33 the same
Mendocino Farms / 300 S Grand Ave offer ($29–39, 4.3 mi, September 11 10:45 AM)
was rejected twice: once from Accessibility card #3c98e21e and once from OCR card
#608a781b. This was one physical card, not two offers.

Root causes:

1. `CardText.identity()` understood Today/Tomorrow pickup times but not calendar-date
   labels such as `September 11 at 10:45 AM`. OCR's `300S` vs Accessibility's `300 S`
   therefore leaked into the fallback merchant token signature and split one offer into
   two budget keys.
2. Reject arbitration used `observe()` and `sent()` as separate synchronized calls. Two
   worker threads could both observe READY before either reserved the attempt.

Changes:

- Calendar-date pickup labels (January–December + day + time) now produce a canonical
  identity and merchant key, making OCR/Accessibility variants of the same card identical.
- RejectSequence adds `reserveIfReady()`: READY validation and attempt reservation are one
  atomic operation. Only one source can win a physical Reject dispatch.
- OCR action-row misses that already contain amount+miles immediately request a coalesced
  Accessibility/next-frame rescue instead of waiting for the ordinary scan interval.
- Existing v2.10.20 PROCESSING hold, explicit-button retry rule, and quick-tree path remain.

Regression additions reproduce the exact Grand Ave OCR/Accessibility text variants and
verify only one atomic Reject reservation can win.
