# DD Offer Monitor Native v1.1.1

这是完全独立的 Android 原生 AccessibilityService 版本，不依赖 NovaFlow / Auto.js，不需要卡密，也不申请 INTERNET 权限。

## 初衷 / 工作流程

D1 → D2 → … → D7 循环轮询 → 金额预筛 → 仅对达到最低金额的订单打开详情 → 读取 miles → 计算 $/mi → 不合格返回继续 → 合格立即声音 + 震动 + 通知 + Accessibility 悬浮提醒 → **停止所有自动操作** → 用户在 Dasher 内手动点击最终 Claim。

最终 `Claim and schedule` / `Claim` / `Acknowledge` 被视为受保护动作，代码不会自动点击。

## v1.1.1 核心

- 仅处理 `com.doordash.driverapp` 前台窗口。

- **日期栏兼容增强**：不再只认 Android `Button`，同时识别顶部可点击/选中/checked 的 Compose/TextView 语义节点；按 Y 行聚类、去重、评分，再按 X 排序为 D1–D7。
- **日期切换二次确认**：点击日期后必须看到 Accessibility tree / selected 状态真实变化；否则记录 `DATE_STATE_TIMEOUT`，不会把“点击返回 true”当成切换成功。
- **详情打开防竞态**：打开订单卡后设置短事务窗口，等待真正进入详情；在详情尚未出现时不会误触下一日期/下一卡，超时记录 `DETAIL_OPEN_TIMEOUT`。
- **返回防竞态**：不合格订单返回后给 UI 一个很短的稳定窗口，避免旧详情残留导致重复判断。
- **诊断日志增强**：日期行找不到时记录顶部可交互节点文本/类名/坐标/selected 状态，方便直接针对三星 DD 实际控件树调优。
- Accessibility 事件驱动扫描 + 550ms 看门狗兜底；同一页面状态不会高速重复点击。
- 一次 scan 只建立一个 Accessibility 树快照。
- 7 天默认全部开启，可单独勾选。
- 日期行按屏幕顶部候选按钮/可点击节点聚类并按 X 坐标排序。
- 金额节点严格匹配 `$xx.xx`，先做 minPay 预筛。
- 详情页解析 `mi / mile / miles`，计算 `$ / mi`。
- minPay / maxMiles / min $/mi 三层筛选。
- 不合格订单 cooldown 去重，避免反复打开同一张。
- 点击优先语义 ACTION_CLICK；无可点击父节点时才使用当前新鲜节点坐标的 Accessibility gesture。
- 页面变化/动作节流，避免 busy loop、连点和重复动作。
- 合格后 `manualPending=true`，自动点击、返回、日期轮询全部冻结。
- 手动 Claim 后仅观察明确成功/失败；无明确结果记 `MANUAL_RESULT_UNVERIFIED`，不假报成功。
- 完整本地日志：`Android/data/com.ddoffermonitor.app/files/dd_offer_monitor.log`。
- 无 Root、无 Hook、无注入、无设备指纹修改、无隐藏 Accessibility、无随机伪装。

## 首次使用

1. 安装 APK。
2. 打开应用 → 打开无障碍设置 → 启用 **DD Offer Monitor**。
3. 先点“测试声音 + 震动 + 通知”。
4. 设置金额/里程/$/mi，保存并开启监控。
5. 打开 Dasher 的 Offers/预约页面。

> 由于 DoorDash UI 可能按账户/版本变化，首次真机运行重点核对日期栏、金额卡片和详情 miles。日志会记录每一步，用于继续针对你的三星界面调优。


## v1.1.2
- 修复 Android 11+ 包可见性导致“未找到 Dasher”的假提示。
- Android 13+ 优先使用不受包可见性限制的 getLaunchIntentSenderForPackage。
- 日期识别补充中文“星期/周X”语义。


## v1.1.3
- 针对 DoorDash Schedule/Offers 日期栏：可从不可点击的 1..31 文本子节点向上寻找真正可点击父容器。
- 增加实时诊断：显示当前前台包、控件数量、是否识别 Offers、日期数量、金额数量。
- 最终 Claim 继续保持人工确认，不自动点击。


## v1.1.4
- 针对三星实机诊断 `Dasher✓ | Offers=true | dates=0` 增加日期栏坐标兜底。
- 只有确认处于 Dasher 的 Schedule/Offers 列表且无最终 Claim 控件时才启用坐标日期切换。
- 日期节点可见时仍优先使用 Accessibility 控件树。
- 坐标模式不会点击 Claim / Claim and schedule / Acknowledge，最终操作继续手动。
- 实时诊断在兜底模式显示 `dates=0(coord)`。
