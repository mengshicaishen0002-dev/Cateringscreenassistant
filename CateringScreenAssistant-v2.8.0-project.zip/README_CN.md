# DD Offer Monitor Native v1.2.4

本版重点：把日期栏“人工接管”做成明确的状态所有权，而不是靠宽泛时间窗猜测。程序会记录自己准备点击的 D1–D7 目标与点击前已选日期；司机如果点到其它日期，会立即取消旧等待、重置未完成轮次并让出控制约 2.2 秒。自动点击后的延迟 `TYPE_WINDOW_CONTENT_CHANGED` 不再被误当成人工操作；如果 selected/checked 仍停留在旧日期，会继续等正常 2.5 秒截止，不会过早误判。空日期页面没有可见变化时记录 `DATE_SETTLE_NO_SIGNAL`，不再假报 `DATE_STATE_TIMEOUT`。最终 Claim 仍必须手动。

# DD Offer Monitor Native v1.2.1

这是完全独立的 Android 原生 AccessibilityService 版本，不依赖 NovaFlow / Auto.js，不需要卡密，也不申请 INTERNET 权限。

## 初衷 / 工作流程

D1 → D2 → … → D7 循环轮询 → 金额预筛 → 仅对达到最低金额的订单打开详情 → 读取 miles → 计算 $/mi → 不合格返回继续 → 合格立即声音 + 震动 + 通知 + Accessibility 悬浮提醒 → **停止所有自动操作** → 用户在 Dasher 内手动点击最终 Claim。

最终 `Claim and schedule` / `Claim` / `Acknowledge` 被视为受保护动作，代码不会自动点击。

## v1.1.1 核心

- 仅处理 `com.doordash.driverapp` 前台窗口。

- **日期栏兼容增强**：不再只认 Android `Button`，同时识别顶部可点击/选中/checked 的 Compose/TextView 语义节点；按 Y 行聚类、去重、评分，再按 X 排序为 D1–D7。
- **日期切换二次确认**：点击日期后必须看到 Accessibility tree / selected 状态真实变化；否则记录 `DATE_STATE_TIMEOUT`，不会把“点击返回 true”当成切换成功。
- **详情打开防竞态**：打开订单卡后设置短事务窗口，等待真正进入详情；在详情尚未出现时不会误触下一日期/下一卡，超时记录 `DETAIL_OPEN_TIMEOUT`。
- **返回防竞态**：不合格订单返回后给 UI 一个很短的稳定窗口，避免旧详情残留导致重复判断。
- **诊断日志增强**：日期行找不到时记录顶部可交互节点文本/类名/坐标/selected 状态，方便直接针对三星 DD 实际控件树调优。
- Accessibility 事件驱动扫描 + 550ms 看门狗兜底；同一页面状态不会高速重复点击。
- 一次 scan 只建立一个 Accessibility 树快照。
- 7 天默认全部开启，可单独勾选。
- 日期行按屏幕顶部候选按钮/可点击节点聚类并按 X 坐标排序。
- 金额节点严格匹配 `$xx.xx`，先做 minPay 预筛。
- 详情页解析 `mi / mile / miles`，计算 `$ / mi`。
- minPay / maxMiles / min $/mi 三层筛选。
- 不合格订单 cooldown 去重，避免反复打开同一张。
- 点击优先语义 ACTION_CLICK；无可点击父节点时才使用当前新鲜节点坐标的 Accessibility gesture。
- 页面变化/动作节流，避免 busy loop、连点和重复动作。
- 合格后 `manualPending=true`，自动点击、返回、日期轮询全部冻结。
- 手动 Claim 后仅观察明确成功/失败；无明确结果记 `MANUAL_RESULT_UNVERIFIED`，不假报成功。
- 完整本地日志：`Android/data/com.ddoffermonitor.app/files/dd_offer_monitor.log`。
- 无 Root、无 Hook、无注入、无设备指纹修改、无隐藏 Accessibility、无随机伪装。

## 首次使用

1. 安装 APK。
2. 打开应用 → 打开无障碍设置 → 启用 **DD Offer Monitor**。
3. 先点“测试声音 + 震动 + 通知”。
4. 设置金额/里程/$/mi，保存并开启监控。
5. 打开 Dasher 的 Offers/预约页面。

> 由于 DoorDash UI 可能按账户/版本变化，首次真机运行重点核对日期栏、金额卡片和详情 miles。日志会记录每一步，用于继续针对你的三星界面调优。


## v1.1.2
- 修复 Android 11+ 包可见性导致“未找到 Dasher”的假提示。
- Android 13+ 优先使用不受包可见性限制的 getLaunchIntentSenderForPackage。
- 日期识别补充中文“星期/周X”语义。


## v1.1.3
- 针对 DoorDash Schedule/Offers 日期栏：可从不可点击的 1..31 文本子节点向上寻找真正可点击父容器。
- 增加实时诊断：显示当前前台包、控件数量、是否识别 Offers、日期数量、金额数量。
- 最终 Claim 继续保持人工确认，不自动点击。


## v1.1.4
- 针对三星实机诊断 `Dasher✓ | Offers=true | dates=0` 增加日期栏坐标兜底。
- 只有确认处于 Dasher 的 Schedule/Offers 列表且无最终 Claim 控件时才启用坐标日期切换。
- 日期节点可见时仍优先使用 Accessibility 控件树。
- 坐标模式不会点击 Claim / Claim and schedule / Acknowledge，最终操作继续手动。
- 实时诊断在兜底模式显示 `dates=0(coord)`。


## v1.0.75
- 移除 v1.1.4 的固定日期坐标兜底，改为移植 NovaFlow 已验证的 Accessibility 日期行算法。
- 优先收集 `android.widget.Button`，按 Y 轴分组并寻找横向 7 个按钮的日期行，不要求按钮自身有 8/9/10 文本。
- 点击使用实时 Accessibility Button 的 bounds 中心，不是固定屏幕坐标。
- 兼容几像素的 Y 偏差，并校验 7 个按钮的横向跨度/间距，减少把 Offers/Dash/My schedule 等其它按钮行误判为日期行。
- 实时诊断识别成功时显示 `dates=7(button-row)`；如果语义日期文本可用则显示 `dates=...(semantic)`。
- 最终 Claim / Claim and schedule / Acknowledge 继续保持人工操作。


## v1.1.6
- 增加可拖动 Accessibility 悬浮控制窗：运行状态 + 暂停/继续 + 停止。
- 主界面同步增加暂停/继续/停止按钮；启用开关变更立即生效，不必先保存才能停止。
- 日期切换后至少等待 0.75 秒；优先确认 Accessibility 页面 fingerprint 变化，最长 2.5 秒后释放，避免读到上一天旧内容。
- 每轮扫描结束按空轮次数自适应休息 5 / 8 / 10 秒；发现任何订单后恢复较短轮休。
- 暂停/停止状态会拦截日期点击、详情点击、返回和 gesture，避免已有延迟任务继续操作。
- 严格 Offers 页面门控：不再自动从其它 Dasher 页面跳入 Offers；只有当前页面被明确识别为 Schedule → Offers 才执行轮询。
- 仍然不会自动点击 Claim / Claim and schedule / Acknowledge。


## v1.1.7
- 合格单提醒增加独立的声音/震动开关，默认开启。
- 增加“监控时保持屏幕常亮”开关，默认开启；通过 Accessibility 悬浮窗的 `FLAG_KEEP_SCREEN_ON` 实现，不新增联网或后台唤醒权限。
- 悬浮窗显示当前本轮进度和 D1–D7 游标，并记住用户拖动后的悬浮位置。
- 合格单系统通知可点击回到 Dasher，最终 Claim 仍由用户手动完成。
- 主界面可直接查看最近 60 条日志、清空日志，不必进入 Android/data。
- 日志超过约 1MB 自动轮转到 `dd_offer_monitor.log.1`，避免长期运行无限增长。
- 保持 v1.1.6 已验证的 NovaFlow 风格 7-Button 日期识别、0.75–2.5 秒页面稳定等待和 5/8/10 秒自适应轮休。

## v1.2.0（长期运行 / 低干扰稳定版）

v1.2.0 不再追求单纯缩短点击间隔，而是把“少漏单、少重复动作、出现异常就停、用户操作优先”作为核心。

- **内容指纹去重**：订单身份改为 D1–D7 + 金额 + 卡片附近文本摘要，不再依赖卡片 Y 坐标；同一订单在短时间内不会被反复打开。
- **不合格详情缓存**：已经因为 miles / $/mi / 解析失败返回的订单短期缓存，避免下一轮又重复进入详情。
- **轮休事件唤醒**：5/8/10 秒轮休期间仍以低频方式待机；若 Accessibility 明确报告页面内容变化，并且页面 fingerprint 确实改变，则提前结束轮休检查新内容。
- **人工操作让行**：识别到用户在 Dasher 内手动点击/滚动时，自动操作短暂停 1.8 秒，避免和手指抢控制权；程序自己的 Accessibility 事件会被排除。
- **观察模式**：只读取当前 Offers 页面和记录日志，不自动切日期、不打开详情。DoorDash App 更新后可先用此模式确认页面结构。
- **安全暂停**：连续日期栏识别失败、连续日期点击失败，或检测到登录/身份验证类页面时，立即暂停并通知，不无限重试或乱点。
- **运行统计**：记录完成轮次、扫描日期、唯一 Offer、详情打开、金额/里程/$/mi 过滤、解析失败、合格单、Claim 成功/失败/未确认、安全暂停、轮休提前唤醒，以及从首次看到 Offer 到判定合格的耗时。
- **合格单冻结**：达到条件后继续保持全自动动作冻结，最终 `Claim and schedule` / `Claim` / `Acknowledge` 仍只允许人工操作。
- **固定签名接口预留**：`app/build.gradle` 已支持 `DD_KEYSTORE_PATH / DD_KEYSTORE_PASSWORD / DD_KEY_ALIAS / DD_KEY_PASSWORD` 环境变量。未配置时继续使用普通 debug 签名；配置 GitHub Actions Secrets 后可切换为固定签名。私钥不应提交到公开仓库。

### v1.2.0 推荐运行方式

默认使用“稳定模式”。只有 DoorDash 刚升级、日期栏识别异常或需要排查时才勾选“观察模式”。如果出现安全暂停，先看实时诊断/最近日志，确认页面恢复为 `Schedule → Offers` 后再点“继续”。


## v1.2.1 手动接管修复

- 修复 v1.2.0 中“用户手动点击时可能不让出控制”的问题。
- 根因：旧版把自动点击后的 1.8 秒全部视为自身事件；日期轮询频繁时，用户点击很容易落在这个窗口内而被忽略。
- 新版只在最近自动点击目标的同一 bounds、且约 650ms 内才判定为自身 click。
- 用户 click/scroll 会让出约 2.2 秒，并取消旧的日期切换等待状态；恢复时从当前页面重新读取。


## v1.2.4 针对现场视频/日志的修正
- 日期扫描默认 550ms；建议 500–600ms，可在主界面 500–1500ms 调整。
- 空日期不再固定等到约 2.5 秒；检测到真实的日期页内容事件并稳定后可快速进入下一天。
- 页面状态不确定时仍保留短额外确认，避免直接读取上一天的旧订单卡。
- 缩短自动日期点击的“归属窗口”，减少把你后续手动日期点击吞成程序自己的事件。
- 增加整条日期栏 parent-click 识别；Dasher 若把手动点击事件挂在整个日期栏父节点上，也会触发人工让出。


## v1.2.4
- 人工接管改用 Android 系统 `TYPE_TOUCH_INTERACTION_START/END` 作为第一优先信号；不再依赖 Dasher 日期按钮是否正确上报 click/selected。
- 手指一碰 Dasher 即暂停自动动作；手指离开后继续让出约 2.2 秒，再从当前页面重新读取。
- 原有日期 click/selected/scroll 推断保留为兼容兜底。
- 空日期无状态信号时，550ms 设置下通常约 650–670ms 进入下一天；若上一日期有订单内容，则保留更长保护等待，避免读到旧卡片。


## v1.2.4 人工接管修复

- 不再把“是否人工点击日期”主要建立在 DoorDash 日期控件是否上报 `TYPE_VIEW_CLICKED/SELECTED` 上。
- 直接订阅 Android 系统的 `TYPE_TOUCH_INTERACTION_START/END`：手指一碰屏幕，只要 Dasher 是当前前台，就立即让出自动控制。
- Accessibility 配置不再用 packageNames 在系统层过滤事件；普通事件仍在代码第一层严格只处理 `com.doordash.driverapp`。这样系统级触摸事件不会因为没有 view package 而丢失。
- 人工触摸期间以及抬手后的 2200ms，日期点击、打开详情和延迟返回动作全部被统一动作闸门阻止。
- 日志验证关键词：`TOUCH_EVENT_SUBSCRIPTION`、`USER_TOUCH_START`、`USER_INTERACTION_HOLD`、`USER_TOUCH_END`。
