# v2.10.12 audit — first effective claim + processing-state retry

Field trace reviewed: a qualified $73.83 / 2.0 mi offer reached the correct Accept rectangle, but the first path spent an extra semantic ACTION_CLICK observation before the 55 ms gesture. After the gesture, DeliverThat disabled the Accept button, proving the gesture reached the control, yet attempts #2/#3 were consumed while the button was still disabled and therefore never became real retries. An earlier OCR frame also showed a stale serial lock causing a one-cycle delay before the same top card was actioned.

## Changes

- First qualified claim uses the verified 55 ms gesture directly; semantic ACTION_CLICK is removed from the latency-critical first attempt.
- `inspectClaim()` checks `acceptEnabled` before calling `dispatchClaim()`. Disabled/processing polls do not call `ClaimBudget.reserve()`.
- Processing state is polled every 95 ms for up to 16 checks (~1.5 s) so a button that re-enables after a backend failure gets a real attempt #2.
- The first-card OCR action row may retire a stale serial lock and continue in the same OCR callback, avoiding a full extra scan cycle.
- Recent DeliverThat Accessibility events/root text are searched for claim outcome hints and attached to success/unknown diagnostics.

## Invariants retained

- Only the first visible offer card can be actioned.
- Accept must remain in the verified right-side action rectangle; Ignore must remain in the left-side action rectangle.
- Whole-card/detail containers are never used as action targets.
- Gesture completion is not acceptance confirmation. Jobs or explicit accepted/assigned evidence is required.
- If the offer disappears without positive evidence, the result remains unknown rather than being reported as a win.
