# v2.10.27 First-Shot Fast Lane

- Pay/mileage/city/time rule values and semantics are unchanged.
- The semantic Accept/Claim index remains the first action path.
- If the indexed action ancestor exposes pay+miles but not every field required by the current configuration, the app scans only a plausible ancestor subtree for the same current card (96-node hard budget) before falling back to the global bounded tree/OCR.
- The local subtree is anchored to the exact side-specific action row and excludes descendants below that row.
- Whole-page/list ancestors are rejected as local-card roots to prevent adjacent-card contamination.
- Evidence requirements are read from the active configuration only: Pasadena or a non-empty city filter requires location evidence; a configured time window requires offer-time evidence. No threshold inference or bypass is used.
- Existing 80ms monitor interval, 55ms first gesture, serial top-card lock, live revalidation, retry protection and Accept/Reject transaction ownership remain unchanged.
