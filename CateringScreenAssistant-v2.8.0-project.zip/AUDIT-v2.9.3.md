# Catering Screen Assistant v2.9.3 audit

## Failure reproduced from the 2026-09-08 log
The rejected card was parsed correctly (`$32.40 / 2.8 mi`) and OCR had a Reject/Decline coordinate, but v2.9.2 still called the Accessibility-only reject verifier. Because this DeliverThat build did not export that visible reject control as an actionable Accessibility node, the verifier returned `目标位置未找到可见且启用的Ignore/Decline/Reject` and refused the click.

## v2.9.3 changes
- **Critical reject fix:** fresh OCR/visual Reject coordinates now use the same foreground/page/freshness-checked gesture fallback already used by Accept. Accessibility semantic click is still preferred when a real node exists.
- **Action-row pairing:** if Reject text is missed but a right-side Accept anchor exists, infer the paired left action center by symmetric row geometry. The reverse direction is also supported for eligible cards when only a left Reject label is readable.
- **Accessibility-first expansion:** scan the active DeliverThat tree plus additional DeliverThat interactive windows; do not prune descendants just because an intermediate WebView/Compose node reports `isVisibleToUser=false`.
- **Structural tree expansion:** retain wider actionable ancestors and climb up to six levels to locate ACTION_CLICK/clickable parents.
- **Safer OCR fallback:** fresh screen-coordinate actions use semantic nodes only when the semantic label matches. Ambiguous structural ancestors are not clicked; the exact fresh coordinate gesture is used instead.
- **Latency:** enhanced OCR no longer runs merely because one action word is missing when a visual or opposite-side action anchor already exists. This avoids the previous ~300–700 ms unnecessary second pass.
- **Diagnostics:** tree summary now reports scanned DeliverThat window count in addition to text/clickable/semantic-action counts.
- Accessibility event intake widened to `typeAllMask` for the DeliverThat package, while the 90 ms independent fast heartbeat remains.

## Safety / correctness invariants
- No action if DeliverThat is not the active foreground package.
- No coordinate action on positively identified Jobs or Ignored pages.
- Screen-evidence coordinate actions expire after 1 second.
- If Accessibility exposes both money and miles, they must agree with OCR before a semantic action is clicked.
- Rule evaluation remains card-specific; Pasadena rules only apply when the card text actually contains Pasadena.

## Regression
Pure-Java regression suite: **225 cases** (including 10 new action-row geometry cases), all passing locally before packaging.
