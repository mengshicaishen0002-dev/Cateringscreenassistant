# Build installable APK

This project includes `.github/workflows/build-apk.yml`.
The workflow builds an Android debug APK using JDK 17, Gradle 8.9, Android SDK 35 and Build Tools 35.0.0.

Output filename:
`CateringScreenAssistant-v2.8.0-Galaxy-A15-Android16.apk`

The debug APK is automatically signed by the Android build system and can be sideloaded directly onto the target Samsung Galaxy A15 5G running Android 16.
