# 2.4.0 — local click-path optimization and correctness fixes

## Changes
- Accessibility event notification timeout: 50 to 10 ms. This is a configured delay, not an end-to-end latency measurement.
- Coalesce queued fast checks and collect current text/button bounds in a single traversal.
- Revalidate the foreground package and full fast-path text immediately before clicking. Retries require unchanged text.
- Separate Ignore from Accept dispatch. Old shared code could invoke Accept during an Ignore request.
- Use current labelled button bounds, never an inferred mirrored Ignore coordinate. Missing labels stop the action.
- Do not click arbitrary clickable ancestors of a button label.
- Route OCR results through the worker, ignore stale results during click cooldown.
- Keep the 15-second cooldown after the three-attempt burst; do not reset it merely because the offer remains visible.
- Missing Accept now reports an unknown result, not a disappeared/successful order.
- Fast-path notification reports local decision-to-click-feedback elapsed time, explicitly not server confirmation.

## Limits and validation
Build/signature/package alignment checks do not validate operation on a Samsung phone or confirm platform acceptance. No real order was accepted during testing.
Multiple visible numeric offers with conflicting amounts/distances are blocked by live validation. Text changes can intentionally stop retries.
OCR-only buttons with no corresponding readable accessibility label will not be clicked in this release. This prioritizes avoiding misclicks; it is not a guarantee of compatibility.
The app still has no reliable server acknowledgement or automatic Jobs identity verification. Check Jobs for actual receipt.
Normal/Pasadena rules and saved preferences are retained. Restart monitoring after installing; first validate on test mode, then disable test mode only after verifying recognized fields and target buttons.
