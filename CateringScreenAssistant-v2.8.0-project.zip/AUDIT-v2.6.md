# v2.6.0 — performance and stale-work corrections

Changes from 2.5.0:
- Fast snapshot collects page flags, action bounds and card text in one hierarchy walk rather than four. Final live verification remains separate.
- Frame throttling now precedes hierarchy reads. Accessibility events remain immediate/coalesced; 250ms fallback polling remains.
- When accessible card processing works, redundant OCR is suppressed for 500ms. Older OCR completions cannot reset the active accessibility decision during this window.
- Reject countdown posts a fresh read at 1s instead of relying only on future frames. No changing countdown notification per tick.
- Notification/history IO runs on one dedicated bounded writer (256 pending jobs; oldest discarded on overload). History remains 100 records. Decision timestamp is captured before logging enqueue.
- OCR results older than 1s and queued clicks older than 1s are discarded. Live page/card/button validation still applies.
- Fast rejection now verifies full card identity before tapping, in addition to amount/miles. OCR cross-source validation remains numeric and labelled-position based; this is a remaining limitation.
- Logs show queue wait, hierarchy-read time, and decision-to-record time. These do not measure time since the server published an offer and do not confirm acquisition.

Validation:
- 74 pure-Java regression assertions: button labels17, card isolation9, rejection sequence7, page guards32, scan timing9.
- Release build, APK signing verification and alignment checked before distribution.
- No attached Samsung/emulator or live DeliverThat session; actual acceptance, backend outcome, end-to-end speed and the observed 15-minute gap have NOT been reproduced or verified.

Remaining limits:
- Semantic ACTION_CLICK/gesture completion is only a local acknowledgement. Jobs/server confirmation is still manual.
- Three bounded same-card acceptance attempts remain; 15s acceptance cooldown remains.
- OCR and decision handling still share a worker; changes reduce work but do not guarantee a latency ceiling for Android accessibility Binder calls.
- No access to Hawk source or verified comparison benchmarks. No guaranteed successful claim or sub-second end-to-end claim.
- Review actual phone logs after installation; maintain Offers foreground and existing permissions/rules.
