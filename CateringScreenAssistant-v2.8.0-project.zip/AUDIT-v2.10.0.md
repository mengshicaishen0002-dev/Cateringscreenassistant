# v2.10.0 reliability audit

This release changes the architecture instead of adding another OCR heuristic.

## Failure identified from the 2026-09-08 live video
The offer remained visible for more than six seconds with Ignore/Accept clearly on screen. Two design gates could leave the app completely idle:

1. The Accessibility fast path was owned by `OcrMonitorService`; if MediaProjection was not running (for example after an APK update), Accessibility events returned without any decision loop.
2. A visible Accessibility text node for `Accept` / `Ignore` could have valid screen bounds but no clickable ancestor. v2.9.x stored the bounds, then rejected the action because `actionNodeReady()` was false or `findActionNode()` returned null. This defeated the coordinate-gesture fallback.

## v2.10 changes
- AccessibilityService now has an independent 110 ms heartbeat and can process offers without MediaProjection/OCR running.
- Visible Accept/Ignore bounds are actionable evidence even if the node itself is not clickable.
- Fast selection no longer requires `acceptEnabled/rejectEnabled`; non-empty live bounds are enough to enter the verified action path.
- `tapVerified()` now revalidates DeliverThat foreground, Offers page, stable card identity, amount and mileage, then dispatches a coordinate gesture if no semantic clickable node exists.
- UNKNOWN page may be read as an offer only when the tree contains money + mileage and a real action-row structure. Final clicking still requires the normal live verification.
- OCR/blue-button detection remains a fallback, not the primary engine.
- Fixed upgrade signing retained.

## Regression
Pure Java regression suite remains green (225 cases).
