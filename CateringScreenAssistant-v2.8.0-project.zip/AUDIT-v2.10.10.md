# v2.10.10 audit — stable order identity + countdown-safe serial lock

## Field issue reproduced
The same real `$36.25 / 2.9 mi` Lazy Dog offer appeared in adjacent reads with different raw OCR/accessibility strings and therefore different old card hashes (`#1adeeee1` then `#35fefc5a`). The old identity was the entire normalized card string, so duplicated address nodes, `Est.` reordering, or transient descriptive-node changes could reset RejectSequence/serial state and make one order look new.

## Changes

1. **Stable fingerprint replaces raw whole-text hash.**
   - Primary fields: low-end pay, miles, scheduled `Today/Tomorrow at HH:MM AM/PM`, and merchant/location core.
   - Full addresses and duplicated repeated card descriptions are excluded from the primary merchant key.
   - If required numeric fields are missing, the code falls back to normalized descriptive content instead of collapsing unrelated partial frames.

2. **One identity is reused across all stateful paths.**
   - Serial first-card lock.
   - Reject retry sequence.
   - Claim attempt budget.
   - Qualified-offer alert de-dupe.
   - Fast-card duplicate filtering and decision-log `卡片#` IDs.

3. **Action revalidation is stricter where it matters.**
   - Money and miles remain exact.
   - If both frames expose scheduled time, a time change is a different order.
   - If both expose merchant core, a merchant change is a different order.
   - Duplicate/missing address/accessibility nodes are tolerated.

4. **Disabled/countdown buttons no longer trigger OCR fallback clicks.**
   - A disabled top Accept or Ignore keeps the current first-card lock.
   - OCR coordinate action is suppressed while that state is visible.
   - This closes the path where a transient disabled Accessibility node could still be clicked via OCR.

5. **Reject retry cadence is less aggressive.**
   - Retry wait increased from 900 ms to 1400 ms.
   - First click remains immediate; only repeated taps on the same stable fingerprint are delayed.

## Safety invariants retained
- DeliverThat foreground/package verification.
- Jobs/Ignored page blocking.
- Strict first visible card only.
- v2.10.8 left/right anti-card-container geometry.
- v2.10.9 stale-snapshot bounded refresh.
- Card disappearance is not acceptance success without positive Jobs/accepted evidence.

## Regression coverage
- Real Lazy Dog OCR/accessibility variants produce the same stable identity.
- Duplicate full-card descriptions produce the same identity.
- Different merchant and different pickup time remain different identities.
- Scheduled-time changes fail action revalidation.
- Reject retry remains locked for 1400 ms.
