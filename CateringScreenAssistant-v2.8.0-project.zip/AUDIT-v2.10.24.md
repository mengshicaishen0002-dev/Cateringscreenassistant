# CateringScreenAssistant v2.10.24

Field-driven post-action state-machine fix from the September 10 Reject traces.

## Confirmed failure in v2.10.23
- A rejected offer could correctly enter `Reject disabled/processing` and disappear from Offers, but the shared serial transaction was later sent through the Accept confirmation path.
- That produced a false message asking for Jobs/claim-success evidence after a Reject and classified a successful reject as an unknown claim result.
- Accept-only success signals such as Jobs badge changes and assigned-job detail text therefore needed to be isolated from Reject transactions.

## v2.10.24 fixes
- Adds an explicit serial action type: `ACCEPT`, `REJECT`, or `NONE`.
- Jobs badge / Delivery Timeline / Dropoff Instructions confirmation now runs only for `ACCEPT` transactions.
- Reject dispatch now starts a dedicated Reject transaction and invalidates stale Accept inspectors.
- Adds a dedicated `inspectReject` confirmation path. It never consults Jobs or assigned-job evidence.
- Reject disappearance requires two consecutive missing reads to avoid treating a transient blank Accessibility frame as success.
- If the card disappears after prior `Reject disabled/processing` acknowledgement, records `REJECT_SUCCESS` and immediately unlocks the next top offer.
- If the card disappears without that acknowledgement, records `REJECT_UNKNOWN` rather than misclassifying it as a failed/unknown Accept.
- A newly observed top offer also closes the old Reject transaction immediately, using the prior processing acknowledgement to classify success.
- Reject dispatch failure clears only the matching Reject serial transaction and preserves future scanning.
- Existing semantic ACTION_CLICK -> lightweight same-card/status recheck -> Gesture90ms fallback remains intact; the fallback is not sent when the Reject control has already disabled or the top card changed.

## Regression
- Added `RejectConfirmationTest` covering same-card visibility, two-read disappearance confirmation, confirmed reject, and unknown reject cases.
- Existing regression suite and real-device integration invariants pass.
