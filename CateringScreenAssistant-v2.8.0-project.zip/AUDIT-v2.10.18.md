# v2.10.18 audit — first-card latency reduction

## Field evidence
The v2.10.17 Galaxy A15 log showed a complete Accessibility decision taking about 499 ms before the rule result was recorded. The same trace also duplicated the visible card text, consistent with the active Accessibility window being walked once via getRootInActiveWindow() and again via getWindows(). For competitive offers, this latency is material.

## Changes
1. Added a bounded active-window **quick top-card** pass (max 180 nodes). It isolates the first visible money+miles pair and only accepts an action row whose numeric pair matches that top pair.
2. When the quick pass has all rule-relevant evidence, a qualified first card can go straight to the existing verified 55 ms Accept path instead of waiting for the full multi-window tree scan.
3. If Pasadena/city logic is enabled, quick execution requires pickup-location evidence (`CA`/California address marker). If a time filter is configured, quick execution also requires a parsed Today/Tomorrow time. Incomplete quick text falls back to the full scan/OCR rather than being rejected.
4. Full multi-window scans no longer traverse the active window a second time when Samsung returns that same window from getWindows(). Secondary DeliverThat windows are still scanned.
5. The verified first Accept dispatch is posted at the front of the assistant service main queue to reduce avoidable handler delay; the existing amount+miles, page, geometry and enabled-state checks are unchanged.
6. Timing logs now show `快速树...ms；首卡直达` for the low-latency path, or `快速树...ms；完整树...ms` when fallback is required.

## Safety invariants retained
- DeliverThat must be foreground.
- Explicit Jobs/Ignored pages block actions.
- Only the first numeric offer is eligible for the quick action row.
- Exact amount+miles still drive rule evaluation and stale verification.
- Pasadena/city/time-sensitive decisions cannot execute from incomplete quick text.
- Whole-card/full-row/detail targets remain rejected by ActionGeometry.
- Gesture completion is not treated as acceptance confirmation.
