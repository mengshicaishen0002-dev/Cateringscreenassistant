# v2.10.1 field-failure audit

Observed real-device failures on Galaxy A15:

1. `$76.45 / 21.6 mi`: Reject coordinate inferred, then `OCR/视觉证据已超过1秒；取消旧点击`. Accessibility tree read reported 785 ms and zero readable cards.
2. `$20.00 / 6.1 mi`: Reject coordinate inferred, initial freshness passed, then `屏幕坐标在点击前已过期；重新识别`. Tree read reported 394 ms and zero readable cards.

Root cause: the 1,000 ms freshness deadline started at frame acquisition, while OCR plus repeated full Accessibility tree traversals consumed most/all of that budget. The coordinate fallback then repeated a semantic/action-node tree search even though the fast Accessibility path had already failed to expose a card.

v2.10.1 changes:

- Separate OCR-result freshness (1.2 s) from verified coordinate action freshness (2.2 s).
- Coordinate fallback no longer repeats the full multi-window Accessibility scan or semantic action-node search.
- Immediately before gesture: verify DeliverThat foreground package, coordinate inside active root, and run a bounded <=90-node page probe. Positive JOBS/IGNORED blocks the gesture; UNKNOWN may proceed only because the caller already supplied money+miles+action-row OCR/visual evidence.
- Full-tree safety heartbeat changed from 90 ms to 900 ms. Accessibility change events still trigger immediate scans.
- OCR frame/evaluate path uses the recent page hint rather than running another full tree scan.
- Inferred Reject records include frame age for field diagnosis.

Pure-Java regression suite: 229 cases. Android compilation still occurs in GitHub Actions.
