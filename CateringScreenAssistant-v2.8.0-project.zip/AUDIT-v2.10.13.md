# v2.10.13 audit — visible-offer action stall recovery

## Field failure

A DeliverThat offer remained visibly at the first position for multiple seconds with active Ignore/Accept controls but no action. The failure mode was consistent with an old transaction state surviving after the previous card: `serialTopText`, global `cooldownUntil` / `accessibilityActionHoldUntil`, or a delayed `inspectClaim()` callback could keep the new top offer from reaching the action path. A particularly bad case occurs when Accessibility temporarily cannot read the top card: the serial queue correctly refuses to unlock from an empty read, but the same action cooldown could also suppress OCR, removing the only safe mechanism able to prove that a new card had taken the first slot.

## Fixes

- Added sparse rescue OCR probes while a stale action gate is active. These probes do not bypass Jobs/Ignored/foreground guards.
- Top replacement requires two stable OCR frames (minimum 70 ms span) before an old serial lock is retired.
- Retiring an old lock invalidates all pending claim-inspection callbacks with an atomic epoch and clears only the old transaction's transient timing gates.
- Accessibility empty-top reads no longer create a permanent blind state; after the arm window they explicitly enable OCR recovery.
- Same-card hard-stall recovery releases cooldown/action-hold only. It does not erase the serial identity, reject sequence, or claim-attempt budget.
- Added `ACTION_STALL_RECOVERY` diagnostics for stale-lock, stale-gate, and same-card hard-wait recovery.

## Safety invariants retained

- Only the first visible offer may be actioned.
- A single mixed OCR frame cannot move the serial lock.
- Accept and Ignore geometry guards remain unchanged.
- Jobs and Ignored pages remain hard action blockers.
- Gesture dispatch is not treated as acceptance success.
- Rescue logic is disabled for dry-run's intentional cooldown.
