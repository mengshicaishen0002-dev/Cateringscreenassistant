# Catering Screen Assistant v2.9.0 Audit

## Why v2.8 could still miss offers

1. **OCR starvation**: when Accessibility could read an offer card but could not expose an actionable Accept node, v2.8 kept refreshing `lastReadableFastScan`. That permanently delayed OCR, so the fallback never got a chance to act.
2. **OCR was not a true fallback**: even after OCR found the Accept coordinates, the click path still required an Accessibility Accept node and an Accessibility page classification of OFFERS. On app/WebView builds that hide the button from Accessibility, OCR could detect the offer but could never click it.
3. **OFFERS page false UNKNOWN**: DeliverThat does not always expose the Offers tab as selected. Empty Offers pages and some offer-card states could therefore remain UNKNOWN.
4. **One worker queue**: Accessibility scans, OCR bookkeeping and retry timing shared one HandlerThread. A heavy screenshot/OCR operation could delay a time-sensitive Accessibility event.
5. **Bad visible card could delay a good visible card**: the old priority processed an ineligible top card before a qualifying lower card.

## v2.9 fixes

- Dedicated high-priority `offer-fast` HandlerThread for Accessibility decisions and retries.
- 90 ms heartbeat plus immediate event-triggered scans.
- OCR runs independently on its original worker thread.
- Readable-but-unactionable Accessibility cards now explicitly release OCR fallback instead of suppressing it.
- OCR is permitted while Accessibility page state is UNKNOWN, but only while DeliverThat is foreground and Jobs/Ignored are not positively identified.
- New **true OCR coordinate fallback**: fresh OCR evidence (Accept + pay + miles + rules pass) can dispatch a verified gesture even if Accessibility hides the action node. If Accessibility does expose numeric fields, they are cross-checked first.
- OFFERS can now be established by selected Offers tab, Accept/Claim, Decline/Ignore/Reject, or `No offers available`.
- Accessibility config includes `flagIncludeNotImportantViews` and zero event coalescing timeout.
- Multiple visible cards: qualifying actionable cards are attempted before spending time declining bad cards.
- Accept semantic click -> fresh gesture retry cadence shortened to ~105 ms; disabled-state checks ~90 ms.
- Stable claim attempt budget can reset after 8 seconds or immediately after the original card disappears, so a later resurfaced job is not permanently blocked.
- OCR default interval changed to 140 ms; Galaxy A15 UI permits 80 ms minimum.
- Wider safe action-label compatibility such as `Accept offer`, `Accept delivery`, `Decline offer`.
- Fixed local signing key introduced in v2.9 so v2.10+ can install over v2.9 without wiping settings.

## Regression

Pure-Java regression suite: **215 assertions/cases passed** before Android CI build.

## Important install note

v2.9 uses the new fixed upgrade signature. Because v2.8 was signed by an ephemeral GitHub runner debug key, Android will require uninstalling v2.8 once before installing v2.9. From v2.9 onward, keep `app/csa-upgrade.keystore` unchanged and future APKs can update in place.
