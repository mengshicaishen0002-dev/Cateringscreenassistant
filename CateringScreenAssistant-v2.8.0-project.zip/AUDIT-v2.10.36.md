# v2.10.36 Reject-Confirm Foreground Priority Audit

## Field evidence
Real-device v2.10.35 traces showed foreground quick-tree latency improved, but old Reject confirmation could still run for 563–2407 ms and spend 226–621 ms in Accessibility while a new $66.67 / 1.8 mi qualified offer was arriving. One Reject gesture fallback also logged 655 ms end-to-end without enough timing detail to identify whether the delay occurred before dispatch or in the callback.

## Changes
- New coherent top card cancels confirmation for a different prior Reject immediately.
- A newly started Accept transaction has explicit priority over all old Reject confirmation work.
- Reject background confirmation uses only the active DeliverThat window with a 90 ms / 72-node quick-tree budget. It no longer calls the multi-window/full-tree `findOffer()` path.
- Background confirmation is capped at 2 probes / 950 ms. A budget timeout is never treated as disappearance.
- Same-card budget stop preserves RejectSequence state; a genuinely different top card receives only the existing short disappearance tombstone.
- Gesture fallback timing is split into preparation, synchronous dispatch call, and callback latency.

## Unchanged
- Accept epoch/fingerprint/success logic and first-shot gesture duration.
- Reject physical ACTION_CLICK/gesture fallback and retry safety gates.
- Large Order popup X guard.
- Pasadena special-rule semantics and every configured threshold.
- 80 ms OCR scan interval and foreground quick-tree v2.10.35 budget.
