# v2.10.17 audit — real Ignore action delivery fix

## Field evidence
Galaxy A15 field logs showed the same ineligible top offer staying visible after two reported Reject gestures. Example: `$21 / 10.0 mi`, card `#78016b8b`, first action used Accessibility bounds `[116,1066,519,1184]` at `(318,1125)` and the second used OCR mirror bounds `[256,1087,376,1159]` at `(316,1123)`. Both `dispatchGesture` callbacks completed, yet DeliverThat did not remove/disable the Ignore control. The supplied video independently shows an ineligible visible offer remaining unchanged for the full recording.

## Root cause
`dispatchGesture(... onCompleted)` only proves Android finished injecting the gesture. It does **not** prove DeliverThat's React-Native control consumed the tap. v2.10.16 logged gesture completion as an action send, but both real-device traces show that this is insufficient for Ignore on the current Samsung/DeliverThat build.

## v2.10.17 changes
1. Reject/Ignore now uses a live Accessibility `ACTION_CLICK` on the verified left action node as the primary path, matching the working NovaFlow-style interaction model.
2. The semantic click is bounded by the same amount+miles verification and anti-card-container geometry guards used by the existing safe action path.
3. Blank-label React-Native controls can be resolved structurally only near the already-verified Ignore rectangle; no fixed screen coordinate is introduced.
4. After `ACTION_CLICK`, wait 160 ms. If the same offer is still on top and Reject remains enabled, issue one 90 ms gesture fallback inside the freshly re-read Reject bounds.
5. The semantic click and its gesture fallback count as **one** `RejectSequence` attempt. Existing two-attempt ceiling and 1100 ms retry budget remain intact.
6. Before the fallback gesture, the current amount+miles and stable offer identity are revalidated so a fast card transition cannot cause the next order to be clicked.
7. Reject logs now state whether the action was `ACTION_CLICK`, `ACTION_CLICK无界面变化→Gesture90ms`, or `ACTION_CLICK不可用→Gesture90ms` instead of treating gesture completion as proof of app response.
8. Accept/claim latency-critical path is unchanged; prior server-side `offer unavailable` evidence showed that the current Accept gesture can reach DeliverThat's claim flow.

## Safety invariants retained
- DeliverThat package/foreground gate.
- Explicit Jobs/Ignored pages block actions.
- First visible offer only; lower cards never leapfrog the top card.
- Exact amount+miles revalidation before fallback.
- Whole-card/full-row/detail-arrow targets remain rejected.
- Card disappearance alone is not accepted-job proof.
