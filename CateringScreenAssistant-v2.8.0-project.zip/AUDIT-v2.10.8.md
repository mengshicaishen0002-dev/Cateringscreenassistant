# v2.10.8 audit — anti-card-container action hardening

## Field failure reproduced from the 2026-09-09 recording
The offer was below the configured rule threshold, so the correct action was Ignore. The app opened the offer detail page instead. The rule decision was correct; the action target was wrong.

Root cause: v2.10.4–v2.10.7 intentionally preferred a larger clickable Accessibility ancestor over a small Ignore/Accept label rectangle. DeliverThat also marks the whole offer card clickable. When that card ancestor replaced the true Ignore rectangle, the gesture landed on the card body and opened details.

## v2.10.8 safety changes
- Semantic Ignore/Accept bounds are never replaced by a larger clickable ancestor merely because the ancestor has more area.
- Every action rectangle is validated against strict left/right button geometry before any gesture.
- Whole-card, full-row and central-container rectangles are rejected.
- Blank-label structural Accessibility nodes are fallback-only and must be button-sized, wide enough to be a real button, confined to one side, and outside the central card band.
- Fast Accept and fast Reject independently re-check rectangle geometry immediately before dispatching the 14 ms gesture.
- OCR Accept/Reject rectangles are also geometry-checked after conversion to full-screen coordinates.
- The slower verified path discards an Accessibility node if its live bounds are card/container-sized.
- Semantic fallback parent climbing may click only ancestors that themselves remain valid button rectangles; it can no longer climb into the offer card.
- Actual gesture X is clamped to a stable interior left/right action column while preserving the verified button Y row.
- Existing strict first-card serial lock, money/miles identity checks, Jobs/Ignored page blocks, claim confirmation, and v2.10.6 low-latency profile remain unchanged.

## Regression coverage
`ActionGeometryTest` now includes the user's real 720×1600 list-button geometry, whole-card geometry, full-row geometry, detail-arrow rejection, detail-screen button geometry, and stable tap-column checks.

Local pure-Java regression suite passed:
- Action geometry: 25
- Alert de-dupe: 4
- Button labels: 21
- Card isolation/identity: 20
- Claim confirmation: 5
- Numeric guard: 6
- Offer/claim-budget: 25
- Page guard: 128
- Reject sequence: 10
- Scan timing: 13

Android runtime/build validation still depends on the GitHub Actions build and the Galaxy A15 real-device test.
