# v2.10.28 Continuous Claim / First-Shot Audit

## Field failures addressed
- Post-success Job Details was being fingerprinted as fresh offers and could receive repeated Accept gestures.
- OCR callbacks that started before a successful/manual claim could complete after the UI transition and create fake cards.
- Real blank-label offers still depended on 170-300 ms ML Kit latency even when Accessibility already exposed the rule fields.
- OCR/card reconstruction could occasionally turn `0.7 mi` into `7 mi`.

## Changes
- Added a post-claim isolation state that blocks only the old accepted-job surface; monitoring never stops and there is no fixed sleep before the next offer.
- Jobs badge increments `0→1→2→3...` invalidate stale OCR immediately and count as independent claim-success evidence, including manual claims.
- Expanded accepted-job detail detection to `Pickup/Dropoff/Delivery Instructions` plus at least two job-only metadata fields (`Approver Name`, `NUID`, `GL String`).
- Added UI-generation + OCR scan-generation invalidation so callbacks from an earlier screen cannot act on the current screen.
- Added same-generation Accessibility decision evidence cache from accessibility events / current card text.
- Added blank-label hybrid first-shot: Accessibility supplies configured-rule fields; the current frame supplies only the blue Accept rectangle; the UI generation is checked again immediately before Gesture55ms.
- Added cross-source decimal correction only when pay + pickup time + merchant identify the same physical card.
- Existing amount/miles/city/time thresholds and rule functions are unchanged byte-for-byte from v2.10.27.

## Safety / continuous monitoring
- Job detail UI cannot authorize Accept.
- Old OCR is invalidated on claim/action transitions.
- A post-claim guard releases only on fresh Offers evidence; user navigation/manual intervention does not stop the monitor.
- No change to the 80 ms scan profile or 55 ms first Accept gesture.
