# v2.10.35 Quick-Tree Tail Latency Audit

## Field evidence
v2.10.34 field logs showed Reject correctness was stable, but the bounded Accessibility quick-tree had rare 200–635 ms spikes while normal passes were roughly 20–80 ms. Async Reject confirmation timing could also display timing from a later foreground card because it read the shared scanTiming string.

## Changes
- Added a 150 ms / 128-node soft budget to the foreground bounded quick-tree fallback.
- If the quick tree exhausts that budget without a coherent first-card decision, skip the full-tree scan for that cycle and immediately yield to the existing OCR fallback.
- Added a 120 ms quick-tree-only backoff after a budget exit. Semantic Accept/Claim indexing remains active, so a newly indexed qualified offer can still dispatch immediately.
- Avoid long-string action-label normalization and gate money/miles/location regex work with cheap lexical checks in the quick traversal.
- Reject async confirmation now owns its own timing record (`Reject确认树 / 探测次数 / 确认总`) instead of borrowing global timing from another card.

## Unchanged
- Accept epoch/fingerprint isolation and Jobs-badge success confirmation.
- Reject transaction/tombstone/retry semantics and direct ACTION_CLICK dispatch.
- Large Order popup X guard.
- Pasadena rule semantics and every configured pay/mileage/city/time threshold.
- 80 ms configured OCR scan interval and established action gesture durations.
