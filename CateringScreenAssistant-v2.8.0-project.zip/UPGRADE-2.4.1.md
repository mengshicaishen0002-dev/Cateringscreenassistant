# 2.4.1 — rejection button compatibility

The screenshot OCR contains `Decline Accept`. OCR already supported Decline, but the live accessibility dispatcher only supported Ignore. Added exact Ignore/Decline/Reject matching to the dispatcher, including isolated button descriptions. Restore and combined Decline Accept labels are deliberately not treated as rejection targets.

Failure callbacks now distinguish missing button, unreadable foreground, changed snapshot text, numeric verification failure, and gesture cancellation/rejection. None of those is automatically reported as a changed order. Rejection callback success is described as click sent, not confirmed platform rejection.

Seventeen standalone Java regression cases exercise rejection labels and unsafe near-matches. No Samsung device or real delivery order was used in validation. Install and runtime compatibility still require on-device confirmation.

The OCR rejection branch now permits a directly detected rejection button as its card anchor when Accept is unavailable. Eligible offers still require a reliably detected Accept button. The OCR crop extends to 92% of screen height instead of 78%, reducing the risk of clipping low buttons. This may increase OCR processing cost; no on-device speed measurement is available. Removed the obsolete mirrored-coordinate rejection fallback.
