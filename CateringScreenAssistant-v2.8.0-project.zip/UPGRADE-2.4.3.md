# 2.4.3 — continuous evaluation after rejection

- While monitoring, re-read the active accessibility window every 250 ms, in addition to page-change events and OCR frames. This provides another evaluation opportunity even when no new frame/event arrives.
- Fast-path ineligible cards now use their own labelled rejection button and the shared one-second observation logic. Snapshots may be rejection-only when Accept is unavailable.
- After a rejection gesture/action callback, schedule a fresh check at 1050 ms. Never replay the old coordinates onto the next card. Normal/Pasadena pay, mileage, city and time settings still apply.
- Track rejection attempts per observed stable card identity: at most three attempts while that identity remains current, at least two seconds apart. A new identity starts a new sequence. Ambiguous/missing accessibility data still requires OCR or causes no click. Hidden cards are not automatically scrolled into view.
- Stopping monitoring removes periodic checks. A successful click callback is not platform acknowledgement; no successful real-device claim/rejection is asserted.

Validation: 17 label cases, 9 multi-card/identity cases, 6 sequence cases; release build/signature/alignment checks. No on-device end-to-end test was available.
