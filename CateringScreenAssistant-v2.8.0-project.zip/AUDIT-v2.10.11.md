# v2.10.11 audit — Accept control response hardening

## Field failure addressed
A qualified `$74.33 / 1.7 mi` offer was recognized in ~97 ms and multiple Android gestures were reported as completed, but DeliverThat never showed a confirmed accepted job. The offer remained visible long enough to show that `dispatchGesture(...).onCompleted()` was not equivalent to the app processing the Accept action.

## v2.10.11 changes

1. **Real Accessibility click first when a true Accept node exists.**
   - Bounded active-window probe (max 180 nodes).
   - Requires exact pay + mileage on the same top action row.
   - Requires the existing v2.10.8 right-button geometry guard.
   - `ACTION_CLICK` is attempted only on the safe semantic node/parent; whole-card ancestors remain forbidden.

2. **UI-response check before gesture fallback.**
   - After an `ACTION_CLICK` returns true, wait 85 ms.
   - If the original Accept disappears or becomes disabled/processing, do not spam another gesture.
   - If the exact same enabled Accept remains, immediately fall back to a 55 ms press on the newly revalidated button rectangle.

3. **Human-length Accept gesture.**
   - First verified Accept gesture is 55 ms instead of the previous 12–14 ms pulse.
   - The press uses the actual verified button rectangle center, not a whole-card/container coordinate.

4. **Retry path rebuilt.**
   - Every retry reacquires the current top-card Accept rectangle and exact numeric pair first.
   - Retry #2: 55 ms center press.
   - Retry #3: 65 ms alternate interior point.
   - A changed/disabled button stops the retry rather than sending a stale tap.

5. **OCR fallback hardened.**
   - OCR/visual Accept fallback now uses a 55 ms gesture.
   - User-visible logs include rect + tap coordinates so the next real miss can distinguish bad geometry from actual competition.

6. **Stable order identity.**
   - Dedupe/claim identity now uses pay + miles + pickup time + merchant key instead of the entire fluctuating OCR/accessibility text.
   - Duplicate address/content-description nodes no longer create a new identity for the same card.

## Safety invariants retained
- DeliverThat package must be foreground.
- Jobs and Ignored pages block action.
- First-card serial lock remains active.
- Pay/miles must match exactly before stale/retry actions.
- Whole-card/full-row clickable ancestors remain forbidden.
- Gesture completion is not treated as claim success; Jobs/accepted-assigned evidence is still required.

## Regression status
- Fast snapshot freshness: 9 cases
- Action dispatch policy: 7 cases
- Action geometry: 25 cases
- Alert dedupe: 4 cases
- Button labels: 21 cases
- Card identity/isolation: 22 cases
- Claim confirmation: 5 cases
- Numeric guard: 6 cases
- Multi-offer/claim-budget: 25 cases
- Page guard: 128 combinations
- Reject sequence: 10 cases
- Scan timing: 13 cases
