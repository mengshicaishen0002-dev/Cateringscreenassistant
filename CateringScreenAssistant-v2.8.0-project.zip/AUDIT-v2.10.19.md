# v2.10.19 audit — silent visible-offer miss

## Field evidence
A ~5 second external video at about 10:30 showed a complete DeliverThat Offers card (3.9 mi, Est. $29–39, Mendocino Farms, Ignore and blue Accept) continuously visible, but v2.10.17 produced no decision-history entry. This proves the failure happened before normal rule/reject logging, not in the dollar/mileage threshold itself.

## Root-cause hardening
1. OCR capture no longer trusts a cached JOBS/IGNORED page hint as a reason to skip the frame. If DeliverThat is the active root, the frame is captured.
2. evaluate() accepts strong current screenshot evidence (money+miles+live action anchor) as an override for a conflicting cached page hint.
3. Accessibility full-tree page classification can recover from a stale selected-tab bit only when current visible tree also contains money+miles and a safe live Accept/Reject action. Restore still blocks the real Ignored page.
4. Bounded quick-page traversal no longer quits when it first sees a stale selected Jobs/Ignored bit. UNKNOWN is used for conflicts so the downstream numeric/action geometry proof decides.
5. If the blue Accept is visible but raw OCR misses both numbers, enhanced OCR is now forced. The old code returned false and could silently abandon exactly such a frame.

## Retained safety
- Actual foreground root must be DeliverThat.
- No click from price/mileage alone. A current action anchor is still required.
- Ignored/Jobs remain blocked unless current offer structure contradicts a stale tab bit.
- Existing amount/miles, city, Pasadena, time, card identity, geometry, stale evidence and retry budgets are unchanged.
