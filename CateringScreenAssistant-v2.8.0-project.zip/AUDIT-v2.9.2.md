# Catering Screen Assistant v2.9.2 audit

## Why this version exists
A real DeliverThat processing log on 2026-09-08 showed an ineligible offer ($25 / 11.8 mi) was parsed, but the app reported `Ignore/Decline/Reject` could not be reliably located. The fast path also reported `可读卡片0`, while OCR took about 982 ms. This means the bottleneck is not amount/distance parsing; it is that the current DeliverThat build can expose offer content in the Android Accessibility tree while leaving action button text/contentDescription blank.

## v2.9.2 strategy
- Accessibility remains the primary path and now works structurally, not only semantically.
- The tree scan collects all visible actionable/clickable nodes, even when their label is blank.
- Offer cards are anchored by money + miles text in the same Accessibility tree.
- Bottom action controls are paired by hierarchy/geometry: same row, same card, left action = reject/decline, right action = accept.
- If one side still exposes a semantic label, structural nodes fill the missing side.
- Before performing any action, the current tree is read again and amount/miles are re-verified against the same card.
- If a semantic action node is absent, the fresh clickable node at the verified structural coordinate is used.
- Offers-page detection no longer depends only on a selected Offers tab or button labels. Strong tree evidence such as `Exclusive ... Offer` or `Expires` + money + miles is accepted.
- Accessibility event coverage adds windows-changed, scroll, click and selected events.
- OCR remains only as a compatibility fallback. The desired fast path no longer requires OCR button text.
- Diagnostic status now reports tree page, text-node count, clickable-node count, semantic Accept count and semantic Reject count when no card is actionable.

## Safety guards retained
- Only `com.deliverthat.driver` may be acted on.
- Jobs / Ignored pages are blocked.
- Amount and miles are verified immediately before action.
- The same card identity must remain stable.
- Existing claim retry budget and rejection sequencing remain active.
- Stable v2.9 signing key is unchanged, so v2.9.2 installs over v2.9/v2.9.1.
