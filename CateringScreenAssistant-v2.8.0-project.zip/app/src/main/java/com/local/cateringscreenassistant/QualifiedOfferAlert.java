package com.local.cateringscreenassistant;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.util.Locale;

/** High-priority local alert emitted once when an offer first passes the user's rules. */
final class QualifiedOfferAlert {
    private static final String CHANNEL = "qualified_offer_alerts_v1";
    private static final String CHANNEL_NAME = "符合条件订单提醒";
    private static final long[] VIBRATION = {0, 220, 120, 220, 120, 450};

    static void sendTest(Context context, SharedPreferences prefs) {
        notifyIfNeeded(context, prefs, "manual-test-" + SystemClock.elapsedRealtime(), 50f, 2f);
    }

    static void notifyIfNeeded(Context context, SharedPreferences prefs,
                               String cardText, float amount, float miles) {
        if (context == null || prefs == null) return;
        if (!prefs.getBoolean("qualifiedAlertEnabled", true)) return;
        if (amount < 0 || miles < 0) return;
        String identity = CardText.identity(cardText);
        long now = SystemClock.elapsedRealtime();
        if (!AlertDedupe.shouldAlert(identity, now)) return;

        float perMile = miles > 0.01f ? amount / miles : amount;
        String title = String.format(Locale.US, "符合条件订单  $%.2f · %.1f mi", amount, miles);
        String text = String.format(Locale.US, "$%.2f/mi · 已通过筛选，正在尝试 Accept", perMile);

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel channel = nm.getNotificationChannel(CHANNEL);
            if (channel == null) {
                channel = new NotificationChannel(CHANNEL, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("金额、里程、城市和时间规则全部通过时立即提醒");
                channel.enableVibration(true);
                channel.setVibrationPattern(VIBRATION);
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                channel.setSound(sound, attrs);
                nm.createNotificationChannel(channel);
            }
        }

        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String detail = compact(cardText);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text + (detail.isEmpty() ? "" : "\n" + detail)))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setTimeoutAfter(20_000)
                .setVibrate(VIBRATION)
                .setSound(sound);
        boolean notificationAllowed = Build.VERSION.SDK_INT < 33
                || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
        if (notificationAllowed && nm != null) {
            // Channel owns sound/vibration on Android O+, preventing duplicate chimes.
            nm.notify(22000 + (identity.hashCode() & 0x0fff), builder.build());
        } else {
            // If notification permission is unavailable, still provide the local alert the
            // user explicitly enabled, without changing the system notification volume.
            try {
                Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
                if (vibrator != null && vibrator.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        vibrator.vibrate(VibrationEffect.createWaveform(VIBRATION, -1));
                    else vibrator.vibrate(VIBRATION, -1);
                }
            } catch (Exception ignored) { }
            try {
                Ringtone tone = RingtoneManager.getRingtone(context, sound);
                if (tone != null && !tone.isPlaying()) tone.play();
            } catch (Exception ignored) { }
        }
    }

    private static String compact(String text) {
        if (text == null) return "";
        String clean = text.replaceAll("\\s+", " ").trim();
        if (clean.length() > 180) clean = clean.substring(0, 180) + "…";
        return clean;
    }
}
