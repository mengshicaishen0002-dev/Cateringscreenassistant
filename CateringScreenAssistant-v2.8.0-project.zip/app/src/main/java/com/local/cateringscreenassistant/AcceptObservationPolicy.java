package com.local.cateringscreenassistant;

/** v2.10.37 same-card observer fence after an Accept gesture has been dispatched. */
final class AcceptObservationPolicy {
    private AcceptObservationPolicy() {}

    static boolean shouldObserveOnly(boolean acceptActive, long acceptStartedAt, long dispatchObservedAt,
                                     String activeCardText, String incomingText) {
        if (!acceptActive || acceptStartedAt <= 0 || dispatchObservedAt < acceptStartedAt) return false;
        if (activeCardText == null || activeCardText.isEmpty()
                || incomingText == null || incomingText.isEmpty()) return false;
        String activeId = CardText.identity(activeCardText);
        String incomingId = CardText.identity(incomingText);
        return activeId.startsWith("pay=") && activeId.equals(incomingId);
    }
}
