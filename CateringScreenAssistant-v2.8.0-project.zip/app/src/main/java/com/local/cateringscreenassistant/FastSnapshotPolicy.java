package com.local.cateringscreenassistant;

/**
 * v2.10.9 policy for time-sensitive Accessibility button snapshots.
 *
 * A snapshot older than the soft limit is not discarded immediately.  It may still be
 * used after a bounded active-window revalidation of the current top card's money+miles
 * and action rectangle.  Only evidence older than the hard limit is rejected outright.
 */
final class FastSnapshotPolicy {
    static final long ACCEPT_SOFT_MS = 380;
    static final long REJECT_SOFT_MS = 420;
    static final long HARD_MS = 2200;
    // v2.10.22: a just-captured Accessibility offer snapshot already proved the live
    // action row. Re-walking page chrome before the very first Accept costs time without
    // adding useful evidence. Only older-but-still-soft snapshots need that extra probe.
    static final long FIRST_ACCEPT_PAGE_RECHECK_MS = 180;

    static boolean needsRefresh(long ageMs, boolean accept) {
        long soft = accept ? ACCEPT_SOFT_MS : REJECT_SOFT_MS;
        return ageMs >= 0 && ageMs > soft && ageMs <= HARD_MS;
    }

    static boolean needsFirstAcceptPageRecheck(long ageMs) {
        return ageMs < 0 || ageMs > FIRST_ACCEPT_PAGE_RECHECK_MS;
    }

    static boolean hardExpired(long ageMs) {
        return ageMs < 0 || ageMs > HARD_MS;
    }

    static boolean freshEnoughWithoutRefresh(long ageMs, boolean accept) {
        long soft = accept ? ACCEPT_SOFT_MS : REJECT_SOFT_MS;
        return ageMs >= 0 && ageMs <= soft;
    }
}
