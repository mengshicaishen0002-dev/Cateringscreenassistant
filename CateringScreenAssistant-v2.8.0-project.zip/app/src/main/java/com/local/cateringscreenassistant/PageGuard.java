package com.local.cateringscreenassistant;

final class PageGuard {
    enum Page { OFFERS, IGNORED, JOBS, UNKNOWN }

    static Page classify(boolean ignoredSelected, boolean jobsSelected, boolean offersSelected,
                         boolean restoreVisible, boolean rejectVisible,
                         boolean acceptVisible, boolean emptyOffersVisible) {
        // Explicit non-offer states always win. This prevents a stale/background action
        // node from accidentally authorizing a click while Jobs/Ignored is active.
        if (ignoredSelected || restoreVisible) return Page.IGNORED;
        if (jobsSelected) return Page.JOBS;

        // DeliverThat does not consistently expose the Offers tab as selected on every
        // Android/WebView build. Treat either action button, or the empty-state text,
        // as positive evidence that the user is on the Offers page.
        return offersSelected || rejectVisible || acceptVisible || emptyOffersVisible
                ? Page.OFFERS : Page.UNKNOWN;
    }
}
