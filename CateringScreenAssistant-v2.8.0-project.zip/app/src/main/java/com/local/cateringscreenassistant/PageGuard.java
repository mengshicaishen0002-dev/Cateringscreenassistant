package com.local.cateringscreenassistant;

final class PageGuard {
    enum Page { OFFERS, IGNORED, JOBS, UNKNOWN }
    static Page classify(boolean ignoredSelected, boolean jobsSelected, boolean offersSelected,
                         boolean restoreVisible, boolean rejectVisible) {
        if (ignoredSelected || restoreVisible) return Page.IGNORED;
        if (jobsSelected) return Page.JOBS;
        return offersSelected || rejectVisible ? Page.OFFERS : Page.UNKNOWN;
    }
}
