package com.local.cateringscreenassistant;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/** Process-wide de-dupe for qualified-offer alerts coming from OCR and Accessibility paths. */
final class AlertDedupe {
    private static final long WINDOW_MS = 10 * 60 * 1000L;
    private static final int MAX_ENTRIES = 64;
    private static final LinkedHashMap<String, Long> SEEN = new LinkedHashMap<>();

    static synchronized boolean shouldAlert(String identity, long now) {
        if (identity == null || identity.trim().isEmpty()) return false;
        Iterator<Map.Entry<String, Long>> it = SEEN.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Long> e = it.next();
            if (now - e.getValue() > WINDOW_MS) it.remove();
        }
        Long previous = SEEN.get(identity);
        if (previous != null && now - previous <= WINDOW_MS) return false;
        SEEN.put(identity, now);
        while (SEEN.size() > MAX_ENTRIES) {
            Iterator<String> keys = SEEN.keySet().iterator();
            if (!keys.hasNext()) break;
            keys.next();
            keys.remove();
        }
        return true;
    }

    static synchronized void clearForTests() {
        SEEN.clear();
    }
}
