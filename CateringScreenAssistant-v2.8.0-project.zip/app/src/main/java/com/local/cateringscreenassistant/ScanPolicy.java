package com.local.cateringscreenassistant;
final class ScanPolicy {
    static boolean needsOcr(long now, long lastFrame, long lastReadable, int interval, boolean busy) {
        return !busy && now - lastFrame >= interval && (lastReadable == 0 || now - lastReadable >= 500);
    }
    static boolean fresh(long now, long started) { return now >= started && now - started <= 1000; }
}
