package com.local.cateringscreenassistant;

/**
 * v2.10.36 background-Reject priority policy.
 *
 * Reject confirmation is diagnostic/safety work after the physical Reject action has already
 * been sent. It must never compete with a newly arrived foreground offer for Accessibility/OCR.
 */
final class RejectConfirmPriorityPolicy {
    private static final long FIRST_PROBE_DELAY_MS = 70L;
    private static final long REPROBE_DELAY_MS = 180L;
    private static final long PROBE_SOFT_BUDGET_MS = 90L;
    private static final int PROBE_MAX_NODES = 72;
    private static final int MAX_BACKGROUND_PROBES = 2;
    private static final long MAX_BACKGROUND_AGE_MS = 950L;

    static long firstProbeDelayMs() { return FIRST_PROBE_DELAY_MS; }
    static long reprobeDelayMs() { return REPROBE_DELAY_MS; }
    static long probeSoftBudgetMs() { return PROBE_SOFT_BUDGET_MS; }
    static int probeMaxNodes() { return PROBE_MAX_NODES; }
    static int maxBackgroundProbes() { return MAX_BACKGROUND_PROBES; }
    static long maxBackgroundAgeMs() { return MAX_BACKGROUND_AGE_MS; }

    static boolean shouldDeferForNewTop(String rejectedText, String newTopText) {
        return rejectedText != null && !rejectedText.isEmpty()
                && newTopText != null && !newTopText.isEmpty()
                && !CardText.sameOffer(rejectedText, newTopText);
    }

    static boolean shouldStopBackground(int probeCount, long ageMs, boolean budgetExceeded) {
        return budgetExceeded || probeCount >= MAX_BACKGROUND_PROBES
                || ageMs >= MAX_BACKGROUND_AGE_MS;
    }

    private RejectConfirmPriorityPolicy() { }
}
