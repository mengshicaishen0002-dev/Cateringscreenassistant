package com.local.cateringscreenassistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.Locale;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.regex.Pattern;

public class TapAccessibilityService extends AccessibilityService {
    private static final Pattern LIVE_MONEY = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_MILES = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_MONEY_RANGE = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)\\s*[-–—]\\s*\\$?(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_OFFER_TIME = Pattern.compile("(?:today|tomorrow)\\s*(?:at)?\\s*(\\d{1,2}:\\d{2})\\s*(am|pm)", Pattern.CASE_INSENSITIVE);
    private static final AtomicReference<TapAccessibilityService> INSTANCE = new AtomicReference<>();
    private static volatile String foregroundPackage = "";
    private static volatile PageGuard.Page pageHint = PageGuard.Page.UNKNOWN;
    private static volatile long pageHintAt;
    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread directThread;
    private Handler directWorker;
    private final AtomicBoolean directQueued = new AtomicBoolean(false);
    private final ClaimBudget directClaimBudget = new ClaimBudget();
    private final RejectSequence directRejectSequence = new RejectSequence();
    private volatile long directCooldownUntil;
    private final Runnable directHeartbeat = new Runnable() {
        @Override public void run() {
            if (directWorker == null) return;
            queueDirectCheck();
            directWorker.postDelayed(this, 110);
        }
    };

    public static final class FastOfferSnapshot {
        public final String text;
        public final Rect acceptBounds;
        public final Rect rejectBounds;
        public final boolean acceptEnabled;
        public final boolean rejectEnabled;
        // v2.10.5: timestamp the exact Accessibility snapshot used for the first-tap fast path.
        // The fast tap is only allowed for a very fresh top-card snapshot.
        public final long capturedAt;

        FastOfferSnapshot(String text, Rect acceptBounds, Rect rejectBounds,
                          boolean acceptEnabled, boolean rejectEnabled) {
            this(text, acceptBounds, rejectBounds, acceptEnabled, rejectEnabled,
                    SystemClock.elapsedRealtime());
        }

        FastOfferSnapshot(String text, Rect acceptBounds, Rect rejectBounds,
                          boolean acceptEnabled, boolean rejectEnabled, long capturedAt) {
            this.text = text;
            this.acceptBounds = new Rect(acceptBounds);
            this.rejectBounds = new Rect(rejectBounds);
            this.acceptEnabled = acceptEnabled;
            this.rejectEnabled = rejectEnabled;
            this.capturedAt = capturedAt;
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE.set(this);
        directThread = new HandlerThread("accessibility-direct", android.os.Process.THREAD_PRIORITY_DISPLAY);
        directThread.start();
        directWorker = new Handler(directThread.getLooper());
        directWorker.post(directHeartbeat);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        String eventPackage = event.getPackageName() == null
                ? "" : event.getPackageName().toString();
        int type = event.getEventType();
        // Notification events from this assistant must not replace the actual
        // foreground app. Only real window transitions may do that.
        if ("com.deliverthat.driver".equals(eventPackage)
                || type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            foregroundPackage = eventPackage;
            if (!"com.deliverthat.driver".equals(eventPackage)) {
                pageHint = PageGuard.Page.UNKNOWN;
                pageHintAt = 0;
            }
        }
        if ("com.deliverthat.driver".equals(eventPackage)) {
            OcrMonitorService.requestImmediateFastCheck(event.getEventTime());
            queueDirectCheck();
        }
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        INSTANCE.compareAndSet(this, null);
        if (directWorker != null) directWorker.removeCallbacksAndMessages(null);
        if (directThread != null) directThread.quitSafely();
        directWorker = null;
        directThread = null;
        super.onDestroy();
    }

    private void queueDirectCheck() {
        Handler worker = directWorker;
        if (worker == null) return;
        if (OcrMonitorService.isMonitoring()) return; // the foreground monitor owns decisions when running
        if (!directQueued.compareAndSet(false, true)) return;
        worker.post(() -> {
            try { processStandaloneAccessibility(); }
            finally { directQueued.set(false); }
        });
    }

    /**
     * v2.10: true NovaFlow-style Accessibility-only execution path. It keeps working
     * even when MediaProjection/OCR is not started or was revoked by an APK update.
     * The screen-capture service remains an optional fallback, not a prerequisite.
     */
    private void processStandaloneAccessibility() {
        long now = SystemClock.elapsedRealtime();
        if (now < directCooldownUntil || !isDeliverThatForeground()) return;
        PageGuard.Page page = activePage();
        if (page != PageGuard.Page.OFFERS) return;
        List<FastOfferSnapshot> cards = getFastOfferSnapshots();
        if (cards.isEmpty()) return;

        android.content.SharedPreferences rules = getSharedPreferences("rules", MODE_PRIVATE);
        // v2.10.3: serial queue. Only the first visible card is ever actionable.
        // Once it disappears the next card naturally moves into this slot and is rescanned.
        FastOfferSnapshot selected = cards.get(0);
        float topAmount = directAmount(selected.text), topMiles = directMiles(selected.text);
        if (topAmount < 0 || topMiles < 0) return;
        String topFailure = directRuleFailure(selected.text, rules, topAmount, topMiles);
        if (topFailure.isEmpty()) {
            QualifiedOfferAlert.notifyIfNeeded(this, rules, selected.text, topAmount, topMiles);
            if (selected.acceptBounds.isEmpty()
                    || !directClaimBudget.available(CardText.identity(selected.text), now)) return;
        } else {
            if (!rules.getBoolean("autoIgnore", true) || selected.rejectBounds.isEmpty()
                    || directRejectSequence.observe(CardText.identity(selected.text), now)
                    != RejectSequence.State.READY) return;
        }
        float amount = directAmount(selected.text), miles = directMiles(selected.text);
        String failure = directRuleFailure(selected.text, rules, amount, miles);
        boolean accept = failure.isEmpty();
        if (rules.getBoolean("dryRun", false)) {
            directCooldownUntil = now + 1500;
            writeDirectStatus("无障碍直通测试：$" + String.format(Locale.US, "%.2f / %.1f mi；未点击", amount, miles));
            return;
        }

        String id = CardText.identity(selected.text);
        if (accept) {
            if (directClaimBudget.reserve(id, now) == 0) return;
        } else {
            directRejectSequence.sent(id, now);
        }
        directCooldownUntil = now + 700;
        Rect target = accept ? selected.acceptBounds : selected.rejectBounds;
        tapVerified(accept, target.exactCenterX(), target.exactCenterY(), amount, miles,
                selected.text, false, false,
                () -> {
                    writeDirectStatus((accept ? "无障碍Accept已发送：" : "无障碍Ignore已发送：")
                            + String.format(Locale.US, "$%.2f / %.1f mi", amount, miles));
                    directCooldownUntil = SystemClock.elapsedRealtime() + 220;
                }, reason -> {
                    writeDirectStatus((accept ? "无障碍Accept未执行：" : "无障碍Ignore未执行：") + reason);
                    directCooldownUntil = 0;
                });
    }

    private static float directAmount(String text) {
        if (text == null) return -1f;
        String normalized = text.replace(',', '.');
        java.util.regex.Matcher range = LIVE_MONEY_RANGE.matcher(normalized);
        if (range.find()) try { return Float.parseFloat(range.group(1)); } catch (Exception ignored) { }
        java.util.regex.Matcher one = LIVE_MONEY.matcher(normalized);
        if (one.find()) try { return Float.parseFloat(one.group(1)); } catch (Exception ignored) { }
        return -1f;
    }

    private static float directMiles(String text) {
        if (text == null) return -1f;
        java.util.regex.Matcher m = LIVE_MILES.matcher(text.replace(',', '.'));
        if (!m.find()) return -1f;
        try { return Float.parseFloat(m.group(1)); } catch (Exception ignored) { return -1f; }
    }

    private static String directRuleFailure(String text, android.content.SharedPreferences prefs,
                                            float amount, float miles) {
        String lower = text == null ? "" : text.toLowerCase(Locale.US);
        boolean pasadena = lower.contains("pasadena");
        boolean pasadenaEnabled = prefs.getBoolean("pasadenaRuleEnabled", false);
        float minimum = prefs.getFloat("minPay", 25f);
        float maximumMiles = prefs.getFloat("maxMiles", 12f);
        if (pasadena && pasadenaEnabled) {
            minimum = prefs.getFloat("pasadenaMinPay", 25f);
            maximumMiles = prefs.getFloat("pasadenaMaxMiles", 12f);
        }
        if (amount < minimum || miles > maximumMiles)
            return pasadena && pasadenaEnabled ? "Pasadena专属金额/里程不符合" : "普通金额/里程不符合";

        if (prefs.getBoolean("requireCity", true) && !(pasadena && pasadenaEnabled)) {
            String configured = prefs.getString("cities", "").trim().toLowerCase(Locale.US);
            if (!configured.isEmpty()) {
                boolean ok = false;
                for (String city : configured.split(",")) {
                    String clean = city.trim();
                    if (!clean.isEmpty() && lower.contains(clean)) { ok = true; break; }
                }
                if (!ok) return "城市不符合";
            }
        }

        String startValue = prefs.getString("startTime", "").trim();
        String endValue = prefs.getString("endTime", "").trim();
        if (!startValue.isEmpty() && !endValue.isEmpty()) {
            try {
                java.util.regex.Matcher matcher = LIVE_OFFER_TIME.matcher(text);
                if (!matcher.find()) return "订单时间不符合";
                DateTimeFormatter offerFormat = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
                LocalTime offer = LocalTime.parse(matcher.group(1) + " "
                        + matcher.group(2).toUpperCase(Locale.US), offerFormat);
                DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
                LocalTime start = LocalTime.parse(startValue, f), end = LocalTime.parse(endValue, f);
                boolean allowed = end.isAfter(start) || end.equals(start)
                        ? !offer.isBefore(start) && !offer.isAfter(end)
                        : !offer.isBefore(start) || !offer.isAfter(end);
                if (!allowed) return "订单时间不符合";
            } catch (Exception ignored) { return "订单时间不符合"; }
        }
        return "";
    }

    private void writeDirectStatus(String status) {
        try {
            getSharedPreferences("rules", MODE_PRIVATE).edit()
                    .putString("lastStatus", status)
                    .putLong("lastStatusAt", System.currentTimeMillis())
                    .apply();
        } catch (RuntimeException ignored) { }
    }

    public static boolean isConnected() {
        return INSTANCE.get() != null;
    }

    public static boolean isDeliverThatForeground() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        try {
            return root.getPackageName() != null
                    && "com.deliverthat.driver".contentEquals(root.getPackageName());
        } finally { root.recycle(); }
    }

    public static PageGuard.Page activePage() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return PageGuard.Page.UNKNOWN;
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return PageGuard.Page.UNKNOWN;
        PageGuard.Page page = pageFromScan(scan);
        updatePageHint(page);
        return page;
    }

    /**
     * Cheap page hint used by the OCR coordinate fallback. A full multi-window tree scan
     * on this Galaxy A15 has been observed to take ~400-800 ms, so the action path must
     * not repeat it after OCR has already located the current offer.
     */
    public static PageGuard.Page recentPageHint() {
        long now = SystemClock.elapsedRealtime();
        return pageHintAt > 0 && now >= pageHintAt && now - pageHintAt <= 1800
                ? pageHint : PageGuard.Page.UNKNOWN;
    }

    private static void updatePageHint(PageGuard.Page page) {
        if (page == null) page = PageGuard.Page.UNKNOWN;
        pageHint = page;
        pageHintAt = SystemClock.elapsedRealtime();
    }

    private static PageGuard.Page pageOf(AccessibilityNodeInfo root) {
        boolean[] flags = new boolean[7];
        StringBuilder visibleText = new StringBuilder();
        collectPageFlags(root, flags, visibleText);
        PageGuard.Page page = PageGuard.classify(flags[0], flags[1], flags[2], flags[3], flags[4], flags[5], flags[6]);
        if (page != PageGuard.Page.UNKNOWN) return page;
        return fallbackPageFromTreeText(visibleText.toString());
    }

    private static PageGuard.Page fallbackPageFromTreeText(String text) {
        if (text == null) return PageGuard.Page.UNKNOWN;
        String lower = text.toLowerCase(Locale.US).replace(',', '.');
        boolean hasMoney = LIVE_MONEY.matcher(lower).find();
        boolean hasMiles = LIVE_MILES.matcher(lower).find();
        // DeliverThat's Offers page exposes offer-specific tree text even on builds where
        // the Offers tab does not report selected=true and the action labels are blank.
        // "Exclusive" / "Expires" are strong offer-page evidence and are not used on Jobs.
        if ((lower.contains("exclusive") && lower.contains("offer"))
                || (lower.contains("expires") && hasMoney && hasMiles)) return PageGuard.Page.OFFERS;
        return PageGuard.Page.UNKNOWN;
    }

    private static void collectPageFlags(AccessibilityNodeInfo node, boolean[] flags, StringBuilder visibleText) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean usable = node.isVisibleToUser() || !bounds.isEmpty()
                || node.isSelected() || node.isChecked() || node.isClickable();
        if (usable) {
            for (CharSequence value : new CharSequence[]{node.getText(), node.getContentDescription()}) {
                if (value == null) continue;
                visibleText.append(value).append(' ');
                String label = value.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", "");
                if (node.isSelected() || node.isChecked()) {
                    if (label.equals("ignored")) flags[0] = true;
                    if (label.equals("jobs")) flags[1] = true;
                    if (label.equals("offers") || label.startsWith("offers")) flags[2] = true;
                }
                if (label.equals("restore") || label.equals("restorebutton")) flags[3] = true;
                if (ButtonLabels.isReject(value)) flags[4] = true;
                if (matchesAccept(value)) flags[5] = true;
                if (label.equals("nooffersavailable") || label.equals("nooffers")) flags[6] = true;
            }
        }
        // Do not prune an entire subtree just because an intermediate WebView/Compose
        // container reports isVisibleToUser=false. Several DeliverThat builds do exactly
        // that while their descendants still carry useful accessibility semantics.
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectPageFlags(child, flags, visibleText); child.recycle(); }
        }
    }

    public static String debugTreeSummary() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return "辅助服务未连接";
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return "前台非DeliverThat或无活动窗口树";
        PageGuard.Page page = pageFromScan(scan);
        return "树页=" + page + "；窗口=" + scan.windowsScanned
                + "；文本块=" + scan.pieces.size() + "；可点击=" + scan.clickables.size()
                + "；语义Accept=" + scan.accepts.size() + "；语义Reject=" + scan.rejects.size();
    }

    public static FastOfferSnapshot getFastOfferSnapshot() {
        List<FastOfferSnapshot> cards = getFastOfferSnapshots();
        return cards.isEmpty() ? null : cards.get(0);
    }

    public static List<FastOfferSnapshot> getFastOfferSnapshots() {
        List<FastOfferSnapshot> cards = new ArrayList<>();
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return cards;
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return cards;
        PageGuard.Page page = pageFromScan(scan);
        updatePageHint(page);
        if (page != PageGuard.Page.OFFERS) {
            String treeText = scan.visibleText.toString();
            boolean hasOfferNumbers = LIVE_MONEY.matcher(treeText).find() && LIVE_MILES.matcher(treeText).find();
            boolean hasActionStructure = !scan.accepts.isEmpty() || !scan.rejects.isEmpty()
                    || scan.clickables.size() >= 2;
            // v2.10: blank-label React-Native/WebView buttons can leave the page classifier
            // at UNKNOWN. Money+miles plus a real action-row structure is sufficient to
            // enter the read-only card builder; the final click still revalidates foreground,
            // card identity and numbers.
            if (!(page == PageGuard.Page.UNKNOWN && hasOfferNumbers && hasActionStructure)) return cards;
        }
        List<ActionHit> anchors = new ArrayList<>(scan.accepts);
        for (ActionHit reject : scan.rejects) {
            boolean paired = false;
            for (ActionHit accept : scan.accepts) if (sameRow(accept.bounds, reject.bounds)) { paired = true; break; }
            if (!paired) anchors.add(reject);
        }
        anchors.sort(java.util.Comparator.comparingInt(hit -> hit.bounds.top));
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (ActionHit anchor : anchors) {
            Rect accept = new Rect(), reject = new Rect();
            boolean acceptEnabled = false, rejectEnabled = false;
            for (ActionHit candidate : scan.accepts) {
                if (sameRow(candidate.bounds, anchor.bounds)) {
                    accept.set(candidate.bounds); acceptEnabled = candidate.enabled; break;
                }
            }
            for (ActionHit candidate : scan.rejects) {
                if (sameRow(candidate.bounds, anchor.bounds)) {
                    reject.set(candidate.bounds); rejectEnabled = candidate.enabled; break;
                }
            }
            String text = CardText.aboveButton(scan.pieces, anchor.bounds.top, anchor.bounds.bottom);
            if (!CardText.MONEY.matcher(text).find() || !LIVE_MILES.matcher(text).find()) continue;
            // v2.10.4: prefer the real clickable button/container bounds whenever the
            // hierarchy exposes them. A text label may report ACTION_CLICK successfully while
            // DeliverThat ignores it; the larger parent/button rectangle is a much safer
            // coordinate target for the gesture path.
            FastOfferSnapshot structuralFill = structuralActionsForText(scan, text);
            if (structuralFill != null) {
                if (!structuralFill.acceptBounds.isEmpty()
                        && (accept.isEmpty() || rectArea(structuralFill.acceptBounds) > rectArea(accept) * 1.35f)) {
                    accept.set(structuralFill.acceptBounds); acceptEnabled = structuralFill.acceptEnabled;
                }
                if (!structuralFill.rejectBounds.isEmpty()
                        && (reject.isEmpty() || rectArea(structuralFill.rejectBounds) > rectArea(reject) * 1.35f)) {
                    reject.set(structuralFill.rejectBounds); rejectEnabled = structuralFill.rejectEnabled;
                }
            }
            if (seen.add(CardText.identity(text)))
                cards.add(new FastOfferSnapshot(text, accept, reject, acceptEnabled, rejectEnabled));
        }

        // Structural Accessibility fallback: some DeliverThat releases expose the two
        // bottom action controls as clickable nodes with blank text/description. In that
        // case v2.9.1 reported zero cards and fell all the way back to ~1s OCR. Pair the
        // clickable controls by row and attach them to the nearest money+miles card text.
        if (cards.isEmpty() && !scan.clickables.isEmpty()) {
            List<ActionHit> structural = new ArrayList<>(scan.clickables);
            structural.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                    .thenComparingInt(hit -> hit.bounds.left));
            for (ActionHit anchor : structural) {
                String text = CardText.aboveButton(scan.pieces, anchor.bounds.top, anchor.bounds.bottom);
                if (!CardText.MONEY.matcher(text).find() || !LIVE_MILES.matcher(text).find()) continue;
                String id = CardText.identity(text);
                if (seen.contains(id)) continue;
                FastOfferSnapshot structuralCard = structuralActionsForText(scan, text);
                if (structuralCard != null
                        && (!structuralCard.acceptBounds.isEmpty() || !structuralCard.rejectBounds.isEmpty())) {
                    seen.add(id);
                    cards.add(structuralCard);
                }
            }
        }
        return cards;
    }

    private static boolean sameRow(Rect a, Rect b) {
        return a.top < b.bottom && a.bottom > b.top;
    }

    private static float rectArea(Rect r) {
        if (r == null || r.isEmpty()) return 0f;
        return (float) r.width() * (float) r.height();
    }

    /**
     * Returns the first visible offer card text even when its Ignore button is temporarily
     * disabled/renamed by a countdown. This lets the serial queue keep lower cards locked.
     */
    public static String getTopVisibleOfferText() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return "";
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan) || scan.pieces.isEmpty()) return "";
        java.util.List<CardText.Piece> pieces = new java.util.ArrayList<>(scan.pieces);
        pieces.sort(java.util.Comparator.comparingDouble((CardText.Piece p) -> p.top)
                .thenComparingDouble(p -> p.left));
        CardText.Piece money = null, miles = null;
        for (CardText.Piece p : pieces) {
            if (money == null && CardText.MONEY.matcher(p.text).find()) money = p;
            if (miles == null && LIVE_MILES.matcher(p.text).find()) miles = p;
            if (money != null && miles != null) {
                float row = Math.max(money.bottom - money.top, miles.bottom - miles.top);
                if (Math.abs(money.top - miles.top) <= Math.max(18f, row * 3f)) break;
                if (money.top < miles.top) money = null; else miles = null;
            }
        }
        if (money == null || miles == null) return "";
        float start = Math.min(money.top, miles.top);
        float end = start + 430f;
        // Stop before the next offer's money/miles row when multiple cards are visible.
        for (CardText.Piece p : pieces) {
            if (p.top <= start + 90f) continue;
            if (CardText.MONEY.matcher(p.text).find() || LIVE_MILES.matcher(p.text).find()) {
                end = Math.min(end, p.top - 4f);
                break;
            }
        }
        StringBuilder out = new StringBuilder();
        for (CardText.Piece p : pieces)
            if (p.top >= start && p.top < end) out.append(p.text).append(' ');
        return out.toString().trim();
    }

    public static FastOfferSnapshot findOffer(String expectedText) {
        for (FastOfferSnapshot card : getFastOfferSnapshots())
            if (CardText.sameOffer(expectedText, card.text)) return card;
        return null;
    }

    // One hierarchy traversal supplies page, button geometry and card text together.
    private static final class ActionHit {
        final Rect bounds;
        final boolean enabled;
        ActionHit(Rect bounds, boolean enabled) { this.bounds = new Rect(bounds); this.enabled = enabled; }
    }

    private static final class WindowScan {
        final boolean[] flags = new boolean[7];
        final List<ActionHit> accepts = new ArrayList<>();
        final List<ActionHit> rejects = new ArrayList<>();
        // v2.9.2+: collect raw clickable/actionable nodes even when their text/contentDescription
        // is blank. Semantics come from hierarchy + geometry first; OCR is only a fallback.
        final List<ActionHit> clickables = new ArrayList<>();
        final List<CardText.Piece> pieces = new ArrayList<>();
        final StringBuilder visibleText = new StringBuilder();
        final Rect rootBounds = new Rect();
        int windowsScanned;
    }

    /**
     * v2.9.3: scan the active DeliverThat window plus any additional interactive
     * DeliverThat windows exposed by Accessibility. React-Native/WebView/Compose builds
     * can split useful descendants across windows even though getRootInActiveWindow()
     * only exposes the shell container.
     *
     * Safety invariant: we still require the ACTIVE window to belong to DeliverThat.
     * Additional windows are used only as extra tree content while DeliverThat is truly
     * foreground, so pulling down notifications cannot accidentally authorize a click.
     */
    private static boolean scanDeliverThatWindows(TapAccessibilityService service, WindowScan scan) {
        if (service == null || scan == null) return false;
        AccessibilityNodeInfo active = service.getRootInActiveWindow();
        if (active == null) return false;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    active.getPackageName() == null ? "" : active.getPackageName())) return false;
            active.getBoundsInScreen(scan.rootBounds);
            scanWindow(active, scan);
            scan.windowsScanned++;
        } finally {
            active.recycle();
        }

        try {
            List<AccessibilityWindowInfo> windows = service.getWindows();
            if (windows == null) return true;
            for (AccessibilityWindowInfo window : windows) {
                if (window == null) continue;
                AccessibilityNodeInfo root = null;
                try {
                    root = window.getRoot();
                    if (root == null || !"com.deliverthat.driver".contentEquals(
                            root.getPackageName() == null ? "" : root.getPackageName())) continue;
                    Rect bounds = new Rect();
                    root.getBoundsInScreen(bounds);
                    // The active root is normally returned again from getWindows().
                    // Duplicate pieces/hits are de-duplicated below, so scanning it again
                    // is harmless and lets secondary-window content be merged uniformly.
                    if (scan.rootBounds.isEmpty() && !bounds.isEmpty()) scan.rootBounds.set(bounds);
                    scanWindow(root, scan);
                    scan.windowsScanned++;
                } finally {
                    if (root != null) root.recycle();
                }
            }
        } catch (RuntimeException ignored) {
            // Some OEM Accessibility implementations transiently throw while windows are
            // changing. The already-scanned active tree remains usable.
        }
        return true;
    }

    private static PageGuard.Page pageFromScan(WindowScan scan) {
        if (scan == null) return PageGuard.Page.UNKNOWN;
        PageGuard.Page page = PageGuard.classify(scan.flags[0], scan.flags[1], scan.flags[2],
                scan.flags[3], scan.flags[4], scan.flags[5], scan.flags[6]);
        if (page == PageGuard.Page.UNKNOWN)
            page = fallbackPageFromTreeText(scan.visibleText.toString());
        return page;
    }

    private static void addUniquePiece(List<CardText.Piece> pieces, String value, Rect bounds) {
        if (pieces == null || value == null || value.isEmpty() || bounds == null || bounds.isEmpty()) return;
        String normalized = value.replaceAll("\\s+", " ").trim();
        if (normalized.isEmpty()) return;
        for (CardText.Piece piece : pieces) {
            if (piece.left == bounds.left && piece.top == bounds.top && piece.bottom == bounds.bottom
                    && normalized.equals(piece.text.replaceAll("\\s+", " ").trim())) return;
        }
        pieces.add(new CardText.Piece(normalized, bounds.left, bounds.top, bounds.bottom));
    }

    private static FastOfferSnapshot structuralActionsForText(WindowScan scan, String text) {
        if (scan == null || text == null || text.isEmpty() || scan.clickables.isEmpty()) return null;
        List<ActionHit> row = new ArrayList<>();
        for (ActionHit candidate : scan.clickables) {
            String candidateText = CardText.aboveButton(scan.pieces,
                    candidate.bounds.top, candidate.bounds.bottom);
            if (CardText.sameOffer(text, candidateText)) row.add(candidate);
        }
        if (row.isEmpty()) return null;
        // Keep only the lowest same-row cluster associated with the card. A card container
        // or detail affordance higher up must not be mistaken for the action row.
        row.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                .thenComparingInt(hit -> hit.bounds.left));
        ActionHit lowest = row.get(row.size() - 1);
        List<ActionHit> actionRow = new ArrayList<>();
        for (ActionHit hit : row) if (sameActionRow(hit.bounds, lowest.bounds)) actionRow.add(hit);
        actionRow.sort(java.util.Comparator.comparingInt(hit -> hit.bounds.left));
        if (actionRow.isEmpty()) return null;
        Rect accept = new Rect(), reject = new Rect();
        boolean acceptEnabled = false, rejectEnabled = false;
        int mid = scan.rootBounds.centerX();
        ActionHit left = actionRow.get(0), right = actionRow.get(actionRow.size() - 1);
        if (actionRow.size() >= 2 && right.bounds.centerX() > left.bounds.centerX()) {
            reject.set(left.bounds); rejectEnabled = left.enabled;
            accept.set(right.bounds); acceptEnabled = right.enabled;
        } else {
            ActionHit only = actionRow.get(0);
            if (only.bounds.centerX() >= mid) {
                accept.set(only.bounds); acceptEnabled = only.enabled;
            } else {
                reject.set(only.bounds); rejectEnabled = only.enabled;
            }
        }
        return new FastOfferSnapshot(text, accept, reject, acceptEnabled, rejectEnabled);
    }

    private static boolean sameActionRow(Rect a, Rect b) {
        int tolerance = Math.max(18, Math.max(a.height(), b.height()));
        return Math.abs(a.centerY() - b.centerY()) <= tolerance;
    }

    private static void addUniqueHit(List<ActionHit> hits, Rect bounds, boolean enabled) {
        if (bounds == null || bounds.isEmpty()) return;
        for (ActionHit hit : hits) {
            if (hit.bounds.equals(bounds)) return;
            Rect intersection = new Rect(hit.bounds);
            if (intersection.intersect(bounds)) {
                float overlap = (float) intersection.width() * intersection.height();
                float smaller = Math.min((float) hit.bounds.width() * hit.bounds.height(),
                        (float) bounds.width() * bounds.height());
                if (smaller > 0 && overlap / smaller > 0.92f) return;
            }
        }
        hits.add(new ActionHit(bounds, enabled));
    }

    private static boolean structuralActionShape(AccessibilityNodeInfo node, Rect bounds, Rect rootBounds) {
        if (node == null || bounds == null || bounds.isEmpty() || rootBounds.isEmpty()) return false;
        boolean actionable = node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0
                || (node.getClassName() != null
                    && node.getClassName().toString().toLowerCase(Locale.US).contains("button"));
        if (!actionable) return false;
        int rw = Math.max(1, rootBounds.width()), rh = Math.max(1, rootBounds.height());
        int minW = Math.max(36, Math.round(rw * 0.05f));
        // v2.9.2 capped at 62% of screen width. Some DeliverThat builds place ACTION_CLICK
        // on a wide button-row/card ancestor, so that cap discarded the only actionable
        // node in the tree. Keep wide candidates; later card/row association disambiguates.
        int maxW = Math.round(rw * 0.94f);
        int minH = Math.max(18, Math.round(rh * 0.010f));
        int maxH = Math.round(rh * 0.20f);
        return bounds.width() >= minW && bounds.width() <= maxW
                && bounds.height() >= minH && bounds.height() <= maxH
                && bounds.centerY() > rootBounds.top + rh * 0.20f;
    }

    private static void scanWindow(AccessibilityNodeInfo node, WindowScan scan) {
        if (node == null) return;
        CharSequence text = node.getText(), description = node.getContentDescription();
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean intersectsScreen = !bounds.isEmpty() && (scan.rootBounds.isEmpty()
                || Rect.intersects(bounds, scan.rootBounds));
        boolean usable = node.isVisibleToUser() || intersectsScreen
                || node.isSelected() || node.isChecked() || node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0;
        CharSequence value = text == null || text.length() == 0 ? description : text;
        if (usable && value != null) {
            scan.visibleText.append(value).append(' ');
            if (!bounds.isEmpty()) addUniquePiece(scan.pieces, value.toString(), bounds);
        }
        if (usable && structuralActionShape(node, bounds, scan.rootBounds))
            addUniqueHit(scan.clickables, bounds, actionNodeReady(node));
        if (usable) {
            for (CharSequence labelValue : new CharSequence[]{text, description}) {
                if (labelValue == null) continue;
                String label = labelValue.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", "");
                if (node.isSelected() || node.isChecked()) {
                    if (label.equals("ignored")) scan.flags[0] = true;
                    if (label.equals("jobs")) scan.flags[1] = true;
                    if (label.equals("offers")) scan.flags[2] = true;
                }
                if (label.equals("restore") || label.equals("restorebutton")) scan.flags[3] = true;
                if (ButtonLabels.isReject(labelValue)) scan.flags[4] = true;
                if (matchesAccept(labelValue)) scan.flags[5] = true;
                if (label.equals("nooffersavailable") || label.equals("nooffers")) scan.flags[6] = true;
            }
            if (!bounds.isEmpty()) {
                boolean ready = actionNodeReady(node);
                if (matchesAccept(text) || matchesAccept(description))
                    addUniqueHit(scan.accepts, bounds, ready);
                if (ButtonLabels.isReject(text) || ButtonLabels.isReject(description))
                    addUniqueHit(scan.rejects, bounds, ready);
            }
        }

        // Always recurse. An invisible intermediate WebView/Compose container must not
        // suppress accessible descendants.
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { try { scanWindow(child, scan); } finally { child.recycle(); } }
        }
    }

    private static boolean findRejectBounds(AccessibilityNodeInfo node, Rect accept, Rect out) {
        if (node == null || !node.isVisibleToUser() || !node.isEnabled()) return false;
        if (ButtonLabels.isReject(node.getText()) || ButtonLabels.isReject(node.getContentDescription())) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (!bounds.isEmpty() && (accept.isEmpty() || (bounds.top < accept.bottom && bounds.bottom > accept.top))) {
                out.set(bounds);
                return true;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = findRejectBounds(child, accept, out);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    private static String cardText(AccessibilityNodeInfo root, Rect button) {
        List<CardText.Piece> pieces = new ArrayList<>();
        collectPieces(root, pieces);
        return CardText.aboveButton(pieces, button.top, button.bottom);
    }

    private static void collectPieces(AccessibilityNodeInfo node, List<CardText.Piece> pieces) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        CharSequence value = node.getText();
        if (value == null || value.length() == 0) value = node.getContentDescription();
        if (value != null && !bounds.isEmpty()) pieces.add(new CardText.Piece(
                value.toString(), bounds.left, bounds.top, bounds.bottom));
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectPieces(child, pieces); child.recycle(); }
        }
    }

    private static void collectSnapshot(AccessibilityNodeInfo node, StringBuilder text, Rect accept) {
        if (node == null || !node.isVisibleToUser()) return;
        CharSequence label = node.getText();
        CharSequence description = node.getContentDescription();
        if (label != null) text.append(label).append(' ');
        if (description != null && !description.equals(label)) text.append(description).append(' ');
        if (accept.isEmpty() && node.isEnabled()
                && (matchesAccept(label) || matchesAccept(description))) node.getBoundsInScreen(accept);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectSnapshot(child, text, accept);
                child.recycle();
            }
        }
    }

    private static boolean matchesAccept(CharSequence value) {
        return value != null && isAcceptLabel(value.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", ""));
    }

    private static boolean findAcceptBounds(AccessibilityNodeInfo node, Rect out) {
        if (node == null) return false;
        String label = "";
        if (node.getText() != null) label += node.getText().toString();
        if (node.getContentDescription() != null) label += " " + node.getContentDescription();
        String normalized = label.toLowerCase(Locale.US).replaceAll("[^a-z]", "");
        if (isAcceptLabel(normalized)) {
            node.getBoundsInScreen(out);
            if (!out.isEmpty()) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = findAcceptBounds(child, out);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    /**
     * v2.10.5 first-tap path. The card has already been read and isolated by the same
     * Accessibility scan, so do not spend another 200-800 ms walking the entire tree before
     * the first gesture. We only accept a very fresh snapshot, re-check the active package,
     * window bounds and a small forbidden-page probe, then tap the verified top-card button.
     */
    public static void tapSnapshotFast(FastOfferSnapshot snapshot, float amount, float miles,
                                       Runnable completion, Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || snapshot == null || snapshot.acceptBounds.isEmpty()
                || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "顶部Accept快照不可用或DeliverThat不在前台");
            return;
        }
        final long queuedAt = SystemClock.elapsedRealtime();
        service.main.post(() -> {
            long now = SystemClock.elapsedRealtime();
            long snapshotAge = now - snapshot.capturedAt;
            if (snapshotAge < 0 || snapshotAge > 380) {
                if (mismatch != null) mismatch.accept("顶部按钮快照已过旧" + snapshotAge + "ms；重新读取后再点");
                return;
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消快速Accept");
                return;
            }
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            float x = snapshot.acceptBounds.exactCenterX();
            float y = snapshot.acceptBounds.exactCenterY();
            PageGuard.Page quickPage = quickPageOf(root, 20);
            root.recycle();
            if (quickPage == PageGuard.Page.JOBS || quickPage == PageGuard.Page.IGNORED) {
                if (mismatch != null) mismatch.accept("页面为" + quickPage + "；取消快速Accept");
                return;
            }
            if (rootBounds.isEmpty() || !rootBounds.contains(Math.round(x), Math.round(y))) {
                if (mismatch != null) mismatch.accept("顶部Accept中心已离开DeliverThat窗口；重新读取");
                return;
            }
            long finalAge = SystemClock.elapsedRealtime() - snapshot.capturedAt;
            if (finalAge > 420) {
                if (mismatch != null) mismatch.accept("快速Accept执行前快照已过旧" + finalAge + "ms；重新读取");
                return;
            }
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 14))
                    .build();
            boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (completion != null) completion.run();
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    if (mismatch != null) mismatch.accept("系统取消了顶部Accept快速手势");
                }
            }, service.main);
            if (!dispatched && mismatch != null) mismatch.accept("系统未接受顶部Accept快速手势");
        });
    }


    /**
     * v2.10.7 fast Ignore/Reject path. Mirrors tapSnapshotFast(): the first visible card
     * and its left action rectangle were already isolated in one fresh Accessibility scan,
     * so do not immediately walk the whole tree again just to compare duplicated text.
     */
    public static void tapSnapshotRejectFast(FastOfferSnapshot snapshot, float amount, float miles,
                                             Runnable completion, Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || snapshot == null || snapshot.rejectBounds.isEmpty()
                || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "顶部Reject快照不可用或DeliverThat不在前台");
            return;
        }
        service.main.post(() -> {
            long now = SystemClock.elapsedRealtime();
            long snapshotAge = now - snapshot.capturedAt;
            if (snapshotAge < 0 || snapshotAge > 420) {
                if (mismatch != null) mismatch.accept("顶部Reject快照已过旧" + snapshotAge + "ms；重新读取后再点");
                return;
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消快速Reject");
                return;
            }
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            float x = snapshot.rejectBounds.exactCenterX();
            float y = snapshot.rejectBounds.exactCenterY();
            PageGuard.Page quickPage = quickPageOf(root, 20);
            root.recycle();
            if (quickPage == PageGuard.Page.JOBS || quickPage == PageGuard.Page.IGNORED) {
                if (mismatch != null) mismatch.accept("页面为" + quickPage + "；取消快速Reject");
                return;
            }
            if (rootBounds.isEmpty() || !rootBounds.contains(Math.round(x), Math.round(y))) {
                if (mismatch != null) mismatch.accept("顶部Reject中心已离开DeliverThat窗口；重新读取");
                return;
            }
            long finalAge = SystemClock.elapsedRealtime() - snapshot.capturedAt;
            if (finalAge > 460) {
                if (mismatch != null) mismatch.accept("快速Reject执行前快照已过旧" + finalAge + "ms；重新读取");
                return;
            }
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 14))
                    .build();
            boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (completion != null) completion.run();
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    if (mismatch != null) mismatch.accept("系统取消了顶部Reject快速手势");
                }
            }, service.main);
            if (!dispatched && mismatch != null) mismatch.accept("系统未接受顶部Reject快速手势");
        });
    }

    /**
     * Positive confirmation only. A card disappearing from Offers is deliberately NOT
     * considered success because another driver/server refresh can remove it at the same time.
     */
    public static boolean hasAcceptSuccessEvidence() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return false;
            PageGuard.Page page = pageOf(root);
            if (page == PageGuard.Page.JOBS) return true;
            StringBuilder text = new StringBuilder();
            int[] budget = new int[]{180};
            collectLimitedText(root, text, budget);
            String lower = text.toString().toLowerCase(Locale.US).replaceAll("\\s+", " ");
            return lower.contains("successfully accepted")
                    || lower.contains("job accepted")
                    || lower.contains("delivery accepted")
                    || lower.contains("offer accepted")
                    || lower.contains("assigned to you")
                    || lower.contains("you are assigned");
        } finally { root.recycle(); }
    }

    private static void collectLimitedText(AccessibilityNodeInfo node, StringBuilder out, int[] budget) {
        if (node == null || budget[0]-- <= 0) return;
        CharSequence text = node.getText(), desc = node.getContentDescription();
        if (text != null) out.append(text).append(' ');
        if (desc != null) out.append(desc).append(' ');
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectLimitedText(child, out, budget); }
                finally { child.recycle(); }
            }
        }
    }

    public static void tapSnapshotRetry(FastOfferSnapshot snapshot, float amount, float miles,
                                       Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, snapshot.acceptBounds.exactCenterX(), snapshot.acceptBounds.exactCenterY(),
                amount, miles, snapshot.text, true, true, completion, mismatch);
    }

    public static void tapIfOfferStillMatches(float x, float y, float amount, float miles,
                                               Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, x, y, amount, miles, null, completion, mismatch);
    }

    /**
     * Fresh screen-evidence fallback. Accessibility remains the preferred action path,
     * but DeliverThat builds exist where the visible button is not exported as an
     * actionable node. In that case a fresh OCR/visual coordinate may dispatch a gesture
     * after foreground/page checks. This is used for BOTH Accept and Reject in v2.9.3.
     */
    public static void tapOcrOffer(float x, float y, float amount, float miles, long evidenceAt,
                                   Runnable completion, Consumer<String> mismatch) {
        tapFreshOcrAction(true, x, y, amount, miles, evidenceAt, completion, mismatch);
    }

    public static void tapOcrReject(float x, float y, float amount, float miles, long evidenceAt,
                                    Runnable completion, Consumer<String> mismatch) {
        tapFreshOcrAction(false, x, y, amount, miles, evidenceAt, completion, mismatch);
    }

    private static void tapFreshOcrAction(boolean accept, float x, float y, float amount, float miles,
                                          long evidenceAt, Runnable completion,
                                          Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "DeliverThat不在前台或无法读取窗口");
            return;
        }
        final long queuedAt = SystemClock.elapsedRealtime();
        service.main.post(() -> {
            long now = SystemClock.elapsedRealtime();
            long age = ScanPolicy.actionAge(now, evidenceAt);
            if (!ScanPolicy.actionFresh(now, evidenceAt)) {
                if (mismatch != null) mismatch.accept("OCR/视觉证据过旧" + age + "ms；等待新帧");
                return;
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消屏幕坐标点击");
                return;
            }
            // Fast foreground verification only. Do not rescan every Accessibility window here:
            // on the user's Galaxy A15 that second tree walk alone can consume 400-800 ms and
            // was the direct cause of both v2.10 timeout errors.
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            if (rootBounds.isEmpty() || !rootBounds.contains(Math.round(x), Math.round(y))) {
                root.recycle();
                if (mismatch != null) mismatch.accept("目标坐标已离开DeliverThat窗口；取消点击");
                return;
            }

            // Use the recent full-scan hint first, then a bounded active-root probe. UNKNOWN is
            // intentionally allowed because the OCR frame already has money+miles+action-row
            // evidence; only a positive JOBS/IGNORED result blocks the gesture.
            PageGuard.Page quickPage = quickPageOf(root, 24);
            PageGuard.Page page = quickPage != PageGuard.Page.UNKNOWN
                    ? quickPage : recentPageHint();
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) {
                root.recycle();
                if (mismatch != null) mismatch.accept("页面为" + page + "；禁止屏幕坐标点击");
                return;
            }
            root.recycle();

            long beforeGesture = SystemClock.elapsedRealtime();
            long finalAge = ScanPolicy.actionAge(beforeGesture, evidenceAt);
            if (!ScanPolicy.actionFresh(beforeGesture, evidenceAt)) {
                if (mismatch != null) mismatch.accept("坐标核验后证据过旧" + finalAge + "ms；等待新帧");
                return;
            }
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 12))
                    .build();
            boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (completion != null) completion.run();
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    if (mismatch != null) mismatch.accept("系统取消了"
                            + (accept ? "Accept" : "Reject") + "坐标点击手势");
                }
            }, service.main);
            if (!dispatched && mismatch != null) mismatch.accept("系统未接受"
                    + (accept ? "Accept" : "Reject") + "坐标点击手势");
        });
    }

    /**
     * Bounded page probe for the time-critical coordinate path. It examines at most
     * maxNodes nodes from the active root and returns only strong page evidence.
     */
    private static PageGuard.Page quickPageOf(AccessibilityNodeInfo root, int maxNodes) {
        if (root == null || maxNodes <= 0) return PageGuard.Page.UNKNOWN;
        boolean[] flags = new boolean[7];
        int[] budget = new int[]{maxNodes};
        collectQuickPageFlags(root, flags, budget);
        PageGuard.Page page = PageGuard.classify(flags[0], flags[1], flags[2],
                flags[3], flags[4], flags[5], flags[6]);
        if (page != PageGuard.Page.UNKNOWN) updatePageHint(page);
        return page;
    }

    private static void collectQuickPageFlags(AccessibilityNodeInfo node, boolean[] flags, int[] budget) {
        if (node == null || budget[0]-- <= 0) return;
        CharSequence text = node.getText(), desc = node.getContentDescription();
        for (CharSequence value : new CharSequence[]{text, desc}) {
            if (value == null) continue;
            String label = value.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", "");
            if (node.isSelected() || node.isChecked()) {
                if (label.equals("ignored")) flags[0] = true;
                if (label.equals("jobs")) flags[1] = true;
                if (label.equals("offers") || label.startsWith("offers")) flags[2] = true;
            }
            if (label.equals("restore") || label.equals("restorebutton")) flags[3] = true;
            if (ButtonLabels.isReject(value)) flags[4] = true;
            if (matchesAccept(value)) flags[5] = true;
            if (label.equals("nooffersavailable") || label.equals("nooffers")) flags[6] = true;
        }
        // Once a positive forbidden page is found, no need to traverse deeper.
        if (flags[0] || flags[1]) return;
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectQuickPageFlags(child, flags, budget); }
                finally { child.recycle(); }
            }
            if (flags[0] || flags[1]) return;
        }
    }

    public static void tapSnapshot(FastOfferSnapshot snapshot, float amount, float miles,
                                   Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, snapshot.acceptBounds.exactCenterX(), snapshot.acceptBounds.exactCenterY(),
                amount, miles, snapshot.text, completion, mismatch);
    }

    public static void ignoreIfOfferStillMatches(float x, float y, float amount, float miles, String expectedText,
                                               Runnable completion, Consumer<String> mismatch) {
        tapVerified(false, x, y, amount, miles, expectedText, completion, mismatch);
    }

    private static void tapVerified(boolean accept, float x, float y, float amount, float miles, String expectedText,
                                    Runnable completion, Consumer<String> mismatch) {
        tapVerified(accept, x, y, amount, miles, expectedText, false, true, completion, mismatch);
    }

    private static void tapVerified(boolean accept, float x, float y, float amount, float miles,
                                    String expectedText, boolean gestureOnly, boolean requireMonitoring,
                                    Runnable completion, Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null ? "辅助点击服务未连接" : "DeliverThat不在前台或无法读取窗口");
            return;
        }
        final long queuedAt = android.os.SystemClock.elapsedRealtime();
        service.main.post(() -> {
            long queueMs = android.os.SystemClock.elapsedRealtime() - queuedAt;
            if (!ScanPolicy.fresh(android.os.SystemClock.elapsedRealtime(), queuedAt)) {
                if (mismatch != null) mismatch.accept("点击排队超时" + queueMs + "ms；取消旧判断，等待重新识别");
                return;
            }
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (requireMonitoring && !OcrMonitorService.isMonitoring()) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("监控已停止；已取消排队点击");
                return;
            }
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            PageGuard.Page page = pageOf(root);
            if (page == PageGuard.Page.UNKNOWN) page = activePage();
            // v2.10.4: several real DeliverThat builds leave the tab state UNKNOWN even while
            // money+miles+the exact top-card identity are readable. UNKNOWN must not veto a
            // fully revalidated top-card action. Positive Jobs/Ignored evidence still blocks.
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED
                    || (page == PageGuard.Page.UNKNOWN && expectedText == null)) {
                root.recycle();
                if (mismatch != null) mismatch.accept("页面为" + page + "；当前证据不足，未点击");
                return;
            }
            AccessibilityNodeInfo button = findActionNode(root, accept, x, y);
            Rect liveBounds = new Rect();
            if (button != null) {
                button.getBoundsInScreen(liveBounds);
            } else {
                // v2.10: a visible Accept/Ignore text node can be non-clickable and have no
                // clickable ancestor. The old fast path refused here even though a verified
                // accessibility coordinate was already known. Keep the coordinate and
                // independently verify the card text/numbers before dispatchGesture().
                int halfW = 26, halfH = 16;
                liveBounds.set(Math.round(x) - halfW, Math.round(y) - halfH,
                        Math.round(x) + halfW, Math.round(y) + halfH);
            }
            String liveText = cardText(root, liveBounds).toLowerCase(Locale.US).replace(',', '.');
            if (expectedText != null && !CardText.sameOfferForAction(expectedText.replace(',', '.'), liveText)) {
                if (button != null) button.recycle();
                root.recycle();
                if (mismatch != null) mismatch.accept("目标卡片稳定内容已变化；本次未点击");
                return;
            }
            if (!NumericGuard.containsExpected(liveText, LIVE_MONEY, amount, 0.011f)
                    || !NumericGuard.containsExpected(liveText, LIVE_MILES, miles, 0.051f)) {
                if (root != null) root.recycle();
                if (button != null) button.recycle();
                if (mismatch != null) mismatch.accept("目标卡片金额/里程未能一致核对；未点击");
                return;
            }

            if (!ScanPolicy.fresh(android.os.SystemClock.elapsedRealtime(), queuedAt)) {
                if (button != null) button.recycle(); root.recycle();
                if (mismatch != null) mismatch.accept("本次核验超过1秒；取消旧点击，重新读取");
                return;
            }
            // v2.10.4 real-device fix: DeliverThat's virtual/React-Native nodes can return
            // true from ACTION_CLICK while the visible button does absolutely nothing. The
            // screen recording confirms that failure mode. Use a real accessibility gesture
            // at the already-verified full action rectangle as the primary action. Semantic
            // ACTION_CLICK is only a fallback when Android refuses/cancels the gesture.
            final AccessibilityNodeInfo semanticFallback = button == null ? null
                    : AccessibilityNodeInfo.obtain(button);
            if (button != null) button.recycle();
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            root.recycle();

            float gestureX = x;
            float gestureY = y;
            if (!rootBounds.contains(Math.round(gestureX), Math.round(gestureY))) {
                if (semanticFallback != null) semanticFallback.recycle();
                if (mismatch != null) mismatch.accept("动作中心已离开DeliverThat窗口；取消点击");
                return;
            }
            Path path = new Path();
            path.moveTo(gestureX, gestureY);
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 18))
                    .build();
            boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (semanticFallback != null) semanticFallback.recycle();
                    if (completion != null) completion.run();
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    boolean clicked = false;
                    if (semanticFallback != null) {
                        try { clicked = !gestureOnly && performClickNodeOrParent(semanticFallback); }
                        finally { semanticFallback.recycle(); }
                    }
                    if (clicked) {
                        if (completion != null) completion.run();
                    } else if (mismatch != null) mismatch.accept("系统取消了坐标手势，语义点击也未执行");
                }
            }, service.main);
            if (!dispatched) {
                boolean clicked = false;
                if (semanticFallback != null) {
                    try { clicked = !gestureOnly && performClickNodeOrParent(semanticFallback); }
                    finally { semanticFallback.recycle(); }
                }
                if (clicked) {
                    if (completion != null) completion.run();
                } else if (mismatch != null) mismatch.accept("系统未接受坐标手势，语义点击也未执行");
            }
        });
    }

    private static AccessibilityNodeInfo findSemanticActionNode(AccessibilityNodeInfo node,
                                                                  boolean accept, float x, float y) {
        NodeCandidate best = new NodeCandidate();
        findActionCandidate(node, accept, x, y, best);
        return best.node;
    }

    private static AccessibilityNodeInfo findActionNode(AccessibilityNodeInfo node, boolean accept, float x, float y) {
        NodeCandidate best = new NodeCandidate();
        findActionCandidate(node, accept, x, y, best);
        if (best.node != null) return best.node;
        // If the label is blank, resolve the freshly read clickable node by the structural
        // coordinate obtained from the same Accessibility tree snapshot.
        findStructuralActionCandidate(node, x, y, best);
        return best.node;
    }

    private static final class NodeCandidate {
        AccessibilityNodeInfo node;
        float score = Float.MAX_VALUE;
    }

    private static void findActionCandidate(AccessibilityNodeInfo node, boolean accept, float x, float y, NodeCandidate best) {
        if (node == null) return;
        CharSequence label = node.getText();
        CharSequence description = node.getContentDescription();
        boolean matches = accept ? (matchesAccept(label) || matchesAccept(description))
                : (ButtonLabels.isReject(label) || ButtonLabels.isReject(description));
        if (matches) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (!bounds.isEmpty()) {
                float dy = Math.abs(bounds.exactCenterY() - y);
                float dx = Math.abs(bounds.exactCenterX() - x);
                float yTolerance = Math.max(90f, bounds.height() * 2.25f);
                float xTolerance = Math.max(140f, bounds.width() * 1.25f);
                if ((bounds.contains(Math.round(x), Math.round(y)) || (dy <= yTolerance && dx <= xTolerance))) {
                    float score = dy + dx * 0.25f;
                    if (score < best.score) {
                        if (best.node != null) best.node.recycle();
                        best.node = AccessibilityNodeInfo.obtain(node);
                        best.score = score;
                    }
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { findActionCandidate(child, accept, x, y, best); }
                finally { child.recycle(); }
            }
        }
    }

    private static void findStructuralActionCandidate(AccessibilityNodeInfo node, float x, float y, NodeCandidate best) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean actionable = node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0
                || (node.getClassName() != null
                    && node.getClassName().toString().toLowerCase(Locale.US).contains("button"));
        if (actionable && actionNodeReady(node) && !bounds.isEmpty()) {
            float dy = Math.abs(bounds.exactCenterY() - y);
            float dx = Math.abs(bounds.exactCenterX() - x);
            float yTolerance = Math.max(48f, bounds.height() * 1.35f);
            float xTolerance = Math.max(80f, bounds.width() * 0.75f);
            if (bounds.contains(Math.round(x), Math.round(y)) || (dy <= yTolerance && dx <= xTolerance)) {
                float areaPenalty = Math.min(250f, (bounds.width() * bounds.height()) / 12000f);
                float score = dy + dx * 0.35f + areaPenalty;
                if (score < best.score) {
                    if (best.node != null) best.node.recycle();
                    best.node = AccessibilityNodeInfo.obtain(node);
                    best.score = score;
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { findStructuralActionCandidate(child, x, y, best); }
                finally { child.recycle(); }
            }
        }
    }

    private static boolean actionNodeReady(AccessibilityNodeInfo node) {
        if (node == null) return false;
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(node);
        try {
            for (int depth = 0; depth < 6 && current != null; depth++) {
                boolean actionable = current.isClickable()
                        || (current.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0
                        || (current.getClassName() != null
                            && current.getClassName().toString().toLowerCase(Locale.US).contains("button"));
                if (current.isEnabled() && actionable) return true;
                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }
            return false;
        } finally {
            if (current != null) current.recycle();
        }
    }

    private static boolean performClickNodeOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(node);
        try {
            for (int depth = 0; depth < 6 && current != null; depth++) {
                boolean actionable = current.isClickable()
                        || (current.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0;
                if (current.isEnabled() && actionable
                        && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }
            return false;
        } finally {
            if (current != null) current.recycle();
        }
    }

    private static boolean performAcceptAction(AccessibilityNodeInfo node) {
        if (node == null) return false;
        String label = "";
        if (node.getText() != null) label += node.getText().toString();
        if (node.getContentDescription() != null) label += " " + node.getContentDescription();
        String normalized = label.toLowerCase(Locale.US).replaceAll("[^a-z]", "");
        if (isAcceptLabel(normalized)) {
            AccessibilityNodeInfo target = node;
            AccessibilityNodeInfo ownedParent = null;
            for (int depth = 0; depth < 3 && target != null; depth++) {
                if (target.isClickable()
                        && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    if (ownedParent != null) ownedParent.recycle();
                    return true;
                }
                AccessibilityNodeInfo parent = target.getParent();
                if (ownedParent != null) ownedParent.recycle();
                ownedParent = parent;
                target = parent;
            }
            if (ownedParent != null) ownedParent.recycle();
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean clicked = performAcceptAction(child);
                child.recycle();
                if (clicked) return true;
            }
        }
        return false;
    }

    private static boolean isAcceptLabel(String normalized) {
        if (normalized == null) return false;
        switch (normalized) {
            case "accept": case "claim":
            case "acceptbutton": case "buttonaccept":
            case "claimbutton": case "buttonclaim":
            case "acceptoffer": case "claimoffer":
            case "acceptdelivery": case "claimdelivery":
            case "acceptjob": case "claimjob":
            case "acceptorder": case "claimorder":
            case "acceptrequest": case "claimrequest":
                return true;
            default:
                return false;
        }
    }

    private static String collectText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder out = new StringBuilder();
        if (node.getText() != null) out.append(node.getText()).append(' ');
        if (node.getContentDescription() != null) out.append(node.getContentDescription()).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                out.append(collectText(child));
                child.recycle();
            }
        }
        return out.toString();
    }

}
