package com.local.cateringscreenassistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.Locale;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.regex.Pattern;

public class TapAccessibilityService extends AccessibilityService {
    private static final Pattern LIVE_MONEY = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_MILES = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_MONEY_RANGE = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)\\s*[-–—]\\s*\\$?(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_OFFER_TIME = Pattern.compile("(?:today|tomorrow)\\s*(?:at)?\\s*(\\d{1,2}:\\d{2})\\s*(am|pm)", Pattern.CASE_INSENSITIVE);
    private static final AtomicReference<TapAccessibilityService> INSTANCE = new AtomicReference<>();
    private static volatile String foregroundPackage = "";
    private static volatile PageGuard.Page pageHint = PageGuard.Page.UNKNOWN;
    private static volatile long pageHintAt;
    // v2.10.12: remember short-lived DeliverThat outcome messages (toast/snackbar/window text)
    // so a dispatched claim can distinguish backend rejection from a silent disappearance.
    private static volatile String lastClaimOutcomeHint = "";
    private static volatile long lastClaimOutcomeHintAt;
    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread directThread;
    private Handler directWorker;
    private final AtomicBoolean directQueued = new AtomicBoolean(false);
    private final ClaimBudget directClaimBudget = new ClaimBudget();
    private final RejectSequence directRejectSequence = RejectSequence.shared();
    private volatile long directCooldownUntil;
    private final Runnable directHeartbeat = new Runnable() {
        @Override public void run() {
            if (directWorker == null) return;
            queueDirectCheck();
            directWorker.postDelayed(this, 110);
        }
    };

    public static final class FastOfferSnapshot {
        public final String text;
        public final Rect acceptBounds;
        public final Rect rejectBounds;
        public final boolean acceptEnabled;
        public final boolean rejectEnabled;
        // v2.10.5: timestamp the exact Accessibility snapshot used for the first-tap fast path.
        // The fast tap is only allowed for a very fresh top-card snapshot.
        public final long capturedAt;

        FastOfferSnapshot(String text, Rect acceptBounds, Rect rejectBounds,
                          boolean acceptEnabled, boolean rejectEnabled) {
            this(text, acceptBounds, rejectBounds, acceptEnabled, rejectEnabled,
                    SystemClock.elapsedRealtime());
        }

        FastOfferSnapshot(String text, Rect acceptBounds, Rect rejectBounds,
                          boolean acceptEnabled, boolean rejectEnabled, long capturedAt) {
            this.text = text;
            this.acceptBounds = new Rect(acceptBounds);
            this.rejectBounds = new Rect(rejectBounds);
            this.acceptEnabled = acceptEnabled;
            this.rejectEnabled = rejectEnabled;
            this.capturedAt = capturedAt;
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE.set(this);
        directThread = new HandlerThread("accessibility-direct", android.os.Process.THREAD_PRIORITY_DISPLAY);
        directThread.start();
        directWorker = new Handler(directThread.getLooper());
        directWorker.post(directHeartbeat);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        String eventPackage = event.getPackageName() == null
                ? "" : event.getPackageName().toString();
        int type = event.getEventType();
        // Notification events from this assistant must not replace the actual
        // foreground app. Only real window transitions may do that.
        if ("com.deliverthat.driver".equals(eventPackage)
                || type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            foregroundPackage = eventPackage;
            if (!"com.deliverthat.driver".equals(eventPackage)) {
                pageHint = PageGuard.Page.UNKNOWN;
                pageHintAt = 0;
            }
        }
        if ("com.deliverthat.driver".equals(eventPackage)) {
            String hint = claimOutcomeHintFromEvent(event);
            if (!hint.isEmpty()) {
                lastClaimOutcomeHint = hint;
                lastClaimOutcomeHintAt = SystemClock.elapsedRealtime();
            }
            OcrMonitorService.requestImmediateFastCheck(event.getEventTime());
            queueDirectCheck();
        }
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        INSTANCE.compareAndSet(this, null);
        if (directWorker != null) directWorker.removeCallbacksAndMessages(null);
        if (directThread != null) directThread.quitSafely();
        directWorker = null;
        directThread = null;
        super.onDestroy();
    }

    private void queueDirectCheck() {
        Handler worker = directWorker;
        if (worker == null) return;
        if (OcrMonitorService.isMonitoring()) return; // the foreground monitor owns decisions when running
        if (!directQueued.compareAndSet(false, true)) return;
        worker.post(() -> {
            try { processStandaloneAccessibility(); }
            finally { directQueued.set(false); }
        });
    }

    /**
     * v2.10: true NovaFlow-style Accessibility-only execution path. It keeps working
     * even when MediaProjection/OCR is not started or was revoked by an APK update.
     * The screen-capture service remains an optional fallback, not a prerequisite.
     */
    private void processStandaloneAccessibility() {
        long now = SystemClock.elapsedRealtime();
        if (now < directCooldownUntil || !isDeliverThatForeground()) return;
        // v2.10.16: DeliverThat's React-Native build can leave the Offers tab/page
        // classifier at UNKNOWN even while a fully readable offer card and its action row
        // are on screen. Do not discard the structural snapshot before we build it.
        // Explicit JOBS/IGNORED still block actions; UNKNOWN is allowed only when
        // getFastOfferSnapshots() independently proves money+miles+button structure.
        PageGuard.Page page = activePage();
        if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) return;
        List<FastOfferSnapshot> cards = getFastOfferSnapshots();
        if (cards.isEmpty()) return;

        android.content.SharedPreferences rules = getSharedPreferences("rules", MODE_PRIVATE);
        // v2.10.3: serial queue. Only the first visible card is ever actionable.
        // Once it disappears the next card naturally moves into this slot and is rescanned.
        FastOfferSnapshot selected = cards.get(0);
        float topAmount = directAmount(selected.text), topMiles = directMiles(selected.text);
        if (topAmount < 0 || topMiles < 0) return;
        String topFailure = directRuleFailure(selected.text, rules, topAmount, topMiles);
        if (topFailure.isEmpty()) {
            QualifiedOfferAlert.notifyIfNeeded(this, rules, selected.text, topAmount, topMiles);
            if (selected.acceptBounds.isEmpty()
                    || !directClaimBudget.available(CardText.identity(selected.text), now)) return;
        } else {
            if (!rules.getBoolean("autoIgnore", true) || selected.rejectBounds.isEmpty() || !selected.rejectEnabled
                    || directRejectSequence.observe(CardText.identity(selected.text), now)
                    != RejectSequence.State.READY) return;
        }
        float amount = directAmount(selected.text), miles = directMiles(selected.text);
        String failure = directRuleFailure(selected.text, rules, amount, miles);
        boolean accept = failure.isEmpty();
        if (rules.getBoolean("dryRun", false)) {
            directCooldownUntil = now + 1500;
            writeDirectStatus("无障碍直通测试：$" + String.format(Locale.US, "%.2f / %.1f mi；未点击", amount, miles));
            return;
        }

        String id = CardText.identity(selected.text);
        final int directRejectAttempt;
        if (accept) {
            if (directClaimBudget.reserve(id, now) == 0) return;
            directRejectAttempt = 0;
        } else {
            directRejectAttempt = directRejectSequence.sent(id, now);
        }
        directCooldownUntil = now + 700;
        Rect target = accept ? selected.acceptBounds : selected.rejectBounds;
        tapVerified(accept, target.exactCenterX(), target.exactCenterY(), amount, miles,
                selected.text, false, false,
                () -> {
                    writeDirectStatus(accept
                            ? String.format(Locale.US, "无障碍Accept已发送：$%.2f / %.1f mi", amount, miles)
                            : String.format(Locale.US, "无障碍Ignore第%d次已发送：$%.2f / %.1f mi", directRejectAttempt, amount, miles));
                    directCooldownUntil = SystemClock.elapsedRealtime() + 220;
                }, reason -> {
                    if (!accept) directRejectSequence.failed(id, SystemClock.elapsedRealtime());
                    writeDirectStatus((accept ? "无障碍Accept未执行：" : "无障碍Ignore未执行：") + reason);
                    directCooldownUntil = 0;
                });
    }

    private static float directAmount(String text) {
        if (text == null) return -1f;
        String normalized = text.replace(',', '.');
        java.util.regex.Matcher range = LIVE_MONEY_RANGE.matcher(normalized);
        if (range.find()) try { return Float.parseFloat(range.group(1)); } catch (Exception ignored) { }
        java.util.regex.Matcher one = LIVE_MONEY.matcher(normalized);
        if (one.find()) try { return Float.parseFloat(one.group(1)); } catch (Exception ignored) { }
        return -1f;
    }

    private static float directMiles(String text) {
        if (text == null) return -1f;
        java.util.regex.Matcher m = LIVE_MILES.matcher(text.replace(',', '.'));
        if (!m.find()) return -1f;
        try { return Float.parseFloat(m.group(1)); } catch (Exception ignored) { return -1f; }
    }

    private static String directRuleFailure(String text, android.content.SharedPreferences prefs,
                                            float amount, float miles) {
        String lower = text == null ? "" : text.toLowerCase(Locale.US);
        boolean pasadena = lower.contains("pasadena");
        boolean pasadenaEnabled = prefs.getBoolean("pasadenaRuleEnabled", false);
        float minimum = prefs.getFloat("minPay", 25f);
        float maximumMiles = prefs.getFloat("maxMiles", 12f);
        if (pasadena && pasadenaEnabled) {
            minimum = prefs.getFloat("pasadenaMinPay", 25f);
            maximumMiles = prefs.getFloat("pasadenaMaxMiles", 12f);
        }
        if (amount < minimum || miles > maximumMiles)
            return pasadena && pasadenaEnabled ? "Pasadena专属金额/里程不符合" : "普通金额/里程不符合";

        if (prefs.getBoolean("requireCity", true) && !(pasadena && pasadenaEnabled)) {
            String configured = prefs.getString("cities", "").trim().toLowerCase(Locale.US);
            if (!configured.isEmpty()) {
                boolean ok = false;
                for (String city : configured.split(",")) {
                    String clean = city.trim();
                    if (!clean.isEmpty() && lower.contains(clean)) { ok = true; break; }
                }
                if (!ok) return "城市不符合";
            }
        }

        String startValue = prefs.getString("startTime", "").trim();
        String endValue = prefs.getString("endTime", "").trim();
        if (!startValue.isEmpty() && !endValue.isEmpty()) {
            try {
                java.util.regex.Matcher matcher = LIVE_OFFER_TIME.matcher(text);
                if (!matcher.find()) return "订单时间不符合";
                DateTimeFormatter offerFormat = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
                LocalTime offer = LocalTime.parse(matcher.group(1) + " "
                        + matcher.group(2).toUpperCase(Locale.US), offerFormat);
                DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
                LocalTime start = LocalTime.parse(startValue, f), end = LocalTime.parse(endValue, f);
                boolean allowed = end.isAfter(start) || end.equals(start)
                        ? !offer.isBefore(start) && !offer.isAfter(end)
                        : !offer.isBefore(start) || !offer.isAfter(end);
                if (!allowed) return "订单时间不符合";
            } catch (Exception ignored) { return "订单时间不符合"; }
        }
        return "";
    }

    private void writeDirectStatus(String status) {
        try {
            getSharedPreferences("rules", MODE_PRIVATE).edit()
                    .putString("lastStatus", status)
                    .putLong("lastStatusAt", System.currentTimeMillis())
                    .apply();
        } catch (RuntimeException ignored) { }
    }

    public static boolean isConnected() {
        return INSTANCE.get() != null;
    }

    public static boolean isDeliverThatForeground() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        try {
            return root.getPackageName() != null
                    && "com.deliverthat.driver".contentEquals(root.getPackageName());
        } finally { root.recycle(); }
    }

    public static PageGuard.Page activePage() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return PageGuard.Page.UNKNOWN;
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return PageGuard.Page.UNKNOWN;
        PageGuard.Page page = pageFromScan(scan);
        updatePageHint(page);
        return page;
    }

    /**
     * Cheap page hint used by the OCR coordinate fallback. A full multi-window tree scan
     * on this Galaxy A15 has been observed to take ~400-800 ms, so the action path must
     * not repeat it after OCR has already located the current offer.
     */
    public static PageGuard.Page recentPageHint() {
        long now = SystemClock.elapsedRealtime();
        return pageHintAt > 0 && now >= pageHintAt && now - pageHintAt <= 1800
                ? pageHint : PageGuard.Page.UNKNOWN;
    }

    private static void updatePageHint(PageGuard.Page page) {
        if (page == null) page = PageGuard.Page.UNKNOWN;
        pageHint = page;
        pageHintAt = SystemClock.elapsedRealtime();
    }

    private static PageGuard.Page pageOf(AccessibilityNodeInfo root) {
        boolean[] flags = new boolean[7];
        StringBuilder visibleText = new StringBuilder();
        collectPageFlags(root, flags, visibleText);
        PageGuard.Page page = PageGuard.classify(flags[0], flags[1], flags[2], flags[3], flags[4], flags[5], flags[6]);
        if (page != PageGuard.Page.UNKNOWN) return page;
        return fallbackPageFromTreeText(visibleText.toString());
    }

    private static PageGuard.Page fallbackPageFromTreeText(String text) {
        if (text == null) return PageGuard.Page.UNKNOWN;
        String lower = text.toLowerCase(Locale.US).replace(',', '.');
        boolean hasMoney = LIVE_MONEY.matcher(lower).find();
        boolean hasMiles = LIVE_MILES.matcher(lower).find();
        // DeliverThat's Offers page exposes offer-specific tree text even on builds where
        // the Offers tab does not report selected=true and the action labels are blank.
        // "Exclusive" / "Expires" are strong offer-page evidence and are not used on Jobs.
        if ((lower.contains("exclusive") && lower.contains("offer"))
                || (lower.contains("expires") && hasMoney && hasMiles)) return PageGuard.Page.OFFERS;
        return PageGuard.Page.UNKNOWN;
    }

    private static void collectPageFlags(AccessibilityNodeInfo node, boolean[] flags, StringBuilder visibleText) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean usable = node.isVisibleToUser() || !bounds.isEmpty()
                || node.isSelected() || node.isChecked() || node.isClickable();
        if (usable) {
            for (CharSequence value : new CharSequence[]{node.getText(), node.getContentDescription()}) {
                if (value == null) continue;
                visibleText.append(value).append(' ');
                String label = value.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", "");
                if (node.isSelected() || node.isChecked()) {
                    if (label.equals("ignored")) flags[0] = true;
                    if (label.equals("jobs")) flags[1] = true;
                    if (label.equals("offers") || label.startsWith("offers")) flags[2] = true;
                }
                if (label.equals("restore") || label.equals("restorebutton")) flags[3] = true;
                if (ButtonLabels.isReject(value)) flags[4] = true;
                if (matchesAccept(value)) flags[5] = true;
                if (label.equals("nooffersavailable") || label.equals("nooffers")) flags[6] = true;
            }
        }
        // Do not prune an entire subtree just because an intermediate WebView/Compose
        // container reports isVisibleToUser=false. Several DeliverThat builds do exactly
        // that while their descendants still carry useful accessibility semantics.
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectPageFlags(child, flags, visibleText); child.recycle(); }
        }
    }

    public static String debugTreeSummary() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return "辅助服务未连接";
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return "前台非DeliverThat或无活动窗口树";
        PageGuard.Page page = pageFromScan(scan);
        return "树页=" + page + "；窗口=" + scan.windowsScanned
                + "；文本块=" + scan.pieces.size() + "；可点击=" + scan.clickables.size()
                + "；语义Accept=" + scan.accepts.size() + "；语义Reject=" + scan.rejects.size();
    }

    public static FastOfferSnapshot getFastOfferSnapshot() {
        List<FastOfferSnapshot> cards = getFastOfferSnapshots();
        return cards.isEmpty() ? null : cards.get(0);
    }

    public static List<FastOfferSnapshot> getFastOfferSnapshots() {
        List<FastOfferSnapshot> cards = new ArrayList<>();
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return cards;
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan)) return cards;
        PageGuard.Page page = pageFromScan(scan);
        updatePageHint(page);
        if (page != PageGuard.Page.OFFERS) {
            String treeText = scan.visibleText.toString();
            boolean hasOfferNumbers = LIVE_MONEY.matcher(treeText).find() && LIVE_MILES.matcher(treeText).find();
            boolean hasActionStructure = !scan.accepts.isEmpty() || !scan.rejects.isEmpty()
                    || scan.clickables.size() >= 2;
            // v2.10: blank-label React-Native/WebView buttons can leave the page classifier
            // at UNKNOWN. Money+miles plus a real action-row structure is sufficient to
            // enter the read-only card builder; the final click still revalidates foreground,
            // card identity and numbers.
            if (!(page == PageGuard.Page.UNKNOWN && hasOfferNumbers && hasActionStructure)) return cards;
        }
        List<ActionHit> anchors = new ArrayList<>(scan.accepts);
        for (ActionHit reject : scan.rejects) {
            boolean paired = false;
            for (ActionHit accept : scan.accepts) if (sameRow(accept.bounds, reject.bounds)) { paired = true; break; }
            if (!paired) anchors.add(reject);
        }
        anchors.sort(java.util.Comparator.comparingInt(hit -> hit.bounds.top));
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (ActionHit anchor : anchors) {
            Rect accept = new Rect(), reject = new Rect();
            boolean acceptEnabled = false, rejectEnabled = false;
            for (ActionHit candidate : scan.accepts) {
                if (sameRow(candidate.bounds, anchor.bounds)) {
                    accept.set(candidate.bounds); acceptEnabled = candidate.enabled; break;
                }
            }
            for (ActionHit candidate : scan.rejects) {
                if (sameRow(candidate.bounds, anchor.bounds)) {
                    reject.set(candidate.bounds); rejectEnabled = candidate.enabled; break;
                }
            }
            String text = CardText.aboveButton(scan.pieces, anchor.bounds.top, anchor.bounds.bottom);
            if (!CardText.MONEY.matcher(text).find() || !LIVE_MILES.matcher(text).find()) continue;

            // v2.10.8: never "upgrade" a semantic Ignore/Accept label to a larger clickable
            // ancestor. Real recordings showed that DeliverThat marks the entire offer card
            // clickable; v2.10.7 then replaced the correct Ignore label rectangle with the
            // card rectangle and opened details. Keep a semantic rectangle if it is geometrically
            // safe; use structural blank-label buttons only to fill a genuinely missing side.
            if (!accept.isEmpty() && !safeActionBounds(scan.rootBounds, accept, true)) {
                accept.setEmpty(); acceptEnabled = false;
            }
            if (!reject.isEmpty() && !safeActionBounds(scan.rootBounds, reject, false)) {
                reject.setEmpty(); rejectEnabled = false;
            }
            FastOfferSnapshot structuralFill = structuralActionsForText(scan, text);
            if (structuralFill != null) {
                if (accept.isEmpty() && !structuralFill.acceptBounds.isEmpty()
                        && safeActionBounds(scan.rootBounds, structuralFill.acceptBounds, true)) {
                    accept.set(structuralFill.acceptBounds); acceptEnabled = structuralFill.acceptEnabled;
                }
                if (reject.isEmpty() && !structuralFill.rejectBounds.isEmpty()
                        && safeActionBounds(scan.rootBounds, structuralFill.rejectBounds, false)) {
                    reject.set(structuralFill.rejectBounds); rejectEnabled = structuralFill.rejectEnabled;
                }
            }
            if (seen.add(CardText.identity(text)))
                cards.add(new FastOfferSnapshot(text, accept, reject, acceptEnabled, rejectEnabled));
        }

        // Structural Accessibility fallback: some DeliverThat releases expose the two
        // bottom action controls as clickable nodes with blank text/description. In that
        // case v2.9.1 reported zero cards and fell all the way back to ~1s OCR. Pair the
        // clickable controls by row and attach them to the nearest money+miles card text.
        if (cards.isEmpty() && !scan.clickables.isEmpty()) {
            List<ActionHit> structural = new ArrayList<>(scan.clickables);
            structural.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                    .thenComparingInt(hit -> hit.bounds.left));
            for (ActionHit anchor : structural) {
                String text = CardText.aboveButton(scan.pieces, anchor.bounds.top, anchor.bounds.bottom);
                if (!CardText.MONEY.matcher(text).find() || !LIVE_MILES.matcher(text).find()) continue;
                String id = CardText.identity(text);
                if (seen.contains(id)) continue;
                FastOfferSnapshot structuralCard = structuralActionsForText(scan, text);
                if (structuralCard != null
                        && (!structuralCard.acceptBounds.isEmpty() || !structuralCard.rejectBounds.isEmpty())) {
                    seen.add(id);
                    cards.add(structuralCard);
                }
            }
        }
        return cards;
    }

    private static boolean sameRow(Rect a, Rect b) {
        return a.top < b.bottom && a.bottom > b.top;
    }

    private static float rectArea(Rect r) {
        if (r == null || r.isEmpty()) return 0f;
        return (float) r.width() * (float) r.height();
    }

    /** v2.10.8: action bounds must be button-sized and stay on the expected side. */
    private static boolean safeActionBounds(Rect rootBounds, Rect bounds, boolean accept) {
        if (rootBounds == null || rootBounds.isEmpty() || bounds == null || bounds.isEmpty()) return false;
        return ActionGeometry.plausibleActionRect(rootBounds.width(), rootBounds.height(),
                bounds.left - rootBounds.left, bounds.top - rootBounds.top,
                bounds.right - rootBounds.left, bounds.bottom - rootBounds.top, accept);
    }

    private static boolean safeStructuralBounds(Rect rootBounds, Rect bounds) {
        if (rootBounds == null || rootBounds.isEmpty() || bounds == null || bounds.isEmpty()) return false;
        return ActionGeometry.plausibleStructuralButton(rootBounds.width(), rootBounds.height(),
                bounds.left - rootBounds.left, bounds.top - rootBounds.top,
                bounds.right - rootBounds.left, bounds.bottom - rootBounds.top);
    }

    private static float safeTapX(Rect rootBounds, Rect bounds, boolean accept) {
        float local = bounds.exactCenterX() - rootBounds.left;
        return rootBounds.left + ActionGeometry.stableTapX(rootBounds.width(), local, accept);
    }

    /**
     * Returns the first visible offer card text even when its Ignore button is temporarily
     * disabled/renamed by a countdown. This lets the serial queue keep lower cards locked.
     */
    public static String getTopVisibleOfferText() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return "";
        WindowScan scan = new WindowScan();
        if (!scanDeliverThatWindows(service, scan) || scan.pieces.isEmpty()) return "";
        java.util.List<CardText.Piece> pieces = new java.util.ArrayList<>(scan.pieces);
        pieces.sort(java.util.Comparator.comparingDouble((CardText.Piece p) -> p.top)
                .thenComparingDouble(p -> p.left));
        CardText.Piece money = null, miles = null;
        for (CardText.Piece p : pieces) {
            if (money == null && CardText.MONEY.matcher(p.text).find()) money = p;
            if (miles == null && LIVE_MILES.matcher(p.text).find()) miles = p;
            if (money != null && miles != null) {
                float row = Math.max(money.bottom - money.top, miles.bottom - miles.top);
                if (Math.abs(money.top - miles.top) <= Math.max(18f, row * 3f)) break;
                if (money.top < miles.top) money = null; else miles = null;
            }
        }
        if (money == null || miles == null) return "";
        float start = Math.min(money.top, miles.top);
        float end = start + 430f;
        // Stop before the next offer's money/miles row when multiple cards are visible.
        for (CardText.Piece p : pieces) {
            if (p.top <= start + 90f) continue;
            if (CardText.MONEY.matcher(p.text).find() || LIVE_MILES.matcher(p.text).find()) {
                end = Math.min(end, p.top - 4f);
                break;
            }
        }
        StringBuilder out = new StringBuilder();
        for (CardText.Piece p : pieces)
            if (p.top >= start && p.top < end) out.append(p.text).append(' ');
        return out.toString().trim();
    }

    public static FastOfferSnapshot findOffer(String expectedText) {
        for (FastOfferSnapshot card : getFastOfferSnapshots())
            if (CardText.sameOffer(expectedText, card.text)) return card;
        return null;
    }

    // One hierarchy traversal supplies page, button geometry and card text together.
    private static final class ActionHit {
        final Rect bounds;
        final boolean enabled;
        ActionHit(Rect bounds, boolean enabled) { this.bounds = new Rect(bounds); this.enabled = enabled; }
    }

    private static final class WindowScan {
        final boolean[] flags = new boolean[7];
        final List<ActionHit> accepts = new ArrayList<>();
        final List<ActionHit> rejects = new ArrayList<>();
        // v2.9.2+: collect raw clickable/actionable nodes even when their text/contentDescription
        // is blank. Semantics come from hierarchy + geometry first; OCR is only a fallback.
        final List<ActionHit> clickables = new ArrayList<>();
        final List<CardText.Piece> pieces = new ArrayList<>();
        final StringBuilder visibleText = new StringBuilder();
        final Rect rootBounds = new Rect();
        int windowsScanned;
    }

    /**
     * v2.9.3: scan the active DeliverThat window plus any additional interactive
     * DeliverThat windows exposed by Accessibility. React-Native/WebView/Compose builds
     * can split useful descendants across windows even though getRootInActiveWindow()
     * only exposes the shell container.
     *
     * Safety invariant: we still require the ACTIVE window to belong to DeliverThat.
     * Additional windows are used only as extra tree content while DeliverThat is truly
     * foreground, so pulling down notifications cannot accidentally authorize a click.
     */
    private static boolean scanDeliverThatWindows(TapAccessibilityService service, WindowScan scan) {
        if (service == null || scan == null) return false;
        AccessibilityNodeInfo active = service.getRootInActiveWindow();
        if (active == null) return false;
        int activeWindowId = Integer.MIN_VALUE;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    active.getPackageName() == null ? "" : active.getPackageName())) return false;
            activeWindowId = active.getWindowId();
            active.getBoundsInScreen(scan.rootBounds);
            scanWindow(active, scan);
            scan.windowsScanned++;
        } finally {
            active.recycle();
        }

        try {
            List<AccessibilityWindowInfo> windows = service.getWindows();
            if (windows == null) return true;
            for (AccessibilityWindowInfo window : windows) {
                if (window == null) continue;
                // Samsung/React-Native normally returns the active Accessibility root again
                // from getWindows(). v2.10.17 walked that same hierarchy twice, which both
                // inflated card text and cost hundreds of milliseconds in field traces.
                // Keep secondary DeliverThat windows, but never rescan the active window id.
                if (window.getId() == activeWindowId) continue;
                AccessibilityNodeInfo root = null;
                try {
                    root = window.getRoot();
                    if (root == null || root.getWindowId() == activeWindowId
                            || !"com.deliverthat.driver".contentEquals(
                            root.getPackageName() == null ? "" : root.getPackageName())) continue;
                    Rect bounds = new Rect();
                    root.getBoundsInScreen(bounds);
                    if (scan.rootBounds.isEmpty() && !bounds.isEmpty()) scan.rootBounds.set(bounds);
                    scanWindow(root, scan);
                    scan.windowsScanned++;
                } finally {
                    if (root != null) root.recycle();
                }
            }
        } catch (RuntimeException ignored) {
            // Some OEM Accessibility implementations transiently throw while windows are
            // changing. The already-scanned active tree remains usable.
        }
        return true;
    }

    private static PageGuard.Page pageFromScan(WindowScan scan) {
        if (scan == null) return PageGuard.Page.UNKNOWN;
        PageGuard.Page page = PageGuard.classify(scan.flags[0], scan.flags[1], scan.flags[2],
                scan.flags[3], scan.flags[4], scan.flags[5], scan.flags[6]);
        String treeText = scan.visibleText.toString();
        boolean hasMoney = LIVE_MONEY.matcher(treeText).find();
        boolean hasMiles = LIVE_MILES.matcher(treeText).find();
        boolean hasLiveAction = !scan.accepts.isEmpty() || !scan.rejects.isEmpty();
        // v2.10.19: field evidence showed a real Offers card could stay visible for seconds
        // while React-Native exposed a stale selected Jobs/Ignored tab flag.  A live current
        // money+miles card plus a safe Accept/Reject node is stronger evidence than that stale
        // tab bit.  Restore still wins, so the real Ignored page cannot be promoted to Offers.
        if ((page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED)
                && !scan.flags[3] && hasMoney && hasMiles && hasLiveAction) {
            page = PageGuard.Page.OFFERS;
        }
        if (page == PageGuard.Page.UNKNOWN)
            page = fallbackPageFromTreeText(treeText);
        return page;
    }

    private static void addUniquePiece(List<CardText.Piece> pieces, String value, Rect bounds) {
        if (pieces == null || value == null || value.isEmpty() || bounds == null || bounds.isEmpty()) return;
        String normalized = value.replaceAll("\\s+", " ").trim();
        if (normalized.isEmpty()) return;
        for (CardText.Piece piece : pieces) {
            if (piece.left == bounds.left && piece.top == bounds.top && piece.bottom == bounds.bottom
                    && normalized.equals(piece.text.replaceAll("\\s+", " ").trim())) return;
        }
        pieces.add(new CardText.Piece(normalized, bounds.left, bounds.top, bounds.bottom));
    }

    private static FastOfferSnapshot structuralActionsForText(WindowScan scan, String text) {
        if (scan == null || text == null || text.isEmpty() || scan.clickables.isEmpty()) return null;
        List<ActionHit> row = new ArrayList<>();
        for (ActionHit candidate : scan.clickables) {
            String candidateText = CardText.aboveButton(scan.pieces,
                    candidate.bounds.top, candidate.bounds.bottom);
            if (CardText.sameOffer(text, candidateText)) row.add(candidate);
        }
        if (row.isEmpty()) return null;
        // Keep only the lowest same-row cluster associated with the card. A card container
        // or detail affordance higher up must not be mistaken for the action row.
        row.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                .thenComparingInt(hit -> hit.bounds.left));
        ActionHit lowest = row.get(row.size() - 1);
        List<ActionHit> actionRow = new ArrayList<>();
        for (ActionHit hit : row) if (sameActionRow(hit.bounds, lowest.bounds)) actionRow.add(hit);
        actionRow.sort(java.util.Comparator.comparingInt(hit -> hit.bounds.left));
        if (actionRow.isEmpty()) return null;
        Rect accept = new Rect(), reject = new Rect();
        boolean acceptEnabled = false, rejectEnabled = false;
        int mid = scan.rootBounds.centerX();
        ActionHit left = actionRow.get(0), right = actionRow.get(actionRow.size() - 1);
        if (actionRow.size() >= 2 && right.bounds.centerX() > left.bounds.centerX()) {
            reject.set(left.bounds); rejectEnabled = left.enabled;
            accept.set(right.bounds); acceptEnabled = right.enabled;
        } else {
            ActionHit only = actionRow.get(0);
            if (only.bounds.centerX() >= mid) {
                accept.set(only.bounds); acceptEnabled = only.enabled;
            } else {
                reject.set(only.bounds); rejectEnabled = only.enabled;
            }
        }
        return new FastOfferSnapshot(text, accept, reject, acceptEnabled, rejectEnabled);
    }

    private static boolean sameActionRow(Rect a, Rect b) {
        int tolerance = Math.max(18, Math.max(a.height(), b.height()));
        return Math.abs(a.centerY() - b.centerY()) <= tolerance;
    }

    private static void addUniqueHit(List<ActionHit> hits, Rect bounds, boolean enabled) {
        if (bounds == null || bounds.isEmpty()) return;
        for (ActionHit hit : hits) {
            if (hit.bounds.equals(bounds)) return;
            Rect intersection = new Rect(hit.bounds);
            if (intersection.intersect(bounds)) {
                float overlap = (float) intersection.width() * intersection.height();
                float smaller = Math.min((float) hit.bounds.width() * hit.bounds.height(),
                        (float) bounds.width() * bounds.height());
                if (smaller > 0 && overlap / smaller > 0.92f) return;
            }
        }
        hits.add(new ActionHit(bounds, enabled));
    }

    private static boolean structuralActionShape(AccessibilityNodeInfo node, Rect bounds, Rect rootBounds) {
        if (node == null || bounds == null || bounds.isEmpty() || rootBounds.isEmpty()) return false;
        boolean actionable = node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0
                || (node.getClassName() != null
                    && node.getClassName().toString().toLowerCase(Locale.US).contains("button"));
        if (!actionable) return false;
        // v2.10.8: structural/blank-label nodes are fallback-only. Reject any candidate
        // that resembles the whole offer card, row container, or tiny details arrow.
        return safeStructuralBounds(rootBounds, bounds);
    }

    private static void scanWindow(AccessibilityNodeInfo node, WindowScan scan) {
        if (node == null) return;
        CharSequence text = node.getText(), description = node.getContentDescription();
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean intersectsScreen = !bounds.isEmpty() && (scan.rootBounds.isEmpty()
                || Rect.intersects(bounds, scan.rootBounds));
        boolean usable = node.isVisibleToUser() || intersectsScreen
                || node.isSelected() || node.isChecked() || node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0;
        CharSequence value = text == null || text.length() == 0 ? description : text;
        if (usable && value != null) {
            scan.visibleText.append(value).append(' ');
            if (!bounds.isEmpty()) addUniquePiece(scan.pieces, value.toString(), bounds);
        }
        if (usable && structuralActionShape(node, bounds, scan.rootBounds))
            addUniqueHit(scan.clickables, bounds, actionNodeReady(node));
        if (usable) {
            for (CharSequence labelValue : new CharSequence[]{text, description}) {
                if (labelValue == null) continue;
                String label = labelValue.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", "");
                if (node.isSelected() || node.isChecked()) {
                    if (label.equals("ignored")) scan.flags[0] = true;
                    if (label.equals("jobs")) scan.flags[1] = true;
                    if (label.equals("offers")) scan.flags[2] = true;
                }
                if (label.equals("restore") || label.equals("restorebutton")) scan.flags[3] = true;
                if (ButtonLabels.isReject(labelValue)) scan.flags[4] = true;
                if (matchesAccept(labelValue)) scan.flags[5] = true;
                if (label.equals("nooffersavailable") || label.equals("nooffers")) scan.flags[6] = true;
            }
            if (!bounds.isEmpty()) {
                boolean ready = actionNodeReady(node);
                if ((matchesAccept(text) || matchesAccept(description))
                        && safeActionBounds(scan.rootBounds, bounds, true))
                    addUniqueHit(scan.accepts, bounds, ready);
                if ((ButtonLabels.isReject(text) || ButtonLabels.isReject(description))
                        && safeActionBounds(scan.rootBounds, bounds, false))
                    addUniqueHit(scan.rejects, bounds, ready);
            }
        }

        // Always recurse. An invisible intermediate WebView/Compose container must not
        // suppress accessible descendants.
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { try { scanWindow(child, scan); } finally { child.recycle(); } }
        }
    }

    private static boolean findRejectBounds(AccessibilityNodeInfo node, Rect accept, Rect out) {
        if (node == null || !node.isVisibleToUser() || !node.isEnabled()) return false;
        if (ButtonLabels.isReject(node.getText()) || ButtonLabels.isReject(node.getContentDescription())) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (!bounds.isEmpty() && (accept.isEmpty() || (bounds.top < accept.bottom && bounds.bottom > accept.top))) {
                out.set(bounds);
                return true;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = findRejectBounds(child, accept, out);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    private static String cardText(AccessibilityNodeInfo root, Rect button) {
        List<CardText.Piece> pieces = new ArrayList<>();
        collectPieces(root, pieces);
        return CardText.aboveButton(pieces, button.top, button.bottom);
    }

    private static void collectPieces(AccessibilityNodeInfo node, List<CardText.Piece> pieces) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        CharSequence value = node.getText();
        if (value == null || value.length() == 0) value = node.getContentDescription();
        if (value != null && !bounds.isEmpty()) pieces.add(new CardText.Piece(
                value.toString(), bounds.left, bounds.top, bounds.bottom));
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectPieces(child, pieces); child.recycle(); }
        }
    }

    private static void collectSnapshot(AccessibilityNodeInfo node, StringBuilder text, Rect accept) {
        if (node == null || !node.isVisibleToUser()) return;
        CharSequence label = node.getText();
        CharSequence description = node.getContentDescription();
        if (label != null) text.append(label).append(' ');
        if (description != null && !description.equals(label)) text.append(description).append(' ');
        if (accept.isEmpty() && node.isEnabled()
                && (matchesAccept(label) || matchesAccept(description))) node.getBoundsInScreen(accept);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectSnapshot(child, text, accept);
                child.recycle();
            }
        }
    }

    private static boolean matchesAccept(CharSequence value) {
        return value != null && isAcceptLabel(value.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", ""));
    }

    private static boolean findAcceptBounds(AccessibilityNodeInfo node, Rect out) {
        if (node == null) return false;
        String label = "";
        if (node.getText() != null) label += node.getText().toString();
        if (node.getContentDescription() != null) label += " " + node.getContentDescription();
        String normalized = label.toLowerCase(Locale.US).replaceAll("[^a-z]", "");
        if (isAcceptLabel(normalized)) {
            node.getBoundsInScreen(out);
            if (!out.isEmpty()) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = findAcceptBounds(child, out);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    /** v2.10.9 bounded active-window refresh for a stale first-tap snapshot. */
    private static final class QuickActionProbe {
        final Rect rootBounds = new Rect();
        final List<CardText.Piece> pieces = new ArrayList<>();
        final List<ActionHit> accepts = new ArrayList<>();
        final List<ActionHit> rejects = new ArrayList<>();
        final List<ActionHit> structural = new ArrayList<>();
    }

    /**
     * Re-read only a bounded prefix of the ACTIVE DeliverThat Accessibility tree.  This is
     * deliberately much cheaper than getFastOfferSnapshots(): no secondary windows, no full
     * page/card reconstruction, no OCR.  A stale coordinate is revived only when the current
     * top action row still carries the exact same low-end pay and mileage values.
     */
    /**
     * v2.10.18 latency path: build only the CURRENT first offer from a bounded active-window
     * prefix. This avoids the expensive multi-window/full-tree scan when the Galaxy A15
     * already exposes the first card and its action row in the active React-Native tree.
     *
     * Safety: the quick path still blocks explicit Jobs/Ignored, requires a top numeric pair,
     * button-sized left/right geometry, and returns only the action row belonging to that
     * top numeric pair. Callers may fall back to the full scan/OCR when text is incomplete.
     */
    public static FastOfferSnapshot getQuickTopOfferSnapshot() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return null;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return null;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return null;
            PageGuard.Page page = quickPageOf(root, 32);
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) return null;

            QuickActionProbe probe = new QuickActionProbe();
            root.getBoundsInScreen(probe.rootBounds);
            if (probe.rootBounds.isEmpty()) return null;
            int[] budget = new int[]{180};
            quickCollectActionEvidence(root, probe, budget);
            return quickTopSnapshotFromProbe(probe);
        } finally { root.recycle(); }
    }

    private static FastOfferSnapshot quickTopSnapshotFromProbe(QuickActionProbe probe) {
        if (probe == null || probe.rootBounds.isEmpty() || probe.pieces.isEmpty()) return null;
        String topText = topVisibleOfferTextFromPieces(probe.pieces);
        float topAmount = directAmount(topText), topMiles = directMiles(topText);
        if (topAmount < 0 || topMiles < 0) return null;

        List<ActionHit> anchors = new ArrayList<>();
        anchors.addAll(probe.accepts);
        anchors.addAll(probe.rejects);
        for (ActionHit hit : probe.structural) {
            if (safeActionBounds(probe.rootBounds, hit.bounds, true)
                    || safeActionBounds(probe.rootBounds, hit.bounds, false))
                addUniqueHit(anchors, hit.bounds, hit.enabled);
        }
        anchors.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                .thenComparingInt(hit -> hit.bounds.left));

        for (ActionHit anchor : anchors) {
            String cardText = CardText.aboveButton(probe.pieces, anchor.bounds.top, anchor.bounds.bottom);
            if (!quickNumericPairMatches(cardText, topAmount, topMiles)) continue;
            Rect accept = new Rect(), reject = new Rect();
            boolean acceptEnabled = false, rejectEnabled = false;
            for (ActionHit hit : probe.accepts) {
                if (sameRow(hit.bounds, anchor.bounds)
                        && safeActionBounds(probe.rootBounds, hit.bounds, true)) {
                    accept.set(hit.bounds); acceptEnabled = hit.enabled; break;
                }
            }
            for (ActionHit hit : probe.rejects) {
                if (sameRow(hit.bounds, anchor.bounds)
                        && safeActionBounds(probe.rootBounds, hit.bounds, false)) {
                    reject.set(hit.bounds); rejectEnabled = hit.enabled; break;
                }
            }
            for (ActionHit hit : probe.structural) {
                if (!sameRow(hit.bounds, anchor.bounds)) continue;
                if (accept.isEmpty() && safeActionBounds(probe.rootBounds, hit.bounds, true)) {
                    accept.set(hit.bounds); acceptEnabled = hit.enabled;
                }
                if (reject.isEmpty() && safeActionBounds(probe.rootBounds, hit.bounds, false)) {
                    reject.set(hit.bounds); rejectEnabled = hit.enabled;
                }
            }
            if (!accept.isEmpty() || !reject.isEmpty())
                return new FastOfferSnapshot(cardText, accept, reject, acceptEnabled, rejectEnabled,
                        SystemClock.elapsedRealtime());
        }
        return null;
    }

    private static String topVisibleOfferTextFromPieces(List<CardText.Piece> source) {
        if (source == null || source.isEmpty()) return "";
        List<CardText.Piece> pieces = new ArrayList<>(source);
        pieces.sort(java.util.Comparator.comparingDouble((CardText.Piece p) -> p.top)
                .thenComparingDouble(p -> p.left));
        CardText.Piece money = null, miles = null;
        for (CardText.Piece p : pieces) {
            if (money == null && CardText.MONEY.matcher(p.text).find()) money = p;
            if (miles == null && LIVE_MILES.matcher(p.text).find()) miles = p;
            if (money != null && miles != null) {
                float row = Math.max(money.bottom - money.top, miles.bottom - miles.top);
                if (Math.abs(money.top - miles.top) <= Math.max(18f, row * 3f)) break;
                if (money.top < miles.top) money = null; else miles = null;
            }
        }
        if (money == null || miles == null) return "";
        float start = Math.min(money.top, miles.top);
        float end = start + 430f;
        for (CardText.Piece p : pieces) {
            if (p.top <= start + 90f) continue;
            if (CardText.MONEY.matcher(p.text).find() || LIVE_MILES.matcher(p.text).find()) {
                end = Math.min(end, p.top - 4f);
                break;
            }
        }
        StringBuilder out = new StringBuilder();
        for (CardText.Piece p : pieces)
            if (p.top >= start && p.top < end) out.append(p.text).append(' ');
        return out.toString().trim();
    }

    /** v2.10.14: bounded active-window consensus used to retire a stale serial lock
     * without waiting a full second OCR cycle. It proves that the CURRENT top action row
     * carries the same amount+miles pair that OCR just read. */
    public static FastOfferSnapshot quickVerifyTopAction(float expectedAmount, float expectedMiles,
                                                          boolean accept) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) return null;
        return quickRefreshTopAction(service, expectedAmount, expectedMiles, accept);
    }

    private static FastOfferSnapshot quickRefreshTopAction(TapAccessibilityService service,
                                                            float expectedAmount, float expectedMiles,
                                                            boolean accept) {
        if (service == null) return null;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return null;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return null;
            PageGuard.Page page = quickPageOf(root, 32);
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) return null;

            QuickActionProbe probe = new QuickActionProbe();
            root.getBoundsInScreen(probe.rootBounds);
            if (probe.rootBounds.isEmpty()) return null;
            int[] budget = new int[]{180};
            quickCollectActionEvidence(root, probe, budget);
            List<ActionHit> candidates = new ArrayList<>(accept ? probe.accepts : probe.rejects);
            // Blank-label React-Native controls are allowed only when their geometry itself
            // is a real left/right action button. Whole-card clickable ancestors never pass.
            for (ActionHit hit : probe.structural) {
                if (safeActionBounds(probe.rootBounds, hit.bounds, accept)) candidates.add(hit);
            }
            candidates.sort(java.util.Comparator.comparingInt((ActionHit hit) -> hit.bounds.top)
                    .thenComparingInt(hit -> hit.bounds.left));
            for (ActionHit hit : candidates) {
                if (!safeActionBounds(probe.rootBounds, hit.bounds, accept)) continue;
                String text = CardText.aboveButton(probe.pieces, hit.bounds.top, hit.bounds.bottom);
                if (!quickNumericPairMatches(text, expectedAmount, expectedMiles)) continue;
                Rect a = new Rect(), r = new Rect();
                boolean ae = false, re = false;
                if (accept) { a.set(hit.bounds); ae = hit.enabled; }
                else { r.set(hit.bounds); re = hit.enabled; }
                return new FastOfferSnapshot(text, a, r, ae, re,
                        SystemClock.elapsedRealtime());
            }
            return null;
        } finally { root.recycle(); }
    }

    private static void quickCollectActionEvidence(AccessibilityNodeInfo node,
                                                    QuickActionProbe probe, int[] budget) {
        if (node == null || probe == null || budget[0]-- <= 0) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        CharSequence text = node.getText(), desc = node.getContentDescription();
        boolean usable = node.isVisibleToUser() || node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0;
        if (usable && !bounds.isEmpty()) {
            if (text != null && text.length() > 0) addUniquePiece(probe.pieces, text.toString(), bounds);
            if (desc != null && desc.length() > 0) addUniquePiece(probe.pieces, desc.toString(), bounds);
            boolean ready = actionNodeReady(node);
            if ((matchesAccept(text) || matchesAccept(desc))
                    && safeActionBounds(probe.rootBounds, bounds, true))
                addUniqueHit(probe.accepts, bounds, ready);
            if ((ButtonLabels.isReject(text) || ButtonLabels.isReject(desc))
                    && safeActionBounds(probe.rootBounds, bounds, false))
                addUniqueHit(probe.rejects, bounds, ready);
            if (structuralActionShape(node, bounds, probe.rootBounds))
                addUniqueHit(probe.structural, bounds, ready);
        }
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { quickCollectActionEvidence(child, probe, budget); }
                finally { child.recycle(); }
            }
        }
    }

    private static boolean quickNumericPairMatches(String text, float expectedAmount,
                                                   float expectedMiles) {
        if (text == null || text.isEmpty() || expectedAmount < 0 || expectedMiles < 0) return false;
        float amount = -1f, miles = -1f;
        java.util.regex.Matcher range = LIVE_MONEY_RANGE.matcher(text);
        java.util.regex.Matcher money = LIVE_MONEY.matcher(text);
        java.util.regex.Matcher mi = LIVE_MILES.matcher(text);
        try {
            if (range.find()) amount = Float.parseFloat(range.group(1).replace(',', '.'));
            else if (money.find()) amount = Float.parseFloat(money.group(1).replace(',', '.'));
            if (mi.find()) miles = Float.parseFloat(mi.group(1).replace(',', '.'));
        } catch (RuntimeException ignored) { return false; }
        return amount >= 0 && miles >= 0
                && Math.abs(amount - expectedAmount) <= 0.011f
                && Math.abs(miles - expectedMiles) <= 0.051f;
    }

    /**
     * v2.10.5 first-tap path. The card has already been read and isolated by the same
     * Accessibility scan, so do not spend another 200-800 ms walking the entire tree before
     * the first gesture. We only accept a very fresh snapshot, re-check the active package,
     * window bounds and a small forbidden-page probe, then tap the verified top-card button.
     */
    public static void tapSnapshotFast(FastOfferSnapshot snapshot, float amount, float miles,
                                       Runnable completion, Consumer<String> mismatch) {
        tapSnapshotFastDetailed(snapshot, amount, miles,
                detail -> { if (completion != null) completion.run(); }, mismatch);
    }

    /**
     * v2.10.12 Accept path: dispatch the verified top-card gesture immediately. Real-device
     * logs showed ACTION_CLICK consumed an extra observation round but did not change the UI,
     * while the 55ms gesture did move DeliverThat into disabled/processing state. Keep the
     * semantic machinery only as a diagnostic/fallback elsewhere; it is no longer on the
     * latency-critical first-claim path. A successful gesture dispatch is still not treated
     * as an accepted job by itself.
     */
    public static void tapSnapshotFastDetailed(FastOfferSnapshot snapshot, float amount, float miles,
                                                Consumer<String> completion, Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || snapshot == null || snapshot.acceptBounds.isEmpty()
                || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "顶部Accept快照不可用或DeliverThat不在前台");
            return;
        }
        service.main.postAtFrontOfQueue(() -> {
            long initialAge = SystemClock.elapsedRealtime() - snapshot.capturedAt;
            if (FastSnapshotPolicy.hardExpired(initialAge)) {
                if (mismatch != null) mismatch.accept("顶部Accept证据已超过硬时限" + initialAge + "ms；等待新订单帧");
                return;
            }
            FastOfferSnapshot current = snapshot;
            if (FastSnapshotPolicy.needsRefresh(initialAge, true)) {
                long verifyStarted = SystemClock.elapsedRealtime();
                current = quickRefreshTopAction(service, amount, miles, true);
                if (current == null) {
                    if (mismatch != null) mismatch.accept("顶部按钮快照" + initialAge
                            + "ms；轻量金额/里程/Accept核验未通过，未点击");
                    return;
                }
                android.util.Log.d("CSA", "stale Accept refreshed in "
                        + (SystemClock.elapsedRealtime() - verifyStarted) + "ms; oldAge=" + initialAge);
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消快速Accept");
                return;
            }

            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            PageGuard.Page quickPage = quickPageOf(root, 16);
            root.recycle();
            if (quickPage == PageGuard.Page.JOBS || quickPage == PageGuard.Page.IGNORED) {
                if (mismatch != null) mismatch.accept("页面为" + quickPage + "；取消快速Accept");
                return;
            }
            if (!safeActionBounds(rootBounds, current.acceptBounds, true)) {
                if (mismatch != null) mismatch.accept("顶部Accept热区几何异常（疑似整卡/容器）；禁止点击并重新识别");
                return;
            }
            if (!current.acceptEnabled) {
                if (mismatch != null) mismatch.accept("顶部Accept已禁用/处理中；本次不占用重试次数");
                return;
            }

            dispatchActionGesture(service, current.acceptBounds, true,
                    ActionDispatchPolicy.firstGestureDurationMs(true), 0,
                    detail -> {
                        if (completion != null) completion.accept("来源=Gesture首击 " + detail);
                    }, mismatch);
        });
    }

    private static final class SemanticNodeHit {
        final AccessibilityNodeInfo node;
        final Rect bounds;
        SemanticNodeHit(AccessibilityNodeInfo node, Rect bounds) {
            this.node = AccessibilityNodeInfo.obtain(node);
            this.bounds = new Rect(bounds);
        }
        void recycle() { node.recycle(); }
    }

    private static final class SemanticNodeProbe {
        final Rect rootBounds = new Rect();
        final List<CardText.Piece> pieces = new ArrayList<>();
        final List<SemanticNodeHit> hits = new ArrayList<>();
        int visited;
        void recycle() { for (SemanticNodeHit hit : hits) hit.recycle(); hits.clear(); }
    }

    private static final class SemanticActionResult {
        final boolean clicked;
        final Rect bounds;
        final int visited;
        SemanticActionResult(boolean clicked, Rect bounds, int visited) {
            this.clicked = clicked;
            this.bounds = bounds == null ? new Rect() : new Rect(bounds);
            this.visited = visited;
        }
    }

    /** One bounded active-root pass that both validates the numeric pair and clicks a real node. */
    private static SemanticActionResult trySemanticActionClick(TapAccessibilityService service,
                                                                float amount, float miles,
                                                                Rect expectedBounds,
                                                                boolean accept) {
        if (service == null) return new SemanticActionResult(false, null, 0);
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return new SemanticActionResult(false, null, 0);
        SemanticNodeProbe probe = new SemanticNodeProbe();
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName()))
                return new SemanticActionResult(false, null, 0);
            PageGuard.Page page = quickPageOf(root, 28);
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED)
                return new SemanticActionResult(false, null, 0);
            root.getBoundsInScreen(probe.rootBounds);
            if (probe.rootBounds.isEmpty()) return new SemanticActionResult(false, null, 0);
            int[] budget = new int[]{180};
            collectSemanticNodeProbe(root, probe, accept, budget);
            probe.hits.sort((a, b) -> Float.compare(
                    actionHitScore(a.bounds, expectedBounds), actionHitScore(b.bounds, expectedBounds)));
            for (SemanticNodeHit hit : probe.hits) {
                if (!safeActionBounds(probe.rootBounds, hit.bounds, accept)) continue;
                if (expectedBounds != null && !expectedBounds.isEmpty()) {
                    float dy = Math.abs(hit.bounds.exactCenterY() - expectedBounds.exactCenterY());
                    float tolerance = Math.max(90f, expectedBounds.height() * 2.2f);
                    if (dy > tolerance) continue;
                }
                String liveText = CardText.aboveButton(probe.pieces, hit.bounds.top, hit.bounds.bottom);
                if (!quickNumericPairMatches(liveText, amount, miles)) continue;
                boolean clicked = performClickNodeOrParentSafe(hit.node, accept, probe.rootBounds);
                if (clicked) return new SemanticActionResult(true, hit.bounds, probe.visited);
            }

            // React-Native sometimes exports the visible Ignore control as a blank clickable
            // node while the text itself is a non-clickable sibling. Resolve a structural
            // node only around the already-verified action rectangle; never search by a
            // fixed coordinate or climb into the full card.
            if (expectedBounds != null && !expectedBounds.isEmpty()) {
                AccessibilityNodeInfo structural = findActionNode(root, accept,
                        expectedBounds.exactCenterX(), expectedBounds.exactCenterY());
                if (structural != null) {
                    try {
                        Rect live = new Rect();
                        structural.getBoundsInScreen(live);
                        if (safeActionBounds(probe.rootBounds, live, accept)) {
                            String liveText = CardText.aboveButton(
                                    probe.pieces, live.top, live.bottom);
                            if (quickNumericPairMatches(liveText, amount, miles)
                                    && performClickNodeOrParentSafe(structural, accept, probe.rootBounds))
                                return new SemanticActionResult(true, live, probe.visited);
                        }
                    } finally { structural.recycle(); }
                }
            }
            return new SemanticActionResult(false, null, probe.visited);
        } finally {
            probe.recycle();
            root.recycle();
        }
    }

    /**
     * Reject-only hybrid dispatcher. ACTION_CLICK is the NovaFlow-style primary path on
     * Samsung because it targets the live accessibility node instead of merely injecting
     * coordinates. A gesture is used only when ACTION_CLICK is unavailable or the same
     * offer is still present with Reject enabled after the settle window.
     *
     * The semantic click + fallback gesture count as ONE RejectSequence attempt.
     */
    private static void dispatchRejectHybrid(TapAccessibilityService service,
                                             float amount, float miles, Rect expectedBounds,
                                             String expectedText, boolean requireMonitoring,
                                             Consumer<String> completion, Consumer<String> mismatch) {
        if (service == null || expectedBounds == null || expectedBounds.isEmpty()) {
            if (mismatch != null) mismatch.accept("Reject目标热区为空；未执行");
            return;
        }
        if (requireMonitoring && !OcrMonitorService.isMonitoring()) {
            if (mismatch != null) mismatch.accept("监控已停止；取消Reject");
            return;
        }
        if (!isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept("DeliverThat不在前台；取消Reject");
            return;
        }

        final Rect original = new Rect(expectedBounds);
        SemanticActionResult semantic = trySemanticActionClick(
                service, amount, miles, original, false);
        if (!semantic.clicked) {
            dispatchActionGesture(service, original, false,
                    ActionDispatchPolicy.rejectFallbackGestureDurationMs(), 0,
                    detail -> {
                        if (completion != null) completion.accept(
                                "ACTION_CLICK不可用→" + detail);
                    }, mismatch);
            return;
        }

        final Rect semanticBounds = semantic.bounds.isEmpty() ? original : new Rect(semantic.bounds);
        final int visited = semantic.visited;
        service.main.postDelayed(() -> {
            if (requireMonitoring && !OcrMonitorService.isMonitoring()) {
                if (completion != null) completion.accept(
                        "ACTION_CLICK已发送；随后监控停止，不再补手势");
                return;
            }
            if (!isDeliverThatForeground()) {
                if (completion != null) completion.accept(
                        "ACTION_CLICK已发送；DeliverThat已离开前台，不再补手势");
                return;
            }

            FastOfferSnapshot current = quickRefreshTopAction(service, amount, miles, false);
            if (current == null) {
                if (completion != null) completion.accept(
                        "ACTION_CLICK已发送；旧卡/Reject状态已变化（visited=" + visited + "），不盲目补点");
                return;
            }
            if (expectedText != null && !expectedText.isEmpty()
                    && !CardText.sameOfferForAction(expectedText, current.text)) {
                if (completion != null) completion.accept(
                        "ACTION_CLICK已发送；顶部已换单，不补手势");
                return;
            }
            if (!current.rejectEnabled) {
                if (completion != null) completion.accept(
                        "ACTION_CLICK已发送；Reject已禁用/处理中（visited=" + visited + "）");
                return;
            }

            Rect fallback = current.rejectBounds.isEmpty()
                    ? semanticBounds : new Rect(current.rejectBounds);
            dispatchActionGesture(service, fallback, false,
                    ActionDispatchPolicy.rejectFallbackGestureDurationMs(), 0,
                    detail -> {
                        if (completion != null) completion.accept(
                                "ACTION_CLICK无界面变化→" + detail);
                    }, mismatch);
        }, ActionDispatchPolicy.rejectSemanticSettleMs());
    }

    private static float actionHitScore(Rect bounds, Rect expected) {
        if (bounds == null || bounds.isEmpty()) return Float.MAX_VALUE;
        if (expected == null || expected.isEmpty()) return bounds.top;
        return Math.abs(bounds.exactCenterY() - expected.exactCenterY())
                + Math.abs(bounds.exactCenterX() - expected.exactCenterX()) * 0.25f;
    }

    private static void collectSemanticNodeProbe(AccessibilityNodeInfo node,
                                                  SemanticNodeProbe probe,
                                                  boolean accept, int[] budget) {
        if (node == null || probe == null || budget[0]-- <= 0) return;
        probe.visited++;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        CharSequence text = node.getText(), desc = node.getContentDescription();
        if (!bounds.isEmpty()) {
            if (text != null && text.length() > 0) addUniquePiece(probe.pieces, text.toString(), bounds);
            if (desc != null && desc.length() > 0) addUniquePiece(probe.pieces, desc.toString(), bounds);
            boolean labelMatch = accept ? (matchesAccept(text) || matchesAccept(desc))
                    : (ButtonLabels.isReject(text) || ButtonLabels.isReject(desc));
            if (labelMatch && actionNodeReady(node)
                    && safeActionBounds(probe.rootBounds, bounds, accept)) {
                probe.hits.add(new SemanticNodeHit(node, bounds));
            }
        }
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectSemanticNodeProbe(child, probe, accept, budget); }
                finally { child.recycle(); }
            }
        }
    }

    /**
     * Dispatch one gesture strictly inside a currently verified action rectangle.
     * variant 0=center, 1=slightly right/bottom, 2=slightly left/top; all stay inside the button.
     */
    private static void dispatchActionGesture(TapAccessibilityService service, Rect bounds,
                                              boolean accept, long durationMs, int variant,
                                              Consumer<String> completion, Consumer<String> mismatch) {
        if (service == null || bounds == null || bounds.isEmpty()) {
            if (mismatch != null) mismatch.accept("动作按钮热区为空；未发送手势");
            return;
        }
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null || !"com.deliverthat.driver".contentEquals(
                root.getPackageName() == null ? "" : root.getPackageName())) {
            if (root != null) root.recycle();
            if (mismatch != null) mismatch.accept("手势前DeliverThat窗口已变化；未点击");
            return;
        }
        Rect rootBounds = new Rect();
        root.getBoundsInScreen(rootBounds);
        PageGuard.Page page = quickPageOf(root, 20);
        root.recycle();
        if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) {
            if (mismatch != null) mismatch.accept("手势前页面为" + page + "；取消动作");
            return;
        }
        if (!safeActionBounds(rootBounds, bounds, accept)) {
            if (mismatch != null) mismatch.accept("动作热区几何异常（疑似整卡/容器）；取消手势");
            return;
        }
        float fx = 0.50f, fy = 0.50f;
        if (variant == 1) { fx = 0.62f; fy = 0.54f; }
        else if (variant == 2) { fx = 0.38f; fy = 0.46f; }
        float x = bounds.left + bounds.width() * fx;
        float y = bounds.top + bounds.height() * fy;
        if (!rootBounds.contains(Math.round(x), Math.round(y))) {
            if (mismatch != null) mismatch.accept("动作点已离开DeliverThat窗口；取消手势");
            return;
        }
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, Math.max(18L, durationMs)))
                .build();
        boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gestureDescription) {
                if (completion != null) completion.accept("Gesture" + durationMs + "ms rect="
                        + rectString(bounds) + " tap=(" + Math.round(x) + "," + Math.round(y) + ")");
            }
            @Override public void onCancelled(GestureDescription gestureDescription) {
                if (mismatch != null) mismatch.accept("系统取消了" + (accept ? "Accept" : "Reject")
                        + "手势；rect=" + rectString(bounds));
            }
        }, service.main);
        if (!dispatched && mismatch != null)
            mismatch.accept("系统未接受" + (accept ? "Accept" : "Reject")
                    + "手势；rect=" + rectString(bounds));
    }

    private static String rectString(Rect r) {
        if (r == null || r.isEmpty()) return "[]";
        return "[" + r.left + "," + r.top + "," + r.right + "," + r.bottom + "]";
    }

    /**
     * v2.10.17 fast Ignore/Reject path. The Galaxy A15 traces proved that Android can
     * report a completed dispatchGesture while DeliverThat leaves the visible Ignore
     * button untouched. For Reject only, prefer a live Accessibility ACTION_CLICK on the
     * verified button node. If the same offer is still present with Reject still enabled
     * after a short settle window, issue one slower gesture fallback inside the SAME
     * logical Reject attempt.
     */
    public static void tapSnapshotRejectFast(FastOfferSnapshot snapshot, float amount, float miles,
                                             Consumer<String> completion, Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || snapshot == null || snapshot.rejectBounds.isEmpty()
                || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "顶部Reject快照不可用或DeliverThat不在前台");
            return;
        }
        service.main.postAtFrontOfQueue(() -> {
            long initialAge = SystemClock.elapsedRealtime() - snapshot.capturedAt;
            if (FastSnapshotPolicy.hardExpired(initialAge)) {
                if (mismatch != null) mismatch.accept("顶部Reject证据已超过硬时限" + initialAge + "ms；等待新订单帧");
                return;
            }
            FastOfferSnapshot current = snapshot;
            if (FastSnapshotPolicy.needsRefresh(initialAge, false)) {
                current = quickRefreshTopAction(service, amount, miles, false);
                if (current == null) {
                    if (mismatch != null) mismatch.accept("顶部Reject快照" + initialAge
                            + "ms；轻量金额/里程/Ignore核验未通过，未点击");
                    return;
                }
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消快速Reject");
                return;
            }
            if (!isDeliverThatForeground()) {
                if (mismatch != null) mismatch.accept("DeliverThat已离开前台；取消快速Reject");
                return;
            }
            Rect expected = new Rect(current.rejectBounds);
            dispatchRejectHybrid(service, amount, miles, expected, current.text, true, completion, mismatch);
        });
    }


    private static String claimOutcomeHintFromEvent(AccessibilityEvent event) {
        if (event == null) return "";
        StringBuilder text = new StringBuilder();
        if (event.getText() != null) {
            for (CharSequence value : event.getText()) if (value != null) text.append(value).append(' ');
        }
        if (event.getContentDescription() != null) text.append(event.getContentDescription()).append(' ');
        return extractClaimOutcomeHint(text.toString());
    }

    private static String extractClaimOutcomeHint(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        String lower = raw.toLowerCase(Locale.US).replaceAll("\\s+", " ").trim();
        String[] phrases = new String[]{
                "successfully accepted", "job accepted", "delivery accepted", "offer accepted",
                "assigned to you", "you are assigned",
                "offer unavailable", "no longer available", "already claimed",
                "claimed by another", "someone else claimed", "unable to accept",
                "failed to accept", "something went wrong", "try again", "error"
        };
        for (String phrase : phrases) if (lower.contains(phrase)) return phrase;
        return "";
    }

    public static String recentClaimOutcomeSince(long sinceElapsed) {
        long now = SystemClock.elapsedRealtime();
        String cached = lastClaimOutcomeHint;
        if (!cached.isEmpty() && lastClaimOutcomeHintAt >= Math.max(0L, sinceElapsed - 120L)
                && now - lastClaimOutcomeHintAt <= 5_000L) return cached;
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return "";
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return "";
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return "";
            StringBuilder text = new StringBuilder();
            int[] budget = new int[]{220};
            collectLimitedText(root, text, budget);
            String hint = extractClaimOutcomeHint(text.toString());
            if (!hint.isEmpty()) {
                lastClaimOutcomeHint = hint;
                lastClaimOutcomeHintAt = now;
            }
            return hint;
        } finally { root.recycle(); }
    }

    public static boolean isPositiveClaimOutcome(String hint) {
        if (hint == null) return false;
        String lower = hint.toLowerCase(Locale.US);
        return lower.contains("accepted") || lower.contains("assigned to you")
                || lower.contains("you are assigned");
    }

    /** Server-side terminal loss. Once seen, do not burn more local retries on that offer. */
    public static boolean isTerminalNegativeClaimOutcome(String hint) {
        if (hint == null || hint.trim().isEmpty()) return false;
        String lower = hint.toLowerCase(Locale.US);
        return lower.contains("offer unavailable") || lower.contains("no longer available")
                || lower.contains("already claimed") || lower.contains("claimed by another")
                || lower.contains("someone else claimed") || lower.contains("unable to accept")
                || lower.contains("failed to accept");
    }

    /**
     * Positive confirmation only. A card disappearing from Offers is deliberately NOT
     * considered success because another driver/server refresh can remove it at the same time.
     */
    public static boolean hasAcceptSuccessEvidence() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        try {
            if (!"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) return false;
            PageGuard.Page page = pageOf(root);
            if (page == PageGuard.Page.JOBS) return true;
            StringBuilder text = new StringBuilder();
            int[] budget = new int[]{180};
            collectLimitedText(root, text, budget);
            String lower = text.toString().toLowerCase(Locale.US).replaceAll("\\s+", " ");
            return lower.contains("successfully accepted")
                    || lower.contains("job accepted")
                    || lower.contains("delivery accepted")
                    || lower.contains("offer accepted")
                    || lower.contains("assigned to you")
                    || lower.contains("you are assigned");
        } finally { root.recycle(); }
    }

    private static void collectLimitedText(AccessibilityNodeInfo node, StringBuilder out, int[] budget) {
        if (node == null || budget[0]-- <= 0) return;
        CharSequence text = node.getText(), desc = node.getContentDescription();
        if (text != null) out.append(text).append(' ');
        if (desc != null) out.append(desc).append(' ');
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectLimitedText(child, out, budget); }
                finally { child.recycle(); }
            }
        }
    }

    public static void tapSnapshotRetry(FastOfferSnapshot snapshot, float amount, float miles,
                                       Runnable completion, Consumer<String> mismatch) {
        tapSnapshotRetryDetailed(snapshot, amount, miles, 2,
                detail -> { if (completion != null) completion.run(); }, mismatch);
    }

    /** v2.10.11 retries use a newly refreshed top-card button, never the stale old coordinate. */
    public static void tapSnapshotRetryDetailed(FastOfferSnapshot snapshot, float amount, float miles,
                                                 int attempt, Consumer<String> completion,
                                                 Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || snapshot == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "DeliverThat不在前台；取消Accept重试");
            return;
        }
        service.main.post(() -> {
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消Accept重试");
                return;
            }
            FastOfferSnapshot current = quickRefreshTopAction(service, amount, miles, true);
            if (current == null || current.acceptBounds.isEmpty()) {
                if (mismatch != null) mismatch.accept("Accept重试前顶部金额/里程/按钮未一致复核；未点击");
                return;
            }
            if (!current.acceptEnabled) {
                if (mismatch != null) mismatch.accept("Accept重试时按钮已禁用/处理中；不重复点击");
                return;
            }
            int variant = ActionDispatchPolicy.retryVariant(attempt);
            long duration = ActionDispatchPolicy.retryGestureDurationMs(attempt);
            dispatchActionGesture(service, current.acceptBounds, true, duration, variant,
                    detail -> { if (completion != null) completion.accept("重试#" + attempt + " " + detail); },
                    mismatch);
        });
    }

    public static void tapIfOfferStillMatches(float x, float y, float amount, float miles,
                                               Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, x, y, amount, miles, null, completion, mismatch);
    }

    /**
     * Fresh screen-evidence fallback. Accessibility remains the preferred action path,
     * but DeliverThat builds exist where the visible button is not exported as an
     * actionable node. In that case a fresh OCR/visual coordinate may dispatch a gesture
     * after foreground/page checks. This is used for BOTH Accept and Reject in v2.9.3.
     */
    public static void tapOcrOffer(float x, float y, float amount, float miles, long evidenceAt,
                                   Runnable completion, Consumer<String> mismatch) {
        tapFreshOcrAction(true, x, y, amount, miles, evidenceAt, completion, mismatch);
    }

    public static void tapOcrReject(float x, float y, float amount, float miles, long evidenceAt,
                                    Runnable completion, Consumer<String> mismatch) {
        tapFreshOcrAction(false, x, y, amount, miles, evidenceAt, completion, mismatch);
    }

    /** v2.10.17 OCR Reject path with a full verified action rectangle and order identity. */
    public static void tapOcrReject(Rect rejectBounds, float amount, float miles, long evidenceAt,
                                    String expectedText, Consumer<String> completion,
                                    Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || rejectBounds == null || rejectBounds.isEmpty()
                || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "Reject热区不可用或DeliverThat不在前台");
            return;
        }
        final Rect expected = new Rect(rejectBounds);
        service.main.post(() -> {
            long now = SystemClock.elapsedRealtime();
            long age = ScanPolicy.actionAge(now, evidenceAt);
            if (!ScanPolicy.actionFresh(now, evidenceAt)) {
                if (mismatch != null) mismatch.accept("OCR/视觉Reject证据过旧" + age + "ms；等待新帧");
                return;
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消OCR Reject");
                return;
            }
            dispatchRejectHybrid(service, amount, miles, expected, expectedText, true, completion, mismatch);
        });
    }

    private static void tapFreshOcrAction(boolean accept, float x, float y, float amount, float miles,
                                          long evidenceAt, Runnable completion,
                                          Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null
                    ? "辅助点击服务未连接" : "DeliverThat不在前台或无法读取窗口");
            return;
        }
        final long queuedAt = SystemClock.elapsedRealtime();
        service.main.post(() -> {
            long now = SystemClock.elapsedRealtime();
            long age = ScanPolicy.actionAge(now, evidenceAt);
            if (!ScanPolicy.actionFresh(now, evidenceAt)) {
                if (mismatch != null) mismatch.accept("OCR/视觉证据过旧" + age + "ms；等待新帧");
                return;
            }
            if (!OcrMonitorService.isMonitoring()) {
                if (mismatch != null) mismatch.accept("监控已停止；取消屏幕坐标点击");
                return;
            }
            // Fast foreground verification only. Do not rescan every Accessibility window here:
            // on the user's Galaxy A15 that second tree walk alone can consume 400-800 ms and
            // was the direct cause of both v2.10 timeout errors.
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            float localX = x - rootBounds.left;
            float localY = y - rootBounds.top;
            boolean sideOk = accept ? ActionGeometry.plausibleRightAction(rootBounds.width(), localX)
                    : ActionGeometry.plausibleLeftAction(rootBounds.width(), localX);
            if (rootBounds.isEmpty() || !rootBounds.contains(Math.round(x), Math.round(y))
                    || !sideOk || !ActionGeometry.plausibleActionY(rootBounds.height(), localY)) {
                root.recycle();
                if (mismatch != null) mismatch.accept("目标坐标不在安全" + (accept ? "Accept" : "Reject")
                        + "按钮区域；取消点击");
                return;
            }

            // Use the recent full-scan hint first, then a bounded active-root probe. UNKNOWN is
            // intentionally allowed because the OCR frame already has money+miles+action-row
            // evidence; only a positive JOBS/IGNORED result blocks the gesture.
            PageGuard.Page quickPage = quickPageOf(root, 24);
            PageGuard.Page page = quickPage != PageGuard.Page.UNKNOWN
                    ? quickPage : recentPageHint();
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED) {
                root.recycle();
                if (mismatch != null) mismatch.accept("页面为" + page + "；禁止屏幕坐标点击");
                return;
            }
            root.recycle();

            long beforeGesture = SystemClock.elapsedRealtime();
            long finalAge = ScanPolicy.actionAge(beforeGesture, evidenceAt);
            if (!ScanPolicy.actionFresh(beforeGesture, evidenceAt)) {
                if (mismatch != null) mismatch.accept("坐标核验后证据过旧" + finalAge + "ms；等待新帧");
                return;
            }
            float gestureX = rootBounds.left + ActionGeometry.stableTapX(
                    rootBounds.width(), x - rootBounds.left, accept);
            Path path = new Path();
            path.moveTo(gestureX, y);
            long gestureDuration = ActionDispatchPolicy.firstGestureDurationMs(accept);
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, gestureDuration))
                    .build();
            boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (completion != null) completion.run();
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    if (mismatch != null) mismatch.accept("系统取消了"
                            + (accept ? "Accept" : "Reject") + "坐标点击手势");
                }
            }, service.main);
            if (!dispatched && mismatch != null) mismatch.accept("系统未接受"
                    + (accept ? "Accept" : "Reject") + "坐标点击手势");
        });
    }

    /**
     * Bounded page probe for the time-critical coordinate path. It examines at most
     * maxNodes nodes from the active root and returns only strong page evidence.
     */
    private static PageGuard.Page quickPageOf(AccessibilityNodeInfo root, int maxNodes) {
        if (root == null || maxNodes <= 0) return PageGuard.Page.UNKNOWN;
        boolean[] flags = new boolean[7];
        int[] budget = new int[]{maxNodes};
        collectQuickPageFlags(root, flags, budget);
        PageGuard.Page page = PageGuard.classify(flags[0], flags[1], flags[2],
                flags[3], flags[4], flags[5], flags[6]);
        // v2.10.19: do not let a conflicting stale selected-tab bit veto a structurally
        // verified top offer.  UNKNOWN is intentional here: callers still have to prove
        // money+miles+button geometry before any action is allowed.
        boolean conflictingOfferEvidence = !flags[3] && (flags[2] || flags[4] || flags[5]);
        if ((page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED)
                && conflictingOfferEvidence) page = PageGuard.Page.UNKNOWN;
        if (page != PageGuard.Page.UNKNOWN) updatePageHint(page);
        return page;
    }

    private static void collectQuickPageFlags(AccessibilityNodeInfo node, boolean[] flags, int[] budget) {
        if (node == null || budget[0]-- <= 0) return;
        CharSequence text = node.getText(), desc = node.getContentDescription();
        for (CharSequence value : new CharSequence[]{text, desc}) {
            if (value == null) continue;
            String label = value.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", "");
            if (node.isSelected() || node.isChecked()) {
                if (label.equals("ignored")) flags[0] = true;
                if (label.equals("jobs")) flags[1] = true;
                if (label.equals("offers") || label.startsWith("offers")) flags[2] = true;
            }
            if (label.equals("restore") || label.equals("restorebutton")) flags[3] = true;
            if (ButtonLabels.isReject(value)) flags[4] = true;
            if (matchesAccept(value)) flags[5] = true;
            if (label.equals("nooffersavailable") || label.equals("nooffers")) flags[6] = true;
        }
        // v2.10.19: keep scanning the bounded prefix even if a selected Jobs/Ignored bit
        // appears. React-Native can leave that bit stale while the visible Offers card and
        // its action row are already current.
        for (int i = 0; i < node.getChildCount() && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectQuickPageFlags(child, flags, budget); }
                finally { child.recycle(); }
            }
        }
    }

    public static void tapSnapshot(FastOfferSnapshot snapshot, float amount, float miles,
                                   Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, snapshot.acceptBounds.exactCenterX(), snapshot.acceptBounds.exactCenterY(),
                amount, miles, snapshot.text, completion, mismatch);
    }

    public static void ignoreIfOfferStillMatches(float x, float y, float amount, float miles, String expectedText,
                                               Runnable completion, Consumer<String> mismatch) {
        tapVerified(false, x, y, amount, miles, expectedText, completion, mismatch);
    }

    private static void tapVerified(boolean accept, float x, float y, float amount, float miles, String expectedText,
                                    Runnable completion, Consumer<String> mismatch) {
        tapVerified(accept, x, y, amount, miles, expectedText, false, true, completion, mismatch);
    }

    private static void tapVerified(boolean accept, float x, float y, float amount, float miles,
                                    String expectedText, boolean gestureOnly, boolean requireMonitoring,
                                    Runnable completion, Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null ? "辅助点击服务未连接" : "DeliverThat不在前台或无法读取窗口");
            return;
        }
        final long queuedAt = android.os.SystemClock.elapsedRealtime();
        service.main.post(() -> {
            long queueMs = android.os.SystemClock.elapsedRealtime() - queuedAt;
            if (!ScanPolicy.fresh(android.os.SystemClock.elapsedRealtime(), queuedAt)) {
                if (mismatch != null) mismatch.accept("点击排队超时" + queueMs + "ms；取消旧判断，等待重新识别");
                return;
            }
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (requireMonitoring && !OcrMonitorService.isMonitoring()) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("监控已停止；已取消排队点击");
                return;
            }
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            Rect rootBounds = new Rect();
            root.getBoundsInScreen(rootBounds);
            PageGuard.Page page = pageOf(root);
            if (page == PageGuard.Page.UNKNOWN) page = activePage();
            if (page == PageGuard.Page.JOBS || page == PageGuard.Page.IGNORED
                    || (page == PageGuard.Page.UNKNOWN && expectedText == null)) {
                root.recycle();
                if (mismatch != null) mismatch.accept("页面为" + page + "；当前证据不足，未点击");
                return;
            }

            // v2.10.8: reject a coordinate before touching the tree if it is not in the
            // expected left/right action column. This is the final barrier against an offer
            // card/detail container being mistaken for Ignore/Accept.
            float localX = x - rootBounds.left;
            float localY = y - rootBounds.top;
            boolean sideOk = accept ? ActionGeometry.plausibleRightAction(rootBounds.width(), localX)
                    : ActionGeometry.plausibleLeftAction(rootBounds.width(), localX);
            if (rootBounds.isEmpty() || !sideOk
                    || !ActionGeometry.plausibleActionY(rootBounds.height(), localY)) {
                root.recycle();
                if (mismatch != null) mismatch.accept("动作坐标不在安全按钮区域；疑似整卡/详情容器，已禁止点击");
                return;
            }

            AccessibilityNodeInfo button = findActionNode(root, accept, x, y);
            Rect liveBounds = new Rect();
            if (button != null) {
                button.getBoundsInScreen(liveBounds);
                if (!safeActionBounds(rootBounds, liveBounds, accept)) {
                    // Never keep a semantic fallback whose bounds are a whole card/container.
                    button.recycle();
                    button = null;
                    liveBounds.setEmpty();
                }
            }
            if (button == null) {
                // The coordinate came from a verified OCR/Accessibility label. Build only a
                // tiny local evidence box; do not substitute a large clickable ancestor.
                int halfW = 26, halfH = 16;
                liveBounds.set(Math.round(x) - halfW, Math.round(y) - halfH,
                        Math.round(x) + halfW, Math.round(y) + halfH);
            }

            String liveText = cardText(root, liveBounds).toLowerCase(Locale.US).replace(',', '.');
            if (expectedText != null && !CardText.sameOfferForAction(expectedText.replace(',', '.'), liveText)) {
                if (button != null) button.recycle();
                root.recycle();
                if (mismatch != null) mismatch.accept("目标卡片稳定内容已变化；本次未点击");
                return;
            }
            if (!NumericGuard.containsExpected(liveText, LIVE_MONEY, amount, 0.011f)
                    || !NumericGuard.containsExpected(liveText, LIVE_MILES, miles, 0.051f)) {
                if (button != null) button.recycle();
                root.recycle();
                if (mismatch != null) mismatch.accept("目标卡片金额/里程未能一致核对；未点击");
                return;
            }
            if (!ScanPolicy.fresh(android.os.SystemClock.elapsedRealtime(), queuedAt)) {
                if (button != null) button.recycle();
                root.recycle();
                if (mismatch != null) mismatch.accept("本次核验超过1秒；取消旧点击，重新读取");
                return;
            }

            final AccessibilityNodeInfo semanticFallback = button == null ? null
                    : AccessibilityNodeInfo.obtain(button);
            if (button != null) button.recycle();
            root.recycle();

            float gestureX = rootBounds.left + ActionGeometry.stableTapX(
                    rootBounds.width(), x - rootBounds.left, accept);
            float gestureY = y;
            if (!rootBounds.contains(Math.round(gestureX), Math.round(gestureY))) {
                if (semanticFallback != null) semanticFallback.recycle();
                if (mismatch != null) mismatch.accept("动作中心已离开DeliverThat窗口；取消点击");
                return;
            }
            Path path = new Path();
            path.moveTo(gestureX, gestureY);
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, ActionDispatchPolicy.firstGestureDurationMs(accept)))
                    .build();
            boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gestureDescription) {
                    if (semanticFallback != null) semanticFallback.recycle();
                    if (completion != null) completion.run();
                }
                @Override public void onCancelled(GestureDescription gestureDescription) {
                    boolean clicked = false;
                    if (semanticFallback != null) {
                        try {
                            clicked = !gestureOnly && performClickNodeOrParentSafe(
                                    semanticFallback, accept, rootBounds);
                        } finally { semanticFallback.recycle(); }
                    }
                    if (clicked) {
                        if (completion != null) completion.run();
                    } else if (mismatch != null) mismatch.accept("系统取消了坐标手势，安全语义点击也未执行");
                }
            }, service.main);
            if (!dispatched) {
                boolean clicked = false;
                if (semanticFallback != null) {
                    try {
                        clicked = !gestureOnly && performClickNodeOrParentSafe(
                                semanticFallback, accept, rootBounds);
                    } finally { semanticFallback.recycle(); }
                }
                if (clicked) {
                    if (completion != null) completion.run();
                } else if (mismatch != null) mismatch.accept("系统未接受坐标手势，安全语义点击也未执行");
            }
        });
    }

    private static AccessibilityNodeInfo findSemanticActionNode(AccessibilityNodeInfo node,
                                                                  boolean accept, float x, float y) {
        NodeCandidate best = new NodeCandidate();
        findActionCandidate(node, accept, x, y, best);
        return best.node;
    }

    private static AccessibilityNodeInfo findActionNode(AccessibilityNodeInfo node, boolean accept, float x, float y) {
        NodeCandidate best = new NodeCandidate();
        findActionCandidate(node, accept, x, y, best);
        if (best.node != null) return best.node;
        // If the label is blank, resolve the freshly read clickable node by the structural
        // coordinate obtained from the same Accessibility tree snapshot.
        findStructuralActionCandidate(node, x, y, best);
        return best.node;
    }

    private static final class NodeCandidate {
        AccessibilityNodeInfo node;
        float score = Float.MAX_VALUE;
    }

    private static void findActionCandidate(AccessibilityNodeInfo node, boolean accept, float x, float y, NodeCandidate best) {
        if (node == null) return;
        CharSequence label = node.getText();
        CharSequence description = node.getContentDescription();
        boolean matches = accept ? (matchesAccept(label) || matchesAccept(description))
                : (ButtonLabels.isReject(label) || ButtonLabels.isReject(description));
        if (matches) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (!bounds.isEmpty()) {
                float dy = Math.abs(bounds.exactCenterY() - y);
                float dx = Math.abs(bounds.exactCenterX() - x);
                float yTolerance = Math.max(90f, bounds.height() * 2.25f);
                float xTolerance = Math.max(140f, bounds.width() * 1.25f);
                if ((bounds.contains(Math.round(x), Math.round(y)) || (dy <= yTolerance && dx <= xTolerance))) {
                    float score = dy + dx * 0.25f;
                    if (score < best.score) {
                        if (best.node != null) best.node.recycle();
                        best.node = AccessibilityNodeInfo.obtain(node);
                        best.score = score;
                    }
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { findActionCandidate(child, accept, x, y, best); }
                finally { child.recycle(); }
            }
        }
    }

    private static void findStructuralActionCandidate(AccessibilityNodeInfo node, float x, float y, NodeCandidate best) {
        if (node == null) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        boolean actionable = node.isClickable()
                || (node.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0
                || (node.getClassName() != null
                    && node.getClassName().toString().toLowerCase(Locale.US).contains("button"));
        if (actionable && actionNodeReady(node) && !bounds.isEmpty()) {
            float dy = Math.abs(bounds.exactCenterY() - y);
            float dx = Math.abs(bounds.exactCenterX() - x);
            float yTolerance = Math.max(48f, bounds.height() * 1.35f);
            float xTolerance = Math.max(80f, bounds.width() * 0.75f);
            if (bounds.contains(Math.round(x), Math.round(y)) || (dy <= yTolerance && dx <= xTolerance)) {
                float areaPenalty = Math.min(250f, (bounds.width() * bounds.height()) / 12000f);
                float score = dy + dx * 0.35f + areaPenalty;
                if (score < best.score) {
                    if (best.node != null) best.node.recycle();
                    best.node = AccessibilityNodeInfo.obtain(node);
                    best.score = score;
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { findStructuralActionCandidate(child, x, y, best); }
                finally { child.recycle(); }
            }
        }
    }

    private static boolean actionNodeReady(AccessibilityNodeInfo node) {
        if (node == null) return false;
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(node);
        try {
            for (int depth = 0; depth < 6 && current != null; depth++) {
                boolean actionable = current.isClickable()
                        || (current.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0
                        || (current.getClassName() != null
                            && current.getClassName().toString().toLowerCase(Locale.US).contains("button"));
                if (current.isEnabled() && actionable) return true;
                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }
            return false;
        } finally {
            if (current != null) current.recycle();
        }
    }

    private static boolean performClickNodeOrParentSafe(AccessibilityNodeInfo node,
                                                        boolean accept, Rect rootBounds) {
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(node);
        try {
            for (int depth = 0; depth < 6 && current != null; depth++) {
                boolean actionable = current.isClickable()
                        || (current.getActions() & AccessibilityNodeInfo.ACTION_CLICK) != 0;
                Rect bounds = new Rect();
                current.getBoundsInScreen(bounds);
                // Critical v2.10.8 invariant: climbing parents may never cross into the
                // whole offer card. Stop using an ancestor as soon as its geometry is no
                // longer a real left/right action button.
                if (current.isEnabled() && actionable
                        && safeActionBounds(rootBounds, bounds, accept)
                        && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }
            return false;
        } finally {
            if (current != null) current.recycle();
        }
    }

    private static boolean performAcceptAction(AccessibilityNodeInfo node) {
        if (node == null) return false;
        String label = "";
        if (node.getText() != null) label += node.getText().toString();
        if (node.getContentDescription() != null) label += " " + node.getContentDescription();
        String normalized = label.toLowerCase(Locale.US).replaceAll("[^a-z]", "");
        if (isAcceptLabel(normalized)) {
            AccessibilityNodeInfo target = node;
            AccessibilityNodeInfo ownedParent = null;
            for (int depth = 0; depth < 3 && target != null; depth++) {
                if (target.isClickable()
                        && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    if (ownedParent != null) ownedParent.recycle();
                    return true;
                }
                AccessibilityNodeInfo parent = target.getParent();
                if (ownedParent != null) ownedParent.recycle();
                ownedParent = parent;
                target = parent;
            }
            if (ownedParent != null) ownedParent.recycle();
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean clicked = performAcceptAction(child);
                child.recycle();
                if (clicked) return true;
            }
        }
        return false;
    }

    private static boolean isAcceptLabel(String normalized) {
        if (normalized == null) return false;
        switch (normalized) {
            case "accept": case "claim":
            case "acceptbutton": case "buttonaccept":
            case "claimbutton": case "buttonclaim":
            case "acceptoffer": case "claimoffer":
            case "acceptdelivery": case "claimdelivery":
            case "acceptjob": case "claimjob":
            case "acceptorder": case "claimorder":
            case "acceptrequest": case "claimrequest":
                return true;
            default:
                return false;
        }
    }

    private static String collectText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder out = new StringBuilder();
        if (node.getText() != null) out.append(node.getText()).append(' ');
        if (node.getContentDescription() != null) out.append(node.getContentDescription()).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                out.append(collectText(child));
                child.recycle();
            }
        }
        return out.toString();
    }

}
