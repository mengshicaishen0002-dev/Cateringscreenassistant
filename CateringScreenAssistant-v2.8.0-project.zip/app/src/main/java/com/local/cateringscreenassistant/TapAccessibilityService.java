package com.local.cateringscreenassistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.concurrent.atomic.AtomicReference;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.regex.Pattern;

public class TapAccessibilityService extends AccessibilityService {
    private static final Pattern LIVE_MONEY = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern LIVE_MILES = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final AtomicReference<TapAccessibilityService> INSTANCE = new AtomicReference<>();
    private static volatile String foregroundPackage = "";
    private final Handler main = new Handler(Looper.getMainLooper());

    public static final class FastOfferSnapshot {
        public final String text;
        public final Rect acceptBounds;
        public final Rect rejectBounds;
        public final boolean acceptEnabled;
        public final boolean rejectEnabled;

        FastOfferSnapshot(String text, Rect acceptBounds, Rect rejectBounds,
                          boolean acceptEnabled, boolean rejectEnabled) {
            this.text = text;
            this.acceptBounds = acceptBounds;
            this.rejectBounds = rejectBounds;
            this.acceptEnabled = acceptEnabled;
            this.rejectEnabled = rejectEnabled;
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE.set(this);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        String eventPackage = event.getPackageName() == null
                ? "" : event.getPackageName().toString();
        int type = event.getEventType();
        // Notification events from this assistant must not replace the actual
        // foreground app. Only real window transitions may do that.
        if ("com.deliverthat.driver".equals(eventPackage)
                || type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            foregroundPackage = eventPackage;
        }
        if ("com.deliverthat.driver".equals(eventPackage)) {
            OcrMonitorService.requestImmediateFastCheck(event.getEventTime());
        }
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        INSTANCE.compareAndSet(this, null);
        super.onDestroy();
    }

    public static boolean isConnected() {
        return INSTANCE.get() != null;
    }

    public static boolean isDeliverThatForeground() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return false;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return false;
        try {
            return root.getPackageName() != null
                    && "com.deliverthat.driver".contentEquals(root.getPackageName());
        } finally { root.recycle(); }
    }

    public static PageGuard.Page activePage() {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return PageGuard.Page.UNKNOWN;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return PageGuard.Page.UNKNOWN;
        try {
            if (!"com.deliverthat.driver".contentEquals(root.getPackageName() == null ? "" : root.getPackageName()))
                return PageGuard.Page.UNKNOWN;
            return pageOf(root);
        } finally { root.recycle(); }
    }

    private static PageGuard.Page pageOf(AccessibilityNodeInfo root) {
        boolean[] flags = new boolean[5];
        collectPageFlags(root, flags);
        return PageGuard.classify(flags[0], flags[1], flags[2], flags[3], flags[4]);
    }

    private static void collectPageFlags(AccessibilityNodeInfo node, boolean[] flags) {
        if (node == null || !node.isVisibleToUser()) return;
        for (CharSequence value : new CharSequence[]{node.getText(), node.getContentDescription()}) {
            if (value == null) continue;
            String label = value.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", "");
            if (node.isSelected() || node.isChecked()) {
                if (label.equals("ignored")) flags[0] = true;
                if (label.equals("jobs")) flags[1] = true;
                if (label.equals("offers")) flags[2] = true;
            }
            if (label.equals("restore") || label.equals("restorebutton")) flags[3] = true;
            if (ButtonLabels.isReject(value)) flags[4] = true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectPageFlags(child, flags); child.recycle(); }
        }
    }

    public static FastOfferSnapshot getFastOfferSnapshot() {
        List<FastOfferSnapshot> cards = getFastOfferSnapshots();
        return cards.isEmpty() ? null : cards.get(0);
    }

    public static List<FastOfferSnapshot> getFastOfferSnapshots() {
        List<FastOfferSnapshot> cards = new ArrayList<>();
        TapAccessibilityService service = INSTANCE.get();
        if (service == null) return cards;
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null) return cards;
        WindowScan scan = new WindowScan();
        try {
            if (!"com.deliverthat.driver".contentEquals(root.getPackageName() == null ? "" : root.getPackageName())) return cards;
            scanWindow(root, scan);
        } finally { root.recycle(); }
        if (PageGuard.classify(scan.flags[0], scan.flags[1], scan.flags[2], scan.flags[3], scan.flags[4])
                != PageGuard.Page.OFFERS) return cards;
        List<ActionHit> anchors = new ArrayList<>(scan.accepts);
        for (ActionHit reject : scan.rejects) {
            boolean paired = false;
            for (ActionHit accept : scan.accepts) if (sameRow(accept.bounds, reject.bounds)) { paired = true; break; }
            if (!paired) anchors.add(reject);
        }
        anchors.sort(java.util.Comparator.comparingInt(hit -> hit.bounds.top));
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (ActionHit anchor : anchors) {
            Rect accept = new Rect(), reject = new Rect();
            boolean acceptEnabled = false, rejectEnabled = false;
            for (ActionHit candidate : scan.accepts) {
                if (sameRow(candidate.bounds, anchor.bounds)) {
                    accept.set(candidate.bounds); acceptEnabled = candidate.enabled; break;
                }
            }
            for (ActionHit candidate : scan.rejects) {
                if (sameRow(candidate.bounds, anchor.bounds)) {
                    reject.set(candidate.bounds); rejectEnabled = candidate.enabled; break;
                }
            }
            String text = CardText.aboveButton(scan.pieces, anchor.bounds.top, anchor.bounds.bottom);
            if (!CardText.MONEY.matcher(text).find() || !LIVE_MILES.matcher(text).find()) continue;
            if (seen.add(CardText.identity(text)))
                cards.add(new FastOfferSnapshot(text, accept, reject, acceptEnabled, rejectEnabled));
        }
        return cards;
    }

    private static boolean sameRow(Rect a, Rect b) {
        return a.top < b.bottom && a.bottom > b.top;
    }

    public static FastOfferSnapshot findOffer(String expectedText) {
        for (FastOfferSnapshot card : getFastOfferSnapshots())
            if (CardText.sameOffer(expectedText, card.text)) return card;
        return null;
    }

    // One hierarchy traversal supplies page, button geometry and card text together.
    private static final class ActionHit {
        final Rect bounds;
        final boolean enabled;
        ActionHit(Rect bounds, boolean enabled) { this.bounds = new Rect(bounds); this.enabled = enabled; }
    }

    private static final class WindowScan {
        final boolean[] flags = new boolean[5];
        final List<ActionHit> accepts = new ArrayList<>();
        final List<ActionHit> rejects = new ArrayList<>();
        final List<CardText.Piece> pieces = new ArrayList<>();
    }

    private static void scanWindow(AccessibilityNodeInfo node, WindowScan scan) {
        if (node == null || !node.isVisibleToUser()) return;
        CharSequence text = node.getText(), description = node.getContentDescription();
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        CharSequence value = text == null || text.length() == 0 ? description : text;
        if (value != null && !bounds.isEmpty()) scan.pieces.add(new CardText.Piece(
                value.toString(), bounds.left, bounds.top, bounds.bottom));
        for (CharSequence labelValue : new CharSequence[]{text, description}) {
            if (labelValue == null) continue;
            String label = labelValue.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", "");
            if (node.isSelected() || node.isChecked()) {
                if (label.equals("ignored")) scan.flags[0] = true;
                if (label.equals("jobs")) scan.flags[1] = true;
                if (label.equals("offers")) scan.flags[2] = true;
            }
            if (label.equals("restore") || label.equals("restorebutton")) scan.flags[3] = true;
            if (ButtonLabels.isReject(labelValue)) scan.flags[4] = true;
        }
        if (!bounds.isEmpty()) {
            // Keep disabled action nodes as card anchors. Right after a click the app may
            // briefly disable a button while the server response is pending. v2.7 then
            // lost the whole card and incorrectly treated the result as disappearance.
            boolean ready = actionNodeReady(node);
            if (matchesAccept(text) || matchesAccept(description)) scan.accepts.add(new ActionHit(bounds, ready));
            if (ButtonLabels.isReject(text) || ButtonLabels.isReject(description)) scan.rejects.add(new ActionHit(bounds, ready));
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { try { scanWindow(child, scan); } finally { child.recycle(); } }
        }
    }

    private static boolean findRejectBounds(AccessibilityNodeInfo node, Rect accept, Rect out) {
        if (node == null || !node.isVisibleToUser() || !node.isEnabled()) return false;
        if (ButtonLabels.isReject(node.getText()) || ButtonLabels.isReject(node.getContentDescription())) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (!bounds.isEmpty() && (accept.isEmpty() || (bounds.top < accept.bottom && bounds.bottom > accept.top))) {
                out.set(bounds);
                return true;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = findRejectBounds(child, accept, out);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    private static String cardText(AccessibilityNodeInfo root, Rect button) {
        List<CardText.Piece> pieces = new ArrayList<>();
        collectPieces(root, pieces);
        return CardText.aboveButton(pieces, button.top, button.bottom);
    }

    private static void collectPieces(AccessibilityNodeInfo node, List<CardText.Piece> pieces) {
        if (node == null || !node.isVisibleToUser()) return;
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        CharSequence value = node.getText();
        if (value == null || value.length() == 0) value = node.getContentDescription();
        if (value != null && !bounds.isEmpty()) pieces.add(new CardText.Piece(
                value.toString(), bounds.left, bounds.top, bounds.bottom));
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { collectPieces(child, pieces); child.recycle(); }
        }
    }

    private static void collectSnapshot(AccessibilityNodeInfo node, StringBuilder text, Rect accept) {
        if (node == null || !node.isVisibleToUser()) return;
        CharSequence label = node.getText();
        CharSequence description = node.getContentDescription();
        if (label != null) text.append(label).append(' ');
        if (description != null && !description.equals(label)) text.append(description).append(' ');
        if (accept.isEmpty() && node.isEnabled()
                && (matchesAccept(label) || matchesAccept(description))) node.getBoundsInScreen(accept);
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectSnapshot(child, text, accept);
                child.recycle();
            }
        }
    }

    private static boolean matchesAccept(CharSequence value) {
        return value != null && isAcceptLabel(value.toString().toLowerCase(Locale.US).replaceAll("[^a-z]", ""));
    }

    private static boolean findAcceptBounds(AccessibilityNodeInfo node, Rect out) {
        if (node == null) return false;
        String label = "";
        if (node.getText() != null) label += node.getText().toString();
        if (node.getContentDescription() != null) label += " " + node.getContentDescription();
        String normalized = label.toLowerCase(Locale.US).replaceAll("[^a-z]", "");
        if (isAcceptLabel(normalized)) {
            node.getBoundsInScreen(out);
            if (!out.isEmpty()) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = findAcceptBounds(child, out);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    public static void tapSnapshotRetry(FastOfferSnapshot snapshot, float amount, float miles,
                                       Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, snapshot.acceptBounds.exactCenterX(), snapshot.acceptBounds.exactCenterY(),
                amount, miles, snapshot.text, true, completion, mismatch);
    }

    public static void tapIfOfferStillMatches(float x, float y, float amount, float miles,
                                               Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, x, y, amount, miles, null, completion, mismatch);
    }

    public static void tapSnapshot(FastOfferSnapshot snapshot, float amount, float miles,
                                   Runnable completion, Consumer<String> mismatch) {
        tapVerified(true, snapshot.acceptBounds.exactCenterX(), snapshot.acceptBounds.exactCenterY(),
                amount, miles, snapshot.text, completion, mismatch);
    }

    public static void ignoreIfOfferStillMatches(float x, float y, float amount, float miles, String expectedText,
                                               Runnable completion, Consumer<String> mismatch) {
        tapVerified(false, x, y, amount, miles, expectedText, completion, mismatch);
    }

    private static void tapVerified(boolean accept, float x, float y, float amount, float miles, String expectedText,
                                    Runnable completion, Consumer<String> mismatch) {
        tapVerified(accept, x, y, amount, miles, expectedText, false, completion, mismatch);
    }

    private static void tapVerified(boolean accept, float x, float y, float amount, float miles,
                                    String expectedText, boolean gestureOnly, Runnable completion, Consumer<String> mismatch) {
        TapAccessibilityService service = INSTANCE.get();
        if (service == null || !isDeliverThatForeground()) {
            if (mismatch != null) mismatch.accept(service == null ? "辅助点击服务未连接" : "DeliverThat不在前台或无法读取窗口");
            return;
        }
        final long queuedAt = android.os.SystemClock.elapsedRealtime();
        service.main.post(() -> {
            long queueMs = android.os.SystemClock.elapsedRealtime() - queuedAt;
            if (!ScanPolicy.fresh(android.os.SystemClock.elapsedRealtime(), queuedAt)) {
                if (mismatch != null) mismatch.accept("点击排队超时" + queueMs + "ms；取消旧判断，等待重新识别");
                return;
            }
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            if (!OcrMonitorService.isMonitoring()) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("监控已停止；已取消排队点击");
                return;
            }
            if (root == null || !"com.deliverthat.driver".contentEquals(
                    root.getPackageName() == null ? "" : root.getPackageName())) {
                if (root != null) root.recycle();
                if (mismatch != null) mismatch.accept("当前窗口不可读取或不是DeliverThat");
                return;
            }
            PageGuard.Page page = pageOf(root);
            if (page != PageGuard.Page.OFFERS) {
                root.recycle();
                if (mismatch != null) mismatch.accept("页面为" + page + "；仅Offers允许点击");
                return;
            }
            AccessibilityNodeInfo button = findActionNode(root, accept, x, y);
            if (button == null) {
                root.recycle();
                if (mismatch != null) mismatch.accept("目标位置未找到可见且启用的" + (accept ? "Accept" : "Ignore/Decline/Reject"));
                return;
            }
            Rect liveBounds = new Rect();
            button.getBoundsInScreen(liveBounds);
            String liveText = cardText(root, liveBounds).toLowerCase(Locale.US).replace(',', '.');
            if (expectedText != null && !CardText.sameOffer(expectedText.replace(',', '.'), liveText)) {
                button.recycle();
                root.recycle();
                if (mismatch != null) mismatch.accept("目标卡片稳定内容已变化；本次未点击");
                return;
            }
            if (!NumericGuard.containsExpected(liveText, LIVE_MONEY, amount, 0.011f)
                    || !NumericGuard.containsExpected(liveText, LIVE_MILES, miles, 0.051f)) {
                if (root != null) root.recycle();
                button.recycle();
                if (mismatch != null) mismatch.accept("目标卡片金额/里程未能一致核对；未点击");
                return;
            }

            if (!ScanPolicy.fresh(android.os.SystemClock.elapsedRealtime(), queuedAt)) {
                button.recycle(); root.recycle();
                if (mismatch != null) mismatch.accept("本次核验超过1秒；取消旧点击，重新读取");
                return;
            }
            // Prefer a semantic Accessibility click. DeliverThat can expose the visible
            // label as a non-clickable child while its parent is the real button, so walk
            // up the hierarchy before falling back to a coordinate gesture.
            if (!gestureOnly && performClickNodeOrParent(button)) {
                button.recycle();
                root.recycle();
                if (completion != null) completion.run();
                return;
            }
            button.recycle();
            if (root != null) root.recycle();

            // Some app builds expose button text but no clickable node. Keep the verified
            // coordinate gesture as a compatibility fallback.
            Path path = new Path();
            path.moveTo(liveBounds.exactCenterX(), liveBounds.exactCenterY());
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 45))
                    .build();
            boolean dispatched = service.dispatchGesture(gesture, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    if (completion != null) completion.run();
                }
                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    if (mismatch != null) mismatch.accept("系统取消了点击手势");
                }
            }, service.main);
            if (!dispatched && mismatch != null) mismatch.accept("系统未接受点击手势");
        });
    }

    private static AccessibilityNodeInfo findActionNode(AccessibilityNodeInfo node, boolean accept, float x, float y) {
        NodeCandidate best = new NodeCandidate();
        findActionCandidate(node, accept, x, y, best);
        return best.node;
    }

    private static final class NodeCandidate {
        AccessibilityNodeInfo node;
        float score = Float.MAX_VALUE;
    }

    private static void findActionCandidate(AccessibilityNodeInfo node, boolean accept, float x, float y, NodeCandidate best) {
        if (node == null || !node.isVisibleToUser()) return;
        CharSequence label = node.getText();
        CharSequence description = node.getContentDescription();
        boolean matches = accept ? (matchesAccept(label) || matchesAccept(description))
                : (ButtonLabels.isReject(label) || ButtonLabels.isReject(description));
        if (matches && actionNodeReady(node)) {
            Rect bounds = new Rect();
            node.getBoundsInScreen(bounds);
            if (!bounds.isEmpty()) {
                float dy = Math.abs(bounds.exactCenterY() - y);
                float dx = Math.abs(bounds.exactCenterX() - x);
                float yTolerance = Math.max(90f, bounds.height() * 2.25f);
                float xTolerance = Math.max(140f, bounds.width() * 1.25f);
                if ((bounds.contains(Math.round(x), Math.round(y)) || (dy <= yTolerance && dx <= xTolerance))) {
                    float score = dy + dx * 0.25f;
                    if (score < best.score) {
                        if (best.node != null) best.node.recycle();
                        best.node = AccessibilityNodeInfo.obtain(node);
                        best.score = score;
                    }
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { findActionCandidate(child, accept, x, y, best); }
                finally { child.recycle(); }
            }
        }
    }

    private static boolean actionNodeReady(AccessibilityNodeInfo node) {
        if (node == null) return false;
        if (node.isEnabled()) return true;
        AccessibilityNodeInfo parent = node.getParent();
        try {
            return parent != null && parent.isVisibleToUser() && parent.isEnabled() && parent.isClickable();
        } finally {
            if (parent != null) parent.recycle();
        }
    }

    private static boolean performClickNodeOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(node);
        try {
            for (int depth = 0; depth < 5 && current != null; depth++) {
                if (current.isVisibleToUser() && current.isEnabled() && current.isClickable()
                        && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
                AccessibilityNodeInfo parent = current.getParent();
                current.recycle();
                current = parent;
            }
            return false;
        } finally {
            if (current != null) current.recycle();
        }
    }

    private static boolean performAcceptAction(AccessibilityNodeInfo node) {
        if (node == null) return false;
        String label = "";
        if (node.getText() != null) label += node.getText().toString();
        if (node.getContentDescription() != null) label += " " + node.getContentDescription();
        String normalized = label.toLowerCase(Locale.US).replaceAll("[^a-z]", "");
        if (isAcceptLabel(normalized)) {
            AccessibilityNodeInfo target = node;
            AccessibilityNodeInfo ownedParent = null;
            for (int depth = 0; depth < 3 && target != null; depth++) {
                if (target.isClickable()
                        && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    if (ownedParent != null) ownedParent.recycle();
                    return true;
                }
                AccessibilityNodeInfo parent = target.getParent();
                if (ownedParent != null) ownedParent.recycle();
                ownedParent = parent;
                target = parent;
            }
            if (ownedParent != null) ownedParent.recycle();
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean clicked = performAcceptAction(child);
                child.recycle();
                if (clicked) return true;
            }
        }
        return false;
    }

    private static boolean isAcceptLabel(String normalized) {
        return normalized.equals("accept") || normalized.equals("claim")
                || normalized.equals("acceptbutton") || normalized.equals("buttonaccept")
                || normalized.equals("claimbutton") || normalized.equals("buttonclaim");
    }

    private static String collectText(AccessibilityNodeInfo node) {
        if (node == null) return "";
        StringBuilder out = new StringBuilder();
        if (node.getText() != null) out.append(node.getText()).append(' ');
        if (node.getContentDescription() != null) out.append(node.getContentDescription()).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                out.append(collectText(child));
                child.recycle();
            }
        }
        return out.toString();
    }

}
