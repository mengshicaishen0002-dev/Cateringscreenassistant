package com.local.cateringscreenassistant;

/**
 * v2.10.26 OCR arbitration.
 *
 * Once a coherent Accessibility snapshot contains every rule-sensitive field and the
 * side-specific action rectangle for the current top card, OCR cannot make a disabled,
 * processing, retry-gated or budget-gated button safer to click. Keep Accessibility as
 * owner of that frame and reserve OCR for genuinely incomplete/missing action evidence.
 */
final class AccessibilityFallbackPolicy {
    private AccessibilityFallbackPolicy() { }

    static boolean accessibilityOwnsFrame(boolean decisionComplete, boolean expectedActionAnchored) {
        return decisionComplete && expectedActionAnchored;
    }

    static boolean shouldRunOcrFallback(boolean decisionComplete, boolean expectedActionAnchored) {
        return !accessibilityOwnsFrame(decisionComplete, expectedActionAnchored);
    }
}
