package com.local.cateringscreenassistant;
import java.util.List;
import java.util.function.Predicate;
final class OfferPriority {
    static <T> T choose(List<T> cards, Predicate<T> eligible, Predicate<T> actionable, Predicate<T> rejectable) {
        // Process top-to-bottom. Skip only cards whose action is unavailable/exhausted.
        for (T card : cards) {
            if (eligible.test(card)) { if (actionable.test(card)) return card; }
            else if (rejectable.test(card)) return card;
        }
        return null;
    }
}
