package com.local.cateringscreenassistant;
import java.util.List;
import java.util.function.Predicate;

final class OfferPriority {
    static <T> T choose(List<T> cards, Predicate<T> eligible, Predicate<T> actionable, Predicate<T> rejectable) {
        // Catch a qualifying visible offer before spending any time declining a bad one.
        // This matters when several cards are already on screen and the good card is lower.
        for (T card : cards) {
            if (eligible.test(card) && actionable.test(card)) return card;
        }
        // Only when no qualifying visible card can be acted on do we clear an ineligible one.
        for (T card : cards) {
            if (!eligible.test(card) && rejectable.test(card)) return card;
        }
        return null;
    }
}
