package com.local.cateringscreenassistant;
import java.util.List;
import java.util.function.Predicate;

/** Serial top-card policy: never act on a lower card while the first visible card remains. */
final class OfferPriority {
    static <T> T choose(List<T> cards, Predicate<T> eligible, Predicate<T> actionable, Predicate<T> rejectable) {
        if (cards == null || cards.isEmpty()) return null;
        T top = cards.get(0);
        if (eligible.test(top)) return actionable.test(top) ? top : null;
        return rejectable.test(top) ? top : null;
    }
}
