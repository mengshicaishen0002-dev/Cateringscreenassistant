package com.local.cateringscreenassistant;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class NumericGuard {
    static boolean containsExpected(String text, Pattern pattern, float expected, float tolerance) {
        if (text == null) return false;
        Matcher matcher = pattern.matcher(text);
        while (matcher.find()) {
            try {
                float actual = Float.parseFloat(matcher.group(1).replace(',', '.'));
                // A price range such as $70-$80 contains two numbers. Matching ANY expected
                // value is enough; a later range endpoint must not invalidate the correct low value.
                if (Math.abs(actual - expected) <= tolerance) return true;
            } catch (NumberFormatException ignored) { }
        }
        return false;
    }
}
