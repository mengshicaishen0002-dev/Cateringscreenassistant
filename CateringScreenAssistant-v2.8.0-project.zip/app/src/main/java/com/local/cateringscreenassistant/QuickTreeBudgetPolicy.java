package com.local.cateringscreenassistant;

/**
 * v2.10.35 latency guard for the bounded Accessibility quick-tree pass.
 *
 * The quick tree is a fallback after semantic action indexing. On Samsung/React-Native
 * frames a single traversal can occasionally stretch from the normal 20-80 ms range into
 * several hundred milliseconds. Once the fallback exceeds this soft budget it is cheaper
 * and safer to yield to the already-running OCR path than to continue into a full-tree scan.
 */
final class QuickTreeBudgetPolicy {
    private static final int MAX_NODES = 128;
    private static final long SOFT_BUDGET_MS = 150L;
    private static final long OCR_BACKOFF_MS = 120L;

    static int maxNodes() { return MAX_NODES; }
    static long softBudgetMs() { return SOFT_BUDGET_MS; }
    static long ocrBackoffMs() { return OCR_BACKOFF_MS; }

    static boolean elapsedBudgetExceeded(long startedAt, long now) {
        return startedAt > 0L && now >= startedAt && now - startedAt >= SOFT_BUDGET_MS;
    }

    static boolean shouldYieldToOcr(boolean budgetExceeded, boolean decisionReady) {
        return budgetExceeded && !decisionReady;
    }

    private QuickTreeBudgetPolicy() { }
}
