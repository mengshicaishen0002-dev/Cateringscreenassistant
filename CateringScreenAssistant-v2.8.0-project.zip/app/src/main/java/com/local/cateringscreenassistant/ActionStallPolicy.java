package com.local.cateringscreenassistant;

/** Pure timing policy for recovering a visible first offer from stale action state. */
final class ActionStallPolicy {
    private ActionStallPolicy() { }

    static long rescueProbeMs() { return 320L; }
    static long rescueArmMs() { return 420L; }
    static long stableTopMs() { return 70L; }
    static int stableFrames() { return 2; }
    static long softStallMs() { return 800L; }
    static long hardHoldMs() { return 2200L; }
    static long recoveryDebounceMs() { return 900L; }

    static boolean stableTop(int frames, long ageMs) {
        return frames >= stableFrames() && ageMs >= stableTopMs();
    }

    static boolean shouldProbe(boolean blocked, boolean dryRun, boolean busy,
                               long sinceLastProbeMs, long actionAgeMs) {
        return blocked && !dryRun && !busy
                && sinceLastProbeMs >= rescueProbeMs()
                && actionAgeMs >= rescueArmMs();
    }
}
