package com.local.cateringscreenassistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.hardware.display.VirtualDisplay;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.text.DateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OcrMonitorService extends Service {
    private static final String CHANNEL = "ocr_monitor";
    private static final int NOTIFICATION_ID = 41;
    private static final Pattern MONEY_RANGE = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)\\s*[-–—]\\s*\\$?(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MILES = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern OFFER_TIME = Pattern.compile("(?:today|tomorrow)\\s*(?:at)?\\s*(\\d{1,2}:\\d{2})\\s*(am|pm)", Pattern.CASE_INSENSITIVE);
    private static final String[] ACCEPT_WORDS = {"accept", "claim"};
    private static final String[] IGNORE_WORDS = {"ignore", "decline", "reject"};
    private static volatile OcrMonitorService activeInstance;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private HandlerThread workerThread;
    private Handler worker;
    private final java.util.concurrent.ThreadPoolExecutor logWriter = new java.util.concurrent.ThreadPoolExecutor(
            1, 1, 0L, java.util.concurrent.TimeUnit.MILLISECONDS,
            new java.util.concurrent.ArrayBlockingQueue<Runnable>(256),
            new java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy());
    private TextRecognizer recognizer;
    private final AtomicBoolean ocrBusy = new AtomicBoolean(false);
    private long lastScan;
    private volatile long lastReadableFastScan;
    private volatile String scanTiming = "";
    private volatile long cooldownUntil;
    private long pendingIgnoreSince;
    private String pendingIgnoreFingerprint = "";
    private String pendingAcceptFingerprint = "";
    private String lastLoggedIneligibleFingerprint = "";
    private int pendingAcceptConfirmations;
    private int width;
    private int height;
    private int density;
    private SharedPreferences prefs;
    private volatile boolean monitorReady;
    private final AtomicBoolean fastCheckQueued = new AtomicBoolean(false);
    private final AtomicBoolean fastCheckDirty = new AtomicBoolean(false);
    public static boolean isMonitoring() {
        OcrMonitorService current = activeInstance;
        return current != null && current.monitorReady;
    }
    private long claimEpoch;
    private final ClaimBudget claimBudget = new ClaimBudget();
    private final RejectSequence rejectSequence = new RejectSequence();
    private final Runnable continuousCheck = new Runnable() {
        @Override public void run() {
            if (!monitorReady || worker == null) return;
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            worker.postDelayed(this, 180);
        }
    };

    public static void requestImmediateFastCheck(long eventTime) {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady || service.worker == null) return;
        if (!service.fastCheckQueued.compareAndSet(false, true)) {
            service.fastCheckDirty.set(true);
            return;
        }
        final long queuedAt = SystemClock.elapsedRealtime();
        service.worker.post(() -> {
            try {
            long now = SystemClock.elapsedRealtime();
            if (now < service.cooldownUntil) return;
            List<TapAccessibilityService.FastOfferSnapshot> cards = TapAccessibilityService.getFastOfferSnapshots();
            service.scanTiming = "排队" + (now - queuedAt) + "ms；读界面"
                    + (SystemClock.elapsedRealtime() - now) + "ms；可读卡片" + cards.size();
            TapAccessibilityService.FastOfferSnapshot selected = OfferPriority.choose(cards,
                    card -> service.fastRuleFailure(card.text).isEmpty(),
                    card -> card.acceptEnabled && !card.acceptBounds.isEmpty() && service.claimBudget.available(CardText.identity(card.text)),
                    card -> service.prefs.getBoolean("autoIgnore", true) && card.rejectEnabled && !card.rejectBounds.isEmpty()
                            && service.rejectSequence.observe(CardText.identity(card.text),
                            SystemClock.elapsedRealtime()) != RejectSequence.State.EXHAUSTED);
            if (selected != null) {
                if (service.tryFastAccept(selected)) service.lastReadableFastScan = SystemClock.elapsedRealtime();
            } else if (!cards.isEmpty()) {
                service.lastReadableFastScan = SystemClock.elapsedRealtime();
                // Preserve the last actionable result; do not immediately overwrite it with idle text.
            } else {
                PageGuard.Page page = TapAccessibilityService.activePage();
                if (page != PageGuard.Page.OFFERS)
                    service.updateStatus("页面：" + page + "｜仅监控Offers；未点击（历史事件请在应用内查看）");
            }
            } finally {
                service.fastCheckQueued.set(false);
                if (service.fastCheckDirty.getAndSet(false) && service.monitorReady)
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
            }
        });
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        activeInstance = this;
        prefs = getSharedPreferences("rules", MODE_PRIVATE);
        createChannel();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        workerThread = new HandlerThread("screen-ocr");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !intent.hasExtra("resultData")) return START_NOT_STICKY;
        if (monitorReady) {
            updateStatus("监控已运行；规则已更新，请返回Offers页面");
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, statusNotification(String.format(Locale.US,
                "等待画面｜生效规则：最低$%.2f / 最高%.1f mi",
                prefs.getFloat("minPay", 25f), prefs.getFloat("maxMiles", 12f))));

        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent resultData = intent.getParcelableExtra("resultData");
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(resultCode, resultData);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, worker);

        DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
        width = dm.widthPixels;
        height = dm.heightPixels;
        density = dm.densityDpi;
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        virtualDisplay = projection.createVirtualDisplay("ocr-capture", width, height, density,
                0, reader.getSurface(), null, worker);
        reader.setOnImageAvailableListener(this::onFrame, worker);
        monitorReady = true;
        worker.removeCallbacks(continuousCheck);
        worker.post(continuousCheck);
        return START_NOT_STICKY;
    }

    private void onFrame(ImageReader imageReader) {
        Image image = imageReader.acquireLatestImage();
        if (image == null) return;
        int interval = prefs.getInt("interval", 200);
        long now = SystemClock.elapsedRealtime();
        // Frame callbacks can arrive at display refresh rate. Gate before any Binder/tree work.
        if (!monitorReady || now < cooldownUntil || !ScanPolicy.needsOcr(now, lastScan, lastReadableFastScan, interval, ocrBusy.get())) {
            image.close();
            return;
        }
        if (TapAccessibilityService.activePage() != PageGuard.Page.OFFERS) {
            lastScan = now;
            image.close();
            return;
        }
        lastScan = now;
        Bitmap bitmap = imageToBitmap(image);
        image.close();
        if (bitmap == null) return;
        ocrBusy.set(true);
        int cropTop = Math.round(height * 0.17f);
        int cropBottom = Math.round(height * 0.92f);
        Bitmap roi = Bitmap.createBitmap(bitmap, 0, cropTop, width, cropBottom - cropTop);
        final long frameStarted = now;
        final AtomicBoolean enhancedStarted = new AtomicBoolean(false);
        Task<Text> task = recognizer.process(InputImage.fromBitmap(roi, 0));
        task.addOnSuccessListener(result -> {
                    if (worker != null) worker.post(() -> {
                        if (!monitorReady || !ScanPolicy.fresh(SystemClock.elapsedRealtime(), frameStarted)) return;
                        scanTiming = "OCR帧至判断" + (SystemClock.elapsedRealtime() - frameStarted) + "ms";
                        evaluate(result);
                    });
                    // Borrow the useful idea from high-contrast OCR pipelines, but only as a
                    // fallback. The normal path stays raw/fast; we pay this cost only when an
                    // offer-looking frame has money+miles but the action labels were missed.
                    if (needsEnhancedOcr(result) && ScanPolicy.fresh(SystemClock.elapsedRealtime(), frameStarted)) {
                        Bitmap enhanced = enhanceForOcr(roi);
                        if (enhanced != null) {
                            try {
                                enhancedStarted.set(true);
                                recognizer.process(InputImage.fromBitmap(enhanced, 0))
                                        .addOnSuccessListener(second -> {
                                            if (worker != null) worker.post(() -> {
                                                if (!monitorReady || !ScanPolicy.fresh(SystemClock.elapsedRealtime(), frameStarted)) return;
                                                scanTiming = "增强OCR帧至判断"
                                                        + (SystemClock.elapsedRealtime() - frameStarted) + "ms";
                                                evaluate(second);
                                            });
                                        })
                                        .addOnCompleteListener(done2 -> {
                                            enhanced.recycle();
                                            ocrBusy.set(false);
                                        });
                            } catch (RuntimeException startFailure) {
                                enhancedStarted.set(false);
                                enhanced.recycle();
                            }
                        }
                    }
                })
                .addOnCompleteListener(done -> {
                    roi.recycle();
                    bitmap.recycle();
                    if (!enhancedStarted.get()) ocrBusy.set(false);
                });
    }

    private boolean needsEnhancedOcr(Text result) {
        String text = result == null ? "" : result.getText().toLowerCase(Locale.US);
        if (!text.contains("$") || !MILES.matcher(text).find()) return false;
        return findButtonBounds(result, ACCEPT_WORDS) == null
                || findButtonBounds(result, IGNORE_WORDS) == null;
    }

    private Bitmap enhanceForOcr(Bitmap source) {
        try {
            Bitmap out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(out);
            Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
            ColorMatrix matrix = new ColorMatrix();
            matrix.setSaturation(0f);
            float contrast = 1.55f;
            float offset = 128f * (1f - contrast);
            ColorMatrix contrastMatrix = new ColorMatrix(new float[]{
                    contrast, 0, 0, 0, offset,
                    0, contrast, 0, 0, offset,
                    0, 0, contrast, 0, offset,
                    0, 0, 0, 1, 0
            });
            matrix.postConcat(contrastMatrix);
            paint.setColorFilter(new ColorMatrixColorFilter(matrix));
            canvas.drawBitmap(source, 0, 0, paint);
            return out;
        } catch (RuntimeException | OutOfMemoryError ignored) {
            return null;
        }
    }

    private String fastRuleFailure(String cardText) {
        String lower = cardText.toLowerCase(Locale.US);
        float amount = offerLowAmount(cardText), miles = offerMiles(cardText);
        if (amount < 0 || miles < 0) return "信息不完整";
        float minimum = prefs.getFloat("minPay", 25f);
        float maximumMiles = prefs.getFloat("maxMiles", 12f);
        boolean pasadena = lower.contains("pasadena");
        boolean pasadenaSpecial = pasadena && prefs.getBoolean("pasadenaRuleEnabled", false);
        if (pasadenaSpecial) {
            minimum = prefs.getFloat("pasadenaMinPay", 25f);
            maximumMiles = prefs.getFloat("pasadenaMaxMiles", 12f);
        }
        if (amount < minimum || miles > maximumMiles) {
            return "金额/里程不符合";
        }
        if (prefs.getBoolean("requireCity", true) && !pasadenaSpecial
                && !containsAllowedCity(cardText)) return "城市不符合";
        if (!offerTimeAllowed(cardText)) return "订单时间不符合";
        return "";
    }

    private boolean tryFastAccept(TapAccessibilityService.FastOfferSnapshot snapshot) {
        final long decisionStarted = SystemClock.elapsedRealtime();
        String cardText = snapshot.text;
        java.util.function.Consumer<String> report = offerReporter(cardText);
        String lower = cardText.toLowerCase(Locale.US);
        float amount = offerLowAmount(cardText);
        float miles = offerMiles(cardText);
        if (amount < 0 || miles < 0) return false;

        String failure = fastRuleFailure(cardText);
        if (!failure.isEmpty()) return handleFastRejection(snapshot, amount, miles, failure);

        if (prefs.getBoolean("dryRun", true)) {
            cooldownUntil = SystemClock.elapsedRealtime() + 5_000;
            report.accept(String.format(Locale.US,
                    "快速通道测试通过：$%.2f / %.1f mi；未点击", amount, miles));
            playAlert();
            return true;
        }
        clearPendingIgnore();
        dispatchClaim(snapshot);
        return true;
    }

    private void dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot) {
        dispatchClaim(snapshot, ++claimEpoch);
    }

    private void dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot, long epoch) {
        if (epoch != claimEpoch) return;
        if (!monitorReady || prefs.getBoolean("dryRun", true)) { cooldownUntil = 0; return; }
        String id = CardText.identity(snapshot.text);
        int attempt = claimBudget.reserve(id);
        if (attempt == 0) return;
        float amount = offerLowAmount(snapshot.text), miles = offerMiles(snapshot.text);
        java.util.function.Consumer<String> report = offerReporter(snapshot.text);
        // Short transaction window only; a different card is not suppressed for 15 seconds.
        cooldownUntil = SystemClock.elapsedRealtime() + 1500;
        Runnable sent = () -> {
            report.accept("Accept第" + attempt + "次点击已发送（非接单确认）");
            worker.postDelayed(() -> inspectClaim(snapshot.text, epoch), 140);
        };
        java.util.function.Consumer<String> failed = reason -> {
            report.accept("Accept第" + attempt + "次未执行：" + reason);
            worker.postDelayed(() -> inspectClaim(snapshot.text, epoch), 140);
        };
        // A semantic click may return success without changing the app. Retry via a
        // freshly verified gesture; serialize attempts so gestures cannot cancel each other.
        if (attempt >= 2) TapAccessibilityService.tapSnapshotRetry(snapshot, amount, miles, sent, failed);
        else TapAccessibilityService.tapSnapshot(snapshot, amount, miles, sent, failed);
    }

    private void inspectClaim(String originalText, long epoch) {
        inspectClaim(originalText, epoch, 0);
    }

    private void inspectClaim(String originalText, long epoch, int disabledChecks) {
        if (!monitorReady || epoch != claimEpoch) return;
        String id = CardText.identity(originalText);
        TapAccessibilityService.FastOfferSnapshot current = TapAccessibilityService.findOffer(originalText);
        java.util.function.Consumer<String> report = offerReporter(originalText);
        if (current != null && fastRuleFailure(current.text).isEmpty() && claimBudget.available(id)) {
            if (current.acceptEnabled && !current.acceptBounds.isEmpty()) {
                dispatchClaim(current, epoch);
                return;
            }
            // A valid tap can briefly disable the button while DeliverThat processes it.
            // Observe that state twice before ending the transaction; do not mistake it
            // for a vanished order and do not issue a blind coordinate tap.
            if (disabledChecks < 2) {
                worker.postDelayed(() -> inspectClaim(originalText, epoch, disabledChecks + 1), 120);
                return;
            }
        }
        if (current != null) {
            report.accept("原订单仍可见；快速尝试结束，立即继续判断屏幕上的其他订单");
        } else {
            PageGuard.Page page = TapAccessibilityService.activePage();
            report.accept(page == PageGuard.Page.OFFERS
                    ? "原卡片已从Offers消失；停止重复点击并立即读取下一单"
                    : "页面已离开Offers；停止重复点击，等待返回Offers");
        }
        cooldownUntil = 0;
        lastScan = 0;
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * width;
        Bitmap padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(buffer);
        Bitmap exact = Bitmap.createBitmap(padded, 0, 0, width, height);
        if (exact != padded) padded.recycle();
        return exact;
    }

    private void evaluate(Text result) {
        if (!monitorReady || SystemClock.elapsedRealtime() < cooldownUntil
                || TapAccessibilityService.activePage() != PageGuard.Page.OFFERS) return;
        // An older OCR completion must not reset a newer accessibility countdown/decision.
        if (lastReadableFastScan != 0 && SystemClock.elapsedRealtime() - lastReadableFastScan < 500) return;
        Rect button = findButtonBounds(result, ACCEPT_WORDS);
        boolean hasAccept = button != null;
        if (!hasAccept) button = findButtonBounds(result, IGNORE_WORDS);
        if (button == null) {
            clearPendingIgnore();
            clearPendingAccept();
            String screenText = result.getText().toLowerCase(Locale.US);
            if (screenText.contains("$") && screenText.contains("mi")) {
                updateOfferStatus("OCR扫描：Accept与拒绝按钮均未可靠定位；未点击", result.getText());
            }
            return;
        }

        String cardText = textNearButton(result, button);
        java.util.function.Consumer<String> report = offerReporter(cardText);
        float amount = offerLowAmount(cardText);
        float miles = offerMiles(cardText);
        if (amount < 0 || miles < 0) {
            clearPendingIgnore();
            clearPendingAccept();
            report.accept("OCR信息不完整：不会点击Accept或Ignore");
            return;
        }
        float minimum = prefs.getFloat("minPay", 25f);
        float maximumMiles = prefs.getFloat("maxMiles", 12f);
        boolean pasadena = cardText.toLowerCase(Locale.US).contains("pasadena");
        if (pasadena && prefs.getBoolean("pasadenaRuleEnabled", false)) {
            minimum = prefs.getFloat("pasadenaMinPay", 25f);
            maximumMiles = prefs.getFloat("pasadenaMaxMiles", 12f);
        }
        if (amount < minimum || miles > maximumMiles) {
            clearPendingAccept();
            handleIneligible(result, button, amount, miles,
                    pasadena && prefs.getBoolean("pasadenaRuleEnabled", false)
                            ? "Pasadena专属金额/里程不符合" : "普通金额/里程不符合");
            return;
        }
        boolean pasadenaSpecial = pasadena && prefs.getBoolean("pasadenaRuleEnabled", false);
        if (prefs.getBoolean("requireCity", true) && !pasadenaSpecial && !containsAllowedCity(cardText)) {
            clearPendingAccept();
            handleIneligible(result, button, amount, miles, "城市不符合");
            return;
        }
        if (!offerTimeAllowed(cardText)) {
            clearPendingAccept();
            handleIneligible(result, button, amount, miles, "订单时间不符合");
            return;
        }

        clearPendingIgnore();

        if (!hasAccept) {
            clearPendingAccept();
            report.accept("规则符合，但未可靠定位Accept按钮；未接单");
            return;
        }

        int cropTop = Math.round(height * 0.17f);
        float x = button.exactCenterX();
        float y = button.exactCenterY() + cropTop;
        if (prefs.getBoolean("dryRun", true)) {
            cooldownUntil = SystemClock.elapsedRealtime() + 5_000;
            report.accept(String.format(Locale.US, "测试通过：$%.2f / %.1f mi；未点击", amount, miles));
            playAlert();
            return;
        }
        if (claimBudget.reserve(CardText.identity(cardText)) == 0) return;
        cooldownUntil = SystemClock.elapsedRealtime() + 1500;
        TapAccessibilityService.tapIfOfferStillMatches(x, y, amount, miles, () -> {
                    report.accept(String.format(Locale.US,
                            "OCR点击已发送：低值 $%.2f / %.1f mi；尚未确认接到", amount, miles));
                    worker.postDelayed(() -> {
                        cooldownUntil = 0;
                        report.accept("OCR点击结果待确认；继续检查其他订单，请核对Jobs");
                        requestImmediateFastCheck(SystemClock.uptimeMillis());
                    }, 180);
                }, reason -> {
                    cooldownUntil = 0;
                    report.accept("Accept未执行：" + reason);
                    lastScan = 0;
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                });
    }

    private Rect findButtonBounds(Text result, String[] words) {
        return findButtonBounds(result, words, null);
    }

    private Rect findButtonBounds(Text result, String[] words, Rect sameRowAs) {
        if (result == null) return null;
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element element : line.getElements()) {
                    String value = element.getText().trim().toLowerCase(Locale.US)
                            .replaceAll("[^a-z0-9]", "");
                    for (String word : words) {
                        Rect box = element.getBoundingBox();
                        if (buttonWordMatches(value, word) && box != null && !box.isEmpty()
                                && (sameRowAs == null || ocrSameRow(box, sameRowAs))) return new Rect(box);
                    }
                }
                String lineText = line.getText().trim().toLowerCase(Locale.US);
                String lineValue = lineText.replaceAll("[^a-z0-9]", "");
                for (String word : words) {
                    boolean present = buttonWordMatches(lineValue, word)
                            || Pattern.compile("(^|[^a-z0-9])" + Pattern.quote(word)
                            + "([^a-z0-9]|$)").matcher(lineText).find();
                    if (present && line.getBoundingBox() != null) {
                        Rect box = new Rect(line.getBoundingBox());
                        int middle = (box.left + box.right) / 2;
                        if (words == ACCEPT_WORDS && (lineValue.contains("ignore")
                                || lineValue.contains("decline") || lineValue.contains("reject"))) box.left = middle;
                        if (words == IGNORE_WORDS && (lineValue.contains("accept")
                                || lineValue.contains("claim"))) box.right = middle;
                        if (!box.isEmpty() && (sameRowAs == null || ocrSameRow(box, sameRowAs))) return box;
                    }
                }
            }
        }
        return null;
    }

    private boolean ocrSameRow(Rect a, Rect b) {
        int tolerance = Math.max(14, Math.max(a.height(), b.height()));
        return Math.abs(a.centerY() - b.centerY()) <= tolerance;
    }

    private boolean buttonWordMatches(String value, String word) {
        if (value.equals(word)) return true;
        // Common Latin OCR substitutions on Android button labels.
        if (word.equals("ignore") && (value.equals("lgnore") || value.equals("ign0re"))) return true;
        if ((word.equals("accept") || word.equals("claim"))
                && value.length() >= 4 && oneEditOrLess(value, word)) return true;
        return false;
    }

    private boolean oneEditOrLess(String a, String b) {
        if (Math.abs(a.length() - b.length()) > 1) return false;
        int i = 0, j = 0, edits = 0;
        while (i < a.length() && j < b.length()) {
            if (a.charAt(i) == b.charAt(j)) {
                i++;
                j++;
                continue;
            }
            if (++edits > 1) return false;
            if (a.length() > b.length()) i++;
            else if (b.length() > a.length()) j++;
            else {
                i++;
                j++;
            }
        }
        if (i < a.length() || j < b.length()) edits++;
        return edits <= 1;
    }

    private void handleIneligible(Text result, Rect accept, float amount, float miles, String reason) {
        Rect reject = findButtonBounds(result, IGNORE_WORDS, accept);
        if (reject != null) {
            reject = new Rect(reject);
            reject.offset(0, Math.round(height * 0.17f));
        }
        handleRejectedCard(textNearButton(result, accept), reject, amount, miles, reason, false);
    }

    private boolean handleFastRejection(TapAccessibilityService.FastOfferSnapshot snapshot,
                                        float amount, float miles, String reason) {
        if (!snapshot.rejectEnabled || snapshot.rejectBounds.isEmpty()) return false;
        handleRejectedCard(snapshot.text, snapshot.rejectBounds, amount, miles, reason, true);
        return true;
    }

    private void handleRejectedCard(String cardText, Rect reject, float amount, float miles, String reason, boolean fastSource) {
        String fingerprint = CardText.identity(cardText);
        java.util.function.Consumer<String> report = offerReporter(cardText);
        if (!fingerprint.equals(lastLoggedIneligibleFingerprint)) {
            lastLoggedIneligibleFingerprint = fingerprint;
            appendIgnoredRecord(amount, miles, reason, cardText);
        }
        if (prefs.getBoolean("dryRun", false)) {
            clearPendingIgnore();
            report.accept(String.format(Locale.US, "测试未Ignore：$%.2f / %.1f mi，%s", amount, miles, reason));
            return;
        }
        if (!prefs.getBoolean("autoIgnore", true)) {
            clearPendingIgnore();
            report.accept(String.format(Locale.US, "未接：$%.2f / %.1f mi，%s", amount, miles, reason));
            return;
        }

        long now = SystemClock.elapsedRealtime();
        RejectSequence.State state = rejectSequence.observe(fingerprint, now);
        if (state == RejectSequence.State.EXHAUSTED) {
            report.accept("原订单拒绝已尝试3次仍可见；跳过本卡并继续检查其他订单");
            return;
        }
        if (state == RejectSequence.State.WAIT) return;

        if (reject == null || reject.isEmpty()) {
            report.accept("订单不符合，但未可靠定位Ignore/Decline/Reject；未点击");
            return;
        }
        float x = reject.exactCenterX();
        float y = reject.exactCenterY();
        cooldownUntil = now + 1_200;
        clearPendingIgnore();
        rejectSequence.sent(fingerprint, now);
        TapAccessibilityService.ignoreIfOfferStillMatches(x, y, amount, miles, fastSource ? cardText : null,
                () -> {
                    report.accept(String.format(Locale.US,
                            "拒绝点击已发送：$%.2f / %.1f mi；立即读取下一单", amount, miles));
                    cooldownUntil = 0;
                    if (worker != null) {
                        worker.postDelayed(() -> {
                            if (!monitorReady) return;
                            lastScan = 0;
                            requestImmediateFastCheck(SystemClock.uptimeMillis());
                        }, 60);
                        worker.postDelayed(() -> {
                            if (monitorReady) requestImmediateFastCheck(SystemClock.uptimeMillis());
                        }, 190);
                    }
                },
                failureReason -> {
                    cooldownUntil = 0;
                    report.accept("拒绝未执行：" + failureReason);
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                });
    }

    private void clearPendingIgnore() {
        pendingIgnoreFingerprint = "";
        pendingIgnoreSince = 0;
    }

    private void clearPendingAccept() {
        pendingAcceptFingerprint = "";
        pendingAcceptConfirmations = 0;
    }

    private void appendIgnoredRecord(float amount, float miles, String reason, String cardText) {
        String when = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date());
        String entry = String.format(Locale.US, "%s｜$%.2f / %.1f mi｜%s\n%s",
                when, amount, miles, reason, compactOfferText(cardText));
        String history = prefs.getString("ignoredHistory", "");
        history = history.isEmpty() ? entry : entry + "\n\n" + history;
        if (history.length() > 7000) history = history.substring(0, 7000);
        prefs.edit().putString("ignoredHistory", history).apply();
        updateOfferStatus("规则未通过：$" + String.format(Locale.US, "%.2f / %.1f mi，", amount, miles)
                + reason, cardText);
    }

    private String compactOfferText(String text) {
        if (text == null) return "";
        String clean = text.replaceAll("\\s+", " ").trim();
        return clean.length() > 360 ? clean.substring(0, 360) + "…" : clean;
    }

    private String textNearButton(Text result, Rect button) {
        if (button == null) return "";
        List<CardText.Piece> pieces = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                if (line.getBoundingBox() == null) continue;
                Rect box = line.getBoundingBox();
                pieces.add(new CardText.Piece(line.getText(), box.left, box.top, box.bottom));
            }
        }
        return CardText.aboveButton(pieces, button.top, button.bottom);
    }

    private float offerLowAmount(String text) {
        Matcher range = MONEY_RANGE.matcher(text.replace(',', '.'));
        if (range.find()) {
            try { return Float.parseFloat(range.group(1).replace(',', '.')); }
            catch (NumberFormatException ignored) { }
        }
        Matcher matcher = MONEY.matcher(text.replace(',', '.'));
        if (!matcher.find()) return -1f;
        try { return Float.parseFloat(matcher.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    private float offerMiles(String text) {
        Matcher matcher = MILES.matcher(text.replace(',', '.'));
        if (!matcher.find()) return -1f;
        try { return Float.parseFloat(matcher.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    private boolean containsAllowedCity(String text) {
        String lower = text.toLowerCase(Locale.US);
        String configuredValue = prefs.getString("cities", "").trim();
        // Blank means that city filtering is disabled.
        if (configuredValue.isEmpty()) return true;
        String[] configured = configuredValue.split(",");
        List<String> cities = new ArrayList<>();
        for (String city : configured) {
            String clean = city.trim().toLowerCase(Locale.US);
            if (!clean.isEmpty()) cities.add(clean);
        }
        if (cities.isEmpty()) return false;
        for (String city : cities) if (lower.contains(city)) return true;
        return false;
    }

    private boolean offerTimeAllowed(String text) {
        try {
            String configuredStart = prefs.getString("startTime", "").trim();
            String configuredEnd = prefs.getString("endTime", "").trim();
            // Blank/incomplete time fields mean that time filtering is disabled.
            if (configuredStart.isEmpty() || configuredEnd.isEmpty()) return true;
            Matcher matcher = OFFER_TIME.matcher(text);
            if (!matcher.find()) return false;
            DateTimeFormatter offerFormat = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
            LocalTime offer = LocalTime.parse(
                    matcher.group(1) + " " + matcher.group(2).toUpperCase(Locale.US), offerFormat);
            DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
            LocalTime start = LocalTime.parse(configuredStart, f);
            LocalTime end = LocalTime.parse(configuredEnd, f);
            if (end.isAfter(start) || end.equals(start)) return !offer.isBefore(start) && !offer.isAfter(end);
            return !offer.isBefore(start) || !offer.isAfter(end);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void playAlert() {
        try {
            AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION,
                    audio.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION), 0);
            Ringtone tone = RingtoneManager.getRingtone(this,
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            tone.play();
        } catch (Exception ignored) { }
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL,
                "OCR monitor", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private Notification statusNotification(String status) {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String expanded = status;
        if (expanded.length() > 3500) expanded = expanded.substring(0, 3500);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Catering Screen Assistant")
                .setContentText(status)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(expanded))
                .setOngoing(true)
                .setContentIntent(open)
                .build();
    }

    private void updateStatus(String status) {
        logWriter.execute(() -> writeStatus(status));
    }

    private void writeStatus(String status) {
        if (!monitorReady && activeInstance != this) return;
        if (status.equals(prefs.getString("lastStatus", ""))) return;
        prefs.edit()
                .putString("lastStatus", status)
                .putLong("lastStatusAt", System.currentTimeMillis())
                .apply();
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, statusNotification(status));
    }

    private String lastEventKey = "";
    private java.util.function.Consumer<String> offerReporter(String cardText) {
        final String rules = ruleSummary();
        final String timing = scanTiming;
        final long started = SystemClock.elapsedRealtime();
        return message -> updateOfferStatus(message + "\n本次处理：" + timing + "；判断至记录"
                + (SystemClock.elapsedRealtime() - started) + "ms", cardText, rules);
    }

    private String ruleSummary() {
        return "普通≥$" + prefs.getFloat("minPay",25f) + " / ≤" + prefs.getFloat("maxMiles",12f)
                + "mi；Pasadena启用=" + prefs.getBoolean("pasadenaRuleEnabled",false)
                + " ≥$" + prefs.getFloat("pasadenaMinPay",25f) + " / ≤" + prefs.getFloat("pasadenaMaxMiles",12f)
                + "mi；城市=" + prefs.getString("cities", "") + "；时间=" + prefs.getString("startTime", "")
                + "–" + prefs.getString("endTime", "");
    }

    private void updateOfferStatus(String status, String cardText) {
        updateOfferStatus(status, cardText, ruleSummary());
    }

    private synchronized void updateOfferStatus(String status, String cardText, String rules) {
        if (!isMonitoring()) return;
        String identity = CardText.identity(cardText);
        String eventKey = identity + "|" + status.split("\\n本次处理：", 2)[0];
        if (eventKey.equals(lastEventKey)) return;
        lastEventKey = eventKey;
        String id = Integer.toHexString(identity.hashCode());
        String event = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(new Date())
                + "｜卡片#" + id + "\n" + status + "\n本次卡片：" + cardText
                + "\n本次规则：" + rules;
        logWriter.execute(() -> {
        if (!monitorReady) return;
        try {
            org.json.JSONArray history = new org.json.JSONArray(prefs.getString("decisionEvents", "[]"));
            org.json.JSONArray next = new org.json.JSONArray();
            next.put(event);
            for (int i = 0; i < Math.min(99, history.length()); i++) next.put(history.getString(i));
            prefs.edit().putString("decisionEvents", next.toString()).putString("lastDecision", event).apply();
        } catch (org.json.JSONException ignored) {
            prefs.edit().putString("lastDecision", event).apply();
        }
        writeStatus(event);
        });
    }

    @Override
    public void onDestroy() {
        monitorReady = false;
        if (worker != null) worker.removeCallbacksAndMessages(null);
        if (worker != null) worker.removeCallbacks(continuousCheck);
        if (activeInstance == this) activeInstance = null;
        if (virtualDisplay != null) virtualDisplay.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (recognizer != null) recognizer.close();
        if (workerThread != null) workerThread.quitSafely();
        logWriter.shutdownNow();
        super.onDestroy();
    }
}
