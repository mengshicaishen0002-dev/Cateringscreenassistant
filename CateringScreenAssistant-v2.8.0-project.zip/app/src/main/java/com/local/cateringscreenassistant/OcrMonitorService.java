package com.local.cateringscreenassistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.hardware.display.VirtualDisplay;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.text.DateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OcrMonitorService extends Service {
    private static final String CHANNEL = "ocr_monitor";
    private static final int NOTIFICATION_ID = 41;
    private static final Pattern MONEY_RANGE = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)\\s*[-–—]\\s*\\$?(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MILES = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern OFFER_TIME = Pattern.compile("(?:today|tomorrow)\\s*(?:at)?\\s*(\\d{1,2}:\\d{2})\\s*(am|pm)", Pattern.CASE_INSENSITIVE);
    private static final String[] ACCEPT_WORDS = {"accept", "claim"};
    private static final String[] IGNORE_WORDS = {"ignore", "decline", "reject"};
    private static volatile OcrMonitorService activeInstance;
    // v2.10.6 Galaxy A15 speed profile: the first DeliverThat card lives roughly in
    // the middle third of the screen. Keep a little safety margin but stop copying/OCRing
    // the navigation bar and lower cards.
    private static final float TOP_ROI_START = 0.20f;
    private static final float TOP_ROI_END = 0.58f;
    private static final int DEFAULT_SCAN_INTERVAL_MS = 80;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private HandlerThread workerThread;
    private Handler worker;
    // Keep Accessibility decisions on their own high-priority queue so a heavy OCR frame
    // cannot delay an offer click. This is the primary low-latency path.
    private HandlerThread fastThread;
    private Handler fastWorker;
    private final java.util.concurrent.ThreadPoolExecutor logWriter = new java.util.concurrent.ThreadPoolExecutor(
            1, 1, 0L, java.util.concurrent.TimeUnit.MILLISECONDS,
            new java.util.concurrent.ArrayBlockingQueue<Runnable>(256),
            new java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy());
    private TextRecognizer recognizer;
    private final AtomicBoolean ocrBusy = new AtomicBoolean(false);
    private long lastScan;
    private volatile long lastReadableFastScan;
    private volatile String scanTiming = "";
    private volatile long cooldownUntil;
    private long pendingIgnoreSince;
    private String pendingIgnoreFingerprint = "";
    private String pendingAcceptFingerprint = "";
    private String lastLoggedIneligibleFingerprint = "";
    private int pendingAcceptConfirmations;
    private int width;
    private int height;
    private int density;
    private SharedPreferences prefs;
    private volatile boolean monitorReady;
    private int[] visualScanPixels;
    // v2.10.9: reuse ROI bitmaps across frames. ML Kit allows only one OCR task here
    // (ocrBusy gate), so pooled buffers are safe and avoid repeated 720x600 allocations/GC.
    private Bitmap roiPaddedBuffer;
    private Bitmap roiExactBuffer;
    private final Paint roiCopyPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    // While an Accessibility decision/gesture is in flight, do not start a competing ML Kit
    // frame. This protects the time-critical first tap from CPU/Binder contention.
    private volatile long accessibilityActionHoldUntil;
    private final AtomicBoolean fastCheckQueued = new AtomicBoolean(false);
    private final AtomicBoolean fastCheckDirty = new AtomicBoolean(false);
    public static boolean isMonitoring() {
        OcrMonitorService current = activeInstance;
        return current != null && current.monitorReady;
    }
    private long claimEpoch;
    // v2.10.3 serial queue: lock the current top card until it actually disappears.
    private volatile String serialTopText = "";
    private volatile long serialTopActionAt;
    private final ClaimBudget claimBudget = new ClaimBudget();
    private final RejectSequence rejectSequence = new RejectSequence();
    private final Runnable continuousCheck = new Runnable() {
        @Override public void run() {
            if (!monitorReady || fastWorker == null) return;
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            // Event-driven scans remain immediate. A full DeliverThat accessibility tree walk
            // on this Samsung can take 400-800 ms, so a 90 ms heartbeat made the fast thread
            // run back-to-back forever and stole time from the OCR action path. Keep only a
            // low-rate safety heartbeat; content-change events still wake us immediately.
            fastWorker.postDelayed(this, 900);
        }
    };

    public static void requestImmediateFastCheck(long eventTime) {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady || service.fastWorker == null) return;
        if (!service.fastCheckQueued.compareAndSet(false, true)) {
            service.fastCheckDirty.set(true);
            return;
        }
        final long queuedAt = SystemClock.elapsedRealtime();
        service.fastWorker.post(() -> {
            try {
            long now = SystemClock.elapsedRealtime();
            if (now < service.cooldownUntil) return;
            List<TapAccessibilityService.FastOfferSnapshot> cards = TapAccessibilityService.getFastOfferSnapshots();
            service.scanTiming = "排队" + (now - queuedAt) + "ms；读界面"
                    + (SystemClock.elapsedRealtime() - now) + "ms；可读卡片" + cards.size();
            // Serial top-card queue. If we just acted on the first card, keep every lower
            // card locked until the original top card is no longer the visible top offer.
            String visibleTop = TapAccessibilityService.getTopVisibleOfferText();
            if (!service.serialTopText.isEmpty()) {
                if (!visibleTop.isEmpty() && CardText.sameOffer(service.serialTopText, visibleTop)) {
                    // Keep processing/waiting only for the same top card. Lower cards must not
                    // steal its button coordinates during Ignore countdown/transition states.
                } else if (!visibleTop.isEmpty()) {
                    service.rejectSequence.forget(CardText.identity(service.serialTopText));
                    service.serialTopText = "";
                    service.serialTopActionAt = 0;
                } else {
                    // v2.10.4: never unlock merely because the top card is temporarily
                    // unreadable during Ignore/Decline countdown or animation. Keep the queue
                    // locked until a different top offer is positively observed.
                    service.updateStatus("顶部订单处理中/倒计时；未确认原卡消失，继续锁定第一张");
                    return;
                }
            }
            // Alert only the current first card; subsequent cards will alert after moving up.
            if (!cards.isEmpty() && service.fastRuleFailure(cards.get(0).text).isEmpty()) {
                TapAccessibilityService.FastOfferSnapshot card = cards.get(0);
                float alertAmount = service.offerLowAmount(card.text);
                float alertMiles = service.offerMiles(card.text);
                QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, card.text, alertAmount, alertMiles);
            }
            TapAccessibilityService.FastOfferSnapshot selected = OfferPriority.choose(cards,
                    card -> service.fastRuleFailure(card.text).isEmpty(),
                    card -> !card.acceptBounds.isEmpty()
                            && service.claimBudget.available(CardText.identity(card.text), SystemClock.elapsedRealtime()),
                    card -> service.prefs.getBoolean("autoIgnore", true) && !card.rejectBounds.isEmpty()
                            && service.rejectSequence.observe(CardText.identity(card.text),
                            SystemClock.elapsedRealtime()) == RejectSequence.State.READY);
            if (selected != null) {
                boolean actionDispatched = service.tryFastAccept(selected);
                service.lastReadableFastScan = actionDispatched ? SystemClock.elapsedRealtime() : 0;
            } else if (!cards.isEmpty()) {
                // Critical v2.9 fix: readable card text must NOT starve the OCR fallback.
                // Some DeliverThat builds expose money/miles but hide or disable the action
                // node; v2.8 refreshed lastReadableFastScan forever and OCR never got a turn.
                service.lastReadableFastScan = 0;
                service.updateStatus("页面：OFFERS｜发现" + cards.size()
                        + "张卡片但辅助功能动作不可用；OCR兜底已激活");
            } else {
                service.lastReadableFastScan = 0;
                PageGuard.Page page = TapAccessibilityService.activePage();
                String treeDebug = TapAccessibilityService.debugTreeSummary();
                if (page == PageGuard.Page.OFFERS)
                    service.updateStatus("页面：OFFERS｜监控中；当前无可读订单｜" + treeDebug);
                else
                    service.updateStatus("页面：" + page + "｜仅监控Offers；未点击｜" + treeDebug
                            + "（历史事件请在应用内查看）");
            }
            } finally {
                service.fastCheckQueued.set(false);
                if (service.fastCheckDirty.getAndSet(false) && service.monitorReady)
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
            }
        });
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        activeInstance = this;
        prefs = getSharedPreferences("rules", MODE_PRIVATE);
        // One-time upgrade from the old 140 ms default. Preserve any non-default value the
        // user chose manually, but move untouched installs to the lower-latency profile.
        if (!prefs.getBoolean("v2106SpeedProfileApplied", false)) {
            SharedPreferences.Editor migration = prefs.edit().putBoolean("v2106SpeedProfileApplied", true);
            if (prefs.getInt("interval", 140) == 140) migration.putInt("interval", DEFAULT_SCAN_INTERVAL_MS);
            migration.apply();
        }
        createChannel();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        workerThread = new HandlerThread("screen-ocr", android.os.Process.THREAD_PRIORITY_DISPLAY);
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        fastThread = new HandlerThread("offer-fast", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        fastThread.start();
        fastWorker = new Handler(fastThread.getLooper());
        warmRecognizer();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !intent.hasExtra("resultData")) return START_NOT_STICKY;
        if (monitorReady) {
            updateStatus("监控已运行；规则已更新，请返回Offers页面");
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, statusNotification(String.format(Locale.US,
                "等待画面｜生效规则：最低$%.2f / 最高%.1f mi",
                prefs.getFloat("minPay", 25f), prefs.getFloat("maxMiles", 12f))));

        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent resultData = intent.getParcelableExtra("resultData");
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(resultCode, resultData);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, worker);

        DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
        width = dm.widthPixels;
        height = dm.heightPixels;
        density = dm.densityDpi;
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        virtualDisplay = projection.createVirtualDisplay("ocr-capture", width, height, density,
                0, reader.getSurface(), null, worker);
        reader.setOnImageAvailableListener(this::onFrame, worker);
        monitorReady = true;
        fastWorker.removeCallbacks(continuousCheck);
        fastWorker.post(continuousCheck);
        return START_NOT_STICKY;
    }

    private void onFrame(ImageReader imageReader) {
        Image image = imageReader.acquireLatestImage();
        if (image == null) return;
        int interval = prefs.getInt("interval", DEFAULT_SCAN_INTERVAL_MS);
        long now = SystemClock.elapsedRealtime();
        // Frame callbacks can arrive at display refresh rate. Gate before any Binder/tree work.
        if (!monitorReady || now < cooldownUntil || now < accessibilityActionHoldUntil
                || !ScanPolicy.needsOcr(now, lastScan, lastReadableFastScan, interval, ocrBusy.get())) {
            image.close();
            return;
        }
        PageGuard.Page active = TapAccessibilityService.recentPageHint();
        if (!TapAccessibilityService.isDeliverThatForeground()
                || active == PageGuard.Page.JOBS || active == PageGuard.Page.IGNORED) {
            lastScan = now;
            image.close();
            return;
        }
        lastScan = now;
        final long frameStarted = now;
        int cropTop = topCropTop();
        int cropBottom = topCropBottom();
        // v2.10.6: copy only the first-card rows directly from the ImageReader plane.
        // v2.10.5 first allocated/copied a full 720x1600 bitmap and then cropped it, which
        // wasted memory bandwidth before ML Kit even started.
        Bitmap roi = imageToTopRoiBitmap(image, cropTop, cropBottom);
        image.close();
        if (roi == null) return;
        final long roiReadyAt = SystemClock.elapsedRealtime();
        ocrBusy.set(true);
        // Start ML Kit first, then scan the visual Accept band while recognition runs on its
        // own executor. The bitmap is read-only until the task completes, so these two reads
        // can overlap instead of serializing visual-button detection before OCR.
        Task<Text> task = recognizer.process(InputImage.fromBitmap(roi, 0));
        // DeliverThat's filled blue Accept button is visually stable even on builds that
        // expose neither button label to Accessibility nor readable button text to ML Kit.
        final Rect visualAccept = findVisualAcceptButton(roi);
        final AtomicBoolean enhancedStarted = new AtomicBoolean(false);
        task.addOnSuccessListener(result -> {
                    if (worker != null) worker.post(() -> {
                        if (!monitorReady || !ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) return;
                        long decidedAt = SystemClock.elapsedRealtime();
                        scanTiming = "首卡ROI复制" + (roiReadyAt - frameStarted) + "ms；OCR"
                                + (decidedAt - roiReadyAt) + "ms；总" + (decidedAt - frameStarted) + "ms";
                        evaluate(result, frameStarted, visualAccept);
                    });
                    // Borrow the useful idea from high-contrast OCR pipelines, but only as a
                    // fallback. The normal path stays raw/fast; we pay this cost only when an
                    // offer-looking frame has money+miles but the action labels were missed.
                    if (needsEnhancedOcr(result, visualAccept) && ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) {
                        Bitmap enhanced = enhanceForOcr(roi);
                        if (enhanced != null) {
                            try {
                                enhancedStarted.set(true);
                                recognizer.process(InputImage.fromBitmap(enhanced, 0))
                                        .addOnSuccessListener(second -> {
                                            if (worker != null) worker.post(() -> {
                                                if (!monitorReady || !ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) return;
                                                scanTiming = "增强OCR帧至判断"
                                                        + (SystemClock.elapsedRealtime() - frameStarted) + "ms";
                                                evaluate(second, frameStarted, visualAccept);
                                            });
                                        })
                                        .addOnCompleteListener(done2 -> {
                                            enhanced.recycle();
                                            ocrBusy.set(false);
                                        });
                            } catch (RuntimeException startFailure) {
                                enhancedStarted.set(false);
                                enhanced.recycle();
                            }
                        }
                    }
                })
                .addOnCompleteListener(done -> {
                    // roi is a pooled reusable buffer in v2.10.9; do not recycle per frame.
                    if (!enhancedStarted.get()) ocrBusy.set(false);
                });
    }

    private boolean needsEnhancedOcr(Text result, Rect visualAccept) {
        String text = result == null ? "" : result.getText().toLowerCase(Locale.US);
        boolean hasMoney = text.contains("$") || MONEY.matcher(text).find();
        boolean hasMiles = MILES.matcher(text).find();
        // If neither numeric signal is present this is usually not an offer frame.
        if (!hasMoney && !hasMiles) return false;
        // One missing numeric field is worth a high-contrast retry.
        if (!hasMoney || !hasMiles) return true;
        // v2.9.3: do not spend another ~300-700 ms merely because one button word
        // was missed. A visual Accept anchor or either action label is enough to infer
        // the paired action row safely on a fresh frame.
        if (visualAccept != null && !visualAccept.isEmpty()) return false;
        if (findButtonBounds(result, ACCEPT_WORDS) != null) return false;
        if (findButtonBounds(result, IGNORE_WORDS) != null) return false;
        return true;
    }

    /**
     * Conservative visual fallback for DeliverThat's filled blue Accept button.
     * We intentionally look only in the lower/right part of the Offers ROI and require
     * a wide, short, dense cyan/blue rectangle. This avoids the selected Offers tab and
     * small navigation/status icons. Coordinates are ROI-local, matching ML Kit boxes.
     */
    private Rect findVisualAcceptButton(Bitmap source) {
        if (source == null) return null;
        final int w = source.getWidth(), h = source.getHeight();
        if (w < 240 || h < 400) return null;
        final int xStart = Math.round(w * 0.51f);
        final int yStart = Math.round(h * 0.55f);
        final int yEnd = Math.round(h * 0.94f);
        final int bandHeight = Math.max(1, yEnd - yStart);
        final int needed = w * bandHeight;
        try {
            if (visualScanPixels == null || visualScanPixels.length < needed)
                visualScanPixels = new int[needed];
            source.getPixels(visualScanPixels, 0, w, 0, yStart, w, bandHeight);
        } catch (RuntimeException | OutOfMemoryError failure) {
            return null;
        }
        final int stepY = 2;
        Rect current = null;
        Rect best = null;
        int bestArea = 0;
        int gapRows = 0;
        for (int y = yStart; y < yEnd; y += stepY) {
            int runStart = -1, runEnd = -1, bestRunStart = -1, bestRunEnd = -1;
            int toleratedGap = 0;
            for (int x = xStart; x < w - 4; x += 2) {
                int c = visualScanPixels[(y - yStart) * w + x];
                if (looksLikeAcceptBlue(c)) {
                    if (runStart < 0) runStart = x;
                    runEnd = x;
                    toleratedGap = 0;
                } else if (runStart >= 0 && toleratedGap < 3) {
                    toleratedGap++;
                } else if (runStart >= 0) {
                    if (runEnd - runStart > bestRunEnd - bestRunStart) {
                        bestRunStart = runStart;
                        bestRunEnd = runEnd;
                    }
                    runStart = runEnd = -1;
                    toleratedGap = 0;
                }
            }
            if (runStart >= 0 && runEnd - runStart > bestRunEnd - bestRunStart) {
                bestRunStart = runStart;
                bestRunEnd = runEnd;
            }
            int minRun = Math.max(56, Math.round(w * 0.105f));
            if (bestRunStart >= 0 && bestRunEnd - bestRunStart >= minRun) {
                Rect row = new Rect(bestRunStart, y, bestRunEnd + 2, y + stepY);
                if (current == null) {
                    current = row;
                } else if (row.left <= current.right + 18 && row.right >= current.left - 18
                        && y - current.bottom <= 6) {
                    current.union(row);
                } else {
                    if (isAcceptShape(current, w, h) && current.width() * current.height() > bestArea) {
                        best = new Rect(current);
                        bestArea = current.width() * current.height();
                    }
                    current = row;
                }
                gapRows = 0;
            } else if (current != null && ++gapRows > 3) {
                if (isAcceptShape(current, w, h) && current.width() * current.height() > bestArea) {
                    best = new Rect(current);
                    bestArea = current.width() * current.height();
                }
                current = null;
                gapRows = 0;
            }
        }
        if (current != null && isAcceptShape(current, w, h) && current.width() * current.height() > bestArea)
            best = new Rect(current);
        return best;
    }

    private boolean looksLikeAcceptBlue(int color) {
        int r = (color >> 16) & 0xff, g = (color >> 8) & 0xff, b = color & 0xff;
        // DeliverThat currently uses a saturated cyan/blue filled button. Keep the gate
        // broad enough for display color profiles but narrow enough to reject gray/white UI.
        return b >= 135 && g >= 95 && r <= 125
                && b - r >= 45 && g - r >= 25;
    }

    private boolean isAcceptShape(Rect r, int w, int h) {
        if (r == null || r.isEmpty()) return false;
        int minW = Math.max(60, Math.round(w * 0.10f));
        int maxW = Math.round(w * 0.43f);
        int minH = Math.max(18, Math.round(h * 0.018f));
        int maxH = Math.round(h * 0.18f);
        float aspect = r.height() == 0 ? 0f : (float) r.width() / r.height();
        return r.width() >= minW && r.width() <= maxW
                && r.height() >= minH && r.height() <= maxH
                && aspect >= 1.7f && aspect <= 8.5f
                && r.centerX() > w * 0.58f && r.centerY() > h * 0.36f;
    }

    private Bitmap enhanceForOcr(Bitmap source) {
        try {
            Bitmap out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(out);
            Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
            ColorMatrix matrix = new ColorMatrix();
            matrix.setSaturation(0f);
            float contrast = 1.55f;
            float offset = 128f * (1f - contrast);
            ColorMatrix contrastMatrix = new ColorMatrix(new float[]{
                    contrast, 0, 0, 0, offset,
                    0, contrast, 0, 0, offset,
                    0, 0, contrast, 0, offset,
                    0, 0, 0, 1, 0
            });
            matrix.postConcat(contrastMatrix);
            paint.setColorFilter(new ColorMatrixColorFilter(matrix));
            canvas.drawBitmap(source, 0, 0, paint);
            return out;
        } catch (RuntimeException | OutOfMemoryError ignored) {
            return null;
        }
    }

    private String fastRuleFailure(String cardText) {
        String lower = cardText.toLowerCase(Locale.US);
        float amount = offerLowAmount(cardText), miles = offerMiles(cardText);
        if (amount < 0 || miles < 0) return "信息不完整";
        float minimum = prefs.getFloat("minPay", 25f);
        float maximumMiles = prefs.getFloat("maxMiles", 12f);
        boolean pasadena = lower.contains("pasadena");
        boolean pasadenaSpecial = pasadena && prefs.getBoolean("pasadenaRuleEnabled", false);
        if (pasadenaSpecial) {
            minimum = prefs.getFloat("pasadenaMinPay", 25f);
            maximumMiles = prefs.getFloat("pasadenaMaxMiles", 12f);
        }
        if (amount < minimum || miles > maximumMiles) {
            return "金额/里程不符合";
        }
        if (prefs.getBoolean("requireCity", true) && !pasadenaSpecial
                && !containsAllowedCity(cardText)) return "城市不符合";
        if (!offerTimeAllowed(cardText)) return "订单时间不符合";
        return "";
    }

    private boolean tryFastAccept(TapAccessibilityService.FastOfferSnapshot snapshot) {
        final long decisionStarted = SystemClock.elapsedRealtime();
        String cardText = snapshot.text;
        java.util.function.Consumer<String> report = offerReporter(cardText);
        String lower = cardText.toLowerCase(Locale.US);
        float amount = offerLowAmount(cardText);
        float miles = offerMiles(cardText);
        if (amount < 0 || miles < 0) return false;

        String failure = fastRuleFailure(cardText);
        if (!failure.isEmpty()) return handleFastRejection(snapshot, amount, miles, failure);

        if (prefs.getBoolean("dryRun", false)) {
            cooldownUntil = SystemClock.elapsedRealtime() + 5_000;
            report.accept(String.format(Locale.US,
                    "快速通道测试通过：$%.2f / %.1f mi；未点击", amount, miles));
            playAlert();
            return true;
        }
        clearPendingIgnore();
        return dispatchClaim(snapshot);
    }

    private boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot) {
        return dispatchClaim(snapshot, ++claimEpoch);
    }

    private boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot, long epoch) {
        if (epoch != claimEpoch) return false;
        if (!monitorReady || prefs.getBoolean("dryRun", false)) { cooldownUntil = 0; return false; }
        String id = CardText.identity(snapshot.text);
        int attempt = claimBudget.reserve(id, SystemClock.elapsedRealtime());
        if (attempt == 0) return false;
        serialTopText = snapshot.text;
        serialTopActionAt = SystemClock.elapsedRealtime();
        float amount = offerLowAmount(snapshot.text), miles = offerMiles(snapshot.text);
        java.util.function.Consumer<String> report = offerReporter(snapshot.text);
        if (snapshot.acceptBounds.isEmpty() || !ActionGeometry.plausibleActionRect(
                width, height, snapshot.acceptBounds.left, snapshot.acceptBounds.top,
                snapshot.acceptBounds.right, snapshot.acceptBounds.bottom, true)) {
            report.accept("Accept热区几何异常（疑似整卡/容器）；已禁止点击并交给OCR重新定位");
            cooldownUntil = 0;
            lastReadableFastScan = 0;
            return false;
        }
        // Short transaction window only; a different card is not suppressed for 15 seconds.
        cooldownUntil = SystemClock.elapsedRealtime() + 1500;
        accessibilityActionHoldUntil = SystemClock.elapsedRealtime() + 520;
        java.util.function.Consumer<String> sent = detail -> {
            accessibilityActionHoldUntil = 0;
            report.accept("Accept第" + attempt + "次动作已发送：" + detail + "；非接单确认");
            if (fastWorker != null) fastWorker.postDelayed(() -> inspectClaim(snapshot.text, epoch), 70);
        };
        java.util.function.Consumer<String> failed = reason -> {
            accessibilityActionHoldUntil = 0;
            report.accept("Accept第" + attempt + "次未执行：" + reason);
            if (fastWorker != null) fastWorker.postDelayed(() -> inspectClaim(snapshot.text, epoch), 70);
        };
        // v2.10.12: first attempt goes straight to the verified 55ms Gesture. Real-device
        // evidence showed ACTION_CLICK added latency but did not move DeliverThat, while the
        // gesture reliably changed Accept into disabled/processing. Retry attempts refresh the
        // top-card action first and never spend an attempt while the button is disabled.
        if (attempt >= 2)
            TapAccessibilityService.tapSnapshotRetryDetailed(snapshot, amount, miles, attempt, sent, failed);
        else
            TapAccessibilityService.tapSnapshotFastDetailed(snapshot, amount, miles, sent, failed);
        return true;
    }

    private void inspectClaim(String originalText, long epoch) {
        inspectClaim(originalText, epoch, 0, 0);
    }

    private void inspectClaim(String originalText, long epoch, int disabledChecks, int missingChecks) {
        if (!monitorReady || epoch != claimEpoch) return;
        String id = CardText.identity(originalText);
        TapAccessibilityService.FastOfferSnapshot current = TapAccessibilityService.findOffer(originalText);
        java.util.function.Consumer<String> report = offerReporter(originalText);
        String outcomeHint = TapAccessibilityService.recentClaimOutcomeSince(serialTopActionAt);
        if (current != null && fastRuleFailure(current.text).isEmpty()
                && claimBudget.available(id, SystemClock.elapsedRealtime())) {
            if (!current.acceptBounds.isEmpty() && current.acceptEnabled) {
                // Important v2.10.12 fix: reserve the next attempt ONLY after the button has
                // returned to an enabled state. v2.10.11 burned attempts #2/#3 while the same
                // Accept was disabled/processing, leaving no real retry when the backend failed.
                dispatchClaim(current, epoch);
                return;
            }
            if (!current.acceptEnabled) {
                if (TapAccessibilityService.isPositiveClaimOutcome(outcomeHint)) {
                    serialTopText = "";
                    serialTopActionAt = 0;
                    claimBudget.forget(id);
                    report.accept("已确认接单成功：" + outcomeHint);
                    cooldownUntil = 0;
                    lastScan = 0;
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                    return;
                }
                // A valid claim commonly disables the button while the server arbitrates it.
                // Poll long enough for that transaction to either disappear or re-enable.
                // These polls do NOT consume ClaimBudget attempts.
                if (disabledChecks < ActionDispatchPolicy.processingMaxChecks()) {
                    if (disabledChecks == 0)
                        report.accept("Accept已进入禁用/处理中；等待服务器结果，不消耗重试次数"
                                + (outcomeHint.isEmpty() ? "" : "；状态=" + outcomeHint));
                    if (fastWorker != null)
                        fastWorker.postDelayed(() -> inspectClaim(originalText, epoch,
                                disabledChecks + 1, missingChecks),
                                ActionDispatchPolicy.processingPollMs());
                    return;
                }
            }
        }
        if (current != null) {
            serialTopText = originalText;
            if (serialTopActionAt <= 0) serialTopActionAt = SystemClock.elapsedRealtime();
            report.accept("顶部原订单仍可见；未确认接单，继续锁定第一张，不处理下面订单"
                    + (outcomeHint.isEmpty() ? "" : "；服务器状态=" + outcomeHint));
            cooldownUntil = 0;
            lastScan = 0;
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            return;
        }

        // Disappearance is NOT success. First look for positive DeliverThat evidence, including
        // short-lived Accessibility event text captured while the transaction was in flight.
        PageGuard.Page page = TapAccessibilityService.activePage();
        boolean successEvidence = TapAccessibilityService.hasAcceptSuccessEvidence()
                || TapAccessibilityService.isPositiveClaimOutcome(outcomeHint);
        ClaimConfirmation.Result confirmation = ClaimConfirmation.classify(false, page, successEvidence);
        if (confirmation == ClaimConfirmation.Result.CONFIRMED) {
            serialTopText = "";
            serialTopActionAt = 0;
            claimBudget.forget(id);
            report.accept("已确认接单成功：" + (outcomeHint.isEmpty() ? "DeliverThat显示Jobs/明确接单成功状态" : outcomeHint));
        } else if (missingChecks < 1) {
            // Give navigation/toast state one short chance to appear before classifying the loss.
            if (fastWorker != null)
                fastWorker.postDelayed(() -> inspectClaim(originalText, epoch,
                        disabledChecks, missingChecks + 1), 110);
            return;
        } else {
            serialTopText = "";
            serialTopActionAt = 0;
            claimBudget.forget(id);
            String suffix = outcomeHint.isEmpty() ? "" : "；捕获服务器提示=" + outcomeHint;
            report.accept(page == PageGuard.Page.OFFERS
                    ? "原卡片已从Offers消失，但未检测到Jobs/接单成功证据；结果未知（可能被其他司机抢走或服务器撤回）" + suffix
                    : "原卡片已消失且未检测到明确接单成功证据；结果未知，等待下一单" + suffix);
        }
        cooldownUntil = 0;
        lastScan = 0;
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    private int topCropTop() {
        return Math.max(0, Math.min(height - 2, Math.round(height * TOP_ROI_START)));
    }

    private int topCropBottom() {
        return Math.max(topCropTop() + 2, Math.min(height, Math.round(height * TOP_ROI_END)));
    }

    /**
     * Copy only [cropTop,cropBottom) rows from the RGBA ImageReader plane. This keeps the
     * source row stride/padding intact while avoiding a full-screen temporary bitmap.
     */
    private Bitmap imageToTopRoiBitmap(Image image, int cropTop, int cropBottom) {
        if (image == null || cropBottom <= cropTop) return null;
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer source = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        if (pixelStride <= 0 || rowStride <= 0) return null;
        int cropHeight = cropBottom - cropTop;
        int paddedWidth = rowStride / pixelStride;
        long startLong = (long) cropTop * rowStride;
        long bytesLong = (long) cropHeight * rowStride;
        if (startLong < 0 || bytesLong <= 0 || startLong + bytesLong > source.capacity()) return null;
        try {
            ByteBuffer rows = source.duplicate();
            rows.position((int) startLong);
            rows.limit((int) (startLong + bytesLong));
            rows = rows.slice();

            if (roiPaddedBuffer == null || roiPaddedBuffer.isRecycled()
                    || roiPaddedBuffer.getWidth() != paddedWidth
                    || roiPaddedBuffer.getHeight() != cropHeight) {
                if (roiPaddedBuffer != null && !roiPaddedBuffer.isRecycled()) roiPaddedBuffer.recycle();
                roiPaddedBuffer = Bitmap.createBitmap(paddedWidth, cropHeight, Bitmap.Config.ARGB_8888);
            }
            roiPaddedBuffer.copyPixelsFromBuffer(rows);
            if (paddedWidth == width) {
                roiExactBuffer = roiPaddedBuffer;
                return roiPaddedBuffer;
            }
            if (roiExactBuffer == null || roiExactBuffer == roiPaddedBuffer || roiExactBuffer.isRecycled()
                    || roiExactBuffer.getWidth() != width || roiExactBuffer.getHeight() != cropHeight) {
                if (roiExactBuffer != null && roiExactBuffer != roiPaddedBuffer && !roiExactBuffer.isRecycled())
                    roiExactBuffer.recycle();
                roiExactBuffer = Bitmap.createBitmap(width, cropHeight, Bitmap.Config.ARGB_8888);
            }
            Canvas canvas = new Canvas(roiExactBuffer);
            canvas.drawBitmap(roiPaddedBuffer,
                    new Rect(0, 0, width, cropHeight),
                    new Rect(0, 0, width, cropHeight), roiCopyPaint);
            return roiExactBuffer;
        } catch (RuntimeException | OutOfMemoryError failure) {
            return null;
        }
    }

    /** Warm ML Kit while the user is opening DeliverThat instead of on the first valuable offer. */
    private void warmRecognizer() {
        if (recognizer == null || worker == null) return;
        worker.post(() -> {
            Bitmap warm = null;
            try {
                warm = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888);
                warm.eraseColor(android.graphics.Color.WHITE);
                final Bitmap toRecycle = warm;
                recognizer.process(InputImage.fromBitmap(warm, 0))
                        .addOnCompleteListener(done -> toRecycle.recycle());
            } catch (RuntimeException | OutOfMemoryError ignored) {
                if (warm != null && !warm.isRecycled()) warm.recycle();
            }
        });
    }


    private void evaluate(Text result, long evidenceAt, Rect visualAccept) {
        PageGuard.Page active = TapAccessibilityService.recentPageHint();
        if (!monitorReady || SystemClock.elapsedRealtime() < cooldownUntil
                || !TapAccessibilityService.isDeliverThatForeground()
                || active == PageGuard.Page.JOBS || active == PageGuard.Page.IGNORED) return;
        // An older OCR completion must not reset a newer accessibility countdown/decision.
        if (lastReadableFastScan != 0 && SystemClock.elapsedRealtime() - lastReadableFastScan < 500) return;

        Rect semanticAccept = findButtonBounds(result, ACCEPT_WORDS);
        Rect semanticReject = findButtonBounds(result, IGNORE_WORDS);
        Rect acceptAnchor = semanticAccept == null ? null : new Rect(semanticAccept);
        boolean visualAcceptUsed = false;
        boolean acceptInferredFromReject = false;

        if (acceptAnchor == null && visualAccept != null && !visualAccept.isEmpty()) {
            acceptAnchor = new Rect(visualAccept);
            visualAcceptUsed = true;
        }
        if (acceptAnchor == null && semanticReject != null
                && ActionGeometry.plausibleLeftAction(width, semanticReject.exactCenterX())) {
            acceptAnchor = inferPairedAction(semanticReject, false);
            acceptInferredFromReject = acceptAnchor != null;
        }

        Rect cardAnchor = acceptAnchor != null ? acceptAnchor
                : (semanticReject == null ? null : new Rect(semanticReject));
        if (cardAnchor == null) {
            clearPendingIgnore();
            clearPendingAccept();
            String screenText = result == null ? "" : result.getText().toLowerCase(Locale.US);
            if ((screenText.contains("$") || MONEY.matcher(screenText).find())
                    && MILES.matcher(screenText).find()) {
                updateOfferStatus("OCR扫描：金额/里程已读到，但动作行仍无可靠锚点；未点击", result.getText());
            }
            return;
        }

        String cardText = textNearButton(result, cardAnchor);
        java.util.function.Consumer<String> report = offerReporter(cardText);
        if (!serialTopText.isEmpty() && !CardText.sameOffer(serialTopText, cardText)) {
            // v2.10.12: this OCR is restricted to the first-card ROI and requires a first-row
            // action anchor. If a different identity is now anchored there, the old serial
            // lock is stale and the new card has already moved into the top slot. Retire the
            // stale lock and continue THIS SAME frame instead of wasting a full scan cycle.
            // A lower card cannot reach this action row while the previous top card is still
            // visible, so the first-card isolation invariant remains intact.
            rejectSequence.forget(CardText.identity(serialTopText));
            serialTopText = "";
            serialTopActionAt = 0;
            report.accept("串行锁已确认换顶：当前订单已进入第一位；同帧继续判断，不再等待下一轮");
        }
        float amount = offerLowAmount(cardText);
        float miles = offerMiles(cardText);
        if (amount < 0 || miles < 0) {
            clearPendingIgnore();
            clearPendingAccept();
            report.accept("OCR信息不完整：不会点击Accept或Ignore");
            return;
        }

        // If Accessibility cannot classify the page, only a strong right-side action
        // anchor (semantic Accept or visual blue Accept) may authorize coordinate actions.
        // An inferred Accept from a lone Reject label is not enough on UNKNOWN.
        boolean strongAcceptEvidence = semanticAccept != null
                || (visualAccept != null && !visualAccept.isEmpty());
        if (active == PageGuard.Page.UNKNOWN && !strongAcceptEvidence) {
            clearPendingIgnore();
            clearPendingAccept();
            report.accept("页面仍UNKNOWN且没有独立Accept证据；未点击");
            return;
        }

        float minimum = prefs.getFloat("minPay", 25f);
        float maximumMiles = prefs.getFloat("maxMiles", 12f);
        boolean pasadena = cardText.toLowerCase(Locale.US).contains("pasadena");
        if (pasadena && prefs.getBoolean("pasadenaRuleEnabled", false)) {
            minimum = prefs.getFloat("pasadenaMinPay", 25f);
            maximumMiles = prefs.getFloat("pasadenaMaxMiles", 12f);
        }
        if (amount < minimum || miles > maximumMiles) {
            clearPendingAccept();
            handleIneligible(result, acceptAnchor, semanticReject, amount, miles,
                    pasadena && prefs.getBoolean("pasadenaRuleEnabled", false)
                            ? "Pasadena专属金额/里程不符合" : "普通金额/里程不符合",
                    evidenceAt);
            return;
        }
        boolean pasadenaSpecial = pasadena && prefs.getBoolean("pasadenaRuleEnabled", false);
        if (prefs.getBoolean("requireCity", true) && !pasadenaSpecial && !containsAllowedCity(cardText)) {
            clearPendingAccept();
            handleIneligible(result, acceptAnchor, semanticReject, amount, miles, "城市不符合", evidenceAt);
            return;
        }
        if (!offerTimeAllowed(cardText)) {
            clearPendingAccept();
            handleIneligible(result, acceptAnchor, semanticReject, amount, miles, "订单时间不符合", evidenceAt);
            return;
        }

        // Fire the human-facing alert before attempting to locate/click Accept. This is
        // intentionally independent from the automated action so a qualified order is
        // still surfaced when the click path fails.
        QualifiedOfferAlert.notifyIfNeeded(this, prefs, cardText, amount, miles);

        clearPendingIgnore();

        if (acceptAnchor == null) {
            clearPendingAccept();
            report.accept("规则符合，但仍无法可靠定位Accept动作行；未接单");
            return;
        }

        if (visualAcceptUsed) {
            report.accept(String.format(Locale.US,
                    "规则符合；Accessibility/OCR按钮文字缺失，使用蓝色Accept视觉锚点：$%.2f / %.1f mi",
                    amount, miles));
        } else if (acceptInferredFromReject) {
            report.accept(String.format(Locale.US,
                    "规则符合；由同排Reject位置镜像推定Accept：$%.2f / %.1f mi", amount, miles));
        }

        int cropTop = topCropTop();
        Rect fullAccept = new Rect(acceptAnchor);
        fullAccept.offset(0, cropTop);
        if (!ActionGeometry.plausibleActionRect(width, height,
                fullAccept.left, fullAccept.top, fullAccept.right, fullAccept.bottom, true)) {
            clearPendingAccept();
            report.accept("规则符合，但Accept热区几何异常（疑似整卡/容器）；未点击，等待重新定位");
            lastReadableFastScan = 0;
            return;
        }
        float x = ActionGeometry.stableTapX(width, fullAccept.exactCenterX(), true);
        float y = fullAccept.exactCenterY();
        if (prefs.getBoolean("dryRun", false)) {
            cooldownUntil = SystemClock.elapsedRealtime() + 5_000;
            report.accept(String.format(Locale.US, "测试通过：$%.2f / %.1f mi；未点击", amount, miles));
            playAlert();
            return;
        }
        if (claimBudget.reserve(CardText.identity(cardText), SystemClock.elapsedRealtime()) == 0) return;
        final long epoch = ++claimEpoch;
        serialTopText = cardText;
        serialTopActionAt = SystemClock.elapsedRealtime();
        cooldownUntil = SystemClock.elapsedRealtime() + 900;
        TapAccessibilityService.tapOcrOffer(x, y, amount, miles, evidenceAt, () -> {
                    report.accept(String.format(Locale.US,
                            "Accept点击已发送：OCR顶部按钮热区 Gesture55ms rect=[%d,%d,%d,%d] tap=(%d,%d) $%.2f / %.1f mi；非接单确认",
                            fullAccept.left, fullAccept.top, fullAccept.right, fullAccept.bottom,
                            Math.round(x), Math.round(y), amount, miles));
                    if (fastWorker != null)
                        fastWorker.postDelayed(() -> inspectClaim(cardText, epoch), 75);
                }, reason -> {
                    cooldownUntil = 0;
                    report.accept("Accept未执行：" + reason);
                    lastScan = 0;
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                });
    }

    private Rect inferPairedAction(Rect anchor, boolean inferLeft) {
        if (anchor == null || anchor.isEmpty()) return null;
        float x;
        if (inferLeft) {
            if (!ActionGeometry.plausibleRightAction(width, anchor.exactCenterX())) return null;
            x = ActionGeometry.inferredLeftActionX(width, anchor.exactCenterX());
        } else {
            if (!ActionGeometry.plausibleLeftAction(width, anchor.exactCenterX())) return null;
            x = ActionGeometry.inferredRightActionX(width, anchor.exactCenterX());
        }
        int halfW = Math.max(18, Math.min(60, anchor.width() / 2));
        int halfH = Math.max(12, Math.min(36, anchor.height() / 2));
        int cx = Math.round(x), cy = Math.round(anchor.exactCenterY());
        return new Rect(cx - halfW, cy - halfH, cx + halfW, cy + halfH);
    }

    private Rect findButtonBounds(Text result, String[] words) {
        return findButtonBounds(result, words, null);
    }

    private Rect findButtonBounds(Text result, String[] words, Rect sameRowAs) {
        if (result == null) return null;
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element element : line.getElements()) {
                    String value = element.getText().trim().toLowerCase(Locale.US)
                            .replaceAll("[^a-z0-9]", "");
                    for (String word : words) {
                        Rect box = element.getBoundingBox();
                        if (buttonWordMatches(value, word) && box != null && !box.isEmpty()
                                && (sameRowAs == null || ocrSameRow(box, sameRowAs))) return new Rect(box);
                    }
                }
                String lineText = line.getText().trim().toLowerCase(Locale.US);
                String lineValue = lineText.replaceAll("[^a-z0-9]", "");
                for (String word : words) {
                    boolean present = buttonWordMatches(lineValue, word)
                            || Pattern.compile("(^|[^a-z0-9])" + Pattern.quote(word)
                            + "([^a-z0-9]|$)").matcher(lineText).find();
                    if (present && line.getBoundingBox() != null) {
                        Rect box = new Rect(line.getBoundingBox());
                        int middle = (box.left + box.right) / 2;
                        if (words == ACCEPT_WORDS && (lineValue.contains("ignore")
                                || lineValue.contains("decline") || lineValue.contains("reject"))) box.left = middle;
                        if (words == IGNORE_WORDS && (lineValue.contains("accept")
                                || lineValue.contains("claim"))) box.right = middle;
                        if (!box.isEmpty() && (sameRowAs == null || ocrSameRow(box, sameRowAs))) return box;
                    }
                }
            }
        }
        return null;
    }

    private boolean ocrSameRow(Rect a, Rect b) {
        int tolerance = Math.max(14, Math.max(a.height(), b.height()));
        return Math.abs(a.centerY() - b.centerY()) <= tolerance;
    }

    private boolean buttonWordMatches(String value, String word) {
        if (value.equals(word)) return true;
        // Common Latin OCR substitutions on Android button labels.
        if (word.equals("ignore") && (value.equals("lgnore") || value.equals("ign0re"))) return true;
        if ((word.equals("accept") || word.equals("claim")
                || word.equals("decline") || word.equals("reject") || word.equals("ignore"))
                && value.length() >= 4 && oneEditOrLess(value, word)) return true;
        return false;
    }

    private boolean oneEditOrLess(String a, String b) {
        if (Math.abs(a.length() - b.length()) > 1) return false;
        int i = 0, j = 0, edits = 0;
        while (i < a.length() && j < b.length()) {
            if (a.charAt(i) == b.charAt(j)) {
                i++;
                j++;
                continue;
            }
            if (++edits > 1) return false;
            if (a.length() > b.length()) i++;
            else if (b.length() > a.length()) j++;
            else {
                i++;
                j++;
            }
        }
        if (i < a.length() || j < b.length()) edits++;
        return edits <= 1;
    }

    private void handleIneligible(Text result, Rect acceptAnchor, Rect semanticReject,
                                  float amount, float miles, String reason, long evidenceAt) {
        Rect reject = null;
        boolean inferredReject = false;

        if (semanticReject != null && !semanticReject.isEmpty()
                && (acceptAnchor == null || ocrSameRow(semanticReject, acceptAnchor))) {
            reject = new Rect(semanticReject);
        }
        if (reject == null && acceptAnchor != null) {
            Rect sameRow = findButtonBounds(result, IGNORE_WORDS, acceptAnchor);
            if (sameRow != null) reject = new Rect(sameRow);
        }
        if (reject == null && acceptAnchor != null) {
            reject = inferPairedAction(acceptAnchor, true);
            inferredReject = reject != null;
        }

        Rect cardAnchor = acceptAnchor != null ? acceptAnchor
                : (semanticReject == null ? reject : semanticReject);
        String cardText = textNearButton(result, cardAnchor);

        if (reject != null) {
            reject = new Rect(reject);
            reject.offset(0, topCropTop());
        }
        handleRejectedCard(cardText, reject, amount, miles, reason,
                false, evidenceAt, inferredReject);
    }

    private boolean handleFastRejection(TapAccessibilityService.FastOfferSnapshot snapshot,
                                        float amount, float miles, String reason) {
        if (snapshot.rejectBounds.isEmpty()) return false;
        if (!ActionGeometry.plausibleActionRect(width, height,
                snapshot.rejectBounds.left, snapshot.rejectBounds.top,
                snapshot.rejectBounds.right, snapshot.rejectBounds.bottom, false)) {
            offerReporter(snapshot.text).accept(
                    "Reject热区几何异常（疑似整卡/容器）；快速路径不点击，交给OCR重定位");
            lastReadableFastScan = 0;
            return false;
        }
        handleRejectedCard(snapshot.text, snapshot.rejectBounds, amount, miles, reason,
                true, 0L, false, snapshot);
        return true;
    }

    private void handleRejectedCard(String cardText, Rect reject, float amount, float miles,
                                    String reason, boolean fastSource, long evidenceAt,
                                    boolean inferredReject) {
        handleRejectedCard(cardText, reject, amount, miles, reason, fastSource, evidenceAt,
                inferredReject, null);
    }

    private void handleRejectedCard(String cardText, Rect reject, float amount, float miles,
                                    String reason, boolean fastSource, long evidenceAt,
                                    boolean inferredReject,
                                    TapAccessibilityService.FastOfferSnapshot fastSnapshot) {
        String fingerprint = CardText.identity(cardText);
        java.util.function.Consumer<String> report = offerReporter(cardText);
        if (!fingerprint.equals(lastLoggedIneligibleFingerprint)) {
            lastLoggedIneligibleFingerprint = fingerprint;
            appendIgnoredRecord(amount, miles, reason, cardText);
        }
        if (prefs.getBoolean("dryRun", false)) {
            clearPendingIgnore();
            report.accept(String.format(Locale.US, "测试未Ignore：$%.2f / %.1f mi，%s", amount, miles, reason));
            return;
        }
        if (!prefs.getBoolean("autoIgnore", true)) {
            clearPendingIgnore();
            report.accept(String.format(Locale.US, "未接：$%.2f / %.1f mi，%s", amount, miles, reason));
            return;
        }

        long now = SystemClock.elapsedRealtime();
        RejectSequence.State state = rejectSequence.observe(fingerprint, now);
        if (state == RejectSequence.State.HOLD) {
            report.accept("顶部订单拒绝已尝试3次仍可见；保持第一卡锁定，不处理下面订单");
            return;
        }
        if (state == RejectSequence.State.WAIT) return;

        if (reject == null || reject.isEmpty()) {
            report.accept("订单不符合，但动作行也无法从Accessibility/OCR/视觉几何定位；未点击");
            return;
        }
        if (!ActionGeometry.plausibleActionRect(width, height,
                reject.left, reject.top, reject.right, reject.bottom, false)) {
            report.accept("订单不符合，但Reject热区几何异常（疑似卡片/详情容器）；为防误点已取消");
            lastReadableFastScan = 0;
            return;
        }
        float x = ActionGeometry.stableTapX(width, reject.exactCenterX(), false);
        float y = reject.exactCenterY();
        cooldownUntil = now + 1_200;
        clearPendingIgnore();
        rejectSequence.sent(fingerprint, now);
        serialTopText = cardText;
        serialTopActionAt = now;
        accessibilityActionHoldUntil = now + 700;

        if (inferredReject) {
            report.accept(String.format(Locale.US,
                    "拒绝文字未识别；由同排Accept位置推定左侧Reject坐标：$%.2f / %.1f mi；帧龄%dms",
                    amount, miles, evidenceAt > 0 ? ScanPolicy.actionAge(SystemClock.elapsedRealtime(), evidenceAt) : -1));
        }

        Runnable completed = () -> {
            report.accept(String.format(Locale.US,
                    "顶部拒绝点击已发送：$%.2f / %.1f mi；等待本卡消失/倒计时结束", amount, miles));
            cooldownUntil = SystemClock.elapsedRealtime() + 420;
            if (fastWorker != null) {
                fastWorker.postDelayed(() -> {
                    if (!monitorReady) return;
                    lastScan = 0;
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                }, 450);
                fastWorker.postDelayed(() -> {
                    if (monitorReady) requestImmediateFastCheck(SystemClock.uptimeMillis());
                }, 980);
            }
        };
        java.util.function.Consumer<String> failed = failureReason -> {
            accessibilityActionHoldUntil = 0;
            cooldownUntil = 0;
            report.accept("拒绝未执行：" + failureReason);
            lastScan = 0;
            requestImmediateFastCheck(SystemClock.uptimeMillis());
        };

        if (fastSource) {
            // v2.10.9: use the SAME first-card snapshot that made the rule decision.
            // Do not perform findOffer() here: that is another full multi-window tree walk
            // and was adding hundreds of milliseconds before Ignore. tapSnapshotRejectFast
            // now performs its own bounded stale-snapshot refresh when necessary.
            if (fastSnapshot != null && !fastSnapshot.rejectBounds.isEmpty()) {
                TapAccessibilityService.tapSnapshotRejectFast(
                        fastSnapshot, amount, miles, completed, failed);
            } else {
                TapAccessibilityService.ignoreIfOfferStillMatches(
                        x, y, amount, miles, cardText, completed, failed);
            }
        } else {
            // v2.9.3 critical fix: OCR already found the Reject coordinate in the failing
            // screenshot, but v2.9.2 then required the same Reject to exist as an
            // Accessibility node and refused to click. Use the same fresh-coordinate
            // verified fallback as Accept instead.
            TapAccessibilityService.tapOcrReject(
                    x, y, amount, miles, evidenceAt, completed, failed);
        }
    }

    private void clearPendingIgnore() {
        pendingIgnoreFingerprint = "";
        pendingIgnoreSince = 0;
    }

    private void clearPendingAccept() {
        pendingAcceptFingerprint = "";
        pendingAcceptConfirmations = 0;
    }

    private void appendIgnoredRecord(float amount, float miles, String reason, String cardText) {
        String when = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date());
        String entry = String.format(Locale.US, "%s｜$%.2f / %.1f mi｜%s\n%s",
                when, amount, miles, reason, compactOfferText(cardText));
        String history = prefs.getString("ignoredHistory", "");
        history = history.isEmpty() ? entry : entry + "\n\n" + history;
        if (history.length() > 7000) history = history.substring(0, 7000);
        prefs.edit().putString("ignoredHistory", history).apply();
        updateOfferStatus("规则未通过：$" + String.format(Locale.US, "%.2f / %.1f mi，", amount, miles)
                + reason, cardText);
    }

    private String compactOfferText(String text) {
        if (text == null) return "";
        String clean = text.replaceAll("\\s+", " ").trim();
        return clean.length() > 360 ? clean.substring(0, 360) + "…" : clean;
    }

    private String textNearButton(Text result, Rect button) {
        if (button == null) return "";
        List<CardText.Piece> pieces = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                if (line.getBoundingBox() == null) continue;
                Rect box = line.getBoundingBox();
                pieces.add(new CardText.Piece(line.getText(), box.left, box.top, box.bottom));
            }
        }
        return CardText.aboveButton(pieces, button.top, button.bottom);
    }

    private float offerLowAmount(String text) {
        Matcher range = MONEY_RANGE.matcher(text.replace(',', '.'));
        if (range.find()) {
            try { return Float.parseFloat(range.group(1).replace(',', '.')); }
            catch (NumberFormatException ignored) { }
        }
        Matcher matcher = MONEY.matcher(text.replace(',', '.'));
        if (!matcher.find()) return -1f;
        try { return Float.parseFloat(matcher.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    private float offerMiles(String text) {
        Matcher matcher = MILES.matcher(text.replace(',', '.'));
        if (!matcher.find()) return -1f;
        try { return Float.parseFloat(matcher.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    private boolean containsAllowedCity(String text) {
        String lower = text.toLowerCase(Locale.US);
        String configuredValue = prefs.getString("cities", "").trim();
        // Blank means that city filtering is disabled.
        if (configuredValue.isEmpty()) return true;
        String[] configured = configuredValue.split(",");
        List<String> cities = new ArrayList<>();
        for (String city : configured) {
            String clean = city.trim().toLowerCase(Locale.US);
            if (!clean.isEmpty()) cities.add(clean);
        }
        if (cities.isEmpty()) return false;
        for (String city : cities) if (lower.contains(city)) return true;
        return false;
    }

    private boolean offerTimeAllowed(String text) {
        try {
            String configuredStart = prefs.getString("startTime", "").trim();
            String configuredEnd = prefs.getString("endTime", "").trim();
            // Blank/incomplete time fields mean that time filtering is disabled.
            if (configuredStart.isEmpty() || configuredEnd.isEmpty()) return true;
            Matcher matcher = OFFER_TIME.matcher(text);
            if (!matcher.find()) return false;
            DateTimeFormatter offerFormat = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
            LocalTime offer = LocalTime.parse(
                    matcher.group(1) + " " + matcher.group(2).toUpperCase(Locale.US), offerFormat);
            DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
            LocalTime start = LocalTime.parse(configuredStart, f);
            LocalTime end = LocalTime.parse(configuredEnd, f);
            if (end.isAfter(start) || end.equals(start)) return !offer.isBefore(start) && !offer.isAfter(end);
            return !offer.isBefore(start) || !offer.isAfter(end);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void playAlert() {
        try {
            AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION,
                    audio.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION), 0);
            Ringtone tone = RingtoneManager.getRingtone(this,
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            tone.play();
        } catch (Exception ignored) { }
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL,
                "OCR monitor", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private Notification statusNotification(String status) {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String expanded = status;
        if (expanded.length() > 3500) expanded = expanded.substring(0, 3500);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Catering Screen Assistant")
                .setContentText(status)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(expanded))
                .setOngoing(true)
                .setContentIntent(open)
                .build();
    }

    private void updateStatus(String status) {
        logWriter.execute(() -> writeStatus(status));
    }

    private void writeStatus(String status) {
        if (!monitorReady && activeInstance != this) return;
        if (status.equals(prefs.getString("lastStatus", ""))) return;
        prefs.edit()
                .putString("lastStatus", status)
                .putLong("lastStatusAt", System.currentTimeMillis())
                .apply();
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, statusNotification(status));
    }

    private String lastEventKey = "";
    private java.util.function.Consumer<String> offerReporter(String cardText) {
        final String rules = ruleSummary();
        final String timing = scanTiming;
        final long started = SystemClock.elapsedRealtime();
        return message -> updateOfferStatus(message + "\n本次处理：" + timing + "；判断至记录"
                + (SystemClock.elapsedRealtime() - started) + "ms", cardText, rules);
    }

    private String ruleSummary() {
        return "普通≥$" + prefs.getFloat("minPay",25f) + " / ≤" + prefs.getFloat("maxMiles",12f)
                + "mi；Pasadena启用=" + prefs.getBoolean("pasadenaRuleEnabled",false)
                + " ≥$" + prefs.getFloat("pasadenaMinPay",25f) + " / ≤" + prefs.getFloat("pasadenaMaxMiles",12f)
                + "mi；城市=" + prefs.getString("cities", "") + "；时间=" + prefs.getString("startTime", "")
                + "–" + prefs.getString("endTime", "");
    }

    private void updateOfferStatus(String status, String cardText) {
        updateOfferStatus(status, cardText, ruleSummary());
    }

    private synchronized void updateOfferStatus(String status, String cardText, String rules) {
        if (!isMonitoring()) return;
        String identity = CardText.identity(cardText);
        String eventKey = identity + "|" + status.split("\\n本次处理：", 2)[0];
        if (eventKey.equals(lastEventKey)) return;
        lastEventKey = eventKey;
        String id = Integer.toHexString(identity.hashCode());
        String event = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(new Date())
                + "｜卡片#" + id + "\n" + status + "\n本次卡片：" + cardText
                + "\n本次规则：" + rules;
        logWriter.execute(() -> {
        if (!monitorReady) return;
        try {
            org.json.JSONArray history = new org.json.JSONArray(prefs.getString("decisionEvents", "[]"));
            org.json.JSONArray next = new org.json.JSONArray();
            next.put(event);
            for (int i = 0; i < Math.min(99, history.length()); i++) next.put(history.getString(i));
            prefs.edit().putString("decisionEvents", next.toString()).putString("lastDecision", event).apply();
        } catch (org.json.JSONException ignored) {
            prefs.edit().putString("lastDecision", event).apply();
        }
        writeStatus(event);
        });
    }

    @Override
    public void onDestroy() {
        monitorReady = false;
        if (worker != null) worker.removeCallbacksAndMessages(null);
        if (fastWorker != null) fastWorker.removeCallbacksAndMessages(null);
        if (activeInstance == this) activeInstance = null;
        if (virtualDisplay != null) virtualDisplay.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (recognizer != null) recognizer.close();
        if (roiPaddedBuffer != null && !roiPaddedBuffer.isRecycled()) roiPaddedBuffer.recycle();
        if (roiExactBuffer != null && roiExactBuffer != roiPaddedBuffer && !roiExactBuffer.isRecycled()) roiExactBuffer.recycle();
        roiPaddedBuffer = null;
        roiExactBuffer = null;
        if (workerThread != null) workerThread.quitSafely();
        if (fastThread != null) fastThread.quitSafely();
        logWriter.shutdownNow();
        super.onDestroy();
    }
}
