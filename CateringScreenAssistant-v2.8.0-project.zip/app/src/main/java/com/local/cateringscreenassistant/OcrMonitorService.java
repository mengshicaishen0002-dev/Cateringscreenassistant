package com.local.cateringscreenassistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.hardware.display.VirtualDisplay;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.text.DateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OcrMonitorService extends Service {
    private static final String CHANNEL = "ocr_monitor";
    private static final int NOTIFICATION_ID = 41;
    private static final Pattern MONEY_RANGE = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)\\s*[-–—]\\s*\\$?(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY = Pattern.compile("(?:\\$|USD\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MILES = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern OFFER_TIME = Pattern.compile("(?:today|tomorrow)\\s*(?:at)?\\s*(\\d{1,2}:\\d{2})\\s*(am|pm)", Pattern.CASE_INSENSITIVE);
    private static final String[] ACCEPT_WORDS = {"accept", "claim"};
    private static final String[] IGNORE_WORDS = {"ignore", "decline", "reject"};
    private static volatile OcrMonitorService activeInstance;
    // v2.10.6 Galaxy A15 speed profile: the first DeliverThat card lives roughly in
    // the middle third of the screen. Keep a little safety margin but stop copying/OCRing
    // the navigation bar and lower cards.
    private static final float TOP_ROI_START = 0.20f;
    private static final float TOP_ROI_END = 0.58f;
    private static final int DEFAULT_SCAN_INTERVAL_MS = 80;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private HandlerThread workerThread;
    private Handler worker;
    // Keep Accessibility decisions on their own high-priority queue so a heavy OCR frame
    // cannot delay an offer click. This is the primary low-latency path.
    private HandlerThread fastThread;
    private Handler fastWorker;
    private final java.util.concurrent.ThreadPoolExecutor logWriter = new java.util.concurrent.ThreadPoolExecutor(
            1, 1, 0L, java.util.concurrent.TimeUnit.MILLISECONDS,
            new java.util.concurrent.ArrayBlockingQueue<Runnable>(256),
            new java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy());
    private TextRecognizer recognizer;
    private final AtomicBoolean ocrBusy = new AtomicBoolean(false);
    private long lastScan;
    private volatile long lastReadableFastScan;
    private volatile String scanTiming = "";
    private volatile long cooldownUntil;
    private long pendingIgnoreSince;
    private String pendingIgnoreFingerprint = "";
    private String pendingAcceptFingerprint = "";
    private String lastLoggedIneligibleFingerprint = "";
    private int pendingAcceptConfirmations;
    private int width;
    private int height;
    private int density;
    private SharedPreferences prefs;
    private volatile boolean monitorReady;
    private int[] visualScanPixels;
    // v2.10.9: reuse ROI bitmaps across frames. ML Kit allows only one OCR task here
    // (ocrBusy gate), so pooled buffers are safe and avoid repeated 720x600 allocations/GC.
    private Bitmap roiPaddedBuffer;
    private Bitmap roiExactBuffer;
    private final Paint roiCopyPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    // While an Accessibility decision/gesture is in flight, do not start a competing ML Kit
    // frame. This protects the time-critical first tap from CPU/Binder contention.
    private volatile long accessibilityActionHoldUntil;
    private final AtomicBoolean fastCheckQueued = new AtomicBoolean(false);
    private final AtomicBoolean fastCheckDirty = new AtomicBoolean(false);
    public static boolean isMonitoring() {
        OcrMonitorService current = activeInstance;
        return current != null && current.monitorReady;
    }
    /** Start time of the currently unresolved Accept transaction; 0 when none. */
    public static long pendingClaimSince() {
        OcrMonitorService current = activeInstance;
        return current == null || current.serialTopAction != SerialAction.ACCEPT
                ? 0L : current.serialTopActionAt;
    }
    private enum SerialAction { NONE, ACCEPT, REJECT }
    private final AtomicLong claimEpoch = new AtomicLong();
    // Serial first-card transaction. Accept and Reject must never share post-action
    // confirmation semantics: Jobs/detail signals belong only to Accept.
    private volatile String serialTopText = "";
    private volatile long serialTopActionAt;
    private volatile SerialAction serialTopAction = SerialAction.NONE;
    private volatile long rejectProcessingConfirmedAt;
    // v2.10.26: after the first coherent scan proves Accept is disabled/processing,
    // cached Accessibility outcome events own the short wait. This avoids repeated 400-800ms
    // tree walks while DeliverThat is already processing the same claim.
    private volatile long acceptProcessingConfirmedAt;
    // v2.10.23: capture the pre-claim Jobs badge without putting another tree walk in front
    // of the tap. Existing page scans keep this cache warm.
    private volatile int pendingAcceptJobsBaseline = -1;
    // v2.10.13 action-stall watchdog. A transaction-level cooldown must never starve
    // screen capture long enough to hide a newly arrived top offer. We therefore allow
    // sparse rescue OCR probes and require two stable first-card observations before
    // retiring an old serial lock.
    private volatile long lastActionDispatchAt;
    private volatile long lastWatchdogProbeAt;
    private volatile long lastStallRecoveryAt;
    private volatile String observedTopIdentity = "";
    private volatile long observedTopSince;
    private volatile int observedTopFrames;
    // v2.10.14: when OCR sees a different first card while an old serial transaction is
    // still present, force the very next available frame instead of waiting for the normal
    // scan/cooldown cadence. Accessibility consensus can confirm the switch immediately.
    private volatile String urgentTransitionIdentity = "";
    private volatile long urgentTransitionUntil;
    // A server-terminal loss such as "offer unavailable" must never trigger local retries.
    // Keep the top card locked until it disappears, but suppress new Accept attempts briefly.
    private volatile String terminalLossIdentity = "";
    private volatile long terminalLossUntil;
    // v2.10.15: short post-Reject transition window. DeliverThat briefly emits partial/blank
    // OCR frames while the first card is animating/entering countdown; suppress those noisy
    // card#0 records without weakening the top-card lock or Accept path.
    private volatile long rejectTransitionSuppressUntil;
    private final ClaimBudget claimBudget = new ClaimBudget();
    private final RejectSequence rejectSequence = RejectSequence.shared();
    private final Runnable continuousCheck = new Runnable() {
        @Override public void run() {
            if (!monitorReady || fastWorker == null) return;
            requestImmediateFastCheck(SystemClock.uptimeMillis());
            // Event-driven scans remain immediate. A full DeliverThat accessibility tree walk
            // on this Samsung can take 400-800 ms, so a 90 ms heartbeat made the fast thread
            // run back-to-back forever and stole time from the OCR action path. Keep only a
            // low-rate safety heartbeat; content-change events still wake us immediately.
            fastWorker.postDelayed(this, 900);
        }
    };

    public static void requestImmediateFastCheck(long eventTime) {
        OcrMonitorService service = activeInstance;
        if (service == null || !service.monitorReady || service.fastWorker == null) return;
        if (!service.fastCheckQueued.compareAndSet(false, true)) {
            service.fastCheckDirty.set(true);
            return;
        }
        final long queuedAt = SystemClock.elapsedRealtime();
        service.fastWorker.post(() -> {
            try {
            long now = SystemClock.elapsedRealtime();

            // v2.10.25: an already-dispatched top-card transaction owns the lane before any
            // cooldown/page/index work. This also catches the race where OCR starts a transaction
            // while a previously queued Accessibility runnable is already executing.
            if (service.handlePendingSerialFast(now)) return;
            if (now < service.cooldownUntil) return;

            // v2.10.22: qualified offers get an even cheaper Accept-index path first.
            // Android can jump directly to the semantic Accept/Claim label; if a card-level
            // ancestor already exposes pay+miles+address, do not walk ~130 React-Native nodes
            // before sending the first claim gesture. Any ambiguity falls through unchanged.
            long indexedStarted = SystemClock.elapsedRealtime();
            TapAccessibilityService.FastOfferSnapshot indexed =
                    TapAccessibilityService.getIndexedTopAcceptSnapshot(
                            service.decisionNeedsLocationEvidence(),
                            service.decisionNeedsOfferTimeEvidence());
            long indexedMs = SystemClock.elapsedRealtime() - indexedStarted;
            // OCR may have dispatched Accept/Reject while the indexed lookup was running.
            if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
            if (indexed != null && service.quickDecisionTextComplete(indexed)) {
                String indexedTop = indexed.text;
                if (!service.serialTopText.isEmpty()
                        && !CardText.sameOffer(service.serialTopText, indexedTop))
                    service.retireStaleSerialLock(indexedTop, "Accept索引确认换顶", null);
                String indexedFailure = service.fastRuleFailure(indexed);
                float indexedAmount = indexed.amount;
                float indexedMiles = indexed.miles;
                if (indexedFailure.isEmpty()) {
                    String indexedId = indexed.identity;
                    boolean indexedActionable = !indexed.acceptBounds.isEmpty()
                            && indexed.acceptEnabled
                            && !service.isTerminalLossSuppressed(indexedId, SystemClock.elapsedRealtime())
                            && service.claimBudget.available(indexedId, SystemClock.elapsedRealtime());
                    if (indexedActionable) {
                        service.scanTiming = "排队" + (now - queuedAt) + "ms；Accept索引"
                                + indexedMs + "ms；合格首卡直达";
                        boolean actionDispatched = service.tryFastAccept(indexed);
                        service.lastReadableFastScan = actionDispatched
                                ? SystemClock.elapsedRealtime() : 0;
                        // Do not construct/post a high-priority notification before the claim
                        // gesture is queued. The user wants the button action to win the race.
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, indexed.text,
                                indexedAmount, indexedMiles);
                        if (actionDispatched) return;
                    } else {
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, indexed.text,
                                indexedAmount, indexedMiles);
                        if (service.accessibilityOwnsDecision(indexed, indexedFailure)) {
                            service.holdAccessibilityDecision(indexed, indexedFailure, "Accept索引");
                            return;
                        }
                    }
                } else if (service.prefs.getBoolean("autoIgnore", true)) {
                    // v2.10.22: most rejected cards also expose a semantic Ignore/Reject index.
                    // Use it before walking ~130 nodes, but require the exact same physical offer.
                    long rejectIndexedStarted = SystemClock.elapsedRealtime();
                    TapAccessibilityService.FastOfferSnapshot indexedReject =
                            TapAccessibilityService.getIndexedTopRejectSnapshot(
                                    service.decisionNeedsLocationEvidence(),
                                    service.decisionNeedsOfferTimeEvidence());
                    long rejectIndexedMs = SystemClock.elapsedRealtime() - rejectIndexedStarted;
                    if (indexedReject != null
                            && service.quickDecisionTextComplete(indexedReject)
                            && CardText.sameOffer(indexed.text, indexedReject.text)) {
                        RejectSequence.State indexedRejectState = service.rejectSequence.observe(
                                indexedReject.identity, SystemClock.elapsedRealtime());
                        if (!indexedReject.rejectBounds.isEmpty()
                                && indexedReject.rejectEnabled
                                && indexedRejectState == RejectSequence.State.READY) {
                            service.scanTiming = "排队" + (now - queuedAt) + "ms；Accept索引"
                                    + indexedMs + "ms；Reject索引" + rejectIndexedMs + "ms；首卡直达";
                            boolean actionDispatched = service.tryFastAccept(indexedReject);
                            service.lastReadableFastScan = actionDispatched
                                    ? SystemClock.elapsedRealtime() : 0;
                            if (actionDispatched) return;
                        }
                        if (service.accessibilityOwnsDecision(indexedReject, indexedFailure)) {
                            service.holdAccessibilityDecision(indexedReject, indexedFailure, "Reject索引");
                            return;
                        }
                    }
                }
            }

            // Existing bounded active-window path remains the fallback for Reject, blank-label
            // controls, or any indexed Accept whose ancestor text was incomplete.
            long quickStarted = SystemClock.elapsedRealtime();
            TapAccessibilityService.FastOfferSnapshot quick = TapAccessibilityService.getQuickTopOfferSnapshot();
            long quickMs = SystemClock.elapsedRealtime() - quickStarted;
            // Same in-flight race guard after the bounded tree read.
            if (service.handlePendingSerialFast(SystemClock.elapsedRealtime())) return;
            if (quick != null && service.quickDecisionTextComplete(quick)) {
                String quickTop = quick.text;
                if (!service.serialTopText.isEmpty()) {
                    if (!CardText.sameOffer(service.serialTopText, quickTop))
                        service.retireStaleSerialLock(quickTop, "快速树确认换顶", null);
                }
                String quickFailure = service.fastRuleFailure(quick);
                float quickAlertAmount = quick.amount;
                float quickAlertMiles = quick.miles;
                boolean quickActionable = quickFailure.isEmpty()
                        ? (!quick.acceptBounds.isEmpty() && quick.acceptEnabled
                        && !service.isTerminalLossSuppressed(quick.identity, SystemClock.elapsedRealtime())
                        && service.claimBudget.available(quick.identity, SystemClock.elapsedRealtime()))
                        : (service.prefs.getBoolean("autoIgnore", true) && !quick.rejectBounds.isEmpty()
                        && quick.rejectEnabled
                        && service.rejectSequence.observe(quick.identity,
                        SystemClock.elapsedRealtime()) == RejectSequence.State.READY);
                if (quickActionable) {
                    service.scanTiming = "排队" + (now - queuedAt) + "ms；Accept索引" + indexedMs
                            + "ms；快速树" + quickMs + "ms；首卡直达";
                    boolean actionDispatched = service.tryFastAccept(quick);
                    service.lastReadableFastScan = actionDispatched ? SystemClock.elapsedRealtime() : 0;
                    if (quickFailure.isEmpty())
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, quick.text,
                                quickAlertAmount, quickAlertMiles);
                    if (actionDispatched) return;
                } else {
                    if (quickFailure.isEmpty())
                        QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, quick.text,
                                quickAlertAmount, quickAlertMiles);
                    if (service.accessibilityOwnsDecision(quick, quickFailure)) {
                        service.holdAccessibilityDecision(quick, quickFailure, "快速树");
                        return;
                    }
                }
            }

            long fullStarted = SystemClock.elapsedRealtime();
            List<TapAccessibilityService.FastOfferSnapshot> cards = TapAccessibilityService.getFastOfferSnapshots();
            service.scanTiming = "排队" + (now - queuedAt) + "ms；Accept索引" + indexedMs
                    + "ms；快速树" + quickMs + "ms；完整树" + (SystemClock.elapsedRealtime() - fullStarted)
                    + "ms；可读卡片" + cards.size();
            // v2.10.14: do not traverse the full Accessibility hierarchy twice. The first
            // snapshot was already built from a single coherent WindowScan and its first card
            // is the authoritative visible top. Only use the text-only fallback when that scan
            // could not build any actionable card while a serial lock still exists.
            String visibleTop = !cards.isEmpty() ? cards.get(0).text
                    : (!service.serialTopText.isEmpty()
                    ? TapAccessibilityService.getTopVisibleOfferText() : "");
            if (!service.serialTopText.isEmpty()) {
                if (!visibleTop.isEmpty() && CardText.sameOffer(service.serialTopText, visibleTop)) {
                    // Keep processing/waiting only for the same top card. Lower cards must not
                    // steal its button coordinates during Ignore countdown/transition states.
                } else if (!visibleTop.isEmpty()) {
                    service.retireStaleSerialLock(visibleTop, "Accessibility确认换顶", null);
                } else {
                    // Do not unlock from an empty Accessibility read alone, but also do not let
                    // that blind spot starve OCR forever. Once the original action is old enough,
                    // release only transient blockers so the rescue OCR probe can identify the
                    // actual first card and safely reconcile the serial lock.
                    long actionAge = service.serialTopActionAt > 0 ? now - service.serialTopActionAt : Long.MAX_VALUE;
                    if (actionAge >= ActionStallPolicy.rescueArmMs()) {
                        service.lastReadableFastScan = 0;
                        if (actionAge >= ActionStallPolicy.hardHoldMs()) {
                            service.cooldownUntil = 0;
                            service.accessibilityActionHoldUntil = 0;
                        }
                        service.updateStatus("顶部锁定订单Accessibility暂不可读；已启用OCR恢复探测，不会处理下面订单");
                    } else {
                        service.updateStatus("顶部订单处理中/倒计时；未确认原卡消失，继续锁定第一张");
                    }
                    return;
                }
            }
            TapAccessibilityService.FastOfferSnapshot selected = OfferPriority.choose(cards,
                    card -> service.fastRuleFailure(card).isEmpty(),
                    card -> !card.acceptBounds.isEmpty()
                            && card.acceptEnabled
                            && !service.isTerminalLossSuppressed(card.identity, SystemClock.elapsedRealtime())
                            && service.claimBudget.available(card.identity, SystemClock.elapsedRealtime()),
                    card -> service.prefs.getBoolean("autoIgnore", true) && !card.rejectBounds.isEmpty()
                            && card.rejectEnabled
                            && service.rejectSequence.observe(card.identity,
                            SystemClock.elapsedRealtime()) == RejectSequence.State.READY);
            if (selected != null) {
                boolean qualified = service.fastRuleFailure(selected).isEmpty();
                float alertAmount = qualified ? selected.amount : -1f;
                float alertMiles = qualified ? selected.miles : -1f;
                boolean actionDispatched = service.tryFastAccept(selected);
                service.lastReadableFastScan = actionDispatched ? SystemClock.elapsedRealtime() : 0;
                if (qualified)
                    QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, selected.text,
                            alertAmount, alertMiles);
            } else if (!cards.isEmpty()) {
                // If a qualified card is visible but its action node is temporarily unavailable,
                // still alert the driver; there is no automated dispatch to delay in this branch.
                TapAccessibilityService.FastOfferSnapshot top = cards.get(0);
                String topFailure = service.fastRuleFailure(top);
                if (topFailure.isEmpty())
                    QualifiedOfferAlert.notifyIfNeeded(service, service.prefs, top.text,
                            top.amount, top.miles);
                // v2.10.26: if Accessibility already has all decision fields AND the exact
                // side-specific action rectangle, OCR cannot improve a disabled/processing or
                // retry-gated state. Keep OCR as fallback only for genuinely missing evidence.
                if (service.accessibilityOwnsDecision(top, topFailure)) {
                    service.holdAccessibilityDecision(top, topFailure, "完整树");
                } else {
                    service.lastReadableFastScan = 0;
                    service.updateStatus("页面：OFFERS｜发现" + cards.size()
                            + "张卡片但辅助功能动作证据不完整；OCR兜底已激活");
                }
            } else {
                service.lastReadableFastScan = 0;
                PageGuard.Page page = TapAccessibilityService.activePage();
                String treeDebug = TapAccessibilityService.debugTreeSummary();
                if (page == PageGuard.Page.OFFERS)
                    service.updateStatus("页面：OFFERS｜监控中；当前无可读订单｜" + treeDebug);
                else
                    service.updateStatus("页面：" + page + "｜仅监控Offers；未点击｜" + treeDebug
                            + "（历史事件请在应用内查看）");
            }
            } finally {
                service.fastCheckQueued.set(false);
                if (service.fastCheckDirty.getAndSet(false) && service.monitorReady)
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
            }
        });
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        activeInstance = this;
        prefs = getSharedPreferences("rules", MODE_PRIVATE);
        // One-time upgrade from the old 140 ms default. Preserve any non-default value the
        // user chose manually, but move untouched installs to the lower-latency profile.
        if (!prefs.getBoolean("v2106SpeedProfileApplied", false)) {
            SharedPreferences.Editor migration = prefs.edit().putBoolean("v2106SpeedProfileApplied", true);
            if (prefs.getInt("interval", 140) == 140) migration.putInt("interval", DEFAULT_SCAN_INTERVAL_MS);
            migration.apply();
        }
        createChannel();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        workerThread = new HandlerThread("screen-ocr", android.os.Process.THREAD_PRIORITY_DISPLAY);
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        fastThread = new HandlerThread("offer-fast", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY);
        fastThread.start();
        fastWorker = new Handler(fastThread.getLooper());
        warmRecognizer();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !intent.hasExtra("resultData")) return START_NOT_STICKY;
        if (monitorReady) {
            updateStatus("监控已运行；规则已更新，请返回Offers页面");
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, statusNotification(String.format(Locale.US,
                "等待画面｜生效规则：最低$%.2f / 最高%.1f mi",
                prefs.getFloat("minPay", 25f), prefs.getFloat("maxMiles", 12f))));

        int resultCode = intent.getIntExtra("resultCode", 0);
        Intent resultData = intent.getParcelableExtra("resultData");
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(resultCode, resultData);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, worker);

        DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
        width = dm.widthPixels;
        height = dm.heightPixels;
        density = dm.densityDpi;
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        virtualDisplay = projection.createVirtualDisplay("ocr-capture", width, height, density,
                0, reader.getSurface(), null, worker);
        reader.setOnImageAvailableListener(this::onFrame, worker);
        monitorReady = true;
        fastWorker.removeCallbacks(continuousCheck);
        fastWorker.post(continuousCheck);
        return START_NOT_STICKY;
    }

    private void onFrame(ImageReader imageReader) {
        Image image = imageReader.acquireLatestImage();
        if (image == null) return;
        int interval = prefs.getInt("interval", DEFAULT_SCAN_INTERVAL_MS);
        long now = SystemClock.elapsedRealtime();
        // Frame callbacks can arrive at display refresh rate. Normally cooldown/action-hold
        // suppress OCR, but v2.10.13 permits a sparse rescue probe while a transaction is
        // blocking. Without this, an old serial lock plus an unreadable Accessibility top row
        // could suppress every new frame and leave a visible offer untouched indefinitely.
        boolean actionBlocked = now < cooldownUntil || now < accessibilityActionHoldUntil;
        long actionAge = serialTopActionAt <= 0 ? Long.MAX_VALUE : Math.max(0L, now - serialTopActionAt);
        boolean rescueProbe = ActionStallPolicy.shouldProbe(
                actionBlocked, prefs.getBoolean("dryRun", false), ocrBusy.get(),
                now - lastWatchdogProbeAt, actionAge);
        if (!urgentTransitionIdentity.isEmpty() && now > urgentTransitionUntil) {
            urgentTransitionIdentity = "";
            urgentTransitionUntil = 0;
        }
        boolean urgentTransitionProbe = !urgentTransitionIdentity.isEmpty()
                && now <= urgentTransitionUntil && !ocrBusy.get();
        boolean normalOcrDue = ScanPolicy.needsOcr(now, lastScan, lastReadableFastScan, interval, ocrBusy.get());
        if (!monitorReady || (!rescueProbe && !urgentTransitionProbe
                && (actionBlocked || !normalOcrDue))) {
            image.close();
            return;
        }
        if (rescueProbe) lastWatchdogProbeAt = now;
        PageGuard.Page active = TapAccessibilityService.recentPageHint();
        // v2.10.19: do not let a stale Accessibility tab hint suppress screen capture.
        // The field miss at 10:30 showed a complete visible offer with no decision record.
        // Capture whenever DeliverThat is actually the active root; evaluate() will require
        // independent OCR/visual offer evidence before overriding a Jobs/Ignored hint.
        if (!TapAccessibilityService.isDeliverThatForeground()) {
            lastScan = now;
            image.close();
            return;
        }
        lastScan = now;
        final long frameStarted = now;
        int cropTop = topCropTop();
        int cropBottom = topCropBottom();
        // v2.10.6: copy only the first-card rows directly from the ImageReader plane.
        // v2.10.5 first allocated/copied a full 720x1600 bitmap and then cropped it, which
        // wasted memory bandwidth before ML Kit even started.
        Bitmap roi = imageToTopRoiBitmap(image, cropTop, cropBottom);
        image.close();
        if (roi == null) return;
        final long roiReadyAt = SystemClock.elapsedRealtime();
        ocrBusy.set(true);
        // Start ML Kit first, then scan the visual Accept band while recognition runs on its
        // own executor. The bitmap is read-only until the task completes, so these two reads
        // can overlap instead of serializing visual-button detection before OCR.
        Task<Text> task = recognizer.process(InputImage.fromBitmap(roi, 0));
        // DeliverThat's filled blue Accept button is visually stable even on builds that
        // expose neither button label to Accessibility nor readable button text to ML Kit.
        final Rect visualAccept = findVisualAcceptButton(roi);
        final AtomicBoolean enhancedStarted = new AtomicBoolean(false);
        task.addOnSuccessListener(result -> {
                    if (worker != null) worker.post(() -> {
                        if (!monitorReady || !ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) return;
                        long decidedAt = SystemClock.elapsedRealtime();
                        scanTiming = "首卡ROI复制" + (roiReadyAt - frameStarted) + "ms；OCR"
                                + (decidedAt - roiReadyAt) + "ms；总" + (decidedAt - frameStarted) + "ms";
                        evaluate(result, frameStarted, visualAccept);
                    });
                    // Borrow the useful idea from high-contrast OCR pipelines, but only as a
                    // fallback. The normal path stays raw/fast; we pay this cost only when an
                    // offer-looking frame has money+miles but the action labels were missed.
                    if (needsEnhancedOcr(result, visualAccept) && ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) {
                        Bitmap enhanced = enhanceForOcr(roi);
                        if (enhanced != null) {
                            try {
                                enhancedStarted.set(true);
                                recognizer.process(InputImage.fromBitmap(enhanced, 0))
                                        .addOnSuccessListener(second -> {
                                            if (worker != null) worker.post(() -> {
                                                if (!monitorReady || !ScanPolicy.actionFresh(SystemClock.elapsedRealtime(), frameStarted)) return;
                                                scanTiming = "增强OCR帧至判断"
                                                        + (SystemClock.elapsedRealtime() - frameStarted) + "ms";
                                                evaluate(second, frameStarted, visualAccept);
                                            });
                                        })
                                        .addOnCompleteListener(done2 -> {
                                            enhanced.recycle();
                                            ocrBusy.set(false);
                                        });
                            } catch (RuntimeException startFailure) {
                                enhancedStarted.set(false);
                                enhanced.recycle();
                            }
                        }
                    }
                })
                .addOnCompleteListener(done -> {
                    // roi is a pooled reusable buffer in v2.10.9; do not recycle per frame.
                    if (!enhancedStarted.get()) ocrBusy.set(false);
                });
    }

    private boolean needsEnhancedOcr(Text result, Rect visualAccept) {
        String text = result == null ? "" : result.getText().toLowerCase(Locale.US);
        boolean hasMoney = text.contains("$") || MONEY.matcher(text).find();
        boolean hasMiles = MILES.matcher(text).find();
        // v2.10.19: a visible blue Accept is itself strong offer evidence. If raw ML Kit
        // misses BOTH numeric fields, retry enhanced OCR instead of silently giving up.
        if (!hasMoney && !hasMiles) return visualAccept != null && !visualAccept.isEmpty();
        // One missing numeric field is worth a high-contrast retry.
        if (!hasMoney || !hasMiles) return true;
        // v2.9.3: do not spend another ~300-700 ms merely because one button word
        // was missed. A visual Accept anchor or either action label is enough to infer
        // the paired action row safely on a fresh frame.
        if (visualAccept != null && !visualAccept.isEmpty()) return false;
        if (findButtonBounds(result, ACCEPT_WORDS) != null) return false;
        if (findButtonBounds(result, IGNORE_WORDS) != null) return false;
        return true;
    }

    /**
     * Conservative visual fallback for DeliverThat's filled blue Accept button.
     * We intentionally look only in the lower/right part of the Offers ROI and require
     * a wide, short, dense cyan/blue rectangle. This avoids the selected Offers tab and
     * small navigation/status icons. Coordinates are ROI-local, matching ML Kit boxes.
     */
    private Rect findVisualAcceptButton(Bitmap source) {
        if (source == null) return null;
        final int w = source.getWidth(), h = source.getHeight();
        if (w < 240 || h < 400) return null;
        final int xStart = Math.round(w * 0.51f);
        final int yStart = Math.round(h * 0.55f);
        final int yEnd = Math.round(h * 0.94f);
        final int bandHeight = Math.max(1, yEnd - yStart);
        final int needed = w * bandHeight;
        try {
            if (visualScanPixels == null || visualScanPixels.length < needed)
                visualScanPixels = new int[needed];
            source.getPixels(visualScanPixels, 0, w, 0, yStart, w, bandHeight);
        } catch (RuntimeException | OutOfMemoryError failure) {
            return null;
        }
        final int stepY = 2;
        Rect current = null;
        Rect best = null;
        int bestArea = 0;
        int gapRows = 0;
        for (int y = yStart; y < yEnd; y += stepY) {
            int runStart = -1, runEnd = -1, bestRunStart = -1, bestRunEnd = -1;
            int toleratedGap = 0;
            for (int x = xStart; x < w - 4; x += 2) {
                int c = visualScanPixels[(y - yStart) * w + x];
                if (looksLikeAcceptBlue(c)) {
                    if (runStart < 0) runStart = x;
                    runEnd = x;
                    toleratedGap = 0;
                } else if (runStart >= 0 && toleratedGap < 3) {
                    toleratedGap++;
                } else if (runStart >= 0) {
                    if (runEnd - runStart > bestRunEnd - bestRunStart) {
                        bestRunStart = runStart;
                        bestRunEnd = runEnd;
                    }
                    runStart = runEnd = -1;
                    toleratedGap = 0;
                }
            }
            if (runStart >= 0 && runEnd - runStart > bestRunEnd - bestRunStart) {
                bestRunStart = runStart;
                bestRunEnd = runEnd;
            }
            int minRun = Math.max(56, Math.round(w * 0.105f));
            if (bestRunStart >= 0 && bestRunEnd - bestRunStart >= minRun) {
                Rect row = new Rect(bestRunStart, y, bestRunEnd + 2, y + stepY);
                if (current == null) {
                    current = row;
                } else if (row.left <= current.right + 18 && row.right >= current.left - 18
                        && y - current.bottom <= 6) {
                    current.union(row);
                } else {
                    if (isAcceptShape(current, w, h) && current.width() * current.height() > bestArea) {
                        best = new Rect(current);
                        bestArea = current.width() * current.height();
                    }
                    current = row;
                }
                gapRows = 0;
            } else if (current != null && ++gapRows > 3) {
                if (isAcceptShape(current, w, h) && current.width() * current.height() > bestArea) {
                    best = new Rect(current);
                    bestArea = current.width() * current.height();
                }
                current = null;
                gapRows = 0;
            }
        }
        if (current != null && isAcceptShape(current, w, h) && current.width() * current.height() > bestArea)
            best = new Rect(current);
        return best;
    }

    private boolean looksLikeAcceptBlue(int color) {
        int r = (color >> 16) & 0xff, g = (color >> 8) & 0xff, b = color & 0xff;
        // DeliverThat currently uses a saturated cyan/blue filled button. Keep the gate
        // broad enough for display color profiles but narrow enough to reject gray/white UI.
        return b >= 135 && g >= 95 && r <= 125
                && b - r >= 45 && g - r >= 25;
    }

    private boolean isAcceptShape(Rect r, int w, int h) {
        if (r == null || r.isEmpty()) return false;
        int minW = Math.max(60, Math.round(w * 0.10f));
        int maxW = Math.round(w * 0.43f);
        int minH = Math.max(18, Math.round(h * 0.018f));
        int maxH = Math.round(h * 0.18f);
        float aspect = r.height() == 0 ? 0f : (float) r.width() / r.height();
        return r.width() >= minW && r.width() <= maxW
                && r.height() >= minH && r.height() <= maxH
                && aspect >= 1.7f && aspect <= 8.5f
                && r.centerX() > w * 0.58f && r.centerY() > h * 0.36f;
    }

    private Bitmap enhanceForOcr(Bitmap source) {
        try {
            Bitmap out = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(out);
            Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
            ColorMatrix matrix = new ColorMatrix();
            matrix.setSaturation(0f);
            float contrast = 1.55f;
            float offset = 128f * (1f - contrast);
            ColorMatrix contrastMatrix = new ColorMatrix(new float[]{
                    contrast, 0, 0, 0, offset,
                    0, contrast, 0, 0, offset,
                    0, 0, contrast, 0, offset,
                    0, 0, 0, 1, 0
            });
            matrix.postConcat(contrastMatrix);
            paint.setColorFilter(new ColorMatrixColorFilter(matrix));
            canvas.drawBitmap(source, 0, 0, paint);
            return out;
        } catch (RuntimeException | OutOfMemoryError ignored) {
            return null;
        }
    }

    private String fastRuleFailure(String cardText) {
        return fastRuleFailure(cardText, offerLowAmount(cardText), offerMiles(cardText));
    }

    private String fastRuleFailure(TapAccessibilityService.FastOfferSnapshot snapshot) {
        if (snapshot == null) return "信息不完整";
        return fastRuleFailure(snapshot.text, snapshot.amount, snapshot.miles);
    }

    private String fastRuleFailure(String cardText, float amount, float miles) {
        if (cardText == null) return "信息不完整";
        String lower = cardText.toLowerCase(Locale.US);
        if (amount < 0 || miles < 0) return "信息不完整";
        float minimum = prefs.getFloat("minPay", 25f);
        float maximumMiles = prefs.getFloat("maxMiles", 12f);
        boolean pasadena = lower.contains("pasadena");
        boolean pasadenaSpecial = pasadena && prefs.getBoolean("pasadenaRuleEnabled", false);
        if (pasadenaSpecial) {
            minimum = prefs.getFloat("pasadenaMinPay", 25f);
            maximumMiles = prefs.getFloat("pasadenaMaxMiles", 12f);
        }
        if (amount < minimum || miles > maximumMiles) {
            return "金额/里程不符合";
        }
        if (prefs.getBoolean("requireCity", true) && !pasadenaSpecial
                && !containsAllowedCity(cardText)) return "城市不符合";
        if (!offerTimeAllowed(cardText)) return "订单时间不符合";
        return "";
    }

    /**
     * The bounded quick tree is allowed to ACT only when it contains the fields that can
     * change the rule result. Missing address/time evidence falls through to the complete
     * Accessibility scan or OCR instead of being misread as a non-Pasadena/non-city order.
     */
    private boolean quickDecisionTextComplete(String cardText) {
        return quickDecisionTextComplete(cardText, offerLowAmount(cardText), offerMiles(cardText));
    }

    private boolean quickDecisionTextComplete(TapAccessibilityService.FastOfferSnapshot snapshot) {
        return snapshot != null && quickDecisionTextComplete(snapshot.text, snapshot.amount, snapshot.miles);
    }

    private boolean decisionNeedsLocationEvidence() {
        if (prefs.getBoolean("pasadenaRuleEnabled", false)) return true;
        return prefs.getBoolean("requireCity", true)
                && !prefs.getString("cities", "").trim().isEmpty();
    }

    private boolean decisionNeedsOfferTimeEvidence() {
        String startValue = prefs.getString("startTime", "").trim();
        String endValue = prefs.getString("endTime", "").trim();
        return !startValue.isEmpty() && !endValue.isEmpty();
    }

    private boolean quickDecisionTextComplete(String cardText, float amount, float miles) {
        if (cardText == null || cardText.isEmpty()) return false;
        String lower = cardText.toLowerCase(Locale.US);
        if (decisionNeedsLocationEvidence()) {
            // Completeness only. Pay/mileage/city/time rule values remain exactly unchanged.
            boolean hasLocationEvidence = lower.contains(", ca")
                    || lower.contains(" california")
                    || lower.matches("(?s).*\\bca\\s+\\d{5}(?:-\\d{4})?\\b.*");
            if (!hasLocationEvidence) return false;
        }
        if (decisionNeedsOfferTimeEvidence() && !OFFER_TIME.matcher(cardText).find()) return false;
        return amount >= 0 && miles >= 0;
    }

    private boolean accessibilityOwnsDecision(TapAccessibilityService.FastOfferSnapshot snapshot,
                                               String failure) {
        if (!quickDecisionTextComplete(snapshot)) return false;
        boolean expectedActionAnchored = failure == null || failure.isEmpty()
                ? snapshot != null && !snapshot.acceptBounds.isEmpty()
                : prefs.getBoolean("autoIgnore", true)
                && snapshot != null && !snapshot.rejectBounds.isEmpty();
        return AccessibilityFallbackPolicy.accessibilityOwnsFrame(true, expectedActionAnchored);
    }

    /** Hold OCR only when Accessibility already owns a complete top-card decision. */
    private void holdAccessibilityDecision(TapAccessibilityService.FastOfferSnapshot snapshot,
                                           String failure, String source) {
        lastReadableFastScan = SystemClock.elapsedRealtime();
        String action = failure == null || failure.isEmpty() ? "Accept" : "Reject";
        boolean enabled = failure == null || failure.isEmpty()
                ? snapshot.acceptEnabled : snapshot.rejectEnabled;
        updateStatus("页面：OFFERS｜" + source + "已完整锁定第一张；" + action
                + (enabled ? "受事务/重试门控" : "已禁用/处理中")
                + "；暂不启动OCR重复识别");
    }

    private boolean tryFastAccept(TapAccessibilityService.FastOfferSnapshot snapshot) {
        final long decisionStarted = SystemClock.elapsedRealtime();
        String cardText = snapshot.text;
        java.util.function.Consumer<String> report = offerReporter(cardText);
        float amount = snapshot.amount;
        float miles = snapshot.miles;
        if (amount < 0 || miles < 0) return false;

        String failure = fastRuleFailure(snapshot);
        scanTiming = scanTiming + "；规则" + (SystemClock.elapsedRealtime() - decisionStarted) + "ms";
        if (!failure.isEmpty()) return handleFastRejection(snapshot, amount, miles, failure);

        if (prefs.getBoolean("dryRun", false)) {
            cooldownUntil = SystemClock.elapsedRealtime() + 5_000;
            report.accept(String.format(Locale.US,
                    "快速通道测试通过：$%.2f / %.1f mi；未点击", amount, miles));
            playAlert();
            return true;
        }
        clearPendingIgnore();
        return dispatchClaim(snapshot);
    }

    /**
     * Own the fast lane while a first-card transaction is unresolved.
     * Returns true when normal offer discovery must stop for this runnable.
     */
    private boolean handlePendingSerialFast(long now) {
        if (serialTopText.isEmpty() || serialTopActionAt <= 0 || serialTopAction == SerialAction.NONE)
            return false;

        final long epoch = claimEpoch.get();
        final long age = Math.max(0L, now - serialTopActionAt);
        if (serialTopAction == SerialAction.ACCEPT) {
            String cached = TapAccessibilityService.recentCachedClaimOutcomeSince(serialTopActionAt);
            if (TapAccessibilityService.isPositiveClaimOutcome(cached)) {
                confirmPendingClaimSuccess(serialTopText, cached);
                return true;
            }
            if (TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
                confirmPendingClaimSuccess(serialTopText, "Jobs徽标已增加");
                return true;
            }
            // A terminal server answer owns the transaction too. Do not let an already-running
            // Accessibility scan fall through and prepare an independent Accept attempt.
            if (TapAccessibilityService.isTerminalNegativeClaimOutcome(cached)) {
                String id = CardText.identity(serialTopText);
                terminalLossIdentity = id;
                terminalLossUntil = now + 2500L;
                // The dispatch callback already owns the short confirmation loop. Do not start
                // another tree walk from every Accessibility event; keep only the long-stop probe.
                if (age >= 1800L) inspectClaim(serialTopText, epoch);
                return true;
            }
            if (age >= 1800L) inspectClaim(serialTopText, epoch);
            return true;
        }

        // Reject has completely separate semantics. Jobs/detail evidence is intentionally
        // ignored. "offer unavailable" after a Reject only closes the Reject transaction.
        if (serialTopAction == SerialAction.REJECT) {
            String cached = TapAccessibilityService.recentCachedClaimOutcomeSince(serialTopActionAt);
            boolean processingAck = rejectProcessingConfirmedAt > 0
                    || rejectSequence.observe(CardText.identity(serialTopText), now)
                    == RejectSequence.State.PROCESSING;
            if (TapAccessibilityService.isTerminalNegativeClaimOutcome(cached)) {
                finishRejectTransaction(serialTopText, processingAck,
                        processingAck
                                ? "服务器返回" + cached + "，且此前Reject已禁用/处理中"
                                : "服务器返回" + cached + "，但未捕获Reject处理中证据");
                return true;
            }
            // Normal short confirmation is already scheduled by the Reject completion callback.
            // Only a long-held transaction gets an extra watchdog probe here.
            if (age >= 3200L) inspectReject(serialTopText, epoch, 0);
            return true;
        }
        return false;
    }

    private boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot) {
        pendingAcceptJobsBaseline = TapAccessibilityService.recentJobsBadgeCount();
        return dispatchClaim(snapshot, claimEpoch.incrementAndGet());
    }

    private boolean dispatchClaim(TapAccessibilityService.FastOfferSnapshot snapshot, long epoch) {
        if (epoch != claimEpoch.get()) return false;
        if (!monitorReady || prefs.getBoolean("dryRun", false)) { cooldownUntil = 0; return false; }
        String id = snapshot.identity;
        long reserveNow = SystemClock.elapsedRealtime();
        if (isTerminalLossSuppressed(id, reserveNow)) return false;
        int attempt = claimBudget.reserve(id, reserveNow);
        if (attempt == 0) return false;
        serialTopText = snapshot.text;
        serialTopActionAt = SystemClock.elapsedRealtime();
        serialTopAction = SerialAction.ACCEPT;
        rejectProcessingConfirmedAt = 0;
        acceptProcessingConfirmedAt = 0;
        lastActionDispatchAt = serialTopActionAt;
        float amount = snapshot.amount, miles = snapshot.miles;
        java.util.function.Consumer<String> report = offerReporter(snapshot.text);
        if (snapshot.acceptBounds.isEmpty() || !ActionGeometry.plausibleActionRect(
                width, height, snapshot.acceptBounds.left, snapshot.acceptBounds.top,
                snapshot.acceptBounds.right, snapshot.acceptBounds.bottom, true)) {
            report.accept("Accept热区几何异常（疑似整卡/容器）；已禁止点击并交给OCR重新定位");
            cooldownUntil = 0;
            lastReadableFastScan = 0;
            return false;
        }
        // Short transaction window only; a different card is not suppressed for 15 seconds.
        cooldownUntil = SystemClock.elapsedRealtime() + 1500;
        accessibilityActionHoldUntil = SystemClock.elapsedRealtime() + 520;
        java.util.function.Consumer<String> sent = detail -> {
            accessibilityActionHoldUntil = 0;
            long pipelineMs = Math.max(0L, SystemClock.elapsedRealtime() - snapshot.capturedAt);
            report.accept("Accept第" + attempt + "次动作已发送：" + detail
                    + "；snapshot→dispatch=" + pipelineMs + "ms；非接单确认");
            if (fastWorker != null) fastWorker.postDelayed(() -> inspectClaim(snapshot.text, epoch), 70);
        };
        java.util.function.Consumer<String> failed = reason -> {
            accessibilityActionHoldUntil = 0;
            report.accept("Accept第" + attempt + "次未执行：" + reason);
            if (fastWorker != null) fastWorker.postDelayed(() -> inspectClaim(snapshot.text, epoch), 70);
        };
        // v2.10.12: first attempt goes straight to the verified 55ms Gesture. Real-device
        // evidence showed ACTION_CLICK added latency but did not move DeliverThat, while the
        // gesture reliably changed Accept into disabled/processing. Retry attempts refresh the
        // top-card action first and never spend an attempt while the button is disabled.
        if (attempt >= 2)
            TapAccessibilityService.tapSnapshotRetryDetailed(snapshot, amount, miles, attempt, sent, failed);
        else
            TapAccessibilityService.tapSnapshotFastDetailed(snapshot, amount, miles, sent, failed);
        return true;
    }

    private void inspectClaim(String originalText, long epoch) {
        inspectClaim(originalText, epoch, 0, 0);
    }

    private void confirmPendingClaimSuccess(String originalText, String evidence) {
        if (originalText == null || originalText.isEmpty()) return;
        String id = CardText.identity(originalText);
        java.util.function.Consumer<String> report = offerReporter(originalText);
        // Invalidate every already-queued inspector/retry before releasing the serial lock.
        claimEpoch.incrementAndGet();
        serialTopText = "";
        serialTopActionAt = 0;
        serialTopAction = SerialAction.NONE;
        rejectProcessingConfirmedAt = 0;
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        claimBudget.forget(id);
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        report.accept("已确认接单成功：" + (evidence == null || evidence.isEmpty()
                ? "DeliverThat明确接单成功状态" : evidence));
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    private void finishPendingClaimLoss(String originalText, String evidence, boolean terminal) {
        if (originalText == null || originalText.isEmpty()
                || serialTopAction != SerialAction.ACCEPT
                || !CardText.sameOffer(serialTopText, originalText)) return;
        String id = CardText.identity(originalText);
        java.util.function.Consumer<String> report = offerReporter(originalText);
        long now = SystemClock.elapsedRealtime();
        claimEpoch.incrementAndGet();
        serialTopText = "";
        serialTopActionAt = 0;
        serialTopAction = SerialAction.NONE;
        rejectProcessingConfirmedAt = 0;
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        claimBudget.forget(id);
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        if (terminal) {
            terminalLossIdentity = id;
            terminalLossUntil = now + 2500L;
            report.accept("ACCEPT_LOST：" + (evidence == null || evidence.isEmpty()
                    ? "服务器明确判定Offer不可用" : evidence)
                    + "；停止所有重试，立即准备下一张");
        } else {
            report.accept("ACCEPT_UNKNOWN：" + (evidence == null || evidence.isEmpty()
                    ? "原卡已消失但没有明确成功/失败证据" : evidence)
                    + "；不再盲目重试");
        }
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    private void inspectClaim(String originalText, long epoch, int disabledChecks, int missingChecks) {
        if (!monitorReady || epoch != claimEpoch.get() || serialTopAction != SerialAction.ACCEPT) return;
        String id = CardText.identity(originalText);
        java.util.function.Consumer<String> report = offerReporter(originalText);

        // Zero-tree fast exit. Accessibility events frequently expose the assigned-job screen
        // before this 70ms inspector runs. If so, do not spend 500-900ms rebuilding the old
        // offer tree and, more importantly, do not allow any stale retry gesture.
        String outcomeHint = TapAccessibilityService.recentCachedClaimOutcomeSince(serialTopActionAt);
        if (TapAccessibilityService.isPositiveClaimOutcome(outcomeHint)) {
            confirmPendingClaimSuccess(originalText, outcomeHint);
            return;
        }
        if (TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
            confirmPendingClaimSuccess(originalText, "Jobs徽标已增加");
            return;
        }

        // Exactly one coherent Accessibility scan. pageFromScan also refreshes outcome/jobs
        // caches, so do not immediately walk the same hierarchy again for success evidence.
        TapAccessibilityService.FastOfferSnapshot current = TapAccessibilityService.findOffer(originalText);
        outcomeHint = TapAccessibilityService.recentCachedClaimOutcomeSince(serialTopActionAt);
        if (TapAccessibilityService.isPositiveClaimOutcome(outcomeHint)) {
            confirmPendingClaimSuccess(originalText, outcomeHint);
            return;
        }
        if (TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
            confirmPendingClaimSuccess(originalText, "Jobs徽标已增加");
            return;
        }

        if (TapAccessibilityService.isTerminalNegativeClaimOutcome(outcomeHint)) {
            long terminalNow = SystemClock.elapsedRealtime();
            terminalLossIdentity = id;
            terminalLossUntil = terminalNow + 2500L;
            cooldownUntil = 0;
            accessibilityActionHoldUntil = 0;
            lastReadableFastScan = 0;
            // Keep the dead first card locked only until it actually leaves the top. The explicit
            // server answer suppresses every Accept retry; no second/third claim is authorized.
            if (current != null) {
                if (fastWorker != null)
                    fastWorker.postDelayed(() -> inspectClaim(originalText, epoch,
                            Math.max(1, disabledChecks), missingChecks), 90);
                return;
            }
        }
        if (current != null && fastRuleFailure(current.text).isEmpty()
                && claimBudget.available(id, SystemClock.elapsedRealtime())) {
            if (!current.acceptBounds.isEmpty() && current.acceptEnabled) {
                // Only this inspector may authorize a retry. Normal OCR/fast scans are gated
                // while serialTopActionAt is non-zero, preventing competing attempts.
                dispatchClaim(current, epoch);
                return;
            }
            if (!current.acceptEnabled) {
                long processingNow = SystemClock.elapsedRealtime();
                acceptProcessingConfirmedAt = processingNow;
                if (disabledChecks == 0)
                    report.accept("Accept已进入禁用/处理中；事件优先等待服务器结果，不消耗重试次数"
                            + (outcomeHint.isEmpty() ? "" : "；状态=" + outcomeHint));
                if (fastWorker != null)
                    fastWorker.postDelayed(() -> awaitClaimProcessingOutcome(originalText, epoch,
                                    missingChecks, processingNow),
                            ActionDispatchPolicy.processingPollMs());
                return;
            }
        }
        if (current != null) {
            serialTopText = originalText;
            if (serialTopActionAt <= 0) serialTopActionAt = SystemClock.elapsedRealtime();
            report.accept("顶部原订单仍可见；未确认接单，继续锁定第一张，不处理下面订单"
                    + (outcomeHint.isEmpty() ? "" : "；服务器状态=" + outcomeHint));
            cooldownUntil = 0;
            lastScan = 0;
            return;
        }

        // The old offer disappeared. One page scan is enough; it also refreshes Jobs badge
        // and assigned-job detail text. Never call hasAcceptSuccessEvidence() here because that
        // would walk the same 100+ node tree a second time.
        PageGuard.Page page = TapAccessibilityService.activePage();
        outcomeHint = TapAccessibilityService.recentCachedClaimOutcomeSince(serialTopActionAt);
        boolean jobsIncreased = TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline);
        boolean successEvidence = TapAccessibilityService.isPositiveClaimOutcome(outcomeHint) || jobsIncreased;
        long confirmNow = SystemClock.elapsedRealtime();
        boolean terminalKnown = TapAccessibilityService.isTerminalNegativeClaimOutcome(outcomeHint)
                || (id.equals(terminalLossIdentity) && confirmNow <= terminalLossUntil);
        ClaimConfirmation.Result confirmation =
                ClaimConfirmation.classify(false, page, successEvidence, terminalKnown);
        if (confirmation == ClaimConfirmation.Result.CONFIRMED) {
            confirmPendingClaimSuccess(originalText, !outcomeHint.isEmpty() ? outcomeHint
                    : (jobsIncreased ? "Jobs徽标已增加" : "DeliverThat显示Jobs"));
            return;
        }
        if (confirmation == ClaimConfirmation.Result.TERMINAL_LOST) {
            finishPendingClaimLoss(originalText,
                    "服务器返回" + (outcomeHint.isEmpty() ? "offer unavailable" : outcomeHint), true);
            return;
        }
        if (missingChecks < 1) {
            if (fastWorker != null)
                fastWorker.postDelayed(() -> inspectClaim(originalText, epoch,
                        disabledChecks, missingChecks + 1), 110);
            return;
        }
        finishPendingClaimLoss(originalText,
                page == PageGuard.Page.OFFERS
                        ? "原卡已从Offers消失，未检测到Jobs/已接单详情"
                        : "原卡已消失且未检测到明确接单成功证据",
                false);
        return;
    }

    /**
     * v2.10.26 processing quiet lane. A prior coherent tree read already proved that the same
     * top offer's Accept control is disabled/processing. During this short window we consume
     * cached Accessibility success/failure signals only, so the confirmation phase does not
     * contend with OCR or the next UI event by rebuilding the full React-Native tree every 95ms.
     */
    private void awaitClaimProcessingOutcome(String originalText, long epoch, int missingChecks,
                                             long processingWindowStarted) {
        if (!monitorReady || epoch != claimEpoch.get() || serialTopAction != SerialAction.ACCEPT)
            return;
        if (originalText == null || originalText.isEmpty()
                || !CardText.sameOffer(serialTopText, originalText)) return;

        String outcomeHint = TapAccessibilityService.recentCachedClaimOutcomeSince(serialTopActionAt);
        if (TapAccessibilityService.isPositiveClaimOutcome(outcomeHint)) {
            confirmPendingClaimSuccess(originalText, outcomeHint);
            return;
        }
        if (TapAccessibilityService.jobsBadgeIncreasedSince(pendingAcceptJobsBaseline)) {
            confirmPendingClaimSuccess(originalText, "Jobs徽标已增加");
            return;
        }
        if (TapAccessibilityService.isTerminalNegativeClaimOutcome(outcomeHint)) {
            // A terminal answer is authoritative, but one coherent tree recheck still owns
            // top-card retirement so a lower card can never inherit the old action rectangle.
            inspectClaim(originalText, epoch, 1, missingChecks);
            return;
        }

        long now = SystemClock.elapsedRealtime();
        long elapsed = Math.max(0L, now - processingWindowStarted);
        if (elapsed < ActionDispatchPolicy.processingTreeRecheckMs()) {
            if (fastWorker != null)
                fastWorker.postDelayed(() -> awaitClaimProcessingOutcome(originalText, epoch,
                                missingChecks, processingWindowStarted),
                        ActionDispatchPolicy.processingPollMs());
            return;
        }

        // Recheck once after the quiet window. If Accept is still disabled, inspectClaim will
        // start a new quiet window. If it rolled back to enabled, the normal bounded retry
        // budget can act immediately; if the card disappeared, normal success/loss semantics run.
        inspectClaim(originalText, epoch, 1, missingChecks);
    }

    /**
     * Reject post-action confirmation is intentionally separate from Accept. Jobs badge and
     * assigned-job detail are NEVER consulted here. Two consecutive misses are required before
     * calling a rejected card gone, preventing a transient blank Accessibility frame from
     * producing a false success.
     */
    private void inspectReject(String originalText, long epoch, int missingChecks) {
        if (!monitorReady || epoch != claimEpoch.get() || serialTopAction != SerialAction.REJECT) return;
        if (originalText == null || originalText.isEmpty()
                || !CardText.sameOffer(serialTopText, originalText)) return;
        final String id = CardText.identity(originalText);
        final long now = SystemClock.elapsedRealtime();
        TapAccessibilityService.FastOfferSnapshot current = TapAccessibilityService.findOffer(originalText);
        if (current != null) {
            // Same card remains: do not reinterpret it as Accept and do not burn a Reject retry
            // while the control is disabled/processing. Normal shared RejectSequence timing
            // still owns any later real retry if DeliverThat rolls the state back.
            if ((!current.rejectEnabled
                    || rejectSequence.observe(id, now) == RejectSequence.State.PROCESSING)
                    && rejectProcessingConfirmedAt == 0) {
                rejectProcessingConfirmedAt = now;
            }
            if (fastWorker != null && now - serialTopActionAt < 3200L)
                fastWorker.postDelayed(() -> inspectReject(originalText, epoch, 0), 240);
            return;
        }

        boolean processingAck = rejectProcessingConfirmedAt > 0
                || rejectSequence.observe(id, now) == RejectSequence.State.PROCESSING;
        int missingReads = missingChecks + 1;
        RejectConfirmation.Result result = RejectConfirmation.classify(false, processingAck, missingReads);
        if (result == RejectConfirmation.Result.PENDING) {
            if (fastWorker != null)
                fastWorker.postDelayed(() -> inspectReject(originalText, epoch, missingChecks + 1), 100);
            return;
        }
        boolean confirmed = result == RejectConfirmation.Result.CONFIRMED;
        finishRejectTransaction(originalText, confirmed, confirmed
                ? "原卡连续两次不可见，且此前Reject已禁用/处理中"
                : "原卡连续两次不可见，但未捕获明确Reject处理中证据");
    }

    private void finishRejectTransaction(String originalText, boolean confirmed, String evidence) {
        if (serialTopAction != SerialAction.REJECT || originalText == null
                || !CardText.sameOffer(serialTopText, originalText)) return;
        String id = CardText.identity(originalText);
        java.util.function.Consumer<String> report = offerReporter(originalText);
        claimEpoch.incrementAndGet();
        serialTopText = "";
        serialTopActionAt = 0;
        serialTopAction = SerialAction.NONE;
        rejectProcessingConfirmedAt = 0;
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        rejectSequence.forget(id);
        rejectTransitionSuppressUntil = 0;
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        report.accept((confirmed ? "REJECT_SUCCESS：" : "REJECT_UNKNOWN：") + evidence
                + (confirmed ? "；确认拒绝成功" : "；不按接单结果判断"));
        requestImmediateFastCheck(SystemClock.uptimeMillis());
    }

    private boolean isTerminalLossSuppressed(String id, long now) {
        if (id == null || id.isEmpty()) return false;
        if (now > terminalLossUntil) {
            terminalLossIdentity = "";
            terminalLossUntil = 0;
            return false;
        }
        return id.equals(terminalLossIdentity);
    }

    /** Record only stable, first-card OCR evidence. Returns true after two consecutive frames. */
    private boolean observeOcrTop(String cardText, long now) {
        String id = CardText.identity(cardText);
        if (id.isEmpty()) return false;
        if (!id.equals(observedTopIdentity)) {
            observedTopIdentity = id;
            observedTopSince = now;
            observedTopFrames = 1;
            return false;
        }
        observedTopFrames = Math.min(1000, observedTopFrames + 1);
        return observedTopFrames >= ActionStallPolicy.stableFrames()
                && now - observedTopSince >= ActionStallPolicy.stableTopMs();
    }

    /**
     * Retire an old action transaction only after a different top offer is positively observed.
     * Invalidate pending claim inspectors as well as global timing gates; otherwise an old
     * inspectClaim callback can re-lock the service after the new card has already reached top.
     */
    private void retireStaleSerialLock(String newTopText, String source,
                                       java.util.function.Consumer<String> report) {
        String old = serialTopText;
        if (old.isEmpty() || CardText.sameOffer(old, newTopText)) return;
        long now = SystemClock.elapsedRealtime();
        SerialAction oldAction = serialTopAction;
        boolean rejectAck = oldAction == SerialAction.REJECT
                && (rejectProcessingConfirmedAt > 0
                || rejectSequence.observe(CardText.identity(old), now) == RejectSequence.State.PROCESSING);
        claimEpoch.incrementAndGet();
        serialTopText = "";
        serialTopActionAt = 0;
        serialTopAction = SerialAction.NONE;
        rejectProcessingConfirmedAt = 0;
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        rejectTransitionSuppressUntil = 0;
        urgentTransitionIdentity = "";
        urgentTransitionUntil = 0;
        cooldownUntil = 0;
        accessibilityActionHoldUntil = 0;
        lastReadableFastScan = 0;
        lastScan = 0;
        lastStallRecoveryAt = now;
        String message;
        if (oldAction == SerialAction.REJECT) {
            rejectSequence.forget(CardText.identity(old));
            message = rejectAck
                    ? "REJECT_SUCCESS：原拒绝卡已离开顶部且此前Reject已禁用/处理中；确认拒绝成功，立即处理下一张"
                    : "REJECT_UNKNOWN：原拒绝卡已离开顶部但未捕获明确处理中证据；不按接单结果判断，立即处理下一张";
        } else if (oldAction == SerialAction.ACCEPT
                && CardText.identity(old).equals(terminalLossIdentity)
                && now <= terminalLossUntil) {
            claimBudget.forget(CardText.identity(old));
            message = "ACCEPT_LOST：服务器已判定旧Offer不可用且顶部已换单；停止旧单全部重试，立即处理当前第一张";
        } else {
            message = "ACTION_STALL_RECOVERY：" + source
                    + "；旧顶部事务已失效，清除serial/cooldown/hold并继续处理当前第一张";
        }
        if (report != null) report.accept(message); else updateStatus(message);
    }

    private int topCropTop() {
        return Math.max(0, Math.min(height - 2, Math.round(height * TOP_ROI_START)));
    }

    private int topCropBottom() {
        return Math.max(topCropTop() + 2, Math.min(height, Math.round(height * TOP_ROI_END)));
    }

    /**
     * Copy only [cropTop,cropBottom) rows from the RGBA ImageReader plane. This keeps the
     * source row stride/padding intact while avoiding a full-screen temporary bitmap.
     */
    private Bitmap imageToTopRoiBitmap(Image image, int cropTop, int cropBottom) {
        if (image == null || cropBottom <= cropTop) return null;
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer source = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        if (pixelStride <= 0 || rowStride <= 0) return null;
        int cropHeight = cropBottom - cropTop;
        int paddedWidth = rowStride / pixelStride;
        long startLong = (long) cropTop * rowStride;
        long bytesLong = (long) cropHeight * rowStride;
        if (startLong < 0 || bytesLong <= 0 || startLong + bytesLong > source.capacity()) return null;
        try {
            ByteBuffer rows = source.duplicate();
            rows.position((int) startLong);
            rows.limit((int) (startLong + bytesLong));
            rows = rows.slice();

            if (roiPaddedBuffer == null || roiPaddedBuffer.isRecycled()
                    || roiPaddedBuffer.getWidth() != paddedWidth
                    || roiPaddedBuffer.getHeight() != cropHeight) {
                if (roiPaddedBuffer != null && !roiPaddedBuffer.isRecycled()) roiPaddedBuffer.recycle();
                roiPaddedBuffer = Bitmap.createBitmap(paddedWidth, cropHeight, Bitmap.Config.ARGB_8888);
            }
            roiPaddedBuffer.copyPixelsFromBuffer(rows);
            if (paddedWidth == width) {
                roiExactBuffer = roiPaddedBuffer;
                return roiPaddedBuffer;
            }
            if (roiExactBuffer == null || roiExactBuffer == roiPaddedBuffer || roiExactBuffer.isRecycled()
                    || roiExactBuffer.getWidth() != width || roiExactBuffer.getHeight() != cropHeight) {
                if (roiExactBuffer != null && roiExactBuffer != roiPaddedBuffer && !roiExactBuffer.isRecycled())
                    roiExactBuffer.recycle();
                roiExactBuffer = Bitmap.createBitmap(width, cropHeight, Bitmap.Config.ARGB_8888);
            }
            Canvas canvas = new Canvas(roiExactBuffer);
            canvas.drawBitmap(roiPaddedBuffer,
                    new Rect(0, 0, width, cropHeight),
                    new Rect(0, 0, width, cropHeight), roiCopyPaint);
            return roiExactBuffer;
        } catch (RuntimeException | OutOfMemoryError failure) {
            return null;
        }
    }

    /** Warm ML Kit while the user is opening DeliverThat instead of on the first valuable offer. */
    private void warmRecognizer() {
        if (recognizer == null || worker == null) return;
        worker.post(() -> {
            Bitmap warm = null;
            try {
                warm = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888);
                warm.eraseColor(android.graphics.Color.WHITE);
                final Bitmap toRecycle = warm;
                recognizer.process(InputImage.fromBitmap(warm, 0))
                        .addOnCompleteListener(done -> toRecycle.recycle());
            } catch (RuntimeException | OutOfMemoryError ignored) {
                if (warm != null && !warm.isRecycled()) warm.recycle();
            }
        });
    }


    private void evaluate(Text result, long evidenceAt, Rect visualAccept) {
        PageGuard.Page active = TapAccessibilityService.recentPageHint();
        if (!monitorReady || !TapAccessibilityService.isDeliverThatForeground()) return;
        // Do not discard the OCR completion yet merely because Accessibility was readable.
        // A rescue frame may be the only source able to prove that an old serial transaction
        // no longer owns the top action row. The normal fast-path suppression is applied only
        // after stale-state reconciliation below.

        Rect semanticAccept = findButtonBounds(result, ACCEPT_WORDS);
        Rect semanticReject = findButtonBounds(result, IGNORE_WORDS);
        Rect acceptAnchor = semanticAccept == null ? null : new Rect(semanticAccept);
        boolean visualAcceptUsed = false;
        boolean acceptInferredFromReject = false;

        if (acceptAnchor == null && visualAccept != null && !visualAccept.isEmpty()) {
            acceptAnchor = new Rect(visualAccept);
            visualAcceptUsed = true;
        }
        if (acceptAnchor == null && semanticReject != null
                && ActionGeometry.plausibleLeftAction(width, semanticReject.exactCenterX())) {
            acceptAnchor = inferPairedAction(semanticReject, false);
            acceptInferredFromReject = acceptAnchor != null;
        }

        String rawScreenText = result == null ? "" : result.getText();
        if (serialTopAction == SerialAction.ACCEPT && serialTopActionAt > 0
                && ClaimSuccessSignals.hasAcceptedJobDetail(rawScreenText)) {
            confirmPendingClaimSuccess(serialTopText, "Delivery Timeline/Dropoff Instructions");
            return;
        }
        boolean screenHasMoney = MONEY.matcher(rawScreenText).find();
        boolean screenHasMiles = MILES.matcher(rawScreenText).find();
        boolean screenHasOfferAction = semanticAccept != null || semanticReject != null
                || (visualAccept != null && !visualAccept.isEmpty());
        boolean ocrProvesOffer = screenHasMoney && screenHasMiles && screenHasOfferAction;
        if ((active == PageGuard.Page.JOBS || active == PageGuard.Page.IGNORED) && !ocrProvesOffer) return;
        if ((active == PageGuard.Page.JOBS || active == PageGuard.Page.IGNORED) && ocrProvesOffer) {
            // A current screenshot with numbers + live Accept/Reject evidence overrides a stale
            // Accessibility selected-tab hint.  This is specifically to prevent silent misses.
            active = PageGuard.Page.OFFERS;
        }

        Rect cardAnchor = acceptAnchor != null ? acceptAnchor
                : (semanticReject == null ? null : new Rect(semanticReject));
        if (cardAnchor == null) {
            if (SystemClock.elapsedRealtime() < rejectTransitionSuppressUntil) return;
            clearPendingIgnore();
            clearPendingAccept();
            String screenText = rawScreenText.toLowerCase(Locale.US);
            if ((screenText.contains("$") || MONEY.matcher(screenText).find())
                    && MILES.matcher(screenText).find()) {
                updateOfferStatus("OCR扫描：金额/里程已读到，但动作行仍无可靠锚点；未点击；已立即请求Accessibility/下一帧复核", result.getText());
                // Do not donate a normal 80 ms scan interval after a clearly offer-looking
                // frame. The fast queue coalesces duplicates, while enhanced OCR may run in
                // parallel if button text was the only thing ML Kit missed.
                lastReadableFastScan = 0;
                lastScan = 0;
                requestImmediateFastCheck(SystemClock.uptimeMillis());
            }
            return;
        }

        String cardText = textNearButton(result, cardAnchor);
        java.util.function.Consumer<String> report = offerReporter(cardText);
        long actionNow = SystemClock.elapsedRealtime();
        float earlyAmount = offerLowAmount(cardText);
        float earlyMiles = offerMiles(cardText);
        boolean stableTop = observeOcrTop(cardText, actionNow);
        if (!serialTopText.isEmpty() && !CardText.sameOffer(serialTopText, cardText)) {
            // v2.10.14: do not automatically donate one full scan cycle to a competitor.
            // If a bounded Accessibility re-read independently sees the same amount+miles on
            // the CURRENT top Accept row, OCR+Accessibility are two-source confirmation and
            // the old transaction can be retired in this same frame. Otherwise force the
            // next camera frame immediately; the old lock is preserved until that proof arrives.
            TapAccessibilityService.FastOfferSnapshot consensus = null;
            if (earlyAmount >= 0 && earlyMiles >= 0 && acceptAnchor != null)
                consensus = TapAccessibilityService.quickVerifyTopAction(earlyAmount, earlyMiles, true);
            if (consensus != null) {
                urgentTransitionIdentity = "";
                urgentTransitionUntil = 0;
                retireStaleSerialLock(cardText, "OCR+Accessibility双源确认换顶", report);
            } else if (!stableTop) {
                urgentTransitionIdentity = CardText.identity(cardText);
                urgentTransitionUntil = actionNow + ActionStallPolicy.urgentTransitionWindowMs();
                lastScan = 0;
                report.accept("检测到疑似换顶；已启动紧急下一帧确认，不等待常规扫描周期");
                return;
            } else {
                urgentTransitionIdentity = "";
                urgentTransitionUntil = 0;
                retireStaleSerialLock(cardText, "OCR快速连续两帧确认换顶", report);
            }
        } else if (stableTop && !prefs.getBoolean("dryRun", false)) {
            if (CardText.identity(cardText).equals(urgentTransitionIdentity)) {
                urgentTransitionIdentity = "";
                urgentTransitionUntil = 0;
            }
            boolean transientBlocked = actionNow < cooldownUntil || actionNow < accessibilityActionHoldUntil;
            long sinceDispatch = lastActionDispatchAt > 0 ? actionNow - lastActionDispatchAt : Long.MAX_VALUE;
            if (transientBlocked && serialTopText.isEmpty()
                    && sinceDispatch >= ActionStallPolicy.softStallMs()
                    && actionNow - lastStallRecoveryAt >= ActionStallPolicy.recoveryDebounceMs()) {
                cooldownUntil = 0;
                accessibilityActionHoldUntil = 0;
                lastReadableFastScan = 0;
                lastStallRecoveryAt = actionNow;
                report.accept("ACTION_STALL_RECOVERY：第一张订单稳定可见但仍被旧cooldown/hold阻塞；已软复位并同帧继续");
            } else if (transientBlocked && !serialTopText.isEmpty()
                    && CardText.sameOffer(serialTopText, cardText)
                    && serialTopActionAt > 0
                    && actionNow - serialTopActionAt >= ActionStallPolicy.hardHoldMs()
                    && actionNow - lastStallRecoveryAt >= ActionStallPolicy.recoveryDebounceMs()) {
                // Same-card hard stall: release only transient timing gates. Keep identity and
                // attempt budgets so we cannot spam a countdown/processing button.
                cooldownUntil = 0;
                accessibilityActionHoldUntil = 0;
                lastReadableFastScan = 0;
                lastStallRecoveryAt = actionNow;
                report.accept("ACTION_STALL_RECOVERY：同一顶部订单超过硬等待仍可见；仅释放临时阻塞，保留串行锁与重试预算");
            }
        }
        // After the watchdog had a chance to reconcile a stale transaction, ordinary cooldown
        // semantics still apply. A live claim/reject transaction is not bypassed.
        if (SystemClock.elapsedRealtime() < cooldownUntil
                || SystemClock.elapsedRealtime() < accessibilityActionHoldUntil) return;
        // An ordinary older OCR completion should still yield to a newer readable
        // Accessibility decision. A successful stall recovery clears lastReadableFastScan,
        // so this cannot suppress the same rescue frame that performed the recovery.
        if (lastReadableFastScan != 0
                && SystemClock.elapsedRealtime() - lastReadableFastScan < 500) return;
        float amount = earlyAmount;
        float miles = earlyMiles;
        if (amount < 0 || miles < 0) {
            if (SystemClock.elapsedRealtime() < rejectTransitionSuppressUntil) return;
            clearPendingIgnore();
            clearPendingAccept();
            report.accept("OCR信息不完整：不会点击Accept或Ignore");
            return;
        }

        // If Accessibility cannot classify the page, only a strong right-side action
        // anchor (semantic Accept or visual blue Accept) may authorize coordinate actions.
        // An inferred Accept from a lone Reject label is not enough on UNKNOWN.
        boolean strongAcceptEvidence = semanticAccept != null
                || (visualAccept != null && !visualAccept.isEmpty());
        if (active == PageGuard.Page.UNKNOWN && !strongAcceptEvidence) {
            clearPendingIgnore();
            clearPendingAccept();
            report.accept("页面仍UNKNOWN且没有独立Accept证据；未点击");
            return;
        }

        float minimum = prefs.getFloat("minPay", 25f);
        float maximumMiles = prefs.getFloat("maxMiles", 12f);
        boolean pasadena = cardText.toLowerCase(Locale.US).contains("pasadena");
        if (pasadena && prefs.getBoolean("pasadenaRuleEnabled", false)) {
            minimum = prefs.getFloat("pasadenaMinPay", 25f);
            maximumMiles = prefs.getFloat("pasadenaMaxMiles", 12f);
        }
        if (amount < minimum || miles > maximumMiles) {
            clearPendingAccept();
            handleIneligible(result, acceptAnchor, semanticReject, amount, miles,
                    pasadena && prefs.getBoolean("pasadenaRuleEnabled", false)
                            ? "Pasadena专属金额/里程不符合" : "普通金额/里程不符合",
                    evidenceAt);
            return;
        }
        boolean pasadenaSpecial = pasadena && prefs.getBoolean("pasadenaRuleEnabled", false);
        if (prefs.getBoolean("requireCity", true) && !pasadenaSpecial && !containsAllowedCity(cardText)) {
            clearPendingAccept();
            handleIneligible(result, acceptAnchor, semanticReject, amount, miles, "城市不符合", evidenceAt);
            return;
        }
        if (!offerTimeAllowed(cardText)) {
            clearPendingAccept();
            handleIneligible(result, acceptAnchor, semanticReject, amount, miles, "订单时间不符合", evidenceAt);
            return;
        }

        clearPendingIgnore();

        if (acceptAnchor == null) {
            clearPendingAccept();
            QualifiedOfferAlert.notifyIfNeeded(this, prefs, cardText, amount, miles);
            report.accept("规则符合，但仍无法可靠定位Accept动作行；未接单");
            return;
        }

        if (visualAcceptUsed) {
            report.accept(String.format(Locale.US,
                    "规则符合；Accessibility/OCR按钮文字缺失，使用蓝色Accept视觉锚点：$%.2f / %.1f mi",
                    amount, miles));
        } else if (acceptInferredFromReject) {
            report.accept(String.format(Locale.US,
                    "规则符合；由同排Reject位置镜像推定Accept：$%.2f / %.1f mi", amount, miles));
        }

        int cropTop = topCropTop();
        Rect fullAccept = new Rect(acceptAnchor);
        fullAccept.offset(0, cropTop);
        if (!ActionGeometry.plausibleActionRect(width, height,
                fullAccept.left, fullAccept.top, fullAccept.right, fullAccept.bottom, true)) {
            clearPendingAccept();
            QualifiedOfferAlert.notifyIfNeeded(this, prefs, cardText, amount, miles);
            report.accept("规则符合，但Accept热区几何异常（疑似整卡/容器）；未点击，等待重新定位");
            lastReadableFastScan = 0;
            return;
        }
        float x = ActionGeometry.stableTapX(width, fullAccept.exactCenterX(), true);
        float y = fullAccept.exactCenterY();
        if (prefs.getBoolean("dryRun", false)) {
            cooldownUntil = SystemClock.elapsedRealtime() + 5_000;
            report.accept(String.format(Locale.US, "测试通过：$%.2f / %.1f mi；未点击", amount, miles));
            playAlert();
            return;
        }
        String claimId = CardText.identity(cardText);
        if (!serialTopText.isEmpty() && serialTopActionAt > 0
                && CardText.sameOffer(serialTopText, cardText)) {
            report.accept(serialTopAction == SerialAction.REJECT
                    ? "Reject事务处理中；OCR不把同一卡重新解释为Accept"
                    : "Accept事务处理中；OCR不启动独立重试，等待统一确认器");
            return;
        }
        if (isTerminalLossSuppressed(claimId, SystemClock.elapsedRealtime())) {
            report.accept("服务器已判定该Offer不可用；等待卡片消失，不重复Accept");
            return;
        }
        if (claimBudget.reserve(claimId, SystemClock.elapsedRealtime()) == 0) return;
        pendingAcceptJobsBaseline = TapAccessibilityService.recentJobsBadgeCount();
        final long epoch = claimEpoch.incrementAndGet();
        serialTopText = cardText;
        serialTopActionAt = SystemClock.elapsedRealtime();
        serialTopAction = SerialAction.ACCEPT;
        rejectProcessingConfirmedAt = 0;
        acceptProcessingConfirmedAt = 0;
        lastActionDispatchAt = serialTopActionAt;
        cooldownUntil = SystemClock.elapsedRealtime() + 900;
        TapAccessibilityService.tapOcrOffer(x, y, amount, miles, evidenceAt, () -> {
                    report.accept(String.format(Locale.US,
                            "Accept点击已发送：OCR顶部按钮热区 Gesture55ms rect=[%d,%d,%d,%d] tap=(%d,%d) $%.2f / %.1f mi；非接单确认",
                            fullAccept.left, fullAccept.top, fullAccept.right, fullAccept.bottom,
                            Math.round(x), Math.round(y), amount, miles));
                    if (fastWorker != null)
                        fastWorker.postDelayed(() -> inspectClaim(cardText, epoch), 75);
                }, reason -> {
                    cooldownUntil = 0;
                    report.accept("Accept未执行：" + reason);
                    lastScan = 0;
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                });
        // Queue the claim first; notification/sound work must never sit ahead of the tap.
        QualifiedOfferAlert.notifyIfNeeded(this, prefs, cardText, amount, miles);
    }

    private Rect inferPairedAction(Rect anchor, boolean inferLeft) {
        if (anchor == null || anchor.isEmpty()) return null;
        float x;
        if (inferLeft) {
            if (!ActionGeometry.plausibleRightAction(width, anchor.exactCenterX())) return null;
            x = ActionGeometry.inferredLeftActionX(width, anchor.exactCenterX());
        } else {
            if (!ActionGeometry.plausibleLeftAction(width, anchor.exactCenterX())) return null;
            x = ActionGeometry.inferredRightActionX(width, anchor.exactCenterX());
        }
        int halfW = Math.max(18, Math.min(60, anchor.width() / 2));
        int halfH = Math.max(12, Math.min(36, anchor.height() / 2));
        int cx = Math.round(x), cy = Math.round(anchor.exactCenterY());
        return new Rect(cx - halfW, cy - halfH, cx + halfW, cy + halfH);
    }

    private Rect findButtonBounds(Text result, String[] words) {
        return findButtonBounds(result, words, null);
    }

    private Rect findButtonBounds(Text result, String[] words, Rect sameRowAs) {
        if (result == null) return null;
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element element : line.getElements()) {
                    String value = element.getText().trim().toLowerCase(Locale.US)
                            .replaceAll("[^a-z0-9]", "");
                    for (String word : words) {
                        Rect box = element.getBoundingBox();
                        if (buttonWordMatches(value, word) && box != null && !box.isEmpty()
                                && (sameRowAs == null || ocrSameRow(box, sameRowAs))) return new Rect(box);
                    }
                }
                String lineText = line.getText().trim().toLowerCase(Locale.US);
                String lineValue = lineText.replaceAll("[^a-z0-9]", "");
                for (String word : words) {
                    boolean present = buttonWordMatches(lineValue, word)
                            || Pattern.compile("(^|[^a-z0-9])" + Pattern.quote(word)
                            + "([^a-z0-9]|$)").matcher(lineText).find();
                    if (present && line.getBoundingBox() != null) {
                        Rect box = new Rect(line.getBoundingBox());
                        int middle = (box.left + box.right) / 2;
                        if (words == ACCEPT_WORDS && (lineValue.contains("ignore")
                                || lineValue.contains("decline") || lineValue.contains("reject"))) box.left = middle;
                        if (words == IGNORE_WORDS && (lineValue.contains("accept")
                                || lineValue.contains("claim"))) box.right = middle;
                        if (!box.isEmpty() && (sameRowAs == null || ocrSameRow(box, sameRowAs))) return box;
                    }
                }
            }
        }
        return null;
    }

    private boolean ocrSameRow(Rect a, Rect b) {
        int tolerance = Math.max(14, Math.max(a.height(), b.height()));
        return Math.abs(a.centerY() - b.centerY()) <= tolerance;
    }

    private boolean buttonWordMatches(String value, String word) {
        if (value.equals(word)) return true;
        // Common Latin OCR substitutions on Android button labels.
        if (word.equals("ignore") && (value.equals("lgnore") || value.equals("ign0re"))) return true;
        if ((word.equals("accept") || word.equals("claim")
                || word.equals("decline") || word.equals("reject") || word.equals("ignore"))
                && value.length() >= 4 && oneEditOrLess(value, word)) return true;
        return false;
    }

    private boolean oneEditOrLess(String a, String b) {
        if (Math.abs(a.length() - b.length()) > 1) return false;
        int i = 0, j = 0, edits = 0;
        while (i < a.length() && j < b.length()) {
            if (a.charAt(i) == b.charAt(j)) {
                i++;
                j++;
                continue;
            }
            if (++edits > 1) return false;
            if (a.length() > b.length()) i++;
            else if (b.length() > a.length()) j++;
            else {
                i++;
                j++;
            }
        }
        if (i < a.length() || j < b.length()) edits++;
        return edits <= 1;
    }

    private void handleIneligible(Text result, Rect acceptAnchor, Rect semanticReject,
                                  float amount, float miles, String reason, long evidenceAt) {
        Rect reject = null;
        boolean inferredReject = false;

        if (semanticReject != null && !semanticReject.isEmpty()
                && (acceptAnchor == null || ocrSameRow(semanticReject, acceptAnchor))) {
            reject = new Rect(semanticReject);
        }
        if (reject == null && acceptAnchor != null) {
            Rect sameRow = findButtonBounds(result, IGNORE_WORDS, acceptAnchor);
            if (sameRow != null) reject = new Rect(sameRow);
        }
        if (reject == null && acceptAnchor != null) {
            reject = inferPairedAction(acceptAnchor, true);
            inferredReject = reject != null;
        }

        Rect cardAnchor = acceptAnchor != null ? acceptAnchor
                : (semanticReject == null ? reject : semanticReject);
        String cardText = textNearButton(result, cardAnchor);

        if (reject != null) {
            reject = new Rect(reject);
            reject.offset(0, topCropTop());
        }
        handleRejectedCard(cardText, reject, amount, miles, reason,
                false, evidenceAt, inferredReject);
    }

    private boolean handleFastRejection(TapAccessibilityService.FastOfferSnapshot snapshot,
                                        float amount, float miles, String reason) {
        if (snapshot.rejectBounds.isEmpty()) return false;
        if (!snapshot.rejectEnabled) {
            offerReporter(snapshot.text).accept("Reject按钮当前禁用/处理中；保持第一卡锁定，不重复点击");
            lastReadableFastScan = 0;
            return false;
        }
        if (!ActionGeometry.plausibleActionRect(width, height,
                snapshot.rejectBounds.left, snapshot.rejectBounds.top,
                snapshot.rejectBounds.right, snapshot.rejectBounds.bottom, false)) {
            offerReporter(snapshot.text).accept(
                    "Reject热区几何异常（疑似整卡/容器）；快速路径不点击，交给OCR重定位");
            lastReadableFastScan = 0;
            return false;
        }
        handleRejectedCard(snapshot.text, snapshot.rejectBounds, amount, miles, reason,
                true, 0L, false, snapshot);
        return true;
    }

    private void handleRejectedCard(String cardText, Rect reject, float amount, float miles,
                                    String reason, boolean fastSource, long evidenceAt,
                                    boolean inferredReject) {
        handleRejectedCard(cardText, reject, amount, miles, reason, fastSource, evidenceAt,
                inferredReject, null);
    }

    private void handleRejectedCard(String cardText, Rect reject, float amount, float miles,
                                    String reason, boolean fastSource, long evidenceAt,
                                    boolean inferredReject,
                                    TapAccessibilityService.FastOfferSnapshot fastSnapshot) {
        String fingerprint = CardText.identity(cardText);
        java.util.function.Consumer<String> report = offerReporter(cardText);
        if (!fingerprint.equals(lastLoggedIneligibleFingerprint)) {
            lastLoggedIneligibleFingerprint = fingerprint;
            appendIgnoredRecord(amount, miles, reason, cardText);
        }
        if (prefs.getBoolean("dryRun", false)) {
            clearPendingIgnore();
            report.accept(String.format(Locale.US, "测试未Ignore：$%.2f / %.1f mi，%s", amount, miles, reason));
            return;
        }
        if (!prefs.getBoolean("autoIgnore", true)) {
            clearPendingIgnore();
            report.accept(String.format(Locale.US, "未接：$%.2f / %.1f mi，%s", amount, miles, reason));
            return;
        }

        long now = SystemClock.elapsedRealtime();
        RejectSequence.State state = rejectSequence.observe(fingerprint, now);
        if (state == RejectSequence.State.HOLD) {
            if (rejectSequence.markHoldReported(fingerprint, now)) {
                report.accept("REJECT_NOT_CONFIRMED：同一顶部订单已完成2次Reject尝试仍可见；停止继续点击，保持第一卡锁定直到卡片变化/消失");
            }
            return;
        }
        // v2.10.20: ACTION_CLICK was followed by a positive UI acknowledgement that Reject
        // became disabled/processing. Do not let OCR or Accessibility fire a second logical
        // reject merely because the card remains visible during the server transition.
        if (state == RejectSequence.State.PROCESSING) return;
        if (state == RejectSequence.State.WAIT) return;

        // A mirror-derived coordinate is acceptable only as a first-resort fallback. If a
        // previous real Reject dispatch already happened, a retry must regain an explicit
        // Accessibility/OCR Reject target instead of guessing the left-side coordinate again.
        if (inferredReject && rejectSequence.attempts(fingerprint, now) > 0) {
            report.accept("Reject重试未找到明确按钮；已禁止再次使用Accept镜像坐标，等待Accessibility/新OCR帧重新定位");
            return;
        }

        if (reject == null || reject.isEmpty()) {
            report.accept("订单不符合，但动作行也无法从Accessibility/OCR/视觉几何定位；未点击");
            return;
        }
        if (!ActionGeometry.plausibleActionRect(width, height,
                reject.left, reject.top, reject.right, reject.bottom, false)) {
            report.accept("订单不符合，但Reject热区几何异常（疑似卡片/详情容器）；为防误点已取消");
            lastReadableFastScan = 0;
            return;
        }
        float x = ActionGeometry.stableTapX(width, reject.exactCenterX(), false);
        float y = reject.exactCenterY();
        // v2.10.21: the final reservation must be atomic with READY validation. OCR and
        // Accessibility run on different handlers and can reach this point from the same
        // physical card within the same few milliseconds. A separate observe()+sent() pair
        // allowed both paths to dispatch once. Only the winner of this reservation may tap.
        int rejectAttempt = rejectSequence.reserveIfReady(fingerprint, now);
        if (rejectAttempt == 0) return;
        cooldownUntil = now + 1_200;
        clearPendingIgnore();
        final long rejectEpoch = claimEpoch.incrementAndGet();
        serialTopText = cardText;
        serialTopActionAt = now;
        serialTopAction = SerialAction.REJECT;
        rejectProcessingConfirmedAt = 0;
        acceptProcessingConfirmedAt = 0;
        pendingAcceptJobsBaseline = -1;
        lastActionDispatchAt = now;
        accessibilityActionHoldUntil = now + 700;
        rejectTransitionSuppressUntil = now + 1400;

        if (inferredReject) {
            report.accept(String.format(Locale.US,
                    "拒绝文字未识别；由同排Accept位置推定左侧Reject坐标：$%.2f / %.1f mi；帧龄%dms",
                    amount, miles, evidenceAt > 0 ? ScanPolicy.actionAge(SystemClock.elapsedRealtime(), evidenceAt) : -1));
        }

        java.util.function.Consumer<String> completed = actionDetail -> {
            String rejectSource = fastSource ? "Accessibility顶部热区"
                    : (inferredReject ? "OCR镜像热区" : "OCR语义热区");
            String detail = actionDetail == null ? "动作详情未知" : actionDetail;
            if (detail.contains("Reject已禁用/处理中")
                    || detail.contains("旧卡/Reject状态已变化")) {
                rejectProcessingConfirmedAt = SystemClock.elapsedRealtime();
            }
            report.accept(String.format(Locale.US,
                    "顶部拒绝第%d次动作已发送：来源=%s；%s；原始rect=[%d,%d,%d,%d] tap=(%d,%d) $%.2f / %.1f mi；等待本卡消失/倒计时结束",
                    rejectAttempt, rejectSource, detail,
                    reject.left, reject.top, reject.right, reject.bottom, Math.round(x), Math.round(y),
                    amount, miles));
            cooldownUntil = SystemClock.elapsedRealtime() + 420;
            if (fastWorker != null) {
                fastWorker.postDelayed(() -> inspectReject(cardText, rejectEpoch, 0), 140);
                fastWorker.postDelayed(() -> {
                    if (!monitorReady) return;
                    lastScan = 0;
                    requestImmediateFastCheck(SystemClock.uptimeMillis());
                }, 450);
                fastWorker.postDelayed(() -> {
                    if (monitorReady) requestImmediateFastCheck(SystemClock.uptimeMillis());
                }, 980);
            }
        };
        java.util.function.Consumer<String> failed = failureReason -> {
            accessibilityActionHoldUntil = 0;
            cooldownUntil = 0;
            rejectSequence.failed(fingerprint, SystemClock.elapsedRealtime());
            if (rejectEpoch == claimEpoch.get() && serialTopAction == SerialAction.REJECT
                    && CardText.sameOffer(serialTopText, cardText)) {
                serialTopText = "";
                serialTopActionAt = 0;
                serialTopAction = SerialAction.NONE;
                rejectProcessingConfirmedAt = 0;
            }
            report.accept("拒绝未执行：" + failureReason + "；本次未计入Reject次数");
            lastScan = 0;
            requestImmediateFastCheck(SystemClock.uptimeMillis());
        };

        if (fastSource) {
            // v2.10.9: use the SAME first-card snapshot that made the rule decision.
            // Do not perform findOffer() here: that is another full multi-window tree walk
            // and was adding hundreds of milliseconds before Ignore. tapSnapshotRejectFast
            // now performs its own bounded stale-snapshot refresh when necessary.
            if (fastSnapshot != null && !fastSnapshot.rejectBounds.isEmpty()) {
                TapAccessibilityService.tapSnapshotRejectFast(
                        fastSnapshot, amount, miles, completed, failed);
            } else {
                TapAccessibilityService.ignoreIfOfferStillMatches(
                        x, y, amount, miles, cardText,
                        () -> completed.accept("verified Gesture" + ActionDispatchPolicy.firstGestureDurationMs(false) + "ms"),
                        failed);
            }
        } else {
            // v2.9.3 critical fix: OCR already found the Reject coordinate in the failing
            // screenshot, but v2.9.2 then required the same Reject to exist as an
            // Accessibility node and refused to click. Use the same fresh-coordinate
            // verified fallback as Accept instead.
            TapAccessibilityService.tapOcrReject(
                    reject, amount, miles, evidenceAt, cardText, completed, failed);
        }
    }

    private void clearPendingIgnore() {
        pendingIgnoreFingerprint = "";
        pendingIgnoreSince = 0;
    }

    private void clearPendingAccept() {
        pendingAcceptFingerprint = "";
        pendingAcceptConfirmations = 0;
    }

    private void appendIgnoredRecord(float amount, float miles, String reason, String cardText) {
        String when = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date());
        String entry = String.format(Locale.US, "%s｜$%.2f / %.1f mi｜%s\n%s",
                when, amount, miles, reason, compactOfferText(cardText));
        String history = prefs.getString("ignoredHistory", "");
        history = history.isEmpty() ? entry : entry + "\n\n" + history;
        if (history.length() > 7000) history = history.substring(0, 7000);
        prefs.edit().putString("ignoredHistory", history).apply();
        updateOfferStatus("规则未通过：$" + String.format(Locale.US, "%.2f / %.1f mi，", amount, miles)
                + reason, cardText);
    }

    private String compactOfferText(String text) {
        if (text == null) return "";
        String clean = text.replaceAll("\\s+", " ").trim();
        return clean.length() > 360 ? clean.substring(0, 360) + "…" : clean;
    }

    private String textNearButton(Text result, Rect button) {
        if (button == null) return "";
        List<CardText.Piece> pieces = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                if (line.getBoundingBox() == null) continue;
                Rect box = line.getBoundingBox();
                pieces.add(new CardText.Piece(line.getText(), box.left, box.top, box.bottom));
            }
        }
        return CardText.aboveButton(pieces, button.top, button.bottom);
    }

    private float offerLowAmount(String text) {
        Matcher range = MONEY_RANGE.matcher(text.replace(',', '.'));
        if (range.find()) {
            try { return Float.parseFloat(range.group(1).replace(',', '.')); }
            catch (NumberFormatException ignored) { }
        }
        Matcher matcher = MONEY.matcher(text.replace(',', '.'));
        if (!matcher.find()) return -1f;
        try { return Float.parseFloat(matcher.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    private float offerMiles(String text) {
        Matcher matcher = MILES.matcher(text.replace(',', '.'));
        if (!matcher.find()) return -1f;
        try { return Float.parseFloat(matcher.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    private boolean containsAllowedCity(String text) {
        String lower = text.toLowerCase(Locale.US);
        String configuredValue = prefs.getString("cities", "").trim();
        // Blank means that city filtering is disabled.
        if (configuredValue.isEmpty()) return true;
        String[] configured = configuredValue.split(",");
        List<String> cities = new ArrayList<>();
        for (String city : configured) {
            String clean = city.trim().toLowerCase(Locale.US);
            if (!clean.isEmpty()) cities.add(clean);
        }
        if (cities.isEmpty()) return false;
        for (String city : cities) if (lower.contains(city)) return true;
        return false;
    }

    private boolean offerTimeAllowed(String text) {
        try {
            String configuredStart = prefs.getString("startTime", "").trim();
            String configuredEnd = prefs.getString("endTime", "").trim();
            // Blank/incomplete time fields mean that time filtering is disabled.
            if (configuredStart.isEmpty() || configuredEnd.isEmpty()) return true;
            Matcher matcher = OFFER_TIME.matcher(text);
            if (!matcher.find()) return false;
            DateTimeFormatter offerFormat = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
            LocalTime offer = LocalTime.parse(
                    matcher.group(1) + " " + matcher.group(2).toUpperCase(Locale.US), offerFormat);
            DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
            LocalTime start = LocalTime.parse(configuredStart, f);
            LocalTime end = LocalTime.parse(configuredEnd, f);
            if (end.isAfter(start) || end.equals(start)) return !offer.isBefore(start) && !offer.isAfter(end);
            return !offer.isBefore(start) || !offer.isAfter(end);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void playAlert() {
        try {
            AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION,
                    audio.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION), 0);
            Ringtone tone = RingtoneManager.getRingtone(this,
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
            tone.play();
        } catch (Exception ignored) { }
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL,
                "OCR monitor", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    private Notification statusNotification(String status) {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String expanded = status;
        if (expanded.length() > 3500) expanded = expanded.substring(0, 3500);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Catering Screen Assistant")
                .setContentText(status)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(expanded))
                .setOngoing(true)
                .setContentIntent(open)
                .build();
    }

    private void updateStatus(String status) {
        logWriter.execute(() -> writeStatus(status));
    }

    private void writeStatus(String status) {
        if (!monitorReady && activeInstance != this) return;
        if (status.equals(prefs.getString("lastStatus", ""))) return;
        prefs.edit()
                .putString("lastStatus", status)
                .putLong("lastStatusAt", System.currentTimeMillis())
                .apply();
        getSystemService(NotificationManager.class).notify(NOTIFICATION_ID, statusNotification(status));
    }

    private String lastEventKey = "";
    private java.util.function.Consumer<String> offerReporter(String cardText) {
        final String rules = ruleSummary();
        final String timing = scanTiming;
        final long started = SystemClock.elapsedRealtime();
        return message -> updateOfferStatus(message + "\n本次处理：" + timing + "；判断至记录"
                + (SystemClock.elapsedRealtime() - started) + "ms", cardText, rules);
    }

    private String ruleSummary() {
        return "普通≥$" + prefs.getFloat("minPay",25f) + " / ≤" + prefs.getFloat("maxMiles",12f)
                + "mi；Pasadena启用=" + prefs.getBoolean("pasadenaRuleEnabled",false)
                + " ≥$" + prefs.getFloat("pasadenaMinPay",25f) + " / ≤" + prefs.getFloat("pasadenaMaxMiles",12f)
                + "mi；城市=" + prefs.getString("cities", "") + "；时间=" + prefs.getString("startTime", "")
                + "–" + prefs.getString("endTime", "");
    }

    private void updateOfferStatus(String status, String cardText) {
        updateOfferStatus(status, cardText, ruleSummary());
    }

    private synchronized void updateOfferStatus(String status, String cardText, String rules) {
        if (!isMonitoring()) return;
        String identity = CardText.identity(cardText);
        String eventKey = identity + "|" + status.split("\\n本次处理：", 2)[0];
        if (eventKey.equals(lastEventKey)) return;
        lastEventKey = eventKey;
        String id = Integer.toHexString(identity.hashCode());
        String event = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(new Date())
                + "｜卡片#" + id + "\n" + status + "\n本次卡片：" + cardText
                + "\n本次规则：" + rules;
        logWriter.execute(() -> {
        if (!monitorReady) return;
        try {
            org.json.JSONArray history = new org.json.JSONArray(prefs.getString("decisionEvents", "[]"));
            org.json.JSONArray next = new org.json.JSONArray();
            next.put(event);
            for (int i = 0; i < Math.min(99, history.length()); i++) next.put(history.getString(i));
            prefs.edit().putString("decisionEvents", next.toString()).putString("lastDecision", event).apply();
        } catch (org.json.JSONException ignored) {
            prefs.edit().putString("lastDecision", event).apply();
        }
        writeStatus(event);
        });
    }

    @Override
    public void onDestroy() {
        monitorReady = false;
        if (worker != null) worker.removeCallbacksAndMessages(null);
        if (fastWorker != null) fastWorker.removeCallbacksAndMessages(null);
        if (activeInstance == this) activeInstance = null;
        if (virtualDisplay != null) virtualDisplay.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (recognizer != null) recognizer.close();
        if (roiPaddedBuffer != null && !roiPaddedBuffer.isRecycled()) roiPaddedBuffer.recycle();
        if (roiExactBuffer != null && roiExactBuffer != roiPaddedBuffer && !roiExactBuffer.isRecycled()) roiExactBuffer.recycle();
        roiPaddedBuffer = null;
        roiExactBuffer = null;
        if (workerThread != null) workerThread.quitSafely();
        if (fastThread != null) fastThread.quitSafely();
        logWriter.shutdownNow();
        super.onDestroy();
    }
}
