package com.local.cateringscreenassistant;

import java.util.Locale;

final class ButtonLabels {
    static boolean isReject(CharSequence text) {
        if (text == null) return false;
        String value = text.toString().toLowerCase(Locale.US).trim().replaceAll("[\\s_\\-]+", " ");
        return value.equals("ignore") || value.equals("decline") || value.equals("reject")
                || value.equals("ignore button") || value.equals("decline button") || value.equals("reject button")
                || value.equals("button ignore") || value.equals("button decline") || value.equals("button reject");
    }
}
