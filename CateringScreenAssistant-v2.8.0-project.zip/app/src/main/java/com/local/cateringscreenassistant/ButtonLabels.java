package com.local.cateringscreenassistant;

import java.util.Locale;

final class ButtonLabels {
    /**
     * Hot-path reject-label matcher. Older builds normalized every Accessibility node with
     * String.replaceAll(), which allocates regex machinery dozens of times per quick-tree walk.
     * DeliverThat uses a tiny fixed vocabulary, so a small allocation-light normalizer is both
     * safer and measurably cheaper on low-end Samsung devices.
     */
    static boolean isReject(CharSequence text) {
        if (text == null) return false;
        String value = normalizeWords(text);
        switch (value) {
            case "ignore": case "decline": case "reject":
            case "ignore button": case "decline button": case "reject button":
            case "button ignore": case "button decline": case "button reject":
            case "ignore offer": case "decline offer": case "reject offer":
            case "ignore delivery": case "decline delivery": case "reject delivery":
            case "ignore job": case "decline job": case "reject job":
                return true;
            default:
                return false;
        }
    }

    private static String normalizeWords(CharSequence raw) {
        int length = raw.length();
        StringBuilder out = new StringBuilder(length);
        boolean pendingSpace = false;
        for (int i = 0; i < length; i++) {
            char c = raw.charAt(i);
            if (c >= 'A' && c <= 'Z') c = (char) (c + ('a' - 'A'));
            boolean letter = c >= 'a' && c <= 'z';
            if (letter) {
                if (pendingSpace && out.length() > 0) out.append(' ');
                out.append(c);
                pendingSpace = false;
            } else if (Character.isWhitespace(c) || c == '_' || c == '-') {
                if (out.length() > 0) pendingSpace = true;
            } else {
                // Punctuation is treated as a separator as well. This preserves the previous
                // exact-vocabulary behavior without regex allocation.
                if (out.length() > 0) pendingSpace = true;
            }
        }
        return out.toString();
    }
}
