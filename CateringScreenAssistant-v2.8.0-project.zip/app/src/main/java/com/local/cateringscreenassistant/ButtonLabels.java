package com.local.cateringscreenassistant;

import java.util.Locale;

final class ButtonLabels {
    static boolean isReject(CharSequence text) {
        if (text == null) return false;
        String value = text.toString().toLowerCase(Locale.US).trim().replaceAll("[\\s_\\-]+", " ");
        switch (value) {
            case "ignore": case "decline": case "reject":
            case "ignore button": case "decline button": case "reject button":
            case "button ignore": case "button decline": case "button reject":
            case "ignore offer": case "decline offer": case "reject offer":
            case "ignore delivery": case "decline delivery": case "reject delivery":
            case "ignore job": case "decline job": case "reject job":
                return true;
            default:
                return false;
        }
    }
}
