package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

final class CardText {
    static final Pattern MONEY = Pattern.compile("(?:\\$|USD\\s*)\\s*\\d", Pattern.CASE_INSENSITIVE);
    static final Pattern MILES = Pattern.compile("\\d(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern ACTION_WORDS = Pattern.compile(
            "\\b(?:accept|claim|ignore|decline|reject)(?:\\s+button)?\\b|\\bbutton\\s+(?:accept|claim|ignore|decline|reject)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPIRES_CLOCK = Pattern.compile(
            "\\bexpires(?:\\s+in)?\\s*:?\\s*\\d{1,2}:\\d{2}(?::\\d{2})?\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPIRES_SECONDS = Pattern.compile(
            "\\bexpires(?:\\s+in)?\\s*:?\\s*\\d+\\s*(?:s|sec|secs|second|seconds)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY_VALUE = Pattern.compile(
            "(?:\\$|usd\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MILES_VALUE = Pattern.compile(
            "(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);

    static final class Piece {
        final String text;
        final float left, top, bottom;
        Piece(String text, float left, float top, float bottom) {
            this.text = text; this.left = left; this.top = top; this.bottom = bottom;
        }
    }

    static String aboveButton(List<Piece> pieces, float buttonTop, float buttonBottom) {
        // Use the previous action row as the hard upper-card boundary. Without this,
        // if the current card temporarily loses its amount/distance accessibility node,
        // v2.7 could accidentally reuse numbers from the card above it.
        float previousActionBottom = Float.NEGATIVE_INFINITY;
        for (Piece p : pieces) {
            if (p.bottom < buttonTop && ACTION_WORDS.matcher(p.text).find())
                previousActionBottom = Math.max(previousActionBottom, p.bottom);
        }
        Piece pay = null, miles = null;
        for (Piece p : pieces) {
            if (p.bottom > buttonTop || p.top < previousActionBottom) continue;
            if (MONEY.matcher(p.text).find() && (pay == null || p.top > pay.top)) pay = p;
            if (MILES.matcher(p.text).find() && (miles == null || p.top > miles.top)) miles = p;
        }
        if (pay == null || miles == null) return "";
        float rowHeight = Math.max(pay.bottom - pay.top, miles.bottom - miles.top);
        if (Math.abs(pay.top - miles.top) > Math.max(8, rowHeight * 2)) return "";
        float start = Math.min(pay.top, miles.top);
        List<Piece> sorted = new ArrayList<>(pieces);
        sorted.sort(Comparator.comparingDouble((Piece p) -> p.top).thenComparingDouble(p -> p.left));
        StringBuilder out = new StringBuilder();
        // The button row is UI state, not order content. Excluding it prevents a
        // transient Accept/Decline disabled/label change from changing card identity.
        float contentEnd = buttonTop + 2f;
        for (Piece p : sorted) {
            if (p.top >= start && p.bottom <= contentEnd) out.append(p.text).append(' ');
        }
        return out.toString().trim();
    }

    static String identity(String text) {
        return normalizeStable(text);
    }

    static boolean sameOffer(String expected, String actual) {
        String a = normalizeStable(expected);
        String b = normalizeStable(actual);
        if (a.isEmpty() || b.isEmpty()) return false;
        if (!sameCapturedValue(MONEY_VALUE, a, b) || !sameCapturedValue(MILES_VALUE, a, b)) return false;
        if (a.equals(b)) return true;

        // Accessibility trees sometimes duplicate/omit content-description nodes
        // between frames. Numeric values are independently verified before clicking;
        // this comparison only tolerates duplicate/missing stable descriptive tokens.
        Set<String> aa = tokens(a), bb = tokens(b);
        if (aa.isEmpty() || bb.isEmpty()) return false;
        int overlap = 0;
        for (String token : aa) if (bb.contains(token)) overlap++;
        int smaller = Math.min(aa.size(), bb.size());
        return smaller >= 4 && ((double) overlap / smaller) >= 0.92d;
    }

    private static String normalizeStable(String text) {
        if (text == null) return "";
        String value = text.toLowerCase(Locale.US);
        value = EXPIRES_CLOCK.matcher(value).replaceAll(" ");
        value = EXPIRES_SECONDS.matcher(value).replaceAll(" ");
        value = ACTION_WORDS.matcher(value).replaceAll(" ");
        return value.replaceAll("[|•·]+", " ").replaceAll("\\s+", " ").trim();
    }


    private static boolean sameCapturedValue(Pattern pattern, String a, String b) {
        java.util.regex.Matcher ma = pattern.matcher(a), mb = pattern.matcher(b);
        if (!ma.find() || !mb.find()) return false;
        return ma.group(1).replace(',', '.').equals(mb.group(1).replace(',', '.'));
    }

    private static Set<String> tokens(String value) {
        Set<String> out = new HashSet<>();
        for (String token : value.split("[^a-z0-9$.:]+")) {
            if (token.length() >= 2) out.add(token);
        }
        return out;
    }
}
