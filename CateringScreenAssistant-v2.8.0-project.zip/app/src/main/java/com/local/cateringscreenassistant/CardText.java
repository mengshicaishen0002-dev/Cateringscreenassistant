package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

final class CardText {
    static final Pattern MONEY = Pattern.compile("(?:\\$|USD\\s*)\\s*\\d", Pattern.CASE_INSENSITIVE);
    static final Pattern MILES = Pattern.compile("\\d(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern ACTION_WORDS = Pattern.compile(
            "\\b(?:accept|claim|ignore|decline|reject)(?:\\s+button)?\\b|\\bbutton\\s+(?:accept|claim|ignore|decline|reject)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPIRES_CLOCK = Pattern.compile(
            "\\bexpires(?:\\s+in)?\\s*:?\\s*\\d{1,2}:\\d{2}(?::\\d{2})?\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPIRES_SECONDS = Pattern.compile(
            "\\bexpires(?:\\s+in)?\\s*:?\\s*\\d+\\s*(?:s|sec|secs|second|seconds)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY_VALUE = Pattern.compile(
            "(?:\\$|usd\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MILES_VALUE = Pattern.compile(
            "(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern OFFER_TIME_VALUE = Pattern.compile(
            "\\b((?:today|tomorrow)|(?:january|february|march|april|may|june|july|august|september|october|november|december)\\s+\\d{1,2})"
                    + "\\s*(?:at)?\\s*(\\d{1,2}:\\d{2})\\s*(am|pm)\\b", Pattern.CASE_INSENSITIVE);

    static final class Piece {
        final String text;
        final float left, top, bottom;
        Piece(String text, float left, float top, float bottom) {
            this.text = text; this.left = left; this.top = top; this.bottom = bottom;
        }
    }

    static String aboveButton(List<Piece> pieces, float buttonTop, float buttonBottom) {
        // Use the previous action row as the hard upper-card boundary. Without this,
        // if the current card temporarily loses its amount/distance accessibility node,
        // v2.7 could accidentally reuse numbers from the card above it.
        float previousActionBottom = Float.NEGATIVE_INFINITY;
        for (Piece p : pieces) {
            if (p.bottom < buttonTop && ACTION_WORDS.matcher(p.text).find())
                previousActionBottom = Math.max(previousActionBottom, p.bottom);
        }
        Piece pay = null, miles = null;
        for (Piece p : pieces) {
            if (p.bottom > buttonTop || p.top < previousActionBottom) continue;
            if (MONEY.matcher(p.text).find() && (pay == null || p.top > pay.top)) pay = p;
            if (MILES.matcher(p.text).find() && (miles == null || p.top > miles.top)) miles = p;
        }
        if (pay == null || miles == null) return "";
        float rowHeight = Math.max(pay.bottom - pay.top, miles.bottom - miles.top);
        if (Math.abs(pay.top - miles.top) > Math.max(8, rowHeight * 2)) return "";
        float start = Math.min(pay.top, miles.top);
        List<Piece> sorted = new ArrayList<>(pieces);
        sorted.sort(Comparator.comparingDouble((Piece p) -> p.top).thenComparingDouble(p -> p.left));
        StringBuilder out = new StringBuilder();
        // The button row is UI state, not order content. Excluding it prevents a
        // transient Accept/Decline disabled/label change from changing card identity.
        float contentEnd = buttonTop + 2f;
        for (Piece p : sorted) {
            if (p.top < start || p.bottom > contentEnd) continue;
            String candidate = p.text == null ? "" : p.text.replaceAll("\\s+", " ").trim();
            if (candidate.isEmpty()) continue;
            // React-Native frequently exports one parent contentDescription containing the
            // whole card and then exports its child labels again. If a later child phrase is
            // already present verbatim in the accumulated parent text, appending it only
            // bloats identity/logging and makes the next comparison more expensive.
            if (out.indexOf(candidate) >= 0) continue;
            out.append(candidate).append(' ');
        }
        return out.toString().trim();
    }

    /** Parse the first/low-end offer amount once for decision-ready snapshots. */
    static float amount(String text) {
        if (text == null) return -1f;
        java.util.regex.Matcher m = MONEY_VALUE.matcher(text.replace(',', '.'));
        if (!m.find()) return -1f;
        try { return Float.parseFloat(m.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    /** Parse DeliverThat delivery distance once for decision-ready snapshots. */
    static float miles(String text) {
        if (text == null) return -1f;
        java.util.regex.Matcher m = MILES_VALUE.matcher(text.replace(',', '.'));
        if (!m.find()) return -1f;
        try { return Float.parseFloat(m.group(1).replace(',', '.')); }
        catch (NumberFormatException ignored) { return -1f; }
    }

    static String identity(String text) {
        String stable = normalizeStable(text);
        if (stable.isEmpty()) return stable;
        String money = captured(MONEY_VALUE, stable);
        String miles = captured(MILES_VALUE, stable);
        if (money.isEmpty() || miles.isEmpty()) return stable;

        String time = "";
        java.util.regex.Matcher tm = OFFER_TIME_VALUE.matcher(stable);
        int tailStart = -1;
        if (tm.find()) {
            time = tm.group(1).toLowerCase(Locale.US).replaceAll("\\s+", "") + "-"
                    + tm.group(2).toLowerCase(Locale.US) + tm.group(3).toLowerCase(Locale.US);
            tailStart = tm.end();
        }
        String merchant = merchantKey(stable, tailStart);
        return "pay=" + money + "|mi=" + miles + "|time=" + time + "|merchant=" + merchant;
    }

    private static String captured(Pattern pattern, String value) {
        java.util.regex.Matcher m = pattern.matcher(value);
        if (!m.find()) return "";
        return m.group(1).replace(',', '.').toLowerCase(Locale.US);
    }

    /**
     * Stable descriptive key used only for identity/dedupe. DeliverThat frequently duplicates
     * address/content-description nodes between adjacent frames, so the full OCR/tree string is
     * intentionally excluded. Prefer the merchant phrase immediately after Today/Tomorrow time;
     * otherwise use a short sorted token signature.
     */
    private static String merchantKey(String stable, int tailStart) {
        String candidate = "";
        if (tailStart >= 0 && tailStart < stable.length()) {
            candidate = stable.substring(tailStart).trim();
            int bullet = candidate.indexOf('•');
            if (bullet >= 0) candidate = candidate.substring(0, bullet);
            java.util.regex.Matcher repeatedTime = OFFER_TIME_VALUE.matcher(candidate);
            if (repeatedTime.find()) candidate = candidate.substring(0, repeatedTime.start());
            candidate = candidate.replaceFirst("^[-–—,:\\s]+", "");
            // Normalize OCR-collapsed street suffix spacing (e.g. 300S -> 300 S) before address stripping.
            candidate = candidate.replaceAll("(?<=\\d)(?=[a-z])", " ");
            candidate = candidate.replaceFirst("\\s+[-–—]\\s+\\d.*$", "");
            candidate = candidate.replaceFirst("\\s+\\d{2,5}\\s+.*$", "");
            candidate = candidate.replaceAll("[^a-z0-9 ]+", " ").replaceAll("\\s+", " ").trim();
            if (candidate.length() > 64) candidate = candidate.substring(0, 64).trim();
        }
        if (!candidate.isEmpty()) return candidate;

        java.util.List<String> tokens = new java.util.ArrayList<>(descriptiveTokens(stable));
        java.util.Collections.sort(tokens);
        StringBuilder out = new StringBuilder();
        for (String token : tokens) {
            if (out.length() > 0) out.append('-');
            out.append(token);
            if (out.length() >= 48) break;
        }
        return out.toString();
    }

    /**
     * v2.10.28 cross-source matcher used only to repair OCR numeric drift from a fresh
     * Accessibility representation of the same card. Amount remains exact; mileage is
     * intentionally excluded from the comparison so a lost decimal (0.7 -> 7) can be corrected
     * from the independent source. Descriptive overlap is still required.
     */
    static boolean sameOfferIgnoringMiles(String expected, String actual) {
        String a = identity(expected);
        String b = identity(actual);
        if (!a.startsWith("pay=") || !b.startsWith("pay=")) return false;
        // identity() already binds pay + pickup time + merchant. Strip only mileage so an
        // independently read 0.7 mi can correct OCR's 7 mi without ever merging two merchants,
        // pickup times or pay values.
        String aWithoutMiles = a.replaceFirst("\\|mi=[^|]*", "");
        String bWithoutMiles = b.replaceFirst("\\|mi=[^|]*", "");
        return aWithoutMiles.equals(bWithoutMiles);
    }

    static boolean sameOffer(String expected, String actual) {
        String a = normalizeStable(expected);
        String b = normalizeStable(actual);
        if (a.isEmpty() || b.isEmpty()) return false;
        if (!sameCapturedValue(MONEY_VALUE, a, b) || !sameCapturedValue(MILES_VALUE, a, b)) return false;
        if (a.equals(b)) return true;

        // Accessibility trees sometimes duplicate/omit content-description nodes
        // between frames. Numeric values are independently verified before clicking;
        // this comparison only tolerates duplicate/missing stable descriptive tokens.
        Set<String> aa = tokens(a), bb = tokens(b);
        if (aa.isEmpty() || bb.isEmpty()) return false;
        int overlap = 0;
        for (String token : aa) if (bb.contains(token)) overlap++;
        int smaller = Math.min(aa.size(), bb.size());
        return smaller >= 4 && ((double) overlap / smaller) >= 0.92d;
    }


    /**
     * Revalidation matcher for the already-isolated top action row.
     * OCR/accessibility descriptions on DeliverThat can add/drop duplicate descriptive
     * nodes between two adjacent frames. For an actual tap we keep money+miles exact,
     * then allow a looser descriptive overlap than sameOffer(). This prevents a harmless
     * tree mutation from cancelling the action while still rejecting a different card
     * whose numeric values changed.
     */
    static boolean sameOfferForAction(String expected, String actual) {
        String a = normalizeStable(expected);
        String b = normalizeStable(actual);
        if (a.isEmpty() || b.isEmpty()) return false;
        if (!sameCapturedValue(MONEY_VALUE, a, b) || !sameCapturedValue(MILES_VALUE, a, b)) return false;
        if (a.equals(b) || sameOffer(a, b)) return true;

        Set<String> aa = descriptiveTokens(a), bb = descriptiveTokens(b);
        if (aa.isEmpty() || bb.isEmpty()) {
            // The numeric pair is independently revalidated immediately before the gesture.
            // If one side lost all descriptive accessibility nodes, do not treat that alone
            // as a different top card.
            return true;
        }
        int overlap = 0;
        for (String token : aa) if (bb.contains(token)) overlap++;
        int smaller = Math.min(aa.size(), bb.size());
        if (overlap >= 2) return true;
        return smaller == 1 && overlap == 1;
    }

    private static Set<String> descriptiveTokens(String value) {
        Set<String> out = new HashSet<>();
        for (String token : value.split("[^a-z0-9]+")) {
            if (token.length() < 3 || token.matches("\\d+(?:\\.\\d+)?")) continue;
            if (token.equals("est") || token.equals("mi") || token.equals("mins")
                    || token.equals("min") || token.equals("today") || token.equals("tomorrow")
                    || token.equals("delivery") || token.equals("pickup") || token.equals("dropoff")
                    || token.equals("united") || token.equals("states") || token.equals("the")
                    || token.equals("and") || token.equals("for")) continue;
            out.add(token);
        }
        return out;
    }

    private static String normalizeStable(String text) {
        if (text == null) return "";
        String value = text.toLowerCase(Locale.US);
        value = EXPIRES_CLOCK.matcher(value).replaceAll(" ");
        value = EXPIRES_SECONDS.matcher(value).replaceAll(" ");
        value = ACTION_WORDS.matcher(value).replaceAll(" ");
        return value.replaceAll("[|•·]+", " ").replaceAll("\\s+", " ").trim();
    }


    private static boolean sameCapturedValue(Pattern pattern, String a, String b) {
        java.util.regex.Matcher ma = pattern.matcher(a), mb = pattern.matcher(b);
        if (!ma.find() || !mb.find()) return false;
        return ma.group(1).replace(',', '.').equals(mb.group(1).replace(',', '.'));
    }

    private static Set<String> tokens(String value) {
        Set<String> out = new HashSet<>();
        for (String token : value.split("[^a-z0-9$.:]+")) {
            if (token.length() >= 2) out.add(token);
        }
        return out;
    }
}
