package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

final class CardText {
    static final Pattern MONEY = Pattern.compile("(?:\\$|USD\\s*)\\s*\\d", Pattern.CASE_INSENSITIVE);
    static final Pattern MILES = Pattern.compile("\\d(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern ACTION_WORDS = Pattern.compile(
            "\\b(?:accept|claim|ignore|decline|reject)(?:\\s+button)?\\b|\\bbutton\\s+(?:accept|claim|ignore|decline|reject)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPIRES_CLOCK = Pattern.compile(
            "\\bexpires(?:\\s+in)?\\s*:?\\s*\\d{1,2}:\\d{2}(?::\\d{2})?\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPIRES_SECONDS = Pattern.compile(
            "\\bexpires(?:\\s+in)?\\s*:?\\s*\\d+\\s*(?:s|sec|secs|second|seconds)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern MONEY_VALUE = Pattern.compile(
            "(?:\\$|usd\\s*)(\\d{1,4}(?:[.,]\\d{1,2})?)", Pattern.CASE_INSENSITIVE);
    private static final Pattern MILES_VALUE = Pattern.compile(
            "(\\d{1,3}(?:[.,]\\d+)?)\\s*(?:mi|miles?)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern SCHEDULE_TIME = Pattern.compile(
            "\\b(today|tomorrow)\\s+at\\s+(\\d{1,2}:\\d{2})\\s*(am|pm)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern PICKUP_MERCHANT = Pattern.compile(
            "\\bpickup\\s+([a-z][a-z0-9 &'()./-]{2,60}?)(?=\\s+\\d{2,6}\\s+[a-z]|\\s*[•·|]|$)", Pattern.CASE_INSENSITIVE);

    static final class Piece {
        final String text;
        final float left, top, bottom;
        Piece(String text, float left, float top, float bottom) {
            this.text = text; this.left = left; this.top = top; this.bottom = bottom;
        }
    }

    static String aboveButton(List<Piece> pieces, float buttonTop, float buttonBottom) {
        // Use the previous action row as the hard upper-card boundary. Without this,
        // if the current card temporarily loses its amount/distance accessibility node,
        // v2.7 could accidentally reuse numbers from the card above it.
        float previousActionBottom = Float.NEGATIVE_INFINITY;
        for (Piece p : pieces) {
            if (p.bottom < buttonTop && ACTION_WORDS.matcher(p.text).find())
                previousActionBottom = Math.max(previousActionBottom, p.bottom);
        }
        Piece pay = null, miles = null;
        for (Piece p : pieces) {
            if (p.bottom > buttonTop || p.top < previousActionBottom) continue;
            if (MONEY.matcher(p.text).find() && (pay == null || p.top > pay.top)) pay = p;
            if (MILES.matcher(p.text).find() && (miles == null || p.top > miles.top)) miles = p;
        }
        if (pay == null || miles == null) return "";
        float rowHeight = Math.max(pay.bottom - pay.top, miles.bottom - miles.top);
        if (Math.abs(pay.top - miles.top) > Math.max(8, rowHeight * 2)) return "";
        float start = Math.min(pay.top, miles.top);
        List<Piece> sorted = new ArrayList<>(pieces);
        sorted.sort(Comparator.comparingDouble((Piece p) -> p.top).thenComparingDouble(p -> p.left));
        StringBuilder out = new StringBuilder();
        // The button row is UI state, not order content. Excluding it prevents a
        // transient Accept/Decline disabled/label change from changing card identity.
        float contentEnd = buttonTop + 2f;
        for (Piece p : sorted) {
            if (p.top >= start && p.bottom <= contentEnd) out.append(p.text).append(' ');
        }
        return out.toString().trim();
    }

    /**
     * Stable order fingerprint used for serial locking, retry budgets, alert de-dupe and logs.
     *
     * DeliverThat's Accessibility/OCR trees frequently duplicate the address, reorder "Est."
     * around the amount, or briefly drop descriptive nodes. Hashing the whole normalized string
     * therefore made one real order look like a new card on the next frame. The primary identity
     * is now built from fields that define the offer and stay stable across those mutations:
     * amount + miles + scheduled time + merchant/location core.
     *
     * We deliberately keep a descriptive fallback when one of the numeric fields is missing; an
     * incomplete frame must never collapse every card to the same key.
     */
    static String identity(String text) {
        String stable = normalizeStable(text);
        if (stable.isEmpty()) return "";

        String money = captured(MONEY_VALUE, stable);
        String miles = captured(MILES_VALUE, stable);
        if (money.isEmpty() || miles.isEmpty()) return stable;

        String time = scheduledTimeKey(stable);
        String merchant = merchantKey(stable);
        StringBuilder key = new StringBuilder(64)
                .append("$:").append(money)
                .append("|mi:").append(miles);
        if (!time.isEmpty()) key.append("|t:").append(time);
        if (!merchant.isEmpty()) key.append("|m:").append(merchant);

        // If neither time nor merchant could be recovered, retain a small canonical token
        // signature instead of using only amount+miles, which could merge two unrelated offers.
        if (time.isEmpty() && merchant.isEmpty()) {
            java.util.ArrayList<String> core = new java.util.ArrayList<>(descriptiveTokens(stable));
            java.util.Collections.sort(core);
            int limit = Math.min(6, core.size());
            for (int i = 0; i < limit; i++) key.append("|d:").append(core.get(i));
        }
        return key.toString();
    }

    static boolean sameOffer(String expected, String actual) {
        String a = normalizeStable(expected);
        String b = normalizeStable(actual);
        if (a.isEmpty() || b.isEmpty()) return false;
        if (!sameCapturedValue(MONEY_VALUE, a, b) || !sameCapturedValue(MILES_VALUE, a, b)) return false;
        String timeA = scheduledTimeKey(a), timeB = scheduledTimeKey(b);
        if (!timeA.isEmpty() && !timeB.isEmpty() && !timeA.equals(timeB)) return false;
        String merchantA = merchantKey(a), merchantB = merchantKey(b);
        if (!merchantA.isEmpty() && !merchantB.isEmpty() && !merchantA.equals(merchantB)) return false;
        if (a.equals(b)) return true;
        String stableA = identity(a), stableB = identity(b);
        if (!stableA.isEmpty() && stableA.equals(stableB)) return true;

        // Accessibility trees sometimes duplicate/omit content-description nodes
        // between frames. Numeric values are independently verified before clicking;
        // this comparison only tolerates duplicate/missing stable descriptive tokens.
        Set<String> aa = tokens(a), bb = tokens(b);
        if (aa.isEmpty() || bb.isEmpty()) return false;
        int overlap = 0;
        for (String token : aa) if (bb.contains(token)) overlap++;
        int smaller = Math.min(aa.size(), bb.size());
        return smaller >= 4 && ((double) overlap / smaller) >= 0.92d;
    }


    /**
     * Revalidation matcher for the already-isolated top action row.
     * OCR/accessibility descriptions on DeliverThat can add/drop duplicate descriptive
     * nodes between two adjacent frames. For an actual tap we keep money+miles exact,
     * then allow a looser descriptive overlap than sameOffer(). This prevents a harmless
     * tree mutation from cancelling the action while still rejecting a different card
     * whose numeric values changed.
     */
    static boolean sameOfferForAction(String expected, String actual) {
        String a = normalizeStable(expected);
        String b = normalizeStable(actual);
        if (a.isEmpty() || b.isEmpty()) return false;
        if (!sameCapturedValue(MONEY_VALUE, a, b) || !sameCapturedValue(MILES_VALUE, a, b)) return false;
        String timeA = scheduledTimeKey(a), timeB = scheduledTimeKey(b);
        if (!timeA.isEmpty() && !timeB.isEmpty() && !timeA.equals(timeB)) return false;
        String merchantA = merchantKey(a), merchantB = merchantKey(b);
        if (!merchantA.isEmpty() && !merchantB.isEmpty() && !merchantA.equals(merchantB)) return false;
        if (a.equals(b) || sameOffer(a, b)) return true;

        Set<String> aa = descriptiveTokens(a), bb = descriptiveTokens(b);
        if (aa.isEmpty() || bb.isEmpty()) {
            // The numeric pair is independently revalidated immediately before the gesture.
            // If one side lost all descriptive accessibility nodes, do not treat that alone
            // as a different top card.
            return true;
        }
        int overlap = 0;
        for (String token : aa) if (bb.contains(token)) overlap++;
        int smaller = Math.min(aa.size(), bb.size());
        if (overlap >= 2) return true;
        return smaller == 1 && overlap == 1;
    }

    private static Set<String> descriptiveTokens(String value) {
        Set<String> out = new HashSet<>();
        for (String token : value.split("[^a-z0-9]+")) {
            if (token.length() < 3 || token.matches("\\d+(?:\\.\\d+)?")) continue;
            if (token.equals("est") || token.equals("mi") || token.equals("mins")
                    || token.equals("min") || token.equals("today") || token.equals("tomorrow")
                    || token.equals("delivery") || token.equals("pickup") || token.equals("dropoff")
                    || token.equals("united") || token.equals("states") || token.equals("the")
                    || token.equals("and") || token.equals("for")) continue;
            out.add(token);
        }
        return out;
    }

    private static String normalizeStable(String text) {
        if (text == null) return "";
        String value = text.toLowerCase(Locale.US);
        value = EXPIRES_CLOCK.matcher(value).replaceAll(" ");
        value = EXPIRES_SECONDS.matcher(value).replaceAll(" ");
        value = ACTION_WORDS.matcher(value).replaceAll(" ");
        return value.replaceAll("[|•·]+", " ").replaceAll("\\s+", " ").trim();
    }


    private static String captured(Pattern pattern, String value) {
        java.util.regex.Matcher matcher = pattern.matcher(value);
        if (!matcher.find()) return "";
        return matcher.group(1).replace(',', '.').toLowerCase(Locale.US);
    }

    private static String scheduledTimeKey(String stable) {
        java.util.regex.Matcher matcher = SCHEDULE_TIME.matcher(stable);
        if (!matcher.find()) return "";
        return matcher.group(1).toLowerCase(Locale.US) + "-"
                + matcher.group(2) + matcher.group(3).toLowerCase(Locale.US);
    }

    /** Extract only the merchant/location core; never include a duplicated full address. */
    private static String merchantKey(String stable) {
        java.util.regex.Matcher pickup = PICKUP_MERCHANT.matcher(stable);
        if (pickup.find()) return compactMerchant(pickup.group(1));

        java.util.regex.Matcher time = SCHEDULE_TIME.matcher(stable);
        if (!time.find()) return "";
        String tail = stable.substring(time.end()).trim();
        // Accessibility can repeat the full card. Work only on the first post-time segment.
        int nextSchedule = indexOfSchedule(tail);
        if (nextSchedule > 0) tail = tail.substring(0, nextSchedule);
        tail = tail.replaceFirst("^[,;:|•·\\-\\s]+", "");
        tail = tail.replaceFirst("^(?:delivery\\s+timeline\\s+)?pickup\\s+", "");

        int cut = firstPositive(
                indexOfAny(tail, "•", "·", "|"),
                regexStart(tail, "\\s+-\\s+\\d{2,6}\\b"),
                regexStart(tail, "\\s+\\d{2,6}\\s+(?:(?:[nsew]\\s+)?[a-z0-9.'-]+\\s+){1,5}(?:st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|way|ln|lane|pkwy|parkway)\\b"),
                regexStart(tail, "\\s+\\d{1,3}(?:[.,]\\d+)?\\s*(?:mi|miles?)\\b"),
                regexStart(tail, "\\s+(?:est\\.?\\s*)?(?:\\$|usd\\s*)\\d"),
                regexStart(tail, "\\bexpires\\b"));
        if (cut > 0) tail = tail.substring(0, cut);
        return compactMerchant(tail);
    }

    private static int indexOfSchedule(String value) {
        java.util.regex.Matcher matcher = SCHEDULE_TIME.matcher(value);
        return matcher.find() ? matcher.start() : -1;
    }

    private static int regexStart(String value, String regex) {
        java.util.regex.Matcher matcher = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(value);
        return matcher.find() ? matcher.start() : -1;
    }

    private static int indexOfAny(String value, String... needles) {
        int best = -1;
        for (String needle : needles) {
            int at = value.indexOf(needle);
            if (at >= 0 && (best < 0 || at < best)) best = at;
        }
        return best;
    }

    private static int firstPositive(int... values) {
        int best = -1;
        for (int value : values) if (value > 0 && (best < 0 || value < best)) best = value;
        return best;
    }

    private static String compactMerchant(String value) {
        if (value == null) return "";
        value = value.toLowerCase(Locale.US)
                .replaceAll("[^a-z0-9&'()]+", " ")
                .replaceAll("\\s+", " ").trim();
        if (value.isEmpty()) return "";
        // Keep enough information to distinguish branches/merchants without letting a long
        // address mutation redefine the card identity.
        String[] parts = value.split(" ");
        StringBuilder out = new StringBuilder();
        int kept = 0;
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (kept++ >= 8) break;
            if (out.length() > 0) out.append('-');
            out.append(part);
        }
        return out.toString();
    }

    private static boolean sameCapturedValue(Pattern pattern, String a, String b) {
        java.util.regex.Matcher ma = pattern.matcher(a), mb = pattern.matcher(b);
        if (!ma.find() || !mb.find()) return false;
        return ma.group(1).replace(',', '.').equals(mb.group(1).replace(',', '.'));
    }

    private static Set<String> tokens(String value) {
        Set<String> out = new HashSet<>();
        for (String token : value.split("[^a-z0-9$.:]+")) {
            if (token.length() >= 2) out.add(token);
        }
        return out;
    }
}
