package com.local.cateringscreenassistant;

/** Pure timing/variant policy for the DeliverThat action dispatcher. */
final class ActionDispatchPolicy {
    private ActionDispatchPolicy() { }

    // Retained for backward regression visibility; semantic-first is no longer on the fast path.
    static long semanticObserveDelayMs() { return 85L; }

    static long processingPollMs() { return 95L; }

    static int processingMaxChecks() { return 16; }

    static long firstGestureDurationMs(boolean accept) {
        return 55L;
    }

    static long retryGestureDurationMs(int attempt) {
        return attempt >= 3 ? 65L : 55L;
    }

    static int retryVariant(int attempt) {
        return attempt >= 3 ? 1 : 0;
    }
}
