package com.local.cateringscreenassistant;

/** Pure timing/variant policy for the DeliverThat action dispatcher. */
final class ActionDispatchPolicy {
    private ActionDispatchPolicy() { }

    static long semanticObserveDelayMs() { return 85L; }

    static long firstGestureDurationMs(boolean accept) {
        return accept ? 55L : 20L;
    }

    static long retryGestureDurationMs(int attempt) {
        return attempt >= 3 ? 65L : 55L;
    }

    static int retryVariant(int attempt) {
        return attempt >= 3 ? 1 : 0;
    }
}
