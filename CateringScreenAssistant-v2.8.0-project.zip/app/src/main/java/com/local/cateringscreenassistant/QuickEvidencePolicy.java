package com.local.cateringscreenassistant;

/** Pure policy for stopping the bounded top-card tree walk as soon as enough evidence exists. */
final class QuickEvidencePolicy {
    static boolean canStop(boolean hasMoney, boolean hasMiles,
                           boolean hasLocationEvidence, boolean hasAction) {
        return hasMoney && hasMiles && hasLocationEvidence && hasAction;
    }
}
