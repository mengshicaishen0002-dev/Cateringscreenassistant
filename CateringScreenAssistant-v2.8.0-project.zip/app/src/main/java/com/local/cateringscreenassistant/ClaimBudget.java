package com.local.cateringscreenassistant;

final class ClaimBudget {
    private static final long RETRY_WINDOW_MS = 8_000L;
    private static final class Entry { int attempts; long lastAttemptAt; }
    private final java.util.LinkedHashMap<String,Entry> attempts = new java.util.LinkedHashMap<>();

    private Entry liveEntry(String id, long now, boolean create) {
        Entry e = attempts.get(id);
        if (e != null && now >= e.lastAttemptAt && now - e.lastAttemptAt >= RETRY_WINDOW_MS) {
            attempts.remove(id);
            e = null;
        }
        if (e == null && create) {
            if (attempts.size() >= 256) attempts.remove(attempts.keySet().iterator().next());
            e = new Entry();
            attempts.put(id, e);
        }
        return e;
    }

    synchronized boolean available(String id, long now) {
        Entry e = liveEntry(id, now, false);
        return e == null || e.attempts < 3;
    }

    synchronized int reserve(String id, long now) {
        Entry e = liveEntry(id, now, true);
        if (e.attempts >= 3) return 0;
        e.attempts++;
        e.lastAttemptAt = now;
        return e.attempts;
    }

    synchronized void forget(String id) { attempts.remove(id); }

    // Pure-Java regression helpers.
    synchronized boolean available(String id) { return available(id, System.currentTimeMillis()); }
    synchronized int reserve(String id) { return reserve(id, System.currentTimeMillis()); }
}
