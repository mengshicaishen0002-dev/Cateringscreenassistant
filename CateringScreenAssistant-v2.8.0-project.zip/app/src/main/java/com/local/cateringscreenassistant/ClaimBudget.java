package com.local.cateringscreenassistant;
final class ClaimBudget {
    private final java.util.LinkedHashMap<String,Integer> attempts = new java.util.LinkedHashMap<>();
    synchronized boolean available(String id) { return attempts.getOrDefault(id, 0) < 3; }
    synchronized int reserve(String id) {
        int next = attempts.getOrDefault(id, 0) + 1;
        if (next > 3) return 0;
        if (!attempts.containsKey(id) && attempts.size() >= 256) attempts.remove(attempts.keySet().iterator().next());
        attempts.put(id, next); return next;
    }
}
