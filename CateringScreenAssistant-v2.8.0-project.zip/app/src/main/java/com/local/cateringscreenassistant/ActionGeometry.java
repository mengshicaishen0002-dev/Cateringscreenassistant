package com.local.cateringscreenassistant;

/** Pure geometry helpers for action-row fallbacks. */
final class ActionGeometry {
    private ActionGeometry() { }

    static boolean plausibleRightAction(int width, float centerX) {
        return width > 0 && centerX >= width * 0.55f && centerX <= width * 0.96f;
    }

    static float inferredLeftActionX(int width, float rightCenterX) {
        if (width <= 0) return rightCenterX;
        // DeliverThat uses a two-button row. Mirroring the right button center around
        // the screen center is more stable than relying on OCR text-box width.
        float mirrored = width - rightCenterX;
        float min = width * 0.14f;
        float max = width * 0.46f;
        if (mirrored < min) mirrored = min;
        if (mirrored > max) mirrored = max;
        return mirrored;
    }

    static float inferredRightActionX(int width, float leftCenterX) {
        if (width <= 0) return leftCenterX;
        float mirrored = width - leftCenterX;
        float min = width * 0.54f;
        float max = width * 0.86f;
        if (mirrored < min) mirrored = min;
        if (mirrored > max) mirrored = max;
        return mirrored;
    }

    static boolean plausibleLeftAction(int width, float centerX) {
        return width > 0 && centerX >= width * 0.04f && centerX <= width * 0.45f;
    }

    static boolean plausibleActionY(int height, float centerY) {
        return height > 0 && centerY >= height * 0.18f && centerY <= height * 0.97f;
    }
}
