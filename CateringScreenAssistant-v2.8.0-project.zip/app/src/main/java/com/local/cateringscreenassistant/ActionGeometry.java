package com.local.cateringscreenassistant;

/** Pure geometry helpers for action-row fallbacks. */
final class ActionGeometry {
    private ActionGeometry() { }

    static boolean plausibleRightAction(int width, float centerX) {
        return width > 0 && centerX >= width * 0.55f && centerX <= width * 0.96f;
    }

    static float inferredLeftActionX(int width, float rightCenterX) {
        if (width <= 0) return rightCenterX;
        // DeliverThat uses a two-button row. Mirroring the right button center around
        // the screen center is more stable than relying on OCR text-box width.
        float mirrored = width - rightCenterX;
        float min = width * 0.14f;
        float max = width * 0.46f;
        if (mirrored < min) mirrored = min;
        if (mirrored > max) mirrored = max;
        return mirrored;
    }

    static float inferredRightActionX(int width, float leftCenterX) {
        if (width <= 0) return leftCenterX;
        float mirrored = width - leftCenterX;
        float min = width * 0.54f;
        float max = width * 0.86f;
        if (mirrored < min) mirrored = min;
        if (mirrored > max) mirrored = max;
        return mirrored;
    }

    static boolean plausibleLeftAction(int width, float centerX) {
        return width > 0 && centerX >= width * 0.04f && centerX <= width * 0.45f;
    }

    static boolean plausibleActionY(int height, float centerY) {
        return height > 0 && centerY >= height * 0.18f && centerY <= height * 0.97f;
    }

    /**
     * v2.10.8: hard anti-card-container guard.
     *
     * DeliverThat makes the whole offer card clickable. Accessibility may therefore expose
     * a very large clickable ancestor around an Ignore/Accept text node. Tapping the center
     * of that ancestor opens offer details instead of pressing the action button. An action
     * rectangle must stay inside one half of the two-button row and must not be card-sized.
     * Coordinates are relative to the DeliverThat root bounds.
     */
    static boolean plausibleActionRect(int screenWidth, int screenHeight,
                                       int left, int top, int right, int bottom,
                                       boolean accept) {
        if (screenWidth <= 0 || screenHeight <= 0 || right <= left || bottom <= top) return false;
        float w = right - left;
        float h = bottom - top;
        float cx = (left + right) * 0.5f;
        float cy = (top + bottom) * 0.5f;

        // A DeliverThat action button is roughly one third of the screen width. Anything
        // approaching full-card width/height is unsafe even if Accessibility says clickable.
        if (w > screenWidth * 0.49f) return false;
        if (h > screenHeight * 0.12f) return false;
        if (w < Math.max(18f, screenWidth * 0.025f)) return false;
        if (h < Math.max(10f, screenHeight * 0.005f)) return false;
        if (!plausibleActionY(screenHeight, cy)) return false;
        if (cy < screenHeight * 0.28f || cy > screenHeight * 0.95f) return false;

        if (accept) {
            if (!plausibleRightAction(screenWidth, cx)) return false;
            // A real right action must not substantially cross the center line.
            if (left < screenWidth * 0.46f) return false;
        } else {
            if (!plausibleLeftAction(screenWidth, cx)) return false;
            // A real left action must not substantially cross the center line.
            if (right > screenWidth * 0.54f) return false;
        }
        return true;
    }

    /** Stable interior tap column for a verified action rectangle. */
    static float stableTapX(int width, float centerX, boolean accept) {
        if (width <= 0) return centerX;
        float min = width * (accept ? 0.58f : 0.14f);
        float max = width * (accept ? 0.86f : 0.42f);
        if (centerX < min) return min;
        if (centerX > max) return max;
        return centerX;
    }

    /** Structural blank-label nodes must look like a real button, not a detail arrow/card. */
    static boolean plausibleStructuralButton(int screenWidth, int screenHeight,
                                             int left, int top, int right, int bottom) {
        if (screenWidth <= 0 || screenHeight <= 0 || right <= left || bottom <= top) return false;
        float w = right - left;
        float h = bottom - top;
        float cx = (left + right) * 0.5f;
        float cy = (top + bottom) * 0.5f;
        if (w < screenWidth * 0.10f || w > screenWidth * 0.49f) return false;
        if (h < Math.max(12f, screenHeight * 0.006f) || h > screenHeight * 0.12f) return false;
        if (!plausibleActionY(screenHeight, cy)) return false;
        if (cy < screenHeight * 0.28f || cy > screenHeight * 0.95f) return false;
        // Exclude the central card/detail container band.
        return cx <= screenWidth * 0.46f || cx >= screenWidth * 0.54f;
    }
}
