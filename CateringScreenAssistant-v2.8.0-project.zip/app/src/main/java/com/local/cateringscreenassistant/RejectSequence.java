package com.local.cateringscreenassistant;

/**
 * Process-wide per-offer Reject/Ignore arbiter. OCR and Accessibility must share the
 * same budget; otherwise the same first card can be clicked once by each path.
 */
final class RejectSequence {
    enum State { READY, WAIT, PROCESSING, HOLD }

    private static final long RETRY_MS = 1100L;
    private static final long FAILED_RETRY_MS = 650L;
    // When DeliverThat has positively changed Reject into a disabled/processing state,
    // do not let a second OCR/accessibility frame re-fire the same button one second later.
    // If the app/server rolls that state back and the same card is still present, the gate
    // eventually re-opens so a real failed reject can recover without an infinite lock.
    private static final long PROCESSING_HOLD_MS = 7000L;
    private static final long ENTRY_TTL_MS = 10 * 60_000L;
    private static final RejectSequence SHARED = new RejectSequence();

    static RejectSequence shared() { return SHARED; }

    private final java.util.LinkedHashMap<String, Entry> entries = new java.util.LinkedHashMap<>();
    private static final class Entry {
        int attempts;
        long retryAfter;
        long processingUntil;
        long lastTouched;
        boolean holdReported;
    }

    private void purgeExpired(long now) {
        java.util.Iterator<java.util.Map.Entry<String, Entry>> it = entries.entrySet().iterator();
        while (it.hasNext()) {
            Entry e = it.next().getValue();
            if (e.lastTouched > 0 && now >= e.lastTouched && now - e.lastTouched > ENTRY_TTL_MS) it.remove();
        }
    }

    private Entry entry(String identity, long now) {
        purgeExpired(now);
        Entry value = entries.get(identity);
        if (value == null) {
            if (entries.size() >= 100) entries.remove(entries.keySet().iterator().next());
            value = new Entry();
            entries.put(identity, value);
        }
        value.lastTouched = now;
        return value;
    }

    synchronized State observe(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts >= 2) return State.HOLD;
        if (now < value.processingUntil) return State.PROCESSING;
        return now < value.retryAfter ? State.WAIT : State.READY;
    }

    /** Reserve one actual Reject dispatch and return its 1-based attempt number. */
    synchronized int sent(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts >= 2) return value.attempts;
        value.attempts++;
        value.retryAfter = now + RETRY_MS;
        value.processingUntil = 0;
        value.holdReported = false;
        return value.attempts;
    }

    /**
     * Positive UI acknowledgement: the same top card was re-read after ACTION_CLICK and
     * its Reject control is disabled/processing. This is stronger evidence than a gesture
     * callback, so suppress cross-path retries while DeliverThat finishes the transition.
     */
    synchronized void markProcessing(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts <= 0) return;
        value.processingUntil = Math.max(value.processingUntil, now + PROCESSING_HOLD_MS);
        value.retryAfter = Math.max(value.retryAfter, value.processingUntil);
        value.holdReported = false;
    }

    /** Undo a reservation when Android never dispatched the gesture/click. */
    synchronized void failed(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts > 0) value.attempts--;
        value.retryAfter = now + FAILED_RETRY_MS;
        value.processingUntil = 0;
        value.holdReported = false;
    }

    /** Returns true only once when the two-attempt ceiling is reached. */
    synchronized boolean markHoldReported(String current, long now) {
        Entry value = entry(current, now);
        if (value.attempts < 2 || value.holdReported) return false;
        value.holdReported = true;
        return true;
    }

    synchronized int attempts(String current, long now) { return entry(current, now).attempts; }

    synchronized void forget(String current) { entries.remove(current); }
}
