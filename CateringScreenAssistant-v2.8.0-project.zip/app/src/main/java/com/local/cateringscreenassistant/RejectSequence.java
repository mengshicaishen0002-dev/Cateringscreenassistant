package com.local.cateringscreenassistant;

final class RejectSequence {
    enum State { READY, WAIT, HOLD }
    private final java.util.LinkedHashMap<String, Entry> entries = new java.util.LinkedHashMap<>();
    private static final class Entry { int attempts; long retryAfter; }
    private Entry entry(String identity) {
        Entry value = entries.get(identity);
        if (value == null) {
            if (entries.size() >= 100) entries.remove(entries.keySet().iterator().next());
            value = new Entry(); entries.put(identity, value);
        }
        return value;
    }
    State observe(String current, long now) {
        Entry value = entry(current);
        if (value.attempts >= 2) return State.HOLD;
        return now < value.retryAfter ? State.WAIT : State.READY;
    }
    void sent(String current, long now) {
        Entry value = entry(current);
        value.attempts++;
        value.retryAfter = now + 1100;
    }
    void forget(String current) { entries.remove(current); }
}
