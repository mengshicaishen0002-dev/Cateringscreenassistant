package com.local.cateringscreenassistant;

/** Pure post-Reject classifier. Never uses Jobs/assigned-job evidence. */
final class RejectConfirmation {
    enum Result { PENDING, CONFIRMED, DISAPPEARED_UNKNOWN }

    private RejectConfirmation() { }

    static Result classify(boolean sameCardVisible, boolean processingAck,
                           int consecutiveMissingReads) {
        if (sameCardVisible || consecutiveMissingReads < 2) return Result.PENDING;
        return processingAck ? Result.CONFIRMED : Result.DISAPPEARED_UNKNOWN;
    }
}
