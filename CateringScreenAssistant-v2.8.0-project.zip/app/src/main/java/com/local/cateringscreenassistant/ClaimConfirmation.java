package com.local.cateringscreenassistant;

/** Pure decision helper for post-Accept state classification. */
final class ClaimConfirmation {
    enum Result { PENDING, CONFIRMED, TERMINAL_LOST, DISAPPEARED_UNKNOWN }

    private ClaimConfirmation() {}

    static Result classify(boolean sameCardVisible, PageGuard.Page page,
                           boolean explicitSuccessEvidence, boolean terminalNegative) {
        if (explicitSuccessEvidence || page == PageGuard.Page.JOBS) return Result.CONFIRMED;
        if (terminalNegative && !sameCardVisible) return Result.TERMINAL_LOST;
        if (sameCardVisible) return Result.PENDING;
        return Result.DISAPPEARED_UNKNOWN;
    }

    // Backward-compatible overload used by older pure tests/helpers.
    static Result classify(boolean sameCardVisible, PageGuard.Page page, boolean explicitSuccessEvidence) {
        return classify(sameCardVisible, page, explicitSuccessEvidence, false);
    }
}
