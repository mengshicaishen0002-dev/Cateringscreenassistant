package com.local.cateringscreenassistant;

/** Pure decision helper for post-Accept state classification. */
final class ClaimConfirmation {
    enum Result { PENDING, CONFIRMED, DISAPPEARED_UNKNOWN }

    private ClaimConfirmation() {}

    static Result classify(boolean sameCardVisible, PageGuard.Page page, boolean explicitSuccessEvidence) {
        if (explicitSuccessEvidence || page == PageGuard.Page.JOBS) return Result.CONFIRMED;
        if (sameCardVisible) return Result.PENDING;
        return Result.DISAPPEARED_UNKNOWN;
    }
}
