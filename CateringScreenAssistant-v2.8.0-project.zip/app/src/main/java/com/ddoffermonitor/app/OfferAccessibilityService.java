package com.ddoffermonitor.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import android.widget.Button;
import android.widget.LinearLayout;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * DoorDash Offers monitor.
 *
 * Design rule: this service may navigate Offers/date/detail screens, but NEVER performs the
 * final scheduling action. Claim/Acknowledge nodes are treated as protected final actions.
 */
public class OfferAccessibilityService extends AccessibilityService {
    private static final String DASHER = "com.doordash.driverapp";
    private static final long EVENT_DEBOUNCE_MS = 110;
    private static final long WATCHDOG_MS = 550;
    private static final long ACTION_MIN_GAP_MS = 260;
    private static final long DETAIL_PARSE_GRACE_MS = 1400;
    private static final long DETAIL_OPEN_TIMEOUT_MS = 1200;
    // Reliability timing: do not read the next date until DoorDash has had time to settle.
    // This is deterministic/state-driven throttling, not human-simulation jitter.
    private static final long DATE_MIN_SETTLE_MS = 1500;
    private static final long DATE_CHANGE_TIMEOUT_MS = 2500;
    private static final long MANUAL_RETURN_GRACE_MS = 1600;
    private static final long IGNORE_COOLDOWN_MS = 20000;
    private static final long MAX_LOG_BYTES = 1024L * 1024L;
    private static final long USER_INTERACTION_GRACE_MS = 1800;
    private static final long SELF_EVENT_GRACE_MS = 1800;
    private static final long REJECT_CACHE_MS = 180000;
    private static final long SEEN_CACHE_MS = 300000;
    private static final int DATE_ROW_FAILURE_LIMIT = 6;
    private static final int DATE_CLICK_FAILURE_LIMIT = 4;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Map<String, Long> cooldown = new HashMap<String, Long>();
    private final Map<String, Long> rejectCache = new HashMap<String, Long>();
    private final Map<String, Long> seenOfferCache = new HashMap<String, Long>();
    private final Map<String, Long> offerFirstSeenUptime = new HashMap<String, Long>();

    private WindowManager wm;
    private View candidateOverlay;
    private LinearLayout controlOverlay;
    private TextView controlState;
    private Button controlPause;
    private WindowManager.LayoutParams controlLp;
    private boolean manualPending;
    private long manualStartedAt;
    private long lastEventAt;
    private long lastActionAt;
    private long detailFirstSeenAt;
    private long detailOpenRequestedAt;
    private long returnHoldUntil;
    private long dateChangeDeadline;
    private long dateChangeSettleUntil;
    private String dateChangeFromFingerprint = "";
    private String lastFingerprint = "";
    private String pendingCardKey = "";
    private double pendingPay;
    private int dayCursor = -1;
    private long lastStatusAt;
    private long roundPauseUntil;
    private int emptyRounds;
    private int scannedDaysInRound;
    private boolean roundHadMoney;
    private boolean clickedDatePendingScan;
    private boolean roundCompletePendingPause;
    private long userInteractionHoldUntil;
    private long selfEventUntil;
    private int consecutiveDateRowFailures;
    private int consecutiveDateClickFailures;
    private boolean contentWakePending;
    private String roundPauseFingerprint = "";

    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            try {
                if (isEnabledByUser()) {
                    ensureControlOverlay();
                    AccessibilityNodeInfo root = getRootInActiveWindow();
                    if (root != null && root.getPackageName() != null && DASHER.contentEquals(root.getPackageName())) {
                        scheduleScan(0);
                    }
                } else {
                    removeControlOverlay();
                }
            } catch (Throwable t) {
                log("WATCHDOG_ERROR", shortErr(t));
            } finally {
                h.postDelayed(this, WATCHDOG_MS);
            }
        }
    };

    private final Runnable scanner = new Runnable() {
        @Override public void run() { scanNow(); }
    };

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        log("SERVICE_CONNECTED", "native-v1.2.0");
        statInc("serviceStarts");
        if (isEnabledByUser()) ensureControlOverlay();
        h.removeCallbacks(watchdog);
        h.post(watchdog);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null || !DASHER.contentEquals(event.getPackageName())) return;
        if (!isEnabledByUser()) return;
        ensureControlOverlay();
        if (isPausedByUser()) return;
        long now = SystemClock.uptimeMillis();

        // If the driver manually clicks or scrolls Dasher, briefly yield control instead of
        // competing with their gesture. Events immediately following our own Accessibility
        // action are ignored by this detector. This is a reliability guard, not evasion logic.
        int type = event.getEventType();
        if (roundPauseUntil > now && now > selfEventUntil && type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            contentWakePending = true;
        }
        if (!manualPending && now > selfEventUntil
                && (type == AccessibilityEvent.TYPE_VIEW_CLICKED || type == AccessibilityEvent.TYPE_VIEW_SCROLLED)) {
            userInteractionHoldUntil = Math.max(userInteractionHoldUntil, now + USER_INTERACTION_GRACE_MS);
            logThrottled("USER_INTERACTION_HOLD", "yield=" + USER_INTERACTION_GRACE_MS + "ms", 1200);
        }

        if (now - lastEventAt < EVENT_DEBOUNCE_MS) return;
        lastEventAt = now;
        scheduleScan(80);
    }

    @Override public void onInterrupt() { log("SERVICE_INTERRUPTED", ""); }

    @Override public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        removeCandidateOverlay();
        removeControlOverlay();
        super.onDestroy();
    }

    private void scheduleScan(long delayMs) {
        h.removeCallbacks(scanner);
        h.postDelayed(scanner, delayMs);
    }

    private void scanNow() {
        if (!isEnabledByUser()) {
            setStatus("监控已停止");
            removeControlOverlay();
            return;
        }
        ensureControlOverlay();
        if (isPausedByUser()) {
            setStatus("监控已暂停");
            updateControlOverlay();
            return;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) {
            setStatus("等待前台窗口…");
            return;
        }
        String activePkg = root.getPackageName().toString();
        if (!DASHER.equals(activePkg)) {
            setStatus("等待 Dasher 前台 | 当前=" + activePkg);
            updateControlOverlay();
            return;
        }

        long preNow = SystemClock.uptimeMillis();
        boolean inRoundPause = roundPauseUntil > preNow;
        if (inRoundPause && !contentWakePending) {
            long left = Math.max(1L, (roundPauseUntil - preNow + 999L) / 1000L);
            setStatus("本轮扫描完成，休息 " + left + " 秒");
            updateControlOverlay();
            return;
        }

        Snapshot s = Snapshot.build(root);
        if (s.nodes.isEmpty()) {
            setStatus("Dasher 已找到，但控件树为空");
            return;
        }

        if (inRoundPause) {
            contentWakePending = false;
            String wakeFp = s.fingerprint();
            if (s.looksLikeOfferList() && roundPauseFingerprint.length() > 0 && !wakeFp.equals(roundPauseFingerprint)) {
                roundPauseUntil = 0;
                emptyRounds = 0;
                log("ROUND_WAKE_ON_CHANGE", "old=" + roundPauseFingerprint + " new=" + wakeFp);
                statInc("roundWakeups");
            } else {
                long left = Math.max(1L, (roundPauseUntil - preNow + 999L) / 1000L);
                setStatus("轮休中，页面无新变化 " + left + " 秒");
                updateControlOverlay();
                return;
            }
        }

        List<Node> diagDates = s.dateButtons();
        int diagDateCount = diagDates.size();
        String diagDateSource = s.dateSource();
        setStatus("Dasher✓ | nodes=" + s.nodes.size() + " | Offers=" + s.looksLikeOfferList()
                + " | dates=" + diagDateCount
                + (diagDateSource.length() > 0 ? "(" + diagDateSource + ")" : "")
                + " | money=" + s.moneyNodes().size());
        updateControlOverlay();
        long now = SystemClock.uptimeMillis();

        if (manualPending) {
            observeManualResult(s);
            return;
        }

        if (s.hasSensitiveScreen()) {
            safetyPause("检测到登录/身份验证等非 Offers 页面，已安全暂停");
            return;
        }

        if (s.looksLoading()) {
            setStatus("Dasher✓ | 页面加载中，等待稳定…");
            updateControlOverlay();
            return;
        }

        if (now < userInteractionHoldUntil) {
            long left = Math.max(1L, userInteractionHoldUntil - now);
            setStatus("检测到手动操作，暂让出控制 " + left + "ms");
            updateControlOverlay();
            return;
        }

        String fp = s.fingerprint();

        // A date tap is not considered complete merely because ACTION_CLICK returned true.
        // Wait for the Accessibility tree/selection to actually change, with a short timeout.
        if (dateChangeDeadline > 0) {
            if (now < dateChangeSettleUntil) return;
            if (!fp.equals(dateChangeFromFingerprint)) {
                log("DATE_STATE_CHANGED", "");
                dateChangeDeadline = 0;
                dateChangeFromFingerprint = "";
            } else if (now < dateChangeDeadline) {
                return;
            } else {
                log("DATE_STATE_TIMEOUT", "tree unchanged after date tap");
                dateChangeDeadline = 0;
                dateChangeFromFingerprint = "";
            }
        }

        // Do not let the next scan race the transition into an offer detail page.
        if (detailOpenRequestedAt > 0 && !s.hasProtectedFinalAction()) {
            if (now - detailOpenRequestedAt < DETAIL_OPEN_TIMEOUT_MS) return;
            log("DETAIL_OPEN_TIMEOUT", "pay=" + pendingPay + " key=" + pendingCardKey);
            detailOpenRequestedAt = 0;
            detailFirstSeenAt = 0;
            pendingPay = 0;
            pendingCardKey = "";
        }

        if (now < returnHoldUntil) return;

        if (fp.equals(lastFingerprint) && now - lastActionAt < ACTION_MIN_GAP_MS) return;
        lastFingerprint = fp;

        // Detail is intentionally checked first: final action nodes are protected and never clicked.
        if (s.hasProtectedFinalAction()) {
            handleDetail(s);
            return;
        }

        Node retry = s.findExactAny("Retry", "Try again");
        if (retry != null) {
            autoClick(retry, "RETRY");
            return;
        }

        if (s.looksLikeOfferList()) {
            handleOfferList(s);
            return;
        }

        // Strict foreground/page gate: never navigate into Offers automatically. The monitor only
        // acts when the current Dasher screen is positively identified as the Offers list.
        setStatus("Dasher✓ | 等待 Schedule → Offers 页面");
        updateControlOverlay();
    }

    private void handleOfferList(Snapshot s) {
        detailFirstSeenAt = 0;
        detailOpenRequestedAt = 0;

        final double minPay = numPref("minPay", 30.0);
        List<Node> money = s.moneyNodes();
        if (!money.isEmpty()) roundHadMoney = true;

        // Count a day only after a date that WE intentionally selected has settled and been read.
        if (clickedDatePendingScan) {
            clickedDatePendingScan = false;
            scannedDaysInRound++;
            statInc("daysScanned");
            int enabled = enabledDayCount();
            if (enabled > 0 && scannedDaysInRound >= enabled) roundCompletePendingPause = true;
        }

        long wallNow = System.currentTimeMillis();
        purgeCaches(wallNow);
        boolean observeOnly = isObserveMode();

        for (Node n : money) {
            double pay = parseMoney(n.text);
            if (pay <= 0) continue;
            String key = s.offerIdentity(n, dayCursor);
            boolean isNew = markOfferSeen(key, pay, s.cardSummary(n));

            if (observeOnly) {
                if (isNew) log("OBSERVE_OFFER", String.format(Locale.US, "pay=%.2f %s", pay, s.cardSummary(n)));
                continue;
            }

            if (pay < minPay) {
                if (isNew) statInc("rejectPay");
                logOnce("IGNORE_PAY", key, String.format(Locale.US, "pay=%.2f min=%.2f %s", pay, minPay, s.cardSummary(n)));
                continue;
            }

            Long rejectedUntil = rejectCache.get(key);
            if (rejectedUntil != null && rejectedUntil.longValue() > wallNow) continue;
            Long until = cooldown.get(key);
            if (until != null && until.longValue() > wallNow) continue;

            pendingCardKey = key;
            pendingPay = pay;
            cooldown.put(key, wallNow + IGNORE_COOLDOWN_MS);
            if (autoClick(n, "OPEN_DETAIL pay=" + fmt(pay))) {
                detailOpenRequestedAt = SystemClock.uptimeMillis();
                statInc("detailOpened");
                consecutiveDateClickFailures = 0;
                return;
            }
            log("CARD_CLICK_FAIL", key);
            statInc("cardClickFail");
        }

        if (observeOnly) {
            setStatus("观察模式 | 当前页 offer=" + money.size() + " | 不执行日期/详情点击");
            updateControlOverlay();
            return;
        }

        if (roundCompletePendingPause) {
            startRoundPause();
            return;
        }
        cycleDate(s);
    }

    private boolean isObserveMode() {
        return "observe".equals(getSharedPreferences("cfg", MODE_PRIVATE).getString("monitorMode", "stable"));
    }

    private boolean markOfferSeen(String key, double pay, String summary) {
        long wall = System.currentTimeMillis();
        Long until = seenOfferCache.get(key);
        if (until != null && until.longValue() > wall) return false;
        seenOfferCache.put(key, wall + SEEN_CACHE_MS);
        offerFirstSeenUptime.put(key, SystemClock.uptimeMillis());
        statInc("offersUnique");
        getSharedPreferences("stats", MODE_PRIVATE).edit()
                .putLong("lastOfferAt", wall)
                .putString("lastOffer", String.format(Locale.US, "$%.2f | %s", pay, compact(summary, 180)))
                .apply();
        log("NEW_OFFER", String.format(Locale.US, "key=%s pay=%.2f %s", key, pay, compact(summary, 180)));
        return true;
    }

    private void purgeCaches(long wallNow) {
        purgeExpired(cooldown, wallNow);
        purgeExpired(rejectCache, wallNow);
        purgeExpired(seenOfferCache, wallNow);
        if (offerFirstSeenUptime.size() > 160) offerFirstSeenUptime.clear();
    }

    private static void purgeExpired(Map<String, Long> map, long now) {
        Iterator<Map.Entry<String, Long>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Long> e = it.next();
            if (e.getValue() == null || e.getValue().longValue() <= now) it.remove();
        }
    }

    private void statInc(String key) {
        try {
            SharedPreferences st = getSharedPreferences("stats", MODE_PRIVATE);
            long started = st.getLong("startedAt", 0L);
            SharedPreferences.Editor ed = st.edit();
            if (started == 0L) ed.putLong("startedAt", System.currentTimeMillis());
            ed.putLong(key, st.getLong(key, 0L) + 1L).apply();
        } catch (Throwable ignored) {}
    }

    private void recordCandidateLatency(String key) {
        try {
            Long first = offerFirstSeenUptime.remove(key);
            if (first == null) return;
            long ms = Math.max(0L, SystemClock.uptimeMillis() - first.longValue());
            SharedPreferences st = getSharedPreferences("stats", MODE_PRIVATE);
            long count = st.getLong("candidateLatencyCount", 0L);
            long total = st.getLong("candidateLatencyTotalMs", 0L);
            st.edit()
                    .putLong("candidateLatencyCount", count + 1L)
                    .putLong("candidateLatencyTotalMs", total + ms)
                    .putLong("lastCandidateLatencyMs", ms)
                    .apply();
            log("CANDIDATE_LATENCY", "ms=" + ms);
        } catch (Throwable ignored) {}
    }

    private void safetyPause(String reason) {
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        if (!p.getBoolean("paused", false)) {
            p.edit().putBoolean("paused", true).apply();
            statInc("safetyPauses");
            log("SAFETY_PAUSE", reason);
            alertSafetyPause(reason);
        }
        setStatus("安全暂停：" + reason);
        updateControlOverlay();
    }

    private void alertSafetyPause(String reason) {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(450, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(450);
            }
        } catch (Throwable ignored) {}
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            String channel = "safety";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(channel, "Monitor safety", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
            nb.setSmallIcon(android.R.drawable.ic_dialog_alert)
                    .setContentTitle("DD Offer Monitor：已安全暂停")
                    .setContentText(compact(reason, 140))
                    .setAutoCancel(true);
            nm.notify(1003, nb.build());
        } catch (Throwable ignored) {}
    }

    private int enabledDayCount() {
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        int n = 0;
        for (int i = 0; i < 7; i++) if (p.getBoolean("d" + i, true)) n++;
        return n;
    }

    private void startRoundPause() {
        if (roundHadMoney) emptyRounds = 0;
        else emptyRounds++;
        long rest = emptyRounds <= 1 ? 5000L : (emptyRounds == 2 ? 8000L : 10000L);
        roundPauseUntil = SystemClock.uptimeMillis() + rest;
        roundPauseFingerprint = lastFingerprint;
        contentWakePending = false;
        statInc("roundsCompleted");
        log("ROUND_PAUSE", "ms=" + rest + " emptyRounds=" + emptyRounds + " hadMoney=" + roundHadMoney);
        scannedDaysInRound = 0;
        roundHadMoney = false;
        roundCompletePendingPause = false;
        updateControlOverlay();
    }

    private void cycleDate(Snapshot s) {
        List<Node> dates = s.dateButtons();
        if (dates.size() < 2) {
            consecutiveDateRowFailures++;
            logThrottled("DATE_ROW_NOT_FOUND", "found=" + dates.size() + " source=" + s.dateSource() + " failures=" + consecutiveDateRowFailures + " " + s.dateDiagnostic(), 5000);
            if (consecutiveDateRowFailures >= DATE_ROW_FAILURE_LIMIT) {
                safetyPause("连续无法识别日期栏");
            }
            return;
        }
        consecutiveDateRowFailures = 0;

        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        int count = Math.min(7, dates.size());
        if (enabledDayCount() <= 0) return;
        int selected = -1;
        for (int i = 0; i < count; i++) {
            if (dates.get(i).selected || dates.get(i).checked) { selected = i; break; }
        }
        if (selected >= 0) dayCursor = selected;

        for (int tries = 0; tries < 7; tries++) {
            dayCursor = (dayCursor + 1) % 7;
            if (!p.getBoolean("d" + dayCursor, true)) continue;
            if (dayCursor >= count) continue;
            Node target = dates.get(dayCursor);
            if (target.selected || target.checked) continue;
            String before = s.fingerprint();
            boolean ok;
            if ("button-row".equals(s.dateSource()) && !target.rect.isEmpty()) {
                // Mirror NovaFlow's proven behavior: tap the center of the actual Accessibility
                // Button bounds. This is NOT a fixed screen coordinate; the position comes from
                // the live node tree on every scan.
                ok = gestureTap(target.rect.centerX(), target.rect.centerY());
                if (ok) {
                    lastActionAt = SystemClock.uptimeMillis();
                    log("DATE_BUTTON_ROW_TAP", "D" + (dayCursor + 1) + " x=" + target.rect.centerX() + " y=" + target.rect.centerY());
                }
            } else {
                ok = autoClick(target, "DATE_CLICK D" + (dayCursor + 1));
            }
            if (ok) {
                consecutiveDateClickFailures = 0;
                long now = SystemClock.uptimeMillis();
                // All date sources use the same state-driven settle gate. Even if the seven
                // Button nodes expose no text, waiting at least 1.5 s prevents reading stale
                // content from the previous day; if the fingerprint stays identical, the
                // 2.5 s ceiling releases the scan without a busy loop.
                dateChangeFromFingerprint = before;
                dateChangeSettleUntil = now + DATE_MIN_SETTLE_MS;
                dateChangeDeadline = now + DATE_CHANGE_TIMEOUT_MS;
                clickedDatePendingScan = true;
                return;
            }
            consecutiveDateClickFailures++;
            statInc("dateClickFail");
            log("DATE_CLICK_FAIL", "D" + (dayCursor + 1) + " source=" + s.dateSource() + " failures=" + consecutiveDateClickFailures + " text=" + target.text);
            if (consecutiveDateClickFailures >= DATE_CLICK_FAILURE_LIMIT) {
                safetyPause("连续日期点击失败");
                return;
            }
        }
    }


    private void handleDetail(Snapshot s) {
        long now = SystemClock.uptimeMillis();
        detailOpenRequestedAt = 0;
        if (detailFirstSeenAt == 0) detailFirstSeenAt = now;

        double pay = s.bestDetailMoney();
        if (pay <= 0 && pendingPay > 0) pay = pendingPay;
        Double miles = s.findMiles();

        if (pay <= 0 || miles == null || miles.doubleValue() <= 0) {
            if (now - detailFirstSeenAt < DETAIL_PARSE_GRACE_MS) return;
            log("DISTANCE_PARSE_FAIL", "pay=" + pay + " miles=" + miles + " " + s.summary());
            statInc("parseFail");
            ignoreCurrentAndBack("PARSE_FAIL");
            return;
        }

        double mi = miles.doubleValue();
        double ppm = pay / mi;
        double minPpm = numPref("minPpm", 2.0);
        double maxMiles = numPref("maxMiles", 99.0);

        if (mi > maxMiles) {
            log("IGNORE_MILES", String.format(Locale.US, "$%.2f %.2fmi max=%.2f %s", pay, mi, maxMiles, s.summary()));
            statInc("rejectMiles");
            ignoreCurrentAndBack("MILES");
            return;
        }
        if (ppm < minPpm) {
            log("IGNORE_PPM", String.format(Locale.US, "$%.2f %.2fmi $%.2f/mi min=$%.2f/mi %s", pay, mi, ppm, minPpm, s.summary()));
            statInc("rejectPpm");
            ignoreCurrentAndBack("PPM");
            return;
        }

        // Candidate reached. From this point all automation is frozen until the user acts.
        manualPending = true;
        manualStartedAt = SystemClock.uptimeMillis();
        statInc("candidates");
        recordCandidateLatency(pendingCardKey);
        String details = String.format(Locale.US, "$%.2f | %.2f mi | $%.2f/mi | %s", pay, mi, ppm, s.summary());
        getSharedPreferences("stats", MODE_PRIVATE).edit()
                .putLong("lastCandidateAt", System.currentTimeMillis())
                .putString("lastCandidate", compact(details, 240))
                .apply();
        log("CANDIDATE", details);
        alertCandidate(pay, mi, ppm, s.summary());
    }

    private void ignoreCurrentAndBack(String reason) {
        if (pendingCardKey.length() > 0) {
            cooldown.put(pendingCardKey, System.currentTimeMillis() + IGNORE_COOLDOWN_MS);
            rejectCache.put(pendingCardKey, System.currentTimeMillis() + REJECT_CACHE_MS);
        }
        safeBack(reason);
        pendingPay = 0;
        pendingCardKey = "";
        detailFirstSeenAt = 0;
        detailOpenRequestedAt = 0;
    }

    private void observeManualResult(Snapshot s) {
        if (s.hasAny("successfully scheduled", "added to your schedule", "you claimed", "scheduled successfully")) {
            log("CLAIM_CONFIRMED", s.summary());
            statInc("claimConfirmed");
            clearManual(true);
            return;
        }
        if (s.hasAny("no longer available", "already claimed", "not available", "someone else", "offer is unavailable")) {
            log("CLAIM_FAILED", s.summary());
            statInc("claimFailed");
            clearManual(true);
            return;
        }

        // If the user manually acted and DoorDash returned to the offers list without explicit
        // confirmation text, record it as unverified rather than claiming success.
        if (!s.hasProtectedFinalAction() && s.looksLikeOfferList() && SystemClock.uptimeMillis() - manualStartedAt > MANUAL_RETURN_GRACE_MS) {
            log("MANUAL_RESULT_UNVERIFIED", s.summary());
            statInc("claimUnverified");
            clearManual(true);
        }
    }

    private void clearManual(boolean resume) {
        manualPending = false;
        pendingPay = 0;
        pendingCardKey = "";
        detailFirstSeenAt = 0;
        detailOpenRequestedAt = 0;
        removeCandidateOverlay();
        updateControlOverlay();
        if (resume && !isPausedByUser() && isEnabledByUser()) scheduleScan(500);
    }

    private boolean autoClick(Node n, String reason) {
        if (n == null) return false;
        if (!automationAllowed()) return false;
        if (isProtectedText(n.text) || subtreeHasProtectedText(n.node, 40)) {
            log("BLOCKED_FINAL_ACTION", reason + " text=" + n.text);
            return false;
        }
        long now = SystemClock.uptimeMillis();
        if (now - lastActionAt < ACTION_MIN_GAP_MS) return false;

        boolean ok = false;
        AccessibilityNodeInfo x = n.node;
        for (int i = 0; i < 6 && x != null; i++) {
            if (isProtectedText(nodeText(x)) || subtreeHasProtectedText(x, 40)) return false;
            if (x.isEnabled() && x.isClickable()) {
                try { ok = x.performAction(AccessibilityNodeInfo.ACTION_CLICK); } catch (Throwable ignored) {}
                if (ok) break;
            }
            x = x.getParent();
        }

        if (!ok && !n.rect.isEmpty()) {
            ok = gestureTap(n.rect.centerX(), n.rect.centerY());
        }
        if (ok) {
            lastActionAt = SystemClock.uptimeMillis();
            selfEventUntil = lastActionAt + SELF_EVENT_GRACE_MS;
            log("AUTO_ACTION", reason + " text=" + n.text);
        }
        return ok;
    }

    private boolean gestureTap(float x, float y) {
        if (!automationAllowed()) return false;
        try {
            Path p = new Path();
            p.moveTo(x, y);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(new GestureDescription.StrokeDescription(p, 0, 55));
            boolean ok = dispatchGesture(b.build(), null, null);
            if (ok) selfEventUntil = SystemClock.uptimeMillis() + SELF_EVENT_GRACE_MS;
            return ok;
        } catch (Throwable t) {
            log("GESTURE_FAIL", shortErr(t));
            return false;
        }
    }

    private void safeBack(String reason) {
        if (!automationAllowed()) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastActionAt < ACTION_MIN_GAP_MS) {
            final String why = reason;
            h.postDelayed(new Runnable() { @Override public void run() { safeBack(why); } }, ACTION_MIN_GAP_MS);
            return;
        }
        if (performGlobalAction(GLOBAL_ACTION_BACK)) {
            lastActionAt = SystemClock.uptimeMillis();
            selfEventUntil = lastActionAt + SELF_EVENT_GRACE_MS;
            returnHoldUntil = lastActionAt + 420;
            log("AUTO_BACK", reason);
        } else {
            log("BACK_FAIL", reason);
        }
    }

    private boolean subtreeHasProtectedText(AccessibilityNodeInfo root, int cap) {
        if (root == null) return false;
        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<AccessibilityNodeInfo>();
        q.add(root);
        int seen = 0;
        while (!q.isEmpty() && seen++ < cap) {
            AccessibilityNodeInfo n = q.removeFirst();
            if (isProtectedText(nodeText(n))) return true;
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) q.addLast(c);
            }
        }
        return false;
    }

    private static String nodeText(AccessibilityNodeInfo n) {
        if (n == null) return "";
        CharSequence t = n.getText();
        if (t != null && t.length() > 0) return t.toString().trim();
        CharSequence d = n.getContentDescription();
        return d == null ? "" : d.toString().trim();
    }

    private static boolean isProtectedText(String text) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.US);
        return l.contains("claim and schedule") || l.equals("claim") || l.equals("acknowledge") || l.contains("confirm claim");
    }

    private void alertCandidate(double pay, double mi, double ppm, String summary) {
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        boolean vibrate = p.getBoolean("vibrateAlert", true);
        boolean sound = p.getBoolean("soundAlert", true);

        if (vibrate) try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                long[] wave = new long[]{0, 280, 120, 420, 120, 650};
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(wave, -1));
                else v.vibrate(1200);
            }
        } catch (Throwable ignored) {}

        if (sound) try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) {}

        showCandidateOverlay(String.format(Locale.US,
                "发现合格预约单  —  自动操作已停止\n$%.2f   %.2f mi   $%.2f/mi\n请在 Dasher 里手动 Claim\n%s",
                pay, mi, ppm, compact(summary, 180)));

        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            String channel = "candidate";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(channel, "Offer alerts", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
            try {
                Intent di = getPackageManager().getLaunchIntentForPackage(DASHER);
                if (di != null) {
                    di.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                    if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
                    nb.setContentIntent(PendingIntent.getActivity(this, 1101, di, flags));
                }
            } catch (Throwable ignored) {}
            nb.setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("DD Offer Monitor：发现合格预约单")
                    .setContentText(String.format(Locale.US, "$%.2f / %.2f mi / $%.2f/mi — 请手动 Claim", pay, mi, ppm))
                    .setAutoCancel(true);
            nm.notify(1001, nb.build());
        } catch (Throwable t) {
            log("NOTIFICATION_FAIL", shortErr(t));
        }
    }

    private void showCandidateOverlay(String text) {
        removeCandidateOverlay();
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        try {
            TextView tv = new TextView(this);
            tv.setText(text);
            tv.setTextSize(16);
            tv.setPadding(26, 18, 26, 18);
            tv.setTextColor(0xff000000);
            tv.setBackgroundColor(0xeefff59d);
            candidateOverlay = tv;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP;
            lp.y = 70;
            wm.addView(candidateOverlay, lp);
        } catch (Throwable t) {
            candidateOverlay = null;
            log("OVERLAY_FAIL", shortErr(t));
        }
    }

    private void removeCandidateOverlay() {
        if (candidateOverlay != null && wm != null) {
            try { wm.removeView(candidateOverlay); } catch (Throwable ignored) {}
        }
        candidateOverlay = null;
    }

    private boolean isPausedByUser() {
        return getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("paused", false);
    }

    private boolean automationAllowed() {
        return isEnabledByUser() && !isPausedByUser() && !manualPending && !isObserveMode();
    }

    private void setPaused(boolean paused) {
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("paused", paused).apply();
        if (paused) {
            h.removeCallbacks(scanner);
            setStatus("监控已暂停");
            log("USER_PAUSE", "overlay");
        } else {
            roundPauseUntil = 0;
            setStatus("监控继续运行");
            log("USER_RESUME", "overlay");
            scheduleScan(150);
        }
        updateControlOverlay();
    }

    private void stopMonitoring() {
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
                .putBoolean("enabled", false)
                .putBoolean("paused", false)
                .apply();
        h.removeCallbacks(scanner);
        roundPauseUntil = 0;
        roundPauseFingerprint = "";
        contentWakePending = false;
        scannedDaysInRound = 0;
        roundHadMoney = false;
        emptyRounds = 0;
        clickedDatePendingScan = false;
        roundCompletePendingPause = false;
        dateChangeDeadline = 0;
        dateChangeFromFingerprint = "";
        detailOpenRequestedAt = 0;
        detailFirstSeenAt = 0;
        pendingPay = 0;
        pendingCardKey = "";
        manualPending = false;
        cooldown.clear();
        rejectCache.clear();
        seenOfferCache.clear();
        offerFirstSeenUptime.clear();
        removeCandidateOverlay();
        setStatus("监控已停止");
        log("USER_STOP", "overlay");
        removeControlOverlay();
    }

    private void ensureControlOverlay() {
        if (!isEnabledByUser() || controlOverlay != null) {
            if (controlOverlay != null) updateControlOverlay();
            return;
        }
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        try {
            final LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(12, 10, 12, 10);
            box.setBackgroundColor(0xdd202124);

            TextView state = new TextView(this);
            state.setTextColor(0xffffffff);
            state.setTextSize(12);
            state.setPadding(6, 2, 6, 4);
            box.addView(state, new LinearLayout.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT));

            LinearLayout buttons = new LinearLayout(this);
            buttons.setOrientation(LinearLayout.HORIZONTAL);
            Button pause = new Button(this);
            pause.setText("暂停");
            pause.setTextSize(12);
            pause.setMinWidth(0);
            pause.setMinimumWidth(0);
            pause.setPadding(12, 2, 12, 2);
            Button stop = new Button(this);
            stop.setText("停止");
            stop.setTextSize(12);
            stop.setMinWidth(0);
            stop.setMinimumWidth(0);
            stop.setPadding(12, 2, 12, 2);
            buttons.addView(pause);
            buttons.addView(stop);
            box.addView(buttons);

            controlOverlay = box;
            controlState = state;
            controlPause = pause;
            int overlayFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
            if (getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("keepAwake", true)) {
                overlayFlags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            }
            controlLp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    overlayFlags,
                    PixelFormat.TRANSLUCENT);
            controlLp.gravity = Gravity.TOP | Gravity.END;
            SharedPreferences overlayPrefs = getSharedPreferences("cfg", MODE_PRIVATE);
            controlLp.x = overlayPrefs.getInt("overlayX", 18);
            controlLp.y = overlayPrefs.getInt("overlayY", 360);

            final float[] touch = new float[4];
            state.setOnTouchListener(new View.OnTouchListener() {
                @Override public boolean onTouch(View v, MotionEvent e) {
                    if (controlLp == null || wm == null) return false;
                    if (e.getAction() == MotionEvent.ACTION_DOWN) {
                        touch[0] = e.getRawX(); touch[1] = e.getRawY();
                        touch[2] = controlLp.x; touch[3] = controlLp.y;
                        return true;
                    }
                    if (e.getAction() == MotionEvent.ACTION_MOVE) {
                        controlLp.x = Math.max(0, (int) (touch[2] - (e.getRawX() - touch[0])));
                        controlLp.y = Math.max(0, (int) (touch[3] + (e.getRawY() - touch[1])));
                        try { wm.updateViewLayout(box, controlLp); } catch (Throwable ignored) {}
                        return true;
                    }
                    if (e.getAction() == MotionEvent.ACTION_UP) {
                        getSharedPreferences("cfg", MODE_PRIVATE).edit()
                                .putInt("overlayX", controlLp.x)
                                .putInt("overlayY", controlLp.y)
                                .apply();
                        return true;
                    }
                    return false;
                }
            });

            pause.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { setPaused(!isPausedByUser()); }
            });
            stop.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { stopMonitoring(); }
            });

            wm.addView(box, controlLp);
            updateControlOverlay();
        } catch (Throwable t) {
            controlOverlay = null;
            controlState = null;
            controlPause = null;
            controlLp = null;
            log("CONTROL_OVERLAY_FAIL", shortErr(t));
        }
    }

    private void updateControlOverlay() {
        if (controlOverlay == null || controlState == null || controlPause == null) return;
        try {
            long now = SystemClock.uptimeMillis();
            String state;
            if (!isEnabledByUser()) state = "DD监控：已停止";
            else if (manualPending) state = "DD监控：合格单已冻结";
            else if (isPausedByUser()) state = "DD监控：已暂停";
            else if (roundPauseUntil > now) {
                long sec = Math.max(1L, (roundPauseUntil - now + 999L) / 1000L);
                state = "DD监控：轮休 " + sec + "s";
            } else state = "DD监控：运行中";
            if (isObserveMode()) state += " [观察]";
            int enabledDays = enabledDayCount();
            String progress = enabledDays > 0 ? ("本轮 " + Math.min(scannedDaysInRound, enabledDays) + "/" + enabledDays) : "未选日期";
            if (dayCursor >= 0 && dayCursor < 7) progress += "  D" + (dayCursor + 1);
            controlState.setText(state + " | " + progress + "\n拖这里移动");

            boolean keep = getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("keepAwake", true);
            if (controlLp != null && wm != null && controlOverlay != null) {
                int wanted = controlLp.flags;
                if (keep) wanted |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                else wanted &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                if (wanted != controlLp.flags) {
                    controlLp.flags = wanted;
                    try { wm.updateViewLayout(controlOverlay, controlLp); } catch (Throwable ignored) {}
                }
            }
            controlPause.setText(isPausedByUser() ? "继续" : "暂停");
            controlPause.setEnabled(!manualPending);
        } catch (Throwable ignored) {}
    }

    private void removeControlOverlay() {
        if (controlOverlay != null && wm != null) {
            try { wm.removeView(controlOverlay); } catch (Throwable ignored) {}
        }
        controlOverlay = null;
        controlState = null;
        controlPause = null;
        controlLp = null;
    }

    private boolean isEnabledByUser() {
        return getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("enabled", false);
    }

    private double numPref(String key, double def) {
        try { return Double.parseDouble(getSharedPreferences("cfg", MODE_PRIVATE).getString(key, String.valueOf(def))); }
        catch (Throwable t) { return def; }
    }

    private static String fmt(double v) { return String.format(Locale.US, "%.2f", v); }

    private static double parseMoney(String s) {
        if (s == null) return 0;
        Matcher m = Pattern.compile("\\$\\s*([0-9]+(?:\\.[0-9]{1,2})?)").matcher(s);
        try { return m.find() ? Double.parseDouble(m.group(1)) : 0; } catch (Throwable t) { return 0; }
    }

    private final Map<String, Long> logThrottle = new HashMap<String, Long>();
    private void logOnce(String type, String key, String msg) {
        String k = type + "|" + key;
        long now = System.currentTimeMillis();
        Long prev = logThrottle.get(k);
        if (prev != null && now - prev.longValue() < 15000) return;
        logThrottle.put(k, now);
        log(type, msg);
    }
    private void logThrottled(String type, String msg, long interval) {
        long now = System.currentTimeMillis();
        Long prev = logThrottle.get(type);
        if (prev != null && now - prev.longValue() < interval) return;
        logThrottle.put(type, now);
        log(type, msg);
    }

    private void log(String type, String msg) {
        try {
            File dir = getExternalFilesDir(null);
            if (dir == null) return;
            File f = new File(dir, "dd_offer_monitor.log");
            if (f.exists() && f.length() > MAX_LOG_BYTES) {
                File old = new File(dir, "dd_offer_monitor.log.1");
                if (old.exists()) old.delete();
                if (!f.renameTo(old)) f.delete();
            }
            FileWriter w = new FileWriter(f, true);
            String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
            w.write(ts + "\t" + type + "\t" + (msg == null ? "" : msg.replace('\n', ' ')) + "\n");
            w.close();
        } catch (Throwable ignored) {}
    }

    private void setStatus(String msg) {
        long now = SystemClock.uptimeMillis();
        if (now - lastStatusAt < 180) return;
        lastStatusAt = now;
        try {
            getSharedPreferences("cfg", MODE_PRIVATE).edit()
                    .putString("diagStatus", msg == null ? "" : msg)
                    .putLong("diagStatusAt", System.currentTimeMillis())
                    .apply();
        } catch (Throwable ignored) {}
    }

    private static String shortErr(Throwable t) {
        if (t == null) return "";
        String m = t.getMessage();
        return t.getClass().getSimpleName() + (m == null ? "" : ":" + m);
    }
    private static String compact(String s, int max) {
        if (s == null) return "";
        String x = s.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        return x.length() <= max ? x : x.substring(0, max) + "…";
    }

    static final class Node {
        final AccessibilityNodeInfo node;
        final String text;
        final String cls;
        final String id;
        final Rect rect;
        final boolean selected;
        final boolean checked;
        final boolean clickable;
        final boolean enabled;
        Node(AccessibilityNodeInfo node, String text, String cls, String id, Rect rect,
             boolean selected, boolean checked, boolean clickable, boolean enabled) {
            this.node = node; this.text = text; this.cls = cls; this.id = id; this.rect = rect;
            this.selected = selected; this.checked = checked; this.clickable = clickable; this.enabled = enabled;
        }
    }

    static final class Snapshot {
        final List<Node> nodes;
        final Rect rootRect;
        private String lastDateSource = "";
        Snapshot(List<Node> nodes, Rect rootRect) { this.nodes = nodes; this.rootRect = rootRect; }

        String dateSource() { return lastDateSource; }

        static Snapshot build(AccessibilityNodeInfo root) {
            ArrayList<Node> out = new ArrayList<Node>();
            Rect rr = new Rect();
            try { root.getBoundsInScreen(rr); } catch (Throwable ignored) {}
            ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<AccessibilityNodeInfo>();
            q.add(root);
            int cap = 1000;
            while (!q.isEmpty() && out.size() < cap) {
                AccessibilityNodeInfo n = q.removeFirst();
                String txt = nodeText(n);
                Rect r = new Rect();
                try { n.getBoundsInScreen(r); } catch (Throwable ignored) {}
                String cls = n.getClassName() == null ? "" : n.getClassName().toString();
                String id = n.getViewIdResourceName() == null ? "" : n.getViewIdResourceName();
                out.add(new Node(n, txt, cls, id, r, n.isSelected(), n.isChecked(), n.isClickable(), n.isEnabled()));
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) q.addLast(c);
                }
            }
            return new Snapshot(out, rr);
        }

        boolean hasAny(String... phrases) {
            for (Node n : nodes) {
                String l = n.text.toLowerCase(Locale.US);
                for (String p : phrases) if (l.contains(p.toLowerCase(Locale.US))) return true;
            }
            return false;
        }

        boolean looksLoading() {
            if (!moneyNodes().isEmpty()) return false;
            if (hasAny("loading", "please wait", "refreshing offers")) return true;
            int screenH = rootRect.height() > 0 ? rootRect.height() : 2400;
            for (Node n : nodes) {
                String c = n.cls == null ? "" : n.cls.toLowerCase(Locale.US);
                if (c.contains("progressbar") && !n.rect.isEmpty()
                        && n.rect.centerY() > screenH * 0.18f && n.rect.centerY() < screenH * 0.88f) return true;
            }
            return false;
        }

        boolean hasSensitiveScreen() {
            return hasAny("verify your identity", "identity verification", "take a selfie",
                    "complete identity check", "sign in to dash", "log in to dash",
                    "enter verification code", "captcha");
        }

        Node findExactAny(String... vals) {
            for (Node n : nodes) for (String v : vals) if (n.text.equalsIgnoreCase(v)) return n;
            return null;
        }

        boolean hasProtectedFinalAction() {
            for (Node n : nodes) if (isProtectedText(n.text)) return true;
            return false;
        }

        boolean looksLikeOfferList() {
            if (!moneyNodes().isEmpty()) return true;
            Node offers = findExactAny("Offers");
            if (offers != null && (offers.selected || offers.checked)) return true;
            // Empty Offers page text seen on the user's current DoorDash Schedule screen.
            if (hasAny("nothing available to schedule", "available to schedule today",
                    "nothing available", "no offers available")) return true;
            return false;
        }

        List<Node> moneyNodes() {
            ArrayList<Node> a = new ArrayList<Node>();
            Pattern exact = Pattern.compile("^\\s*\\$\\s*[0-9]+(?:\\.[0-9]{1,2})?\\s*$");
            for (Node n : nodes) {
                if (exact.matcher(n.text).matches()) a.add(n);
            }
            Collections.sort(a, new Comparator<Node>() {
                @Override public int compare(Node x, Node y) {
                    int dy = Integer.compare(x.rect.top, y.rect.top);
                    return dy != 0 ? dy : Integer.compare(x.rect.left, y.rect.left);
                }
            });
            return a;
        }

        double bestDetailMoney() {
            List<Node> m = moneyNodes();
            double best = 0;
            for (Node n : m) {
                double v = parseMoney(n.text);
                // Detail pay is normally the prominent amount. Prefer a plausible offer amount.
                if (v > best && v < 10000) best = v;
            }
            return best;
        }

        Double findMiles() {
            Pattern p = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s*(?:mi|mile|miles)\\b", Pattern.CASE_INSENSITIVE);
            for (Node n : nodes) {
                Matcher m = p.matcher(n.text);
                if (m.find()) {
                    try { return Double.valueOf(Double.parseDouble(m.group(1))); } catch (Throwable ignored) {}
                }
            }
            return null;
        }

        List<Node> dateButtons() {
            lastDateSource = "";

            // First choice: faithfully port NovaFlow's working date-row heuristic.
            // NovaFlow does not read the visible day number at all. It collects every
            // android.widget.Button, groups them by Y, and uses the row containing seven buttons.
            // DoorDash may therefore expose the seven date cells as empty Button nodes even when
            // the 8/9/10 labels are not available as accessible text.
            ArrayList<Node> buttonRow = novaStyleSevenButtonRow();
            if (buttonRow.size() == 7) {
                lastDateSource = "button-row";
                return buttonRow;
            }

            ArrayList<Node> candidates = new ArrayList<Node>();
            int screenH = rootRect.height() > 0 ? rootRect.height() : 2400;
            int screenW = rootRect.width() > 0 ? rootRect.width() : 1080;
            int topLimit = (int) (screenH * 0.34f);

            // Semantic fallback for builds that expose the visible date text.
            for (Node n : nodes) {
                if (n.rect.isEmpty() || n.rect.top < 0 || n.rect.top > topLimit) continue;
                if (!isExactDayNumber(n.text)) continue;
                Node promoted = promoteToClickableAncestor(n);
                if (promoted != null) addDateCandidateDedup(candidates, withVisibleDateText(promoted, n.text));
                else addDateCandidateDedup(candidates, n);
            }

            for (Node n : nodes) {
                if (n.rect.isEmpty() || n.rect.top < 0 || n.rect.top > topLimit) continue;
                if (!n.enabled) continue;
                if (!(n.clickable || n.selected || n.checked || n.cls.contains("Button"))) continue;
                if (!dateLike(n.text)) continue;
                addDateCandidateDedup(candidates, n);
            }

            if (candidates.size() < 2) return candidates;
            ArrayList<Node> best = new ArrayList<Node>();
            int bestScore = Integer.MIN_VALUE;
            int yTol = Math.max(56, screenH / 28);
            for (Node seed : candidates) {
                ArrayList<Node> band = new ArrayList<Node>();
                for (Node x : candidates) {
                    if (Math.abs(x.rect.centerY() - seed.rect.centerY()) <= yTol) {
                        addDateCandidateDedup(band, x);
                    }
                }
                int numeric = 0, clickable = 0, state = 0;
                for (Node x : band) {
                    if (containsDayNumber(x.text)) numeric++;
                    if (x.clickable) clickable++;
                    if (x.selected || x.checked) state++;
                }
                int score = band.size() * 4 + numeric * 8 + clickable * 3 + state * 2;
                if (band.size() >= 2 && score > bestScore) {
                    bestScore = score;
                    best = band;
                }
            }

            Collections.sort(best, new Comparator<Node>() {
                @Override public int compare(Node a, Node b) { return Integer.compare(a.rect.centerX(), b.rect.centerX()); }
            });

            ArrayList<Node> columns = new ArrayList<Node>();
            int xTol = Math.max(28, screenW / 30);
            for (Node n : best) {
                boolean merged = false;
                for (int i = 0; i < columns.size(); i++) {
                    Node x = columns.get(i);
                    if (Math.abs(x.rect.centerX() - n.rect.centerX()) <= xTol) {
                        if (dateQuality(n) > dateQuality(x)) columns.set(i, n);
                        merged = true;
                        break;
                    }
                }
                if (!merged) columns.add(n);
            }
            Collections.sort(columns, new Comparator<Node>() {
                @Override public int compare(Node a, Node b) { return Integer.compare(a.rect.centerX(), b.rect.centerX()); }
            });
            if (columns.size() > 7) columns = new ArrayList<Node>(columns.subList(0, 7));
            if (columns.size() >= 2) lastDateSource = "semantic";
            return columns;
        }

        private ArrayList<Node> novaStyleSevenButtonRow() {
            int screenH = rootRect.height() > 0 ? rootRect.height() : 2400;
            int screenW = rootRect.width() > 0 ? rootRect.width() : 1080;
            int topLimit = (int) (screenH * 0.42f);
            ArrayList<Node> buttons = new ArrayList<Node>();

            for (Node n : nodes) {
                if (!"android.widget.Button".equals(n.cls)) continue;
                if (!n.enabled || n.rect.isEmpty()) continue;
                int cy = n.rect.centerY();
                if (cy < 0 || cy > topLimit) continue;
                if (isProtectedText(n.text)) continue;
                addByBoundsDedup(buttons, n);
            }
            if (buttons.size() < 7) return new ArrayList<Node>();

            // Stage 1: exact-centerY grouping, matching NovaFlow's yMap[item.y].
            Map<Integer, ArrayList<Node>> exact = new HashMap<Integer, ArrayList<Node>>();
            for (Node n : buttons) {
                int y = n.rect.centerY();
                ArrayList<Node> row = exact.get(Integer.valueOf(y));
                if (row == null) {
                    row = new ArrayList<Node>();
                    exact.put(Integer.valueOf(y), row);
                }
                addByBoundsDedup(row, n);
            }
            ArrayList<Node> best = chooseSevenButtonRow(new ArrayList<ArrayList<Node>>(exact.values()), screenW);
            if (best.size() == 7) return best;

            // Stage 2: Android versions can differ by a few pixels in bounds. Keep NovaFlow's
            // concept but allow a very small deterministic Y tolerance.
            int yTol = Math.max(6, screenH / 320);
            ArrayList<ArrayList<Node>> bands = new ArrayList<ArrayList<Node>>();
            for (Node seed : buttons) {
                ArrayList<Node> band = new ArrayList<Node>();
                for (Node n : buttons) {
                    if (Math.abs(n.rect.centerY() - seed.rect.centerY()) <= yTol) addByBoundsDedup(band, n);
                }
                bands.add(band);
            }
            return chooseSevenButtonRow(bands, screenW);
        }

        private static ArrayList<Node> chooseSevenButtonRow(List<ArrayList<Node>> rows, int screenW) {
            ArrayList<Node> best = new ArrayList<Node>();
            double bestScore = -1e9;
            for (ArrayList<Node> raw : rows) {
                if (raw.size() < 7) continue;
                ArrayList<Node> row = new ArrayList<Node>(raw);
                Collections.sort(row, new Comparator<Node>() {
                    @Override public int compare(Node a, Node b) { return Integer.compare(a.rect.centerX(), b.rect.centerX()); }
                });

                // If duplicate/extra Button nodes exist on the same horizontal band, evaluate
                // every consecutive seven-node window and keep the evenly-spaced wide row.
                for (int start = 0; start + 7 <= row.size(); start++) {
                    ArrayList<Node> seven = new ArrayList<Node>(row.subList(start, start + 7));
                    int span = seven.get(6).rect.centerX() - seven.get(0).rect.centerX();
                    if (span < screenW * 0.52f) continue;

                    double mean = span / 6.0;
                    if (mean <= 0) continue;
                    double dev = 0;
                    int minGap = Integer.MAX_VALUE;
                    int maxGap = 0;
                    for (int i = 1; i < seven.size(); i++) {
                        int gap = seven.get(i).rect.centerX() - seven.get(i - 1).rect.centerX();
                        if (gap <= 0) { dev = 1e9; break; }
                        minGap = Math.min(minGap, gap);
                        maxGap = Math.max(maxGap, gap);
                        dev += Math.abs(gap - mean) / mean;
                    }
                    if (dev >= 1e8) continue;
                    if (minGap <= 0 || maxGap > minGap * 2.1) continue;

                    int stateCount = 0;
                    for (Node n : seven) if (n.selected || n.checked) stateCount++;
                    double score = span - dev * 180.0 + stateCount * 120.0;
                    if (score > bestScore) {
                        bestScore = score;
                        best = seven;
                    }
                }
            }
            return best;
        }

        private static void addByBoundsDedup(List<Node> list, Node n) {
            for (Node x : list) {
                if (x.rect.equals(n.rect) && x.cls.equals(n.cls)) return;
            }
            list.add(n);
        }

        private Node promoteToClickableAncestor(Node visible) {
            AccessibilityNodeInfo x = visible.node;
            for (int depth = 0; depth < 7 && x != null; depth++) {
                if (x.isEnabled() && (x.isClickable() || x.isSelected() || x.isChecked())) {
                    Rect r = new Rect();
                    try { x.getBoundsInScreen(r); } catch (Throwable ignored) {}
                    String cls = x.getClassName() == null ? "" : x.getClassName().toString();
                    String id = x.getViewIdResourceName() == null ? "" : x.getViewIdResourceName();
                    return new Node(x, nodeText(x), cls, id, r, x.isSelected(), x.isChecked(), x.isClickable(), x.isEnabled());
                }
                x = x.getParent();
            }
            return null;
        }

        private static Node withVisibleDateText(Node container, String visibleText) {
            String t = container.text == null || container.text.trim().length() == 0 ? visibleText : container.text;
            // If the container has generic/no numeric semantics, preserve the visible number for diagnostics.
            if (!containsDayNumber(t) && containsDayNumber(visibleText)) t = visibleText;
            return new Node(container.node, t, container.cls, container.id, container.rect,
                    container.selected, container.checked, container.clickable, container.enabled);
        }

        private static boolean isExactDayNumber(String text) {
            if (text == null) return false;
            String t = text.trim();
            if (!t.matches("\\d{1,2}")) return false;
            try {
                int v = Integer.parseInt(t);
                return v >= 1 && v <= 31;
            } catch (Throwable ignored) { return false; }
        }

        private static boolean containsDayNumber(String text) {
            if (text == null) return false;
            Matcher m = Pattern.compile("(?:^|\\D)([1-9]|[12][0-9]|3[01])(?:\\D|$)").matcher(text);
            return m.find();
        }

        private static int dateQuality(Node n) {
            int q = 0;
            if (dateLike(n.text)) q += 8;
            if (n.selected || n.checked) q += 4;
            if (n.clickable) q += 2;
            if (n.cls.contains("Button")) q += 1;
            return q;
        }

        private static boolean dateLike(String text) {
            if (text == null) return false;
            String t = text.toLowerCase(Locale.US).replace('\n', ' ').trim();
            if (t.matches(".*\\b(mon|monday|tue|tues|tuesday|wed|wednesday|thu|thur|thurs|thursday|fri|friday|sat|saturday|sun|sunday)\\b.*")) return true;
            return t.matches(".*(?:^|\\D)(?:[1-9]|[12][0-9]|3[01])(?:\\D|$).*");
        }

        private static void addDateCandidateDedup(List<Node> list, Node n) {
            for (int i = 0; i < list.size(); i++) {
                Node x = list.get(i);
                if (Math.abs(x.rect.centerX() - n.rect.centerX()) <= 18
                        && Math.abs(x.rect.centerY() - n.rect.centerY()) <= 18) {
                    if (dateQuality(n) > dateQuality(x)) list.set(i, n);
                    return;
                }
            }
            list.add(n);
        }

        String dateDiagnostic() {
            StringBuilder b = new StringBuilder("topControls=");
            int shown = 0;
            int screenH = rootRect.height() > 0 ? rootRect.height() : 2400;
            for (Node n : nodes) {
                if (n.rect.isEmpty() || n.rect.top > screenH * 0.5f) continue;
                if (!(n.clickable || n.cls.contains("Button") || n.selected || n.checked)) continue;
                if (shown++ > 0) b.append(" | ");
                b.append('[').append(compact(n.text, 36)).append(" cls=")
                        .append(compact(n.cls, 22)).append(" x=").append(n.rect.centerX())
                        .append(" y=").append(n.rect.centerY()).append(" c=").append(n.clickable)
                        .append(" s=").append(n.selected || n.checked).append(']');
                if (shown >= 18) break;
            }
            return b.toString();
        }

        String offerIdentity(Node money, int dayCursor) {
            String summary = cardSummary(money).toLowerCase(Locale.US)
                    .replaceAll("\\s+", " ").trim();
            String day = dayCursor >= 0 && dayCursor < 7 ? ("D" + (dayCursor + 1)) : "D?";
            return day + "|" + money.text.trim() + "|" + Integer.toHexString(summary.hashCode());
        }

        String offerKey(Node money) {
            return money.text + "@" + (money.rect.centerY() / 24) + "|" + compact(cardSummary(money), 120);
        }

        String cardSummary(Node money) {
            if (money == null) return "";
            StringBuilder b = new StringBuilder();
            int cy = money.rect.centerY();
            int range = rootRect.height() > 0 ? rootRect.height() / 7 : 320;
            for (Node n : nodes) {
                if (n.text.length() == 0) continue;
                if (Math.abs(n.rect.centerY() - cy) <= range) {
                    if (b.length() > 0) b.append(" • ");
                    b.append(n.text);
                    if (b.length() > 220) break;
                }
            }
            return b.toString();
        }

        String fingerprint() {
            StringBuilder b = new StringBuilder();
            int k = 0;
            for (Node n : nodes) {
                if (n.text.length() == 0) continue;
                b.append(n.text).append('@').append(n.rect.left / 12).append(',').append(n.rect.top / 12).append(':').append(n.selected ? 'S' : '-').append(n.checked ? 'K' : '-').append(n.clickable ? 'C' : '-').append('|');
                if (++k >= 36) break;
            }
            return Integer.toHexString(b.toString().hashCode());
        }

        String summary() {
            StringBuilder b = new StringBuilder();
            int k = 0;
            for (Node n : nodes) {
                if (n.text.length() == 0) continue;
                if (b.length() > 0) b.append(" • ");
                b.append(n.text);
                if (++k >= 16 || b.length() > 300) break;
            }
            return b.toString();
        }
    }
}
