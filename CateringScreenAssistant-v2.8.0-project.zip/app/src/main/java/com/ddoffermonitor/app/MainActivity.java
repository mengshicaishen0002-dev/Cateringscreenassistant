package com.ddoffermonitor.app;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.Gravity;
import android.view.accessibility.AccessibilityManager;
import android.widget.*;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String DASHER = "com.doordash.driverapp";
    private SharedPreferences prefs;
    private EditText minPay, minPpm, maxMiles;
    private final CheckBox[] days = new CheckBox[7];
    private Switch enable;
    private CheckBox soundAlert;
    private CheckBox vibrateAlert;
    private CheckBox keepAwake;
    private CheckBox observeOnly;
    private Button pauseResume;
    private Button stopMonitor;
    private TextView serviceState;
    private TextView diagState;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable diagUpdater = new Runnable() {
        @Override public void run() {
            refreshDiagnostic();
            uiHandler.postDelayed(this, 700);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        buildUi();
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 40, 36, 40);
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("DD Offer Monitor  v1.2.1");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("7天自动轮询/筛选；合格单立即提醒；最终 Claim 必须手动。\n无卡密、无联网、无 Root/Hook。\n");
        sub.setTextSize(15);
        root.addView(sub);

        serviceState = new TextView(this);
        serviceState.setTextSize(15);
        root.addView(serviceState);

        diagState = new TextView(this);
        diagState.setTextSize(14);
        diagState.setText("实时诊断：等待监控服务数据…");
        root.addView(diagState);

        enable = new Switch(this);
        enable.setText("启用监控");
        enable.setChecked(prefs.getBoolean("enabled", false));
        root.addView(enable);
        enable.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("enabled", isChecked).putBoolean("paused", false).apply();
            if (!isChecked) Toast.makeText(this, "监控已停止", Toast.LENGTH_SHORT).show();
            refreshControlButtons();
        });

        LinearLayout controlRow = new LinearLayout(this);
        controlRow.setOrientation(LinearLayout.HORIZONTAL);
        pauseResume = new Button(this);
        pauseResume.setText("暂停监控");
        stopMonitor = new Button(this);
        stopMonitor.setText("停止监控");
        controlRow.addView(pauseResume, new LinearLayout.LayoutParams(0, -2, 1f));
        controlRow.addView(stopMonitor, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(controlRow);
        pauseResume.setOnClickListener(v -> {
            boolean paused = prefs.getBoolean("paused", false);
            prefs.edit().putBoolean("enabled", true).putBoolean("paused", !paused).apply();
            enable.setChecked(true);
            refreshControlButtons();
            Toast.makeText(this, paused ? "监控继续" : "监控已暂停", Toast.LENGTH_SHORT).show();
        });
        stopMonitor.setOnClickListener(v -> {
            prefs.edit().putBoolean("enabled", false).putBoolean("paused", false).apply();
            enable.setChecked(false);
            refreshControlButtons();
            Toast.makeText(this, "监控已停止", Toast.LENGTH_SHORT).show();
        });

        TextView daysLabel = new TextView(this);
        daysLabel.setText("监控日期（D1–D7）");
        daysLabel.setTextSize(15);
        root.addView(daysLabel);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            days[i] = new CheckBox(this);
            days[i].setText("D" + (i + 1));
            // Full product intent is seven-day monitoring; a saved preference always wins.
            days[i].setChecked(prefs.getBoolean("d" + i, true));
            row.addView(days[i]);
        }
        root.addView(row);

        minPay = addField(root, "最低金额 ($)", prefs.getString("minPay", "30"));
        minPpm = addField(root, "最低 $/mi", prefs.getString("minPpm", "2.0"));
        maxMiles = addField(root, "最大 miles", prefs.getString("maxMiles", "99"));

        observeOnly = new CheckBox(this);
        observeOnly.setText("观察模式（只读取当前页面，不自动切日期/打开详情）");
        observeOnly.setChecked("observe".equals(prefs.getString("monitorMode", "stable")));
        root.addView(observeOnly);

        soundAlert = new CheckBox(this);
        soundAlert.setText("合格单声音提醒");
        soundAlert.setChecked(prefs.getBoolean("soundAlert", true));
        root.addView(soundAlert);

        vibrateAlert = new CheckBox(this);
        vibrateAlert.setText("合格单震动提醒");
        vibrateAlert.setChecked(prefs.getBoolean("vibrateAlert", true));
        root.addView(vibrateAlert);

        keepAwake = new CheckBox(this);
        keepAwake.setText("监控时保持屏幕常亮");
        keepAwake.setChecked(prefs.getBoolean("keepAwake", true));
        root.addView(keepAwake);

        Button save = new Button(this);
        save.setText("保存设置");
        root.addView(save);
        save.setOnClickListener(v -> save());

        Button acc = new Button(this);
        acc.setText("打开无障碍设置");
        root.addView(acc);
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        Button dasher = new Button(this);
        dasher.setText("打开 Dasher");
        root.addView(dasher);
        dasher.setOnClickListener(v -> openDasher());

        Button test = new Button(this);
        test.setText("测试声音 + 震动 + 通知");
        root.addView(test);
        test.setOnClickListener(v -> testAlert());

        LinearLayout logRow = new LinearLayout(this);
        logRow.setOrientation(LinearLayout.HORIZONTAL);
        Button recentLog = new Button(this);
        recentLog.setText("查看最近日志");
        Button clearLog = new Button(this);
        clearLog.setText("清空日志");
        logRow.addView(recentLog, new LinearLayout.LayoutParams(0, -2, 1f));
        logRow.addView(clearLog, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(logRow);
        recentLog.setOnClickListener(v -> showRecentLog());
        clearLog.setOnClickListener(v -> clearLog());

        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        Button showStats = new Button(this);
        showStats.setText("查看统计");
        Button clearStats = new Button(this);
        clearStats.setText("清空统计");
        statsRow.addView(showStats, new LinearLayout.LayoutParams(0, -2, 1f));
        statsRow.addView(clearStats, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(statsRow);
        showStats.setOnClickListener(v -> showStats());
        clearStats.setOnClickListener(v -> clearStats());

        Button log = new Button(this);
        log.setText("显示日志位置");
        root.addView(log);
        log.setOnClickListener(v -> {
            File dir = getExternalFilesDir(null);
            String path = dir == null ? "外部文件目录暂不可用" : new File(dir, "dd_offer_monitor.log").getAbsolutePath();
            Toast.makeText(this, path, Toast.LENGTH_LONG).show();
        });

        TextView note = new TextView(this);
        note.setText("\n稳定模式：只在 Dasher Schedule → Offers 前台运行；D1→D7 状态驱动轮询。日期切换后至少等待 1.5 秒并确认页面稳定；一轮结束后 5/8/10 秒自适应轮休。页面内容在轮休期间确实发生变化时可提前唤醒检查。\n\n订单处理：金额先筛选；达到金额门槛才打开详情读取 miles 和 $/mi。相同订单使用内容指纹去重，不合格详情结果短期缓存，减少重复打开。发现合格预约单后立即冻结所有自动操作并提醒，最终 Claim and schedule / Claim / Acknowledge 永远由你手动。\n\n人工优先：检测到你在 Dasher 手动点击/滚动时会短暂让出控制，避免程序和手指抢操作。连续日期栏识别失败或点击失败、进入登录/身份验证页面时自动安全暂停并通知。\n\n观察模式：只读取当前 Offers 页面和记录日志，不自动切日期、不打开详情，适合 DoorDash 更新后先验证界面。\n\n统计：记录扫描轮数、日期数、唯一 offer、详情打开、各类过滤、合格单及人工 Claim 结果；可在主界面查看/清空。\n\n低干扰原则：事件驱动为主、低频看门狗兜底；无随机伪装、无隐藏无障碍、无设备指纹修改。\n");
        note.setTextSize(14);
        root.addView(note);
        setContentView(sv);
        refreshServiceState();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshServiceState();
        refreshControlButtons();
        uiHandler.removeCallbacks(diagUpdater);
        uiHandler.post(diagUpdater);
    }

    @Override protected void onPause() {
        uiHandler.removeCallbacks(diagUpdater);
        super.onPause();
    }

    private void refreshControlButtons() {
        if (pauseResume == null || stopMonitor == null) return;
        boolean enabled = prefs.getBoolean("enabled", false);
        boolean paused = prefs.getBoolean("paused", false);
        pauseResume.setText(paused ? "继续监控" : "暂停监控");
        pauseResume.setEnabled(enabled || paused);
        stopMonitor.setEnabled(enabled || paused);
    }

    private void refreshDiagnostic() {
        if (diagState == null) return;
        String s = prefs.getString("diagStatus", "等待监控服务数据…");
        long at = prefs.getLong("diagStatusAt", 0L);
        long age = at <= 0 ? -1 : Math.max(0L, (System.currentTimeMillis() - at) / 1000L);
        diagState.setText("实时诊断：" + s + (age >= 0 ? " | " + age + "秒前" : ""));
    }

    private void openDasher() {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                android.content.IntentSender sender = getPackageManager().getLaunchIntentSenderForPackage(DASHER);
                sender.sendIntent(this, 0, null, null, null);
                return;
            }
        } catch (Throwable ignored) { }
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(DASHER);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return;
            }
        } catch (Throwable ignored) { }
        Toast.makeText(this, "无法自动打开 Dasher，请手动切换到 Dasher", Toast.LENGTH_LONG).show();
    }

    private EditText addField(LinearLayout root, String label, String value) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(15);
        root.addView(t);
        EditText e = new EditText(this);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(value);
        root.addView(e);
        return e;
    }

    private void save() {
        if (!validNumber(minPay, 0.0, 10000.0, "最低金额") ||
                !validNumber(minPpm, 0.0, 1000.0, "最低 $/mi") ||
                !validNumber(maxMiles, 0.1, 10000.0, "最大 miles")) return;
        boolean any = false;
        for (CheckBox d : days) any |= d.isChecked();
        if (!any) {
            Toast.makeText(this, "至少选择一天", Toast.LENGTH_SHORT).show();
            return;
        }
        SharedPreferences.Editor ed = prefs.edit();
        ed.putBoolean("enabled", enable.isChecked());
        if (!enable.isChecked()) ed.putBoolean("paused", false);
        for (int i = 0; i < 7; i++) ed.putBoolean("d" + i, days[i].isChecked());
        ed.putString("minPay", minPay.getText().toString().trim());
        ed.putString("minPpm", minPpm.getText().toString().trim());
        ed.putString("maxMiles", maxMiles.getText().toString().trim());
        ed.putString("monitorMode", observeOnly.isChecked() ? "observe" : "stable");
        ed.putBoolean("soundAlert", soundAlert.isChecked());
        ed.putBoolean("vibrateAlert", vibrateAlert.isChecked());
        ed.putBoolean("keepAwake", keepAwake.isChecked());
        ed.apply();
        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
    }

    private File logFile() {
        File dir = getExternalFilesDir(null);
        return dir == null ? null : new File(dir, "dd_offer_monitor.log");
    }

    private void showRecentLog() {
        String text = "暂无日志";
        try {
            File f = logFile();
            if (f != null && f.exists()) {
                ArrayDeque<String> lines = new ArrayDeque<String>();
                BufferedReader r = new BufferedReader(new FileReader(f));
                String line;
                while ((line = r.readLine()) != null) {
                    if (lines.size() >= 60) lines.removeFirst();
                    lines.addLast(line);
                }
                r.close();
                if (!lines.isEmpty()) {
                    StringBuilder b = new StringBuilder();
                    for (String x : lines) b.append(x).append('\n');
                    text = b.toString();
                }
            }
        } catch (Throwable t) { text = "读取日志失败：" + t.getClass().getSimpleName(); }

        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(11);
        tv.setTextIsSelectable(true);
        tv.setPadding(24, 12, 24, 12);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("最近 60 条日志")
                .setView(sv)
                .setPositiveButton("关闭", null)
                .show();
    }

    private void clearLog() {
        new AlertDialog.Builder(this)
                .setTitle("清空日志")
                .setMessage("确定清空当前诊断日志吗？")
                .setNegativeButton("取消", null)
                .setPositiveButton("清空", (d, w) -> {
                    try {
                        File f = logFile();
                        if (f != null && f.exists()) f.delete();
                        File b = f == null ? null : new File(f.getParentFile(), "dd_offer_monitor.log.1");
                        if (b != null && b.exists()) b.delete();
                        Toast.makeText(this, "日志已清空", Toast.LENGTH_SHORT).show();
                    } catch (Throwable t) {
                        Toast.makeText(this, "清空失败", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showStats() {
        SharedPreferences st = getSharedPreferences("stats", MODE_PRIVATE);
        long started = st.getLong("startedAt", 0L);
        long latencyCount = st.getLong("candidateLatencyCount", 0L);
        long latencyTotal = st.getLong("candidateLatencyTotalMs", 0L);
        long avgLatency = latencyCount > 0 ? latencyTotal / latencyCount : 0L;
        StringBuilder b = new StringBuilder();
        b.append("统计开始：").append(formatTime(started)).append('\n');
        b.append("服务启动：").append(st.getLong("serviceStarts", 0L)).append('\n');
        b.append("完成轮次：").append(st.getLong("roundsCompleted", 0L)).append('\n');
        b.append("扫描日期：").append(st.getLong("daysScanned", 0L)).append('\n');
        b.append("唯一 Offer：").append(st.getLong("offersUnique", 0L)).append('\n');
        b.append("详情打开：").append(st.getLong("detailOpened", 0L)).append('\n');
        b.append("金额过滤：").append(st.getLong("rejectPay", 0L)).append('\n');
        b.append("里程过滤：").append(st.getLong("rejectMiles", 0L)).append('\n');
        b.append("$/mi 过滤：").append(st.getLong("rejectPpm", 0L)).append('\n');
        b.append("详情解析失败：").append(st.getLong("parseFail", 0L)).append('\n');
        b.append("合格单：").append(st.getLong("candidates", 0L)).append('\n');
        b.append("Claim 确认成功：").append(st.getLong("claimConfirmed", 0L)).append('\n');
        b.append("Claim 失败/已被抢：").append(st.getLong("claimFailed", 0L)).append('\n');
        b.append("Claim 结果未确认：").append(st.getLong("claimUnverified", 0L)).append('\n');
        b.append("安全暂停：").append(st.getLong("safetyPauses", 0L)).append('\n');
        b.append("轮休提前唤醒：").append(st.getLong("roundWakeups", 0L)).append('\n');
        if (latencyCount > 0) b.append("合格判定平均耗时：").append(avgLatency).append(" ms\n");
        long lastLat = st.getLong("lastCandidateLatencyMs", -1L);
        if (lastLat >= 0) b.append("最近一次判定耗时：").append(lastLat).append(" ms\n");
        String lastOffer = st.getString("lastOffer", "");
        if (lastOffer.length() > 0) b.append("\n最近 Offer：\n").append(lastOffer).append('\n');
        String lastCandidate = st.getString("lastCandidate", "");
        if (lastCandidate.length() > 0) b.append("\n最近合格单：\n").append(lastCandidate).append('\n');

        TextView tv = new TextView(this);
        tv.setText(b.toString());
        tv.setTextSize(13);
        tv.setTextIsSelectable(true);
        tv.setPadding(24, 12, 24, 12);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this).setTitle("v1.2 运行统计").setView(sv).setPositiveButton("关闭", null).show();
    }

    private void clearStats() {
        new AlertDialog.Builder(this)
                .setTitle("清空统计")
                .setMessage("只清空运行统计，不会清除你的筛选设置。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清空", (d, w) -> {
                    getSharedPreferences("stats", MODE_PRIVATE).edit().clear().apply();
                    Toast.makeText(this, "统计已清空", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private String formatTime(long millis) {
        if (millis <= 0L) return "尚未开始";
        try {
            return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new java.util.Date(millis));
        } catch (Throwable t) { return String.valueOf(millis); }
    }

    private boolean validNumber(EditText e, double min, double max, String label) {
        try {
            double v = Double.parseDouble(e.getText().toString().trim());
            if (v >= min && v <= max) return true;
        } catch (Throwable ignored) { }
        Toast.makeText(this, label + " 数值无效", Toast.LENGTH_SHORT).show();
        return false;
    }

    private boolean isServiceEnabled() {
        try {
            AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            List<AccessibilityServiceInfo> services = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
            String expected = getPackageName() + "/" + OfferAccessibilityService.class.getName();
            for (AccessibilityServiceInfo info : services) {
                if (info.getResolveInfo() == null || info.getResolveInfo().serviceInfo == null) continue;
                String actual = info.getResolveInfo().serviceInfo.packageName + "/" + info.getResolveInfo().serviceInfo.name;
                if (expected.equals(actual)) return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private void refreshServiceState() {
        if (serviceState == null) return;
        boolean on = isServiceEnabled();
        serviceState.setText(on ? "无障碍服务：已开启 ✓" : "无障碍服务：未开启（必须开启）");
    }

    private void testAlert() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(600);
            }
        } catch (Throwable ignored) { }
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) { }
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            String channel = "candidate";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(channel, "Offer alerts", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
            nb.setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("DD Offer Monitor 测试")
                    .setContentText("声音、震动、通知正常")
                    .setAutoCancel(true);
            nm.notify(1002, nb.build());
        } catch (Throwable ignored) { }
        Toast.makeText(this, String.format(Locale.US, "提醒测试已触发"), Toast.LENGTH_SHORT).show();
    }
}
