package com.ddoffermonitor.app;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.Gravity;
import android.view.accessibility.AccessibilityManager;
import android.widget.*;

import java.io.File;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String DASHER = "com.doordash.driverapp";
    private SharedPreferences prefs;
    private EditText minPay, minPpm, maxMiles;
    private final CheckBox[] days = new CheckBox[7];
    private Switch enable;
    private Button pauseResume;
    private Button stopMonitor;
    private TextView serviceState;
    private TextView diagState;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable diagUpdater = new Runnable() {
        @Override public void run() {
            refreshDiagnostic();
            uiHandler.postDelayed(this, 700);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        buildUi();
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 40, 36, 40);
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("DD Offer Monitor");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("7天自动轮询/筛选；合格单立即提醒；最终 Claim 必须手动。\n无卡密、无联网、无 Root/Hook。\n");
        sub.setTextSize(15);
        root.addView(sub);

        serviceState = new TextView(this);
        serviceState.setTextSize(15);
        root.addView(serviceState);

        diagState = new TextView(this);
        diagState.setTextSize(14);
        diagState.setText("实时诊断：等待监控服务数据…");
        root.addView(diagState);

        enable = new Switch(this);
        enable.setText("启用监控");
        enable.setChecked(prefs.getBoolean("enabled", false));
        root.addView(enable);
        enable.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("enabled", isChecked).putBoolean("paused", false).apply();
            if (!isChecked) Toast.makeText(this, "监控已停止", Toast.LENGTH_SHORT).show();
            refreshControlButtons();
        });

        LinearLayout controlRow = new LinearLayout(this);
        controlRow.setOrientation(LinearLayout.HORIZONTAL);
        pauseResume = new Button(this);
        pauseResume.setText("暂停监控");
        stopMonitor = new Button(this);
        stopMonitor.setText("停止监控");
        controlRow.addView(pauseResume, new LinearLayout.LayoutParams(0, -2, 1f));
        controlRow.addView(stopMonitor, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(controlRow);
        pauseResume.setOnClickListener(v -> {
            boolean paused = prefs.getBoolean("paused", false);
            prefs.edit().putBoolean("enabled", true).putBoolean("paused", !paused).apply();
            enable.setChecked(true);
            refreshControlButtons();
            Toast.makeText(this, paused ? "监控继续" : "监控已暂停", Toast.LENGTH_SHORT).show();
        });
        stopMonitor.setOnClickListener(v -> {
            prefs.edit().putBoolean("enabled", false).putBoolean("paused", false).apply();
            enable.setChecked(false);
            refreshControlButtons();
            Toast.makeText(this, "监控已停止", Toast.LENGTH_SHORT).show();
        });

        TextView daysLabel = new TextView(this);
        daysLabel.setText("监控日期（D1–D7）");
        daysLabel.setTextSize(15);
        root.addView(daysLabel);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 7; i++) {
            days[i] = new CheckBox(this);
            days[i].setText("D" + (i + 1));
            // Full product intent is seven-day monitoring; a saved preference always wins.
            days[i].setChecked(prefs.getBoolean("d" + i, true));
            row.addView(days[i]);
        }
        root.addView(row);

        minPay = addField(root, "最低金额 ($)", prefs.getString("minPay", "30"));
        minPpm = addField(root, "最低 $/mi", prefs.getString("minPpm", "2.0"));
        maxMiles = addField(root, "最大 miles", prefs.getString("maxMiles", "99"));

        Button save = new Button(this);
        save.setText("保存设置");
        root.addView(save);
        save.setOnClickListener(v -> save());

        Button acc = new Button(this);
        acc.setText("打开无障碍设置");
        root.addView(acc);
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        Button dasher = new Button(this);
        dasher.setText("打开 Dasher");
        root.addView(dasher);
        dasher.setOnClickListener(v -> openDasher());

        Button test = new Button(this);
        test.setText("测试声音 + 震动 + 通知");
        root.addView(test);
        test.setOnClickListener(v -> testAlert());

        Button log = new Button(this);
        log.setText("显示日志位置");
        root.addView(log);
        log.setOnClickListener(v -> {
            File dir = getExternalFilesDir(null);
            String path = dir == null ? "外部文件目录暂不可用" : new File(dir, "dd_offer_monitor.log").getAbsolutePath();
            Toast.makeText(this, path, Toast.LENGTH_LONG).show();
        });

        TextView note = new TextView(this);
        note.setText("\n运行逻辑：只在 Dasher 前台处理。D1→D7 循环扫描；切换日期后至少等待 1.5 秒并确认页面状态后再读取；一轮结束后按空轮次数自适应休息 5/8/10 秒。低金额直接跳过，达到金额门槛才进入详情读取 miles；不合格返回继续扫描。发现合格预约单后立即冻结全部自动操作并提醒，最后的 Claim and schedule / Claim / Acknowledge 不会自动点击。\n\n控制：启用监控后会出现可拖动悬浮窗，可直接暂停/继续/停止；主界面也提供相同控制。\n\n低干扰模式：事件驱动为主，低频看门狗兜底；页面不变不重复点击；无随机伪装、无隐藏无障碍、无设备指纹修改。\n");
        note.setTextSize(14);
        root.addView(note);
        setContentView(sv);
        refreshServiceState();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshServiceState();
        refreshControlButtons();
        uiHandler.removeCallbacks(diagUpdater);
        uiHandler.post(diagUpdater);
    }

    @Override protected void onPause() {
        uiHandler.removeCallbacks(diagUpdater);
        super.onPause();
    }

    private void refreshControlButtons() {
        if (pauseResume == null || stopMonitor == null) return;
        boolean enabled = prefs.getBoolean("enabled", false);
        boolean paused = prefs.getBoolean("paused", false);
        pauseResume.setText(paused ? "继续监控" : "暂停监控");
        pauseResume.setEnabled(enabled || paused);
        stopMonitor.setEnabled(enabled || paused);
    }

    private void refreshDiagnostic() {
        if (diagState == null) return;
        String s = prefs.getString("diagStatus", "等待监控服务数据…");
        long at = prefs.getLong("diagStatusAt", 0L);
        long age = at <= 0 ? -1 : Math.max(0L, (System.currentTimeMillis() - at) / 1000L);
        diagState.setText("实时诊断：" + s + (age >= 0 ? " | " + age + "秒前" : ""));
    }

    private void openDasher() {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                android.content.IntentSender sender = getPackageManager().getLaunchIntentSenderForPackage(DASHER);
                sender.sendIntent(this, 0, null, null, null);
                return;
            }
        } catch (Throwable ignored) { }
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(DASHER);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return;
            }
        } catch (Throwable ignored) { }
        Toast.makeText(this, "无法自动打开 Dasher，请手动切换到 Dasher", Toast.LENGTH_LONG).show();
    }

    private EditText addField(LinearLayout root, String label, String value) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(15);
        root.addView(t);
        EditText e = new EditText(this);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(value);
        root.addView(e);
        return e;
    }

    private void save() {
        if (!validNumber(minPay, 0.0, 10000.0, "最低金额") ||
                !validNumber(minPpm, 0.0, 1000.0, "最低 $/mi") ||
                !validNumber(maxMiles, 0.1, 10000.0, "最大 miles")) return;
        boolean any = false;
        for (CheckBox d : days) any |= d.isChecked();
        if (!any) {
            Toast.makeText(this, "至少选择一天", Toast.LENGTH_SHORT).show();
            return;
        }
        SharedPreferences.Editor ed = prefs.edit();
        ed.putBoolean("enabled", enable.isChecked());
        if (!enable.isChecked()) ed.putBoolean("paused", false);
        for (int i = 0; i < 7; i++) ed.putBoolean("d" + i, days[i].isChecked());
        ed.putString("minPay", minPay.getText().toString().trim());
        ed.putString("minPpm", minPpm.getText().toString().trim());
        ed.putString("maxMiles", maxMiles.getText().toString().trim());
        ed.apply();
        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show();
    }

    private boolean validNumber(EditText e, double min, double max, String label) {
        try {
            double v = Double.parseDouble(e.getText().toString().trim());
            if (v >= min && v <= max) return true;
        } catch (Throwable ignored) { }
        Toast.makeText(this, label + " 数值无效", Toast.LENGTH_SHORT).show();
        return false;
    }

    private boolean isServiceEnabled() {
        try {
            AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
            List<AccessibilityServiceInfo> services = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
            String expected = getPackageName() + "/" + OfferAccessibilityService.class.getName();
            for (AccessibilityServiceInfo info : services) {
                if (info.getResolveInfo() == null || info.getResolveInfo().serviceInfo == null) continue;
                String actual = info.getResolveInfo().serviceInfo.packageName + "/" + info.getResolveInfo().serviceInfo.name;
                if (expected.equals(actual)) return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private void refreshServiceState() {
        if (serviceState == null) return;
        boolean on = isServiceEnabled();
        serviceState.setText(on ? "无障碍服务：已开启 ✓" : "无障碍服务：未开启（必须开启）");
    }

    private void testAlert() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(600);
            }
        } catch (Throwable ignored) { }
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) { }
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            String channel = "candidate";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(channel, "Offer alerts", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
            nb.setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("DD Offer Monitor 测试")
                    .setContentText("声音、震动、通知正常")
                    .setAutoCancel(true);
            nm.notify(1002, nb.build());
        } catch (Throwable ignored) { }
        Toast.makeText(this, String.format(Locale.US, "提醒测试已触发"), Toast.LENGTH_SHORT).show();
    }
}
