# ML Kit and AndroidX supply their own consumer rules.
