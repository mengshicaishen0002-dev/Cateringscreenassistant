package com.local.cateringscreenassistant;

public class QuickTreeBudgetPolicyTest {
    private static int n;
    private static void check(boolean value) { n++; if (!value) throw new AssertionError("case " + n); }
    public static void main(String[] args) {
        check(QuickTreeBudgetPolicy.maxNodes() == 128);
        check(QuickTreeBudgetPolicy.softBudgetMs() == 150L);
        check(QuickTreeBudgetPolicy.ocrBackoffMs() == 120L);
        check(!QuickTreeBudgetPolicy.elapsedBudgetExceeded(1000L, 1149L));
        check(QuickTreeBudgetPolicy.elapsedBudgetExceeded(1000L, 1150L));
        check(QuickTreeBudgetPolicy.shouldYieldToOcr(true, false));
        check(!QuickTreeBudgetPolicy.shouldYieldToOcr(true, true));
        check(!QuickTreeBudgetPolicy.shouldYieldToOcr(false, false));
        System.out.println(n + " quick-tree budget cases passed");
    }
}
