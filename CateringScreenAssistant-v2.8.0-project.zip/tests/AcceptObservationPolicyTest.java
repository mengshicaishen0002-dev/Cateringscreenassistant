package com.local.cateringscreenassistant;

public final class AcceptObservationPolicyTest {
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        String card = "$84.87 Est. 7.8 mi (~15 mins) Tomorrow at 3:50 PM, Chicken Maison • 21732 S Vermont Ave, Torrance, CA 90502, United States Large Order";
        String lateOcr = "Tomorrow • 1Offer 7.8 mi (~15 mins) Est. $84.87 Tomorrow at 3:50 PM Chicken Maison • 21732 S Vermont Ave, Torrance, CA 90502, United States Large Order";
        check(!AcceptObservationPolicy.shouldObserveOnly(true, 100, 0, card, lateOcr),
                "fence armed before dispatch");
        check(AcceptObservationPolicy.shouldObserveOnly(true, 100, 150, card, lateOcr),
                "same-card late OCR was not observer-only");
        check(!AcceptObservationPolicy.shouldObserveOnly(false, 100, 150, card, lateOcr),
                "inactive Accept should not fence callbacks");
        check(!AcceptObservationPolicy.shouldObserveOnly(true, 100, 150, card,
                lateOcr.replace("Chicken Maison", "Mendocino Farms")),
                "different merchant was incorrectly fenced");
        check(!AcceptObservationPolicy.shouldObserveOnly(true, 100, 150, card,
                lateOcr.replace("3:50 PM", "4:50 PM")),
                "different pickup time was incorrectly fenced");
        System.out.println("5 accept-observation fence cases passed");
    }
}
