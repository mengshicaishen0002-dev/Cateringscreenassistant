package com.local.cateringscreenassistant;

public class ActionGeometryTest {
    private static int tests;
    public static void main(String[] args) {
        eq(true, ActionGeometry.plausibleRightAction(1080, 820f));
        eq(false, ActionGeometry.plausibleRightAction(1080, 430f));
        near(260f, ActionGeometry.inferredLeftActionX(1080, 820f), 1f);
        eq(true, ActionGeometry.plausibleLeftAction(1080, 260f));
        eq(false, ActionGeometry.plausibleLeftAction(1080, 800f));
        near(820f, ActionGeometry.inferredRightActionX(1080, 260f), 1f);
        eq(true, ActionGeometry.plausibleActionY(2000, 1500f));
        eq(false, ActionGeometry.plausibleActionY(2000, 100f));
        // Clamp extreme OCR centers into the expected left/right action columns.
        near(151.2f, ActionGeometry.inferredLeftActionX(1080, 1040f), 1f);
        near(928.8f, ActionGeometry.inferredRightActionX(1080, 40f), 1f);
        System.out.println("Action geometry: " + tests + " tests passed");
    }
    private static void eq(boolean expected, boolean actual) {
        tests++;
        if (expected != actual) throw new AssertionError("expected=" + expected + " actual=" + actual);
    }
    private static void near(float expected, float actual, float tolerance) {
        tests++;
        if (Math.abs(expected - actual) > tolerance)
            throw new AssertionError("expected~=" + expected + " actual=" + actual);
    }
}
