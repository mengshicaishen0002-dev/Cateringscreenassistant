package com.local.cateringscreenassistant;

public class ActionGeometryTest {
    private static int tests;
    public static void main(String[] args) {
        eq(true, ActionGeometry.plausibleRightAction(1080, 820f));
        eq(false, ActionGeometry.plausibleRightAction(1080, 430f));
        near(260f, ActionGeometry.inferredLeftActionX(1080, 820f), 1f);
        eq(true, ActionGeometry.plausibleLeftAction(1080, 260f));
        eq(false, ActionGeometry.plausibleLeftAction(1080, 800f));
        near(820f, ActionGeometry.inferredRightActionX(1080, 260f), 1f);
        eq(true, ActionGeometry.plausibleActionY(2000, 1500f));
        eq(false, ActionGeometry.plausibleActionY(2000, 100f));
        near(151.2f, ActionGeometry.inferredLeftActionX(1080, 1040f), 1f);
        near(928.8f, ActionGeometry.inferredRightActionX(1080, 40f), 1f);

        // Real Galaxy A15 / DeliverThat list geometry from the user's screenshots.
        eq(true, ActionGeometry.plausibleActionRect(720, 1600, 77, 745, 339, 821, false));
        eq(true, ActionGeometry.plausibleActionRect(720, 1600, 370, 744, 633, 821, true));

        // Critical regression: the whole offer card must NEVER be accepted as Ignore/Accept.
        eq(false, ActionGeometry.plausibleActionRect(720, 1600, 46, 418, 664, 852, false));
        eq(false, ActionGeometry.plausibleActionRect(720, 1600, 46, 418, 664, 852, true));
        eq(false, ActionGeometry.plausibleActionRect(720, 1600, 60, 740, 650, 830, false));
        eq(false, ActionGeometry.plausibleActionRect(720, 1600, 60, 740, 650, 830, true));

        // A tiny details arrow/card affordance is not a structural action button.
        eq(false, ActionGeometry.plausibleStructuralButton(720, 1600, 620, 470, 652, 512));
        eq(true, ActionGeometry.plausibleStructuralButton(720, 1600, 77, 745, 339, 821));
        eq(true, ActionGeometry.plausibleStructuralButton(720, 1600, 370, 744, 633, 821));
        // Detail-screen action row from the same recording remains valid.
        eq(true, ActionGeometry.plausibleActionRect(720, 1600, 88, 1180, 330, 1265, false));
        eq(true, ActionGeometry.plausibleActionRect(720, 1600, 370, 1180, 650, 1265, true));

        // Stable tap stays inside the intended left/right action columns.
        near(100.8f, ActionGeometry.stableTapX(720, 30f, false), 0.5f);
        near(619.2f, ActionGeometry.stableTapX(720, 700f, true), 0.5f);
        near(208f, ActionGeometry.stableTapX(720, 208f, false), 0.5f);
        near(501f, ActionGeometry.stableTapX(720, 501f, true), 0.5f);

        System.out.println("Action geometry: " + tests + " tests passed");
    }
    private static void eq(boolean expected, boolean actual) {
        tests++;
        if (expected != actual) throw new AssertionError("expected=" + expected + " actual=" + actual);
    }
    private static void near(float expected, float actual, float tolerance) {
        tests++;
        if (Math.abs(expected - actual) > tolerance)
            throw new AssertionError("expected~=" + expected + " actual=" + actual);
    }
}
