package com.local.cateringscreenassistant;
public class FastSnapshotPolicyTest {
    static int n;
    static void check(boolean v){ n++; if(!v) throw new AssertionError("case "+n); }
    public static void main(String[] args){
        check(FastSnapshotPolicy.freshEnoughWithoutRefresh(0, true));
        check(FastSnapshotPolicy.freshEnoughWithoutRefresh(380, true));
        check(!FastSnapshotPolicy.freshEnoughWithoutRefresh(381, true));
        check(FastSnapshotPolicy.needsRefresh(381, true));
        check(FastSnapshotPolicy.needsRefresh(1091, true));
        check(FastSnapshotPolicy.needsRefresh(421, false));
        check(!FastSnapshotPolicy.hardExpired(2200));
        check(FastSnapshotPolicy.hardExpired(2201));
        check(FastSnapshotPolicy.hardExpired(-1));
        check(!FastSnapshotPolicy.needsFirstAcceptPageRecheck(0));
        check(!FastSnapshotPolicy.needsFirstAcceptPageRecheck(180));
        check(FastSnapshotPolicy.needsFirstAcceptPageRecheck(181));
        check(FastSnapshotPolicy.needsFirstAcceptPageRecheck(-1));
        System.out.println(n+" fast-snapshot freshness cases passed");
    }
}
