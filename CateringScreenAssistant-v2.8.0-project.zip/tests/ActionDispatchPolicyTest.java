package com.local.cateringscreenassistant;

public class ActionDispatchPolicyTest {
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        check(ActionDispatchPolicy.semanticObserveDelayMs() == 85L, "semantic observe delay changed");
        check(ActionDispatchPolicy.firstGestureDurationMs(true) == 55L, "Accept first gesture too short");
        check(ActionDispatchPolicy.firstGestureDurationMs(false) == 20L, "Reject first gesture changed");
        check(ActionDispatchPolicy.retryGestureDurationMs(2) == 55L, "second Accept retry duration");
        check(ActionDispatchPolicy.retryGestureDurationMs(3) == 65L, "third Accept retry duration");
        check(ActionDispatchPolicy.retryVariant(2) == 0, "second retry should use center");
        check(ActionDispatchPolicy.retryVariant(3) == 1, "third retry should use alternate interior point");
        System.out.println("7 action-dispatch policy cases passed");
    }
}
