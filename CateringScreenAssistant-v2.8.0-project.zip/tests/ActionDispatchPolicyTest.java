package com.local.cateringscreenassistant;

public class ActionDispatchPolicyTest {
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        check(ActionDispatchPolicy.semanticObserveDelayMs() == 85L, "semantic observe delay changed");
        check(ActionDispatchPolicy.processingPollMs() == 95L, "processing poll changed");
        check(ActionDispatchPolicy.processingTreeRecheckMs() == 520L, "processing tree recheck window changed");
        check(ActionDispatchPolicy.processingMaxChecks() == 16, "processing window changed");
        check(ActionDispatchPolicy.firstGestureDurationMs(true) == 55L, "Accept first gesture too short");
        check(ActionDispatchPolicy.firstGestureDurationMs(false) == 55L, "Reject compatibility gesture changed");
        check(ActionDispatchPolicy.rejectSemanticSettleMs() == 160L, "Reject semantic settle window");
        check(ActionDispatchPolicy.rejectFallbackGestureDurationMs() == 90L, "Reject fallback gesture must be Samsung-safe");
        check(ActionDispatchPolicy.retryGestureDurationMs(2) == 55L, "second Accept retry duration");
        check(ActionDispatchPolicy.retryGestureDurationMs(3) == 65L, "third Accept retry duration");
        check(ActionDispatchPolicy.retryVariant(2) == 0, "second retry should use center");
        check(ActionDispatchPolicy.retryVariant(3) == 1, "third retry should use alternate interior point");
        System.out.println("12 action-dispatch policy cases passed");
    }
}
