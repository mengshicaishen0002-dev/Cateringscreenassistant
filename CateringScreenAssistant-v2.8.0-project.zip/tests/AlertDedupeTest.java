package com.local.cateringscreenassistant;

public class AlertDedupeTest {
    public static void main(String[] args) {
        AlertDedupe.clearForTests();
        long t = 1000L;
        if (!AlertDedupe.shouldAlert("offer-a", t)) throw new AssertionError("first alert must pass");
        if (AlertDedupe.shouldAlert("offer-a", t + 1000L)) throw new AssertionError("duplicate must be suppressed");
        if (!AlertDedupe.shouldAlert("offer-b", t + 1000L)) throw new AssertionError("different offer must alert");
        if (!AlertDedupe.shouldAlert("offer-a", t + 10 * 60 * 1000L + 1L)) throw new AssertionError("expired offer may alert again");
        System.out.println("Alert de-dupe: 4 checks passed");
    }
}
