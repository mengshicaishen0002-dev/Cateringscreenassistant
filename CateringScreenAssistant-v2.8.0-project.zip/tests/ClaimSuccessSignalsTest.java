package com.local.cateringscreenassistant;
public class ClaimSuccessSignalsTest {
    static int n;
    static void check(boolean v){n++; if(!v) throw new AssertionError("case "+n);}
    public static void main(String[] args){
        check(ClaimSuccessSignals.hasAcceptedJobDetail("Dropoff Instructions: call when arrive Delivery Timeline"));
        check(!ClaimSuccessSignals.hasAcceptedJobDetail("Dropoff Instructions: call when arrive"));
        check(ClaimSuccessSignals.isPositive(ClaimSuccessSignals.extractOutcomeHint("Delivery Timeline Dropoff Instructions")));
        check(ClaimSuccessSignals.jobsBadgeCount("Deliveries Jobs 1 Offers") == 1);
        check(ClaimSuccessSignals.jobsBadgeCount("Deliveries Jobs Offers No offers available") == 0);
        check(ClaimSuccessSignals.jobsBadgeCount("Offers No offers available") == -1);
        check(ClaimSuccessSignals.jobsBadgeIncreased(0,1));
        check(!ClaimSuccessSignals.jobsBadgeIncreased(1,1));
        check(!ClaimSuccessSignals.jobsBadgeIncreased(-1,1));
        System.out.println(n+" claim-success-signal cases passed");
    }
}
