package com.local.cateringscreenassistant;

public final class ActionStallPolicyTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        check(!ActionStallPolicy.stableTop(1, 500), "one frame must not prove a top change");
        check(!ActionStallPolicy.stableTop(2, 20), "two near-simultaneous frames are not stable enough");
        check(ActionStallPolicy.stableTop(2, 80), "two spaced frames should prove a stable top");
        check(!ActionStallPolicy.shouldProbe(false, false, false, 1000, 1000), "no blocker, no probe");
        check(!ActionStallPolicy.shouldProbe(true, true, false, 1000, 1000), "dry run must keep its intentional cooldown");
        check(!ActionStallPolicy.shouldProbe(true, false, true, 1000, 1000), "busy OCR must not overlap rescue OCR");
        check(!ActionStallPolicy.shouldProbe(true, false, false, 100, 1000), "probe cadence must be bounded");
        check(!ActionStallPolicy.shouldProbe(true, false, false, 1000, 100), "do not probe immediately after an action");
        check(ActionStallPolicy.shouldProbe(true, false, false, 400, 500), "stale blocker should permit a rescue probe");
        check(ActionStallPolicy.hardHoldMs() > ActionStallPolicy.softStallMs(), "hard hold must exceed soft stall");
        System.out.println("ActionStallPolicyTest passed");
    }
}
