package com.local.cateringscreenassistant;

public class RejectSequenceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        RejectSequence sequence = new RejectSequence();
        check(sequence.observe("A", 0) == RejectSequence.State.READY);
        check(sequence.sent("A", 0) == 1);
        check(sequence.observe("A", 100) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 1099) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 1100) == RejectSequence.State.READY);
        check(sequence.sent("A", 1100) == 2);
        check(sequence.observe("A", 1101) == RejectSequence.State.HOLD);
        check(sequence.observe("A", 3000) == RejectSequence.State.HOLD);
        check(sequence.markHoldReported("A", 3000));
        check(!sequence.markHoldReported("A", 3001));
        check(sequence.observe("B", 3000) == RejectSequence.State.READY);
        check(sequence.sent("B", 3000) == 1);
        sequence.failed("B", 3050);
        check(sequence.attempts("B", 3050) == 0);
        check(sequence.observe("B", 3200) == RejectSequence.State.WAIT);
        check(sequence.observe("B", 3700) == RejectSequence.State.READY);

        RejectSequence processing = new RejectSequence();
        check(processing.sent("P", 4000) == 1);
        processing.markProcessing("P", 4200);
        check(processing.observe("P", 5000) == RejectSequence.State.PROCESSING);
        check(processing.observe("P", 11199) == RejectSequence.State.PROCESSING);
        check(processing.observe("P", 11200) == RejectSequence.State.READY);
        check(processing.sent("P", 11200) == 2);
        check(processing.observe("P", 11201) == RejectSequence.State.HOLD);

        RejectSequence failedProcessing = new RejectSequence();
        check(failedProcessing.sent("FP", 5000) == 1);
        failedProcessing.markProcessing("FP", 5100);
        failedProcessing.failed("FP", 5200);
        check(failedProcessing.attempts("FP", 5200) == 0);
        check(failedProcessing.observe("FP", 5849) == RejectSequence.State.WAIT);
        check(failedProcessing.observe("FP", 5850) == RejectSequence.State.READY);
        sequence.forget("A");
        check(sequence.observe("A", 3200) == RejectSequence.State.READY);

        RejectSequence shared1 = RejectSequence.shared();
        RejectSequence shared2 = RejectSequence.shared();
        shared1.forget("SHARED");
        check(shared1.sent("SHARED", 5000) == 1);
        check(shared2.observe("SHARED", 5001) == RejectSequence.State.WAIT);
        shared2.forget("SHARED");

        RejectSequence atomic = new RejectSequence();
        check(atomic.reserveIfReady("RACE", 7000) == 1);
        check(atomic.reserveIfReady("RACE", 7000) == 0);
        check(atomic.reserveIfReady("RACE", 8099) == 0);
        check(atomic.reserveIfReady("RACE", 8100) == 2);
        check(atomic.reserveIfReady("RACE", 8101) == 0);
        RejectSequence atomicProcessing = new RejectSequence();
        check(atomicProcessing.reserveIfReady("RP", 9000) == 1);
        atomicProcessing.markProcessing("RP", 9050);
        check(atomicProcessing.reserveIfReady("RP", 10000) == 0);
        System.out.println("37 rejection sequence cases passed");
    }
}
