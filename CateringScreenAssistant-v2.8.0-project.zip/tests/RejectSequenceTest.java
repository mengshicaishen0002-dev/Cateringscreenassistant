package com.local.cateringscreenassistant;

public class RejectSequenceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        RejectSequence sequence = new RejectSequence();
        check(sequence.observe("A", 0) == RejectSequence.State.READY);
        sequence.sent("A", 0);
        check(sequence.observe("A", 100) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 180) == RejectSequence.State.READY);
        sequence.sent("A", 180);
        check(sequence.observe("A", 300) == RejectSequence.State.WAIT);
        sequence.sent("A", 360);
        check(sequence.observe("A", 540) == RejectSequence.State.EXHAUSTED);
        check(sequence.observe("B", 540) == RejectSequence.State.READY);
        sequence.sent("B", 540);
        check(sequence.observe("C", 610) == RejectSequence.State.READY);
        check(sequence.observe("A", 700) == RejectSequence.State.EXHAUSTED);
        System.out.println("9 rejection sequence cases passed");
    }
}
