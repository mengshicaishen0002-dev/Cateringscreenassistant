package com.local.cateringscreenassistant;

public class RejectSequenceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        RejectSequence sequence = new RejectSequence();
        check(sequence.observe("A", 0) == RejectSequence.State.READY);
        sequence.sent("A", 0);
        check(sequence.observe("A", 100) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 899) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 1399) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 1400) == RejectSequence.State.READY);
        sequence.sent("A", 1400);
        check(sequence.observe("A", 2200) == RejectSequence.State.WAIT);
        sequence.sent("A", 2800);
        check(sequence.observe("A", 4200) == RejectSequence.State.HOLD);
        check(sequence.observe("B", 4200) == RejectSequence.State.READY);
        sequence.sent("B", 4200);
        sequence.forget("A");
        check(sequence.observe("A", 4500) == RejectSequence.State.READY);
        System.out.println("11 rejection sequence cases passed");
    }
}
