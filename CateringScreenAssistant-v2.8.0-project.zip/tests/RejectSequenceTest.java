package com.local.cateringscreenassistant;

public class RejectSequenceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        RejectSequence sequence = new RejectSequence();
        check(sequence.observe("A", 0) == RejectSequence.State.READY);
        sequence.sent("A", 0);
        check(sequence.observe("A", 100) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 899) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 900) == RejectSequence.State.READY);
        sequence.sent("A", 900);
        check(sequence.observe("A", 1500) == RejectSequence.State.WAIT);
        sequence.sent("A", 1800);
        check(sequence.observe("A", 2700) == RejectSequence.State.HOLD);
        check(sequence.observe("B", 2700) == RejectSequence.State.READY);
        sequence.sent("B", 2700);
        sequence.forget("A");
        check(sequence.observe("A", 3000) == RejectSequence.State.READY);
        System.out.println("10 rejection sequence cases passed");
    }
}
