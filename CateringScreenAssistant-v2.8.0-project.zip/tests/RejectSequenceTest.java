package com.local.cateringscreenassistant;

public class RejectSequenceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        RejectSequence sequence = new RejectSequence();
        check(sequence.observe("A", 0) == RejectSequence.State.READY);
        check(sequence.sent("A", 0) == 1);
        check(sequence.observe("A", 100) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 1099) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 1100) == RejectSequence.State.READY);
        check(sequence.sent("A", 1100) == 2);
        check(sequence.observe("A", 1101) == RejectSequence.State.HOLD);
        check(sequence.observe("A", 3000) == RejectSequence.State.HOLD);
        check(sequence.markHoldReported("A", 3000));
        check(!sequence.markHoldReported("A", 3001));
        check(sequence.observe("B", 3000) == RejectSequence.State.READY);
        check(sequence.sent("B", 3000) == 1);
        sequence.failed("B", 3050);
        check(sequence.attempts("B", 3050) == 0);
        check(sequence.observe("B", 3200) == RejectSequence.State.WAIT);
        check(sequence.observe("B", 3700) == RejectSequence.State.READY);
        sequence.forget("A");
        check(sequence.observe("A", 3200) == RejectSequence.State.READY);

        RejectSequence shared1 = RejectSequence.shared();
        RejectSequence shared2 = RejectSequence.shared();
        shared1.forget("SHARED");
        check(shared1.sent("SHARED", 5000) == 1);
        check(shared2.observe("SHARED", 5001) == RejectSequence.State.WAIT);
        shared2.forget("SHARED");
        System.out.println("19 rejection sequence cases passed");
    }
}
