package com.local.cateringscreenassistant;

public class RejectSequenceTest {
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        RejectSequence sequence = new RejectSequence();
        check(sequence.observe("A", 0) == RejectSequence.State.READY);
        sequence.sent("A", 0);
        check(sequence.observe("A", 100) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 1099) == RejectSequence.State.WAIT);
        check(sequence.observe("A", 1100) == RejectSequence.State.READY);
        sequence.sent("A", 1100);
        check(sequence.observe("A", 1101) == RejectSequence.State.HOLD);
        check(sequence.observe("A", 3000) == RejectSequence.State.HOLD);
        check(sequence.observe("B", 3000) == RejectSequence.State.READY);
        sequence.sent("B", 3000);
        sequence.forget("A");
        check(sequence.observe("A", 3200) == RejectSequence.State.READY);
        System.out.println("10 rejection sequence cases passed");
    }
}
