package com.local.cateringscreenassistant;
public class AccessibilityFallbackPolicyTest {
    static int n;
    static void check(boolean v){ n++; if(!v) throw new AssertionError("case "+n); }
    public static void main(String[] args){
        check(AccessibilityFallbackPolicy.accessibilityOwnsFrame(true, true));
        check(!AccessibilityFallbackPolicy.accessibilityOwnsFrame(false, true));
        check(!AccessibilityFallbackPolicy.accessibilityOwnsFrame(true, false));
        check(!AccessibilityFallbackPolicy.accessibilityOwnsFrame(false, false));
        check(!AccessibilityFallbackPolicy.shouldRunOcrFallback(true, true));
        check(AccessibilityFallbackPolicy.shouldRunOcrFallback(false, true));
        check(AccessibilityFallbackPolicy.shouldRunOcrFallback(true, false));
        check(AccessibilityFallbackPolicy.shouldRunOcrFallback(false, false));
        System.out.println(n+" accessibility/OCR arbitration cases passed");
    }
}
