package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CardTextTest {
    static CardText.Piece p(String text, float x, float y) {
        return new CardText.Piece(text, x, y, y + 20);
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        List<CardText.Piece> screen = Arrays.asList(
                p("13 mi (~27 mins)", 10, 100), p("Est. $23–33", 300, 100),
                p("Tomorrow at 10:35 AM", 10, 150), p("Urbane Cafe Burbank", 10, 200),
                p("Expires: 09:42", 10, 300), p("Decline", 10, 400), p("Accept", 300, 400),
                p("1 mi (~6 mins)", 10, 500), p("Est. $21.45", 300, 500),
                p("Tomorrow at 10:35 AM Mendocino Farms Los Angeles", 10, 550),
                p("Decline", 10, 800), p("Accept", 300, 800));
        String first = CardText.aboveButton(screen, 400, 420);
        String second = CardText.aboveButton(screen, 800, 820);
        check(first.contains("$23–33") && first.contains("13 mi"), "first fields missing");
        check(!first.contains("21.45") && !first.contains("Mendocino"), "next card leaked into first");
        check(second.contains("$21.45") && second.contains("1 mi"), "second fields missing");
        check(!second.contains("Burbank") && !second.contains("$23"), "previous card leaked into second");
        List<CardText.Piece> incomplete = new ArrayList<>(screen);
        incomplete.removeIf(p -> p.text.contains("21.45"));
        check(CardText.aboveButton(incomplete, 800, 820).isEmpty(), "mixed fields from separate cards");
        List<CardText.Piece> noSecondNumbers = new ArrayList<>(screen);
        noSecondNumbers.removeIf(p -> p.text.contains("21.45") || p.text.contains("1 mi"));
        check(CardText.aboveButton(noSecondNumbers, 800, 820).isEmpty(), "previous card reused when current numbers absent");
        check(CardText.identity(first).equals(CardText.identity(first.replace("09:42", "09:41"))), "countdown invalidates identity");
        check(!CardText.identity(first).equals(CardText.identity(first.replace("10:35 AM", "11:35 AM"))), "pickup time change hidden");
        check(!CardText.identity(first).equals(CardText.identity(first.replace("Burbank", "Pasadena"))), "city change hidden");
        check(CardText.aboveButton(screen, 50, 70).isEmpty(), "missing fields accepted");
        check(!first.toLowerCase().contains("accept") && !first.toLowerCase().contains("decline"), "action row leaked into card text");
        check(CardText.identity(first + " Accept Decline").equals(CardText.identity(first + " Claim Ignore")), "action labels invalidate identity");
        check(CardText.sameOffer(first, first + " Accept button Decline button"), "same offer rejected after action-node change");
        check(CardText.sameOffer(first, first + " " + first), "duplicated accessibility description rejected");
        check(!CardText.sameOffer(first, first.replace("Burbank", "Pasadena").replace("10:35", "11:35")), "different card accepted as same");
        check(!CardText.sameOffer(first, first.replace("$23", "$24")), "changed amount accepted as same offer");
        check(!CardText.sameOffer(first, first.replace("13 mi", "14 mi")), "changed miles accepted as same offer");
        String sparseLive = "Est. $23–33 13 mi Urbane Cafe";
        check(CardText.sameOfferForAction(first, sparseLive), "action revalidation rejected sparse same-card tree");
        check(!CardText.sameOfferForAction(first, sparseLive.replace("$23", "$24")), "action revalidation accepted changed amount");
        check(!CardText.sameOfferForAction(first, sparseLive.replace("13 mi", "14 mi")), "action revalidation accepted changed miles");

        String lazyA = "Est. $36.25 0 2.9 mi (~10 mins) Tomorrow at 11:25 AM Lazy Dog Restaurant and Bar • 598 Town Center Dr, Oxnard, CA 93036, United States";
        String lazyB = "$36.25 Est. 2.9 mi (~10 mins) Tomorrow at 11:25 AM, Lazy Dog Restaurant and Bar • 598 Town Center Dr, Oxnard, CA 93036, United States Tomorrow at 11:25 AM Lazy Dog Restaurant and Bar • 598 Town Center Dr, Oxnard, CA 93036, United States";
        check(CardText.identity(lazyA).equals(CardText.identity(lazyB)), "same real offer drifted across OCR/accessibility variants");
        check(CardText.sameOffer(lazyA, lazyB), "same real offer not matched after duplicate address/order mutation");
        check(!CardText.identity(lazyA).equals(CardText.identity(lazyA.replace("Lazy Dog Restaurant and Bar", "Urbane Cafe"))), "different merchant collapsed into same identity");
        check(!CardText.identity(lazyA).equals(CardText.identity(lazyA.replace("11:25 AM", "11:55 AM"))), "different pickup time collapsed into same identity");
        check(!CardText.sameOfferForAction(lazyA, lazyA.replace("11:25 AM", "11:55 AM")), "action revalidation ignored changed scheduled time");
        System.out.println("25 card-isolation and identity regression cases passed");
    }
}
