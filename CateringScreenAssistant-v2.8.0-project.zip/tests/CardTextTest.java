package com.local.cateringscreenassistant;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CardTextTest {
    static CardText.Piece p(String text, float x, float y) {
        return new CardText.Piece(text, x, y, y + 20);
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        List<CardText.Piece> screen = Arrays.asList(
                p("13 mi (~27 mins)", 10, 100), p("Est. $23–33", 300, 100),
                p("Tomorrow at 10:35 AM", 10, 150), p("Urbane Cafe Burbank", 10, 200),
                p("Expires: 09:42", 10, 300), p("Decline", 10, 400), p("Accept", 300, 400),
                p("1 mi (~6 mins)", 10, 500), p("Est. $21.45", 300, 500),
                p("Tomorrow at 10:35 AM Mendocino Farms Los Angeles", 10, 550),
                p("Decline", 10, 800), p("Accept", 300, 800));
        String first = CardText.aboveButton(screen, 400, 420);
        String second = CardText.aboveButton(screen, 800, 820);
        check(first.contains("$23–33") && first.contains("13 mi"), "first fields missing");
        check(!first.contains("21.45") && !first.contains("Mendocino"), "next card leaked into first");
        check(second.contains("$21.45") && second.contains("1 mi"), "second fields missing");
        check(!second.contains("Burbank") && !second.contains("$23"), "previous card leaked into second");
        List<CardText.Piece> incomplete = new ArrayList<>(screen);
        incomplete.removeIf(p -> p.text.contains("21.45"));
        check(CardText.aboveButton(incomplete, 800, 820).isEmpty(), "mixed fields from separate cards");
        List<CardText.Piece> noSecondNumbers = new ArrayList<>(screen);
        noSecondNumbers.removeIf(p -> p.text.contains("21.45") || p.text.contains("1 mi"));
        check(CardText.aboveButton(noSecondNumbers, 800, 820).isEmpty(), "previous card reused when current numbers absent");
        check(CardText.identity(first).equals(CardText.identity(first.replace("09:42", "09:41"))), "countdown invalidates identity");
        check(!CardText.identity(first).equals(CardText.identity(first.replace("10:35 AM", "11:35 AM"))), "pickup time change hidden");
        check(!CardText.identity(first).equals(CardText.identity(first.replace("Burbank", "Pasadena"))), "city change hidden");
        check(CardText.aboveButton(screen, 50, 70).isEmpty(), "missing fields accepted");
        check(!first.toLowerCase().contains("accept") && !first.toLowerCase().contains("decline"), "action row leaked into card text");
        check(CardText.identity(first + " Accept Decline").equals(CardText.identity(first + " Claim Ignore")), "action labels invalidate identity");
        check(CardText.identity(first).equals(CardText.identity(first + " " + first)), "duplicate tree text changes stable identity");
        String stableMerchantA = "Est. $74.33 1.7 mi Tomorrow at 3:30 PM Mendocino Farms • 11960 Ventura Blvd, Studio City, CA";
        String stableMerchantB = stableMerchantA + " Tomorrow at 3:30 PM Mendocino Farms • 11960 Ventura Blvd, Studio City, CA";
        check(CardText.identity(stableMerchantA).equals(CardText.identity(stableMerchantB)), "duplicated merchant/address changes identity");
        check(CardText.sameOffer(first, first + " Accept button Decline button"), "same offer rejected after action-node change");
        check(CardText.sameOffer(first, first + " " + first), "duplicated accessibility description rejected");
        check(!CardText.sameOffer(first, first.replace("Burbank", "Pasadena").replace("10:35", "11:35")), "different card accepted as same");
        check(!CardText.sameOffer(first, first.replace("$23", "$24")), "changed amount accepted as same offer");
        check(!CardText.sameOffer(first, first.replace("13 mi", "14 mi")), "changed miles accepted as same offer");
        String sparseLive = "Est. $23–33 13 mi Urbane Cafe";
        check(CardText.sameOfferForAction(first, sparseLive), "action revalidation rejected sparse same-card tree");
        check(!CardText.sameOfferForAction(first, sparseLive.replace("$23", "$24")), "action revalidation accepted changed amount");
        check(!CardText.sameOfferForAction(first, sparseLive.replace("13 mi", "14 mi")), "action revalidation accepted changed miles");

        List<CardText.Piece> duplicatedParent = Arrays.asList(
                p("Est. $30–40 14.1 mi September 11 at 10:35 AM Porto's Bakery 6100 S Malt Ave, Commerce, CA 90040, United States", 10, 100),
                p("September 11 at 10:35 AM", 10, 150),
                p("Porto's Bakery", 10, 180),
                p("6100 S Malt Ave, Commerce, CA 90040, United States", 10, 210),
                p("Reject", 10, 300), p("Accept", 300, 300));
        String deduped = CardText.aboveButton(duplicatedParent, 300, 320);
        check(deduped.indexOf("Porto's Bakery") == deduped.lastIndexOf("Porto's Bakery"),
                "parent/child accessibility text duplicated merchant");
        check(deduped.indexOf("6100 S Malt Ave") == deduped.lastIndexOf("6100 S Malt Ave"),
                "parent/child accessibility text duplicated address");

        // v2.10.21 real-device regression: the same Mendocino Grand Ave card was read
        // once as OCR (distance first / "300S") and once as Accessibility (pay first /
        // "300 S"). Old identity lacked calendar-date pickup parsing, so the two sources
        // generated different reject budgets and both tapped the same physical card.
        String grandOcr = "4.3 mi (~12 mins) Est. $29-39 O September 11 at 10:45 AM "
                + "Mendocino Farms • 300S Grand Ave, Los Angeles, CA 90071, United States Expires: 09:59";
        String grandAx = "$29-39 Est. 4.3 mi (~12 mins) September 11 at 10:45 AM, "
                + "Mendocino Farms • 300 S Grand Ave, Los Angeles, CA 90071, United States Expires: 09:59";
        check(CardText.identity(grandOcr).equals(CardText.identity(grandAx)),
                "calendar-date OCR/accessibility variants split one physical offer identity");
        check(!CardText.identity(grandAx).equals(CardText.identity(grandAx.replace("10:45 AM", "11:05 AM"))),
                "calendar-date pickup-time change hidden");
        check(!CardText.identity(grandAx).equals(CardText.identity(grandAx.replace("Mendocino Farms", "Porto's Bakery"))),
                "calendar-date merchant change hidden");
        check(Math.abs(CardText.amount("$70.00 22.5 mi") - 70f) < 0.001f, "decision amount parse");
        check(Math.abs(CardText.amount("$40-$65 3.2 mi") - 40f) < 0.001f, "range low-end amount parse");
        check(Math.abs(CardText.miles("$40 22.5 mi") - 22.5f) < 0.001f, "decision miles parse");
        check(CardText.amount("no money") < 0f && CardText.miles("no miles") < 0f, "missing decision fields");
        System.out.println("31 card-isolation and identity regression cases passed");
    }
}
