package com.local.cateringscreenassistant;
public class ScanPolicyTest {
    static int count;
    static void check(boolean x) { count++; if (!x) throw new AssertionError("case " + count); }
    public static void main(String[] args) {
        check(ScanPolicy.needsOcr(10000, 9000, 0, 250, false));
        check(!ScanPolicy.needsOcr(10000, 9950, 0, 250, false));
        check(!ScanPolicy.needsOcr(10000, 9000, 9800, 250, false));
        check(ScanPolicy.needsOcr(10000, 9000, 9500, 250, false));
        check(!ScanPolicy.needsOcr(10000, 9000, 0, 250, true));
        check(ScanPolicy.fresh(11000, 10000));
        check(!ScanPolicy.fresh(11001, 10000));
        check(!ScanPolicy.fresh(10000, 11000));
        check(!ScanPolicy.fresh(900000, 10000));
        System.out.println(count + " scan timing regression cases passed");
    }
}
