package com.local.cateringscreenassistant;
import java.util.regex.Pattern;
public class NumericGuardTest {
    static void check(boolean v, String m) { if (!v) throw new AssertionError(m); }
    public static void main(String[] args) {
        Pattern money = Pattern.compile("\\$(\\d{1,4}(?:[.,]\\d{1,2})?)");
        Pattern miles = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*mi\\b", Pattern.CASE_INSENSITIVE);
        check(NumericGuard.containsExpected("Est. $70-$80 3 mi", money, 70f, .011f), "range low blocked");
        check(NumericGuard.containsExpected("Est. $23-$33 13 mi", money, 23f, .011f), "second range endpoint invalidated low");
        check(NumericGuard.containsExpected("Est. $70-$80 3 mi", money, 80f, .011f), "range high not found");
        check(!NumericGuard.containsExpected("Est. $70-$80 3 mi", money, 75f, .011f), "nonexistent money matched");
        check(NumericGuard.containsExpected("3 mi (~8 mins)", miles, 3f, .051f), "miles not found");
        check(NumericGuard.containsExpected("1 mi route; delivery 3 mi", miles, 3f, .051f), "later matching miles blocked by earlier value");
        System.out.println("6 numeric live-guard regression cases passed");
    }
}
