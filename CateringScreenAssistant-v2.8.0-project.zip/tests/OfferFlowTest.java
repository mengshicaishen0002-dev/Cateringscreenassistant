package com.local.cateringscreenassistant;
import java.util.*;
public class OfferFlowTest {
    static int cases;
    static void check(boolean condition) { cases++; if (!condition) throw new AssertionError("case " + cases); }
    static class Offer {
        String id; boolean qualified, accept, reject;
        Offer(String id, boolean qualified, boolean accept, boolean reject) {
            this.id=id; this.qualified=qualified; this.accept=accept; this.reject=reject;
        }
    }
    static Offer choose(List<Offer> offers, ClaimBudget budget) {
        return OfferPriority.choose(offers, o->o.qualified, o->o.accept && budget.available(o.id), o->o.reject);
    }
    public static void main(String[] args) throws Exception {
        ClaimBudget budget = new ClaimBudget();
        Offer low=new Offer("low",false,true,true), high=new Offer("high",true,true,true);
        // v2.10.3: strict serial queue — always finish the first visible card before lower cards.
        check(choose(Arrays.asList(low,high),budget)==low);
        check(choose(Arrays.asList(high,low),budget)==high);
        check(choose(Arrays.asList(low),budget)==low);
        check(choose(Collections.emptyList(),budget)==null);
        check(budget.reserve("high")==1);
        check(budget.reserve("high")==2);
        check(budget.reserve("high")==3);
        check(budget.reserve("high")==0);
        check(choose(Arrays.asList(high,low),budget)==null);
        Offer newOrder=new Offer("samePayDifferentMerchant",true,true,true);
        check(choose(Arrays.asList(high,newOrder),budget)==null);
        check(choose(Arrays.asList(high),budget)==null);
        check(choose(Arrays.asList(new Offer("partial",true,false,false),low),budget)==null);
        check(choose(Arrays.asList(newOrder),budget)==newOrder);
        String base="$80 3 mi Tomorrow at 11:00 AM Store A, Pasadena CA 91101 Expires: 09:42 Accept Decline";
        check(CardText.identity(base).equals(CardText.identity(base.replace("09:42","09:41"))));
        check(!CardText.identity(base).equals(CardText.identity(base.replace("Store A","Store B"))));
        check(!CardText.identity(base).equals(CardText.identity(base.replace("11:00","11:30"))));
        List<CardText.Piece> pieces=Arrays.asList(
            new CardText.Piece("Est. $23–33",400,100,120),new CardText.Piece("13 mi",20,100,120),
            new CardText.Piece("Tomorrow at 10:35 AM Urbane Cafe Burbank CA",20,130,170),
            new CardText.Piece("Decline Accept",20,200,230),
            new CardText.Piece("Est. $90",400,300,320),new CardText.Piece("2 mi",20,300,320),
            new CardText.Piece("Tomorrow at 11:35 AM Store B Pasadena CA",20,330,370),
            new CardText.Piece("Decline Accept",20,400,430));
        String upper=CardText.aboveButton(pieces,200,230),lower=CardText.aboveButton(pieces,400,430);
        check(upper.contains("$23") && !upper.contains("$90"));
        check(lower.contains("$90") && !lower.contains("Burbank"));
        ClaimBudget concurrent=new ClaimBudget();
        List<Thread> threads=new ArrayList<>(); java.util.concurrent.atomic.AtomicInteger reserved=new java.util.concurrent.atomic.AtomicInteger();
        for(int i=0;i<12;i++) {Thread t=new Thread(()->{if(concurrent.reserve("one")>0)reserved.incrementAndGet();});threads.add(t);t.start();}
        for(Thread t:threads)t.join();
        check(reserved.get()==3);
        // Expired attempt budget becomes usable again for a genuinely resurfaced offer.
        ClaimBudget expiring = new ClaimBudget();
        check(expiring.reserve("again", 1000)==1);
        check(expiring.reserve("again", 1100)==2);
        check(expiring.reserve("again", 1200)==3);
        check(!expiring.available("again", 1300));
        check(expiring.available("again", 9500));
        check(expiring.reserve("again", 9500)==1);
        System.out.println(cases+" multi-offer/claim-budget regression cases passed");
    }
}
