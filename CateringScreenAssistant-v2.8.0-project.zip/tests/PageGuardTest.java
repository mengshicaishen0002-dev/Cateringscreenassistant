package com.local.cateringscreenassistant;

public class PageGuardTest {
    public static void main(String[] args) {
        for (int bits = 0; bits < 32; bits++) {
            boolean ignored = (bits & 1) != 0, jobs = (bits & 2) != 0, offers = (bits & 4) != 0;
            boolean restore = (bits & 8) != 0, reject = (bits & 16) != 0;
            PageGuard.Page page = PageGuard.classify(ignored, jobs, offers, restore, reject);
            if ((ignored || restore || jobs) && page == PageGuard.Page.OFFERS)
                throw new AssertionError("Non-offer page permitted: " + bits);
            if (!ignored && !restore && !jobs && (offers || reject) && page != PageGuard.Page.OFFERS)
                throw new AssertionError("Active offer blocked: " + bits);
            if (bits == 0 && page != PageGuard.Page.UNKNOWN) throw new AssertionError();
        }
        System.out.println("32 page guard combinations passed");
    }
}
