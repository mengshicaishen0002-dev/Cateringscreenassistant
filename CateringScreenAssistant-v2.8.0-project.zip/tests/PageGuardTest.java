package com.local.cateringscreenassistant;

public class PageGuardTest {
    public static void main(String[] args) {
        int cases = 0;
        for (int bits = 0; bits < 128; bits++) {
            boolean ignored = (bits & 1) != 0;
            boolean jobs = (bits & 2) != 0;
            boolean offers = (bits & 4) != 0;
            boolean restore = (bits & 8) != 0;
            boolean reject = (bits & 16) != 0;
            boolean accept = (bits & 32) != 0;
            boolean emptyOffers = (bits & 64) != 0;
            PageGuard.Page page = PageGuard.classify(
                    ignored, jobs, offers, restore, reject, accept, emptyOffers);
            cases++;
            if ((ignored || restore || jobs) && page == PageGuard.Page.OFFERS)
                throw new AssertionError("Non-offer page permitted: " + bits);
            if (!ignored && !restore && !jobs && (offers || reject || accept || emptyOffers)
                    && page != PageGuard.Page.OFFERS)
                throw new AssertionError("Offers evidence blocked: " + bits);
            if (bits == 0 && page != PageGuard.Page.UNKNOWN) throw new AssertionError();
        }
        System.out.println(cases + " page guard combinations passed");
    }
}
