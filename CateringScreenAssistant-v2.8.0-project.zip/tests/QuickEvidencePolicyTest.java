package com.local.cateringscreenassistant;
public class QuickEvidencePolicyTest {
    static int n;
    static void check(boolean v) { n++; if (!v) throw new AssertionError("case " + n); }
    public static void main(String[] args) {
        check(QuickEvidencePolicy.canStop(true, true, true, true));
        check(!QuickEvidencePolicy.canStop(false, true, true, true));
        check(!QuickEvidencePolicy.canStop(true, false, true, true));
        check(!QuickEvidencePolicy.canStop(true, true, false, true));
        check(!QuickEvidencePolicy.canStop(true, true, true, false));
        System.out.println(n + " quick-evidence stop cases passed");
    }
}
