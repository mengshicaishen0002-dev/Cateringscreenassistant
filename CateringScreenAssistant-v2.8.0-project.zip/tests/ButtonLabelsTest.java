package com.local.cateringscreenassistant;

public class ButtonLabelsTest {
    public static void main(String[] args) {
        int cases = 0;
        for (String label : new String[]{"Ignore", "Decline", "Reject", " DECLINE ",
                "Decline button", "button ignore", "reject_button", "Decline offer",
                "Ignore delivery", "Reject job"}) {
            cases++;
            if (!ButtonLabels.isReject(label)) throw new AssertionError("Missed reject: " + label);
        }
        for (String label : new String[]{null, "", "Accept", "Accept button", "Restore", "Ignore Accept",
                "Decline Accept", "Declined", "Do not decline", "Tomorrow Decline", "Rejected"}) {
            cases++;
            if (ButtonLabels.isReject(label)) throw new AssertionError("Unsafe match: " + label);
        }
        System.out.println(cases + " button-label regression cases passed");
    }
}
