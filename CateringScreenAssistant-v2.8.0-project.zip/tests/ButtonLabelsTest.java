package com.local.cateringscreenassistant;

public class ButtonLabelsTest {
    public static void main(String[] args) {
        for (String label : new String[]{"Ignore", "Decline", "Reject", " DECLINE ",
                "Decline button", "button ignore", "reject_button"}) {
            if (!ButtonLabels.isReject(label)) throw new AssertionError("Missed reject: " + label);
        }
        for (String label : new String[]{null, "", "Accept", "Accept button", "Restore", "Ignore Accept",
                "Decline Accept", "Declined", "Do not decline", "Tomorrow Decline"}) {
            if (ButtonLabels.isReject(label)) throw new AssertionError("Unsafe match: " + label);
        }
        System.out.println("17 button-label regression cases passed");
    }
}
