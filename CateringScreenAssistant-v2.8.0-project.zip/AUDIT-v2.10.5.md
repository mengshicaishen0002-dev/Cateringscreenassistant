# v2.10.5 audit

Goal: fix the real-device failure where a high-value offer disappears after repeated Accept gestures but the app cannot tell whether this was a successful claim or the offer being taken/withdrawn.

Changes:
- First Accept now uses a strict fresh top-card snapshot and skips a second full accessibility-tree walk before the first gesture.
- First-tap snapshot freshness is capped at 380–420 ms and still checks DeliverThat foreground, window bounds, and a bounded Jobs/Ignored page guard.
- Retry taps keep the slower full card/number revalidation path.
- Post-Accept state no longer treats `card disappeared` as success.
- Success requires positive evidence: Jobs page or explicit accepted/assigned UI text.
- If the card disappears without positive evidence, log `unknown / possibly taken or withdrawn` and immediately continue scanning.
- Top-card OCR crop reduced to 17%–64% of screen height so lower cards are not OCR'd before moving to the first position.
- OCR Accept path now shares the same post-claim confirmation logic.
