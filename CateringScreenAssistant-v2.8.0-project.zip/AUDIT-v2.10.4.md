# v2.10.4 real-device action fix

Based on the 2026-09-09 DeliverThat real-device video where the first offer remained unchanged and no visible Ignore press occurred.

Changes:
- Gesture-first action execution for DeliverThat. Do not trust virtual Accessibility ACTION_CLICK=true as proof of a real button press.
- Prefer larger structural/clickable button-container bounds over text-label bounds.
- Allow UNKNOWN tab classification only when exact top-card identity + amount + miles were revalidated; Jobs/Ignored still block actions.
- Strict serial top-card lock: no 1.5s timeout unlock while a Decline/Ignore countdown or transition makes the top card temporarily unreadable.
- After three failed reject attempts, HOLD the first card instead of skipping to lower cards.
- Forget reject hold only after a different top offer is positively observed.
- Gesture duration increased to 45 ms for a more reliable Android touch dispatch.

Version: 2.10.4 (30)
