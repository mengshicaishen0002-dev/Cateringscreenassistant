# v2.10.3 audit

This release changes offer handling to a strict **serial top-card queue**, based on the real Galaxy A15 DeliverThat screenshots supplied by the user.

- Only the first visible offer card may be acted on.
- After Accept/Ignore, the current top card stays locked until it actually disappears or the visible top identity changes.
- A second/lower card is never acted on while the first card is in an Ignore countdown, disabled-button transition, or post-click animation.
- Once the first card disappears, the next card moves into the first-card position and the scanner rebuilds all action coordinates from scratch.
- Accessibility can identify the top offer text even when Ignore temporarily changes label/disabled state, so countdown states do not cause the lower card to steal the first card's button row.
- Reject retry spacing increased from 180 ms to 900 ms to avoid fighting DeliverThat's countdown/transition state.
- Qualified-order alert is emitted for the current top card; later cards alert when they move to the top.
- Existing OCR/visual/action geometry fallbacks remain available for the top card only.
