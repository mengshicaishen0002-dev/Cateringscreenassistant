# 2.4.2 — stacked offer cards

The 2.4.1 live numeric check covered the entire visible screen, so a second offer with different numbers could prevent clicking the first. Fast snapshots and live validation now extract text from the target button's card using the nearest preceding aligned money/miles row. OCR uses the same extraction rather than a fixed 30%-screen-height band. Missing or unaligned rows stop the action.

Button dispatch must match the requested action at the expected position. A changed layout stops the action rather than redirecting it to another card's first button. Fast-path identity and retry comparison ignore only the labelled Expires countdown, retaining pickup time, pay, distance and other card content.

Rejection cooldown is reduced from 15 seconds to 1 second so subsequent visible cards are not blocked for 15 seconds after sending a rejection. The separate one-second ineligible-offer observation period remains.

Validation: 17 rejection-label cases and 9 card extraction/identity cases. Tests use constructed geometry and text based on the user's screenshot; they are not a live OCR or Samsung accessibility replay. Android release compilation, signature and alignment are checked separately.

Limits: visible vertically stacked cards only; no automatic scrolling to hidden offers. Live accessibility labels and aligned pay/miles rows must be available. Click feedback is not server acknowledgement; real acceptance still needs Jobs confirmation. No on-device latency or successful real order claim has been verified.
