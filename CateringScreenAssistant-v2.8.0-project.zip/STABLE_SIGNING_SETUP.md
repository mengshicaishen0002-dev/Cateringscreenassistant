# Stable signing hook (v1.2.0)

The app build supports a stable keystore through environment variables:

- DD_KEYSTORE_PATH
- DD_KEYSTORE_PASSWORD
- DD_KEY_ALIAS
- DD_KEY_PASSWORD

Do not commit a keystore or passwords to a public repository.

The current public-repo workflow may continue to produce a fresh debug signature until GitHub Actions Secrets are configured and the root workflow decodes the keystore into the runner and exports the variables above. Switching from the current random debug signature to a stable signature requires one final uninstall/reinstall; builds signed by the same stable key can then upgrade in place.
