# CateringScreenAssistant v2.10.25

Field-driven correction after the September 10 noon traces.

## Root cause found
The APK previously handed to the user as `v2.10.24` was byte-for-byte identical to the prior `v2.10.23` APK. The short-name upload workaround (`CSA_v21024_GitHub.zip`) did not replace the workflow's hard-coded source file `CateringScreenAssistant-v2.8.0-project.zip`, so GitHub Actions rebuilt the old project. The field screenshots therefore did not actually exercise the intended v2.10.24 Reject state-machine fix.

## v2.10.25 hardening
- Carries forward the intended v2.10.24 Accept/Reject post-action split.
- Adds a single `handlePendingSerialFast()` gate that runs before cooldown/index/page work.
- Pending Reject now owns the fast lane just like pending Accept; normal discovery cannot fall through into an Accept confirmation path.
- Rechecks the serial transaction after the Accept-index lookup and after the bounded quick-tree lookup, closing the race where OCR dispatches an action while an older Accessibility runnable is already executing.
- `offer unavailable` is resolved by transaction type:
  - Accept -> terminal loss (`ACCEPT_LOST`), no further Accept retry.
  - Reject + processing acknowledgement -> `REJECT_SUCCESS`.
  - Reject without acknowledgement -> `REJECT_UNKNOWN`.
- Accept terminal loss is preserved until the dead top card leaves, then closed as `ACCEPT_LOST` instead of generic Jobs/claim-success unknown.
- If the top card changes after a terminal Accept loss, the old transaction is logged as `ACCEPT_LOST`, not `ACTION_STALL_RECOVERY`.
- UI version banner updated to v2.10.25 so the installed build can be visually identified.

## Performance notes from the user's traces
- Reject decision/action path was already around 80-155 ms in several samples.
- The $121.97 / 1.3 mi Accept was dispatched from OCR in ~179 ms, but DeliverThat returned `offer unavailable`; that is a server-side lost-race result, not a rule-parser failure.
- v2.10.25 avoids post-dispatch duplicate tree work and stale retry preparation, but does not weaken the 55 ms gesture duration that has been reliable on the Galaxy A15.

## Build/upload rule
The GitHub workflow is hard-coded to extract `CateringScreenAssistant-v2.8.0-project.zip`. The replacement file must use that exact name in the repository; adding a differently named ZIP will build the old project.
