# v2.9.1 targeted hotfix

Observed on-device: OCR reads offer card money/miles, but both Accept and Decline labels can be absent from ML Kit results.

Changes:
- Added conservative filled-blue Accept visual locator from the raw MediaProjection frame.
- Uses the visual rectangle only when OCR did not locate Accept text.
- Existing foreground/page/freshness/rule guards still run before any gesture.
- Expanded one-edit OCR tolerance to Decline/Reject/Ignore labels.
- No inferred reject-coordinate click: if reject is not reliably located, the app still refuses to guess.

Important: an $82.70 / 11.9 mi offer does not satisfy a <=10.0 mi rule, so it must not be accepted.
