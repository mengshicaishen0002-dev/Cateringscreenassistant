# v2.10.7 audit

Real-device log motivating this release:
- First-card ROI copy: 17 ms
- OCR: 71 ms
- total: 88 ms
- ineligible $26.33 / 18.2 mi correctly classified
- Reject was cancelled by `目标卡片稳定内容已变化`

Fixes:
1. Fast first-card Reject mirrors fast Accept and uses the fresh reject rectangle directly.
2. Retry revalidation uses `sameOfferForAction`: exact money + exact miles remain mandatory, descriptive node overlap is tolerant of React-Native duplication/omission.
3. Full verified gesture duration reduced 45 ms -> 18 ms.
4. Strict first-card serial lock, Jobs/Ignored guards, dry-run behavior and qualification rules remain unchanged.

No claim of real-device runtime success is made; static/local regression tests only.
