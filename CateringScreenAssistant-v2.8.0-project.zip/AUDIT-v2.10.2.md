# Catering Screen Assistant v2.10.2 audit

## Qualified-offer alert

- Adds an independent alert path for every offer that passes all active amount, mileage, city and time rules.
- Alert fires before Accept localization/clicking, so the driver is warned even when automated clicking later fails.
- High-importance Android notification includes amount, miles and $/mi, plus sound and a multi-pulse vibration pattern.
- Accessibility and OCR paths share a process-wide de-dupe: the same normalized offer alerts once per 10 minutes, while different offers alert immediately.
- User-facing toggle `qualifiedAlertEnabled` defaults to true.
- Adds VIBRATE permission.
- Version: 2.10.2 / code 28; stable signing key unchanged.

- Adds a one-tap test button in the settings screen so sound/vibration/heads-up behavior can be verified before waiting for a real offer.
- Pure-Java regression suite: 233 checks passed.
