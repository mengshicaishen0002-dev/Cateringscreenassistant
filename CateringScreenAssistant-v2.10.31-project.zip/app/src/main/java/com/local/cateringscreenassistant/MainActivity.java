package com.local.cateringscreenassistant;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CAPTURE = 7001;
    private SharedPreferences prefs;
    private EditText minPay;
    private EditText maxMiles;
    private EditText pasadenaMinPay;
    private EditText pasadenaMaxMiles;
    private EditText cities;
    private EditText startTime;
    private EditText endTime;
    private EditText interval;
    private CheckBox requireCity;
    private CheckBox dryRun;
    private CheckBox autoIgnore;
    private CheckBox pasadenaRuleEnabled;
    private CheckBox qualifiedAlertEnabled;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("rules", MODE_PRIVATE);
        if (!prefs.getBoolean("finalModeInitialized", false)) {
            prefs.edit()
                    .putBoolean("dryRun", false)
                    .putBoolean("finalModeInitialized", true)
                    .apply();
        }
        setContentView(buildUi());
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3);
        }
    }

    private View buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView intro = new TextView(this);
        intro.setText("v2.10.31：强化Reject确认与定位：原卡离开且下一张顶上可直接多证据确认成功，减少无意义第2次Reject；Reject定位优先Accessibility配对几何，再走OCR镜像兜底；规则失败日志直接显示具体阈值差；处理记录默认每张卡只显示最终结果，完整原始记录仍可查看。扫描阈值和Accept主链不变。");
        intro.setTextSize(16);
        root.addView(intro, row());

        String savedStatus = prefs.getString("lastStatus", "暂无识别记录");
        long savedStatusAt = prefs.getLong("lastStatusAt", 0L);
        TextView lastStatus = new TextView(this);
        lastStatus.setText(savedStatusAt > 0
                ? "最近识别记录（停止监控后仍保留）：\n"
                    + DateFormat.getDateTimeInstance().format(new Date(savedStatusAt))
                    + "\n" + savedStatus
                : "最近识别记录：暂无");
        lastStatus.setTextSize(15);
        root.addView(lastStatus, row());

        Button events = new Button(this);
        events.setText("查看最终处理记录（每张卡一条）");
        events.setOnClickListener(v -> showDecisionEvents(true));
        root.addView(events, row());

        Button rawEvents = new Button(this);
        rawEvents.setText("查看完整调试记录（最近100条）");
        rawEvents.setOnClickListener(v -> showDecisionEvents(false));
        root.addView(rawEvents, row());

        TextView ignoredTitle = new TextView(this);
        ignoredTitle.setText("旧式筛选历史（不对应当前报错；排查请用上方处理记录）：");
        ignoredTitle.setTextSize(16);
        root.addView(ignoredTitle, row());
        TextView ignoredHistory = new TextView(this);
        ignoredHistory.setText(prefs.getString("ignoredHistory", "暂无记录"));
        ignoredHistory.setTextSize(14);
        ignoredHistory.setTextIsSelectable(true);
        root.addView(ignoredHistory, row());

        Button clearHistory = new Button(this);
        clearHistory.setText("清空未通过订单记录");
        clearHistory.setOnClickListener(v -> {
            prefs.edit().remove("ignoredHistory").apply();
            ignoredHistory.setText("暂无记录");
        });
        root.addView(clearHistory, row());

        minPay = field("最低预估金额低值，例如 25", String.valueOf(prefs.getFloat("minPay", 25f)), true);
        root.addView(minPay, row());
        maxMiles = field("最高里程，例如 12", String.valueOf(prefs.getFloat("maxMiles", 12f)), true);
        root.addView(maxMiles, row());
        TextView pasadenaTitle = new TextView(this);
        pasadenaTitle.setText("Pasadena 专属规则（命中 Pasadena 时优先于普通规则）");
        pasadenaTitle.setTextSize(16);
        root.addView(pasadenaTitle, row());
        pasadenaRuleEnabled = new CheckBox(this);
        pasadenaRuleEnabled.setText("启用 Pasadena 专属规则");
        pasadenaRuleEnabled.setChecked(prefs.getBoolean("pasadenaRuleEnabled", false));
        root.addView(pasadenaRuleEnabled, row());
        pasadenaMinPay = field("Pasadena 最低预估金额", String.valueOf(prefs.getFloat("pasadenaMinPay", 25f)), true);
        root.addView(pasadenaMinPay, row());
        pasadenaMaxMiles = field("Pasadena 最高里程", String.valueOf(prefs.getFloat("pasadenaMaxMiles", 12f)), true);
        root.addView(pasadenaMaxMiles, row());
        cities = field("允许城市（留空=不限制）", prefs.getString("cities", ""), false);
        root.addView(cities, row());
        startTime = field("开始时间（留空=不限制）", prefs.getString("startTime", ""), false);
        root.addView(startTime, row());
        endTime = field("结束时间（留空=不限制）", prefs.getString("endTime", ""), false);
        root.addView(endTime, row());
        interval = field("扫描间隔毫秒（Galaxy A15高速建议 70–100）", String.valueOf(prefs.getInt("interval", 80)), true);
        root.addView(interval, row());
        requireCity = new CheckBox(this);
        requireCity.setText("必须识别到允许城市才点击（建议开启）");
        requireCity.setChecked(prefs.getBoolean("requireCity", false));
        root.addView(requireCity, row());
        qualifiedAlertEnabled = new CheckBox(this);
        qualifiedAlertEnabled.setText("符合条件订单提醒：高优先级通知 + 声音 + 震动（建议开启）");
        qualifiedAlertEnabled.setChecked(prefs.getBoolean("qualifiedAlertEnabled", true));
        root.addView(qualifiedAlertEnabled, row());

        Button testAlert = new Button(this);
        testAlert.setText("测试符合条件订单提醒");
        testAlert.setOnClickListener(v -> {
            prefs.edit().putBoolean("qualifiedAlertEnabled", qualifiedAlertEnabled.isChecked()).apply();
            QualifiedOfferAlert.sendTest(this, prefs);
            Toast.makeText(this, "已发送测试提醒；应出现通知、声音和震动", Toast.LENGTH_LONG).show();
        });
        root.addView(testAlert, row());

        dryRun = new CheckBox(this);
        dryRun.setText("测试模式：只识别和响铃，不点击（正式接单请勿勾选）");
        dryRun.setChecked(prefs.getBoolean("dryRun", false));
        root.addView(dryRun, row());

        autoIgnore = new CheckBox(this);
        autoIgnore.setText("不符合条件时，可靠识别到Ignore/Decline/Reject后立即点击");
        autoIgnore.setChecked(prefs.getBoolean("autoIgnore", true));
        root.addView(autoIgnore, row());

        Button accessibility = new Button(this);
        accessibility.setText("1. 开启辅助功能点击服务");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility, row());

        Button start = new Button(this);
        start.setText("2. 保存规则并开始监控");
        start.setOnClickListener(v -> saveAndRequestCapture());
        root.addView(start, row());

        Button stop = new Button(this);
        stop.setText("停止监控");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OcrMonitorService.class));
            Toast.makeText(this, "监控已停止", Toast.LENGTH_SHORT).show();
        });
        root.addView(stop, row());

        TextView warning = new TextView(this);
        warning.setText("限制：仅在DeliverThat前台Offers页点击；每次动作前重新核对当前卡片金额/里程/按钮。OCR无法可靠核对时不点击。自动化可能受平台规则限制。");
        root.addView(warning, row());

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        return scroll;
    }

    private EditText field(String hint, String value, boolean numeric) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private void saveAndRequestCapture() {
        try {
            float pay = Float.parseFloat(minPay.getText().toString().trim());
            float miles = Float.parseFloat(maxMiles.getText().toString().trim());
            float pasadenaPay = Float.parseFloat(pasadenaMinPay.getText().toString().trim());
            float pasadenaMiles = Float.parseFloat(pasadenaMaxMiles.getText().toString().trim());
            if (!Float.isFinite(pay) || !Float.isFinite(miles) || !Float.isFinite(pasadenaPay)
                    || !Float.isFinite(pasadenaMiles) || pay < 0 || miles < 0 || pasadenaPay < 0 || pasadenaMiles < 0) {
                throw new NumberFormatException();
            }
            int scan = Integer.parseInt(interval.getText().toString().trim());
            scan = Math.max(60, Math.min(scan, 2000));
            prefs.edit()
                    .putFloat("minPay", pay)
                    .putFloat("maxMiles", miles)
                    .putBoolean("pasadenaRuleEnabled", pasadenaRuleEnabled.isChecked())
                    .putFloat("pasadenaMinPay", pasadenaPay)
                    .putFloat("pasadenaMaxMiles", pasadenaMiles)
                    .putString("cities", cities.getText().toString().trim())
                    .putString("startTime", startTime.getText().toString().trim())
                    .putString("endTime", endTime.getText().toString().trim())
                    .putInt("interval", scan)
                    .putBoolean("requireCity", requireCity.isChecked())
                    .putBoolean("qualifiedAlertEnabled", qualifiedAlertEnabled.isChecked())
                    .putBoolean("dryRun", dryRun.isChecked())
                    .putBoolean("autoIgnore", autoIgnore.isChecked())
                    .apply();
        } catch (NumberFormatException ex) {
            Toast.makeText(this, "金额或扫描间隔格式不正确", Toast.LENGTH_LONG).show();
            return;
        }
        if (!TapAccessibilityService.isConnected()) {
            Toast.makeText(this, "请先开启辅助功能点击服务", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE || resultCode != Activity.RESULT_OK || data == null) return;
        Intent service = new Intent(this, OcrMonitorService.class);
        service.putExtra("resultCode", resultCode);
        service.putExtra("resultData", data);
        startForegroundService(service);
        Toast.makeText(this, "监控已启动；现在打开DeliverThat订单页", Toast.LENGTH_LONG).show();
    }

    private void showDecisionEvents(boolean compact) {
        StringBuilder text = new StringBuilder();
        try {
            org.json.JSONArray records = new org.json.JSONArray(prefs.getString("decisionEvents", "[]"));
            if (!compact) {
                for (int i = 0; i < records.length(); i++)
                    text.append(records.getString(i)).append("\n\n────────\n\n");
            } else {
                java.util.LinkedHashMap<String, String> chosen = new java.util.LinkedHashMap<>();
                java.util.HashSet<String> terminal = new java.util.HashSet<>();
                for (int i = 0; i < records.length(); i++) {
                    String event = records.getString(i);
                    int marker = event.indexOf("｜卡片#");
                    int end = marker < 0 ? -1 : event.indexOf('\n', marker);
                    String key = marker < 0 ? "event-" + i
                            : event.substring(marker + 1, end < 0 ? event.length() : end);
                    boolean isTerminal = event.contains("REJECT_SUCCESS")
                            || event.contains("REJECT_UNKNOWN")
                            || event.contains("REJECT_NOT_CONFIRMED")
                            || event.contains("ACCEPT_SUCCESS")
                            || event.contains("ACCEPT_LOST");
                    if (!chosen.containsKey(key)) chosen.put(key, event);
                    if (isTerminal && !terminal.contains(key)) {
                        chosen.put(key, event);
                        terminal.add(key);
                    }
                }
                for (String event : chosen.values())
                    text.append(event).append("\n\n────────\n\n");
            }
        } catch (org.json.JSONException ignored) { }
        TextView view = new TextView(this);
        view.setPadding(dp(16),dp(16),dp(16),dp(16));
        view.setTextIsSelectable(true);
        view.setText(text.length() == 0 ? "暂无新版本处理记录" : text.toString());
        ScrollView scroll = new ScrollView(this); scroll.addView(view);
        new android.app.AlertDialog.Builder(this)
                .setTitle(compact ? "每张卡最终结果" : "完整调试记录")
                .setView(scroll).setPositiveButton("关闭", null).show();
    }

    private LinearLayout.LayoutParams row() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(12));
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
