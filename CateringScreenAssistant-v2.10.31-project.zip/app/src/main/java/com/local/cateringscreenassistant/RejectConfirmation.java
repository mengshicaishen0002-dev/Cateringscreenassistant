package com.local.cateringscreenassistant;

/** Pure post-Reject classifier. Never uses Jobs/assigned-job evidence. */
final class RejectConfirmation {
    enum Result { PENDING, CONFIRMED, DISAPPEARED_UNKNOWN }

    private RejectConfirmation() { }

    static Result classify(boolean sameCardVisible, boolean processingAck,
                           int consecutiveMissingReads) {
        return classify(sameCardVisible, processingAck, consecutiveMissingReads, false);
    }

    /**
     * Multi-evidence confirmation. A positive processing acknowledgement remains the strongest
     * signal. Otherwise a newly visible, different top card plus disappearance of the original
     * card is enough to confirm the Reject without waiting for another blind retry. Two
     * consecutive misses are still required when no replacement top card is visible.
     */
    static Result classify(boolean sameCardVisible, boolean processingAck,
                           int consecutiveMissingReads, boolean differentTopVisible) {
        if (sameCardVisible) return Result.PENDING;
        if (processingAck && consecutiveMissingReads >= 1) return Result.CONFIRMED;
        if (differentTopVisible && consecutiveMissingReads >= 1) return Result.CONFIRMED;
        if (consecutiveMissingReads < 2) return Result.PENDING;
        return Result.DISAPPEARED_UNKNOWN;
    }
}
