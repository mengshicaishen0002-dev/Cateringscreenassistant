package com.local.cateringscreenassistant;

public class RejectConfirmationTest {
    static int n;
    static void check(boolean v) { n++; if (!v) throw new AssertionError("case " + n); }
    public static void main(String[] args) {
        check(RejectConfirmation.classify(true, true, 5) == RejectConfirmation.Result.PENDING);
        check(RejectConfirmation.classify(false, true, 1) == RejectConfirmation.Result.CONFIRMED);
        check(RejectConfirmation.classify(false, true, 2) == RejectConfirmation.Result.CONFIRMED);
        check(RejectConfirmation.classify(false, false, 1, true) == RejectConfirmation.Result.CONFIRMED);
        check(RejectConfirmation.classify(false, false, 1, false) == RejectConfirmation.Result.PENDING);
        check(RejectConfirmation.classify(false, false, 2, false) == RejectConfirmation.Result.DISAPPEARED_UNKNOWN);
        System.out.println(n + " reject-confirmation cases passed");
    }
}
