# v2.10.31 audit

Focused changes based on 2026-09-10 device traces:

1. Reject confirmation now accepts a different live top card plus disappearance of the original card as positive multi-evidence confirmation, reducing unnecessary second Reject attempts and REJECT_UNKNOWN outcomes.
2. Reject targeting prefers Accessibility paired-action geometry before OCR mirrored-coordinate fallback.
3. Amount/mileage failures log the exact failed threshold (for example `$26.00<60.00` or `18.7mi>15.0mi`).
4. The default processing-history view collapses each card to one final result while preserving a separate full raw-debug history view.
5. Scan cadence, Accept thresholds, city/time rules, Pasadena rule semantics, and Accept dispatch logic are unchanged.

Regression suite: run-regression-tests.sh passes all pure policy/invariant tests.
