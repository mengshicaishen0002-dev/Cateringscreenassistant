package com.local.cateringscreenassistant;

public final class RejectConfirmPriorityPolicyTest {
    private static int tests;

    private static void check(boolean condition, String message) {
        tests++;
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        check(RejectConfirmPriorityPolicy.firstProbeDelayMs() == 70L, "first delay");
        check(RejectConfirmPriorityPolicy.reprobeDelayMs() == 180L, "reprobe delay");
        check(RejectConfirmPriorityPolicy.probeSoftBudgetMs() == 45L, "probe budget");
        check(RejectConfirmPriorityPolicy.probeMaxNodes() == 48, "node budget");
        check(RejectConfirmPriorityPolicy.foregroundYieldMs() == 220L, "foreground yield");
        check(RejectConfirmPriorityPolicy.foregroundRecheckMs() == 80L, "foreground recheck");
        check(RejectConfirmPriorityPolicy.finalTailMs() == 1600L, "final tail");
        check(RejectConfirmPriorityPolicy.finalTailPollMs() == 160L, "final tail poll");
        check(RejectConfirmPriorityPolicy.maxBackgroundProbes() == 2, "probe cap");
        check(RejectConfirmPriorityPolicy.maxBackgroundAgeMs() == 950L, "age cap");

        String oldOffer = "$29–39 Est. 2.1 mi Tomorrow at 10:15 AM Mendocino Farms • Huntington Beach, CA";
        String sameOffer = "$29-39 2.1 mi Tomorrow at 10:15 AM Mendocino Farms Huntington Beach CA";
        String newOffer = "$66.67 Est. 1.8 mi Tomorrow at 10:00 AM Mendocino Farms • El Segundo, CA";
        check(!RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldOffer, sameOffer), "same offer must not defer");
        check(RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldOffer, newOffer), "new offer must defer");
        check(!RejectConfirmPriorityPolicy.shouldDeferForNewTop(oldOffer, ""), "blank top");

        check(RejectConfirmPriorityPolicy.shouldStopBackground(1, 100L, true), "budget stop");
        check(RejectConfirmPriorityPolicy.shouldStopBackground(2, 100L, false), "probe cap stop");
        check(RejectConfirmPriorityPolicy.shouldStopBackground(1, 950L, false), "age stop");
        check(!RejectConfirmPriorityPolicy.shouldStopBackground(1, 400L, false), "ordinary probe continues");

        System.out.println(tests + " reject-confirm priority cases passed");
    }
}
