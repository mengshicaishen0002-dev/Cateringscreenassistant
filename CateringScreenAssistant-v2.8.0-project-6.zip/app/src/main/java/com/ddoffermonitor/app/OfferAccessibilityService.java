package com.ddoffermonitor.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * DoorDash Offers monitor.
 *
 * Design rule: this service may navigate Offers/date/detail screens, but NEVER performs the
 * final scheduling action. Claim/Acknowledge nodes are treated as protected final actions.
 */
public class OfferAccessibilityService extends AccessibilityService {
    private static final String DASHER = "com.doordash.driverapp";
    private static final long EVENT_DEBOUNCE_MS = 110;
    private static final long WATCHDOG_MS = 550;
    private static final long ACTION_MIN_GAP_MS = 260;
    private static final long DETAIL_PARSE_GRACE_MS = 1400;
    private static final long DETAIL_OPEN_TIMEOUT_MS = 1200;
    private static final long DATE_CHANGE_TIMEOUT_MS = 1200;
    private static final long MANUAL_RETURN_GRACE_MS = 1600;
    private static final long IGNORE_COOLDOWN_MS = 20000;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Map<String, Long> cooldown = new HashMap<String, Long>();

    private WindowManager wm;
    private View overlay;
    private boolean manualPending;
    private long manualStartedAt;
    private long lastEventAt;
    private long lastActionAt;
    private long detailFirstSeenAt;
    private long detailOpenRequestedAt;
    private long returnHoldUntil;
    private long dateChangeDeadline;
    private long dateChangeSettleUntil;
    private String dateChangeFromFingerprint = "";
    private String lastFingerprint = "";
    private String pendingCardKey = "";
    private double pendingPay;
    private int dayCursor = -1;

    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            try {
                if (isEnabledByUser()) {
                    AccessibilityNodeInfo root = getRootInActiveWindow();
                    if (root != null && root.getPackageName() != null && DASHER.contentEquals(root.getPackageName())) {
                        scheduleScan(0);
                    }
                }
            } catch (Throwable t) {
                log("WATCHDOG_ERROR", shortErr(t));
            } finally {
                h.postDelayed(this, WATCHDOG_MS);
            }
        }
    };

    private final Runnable scanner = new Runnable() {
        @Override public void run() { scanNow(); }
    };

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        log("SERVICE_CONNECTED", "native-v1.1.1");
        h.removeCallbacks(watchdog);
        h.post(watchdog);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null || !DASHER.contentEquals(event.getPackageName())) return;
        if (!isEnabledByUser()) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastEventAt < EVENT_DEBOUNCE_MS) return;
        lastEventAt = now;
        scheduleScan(80);
    }

    @Override public void onInterrupt() { log("SERVICE_INTERRUPTED", ""); }

    @Override public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        removeOverlay();
        super.onDestroy();
    }

    private void scheduleScan(long delayMs) {
        h.removeCallbacks(scanner);
        h.postDelayed(scanner, delayMs);
    }

    private void scanNow() {
        if (!isEnabledByUser()) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null || !DASHER.contentEquals(root.getPackageName())) return;

        Snapshot s = Snapshot.build(root);
        if (s.nodes.isEmpty()) return;
        long now = SystemClock.uptimeMillis();

        if (manualPending) {
            observeManualResult(s);
            return;
        }

        String fp = s.fingerprint();

        // A date tap is not considered complete merely because ACTION_CLICK returned true.
        // Wait for the Accessibility tree/selection to actually change, with a short timeout.
        if (dateChangeDeadline > 0) {
            if (now < dateChangeSettleUntil) return;
            if (!fp.equals(dateChangeFromFingerprint)) {
                log("DATE_STATE_CHANGED", "");
                dateChangeDeadline = 0;
                dateChangeFromFingerprint = "";
            } else if (now < dateChangeDeadline) {
                return;
            } else {
                log("DATE_STATE_TIMEOUT", "tree unchanged after date tap");
                dateChangeDeadline = 0;
                dateChangeFromFingerprint = "";
            }
        }

        // Do not let the next scan race the transition into an offer detail page.
        if (detailOpenRequestedAt > 0 && !s.hasProtectedFinalAction()) {
            if (now - detailOpenRequestedAt < DETAIL_OPEN_TIMEOUT_MS) return;
            log("DETAIL_OPEN_TIMEOUT", "pay=" + pendingPay + " key=" + pendingCardKey);
            detailOpenRequestedAt = 0;
            detailFirstSeenAt = 0;
            pendingPay = 0;
            pendingCardKey = "";
        }

        if (now < returnHoldUntil) return;

        if (fp.equals(lastFingerprint) && now - lastActionAt < ACTION_MIN_GAP_MS) return;
        lastFingerprint = fp;

        // Detail is intentionally checked first: final action nodes are protected and never clicked.
        if (s.hasProtectedFinalAction()) {
            handleDetail(s);
            return;
        }

        Node retry = s.findExactAny("Retry", "Try again");
        if (retry != null) {
            autoClick(retry, "RETRY");
            return;
        }

        if (s.looksLikeOfferList()) {
            handleOfferList(s);
            return;
        }

        Node offers = s.findExactAny("Offers");
        if (offers != null) autoClick(offers, "OPEN_OFFERS");
    }

    private void handleOfferList(Snapshot s) {
        detailFirstSeenAt = 0;
        detailOpenRequestedAt = 0;

        final double minPay = numPref("minPay", 30.0);
        List<Node> money = s.moneyNodes();
        long wallNow = System.currentTimeMillis();

        for (Node n : money) {
            double pay = parseMoney(n.text);
            if (pay <= 0) continue;
            String key = s.offerKey(n);
            if (pay < minPay) {
                logOnce("IGNORE_PAY", key, String.format(Locale.US, "pay=%.2f min=%.2f %s", pay, minPay, s.cardSummary(n)));
                continue;
            }
            Long until = cooldown.get(key);
            if (until != null && until.longValue() > wallNow) continue;

            pendingCardKey = key;
            pendingPay = pay;
            cooldown.put(key, wallNow + IGNORE_COOLDOWN_MS);
            if (autoClick(n, "OPEN_DETAIL pay=" + fmt(pay))) {
                detailOpenRequestedAt = SystemClock.uptimeMillis();
                return;
            }
            log("CARD_CLICK_FAIL", key);
        }

        cycleDate(s);
    }

    private void cycleDate(Snapshot s) {
        List<Node> dates = s.dateButtons();
        if (dates.size() < 2) {
            logThrottled("DATE_ROW_NOT_FOUND", "found=" + dates.size() + " " + s.dateDiagnostic(), 5000);
            return;
        }

        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        int count = Math.min(7, dates.size());
        int selected = -1;
        for (int i = 0; i < count; i++) {
            if (dates.get(i).selected || dates.get(i).checked) { selected = i; break; }
        }
        if (selected >= 0) dayCursor = selected;

        for (int tries = 0; tries < 7; tries++) {
            dayCursor = (dayCursor + 1) % 7;
            if (!p.getBoolean("d" + dayCursor, true)) continue;
            if (dayCursor >= count) continue;
            Node target = dates.get(dayCursor);
            if (target.selected || target.checked) continue;
            String before = s.fingerprint();
            if (autoClick(target, "DATE_CLICK D" + (dayCursor + 1))) {
                long now = SystemClock.uptimeMillis();
                dateChangeFromFingerprint = before;
                dateChangeSettleUntil = now + 180;
                dateChangeDeadline = now + DATE_CHANGE_TIMEOUT_MS;
                return;
            }
            log("DATE_CLICK_FAIL", "D" + (dayCursor + 1) + " text=" + target.text);
        }
    }

    private void handleDetail(Snapshot s) {
        long now = SystemClock.uptimeMillis();
        detailOpenRequestedAt = 0;
        if (detailFirstSeenAt == 0) detailFirstSeenAt = now;

        double pay = s.bestDetailMoney();
        if (pay <= 0 && pendingPay > 0) pay = pendingPay;
        Double miles = s.findMiles();

        if (pay <= 0 || miles == null || miles.doubleValue() <= 0) {
            if (now - detailFirstSeenAt < DETAIL_PARSE_GRACE_MS) return;
            log("DISTANCE_PARSE_FAIL", "pay=" + pay + " miles=" + miles + " " + s.summary());
            ignoreCurrentAndBack("PARSE_FAIL");
            return;
        }

        double mi = miles.doubleValue();
        double ppm = pay / mi;
        double minPpm = numPref("minPpm", 2.0);
        double maxMiles = numPref("maxMiles", 99.0);

        if (mi > maxMiles) {
            log("IGNORE_MILES", String.format(Locale.US, "$%.2f %.2fmi max=%.2f %s", pay, mi, maxMiles, s.summary()));
            ignoreCurrentAndBack("MILES");
            return;
        }
        if (ppm < minPpm) {
            log("IGNORE_PPM", String.format(Locale.US, "$%.2f %.2fmi $%.2f/mi min=$%.2f/mi %s", pay, mi, ppm, minPpm, s.summary()));
            ignoreCurrentAndBack("PPM");
            return;
        }

        // Candidate reached. From this point all automation is frozen until the user acts.
        manualPending = true;
        manualStartedAt = SystemClock.uptimeMillis();
        String details = String.format(Locale.US, "$%.2f | %.2f mi | $%.2f/mi | %s", pay, mi, ppm, s.summary());
        log("CANDIDATE", details);
        alertCandidate(pay, mi, ppm, s.summary());
    }

    private void ignoreCurrentAndBack(String reason) {
        if (pendingCardKey.length() > 0) cooldown.put(pendingCardKey, System.currentTimeMillis() + IGNORE_COOLDOWN_MS);
        safeBack(reason);
        pendingPay = 0;
        pendingCardKey = "";
        detailFirstSeenAt = 0;
        detailOpenRequestedAt = 0;
    }

    private void observeManualResult(Snapshot s) {
        if (s.hasAny("successfully scheduled", "added to your schedule", "you claimed", "scheduled successfully")) {
            log("CLAIM_CONFIRMED", s.summary());
            clearManual(true);
            return;
        }
        if (s.hasAny("no longer available", "already claimed", "not available", "someone else", "offer is unavailable")) {
            log("CLAIM_FAILED", s.summary());
            clearManual(true);
            return;
        }

        // If the user manually acted and DoorDash returned to the offers list without explicit
        // confirmation text, record it as unverified rather than claiming success.
        if (!s.hasProtectedFinalAction() && s.looksLikeOfferList() && SystemClock.uptimeMillis() - manualStartedAt > MANUAL_RETURN_GRACE_MS) {
            log("MANUAL_RESULT_UNVERIFIED", s.summary());
            clearManual(true);
        }
    }

    private void clearManual(boolean resume) {
        manualPending = false;
        pendingPay = 0;
        pendingCardKey = "";
        detailFirstSeenAt = 0;
        detailOpenRequestedAt = 0;
        removeOverlay();
        if (resume) scheduleScan(500);
    }

    private boolean autoClick(Node n, String reason) {
        if (n == null) return false;
        if (manualPending) return false;
        if (isProtectedText(n.text) || subtreeHasProtectedText(n.node, 40)) {
            log("BLOCKED_FINAL_ACTION", reason + " text=" + n.text);
            return false;
        }
        long now = SystemClock.uptimeMillis();
        if (now - lastActionAt < ACTION_MIN_GAP_MS) return false;

        boolean ok = false;
        AccessibilityNodeInfo x = n.node;
        for (int i = 0; i < 6 && x != null; i++) {
            if (isProtectedText(nodeText(x)) || subtreeHasProtectedText(x, 40)) return false;
            if (x.isEnabled() && x.isClickable()) {
                try { ok = x.performAction(AccessibilityNodeInfo.ACTION_CLICK); } catch (Throwable ignored) {}
                if (ok) break;
            }
            x = x.getParent();
        }

        if (!ok && !n.rect.isEmpty()) {
            ok = gestureTap(n.rect.centerX(), n.rect.centerY());
        }
        if (ok) {
            lastActionAt = SystemClock.uptimeMillis();
            log("AUTO_ACTION", reason + " text=" + n.text);
        }
        return ok;
    }

    private boolean gestureTap(float x, float y) {
        if (manualPending) return false;
        try {
            Path p = new Path();
            p.moveTo(x, y);
            GestureDescription.Builder b = new GestureDescription.Builder();
            b.addStroke(new GestureDescription.StrokeDescription(p, 0, 55));
            return dispatchGesture(b.build(), null, null);
        } catch (Throwable t) {
            log("GESTURE_FAIL", shortErr(t));
            return false;
        }
    }

    private void safeBack(String reason) {
        if (manualPending) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastActionAt < ACTION_MIN_GAP_MS) {
            final String why = reason;
            h.postDelayed(new Runnable() { @Override public void run() { safeBack(why); } }, ACTION_MIN_GAP_MS);
            return;
        }
        if (performGlobalAction(GLOBAL_ACTION_BACK)) {
            lastActionAt = SystemClock.uptimeMillis();
            returnHoldUntil = lastActionAt + 420;
            log("AUTO_BACK", reason);
        } else {
            log("BACK_FAIL", reason);
        }
    }

    private boolean subtreeHasProtectedText(AccessibilityNodeInfo root, int cap) {
        if (root == null) return false;
        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<AccessibilityNodeInfo>();
        q.add(root);
        int seen = 0;
        while (!q.isEmpty() && seen++ < cap) {
            AccessibilityNodeInfo n = q.removeFirst();
            if (isProtectedText(nodeText(n))) return true;
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) q.addLast(c);
            }
        }
        return false;
    }

    private static String nodeText(AccessibilityNodeInfo n) {
        if (n == null) return "";
        CharSequence t = n.getText();
        if (t != null && t.length() > 0) return t.toString().trim();
        CharSequence d = n.getContentDescription();
        return d == null ? "" : d.toString().trim();
    }

    private static boolean isProtectedText(String text) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.US);
        return l.contains("claim and schedule") || l.equals("claim") || l.equals("acknowledge") || l.contains("confirm claim");
    }

    private void alertCandidate(double pay, double mi, double ppm, String summary) {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                long[] wave = new long[]{0, 280, 120, 420, 120, 650};
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(wave, -1));
                else v.vibrate(1200);
            }
        } catch (Throwable ignored) {}

        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(this, uri);
            if (r != null) r.play();
        } catch (Throwable ignored) {}

        showOverlay(String.format(Locale.US,
                "发现合格预约单  —  自动操作已停止\n$%.2f   %.2f mi   $%.2f/mi\n请在 Dasher 里手动 Claim\n%s",
                pay, mi, ppm, compact(summary, 180)));

        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            String channel = "candidate";
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(channel, "Offer alerts", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
            nb.setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("DD Offer Monitor：发现合格预约单")
                    .setContentText(String.format(Locale.US, "$%.2f / %.2f mi / $%.2f/mi — 请手动 Claim", pay, mi, ppm))
                    .setAutoCancel(true);
            nm.notify(1001, nb.build());
        } catch (Throwable t) {
            log("NOTIFICATION_FAIL", shortErr(t));
        }
    }

    private void showOverlay(String text) {
        removeOverlay();
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        try {
            TextView tv = new TextView(this);
            tv.setText(text);
            tv.setTextSize(16);
            tv.setPadding(26, 18, 26, 18);
            tv.setTextColor(0xff000000);
            tv.setBackgroundColor(0xeefff59d);
            overlay = tv;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP;
            lp.y = 70;
            wm.addView(overlay, lp);
        } catch (Throwable t) {
            overlay = null;
            log("OVERLAY_FAIL", shortErr(t));
        }
    }

    private void removeOverlay() {
        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Throwable ignored) {}
        }
        overlay = null;
    }

    private boolean isEnabledByUser() {
        return getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("enabled", false);
    }

    private double numPref(String key, double def) {
        try { return Double.parseDouble(getSharedPreferences("cfg", MODE_PRIVATE).getString(key, String.valueOf(def))); }
        catch (Throwable t) { return def; }
    }

    private static String fmt(double v) { return String.format(Locale.US, "%.2f", v); }

    private static double parseMoney(String s) {
        if (s == null) return 0;
        Matcher m = Pattern.compile("\\$\\s*([0-9]+(?:\\.[0-9]{1,2})?)").matcher(s);
        try { return m.find() ? Double.parseDouble(m.group(1)) : 0; } catch (Throwable t) { return 0; }
    }

    private final Map<String, Long> logThrottle = new HashMap<String, Long>();
    private void logOnce(String type, String key, String msg) {
        String k = type + "|" + key;
        long now = System.currentTimeMillis();
        Long prev = logThrottle.get(k);
        if (prev != null && now - prev.longValue() < 15000) return;
        logThrottle.put(k, now);
        log(type, msg);
    }
    private void logThrottled(String type, String msg, long interval) {
        long now = System.currentTimeMillis();
        Long prev = logThrottle.get(type);
        if (prev != null && now - prev.longValue() < interval) return;
        logThrottle.put(type, now);
        log(type, msg);
    }

    private void log(String type, String msg) {
        try {
            File dir = getExternalFilesDir(null);
            if (dir == null) return;
            File f = new File(dir, "dd_offer_monitor.log");
            FileWriter w = new FileWriter(f, true);
            String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
            w.write(ts + "\t" + type + "\t" + (msg == null ? "" : msg.replace('\n', ' ')) + "\n");
            w.close();
        } catch (Throwable ignored) {}
    }

    private static String shortErr(Throwable t) {
        if (t == null) return "";
        String m = t.getMessage();
        return t.getClass().getSimpleName() + (m == null ? "" : ":" + m);
    }
    private static String compact(String s, int max) {
        if (s == null) return "";
        String x = s.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        return x.length() <= max ? x : x.substring(0, max) + "…";
    }

    static final class Node {
        final AccessibilityNodeInfo node;
        final String text;
        final String cls;
        final String id;
        final Rect rect;
        final boolean selected;
        final boolean checked;
        final boolean clickable;
        final boolean enabled;
        Node(AccessibilityNodeInfo node, String text, String cls, String id, Rect rect,
             boolean selected, boolean checked, boolean clickable, boolean enabled) {
            this.node = node; this.text = text; this.cls = cls; this.id = id; this.rect = rect;
            this.selected = selected; this.checked = checked; this.clickable = clickable; this.enabled = enabled;
        }
    }

    static final class Snapshot {
        final List<Node> nodes;
        final Rect rootRect;
        Snapshot(List<Node> nodes, Rect rootRect) { this.nodes = nodes; this.rootRect = rootRect; }

        static Snapshot build(AccessibilityNodeInfo root) {
            ArrayList<Node> out = new ArrayList<Node>();
            Rect rr = new Rect();
            try { root.getBoundsInScreen(rr); } catch (Throwable ignored) {}
            ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<AccessibilityNodeInfo>();
            q.add(root);
            int cap = 1000;
            while (!q.isEmpty() && out.size() < cap) {
                AccessibilityNodeInfo n = q.removeFirst();
                String txt = nodeText(n);
                Rect r = new Rect();
                try { n.getBoundsInScreen(r); } catch (Throwable ignored) {}
                String cls = n.getClassName() == null ? "" : n.getClassName().toString();
                String id = n.getViewIdResourceName() == null ? "" : n.getViewIdResourceName();
                out.add(new Node(n, txt, cls, id, r, n.isSelected(), n.isChecked(), n.isClickable(), n.isEnabled()));
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) q.addLast(c);
                }
            }
            return new Snapshot(out, rr);
        }

        boolean hasAny(String... phrases) {
            for (Node n : nodes) {
                String l = n.text.toLowerCase(Locale.US);
                for (String p : phrases) if (l.contains(p.toLowerCase(Locale.US))) return true;
            }
            return false;
        }

        Node findExactAny(String... vals) {
            for (Node n : nodes) for (String v : vals) if (n.text.equalsIgnoreCase(v)) return n;
            return null;
        }

        boolean hasProtectedFinalAction() {
            for (Node n : nodes) if (isProtectedText(n.text)) return true;
            return false;
        }

        boolean looksLikeOfferList() {
            return findExactAny("Offers") != null || !moneyNodes().isEmpty();
        }

        List<Node> moneyNodes() {
            ArrayList<Node> a = new ArrayList<Node>();
            Pattern exact = Pattern.compile("^\\s*\\$\\s*[0-9]+(?:\\.[0-9]{1,2})?\\s*$");
            for (Node n : nodes) {
                if (exact.matcher(n.text).matches()) a.add(n);
            }
            Collections.sort(a, new Comparator<Node>() {
                @Override public int compare(Node x, Node y) {
                    int dy = Integer.compare(x.rect.top, y.rect.top);
                    return dy != 0 ? dy : Integer.compare(x.rect.left, y.rect.left);
                }
            });
            return a;
        }

        double bestDetailMoney() {
            List<Node> m = moneyNodes();
            double best = 0;
            for (Node n : m) {
                double v = parseMoney(n.text);
                // Detail pay is normally the prominent amount. Prefer a plausible offer amount.
                if (v > best && v < 10000) best = v;
            }
            return best;
        }

        Double findMiles() {
            Pattern p = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s*(?:mi|mile|miles)\\b", Pattern.CASE_INSENSITIVE);
            for (Node n : nodes) {
                Matcher m = p.matcher(n.text);
                if (m.find()) {
                    try { return Double.valueOf(Double.parseDouble(m.group(1))); } catch (Throwable ignored) {}
                }
            }
            return null;
        }

        List<Node> dateButtons() {
            ArrayList<Node> candidates = new ArrayList<Node>();
            int screenH = rootRect.height() > 0 ? rootRect.height() : 2400;
            int screenW = rootRect.width() > 0 ? rootRect.width() : 1080;
            int topLimit = (int) (screenH * 0.48f);
            int maxW = (int) (screenW * 0.36f);
            int maxH = (int) (screenH * 0.13f);

            // DoorDash builds may expose the date strip as Button, Compose semantics, or
            // clickable TextView containers. Do not depend on one widget class.
            for (Node n : nodes) {
                if (n.rect.isEmpty() || n.rect.top < 0 || n.rect.top > topLimit) continue;
                if (n.rect.width() < 24 || n.rect.width() > maxW) continue;
                if (n.rect.height() < 20 || n.rect.height() > maxH) continue;
                boolean interactive = n.cls.contains("Button") || n.clickable || n.selected || n.checked;
                if (!interactive || !n.enabled) continue;
                if (!(dateLike(n.text) || n.cls.contains("Button") || n.selected || n.checked)) continue;
                addDateCandidateDedup(candidates, n);
            }
            if (candidates.size() < 2) return candidates;

            ArrayList<Node> best = new ArrayList<Node>();
            int bestScore = Integer.MIN_VALUE;
            int yTol = Math.max(42, screenH / 32);
            for (Node seed : candidates) {
                ArrayList<Node> band = new ArrayList<Node>();
                int dateLikeCount = 0, stateCount = 0, clickableCount = 0;
                for (Node x : candidates) {
                    if (Math.abs(x.rect.centerY() - seed.rect.centerY()) <= yTol) {
                        addDateCandidateDedup(band, x);
                    }
                }
                for (Node x : band) {
                    if (dateLike(x.text)) dateLikeCount++;
                    if (x.selected || x.checked) stateCount++;
                    if (x.clickable) clickableCount++;
                }
                int score = band.size() * 2 + dateLikeCount * 5 + stateCount * 3 + clickableCount;
                if (band.size() >= 2 && score > bestScore) {
                    bestScore = score;
                    best = band;
                }
            }

            // If an extra navigation control shares the row, keep the seven strongest date-like
            // controls, then restore left-to-right order.
            if (best.size() > 7) {
                Collections.sort(best, new Comparator<Node>() {
                    @Override public int compare(Node a, Node b) {
                        return Integer.compare(dateQuality(b), dateQuality(a));
                    }
                });
                best = new ArrayList<Node>(best.subList(0, 7));
            }
            Collections.sort(best, new Comparator<Node>() {
                @Override public int compare(Node a, Node b) { return Integer.compare(a.rect.centerX(), b.rect.centerX()); }
            });
            return best;
        }

        private static int dateQuality(Node n) {
            int q = 0;
            if (dateLike(n.text)) q += 8;
            if (n.selected || n.checked) q += 4;
            if (n.clickable) q += 2;
            if (n.cls.contains("Button")) q += 1;
            return q;
        }

        private static boolean dateLike(String text) {
            if (text == null) return false;
            String t = text.toLowerCase(Locale.US).replace('\n', ' ').trim();
            if (t.matches(".*\\b(mon|monday|tue|tues|tuesday|wed|wednesday|thu|thur|thurs|thursday|fri|friday|sat|saturday|sun|sunday)\\b.*")) return true;
            return t.matches(".*(?:^|\\D)(?:[1-9]|[12][0-9]|3[01])(?:\\D|$).*");
        }

        private static void addDateCandidateDedup(List<Node> list, Node n) {
            for (int i = 0; i < list.size(); i++) {
                Node x = list.get(i);
                if (Math.abs(x.rect.centerX() - n.rect.centerX()) <= 18
                        && Math.abs(x.rect.centerY() - n.rect.centerY()) <= 18) {
                    if (dateQuality(n) > dateQuality(x)) list.set(i, n);
                    return;
                }
            }
            list.add(n);
        }

        String dateDiagnostic() {
            StringBuilder b = new StringBuilder("topControls=");
            int shown = 0;
            int screenH = rootRect.height() > 0 ? rootRect.height() : 2400;
            for (Node n : nodes) {
                if (n.rect.isEmpty() || n.rect.top > screenH * 0.5f) continue;
                if (!(n.clickable || n.cls.contains("Button") || n.selected || n.checked)) continue;
                if (shown++ > 0) b.append(" | ");
                b.append('[').append(compact(n.text, 36)).append(" cls=")
                        .append(compact(n.cls, 22)).append(" x=").append(n.rect.centerX())
                        .append(" y=").append(n.rect.centerY()).append(" c=").append(n.clickable)
                        .append(" s=").append(n.selected || n.checked).append(']');
                if (shown >= 18) break;
            }
            return b.toString();
        }

        String offerKey(Node money) {
            return money.text + "@" + (money.rect.centerY() / 24) + "|" + compact(cardSummary(money), 120);
        }

        String cardSummary(Node money) {
            if (money == null) return "";
            StringBuilder b = new StringBuilder();
            int cy = money.rect.centerY();
            int range = rootRect.height() > 0 ? rootRect.height() / 7 : 320;
            for (Node n : nodes) {
                if (n.text.length() == 0) continue;
                if (Math.abs(n.rect.centerY() - cy) <= range) {
                    if (b.length() > 0) b.append(" • ");
                    b.append(n.text);
                    if (b.length() > 220) break;
                }
            }
            return b.toString();
        }

        String fingerprint() {
            StringBuilder b = new StringBuilder();
            int k = 0;
            for (Node n : nodes) {
                if (n.text.length() == 0) continue;
                b.append(n.text).append('@').append(n.rect.left / 12).append(',').append(n.rect.top / 12).append(':').append(n.selected ? 'S' : '-').append(n.checked ? 'K' : '-').append(n.clickable ? 'C' : '-').append('|');
                if (++k >= 36) break;
            }
            return Integer.toHexString(b.toString().hashCode());
        }

        String summary() {
            StringBuilder b = new StringBuilder();
            int k = 0;
            for (Node n : nodes) {
                if (n.text.length() == 0) continue;
                if (b.length() > 0) b.append(" • ");
                b.append(n.text);
                if (++k >= 16 || b.length() > 300) break;
            }
            return b.toString();
        }
    }
}
